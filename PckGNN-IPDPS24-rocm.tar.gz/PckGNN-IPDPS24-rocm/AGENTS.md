# AGENTS.md — PckGNN ROCm/HIP 适配项目

## 项目概述

本项目是 **PckGNN**（论文 "Understanding and Bridging the Gaps in Current GNN Performance Optimizations", PPoPP'21）的 **ROCm/HIP 适配版本**。原始 CUDA 项目位于 `/home/hdz/testpath/rocm/PckGNN/PckGNN-IPDPS24-2080`。

PckGNN 是一个 GNN 性能基准测试和优化框架，集成了多种 GNN kernel 优化策略（SpMM/SDDMM 稀疏算子），对比了以下框架：
- **GNNAdvisor** — 参数自适应 GNN kernel，带 workload 分区
- **KG_GNN** — 知识引导的 GNN，SpMM/SDDMM/MM 流水线 + bin-packing
- **UBG** — PPoPP'21 论文提出的 GNN 优化框架
- **dgSPARSE / GE-SpMM** — 通用稀疏矩阵乘法库
- **cuSPARSE** — HIP 移植的 cuSPARSE 接口测试
- **Rabbit Order** — CPU 端图重排序（缓存局部性优化）

## 目标环境

- **超算**: `sunjw@60.245.128.10:65010`，路径 `/public/home/sunjw/scd/PckGNN-IPDPS24-rocm`
- **编译器/运行时**: ROCm 4.0.1, devtoolset 7.3.1 (GCC 7.3.1)
- **深度学习框架**: PyTorch 1.10.1+rocm4.0.1
- **目标 GPU**: gfx906 (AMD MI50/MI60)
- **Python**: 3.6

## 核心工作流

本项目的核心目的是 **本地修改 → 上传超算 → 编译测试 → 下载反馈 → 本地调整** 的迭代循环：

```
┌─────────────────────┐     tar + scp      ┌──────────────────────┐
│   本地开发环境        │ ─────────────────→ │   超算环境             │
│   (WSL2/Linux)      │                    │   (CentOS 7.6)       │
│                     │                    │                      │
│ - 修改源码           │                    │ - bash cmd2.sh build │
│ - 修改 setup.py      │                    │ - bash cmd2.sh test-*│
│ - 查看 build.log     │ ←───────────────── │ - 生成 build.log     │
│ - 根据日志调整代码    │     scp 下载日志    │                      │
└─────────────────────┘                    └──────────────────────┘
```

### 部署与测试完整流程

```bash
# ===== 1. 本地打包上传 =====
cd /home/hdz/testpath/rocm/PckGNN/
rm -rf PckGNN-IPDPS24-rocm.tar.gz
tar czf PckGNN-IPDPS24-rocm.tar.gz PckGNN-IPDPS24-rocm
scp -P65010 PckGNN-IPDPS24-rocm.tar.gz sunjw@60.245.128.10:~/scd

# ===== 2. 超算解压与准备 =====
ssh -p65010 sunjw@60.245.128.10
cd ~/scd
rm -rf PckGNN-IPDPS24-rocm
tar xzf PckGNN-IPDPS24-rocm.tar.gz -C ~/scd
cd ~/scd/PckGNN-IPDPS24-rocm

# ===== 3. 进入计算节点 =====
srun -p debug -N 1 -n 1 --gres=dcu:1 --pty bash

# 重新加载模块（计算节点环境可能不同）
module unload compiler/rocm/dtk/22.10.1
module load compiler/rocm/4.0.1
module load apps/PyTorch/1.10.1a0/pytorch_1.10.1-rocm_4.0.1
module list

# ===== 4. 编译 =====
bash cmd2.sh build

# ===== 5. 验证导入 =====
bash cmd2.sh verify-imports

# ===== 6. 运行测试 =====
bash cmd2.sh test-gcn ~/scd/data/pckgnn/BlogCatalog.pt
bash cmd2.sh test-spmm ~/scd/data/pckgnn/BlogCatalog.pt 64

# ===== 7. 查看结果 =====
cat build.log

# ===== 8. 本地下载日志 =====
# 在本地执行:
scp -P65010 sunjw@60.245.128.10:/public/home/sunjw/scd/PckGNN-IPDPS24-rocm/build.log \
    /home/hdz/testpath/rocm/PckGNN/PckGNN-IPDPS24-rocm/
```

## 项目结构

```
PckGNN-IPDPS24-rocm/
├── cmd2.sh                      # ★ 主控脚本 (setup.py 编译 + 测试)
├── tips.sh                      # 导入/依赖全面检查 (6 阶段诊断)
├── READMEv1.md                  # 当前 README (推荐参考)
├── READMEv0.md                  # 旧版 README (Makefile 方式, 已废弃)
├── build.log                    # 最新编译/测试输出日志
│
├── GNNAdvisor/                  # GNNAdvisor 框架
│   ├── gnn_conv.py              #   PyTorch autograd GNN 层 (GCN/GIN)
│   ├── param.py                 #   运行时参数自动调优
│   └── GNNConv/
│       ├── setup.py             #   PyTorch CUDAExtension 编译
│       ├── GNNAdvisor.cpp       #   Host 端 C++ (PyTorch 绑定)
│       └── GNNAdvisor_kernel.cu #   Device 端 HIP kernel
│
├── KG_GNN/                      # KG-GNN 框架
│   ├── KG_GNN.py                #   Python 封装
│   └── core/
│       ├── setup.py             #   PyTorch CUDAExtension 编译
│       ├── include/             #   C++ 头文件
│       └── src/                 #   HIP kernel 源文件 (.cu + .cpp)
│
├── UBG/                         # UBG 框架
│   ├── setup.py                 #   PyTorch CUDAExtension 编译
│   ├── include/                 #   头文件
│   └── src/                     #   HIP kernel 源文件
│
├── dgSPARSE/                    # 稀疏算子库
│   ├── src/ge-spmm/             #   GE-SpMM kernel
│   ├── src/sddmm/               #   SDDMM kernel
│   └── example/ge-spmm/
│       └── setup.py             #   GESpMM PyTorch CUDAExtension 编译
│
├── rabbit_module/               # Rabbit Order 图重排序 (CPU-only)
│   ├── rabbit_order.py          #   Python 封装
│   └── src/
│       └── setup.py             #   CppExtension 编译 (无需 ROCm)
│
├── cuSPARSE/                    # cuSPARSE HIP 测试 (独立二进制)
│
├── test/                        # Python 测试套件
│   ├── test_gcn.py              #   GCN 模型测试
│   ├── test_gat.py              #   GAT 模型测试
│   ├── test_gin.py              #   GIN 模型测试
│   ├── test_spmm.py             #   SpMM kernel 基准
│   ├── test_sddmm.py            #   SDDMM kernel 基准
│   ├── test_mm.py               #   MM kernel 基准
│   └── lib/                     #   测试 harness (每框架一个)
│       ├── dgl_test.py          #     DGL 测试 harness
│       ├── pyg_test.py          #     PyG 测试 harness
│       ├── gnna_test.py         #     GNNAdvisor 测试 harness
│       ├── kg_test.py           #     KG-GNN 测试 harness
│       ├── ubg_test.py          #     UBG 测试 harness
│       ├── ge_test.py           #     GE-SpMM 测试 harness
│       └── cusparse_test.py     #     cuSPARSE 测试 harness
│
├── dataset/                     # 数据集预处理脚本
├── run_*.sh                     # 批量测试脚本 (gcn/gat/gin/spmm/sddmm)
├── matrix_list / matrix_sample  # 数据集列表
└── pic/                         # 论文图表生成
```

## 5 个 C++/HIP 扩展模块

| 模块 | setup.py 位置 | 类型 | 用途 |
|------|--------------|------|------|
| `rabbit` | `rabbit_module/src/` | CPU (CppExtension) | 图重排序 |
| `GNNAdvisor` | `GNNAdvisor/GNNConv/` | HIP (CUDAExtension) | 参数自适应 SpMM/GNN |
| `KGGNN` | `KG_GNN/core/` | HIP (CUDAExtension) | KG-GNN SpMM/SDDMM/MM |
| `UBGGNN` | `UBG/` | HIP (CUDAExtension) | UBG GNN 编译/运行时 |
| `GESpMM` | `dgSPARSE/example/ge-spmm/` | HIP (CUDAExtension) | GE-SpMM |

## cmd2.sh 命令参考

```bash
# 编译
bash cmd2.sh build              # 编译所有扩展
bash cmd2.sh build-rabbit       # 仅编译 rabbit (CPU, 最快)
bash cmd2.sh build-gnna         # 仅编译 GNNAdvisor
bash cmd2.sh build-kggnn        # 仅编译 KGGNN
bash cmd2.sh build-ubg          # 仅编译 UBGGNN
bash cmd2.sh build-gespmm       # 仅编译 GESpMM

# 测试 (需先编译对应扩展)
bash cmd2.sh test-gcn    <dataset.pt> [outcsv]
bash cmd2.sh test-gat    <dataset.pt> [outcsv]
bash cmd2.sh test-gin    <dataset.pt> [outcsv]
bash cmd2.sh test-spmm   <dataset.pt> <in_dim> [outcsv]
bash cmd2.sh test-sddmm  <dataset.pt> <in_dim> [outcsv]
bash cmd2.sh test-mm

# 工具
bash cmd2.sh verify-imports     # 验证所有扩展可导入
bash cmd2.sh clean              # 清理编译产物
bash cmd2.sh info               # 查看环境信息
```

## HIP 适配要点

本项目通过 `hipify-perl --inplace` 将 CUDA 代码自动转换为 HIP，然后对以下 8 类无法自动转换的内容进行了**手动修复**：

1. **Warp Shuffle**: `__shfl_down_sync(FULLMASK, ...)` → `__shfl_down(...)` (HIP 不支持 mask 参数)
2. **cuBLAS → hipBLAS**: `cublasHandle_t` → `hipblasHandle_t`, `CUBLAS_OP_T` → `HIPBLAS_OP_T`
3. **cuRAND → hipRAND**: `curandState` → `hiprandState`, `curand_init` → `hiprand_init`
4. **cuSPARSE 常量**: `CUSPARSE_INDEX_32I` → `HIPSPARSE_INDEX_32I`
5. **`__ldg` 纹理加载**: 替换为普通指针解引用 `*(ptr + offset)`
6. **动态共享内存**: `cudaFuncSetAttribute` → `hipFuncSetAttribute`
7. **自定义函数/宏**: `cudaMalloc2` → `hipMalloc2`, `checkCudaErrors` → `checkHipErrors`
8. **Profiler 头文件**: 移除 `cuda_profiler_api.h`

> 注意: `__ldg` 替换为普通加载可能影响某些访问模式的性能。每个被 hipify 的文件都有 `.prehip` 后缀的原始 CUDA 备份。

## PYTHONPATH 说明

`cmd2.sh` 自动设置 `PYTHONPATH`，所有模块导入都在项目内部解析：

- 项目根目录
- `GNNAdvisor/` + `GNNAdvisor/GNNConv/` + `build/lib.*/`
- `KG_GNN/` + `KG_GNN/core/` + `build/lib.*/`
- `UBG/` + `build/lib.*/`
- `dgSPARSE/example/ge-spmm/` + `build/lib.*/`
- `rabbit_module/` + `rabbit_module/src/` + `build/lib.*/`
- `test/` + `test/lib/`

## 超算环境适配细节

`cmd2.sh` 处理了以下非标准 ROCm 布局问题：

- **hipcc 路径**: 某些集群将 hipcc 安装在 `$ROCM_PATH/hip/bin/` 而非 `$ROCM_PATH/bin/`。策略 A 尝试在 ROCm 目录内创建符号链接；策略 B 在 `build/rocm-wrap/` 下创建完整 ROCm 树符号链接包装
- **HIP 运行时库**: 添加 `$ROCM_PATH/hip/lib` 到 `LIBRARY_PATH`
- **HIP/HSA 头文件**: 添加 `$ROCM_PATH/hip/include` 和 `$ROCM_PATH/hsa/include` 到 `CPATH`
- **GPU 架构**: 通过 `AMDGPU_TARGET` 环境变量控制，默认 `gfx906`，同时设置 `PYTORCH_ROCM_ARCH` 和 `TORCH_CUDA_ARCH_LIST` 防止 PyTorch 自动检测不支持的架构
- **rabbit 编译**: 依赖 `libnuma` 和 `libtcmalloc_minimal`，若 tcmalloc 不可用则自动回退

## 本地开发注意事项

- 本地修改代码后，使用 `tar czf` 打包上传（不要包含 `.so` 编译产物和 `build/` 目录）
- 超算上的 `build.log` 是判断编译/测试是否成功的关键反馈来源
- 每个被 hipify 的文件都有 `.prehip` 备份 — 切勿编辑 `.prehip` 文件，它们仅供参考
- 如果要新增 HIP kernel 文件，需要在对应模块的 `setup.py` 中添加源文件路径
- Python 测试文件在 `test/` 目录，可以直接用 `python3 test_*.py` 运行（前提是 `PYTHONPATH` 已正确设置）
- DGL 和 PyG 是可选依赖 — 测试中的 DGL/PyG 对比在它们不可用时会自动跳过
- 项目中有大量 `backup/` 目录存放了旧版 CUDA/HIP 代码变体，修改时注意不要混淆
