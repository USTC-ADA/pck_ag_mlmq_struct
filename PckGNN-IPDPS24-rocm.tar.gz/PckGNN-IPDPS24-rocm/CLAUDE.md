# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

See also `AGENTS.md` for additional context and the full supercomputer deployment workflow.

## Project Overview

This is the **ROCm/HIP adaptation** of PckGNN ("Understanding and Bridging the Gaps in Current GNN Performance Optimizations", PPoPP'21), a GNN performance benchmarking framework that compares multiple GNN kernel optimization strategies (SpMM/SDDMM sparse operators) across five frameworks: GNNAdvisor, KG-GNN, UBG, dgSPARSE/GE-SpMM, and cuSPARSE.

- **Original CUDA project**: `/home/hdz/testpath/rocm/PckGNN/PckGNN-IPDPS24-2080`
- **Target GPU**: gfx906 (AMD MI50/MI60). Also supports gfx908 (MI100) and gfx90a (MI200).
- **Supercomputer**: `sunjw@60.245.128.10:65010`, path `/public/home/sunjw/scd/PckGNN-IPDPS24-rocm`

## Build, Test, and Common Commands

All commands are driven by `cmd2.sh` (the "v1" setup.py-based approach). The old Makefile-based approach (`cmd.sh`, top-level `Makefile`) is deprecated and may not work.

```bash
# Build all 5 extensions (order: rabbit → gnna → kggnn → ubg → gespmm)
bash cmd2.sh build

# Build a single extension
bash cmd2.sh build-rabbit       # CPU-only, fastest, no ROCm needed
bash cmd2.sh build-gnna         # GNNAdvisor (HIP)
bash cmd2.sh build-kggnn        # KGGNN (HIP)
bash cmd2.sh build-ubg          # UBGGNN (HIP)
bash cmd2.sh build-gespmm       # GESpMM (HIP)

# Verify all imports after build
bash cmd2.sh verify-imports

# Run tests (require prior build of the relevant extension)
bash cmd2.sh test-gcn    <dataset.pt> [outcsv]
bash cmd2.sh test-gat    <dataset.pt> [outcsv]
bash cmd2.sh test-gin    <dataset.pt> [outcsv]
bash cmd2.sh test-spmm   <dataset.pt> <in_dim> [outcsv]
bash cmd2.sh test-sddmm  <dataset.pt> <in_dim> [outcsv]
bash cmd2.sh test-mm

# Utility
bash cmd2.sh clean               # Remove all build artifacts and reset build.log
bash cmd2.sh info                # Show environment info (paths, versions, .so files)
```

You can also run tests directly without `cmd2.sh` (requires PYTHONPATH to be set):
```bash
cd test
python3 test_gcn.py    <dataset.pt> [outcsv]
python3 test_gat.py    <dataset.pt> [outcsv]
python3 test_gin.py    <dataset.pt> [outcsv]
python3 test_spmm.py   <dataset.pt> <in_dim> [outcsv]
python3 test_sddmm.py  <dataset.pt> <in_dim> [outcsv]
python3 test_mm.py
```

**Batch testing** across multiple datasets using `matrix_list` or `matrix_sample`:
```bash
bash run_gcn.sh    matrix_sample <output_dir>
bash run_gat.sh    matrix_sample <output_dir>
bash run_gin.sh    matrix_sample <output_dir>
bash run_spmm.sh   matrix_sample <output_dir>
bash run_sddmm.sh  matrix_sample <output_dir>
```

`tips.sh` provides a 6-phase import diagnostic that sets PYTHONPATH locally (no export) and checks every import needed by each test file.

## Target Environment

```
module load compiler/devtoolset/7.3.1
module load compiler/rocm/4.0.1
module load mpi/hpcx/2.11.0/gcc-7.3.1
module load apps/PyTorch/1.10.1a0/pytorch_1.10.1-rocm_4.0.1
```

- **Compiler/runtime**: ROCm 4.0.1, devtoolset 7.3.1 (GCC 7.3.1)
- **PyTorch**: 1.10.1+rocm4.0.1
- **Python**: 3.6
- **GPU target**: `gfx906` (default). Override with `export AMDGPU_TARGET=gfx908` or `gfx90a`.
- **Cluster quirk**: hipcc is at `$ROCM_PATH/hip/bin/hipcc` (non-standard), not `$ROCM_PATH/bin/hipcc`. `cmd2.sh` auto-handles this.

## Project Structure

```
PckGNN-IPDPS24-rocm/
├── cmd2.sh                      # ★ Main control script (build + test)
├── tips.sh                      # 6-phase import diagnostic (independent of cmd2.sh)
├── import_check.py              # Python import checker (used by verify-imports)
├── READMEv1.md                  # Current README (recommended reference)
├── build.log                    # Latest build/test output log
│
├── GNNAdvisor/                  # Parameter-adaptive GNN kernels
│   ├── gnn_conv.py              #   PyTorch autograd GNN layers (GCN/GIN)
│   ├── param.py                 #   Runtime parameter auto-tuning
│   ├── dataset.py               #   Dataset loading
│   └── GNNConv/
│       ├── setup.py             #   CUDAExtension build config
│       ├── GNNAdvisor.cpp       #   Host-side C++ (PyTorch bindings)
│       └── GNNAdvisor_kernel.cu #   Device-side HIP kernel
│
├── KG_GNN/                      # Knowledge-guided GNN
│   ├── KG_GNN.py                #   Python wrapper
│   └── core/
│       ├── setup.py             #   CUDAExtension build config
│       ├── include/             #   C++ headers
│       └── src/                 #   HIP kernel sources (.cu + .cpp)
│
├── UBG/                         # UBG framework (PPoPP'21 paper)
│   ├── setup.py                 #   CUDAExtension build config
│   ├── util.py                  #   Python utilities
│   ├── include/                 #   Headers
│   └── src/                     #   HIP kernel sources
│
├── dgSPARSE/                    # General sparse matrix library
│   ├── src/ge-spmm/             #   GE-SpMM kernel
│   ├── src/sddmm/               #   SDDMM kernel
│   └── example/ge-spmm/
│       └── setup.py             #   GESpMM CUDAExtension build config
│
├── rabbit_module/               # Rabbit Order graph reordering (CPU-only)
│   ├── rabbit_order.py          #   Python wrapper
│   └── src/
│       └── setup.py             #   CppExtension build config (no ROCm needed)
│
├── cuSPARSE/                    # cuSPARSE HIP interface test (standalone binary)
│
├── test/                        # Python test suite
│   ├── test_gcn.py              #   GCN model test
│   ├── test_gat.py              #   GAT model test
│   ├── test_gin.py              #   GIN model test
│   ├── test_spmm.py             #   SpMM kernel benchmark
│   ├── test_sddmm.py            #   SDDMM kernel benchmark
│   ├── test_mm.py               #   MM kernel benchmark
│   ├── load_dataset.py          #   Dataset loading utilities
│   ├── utils.py                 #   Graph format conversion (CSR/COO)
│   ├── perf_time.py             #   Performance timing decorator
│   └── lib/                     #   Framework-specific test harnesses
│       ├── gnna_test.py         #     GNNAdvisor harness
│       ├── kg_test.py           #     KG-GNN harness
│       ├── ubg_test.py          #     UBG harness
│       ├── ge_test.py           #     GE-SpMM harness
│       ├── cusparse_test.py     #     cuSPARSE harness
│       ├── dgl_test.py          #     DGL baseline harness (optional)
│       └── pyg_test.py          #     PyG baseline harness (optional)
│
├── dataset/                     # Dataset preprocessing scripts
├── run_*.sh                     # Batch test scripts (gcn/gat/gin/spmm/sddmm)
├── matrix_list / matrix_sample  # Dataset lists for batch testing
├── pic/                         # Paper figure generation
└── results/                     # Test result output
```

## Architecture: 5 C++/HIP Extension Modules

The project compiles 5 independent PyTorch C++ extensions via `setup.py build_ext --inplace`. They share no code — each can be built and tested individually.

| Module | `setup.py` location | Type | Sources | Function |
|--------|---------------------|------|---------|----------|
| `rabbit` | `rabbit_module/src/` | CPU (CppExtension) | `reorder.cpp` | Graph reordering for cache locality |
| `GNNAdvisor` | `GNNAdvisor/GNNConv/` | HIP (CUDAExtension) | `GNNAdvisor.cpp`, `GNNAdvisor_kernel.cu` | Parameter-adaptive GNN + workload partitioning |
| `KGGNN` | `KG_GNN/core/` | HIP (CUDAExtension) | Multiple `.cu` + `.cpp` in `src/` | SpMM/SDDMM/MM pipeline + bin-packing |
| `UBGGNN` | `UBG/` | HIP (CUDAExtension) | Multiple `.cu` + `.cpp` in `src/` | UBG GNN compile/runtime |
| `GESpMM` | `dgSPARSE/example/ge-spmm/` | HIP (CUDAExtension) | Sources from `dgSPARSE/src/` | General-purpose SpMM |

Each `.so` is built in-place next to its `setup.py`. `cmd2.sh` builds in this order: rabbit → gnna → kggnn → ubg → gespmm.

## PYTHONPATH

`cmd2.sh` sets `PYTHONPATH` to include all module source directories and their `build/lib.*/` fallback directories. This is the single most important configuration — it resolves all imports like `import GNNAdvisor`, `import KGGNN`, `from lib.kg_test import *` without requiring `pip install`.

The full PYTHONPATH includes:
- Project root, `GNNAdvisor/`, `GNNAdvisor/GNNConv/`, `GNNAdvisor/GNNConv/build/lib.*/`
- `KG_GNN/`, `KG_GNN/core/`, `KG_GNN/core/build/lib.*/`
- `UBG/`, `UBG/build/lib.*/`
- `dgSPARSE/example/ge-spmm/`, `dgSPARSE/example/ge-spmm/build/lib.*/`
- `rabbit_module/`, `rabbit_module/src/`, `rabbit_module/src/build/lib.*/`
- `test/`, `test/lib/`

## HIP Adaptation: What to Know When Modifying Code

The project was migrated from CUDA via `hipify-perl --inplace`. **Adaptation stats**: 25 `.cu` files, 3 `.cuh` files, 17 `.h` files, 7 `.cpp/.cc` files were auto-hipified.

Each hipified file has a `.prehip` backup — **never edit `.prehip` files**, they are reference-only. There are also `backup/` directories throughout the project containing old CUDA/HIP code variants — be careful not to confuse them with active source files.

8 categories of manual fixes were applied that hipify-perl could not handle:

1. **Warp shuffle**: `__shfl_down_sync(FULLMASK, val, offset)` → `__shfl_down(val, offset)` (HIP drops the mask parameter; `__syncwarp()` is natively supported in ROCm 4.0.1)
2. **cuBLAS → hipBLAS**: `cublasHandle_t` → `hipblasHandle_t`, `cublasSgemm` → `hipblasSgemm`, `CUBLAS_OP_T` → `HIPBLAS_OP_T`
3. **cuRAND → hipRAND**: `curandState` → `hiprandState`, `curand_init` → `hiprand_init`
4. **cuSPARSE constants**: `CUSPARSE_INDEX_32I` → `HIPSPARSE_INDEX_32I`, `CUSPARSE_STATUS_SUCCESS` → `HIPSPARSE_STATUS_SUCCESS`
5. **`__ldg` texture loads**: Replaced with plain pointer dereference `*(ptr + offset)`. May affect performance on some access patterns — consider `__builtin_nontemporal_load` for optimization.
6. **Dynamic shared memory**: `cudaFuncSetAttribute` → `hipFuncSetAttribute`, `cudaFuncAttributeMaxDynamicSharedMemorySize` → `hipFuncAttributeMaxDynamicSharedMemorySize`
7. **Custom wrappers**: `cudaMalloc2` → `hipMalloc2`, `checkCudaErrors` → `checkHipErrors`
8. **Profiler headers**: Removed `#include <cuda_profiler_api.h>` (ROCm uses roctx instead)

If adding new HIP kernel files, add their source paths to the corresponding module's `setup.py`.

## Key Environment Variables

- `AMDGPU_TARGET` — GPU architecture (default: `gfx906`). Also controls which device libs hipcc links.
- `PYTORCH_ROCM_ARCH` — Restricts PyTorch `cpp_extension` to only compile for the target arch. Set by `cmd2.sh` to prevent hipcc from failing on unsupported architectures (gfx803/gfx900).
- `TORCH_CUDA_ARCH_LIST` — Same purpose as above, also set by `cmd2.sh`.
- `ROCM_PATH` — Auto-cleaned by `cmd2.sh` to remove DTK path pollution (PyTorch module may append a second ROCm path).
- `LIBRARY_PATH` — Extended with `$ROCM_PATH/hip/lib` for non-standard HIP runtime library location.
- `CPATH` — Extended with `$ROCM_PATH/hip/include` and `$ROCM_PATH/hsa/include` for non-standard header locations.
- `LC_ALL=C` / `LANG=C` — Set by `cmd2.sh` to suppress locale warnings on HPC systems.

## Non-Standard ROCm Layout Handling

`cmd2.sh` (`_fix_rocm_hipcc` function) handles clusters where hipcc is in `$ROCM_PATH/hip/bin/` instead of `$ROCM_PATH/bin/`:

- **Strategy A**: Create `$ROCM_PATH/bin/hipcc → ../hip/bin/hipcc` symlink (requires write permission on ROCm install tree)
- **Strategy B** (fallback): Create a full-tree symlink wrapper at `build/rocm-wrap/` with `bin/` populated from `hip/bin/` and all other top-level directories symlinked from the real ROCm root. `ROCM_PATH` is then pointed to this wrapper.

Additional layout fixes applied unconditionally:
- `LIBRARY_PATH` += `$ROCM_PATH/hip/lib` (HIP runtime libraries may not be in `$ROCM_PATH/lib`)
- `CPATH` += `$ROCM_PATH/hip/include:$ROCM_PATH/hsa/include` (HIP/HSA headers for g++ compiling .cpp files)

## Test Structure

Test scripts in `test/` each benchmark one model/kernel type across multiple frameworks, comparing results and measuring performance:

- `test_gcn.py`, `test_gat.py`, `test_gin.py` — GNN model tests (compare DGL, PyG, GNNAdvisor, UBG, KG-GNN)
- `test_spmm.py`, `test_sddmm.py` — Sparse kernel benchmarks (SpMM/SDDMM)
- `test_mm.py` — Dense matrix multiply benchmark

`test/lib/` contains framework-specific harnesses that wrap each extension's API into a uniform interface (`model_init`, `model_run`, `data_init`):
- `gnna_test.py`, `ubg_test.py`, `kg_test.py`, `ge_test.py`, `cusparse_test.py` — Core harnesses
- `dgl_test.py`, `pyg_test.py` — Baseline harnesses. DGL and PyG are **optional dependencies** — tests automatically skip their comparisons when they're unavailable.

## Third-Party Python Packages (project-local, no global pollution)

The project uses `pip install --target pkgs/ --no-deps` to install third-party packages
**exclusively within the project**.  `cmd2.sh` and `tips.sh` both prepend `${PROJ_DIR}/pkgs`
to `PYTHONPATH`, so packages placed there are imported without touching the global
site-packages.

### Compatible versions (Python 3.6.8 / ROCm 4.0.1 / PyTorch 1.10.1)

| Package | Version | Type | Required? | Notes |
|---------|---------|------|-----------|-------|
| `tqdm` | 4.64.1 | pure Python | optional | Last version supporting Python 3.6 |
| `torch_geometric` | 2.0.3 | pure Python (sdist) | optional | PyG baseline; **replaces DGL** for GCN/GAT/GIN comparison |
| `datasketch` | 1.5.9 (patched) | pure Python | optional | scipy made optional (see below) |
| `ogb` | 1.3.6 | pure Python | optional | Dataset preprocessing only (`dataset/OGB.py`) |
| `dgl` | — | — | **no longer needed** | PyG provides identical baseline functionality |

### Why DGL was removed

DGL and PyG serve the same role in this project: GCN/GAT/GIN baseline models for
benchmark comparison.  Both are marked optional in all test files.  DGL has
**no ROCm 4.0.1 compatible wheel** (AMD's `amd-dgl` requires ROCm ≥ 6.4), and the
old CPU-only DGL wheel is meaningless for GPU benchmarks.  PyG 2.0.3 fully replaces it.

### datasketch patching

`datasketch` 1.5.9 is the last version whose wheel metadata allows Python 3.6,
but it lists `scipy >= 1.0.0` as a hard dependency.  `scipy` 1.5.4 (last version
supporting Python 3.6) has been **removed from PyPI and all mirrors**.

The wheel in `wheels/datasketch-1.5.9-py3-none-any.whl` has been patched to make
scipy optional:

- `lsh.py`: `from scipy.integrate import quad` deferred into `_false_positive_probability()`
- `weighted_minhash.py`: `import scipy` deferred into `minhash_many()` method body
- `METADATA`: `Requires-Dist: scipy` removed

**What works without scipy:** `MinHash`, `HyperLogLog`, `LSHForest`, `HNSW`, `MinHashLSH` (with explicit `params=(b, r)`)
**What needs scipy:** `WeightedMinHash`, `MinHashLSH` auto-parameter optimization

### Supercomputer install commands

```bash
cd ~/scd/PckGNN-IPDPS24-rocm
pip install --target pkgs/ --no-deps wheels/tqdm-4.64.1-py2.py3-none-any.whl
pip install --target pkgs/ --no-deps wheels/datasketch-1.5.9-py3-none-any.whl
pip install --target pkgs/ --no-deps wheels/ogb-1.3.6-py3-none-any.whl
pip install --target pkgs/ --no-deps wheels/torch_geometric-2.0.3.tar.gz
```

Then verify with `bash cmd2.sh verify-imports`.  Expected:
- `import tqdm` → success, `import datasketch` → success, `import torch_geometric` → success
- `import ogb` → success, `import dgl` → fail (optional, expected)

### Adding or updating packages

1. Download the wheel locally: `pip download <pkg>==<ver> --no-deps -d wheels/`
2. Check Python 3.6 compatibility before downloading
3. Do NOT install locally — wheels are only for supercomputer deployment
4. Update the version table above

## Local Development Notes

- When packaging for the supercomputer, use `tar czf` and **exclude** `.so` files, `build/` directories, `__pycache__/`, and `.egg-info/` to keep the archive small.
- `build.log` is the primary feedback mechanism — after running build/test on the supercomputer, `scp` it back to the local machine to diagnose issues.
- **Never edit `.prehip` files** — they are the original CUDA backups from hipify.
- There are many `backup/` subdirectories with old CUDA/HIP code variants — do not confuse them with active source code.
- The `rabbit` extension depends on `libnuma` and (optionally) `libtcmalloc_minimal`. `cmd2.sh` auto-detects tcmalloc unavailability, patches the `setup.py` to remove the dependency, and retries.
- Some modules have `build.sh` scripts in their directories — these are older build methods; prefer `cmd2.sh build-*` instead.

## Known Issues

1. **ROCm 4.0.1 non-standard layout**: hipcc is at `$ROCM_PATH/hip/bin/hipcc`, not `$ROCM_PATH/bin/hipcc`. PyTorch's `cpp_extension` hardcodes the latter. `cmd2.sh` auto-fixes this.
2. **`__ldg` replacement**: Plain pointer dereference may reduce performance for certain access patterns. If profiling shows this as a bottleneck, consider `__builtin_nontemporal_load`.
3. **tcmalloc on supercomputer**: `libtcmalloc_minimal` may not be available on the compute node. `cmd2.sh` handles the fallback automatically by patching `setup.py`.
4. **v0 (Makefile) → v1 (setup.py) migration**: The old `cmd.sh` and top-level `Makefile` are preserved but no longer maintained. All development should use `cmd2.sh`.
5. **PyTorch architecture auto-detection**: Without `PYTORCH_ROCM_ARCH` set, PyTorch auto-detects all ROCm-supported architectures including unsupported ones (gfx803/gfx900), causing hipcc failures. `cmd2.sh` sets this automatically.
6. **Chinese characters in `import_check.py`**: The diagnostic output uses Chinese text. If the locale is `C` (ASCII-only), Python 3.6 raises `UnicodeEncodeError`. Fixed in two places: `cmd2.sh` now prefers a UTF-8 locale (`en_US.UTF-8` → `C.UTF-8` → `C` fallback), and `import_check.py` wraps `sys.stdout` with a UTF-8 `TextIOWrapper` as a safety net.

## References

- [ROCm HIP Documentation](https://rocm.docs.amd.com/projects/HIP/en/latest/)
- [hipify-perl User Guide](https://rocm.docs.amd.com/projects/HIPIFY/en/latest/)
- Reference ROCm adaptation project: `/home/hdz/testpath/rocm/agsptrsv_rocm`
- Original CUDA project: `/home/hdz/testpath/rocm/PckGNN/PckGNN-IPDPS24-2080`
- Supercomputer environment details: `env.txt`, `pyenv.txt`
