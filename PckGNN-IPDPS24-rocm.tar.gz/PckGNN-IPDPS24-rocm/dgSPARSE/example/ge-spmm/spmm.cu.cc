// file: spmm.cu.cc
//
// Using cusparse API to test SpMM performance.
//  author: guyue huang
//  date  : 2021/10/13
// compile: nvcc version >=11.0


#include <hip/hip_runtime_api.h>   // hipMalloc, hipMemcpy, etc.
#include <hipsparse.h>            // cusparseSpMM (>= v11.0) or hipsparseScsrmm
#include <stdio.h>
#include <stdlib.h>             
#include <cstdlib>              // std::rand(), RAND_MAX
#include <vector>     
#include "../../src/ge-spmm/gespmm.h"            // gespmmCsrSpMM()
#include "spmm_util.hpp"        // read_mtx


#include <torch/extension.h>
#include <string.h>

#define DATACHECKNUM 5

#define CUDA_CHECK(func)                                                       \
{                                                                              \
    hipError_t status = (func);                                               \
    if (status != hipSuccess) {                                               \
        printf("CUDA API failed at line %d with error: %s (%d)\n",             \
               __LINE__, hipGetErrorString(status), status);                  \
        return EXIT_FAILURE;                                                   \
    }                                                                          \
}


#define CUSPARSE_CHECK(func)                                                   \
{                                                                              \
    hipsparseStatus_t status = (func);                                          \
    if (status != HIPSPARSE_STATUS_SUCCESS) {                                   \
        printf("CUSPARSE API failed at line %d with error: %d\n",              \
               __LINE__, (int)status);                                          \
        exit(EXIT_FAILURE);                                                    \
    }                                                                          \
}


//int main(int argc, const char** argv) {

float ge_spmm(
    int M,      // num_nodes 
    int N,      // gcc_hidden / out_dim
    int nnz,
    torch::Tensor indptr_t,
    torch::Tensor indices_t,
    torch::Tensor degrees_t,
    torch::Tensor B_ht,     // feats 
    torch::Tensor C_ht      // output (?)
)
{
    /// check command-line argument
    int *indptr  = indptr_t.data_ptr<int>();
    int *indices = indices_t.data_ptr<int>();
    int *degrees = indices_t.data_ptr<int>();
    // if (argc < 2) {
    //     printf("Require command-line argument: name of the sparse matrix file in .mtx format.\n");
    //     return EXIT_FAILURE;
    // }
    
    //
    // Load sparse matrix
    //

    //  int M;   // number of A-rows
    int K=M;     // number of A-columns
    //  int nnz; // number of non-zeros in A
    std::vector<int> csr_indptr_buffer;     // buffer for indptr array in CSR format
    std::vector<int> csr_indices_buffer;    // buffer for indices (column-ids) array in CSR format

    int idx;

    for(idx = 0; idx < M+1; idx++) csr_indptr_buffer.push_back(indptr[idx]);
    for(idx = 0; idx < nnz; idx++) csr_indices_buffer.push_back(indices[idx]); 
    //accept data

    // load sparse matrix from mtx file
    // read_mtx_file(argv[1], 
    //             M, 
    //             K, 
    //             nnz, 
    //             csr_indptr_buffer, 
    //             csr_indices_buffer);
    // printf("Finish reading matrix %d rows, %d columns, %d nnz. \nIgnore original values and use randomly generated values.\n", M, K, nnz);
    
    // Create GPU arrays
    // int N = 128;   // number of B-columns
    // if (argc > 2) {
    //     N = atoi(argv[2]);
    // }
    // assert(N > 0 && "second command-line argument is number of B columns, should be >0.\n");

    float *B_h = B_ht.data_ptr<float>(), *C_h = C_ht.data_ptr<float>();
    float *csr_values_h = NULL, *C_ref = NULL;
    float *B_d = NULL, *C_d = NULL, *csr_values_d = NULL;
    int   *csr_indptr_d = NULL, *csr_indices_d = NULL;

    

    // B_h   = (float*) malloc(sizeof(float) * K * N);
    // C_h   = (float*) malloc(sizeof(float) * M * N);
    C_ref = (float*) malloc(sizeof(float) * M * N);
    csr_values_h = (float*) malloc(sizeof(float) * nnz);
    if (/* !B_h || !C_h || */ !C_ref || !csr_values_h) {
        printf("Host allocation failed.\n");
        return EXIT_FAILURE;
    } 

    fill_ones(csr_values_h, nnz);
    // weights all one
    //fill_random(B_h, K * N);

    CUDA_CHECK( hipMalloc((void**)&B_d, sizeof(float) * K * N) );
    CUDA_CHECK( hipMalloc((void**)&C_d, sizeof(float) * M * N) );
    CUDA_CHECK( hipMalloc((void**)&csr_values_d, sizeof(float) * nnz) );
    CUDA_CHECK( hipMalloc((void**)&csr_indptr_d, sizeof(int) * (M + 1)) );
    CUDA_CHECK( hipMalloc((void**)&csr_indices_d, sizeof(int) * nnz) );

    CUDA_CHECK( hipMemcpy(B_d, B_h, sizeof(float) * K * N, hipMemcpyHostToDevice));
    CUDA_CHECK( hipMemset(C_d, 0x0, sizeof(float) * M * N));
    CUDA_CHECK( hipMemcpy(csr_values_d, csr_values_h, sizeof(float)*nnz, hipMemcpyHostToDevice));
    CUDA_CHECK( hipMemcpy(csr_indptr_d, csr_indptr_buffer.data(), sizeof(int) * (M+1), hipMemcpyHostToDevice));
    CUDA_CHECK( hipMemcpy(csr_indices_d, csr_indices_buffer.data(), sizeof(int)*nnz, hipMemcpyHostToDevice));

    

    //
    // Run Cusparse-SpMM and check result
    //

    hipsparseHandle_t     handle;
    hipsparseMatDescr_t   descr;
    float alpha = 1.0f, beta = 0.0f;

    CUSPARSE_CHECK(hipsparseCreate(&handle));
    CUSPARSE_CHECK(hipsparseCreateMatDescr(&descr));
    hipsparseSetMatType(descr, HIPSPARSE_MATRIX_TYPE_GENERAL);
    hipsparseSetMatIndexBase(descr, HIPSPARSE_INDEX_BASE_ZERO);

    // Run SpMM: C = alpha * A * B + beta * C  (A=MxK CSR, B=KxN row-major, C=MxN row-major)
    CUSPARSE_CHECK(hipsparseScsrmm(handle,
                                   HIPSPARSE_OPERATION_NON_TRANSPOSE,
                                   M, N, K, nnz,
                                   &alpha, descr,
                                   csr_values_d, csr_indptr_d, csr_indices_d,
                                   B_d, N,
                                   &beta,
                                   C_d, N));

    CUDA_CHECK( hipMemcpy(C_h, C_d, sizeof(float) * M * N, hipMemcpyDeviceToHost) );
    
    // printf("Check 0\n");
    // printf("M=%d, N=%d, K=%d, nnz = %d\n", M, N, K, nnz);

    spmm_reference_host<int, float>(M, N, K, csr_indptr_buffer.data(), csr_indices_buffer.data(), 
    csr_values_h, B_h, C_ref);

    //return 0;

    bool correct = check_result<float>(M, N, C_h, C_ref);
    
    //return 0;

    //
    // Benchmark Cusparse-SpMM performance
    //

    float best_time = 100000.0;

    if (1) {
        
        GpuTimer gpu_timer;
        int warmup_iter = 10;
        int repeat_iter = 100;
        for (int iter = 0; iter < warmup_iter + repeat_iter; iter++) {
            if (iter == warmup_iter) {
                gpu_timer.start();
            }

            hipsparseScsrmm(handle,
                           HIPSPARSE_OPERATION_NON_TRANSPOSE,
                           M, N, K, nnz,
                           &alpha, descr,
                           csr_values_d, csr_indptr_d, csr_indices_d,
                           B_d, N,
                           &beta,
                           C_d, N);

            hipDeviceSynchronize();

        }
        gpu_timer.stop();

        float kernel_dur_msecs = gpu_timer.elapsed_msecs() / repeat_iter;

        float MFlop_count = (float)nnz / 1e6 * N * 2;

        float gflops = MFlop_count / kernel_dur_msecs;
        
        printf("[Cusparse] Report: spmm A(%d x %d) * B(%d x %d) sparsity %f (nnz=%d) \n Time %f (ms), Throughput %f (gflops).\n", 
            M, K, K, N, 
            (float)nnz / M / K,
            nnz,
            kernel_dur_msecs,
            gflops);

            float best_time = kernel_dur_msecs;
    }

    SpMatCsrDescr_t spmatA {
        M, K, nnz, csr_indptr_d, csr_indices_d, csr_values_d};
    gespmmAlg_t algs[] = {
        GESPMM_ALG_SEQREDUCE_ROWBALANCE,
        GESPMM_ALG_PARREDUCE_ROWBALANCE,
        GESPMM_ALG_SEQREDUCE_NNZBALANCE,
        GESPMM_ALG_PARREDUCE_NNZBALANCE,
        GESPMM_ALG_ROWCACHING_ROWBALANCE,
        GESPMM_ALG_ROWCACHING_NNZBALANCE
    };

    for (auto alg: algs) {
        
        //
        // Run GE-SpMM and check result
        // 

        //printf("alg %d\n", alg);

        CUDA_CHECK(hipMemset(C_d, 0x0, sizeof(float) * M * N));

        gespmmCsrSpMM( spmatA, B_d, N, C_d, true, alg);

        hipDeviceSynchronize();
        CUDA_CHECK( hipMemcpy(C_h, C_d, sizeof(float) * M * N, hipMemcpyDeviceToHost) );
    
        spmm_reference_host<int, float>(M, N, K, csr_indptr_buffer.data(), csr_indices_buffer.data(), csr_values_h, B_h, C_ref);

        bool correct = check_result<float>(M, N, C_h, C_ref);

        if (correct) {
            
            // benchmark GE-SpMM performance
            
            GpuTimer gpu_timer;
            int warmup_iter = 10;
            int repeat_iter = 100;
            for (int iter = 0; iter < warmup_iter + repeat_iter; iter++) {
                if (iter == warmup_iter) {
                    gpu_timer.start();
                }

                gespmmCsrSpMM( spmatA, B_d, N, C_d, true, alg);

                hipDeviceSynchronize();

            }
            gpu_timer.stop();

            float kernel_dur_msecs = gpu_timer.elapsed_msecs() / repeat_iter;

            if(kernel_dur_msecs < best_time) best_time = kernel_dur_msecs;

            float MFlop_count = (float)nnz / 1e6 * N * 2;

            float gflops = MFlop_count / kernel_dur_msecs;
            
            printf("[GE-SpMM][Alg: %d] Report: spmm A(%d x %d) * B(%d x %d) sparsity %f (nnz=%d) \n Time %f (ms), Throughput %f (gflops).\n", 
                alg,
                M, K, K, N, 
                (float)nnz / M / K,
                nnz,
                kernel_dur_msecs,
                gflops);
        }
    }
       
    /// free memory

    // if (B_h)            free(B_h);
    // if (C_h)            free(C_h);
    if (C_ref)          free(C_ref);
    if (csr_values_h)   free(csr_values_h);
    if (B_d)            CUDA_CHECK( hipFree(B_d) );
    if (C_d)            CUDA_CHECK( hipFree(C_d) );
    if (csr_values_d)   CUDA_CHECK( hipFree(csr_values_d) );
    if (csr_indptr_d)   CUDA_CHECK( hipFree(csr_indptr_d) );
    if (csr_indices_d)  CUDA_CHECK( hipFree(csr_indices_d) );
    CUSPARSE_CHECK(hipsparseDestroyMatDescr(descr));
    CUSPARSE_CHECK(hipsparseDestroy(handle));
    
    ///return results

    hipMemcpy(C_h, C_d, sizeof(float) * M * N, hipMemcpyDeviceToHost);

    return best_time;
}

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m)
{
  m.def("ge_spmm", &ge_spmm, "ge_spmm");
}
