import os
from setuptools import setup
from torch.utils.cpp_extension import BuildExtension, CUDAExtension

if not os.environ.get('PYTORCH_ROCM_ARCH'):
    os.environ['PYTORCH_ROCM_ARCH'] = 'gfx906'

setup(
    name='GESpMM',
    ext_modules=[
        CUDAExtension(
        name='GESpMM',
        sources=[
                    './spmm.cu.cc',
                    '../../src/ge-spmm/csrspmm_non_transpose.cu',
                    '../../src/ge-spmm/csrspmm_parreduce.cu',
                    '../../src/ge-spmm/csrspmm_rowcaching.cu',
                    '../../src/ge-spmm/csrspmm_seqreduce.cu',
                    '../../src/ge-spmm/gespmm.cc',
                    '../../src/ge-spmm/gespmm_csrcoo_v2.cu',
                    #'../../src/ge-spmm/gespmm.h',
                    '../../src/ge-spmm/gespmm_v2.cu',
                    #'../../src/ge-spmm/gespmm_v2.h',
                    #'../../src/ge-spmm/libgespmm.a',
                ]
        )
    ],
    cmdclass={
        'build_ext': BuildExtension
    })