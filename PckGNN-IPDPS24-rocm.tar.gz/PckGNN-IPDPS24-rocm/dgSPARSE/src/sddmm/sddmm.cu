#include "hip/hip_runtime.h"
#include "../util/cuda_util.cuh"
#include "coosddmm_ebalance.cuh"
#include "csrsddmm_ebalance.cuh"


void sddmm_cuda_coo(int k, int nnz, int *rowind, int *colind, float *D1,
                    float *D2, float *out);

void sddmm_cuda_csr(int m, int k, int nnz, int *rowptr, int *colind, float *D1,
                    float *D2, float *out);

void sddmm_cuda_coo(int k, int nnz, int *rowind, int *colind, float *D1,
                    float *D2, float *out) {
  if ((k % 4) == 0) {
    hipLaunchKernelGGL((sddmm_coo_ebalance_vec4), dim3(nnz / 16 + (nnz & 15), 1, 1), dim3(8, 4, 1), 0, 0, k, nnz, rowind, colind, D1, D2,
                                               out);
  } else if ((k % 2) == 0) {
    hipLaunchKernelGGL((sddmm_coo_ebalance_vec2), dim3(nnz / 16 + (nnz & 15), 1, 1), dim3(16, 4, 1), 0, 0, k, nnz, rowind, colind, D1, D2,
                                                out);
  } else {
    hipLaunchKernelGGL((sddmm_coo_ebalance_scalar), dim3(nnz / 16 + (nnz & 15), 1, 1), dim3(32, 4, 1), 0, 0, k, nnz, rowind, colind, D1,
                                                  D2, out);
  }
}

void sddmm_cuda_csr(int m, int k, int nnz, int *rowptr, int *colind, float *D1,
                    float *D2, float *out) {
  if ((k % 4) == 0) {
    hipLaunchKernelGGL((sddmm_csr_ebalance_vec4), dim3(nnz / 16 + (nnz & 15), 1, 1), dim3(8, 4, 1), 0, 0, m, k, nnz, rowptr, colind, D1,
                                               D2, out);
  }
  if ((k % 2) == 0) {
    hipLaunchKernelGGL((sddmm_csr_ebalance_vec2), dim3(nnz / 16 + (nnz & 15), 1, 1), dim3(16, 4, 1), 0, 0, m, k, nnz, rowptr, colind, D1,
                                                D2, out);
  } else {
    hipLaunchKernelGGL((sddmm_csr_ebalance_scalar), dim3(nnz / 16 + (nnz & 15), 1, 1), dim3(32, 4, 1), 0, 0, m, k, nnz, rowptr, colind, D1,
                                                  D2, out);
  }
}