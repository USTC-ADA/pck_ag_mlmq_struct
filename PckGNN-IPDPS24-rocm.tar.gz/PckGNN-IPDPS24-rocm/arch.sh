#!/bin/bash
# ============================================================
# Environment info collection for PckGNN ROCm build debugging
# Run on the HPC server and feed output back for diagnosis.
# Usage: bash arch.sh [> arch.log]
# ============================================================

echo "============================================"
echo "1. OS & Kernel"
echo "============================================"
uname -a
cat /etc/os-release 2>/dev/null | head -5

echo ""
echo "============================================"
echo "2. Loaded Modules"
echo "============================================"
module list 2>&1

echo ""
echo "============================================"
echo "3. Available ROCm Modules"
echo "============================================"
module avail rocm 2>&1 | head -20

echo ""
echo "============================================"
echo "4. ROCm / HIP Installation"
echo "============================================"
echo "--- which hipcc ---"
which hipcc 2>/dev/null || echo "NOT FOUND"
echo "--- hipcc version ---"
hipcc --version 2>&1 || echo "NOT FOUND"
echo "--- /opt/rocm ---"
ls -d /opt/rocm* 2>/dev/null || echo "NOT FOUND"
echo "--- ROCm version file ---"
cat /opt/rocm/.info/version 2>/dev/null || cat /opt/rocm/share/doc/rocm-version 2>/dev/null || echo "NOT FOUND"

echo ""
echo "============================================"
echo "5. HIP Runtime Headers"
echo "============================================"
echo "--- hip/hip_runtime.h ---"
find /opt/rocm* -name "hip_runtime.h" -path "*/hip/*" 2>/dev/null | head -5
echo "--- __syncwarp check ---"
grep -r "syncwarp" /opt/rocm*/include/hip/ 2>/dev/null | head -5 || echo "NOT FOUND (__syncwarp is NOT available)"

echo ""
echo "============================================"
echo "6. Sparse Libraries"
echo "============================================"
echo "--- libhipsparse ---"
ls -la /opt/rocm*/lib/libhipsparse* 2>/dev/null || echo "NOT FOUND"
echo "--- librocsparse ---"
ls -la /opt/rocm*/lib/librocsparse* 2>/dev/null || echo "NOT FOUND"
echo "--- hipsparse.h ---"
find /opt/rocm* -name "hipsparse.h" 2>/dev/null | head -5
echo "--- hipsparse Sbsrmm check ---"
grep -r "hipsparseSbsrmm\|hipsparseBsrmm" /opt/rocm*/include/hipsparse* 2>/dev/null | head -5 || echo "NOT FOUND"
echo "--- hiprand.h ---"
find /opt/rocm* -name "hiprand.h" 2>/dev/null | head -5

echo ""
echo "============================================"
echo "7. Other Key Libraries"
echo "============================================"
echo "--- libhipblas ---"
ls -la /opt/rocm*/lib/libhipblas* 2>/dev/null || echo "NOT FOUND"
echo "--- libhip_hcc ---"
ls -la /opt/rocm*/lib/libhip_hcc* 2>/dev/null || echo "NOT FOUND"

echo ""
echo "============================================"
echo "8. C/C++ Compilers"
echo "============================================"
echo "--- gcc ---"
gcc --version 2>&1 | head -1
which gcc 2>/dev/null
echo "--- g++ ---"
g++ --version 2>&1 | head -1
echo "--- clang ---"
clang++ --version 2>&1 | head -1

echo ""
echo "============================================"
echo "9. PyTorch ROCm (if any)"
echo "============================================"
python3 -c "import torch; print('PyTorch:', torch.__version__); print('CUDA available:', torch.cuda.is_available()); print('ROCm:', torch.version.hip if hasattr(torch.version, 'hip') else 'N/A')" 2>&1 || echo "PyTorch NOT FOUND"

echo ""
echo "============================================"
echo "10. GPU Info"
echo "============================================"
rocm-smi 2>/dev/null || rocminfo 2>/dev/null | head -40 || echo "GPU tools NOT AVAILABLE"

echo ""
echo "============================================"
echo "11. Key Environment Variables"
echo "============================================"
echo "ROCM_PATH       = ${ROCM_PATH:-unset}"
echo "HIP_PATH        = ${HIP_PATH:-unset}"
echo "AMDGPU_TARGET   = ${AMDGPU_TARGET:-unset}"
echo "LD_LIBRARY_PATH = ${LD_LIBRARY_PATH:-unset}"
echo "LIBRARY_PATH    = ${LIBRARY_PATH:-unset}"
echo "PATH (rocm)     = $(echo "$PATH" | tr ':' '\n' | grep -i rocm | head -5)"

echo ""
echo "============================================"
echo "12. Locale Settings"
echo "============================================"
locale 2>&1 | head -10
echo "--- locale -a (C/C.UTF-8) ---"
locale -a 2>/dev/null | grep -E '^C|UTF' | head -5

echo ""
echo "============================================"
echo "13. Boost (for rabbit_module)"
echo "============================================"
echo "--- boost version ---"
cat /usr/include/boost/version.hpp 2>/dev/null | grep "BOOST_LIB_VERSION" || echo "NOT FOUND"

echo ""
echo "============================================"
echo "Collection complete."
echo "============================================"
