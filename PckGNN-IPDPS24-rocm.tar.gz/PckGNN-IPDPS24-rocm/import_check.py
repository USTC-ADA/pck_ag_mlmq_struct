#!/usr/bin/env python3
"""
import_check.py — 逐项检查 PckGNN 项目所有 Python 模块导入

用法:
    python3 import_check.py             # 全部检查 (Phase 1-6)
    python3 import_check.py --short     # 简洁输出, 跳过 phase 标题

输出格式:
    import xxx module success
    import xxx module fail: <错误信息>
"""

import sys
import os
import io
import importlib

# Force UTF-8 stdout encoding so Chinese characters don't raise
# UnicodeEncodeError on HPC systems where LC_ALL=C is the default.
if hasattr(sys.stdout, 'buffer'):
    sys.stdout = io.TextIOWrapper(
        sys.stdout.buffer, encoding='utf-8', errors='replace')


# ============================================================
# 颜色定义
# ============================================================
RED = "\033[0;31m"
GREEN = "\033[0;32m"
YELLOW = "\033[1;33m"
BLUE = "\033[0;34m"
NC = "\033[0m"


def _try_import(import_stmt: str, mod_name: str, required: bool = True):
    """尝试执行 import 语句, 返回 (success: bool, error_msg: str)"""
    try:
        exec(import_stmt)
        return True, ""
    except Exception as e:
        return False, str(e)


def check(import_stmt: str, mod_name: str, description: str,
          required: bool = True, short: bool = False):
    """检查单个 import 并打印结果"""
    success, err = _try_import(import_stmt, mod_name)

    if success:
        tag = f"{GREEN}success{NC}"
        print(f"import {description} {tag}")
        return True, False
    else:
        if required:
            tag = f"{RED}fail{NC}"
            if short:
                print(f"import {description} {tag}")
            else:
                print(f"import {description} {tag}: {err}")
            return False, True
        else:
            tag = f"{YELLOW}fail (optional){NC}"
            if short:
                print(f"import {description} {tag}")
            else:
                print(f"import {description} {tag}: {err}")
            return False, False


# ============================================================
# Phase 1: 环境概览
# ============================================================
def phase1_env(short=False):
    if not short:
        print(f"{BLUE}=== Phase 1: 环境概览 ==={NC}")
    proj_dir = os.path.dirname(os.path.abspath(__file__))
    try:
        import torch
        torch_ver = torch.__version__
    except Exception:
        torch_ver = "NOT FOUND"
    python_ver = f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
    if not short:
        print(f"  Project:  {proj_dir}")
        print(f"  Python:   {python_ver}")
        print(f"  torch:    {torch_ver}")
        print()


# ============================================================
# Phase 2: 基础 Python 环境检查
# ============================================================
def phase2_basic(short=False):
    if not short:
        print(f"{BLUE}=== Phase 2: 基础 Python 环境检查 ==={NC}")

    modules = [
        ("import torch",                   "torch (PyTorch)"),
        ("import torch.nn",                "torch.nn"),
        ("import torch.nn.functional",     "torch.nn.functional"),
        ("import numpy",                   "numpy"),
        ("import scipy.sparse",            "scipy.sparse"),
        ("import matplotlib.pyplot",       "matplotlib.pyplot", False),  # optional
        ("import setuptools",              "setuptools"),
        ("import sys",                     "sys (stdlib)"),
        ("import time",                    "time (stdlib)"),
        ("import os",                      "os (stdlib)"),
        ("import csv",                     "csv (stdlib)"),
        ("import pathlib",                 "pathlib (stdlib)"),
        ("import ctypes",                  "ctypes (stdlib)"),
        ("import math",                    "math (stdlib)"),
        ("import re",                      "re (stdlib)"),
        ("import argparse",                "argparse (stdlib)"),
        ("import pickle",                  "pickle (stdlib)"),
        ("import queue",                   "queue (stdlib)"),
        ("import functools",               "functools (stdlib)"),
    ]

    fail_count = 0
    for item in modules:
        stmt = item[0]
        desc = item[1]
        req = item[2] if len(item) > 2 else True
        _, failed = check(stmt, desc, desc, required=req, short=short)
        if failed:
            fail_count += 1

    if not short:
        print()
    return fail_count


# ============================================================
# Phase 3: C 扩展 (.so) 检查
# ============================================================
def phase3_extensions(short=False):
    if not short:
        print(f"{BLUE}=== Phase 3: C 扩展 (.so) 检查 ==={NC}")

    extensions = [
        ("import rabbit",       "rabbit (CPU reorder)"),
        ("import GNNAdvisor",   "GNNAdvisor (HIP)"),
        ("import KGGNN",        "KGGNN (HIP)"),
        ("import UBGGNN",       "UBGGNN (HIP)"),
        ("import GESpMM",       "GESpMM (HIP)"),
    ]

    fail_count = 0
    for stmt, desc in extensions:
        _, failed = check(stmt, desc, desc, required=True, short=short)
        if failed:
            fail_count += 1

    if not short:
        print()
    return fail_count


# ============================================================
# Phase 4: test/ 目录内的 Python 模块
# ============================================================
def phase4_test_modules(short=False):
    if not short:
        print(f"{BLUE}=== Phase 4: test/ 目录内模块检查 ==={NC}")

    modules = [
        ("import load_dataset",  "load_dataset"),
        ("import utils",         "utils"),
        ("import perf_time",     "perf_time"),
        ("import similarity",    "similarity"),
    ]

    fail_count = 0
    for stmt, desc in modules:
        _, failed = check(stmt, desc, desc, required=True, short=short)
        if failed:
            fail_count += 1

    if not short:
        print()
    return fail_count


# ============================================================
# Phase 5: test/lib/ 子模块检查
# ============================================================
def phase5_lib_modules(short=False):
    if not short:
        print(f"{BLUE}=== Phase 5: test/lib/ 子模块检查 ==={NC}")

    fail_count = 0

    # ---- 5a. lib.dgl_test ----
    if not short:
        print("--- lib.dgl_test (需 dgl) ---")
    check("import dgl", "dgl", "dgl (第三方库)", required=False, short=short)
    check("from lib.dgl_test import *", "lib.dgl_test", "lib.dgl_test", required=False, short=short)

    # ---- 5b. lib.pyg_test ----
    if not short:
        print("--- lib.pyg_test (需 torch_geometric) ---")
    check("import torch_geometric", "torch_geometric", "torch_geometric (stub)", required=False, short=short)
    check("from torch_geometric.nn import GCNConv, GATConv, GINConv",
          "torch_geometric.nn", "torch_geometric.nn", required=False, short=short)
    check("from lib.pyg_test import *", "lib.pyg_test", "lib.pyg_test", required=False, short=short)

    # ---- 5c. lib.gnna_test ----
    if not short:
        print("--- lib.gnna_test (需 GNNAdvisor .so) ---")
    gnna_ok, _ = _try_import("import GNNAdvisor", "GNNAdvisor")
    if gnna_ok:
        _, f = check("from lib.gnna_test import *", "lib.gnna_test", "lib.gnna_test", required=True, short=short)
        if f: fail_count += 1
    else:
        check("from lib.gnna_test import *", "lib.gnna_test",
              "lib.gnna_test (GNNAdvisor 未构建)", required=False, short=short)

    # ---- 5d. lib.ubg_test ----
    if not short:
        print("--- lib.ubg_test (需 UBGGNN .so) ---")
    ubg_ok, _ = _try_import("import UBGGNN", "UBGGNN")
    if ubg_ok:
        _, f = check("from lib.ubg_test import *", "lib.ubg_test", "lib.ubg_test", required=True, short=short)
        if f: fail_count += 1
    else:
        check("from lib.ubg_test import *", "lib.ubg_test",
              "lib.ubg_test (UBGGNN 未构建)", required=False, short=short)

    # ---- 5e. lib.kg_test ----
    if not short:
        print("--- lib.kg_test (需 KGGNN .so) ---")
    kg_ok, _ = _try_import("import KGGNN", "KGGNN")
    if kg_ok:
        _, f = check("from lib.kg_test import *", "lib.kg_test", "lib.kg_test", required=True, short=short)
        if f: fail_count += 1
    else:
        check("from lib.kg_test import *", "lib.kg_test",
              "lib.kg_test (KGGNN 未构建)", required=False, short=short)

    # ---- 5f. lib.ge_test ----
    if not short:
        print("--- lib.ge_test (需 GESpMM .so) ---")
    ge_ok, _ = _try_import("import GESpMM", "GESpMM")
    if ge_ok:
        _, f = check("from lib.ge_test import *", "lib.ge_test", "lib.ge_test", required=True, short=short)
        if f: fail_count += 1
    else:
        check("from lib.ge_test import *", "lib.ge_test",
              "lib.ge_test (GESpMM 未构建)", required=False, short=short)

    # ---- 5g. lib.cusparse_test ----
    if not short:
        print("--- lib.cusparse_test (需 KGGNN .so) ---")
    kg_ok2, _ = _try_import("import KGGNN", "KGGNN")
    if kg_ok2:
        _, f = check("from lib.cusparse_test import *", "lib.cusparse_test", "lib.cusparse_test", required=True, short=short)
        if f: fail_count += 1
    else:
        check("from lib.cusparse_test import *", "lib.cusparse_test",
              "lib.cusparse_test (KGGNN 未构建)", required=False, short=short)

    if not short:
        print()
    return fail_count


# ============================================================
# Phase 6: 按测试文件汇总
# ============================================================
tests_imports = {
    "GCN": [
        ("import torch",                        "torch"),
        ("import torch.nn.functional",          "torch.nn.functional"),
        ("from load_dataset import *",          "load_dataset"),
        ("from lib.gnna_test import *",         "lib.gnna_test"),
        ("from lib.ubg_test import *",          "lib.ubg_test"),
        ("from lib.kg_test import *",           "lib.kg_test"),
        ("import utils",                        "utils"),
        ("from perf_time import *",             "perf_time"),
        ("import rabbit",                       "rabbit"),
        ("from lib.dgl_test import *",          "lib.dgl_test",         False),
        ("from lib.pyg_test import *",          "lib.pyg_test",         False),
    ],
    "GAT": [
        ("import torch",                        "torch"),
        ("import torch.nn.functional",          "torch.nn.functional"),
        ("from load_dataset import *",          "load_dataset"),
        ("from lib.ubg_test import *",          "lib.ubg_test"),
        ("from lib.kg_test import *",           "lib.kg_test"),
        ("import utils",                        "utils"),
        ("from perf_time import *",             "perf_time"),
        ("import rabbit",                       "rabbit"),
        ("from lib.dgl_test import *",          "lib.dgl_test",         False),
        ("from lib.pyg_test import *",          "lib.pyg_test",         False),
    ],
    "GIN": [
        ("import torch",                        "torch"),
        ("import torch.nn.functional",          "torch.nn.functional"),
        ("from load_dataset import *",          "load_dataset"),
        ("from lib.gnna_test import *",         "lib.gnna_test"),
        ("from lib.kg_test import *",           "lib.kg_test"),
        ("import utils",                        "utils"),
        ("from perf_time import *",             "perf_time"),
        ("import rabbit",                       "rabbit"),
        ("from lib.dgl_test import *",          "lib.dgl_test",         False),
        ("from lib.pyg_test import *",          "lib.pyg_test",         False),
    ],
    "SpMM": [
        ("import torch",                        "torch"),
        ("from load_dataset import *",          "load_dataset"),
        ("from lib.gnna_test import *",         "lib.gnna_test"),
        ("from lib.ubg_test import *",          "lib.ubg_test"),
        ("from lib.kg_test import *",           "lib.kg_test"),
        ("from lib.ge_test import *",           "lib.ge_test"),
        ("import utils",                        "utils"),
        ("from perf_time import *",             "perf_time"),
        ("import rabbit",                       "rabbit"),
        ("import csv",                          "csv"),
        ("from lib.dgl_test import *",          "lib.dgl_test",         False),
        ("from lib.pyg_test import *",          "lib.pyg_test",         False),
    ],
    "SDDMM": [
        ("import torch",                        "torch"),
        ("from load_dataset import *",          "load_dataset"),
        ("from lib.gnna_test import *",         "lib.gnna_test"),
        ("from lib.ubg_test import *",          "lib.ubg_test"),
        ("from lib.kg_test import *",           "lib.kg_test"),
        ("from lib.ge_test import *",           "lib.ge_test"),
        ("from lib.cusparse_test import *",     "lib.cusparse_test"),
        ("import utils",                        "utils"),
        ("from perf_time import *",             "perf_time"),
        ("import rabbit",                       "rabbit"),
        ("import csv",                          "csv"),
        ("from lib.dgl_test import *",          "lib.dgl_test",         False),
        ("from lib.pyg_test import *",          "lib.pyg_test",         False),
    ],
    "MM": [
        ("import torch",                        "torch"),
        ("import torch.nn.functional",          "torch.nn.functional"),
        ("from load_dataset import *",          "load_dataset"),
        ("import numpy",                        "numpy"),
        ("import utils",                        "utils"),
        ("from perf_time import *",             "perf_time"),
        ("import rabbit",                       "rabbit"),
        ("import KGGNN",                        "KGGNN",                False),
    ],
}


def phase6_by_test(short=False):
    if not short:
        print(f"{BLUE}=== Phase 6: 按测试文件汇总 ==={NC}")

    total_fail = 0
    for test_name in ["GCN", "GAT", "GIN", "SpMM", "SDDMM", "MM"]:
        if not short:
            print(f"\n{BLUE}--- {test_name} 测试 ---{NC}")
        else:
            print(f"[{test_name}]")

        test_fail = 0
        for item in tests_imports[test_name]:
            stmt = item[0]
            desc = item[1]
            req = item[2] if len(item) > 2 else True
            _, failed = check(stmt, desc, desc, required=req, short=short)
            if failed:
                test_fail += 1

        if not short:
            if test_fail == 0:
                print(f"  {GREEN}-> {test_name}: 所有必需 import 通过{NC}")
            else:
                print(f"  {RED}-> {test_name}: 存在 {test_fail} 个必需 import 失败!{NC}")

        total_fail += test_fail

    if not short:
        print()
    return total_fail


# ============================================================
# 其他可选模块 (tqdm, dgl, torch_geometric, ogb, datasketch)
# ============================================================
def phase_optional_extra(short=False):
    if not short:
        print(f"{BLUE}=== Phase X: 其他可选依赖 ==={NC}")

    extras = [
        ("import tqdm",                 "tqdm",                 False),
        ("import dgl",                  "dgl",                  False),
        ("import torch_geometric",      "torch_geometric",      False),
        ("import ogb",                  "ogb",                  False),
        ("import datasketch",           "datasketch",           False),
    ]

    for stmt, desc, req in extras:
        check(stmt, desc, desc, required=req, short=short)

    if not short:
        print()


# ============================================================
# Main
# ============================================================
def main():
    short = "--short" in sys.argv

    phase1_env(short=short)
    f2 = phase2_basic(short=short)
    f3 = phase3_extensions(short=short)
    f4 = phase4_test_modules(short=short)
    f5 = phase5_lib_modules(short=short)
    f6 = phase6_by_test(short=short)
    phase_optional_extra(short=short)

    total = f2 + f3 + f4 + f5 + f6

    # Summary
    print("=" * 50)
    if total == 0:
        print(f"{GREEN}所有必需 import 均通过! 可以运行测试。{NC}")
    else:
        print(f"{RED}存在 {total} 个必需 import 失败, 请检查上述错误信息!{NC}")
        print()
        print("常见解决方法:")
        print("  1. 检查 .so 文件是否已构建: bash cmd2.sh build")
        print("  2. 检查 ROCm / PyTorch 模块是否正确加载")
        print("  3. 确认当前目录为项目根目录, PYTHONPATH 已正确设置")
    print("=" * 50)

    return 0 if total == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
