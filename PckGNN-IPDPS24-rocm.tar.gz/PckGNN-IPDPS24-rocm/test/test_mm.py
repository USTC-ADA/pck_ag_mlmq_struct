import torch
import torch.nn.functional as F
import torch.nn as nn
from load_dataset import *
# from lib.kg_test import *
try:
    import KGGNN
    HAS_KGGNN = True
except ImportError:
    HAS_KGGNN = False
    print("Warning: KGGNN extension not built. MM test will be skipped.")
import numpy as np

import utils
import sys
import time
from perf_time import * 

import rabbit

import os

os.environ["CUDA_VISIBLE_DEVICES"] = '0'

# Set device
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

torch.backends.cuda.matmul.allow_tf32 = False
torch.backends.cudnn.allow_tf32 = False

# Cora
# m = 2816
# n = 64
# k = 1440

# ogbn-arxiv
m = 169343
n = 64
k = 128

# Pubmed
m = 19717
n = 64
k = 512


# m = 1024
# n = 1024
# k = 1024

np.random.seed(5)

a = torch.randn(m, k).to(device)
b = torch.randn(k, n).to(device)
c2 = torch.zeros(m, n).to(device)

#print(a.cpu()[128:133][0:8])
#print(b.cpu()[:][0:8])

perf_time_init("tmp")

c1 = torch.mm(a, b)
#c2 = torch.mm(a, b)

warmup = 10
repetitions = 100

# warmup = 0
# repetitions = 1

starter, ender = torch.cuda.Event(enable_timing=True), torch.cuda.Event(enable_timing=True)

# 初始化一个时间容器
timings = 0.0
with torch.no_grad():
    for repeat in range(warmup):
        c1 = torch.mm(a, b)
    starter.record()
    #with torch.autograd.profiler.profile(enabled=True, use_cuda=True) as prof:
    for repeat in range(repetitions):
        c1 = torch.mm(a, b)
    ender.record()
    torch.cuda.synchronize()
    curr_time = starter.elapsed_time(ender) # 从 starter 到 ender 之间用时,单位为毫秒
    timings += curr_time
torch_time = timings / repetitions * 1000
print("Torch time: {:.4f} us".format(torch_time))

# tb = prof.table()
# print(tb[tb.index("Self CUDA time total:"):-1])

torch.cuda.synchronize()

# KGGNN.cublas_run_mm(a, b, c2)
# KGGNN.kg_gcn_run_mm(a, b, c2)

# EFGNN
if HAS_KGGNN:
    timings = 0.0
    with torch.no_grad():
        for repeat in range(warmup):
            KGGNN.kg_gcn_run_mm(a, b, c2)
            #KGGNN.kg_gcn_run_fused_mm(a, b, c2)
        starter.record()
        for repeat in range(repetitions):
            KGGNN.kg_gcn_run_mm(a, b, c2)
            #KGGNN.kg_gcn_run_fused_mm(a, b, c2)
        ender.record()
        torch.cuda.synchronize()
        curr_time = starter.elapsed_time(ender) # 从 starter 到 ender 之间用时,单位为毫秒
        timings += curr_time
    kg_time = timings / repetitions * 1000
    print("KG time: {:.4f} us".format(kg_time))

    # print(b.cpu())

    print(c1.cpu())
    print(c2.cpu())
    print(torch.norm(c1.cpu() - c2.cpu()))
    tflops = m * n * k / 1024 / 1024 / 1024 / 1024 * 1000 * 1000
    print("torch perf: {:.2f} TFLOPS".format(tflops / torch_time))
    print("kg mm perf: {:.2f} TFLOPS".format(tflops / kg_time))
else:
    print("Skipping KG MM test: KGGNN extension not built.")
    print("Run 'bash cmd.sh build-ext' first.")
# print(torch.max(c1.cpu() - c2.cpu()))
# idx = int(int(torch.argmax(c1.cpu() - c2.cpu()) / n) / 64) * 64
# print(idx)
# print(c1[idx:idx+128])
# print(c2[idx:idx+128])
