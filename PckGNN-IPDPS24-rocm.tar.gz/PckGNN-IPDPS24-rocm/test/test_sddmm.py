import torch
import torch.nn.functional as F
import torch.nn as nn
from load_dataset import *
try:
    from lib.dgl_test import *
except ImportError:
    pass
try:
    from lib.pyg_test import *
except ImportError:
    pass
from lib.gnna_test import *
from lib.ubg_test import *
from lib.kg_test import *
from lib.ge_test import *
from lib.cusparse_test import *

import utils
import sys
import time
from perf_time import * 

import rabbit

import os

import csv

os.environ["CUDA_VISIBLE_DEVICES"] = '1'

if (len(sys.argv) < 3 or len(sys.argv) > 4):
    print("Usage: python test_sddmm.py [dataset] [in_dim] [outcsv_name | optional]")
    exit(1)

dataset_dir = sys.argv[1]
in_dim = int(sys.argv[2])
if len(sys.argv) == 4:
    outcsv_name = sys.argv[3]
else:
    outcsv_name = None

# Load and initialize input data
graph_data = dataset_load(dataset_dir)
_, _ = dataset_prop(graph_data)
#in_dim = 128
reorder = True

torch.manual_seed(2024)

input_feature = torch.randn(2, graph_data.num_nodes, in_dim)

# Set device and move data
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
graph_data = graph_data.to(device)
input_feature = input_feature.to(device)

graph_csr = utils.graph_to_csr(graph_data, show_degree = True, reorder = reorder)

out_cu, cu_time = cusp_run('SDDMM', graph_csr, input_feature, in_dim, device)
print("cu_time: {:.2f} ms".format(cu_time / 1000))

# out_ubg, ubg_time = ubg_model_run('SDDMM', graph_csr, 32, 32, 32, input_feature, device, detail_test = 1)

# print(input_feature[:,:,:])


out_pck, pck_time = kg_run_kernel('SDDMM', graph_csr, input_feature, in_dim, device,
balance = 1, detail_test = 0)
out_pck, pck_time = kg_run_kernel('SDDMM', graph_csr, input_feature, in_dim, device,
balance = 1, detail_test = 1)
out_pck, pck_time = kg_run_kernel('SDDMM', graph_csr, input_feature, in_dim, device,
balance = 2, detail_test = 0)
out_pck, pck_time = kg_run_kernel('SDDMM', graph_csr, input_feature, in_dim, device,
balance = 2, detail_test = 1)

# print(out_cu)
# print(out_pck)
print(torch.norm(out_cu - out_pck))
# print(torch.norm(out_cu - out_ubg))

if (outcsv_name != None):
    with open(outcsv_name, "a") as csvfile: 
        writer = csv.writer(csvfile)

        row = []
        row.append(dataset_dir)
        row.append(str(in_dim))
        row.append(str(pck_time))
        row.append(str(cu_time / 1000))

        writer.writerow(row)
