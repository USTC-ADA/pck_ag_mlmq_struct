"""
run_mm.py — 独立 Dense MM (矩阵乘法) 基准测试 (不依赖 DGL/PyG)

用法:
    python3 run_mm.py [m] [n] [k]

或通过 cmd2.sh:
    bash cmd2.sh st-mm

测试内容:
    - torch.mm (PyTorch cuBLAS/hipBLAS) 基准
    - KGGNN.kg_gcn_run_mm (KG 自定义 MM kernel) 基准
    - TFLOPS 统计与正确性校验
"""

import sys
import os
from pathlib import Path

_TEST_DIR = str(Path(__file__).resolve().parent.parent)
if _TEST_DIR not in sys.path:
    sys.path.insert(0, _TEST_DIR)

import torch
import torch.nn.functional as F
import numpy as np

from perf_time import perf_time_init

try:
    import KGGNN
    HAS_KGGNN = True
except ImportError:
    HAS_KGGNN = False
    print("Warning: KGGNN extension not built. MM kernel test will be skipped.")

os.environ.setdefault("CUDA_VISIBLE_DEVICES", '0')

USAGE = "Usage: python3 run_mm.py [m] [n] [k]"


def main():
    args = sys.argv[1:]
    if len(args) == 0:
        m, n, k = 169343, 64, 128
    elif len(args) == 3:
        m, n, k = int(args[0]), int(args[1]), int(args[2])
    else:
        print(USAGE)
        sys.exit(1)

    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    print("device:", device)
    print("matrix: m={}, n={}, k={}".format(m, n, k))

    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False

    np.random.seed(5)

    a = torch.randn(m, k).to(device)
    b = torch.randn(k, n).to(device)
    c2 = torch.zeros(m, n).to(device)

    perf_time_init("mm_test")

    c1 = torch.mm(a, b)

    warmup = 10
    repetitions = 100

    starter, ender = torch.cuda.Event(enable_timing=True), \
        torch.cuda.Event(enable_timing=True)

    # ---- torch.mm ----
    timings = 0.0
    with torch.no_grad():
        for _ in range(warmup):
            c1 = torch.mm(a, b)
        starter.record()
        for _ in range(repetitions):
            c1 = torch.mm(a, b)
        ender.record()
        torch.cuda.synchronize()
        curr_time = starter.elapsed_time(ender)
        timings += curr_time
    torch_time = timings / repetitions * 1000
    print("Torch time: {:.4f} us".format(torch_time))

    torch.cuda.synchronize()

    # ---- KGGNN MM ----
    if HAS_KGGNN:
        timings = 0.0
        with torch.no_grad():
            for _ in range(warmup):
                KGGNN.kg_gcn_run_mm(a, b, c2)
            starter.record()
            for _ in range(repetitions):
                KGGNN.kg_gcn_run_mm(a, b, c2)
            ender.record()
            torch.cuda.synchronize()
            curr_time = starter.elapsed_time(ender)
            timings += curr_time
        kg_time = timings / repetitions * 1000
        print("KG time: {:.4f} us".format(kg_time))

        # ---- 正确性校验 ----
        print("\n=== Correctness Check ===")
        diff = torch.norm(c1.cpu() - c2.cpu()).item()
        print("  torch.mm vs KG MM norm diff: {:.6e}".format(diff))
        print("  (first 5x5 of torch.mm):")
        print(c1.cpu()[:5, :5])
        print("  (first 5x5 of KG MM):")
        print(c2.cpu()[:5, :5])

        # ---- TFLOPS ----
        tflops = m * n * k / 1024 / 1024 / 1024 / 1024 * 1000 * 1000
        print("\n=== Performance ===")
        print("  torch.mm: {:.2f} TFLOPS".format(tflops / torch_time))
        print("  KG MM:    {:.2f} TFLOPS".format(tflops / kg_time))
    else:
        print("Skipping KG MM test: KGGNN extension not built.")
        print("Run 'bash cmd2.sh build-kggnn' first.")


if __name__ == "__main__":
    main()
