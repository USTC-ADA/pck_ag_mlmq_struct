"""
naive_ref.py — 纯 PyTorch 参考实现, 用于在不依赖 DGL/PyG 的情况下
对 KGGNN/UBGGNN/GESpMM 等 kernel 的输出做正确性校验。

所有实现仅使用 torch 原生算子 (index_add_, repeat_interleave, mm),
不依赖任何第三方稀疏库, 逻辑简单直观, 可作为 ground truth。

用法:
    from standalone.naive_ref import naive_spmm, naive_sddmm, naive_gcn_forward
"""

import torch


def naive_spmm(rowptr, indices, feat, num_nodes=None):
    """SpMM 参考实现: Y = A * X (CSR 格式, 求和聚合)

    Args:
        rowptr:  [N+1] int tensor, CSR 行指针
        indices: [nnz] int tensor, CSR 列索引
        feat:    [N, D] float tensor, 节点特征矩阵
        num_nodes: 节点数 (默认从 rowptr 推断)

    Returns:
        [N, D] float tensor, 聚合后特征
    """
    if num_nodes is None:
        num_nodes = rowptr.size(0) - 1
    device = feat.device
    row_ids = torch.repeat_interleave(
        torch.arange(num_nodes, device=device, dtype=torch.long),
        (rowptr[1:] - rowptr[:-1]).to(torch.long))
    out = torch.zeros(num_nodes, feat.size(1), device=device, dtype=feat.dtype)
    out.index_add_(0, row_ids, feat[indices])
    return out


def naive_spmm_with_deg(rowptr, indices, feat, degree, num_nodes=None):
    """带度归一化的 SpMM: Y = D^{-1} * (A * X)

    与 KGGNN.kg_gcn_run_balance_with_deg 语义一致:
        degree = 1.0 / node_degree
        out[i] = degree[i] * sum_j(feat[j])

    Args:
        rowptr:  [N+1] int tensor
        indices: [nnz] int tensor
        feat:    [N, D] float tensor
        degree:  [N] float tensor, 1/度
        num_nodes: 节点数

    Returns:
        [N, D] float tensor
    """
    agg = naive_spmm(rowptr, indices, feat, num_nodes)
    return degree.unsqueeze(1) * agg


def naive_sddmm(rowptr, indices, X, Y, num_nodes=None):
    """SDDMM 参考实现: S[i,j] = <X[i], Y[j]> 对每条边 (i,j)

    Args:
        rowptr:  [N+1] int tensor, CSR 行指针
        indices: [nnz] int tensor, CSR 列索引
        X:       [N, D] float tensor
        Y:       [N, D] float tensor
        num_nodes: 节点数

    Returns:
        [nnz] float tensor, 每条边的点积结果
    """
    if num_nodes is None:
        num_nodes = rowptr.size(0) - 1
    device = X.device
    row_ids = torch.repeat_interleave(
        torch.arange(num_nodes, device=device, dtype=torch.long),
        (rowptr[1:] - rowptr[:-1]).to(torch.long))
    Xi = X[row_ids]
    Yj = Y[indices]
    return (Xi * Yj).sum(dim=1)


def naive_gcn_forward(rowptr, indices, input_feat, w0, b0, w1, b1,
                      degree, num_nodes=None):
    """Naive GCN 2层前向传播 (与 kg_run_tmp name='GCN' 语义一致)

    流程:
        feat0 = X * W0
        agg0  = D^{-1} * SpMM(feat0)
        h0    = ReLU(agg0 + b0)
        feat1 = h0 * W1
        agg1  = D^{-1} * SpMM(feat1)
        out   = log_softmax(agg1 + b1)

    Args:
        rowptr, indices: CSR 图结构
        input_feat: [N, in_dim] 输入特征
        w0, b0:     [in_dim, hidden], [hidden] 第一层参数
        w1, b1:     [hidden, out_dim], [out_dim] 第二层参数
        degree:     [N] 1/度
        num_nodes:  节点数

    Returns:
        [N, out_dim] float tensor, log_softmax 输出
    """
    feat0 = torch.mm(input_feat, w0)
    agg0 = naive_spmm_with_deg(rowptr, indices, feat0, degree, num_nodes)
    h0 = torch.relu(agg0 + b0)
    feat1 = torch.mm(h0, w1)
    agg1 = naive_spmm_with_deg(rowptr, indices, feat1, degree, num_nodes)
    out = torch.log_softmax(agg1 + b1, dim=1)
    return out


def naive_gin_forward(rowptr, indices, input_feat, w0, b0, w1, b1,
                      eps=0.0, num_nodes=None):
    """Naive GIN 2层前向传播 (与 kg_run_tmp name='GIN' 语义一致)

    流程:
        agg0  = SpMM(X) + (1+eps)*X     (GIN 聚合 = sum + self-loop * (1+eps))
        h0    = ReLU(agg0 * W0 + b0)
        agg1  = SpMM(h0) + (1+eps)*h0
        out   = log_softmax(agg1 * W1 + b1)

    Args:
        rowptr, indices: CSR 图结构
        input_feat: [N, in_dim]
        w0, b0, w1, b1: 参数
        eps: GIN epsilon
        num_nodes: 节点数

    Returns:
        [N, out_dim] float tensor
    """
    agg0 = naive_spmm(rowptr, indices, input_feat, num_nodes)
    agg0 = agg0 + (1 + eps) * input_feat
    h0 = torch.relu(torch.mm(agg0, w0) + b0)
    agg1 = naive_spmm(rowptr, indices, h0, num_nodes)
    agg1 = agg1 + (1 + eps) * h0
    out = torch.log_softmax(torch.mm(agg1, w1) + b1, dim=1)
    return out


def check_correctness(out_kernel, out_ref, name="kernel", tol=1e-2):
    """正确性校验: 计算两个输出的范数差异并打印结果。

    Args:
        out_kernel: kernel 输出 (GPU 或 CPU tensor)
        out_ref:    参考实现输出 (同一设备)
        name:       kernel 名称 (用于打印)
        tol:        相对容差

    Returns:
        (passed: bool, norm: float)
    """
    if out_kernel is None or out_ref is None:
        print("  [CHECK] {} -- skipped (None input)".format(name))
        return True, 0.0
    diff = out_kernel.float().cpu() - out_ref.float().cpu()
    norm = torch.norm(diff).item()
    ref_norm = torch.norm(out_ref.float().cpu()).item()
    rel = norm / max(ref_norm, 1e-12)
    passed = rel < tol
    tag = "PASS" if passed else "FAIL"
    print("  [CHECK] {} -- {}  abs_norm={:.6e}  rel_norm={:.6e}  tol={}".format(
        name, tag, norm, rel, tol))
    return passed, norm
