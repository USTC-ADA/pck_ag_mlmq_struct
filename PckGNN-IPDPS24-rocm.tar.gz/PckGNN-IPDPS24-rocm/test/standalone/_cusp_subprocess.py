"""
_cusp_subprocess.py — 隔离的 cuSPARSE/hipSPARSE 运行器 (子进程)

本脚本在独立子进程中运行 cuSPARSE 调用, 因为 KGGNN 的 CUSPARSE_CHECK 宏
在 hipSPARSE 返回错误时会调用 C 的 exit(), 直接终止整个进程, Python 的
try/except 无法捕获。通过子进程隔离, exit() 只杀死子进程, 主进程可继续
运行后续测试和正确性校验。

用法 (由 run_spmm.py / run_sddmm.py 自动调用, 不需手动运行):
    python3 _cusp_subprocess.py <mode> <dataset.pt> <in_dim> <seed> <out.pt>

    mode:     'SpMM' 或 'SDDMM'
    dataset:  .pt 数据集路径
    in_dim:   特征维度
    seed:     随机种子 (用于复现父进程的 input_feature)
    out.pt:   输出 tensor 保存路径 (成功时写入)

退出码:
    0  = 成功, 结果已保存到 out.pt, 计时信息打印到 stdout
    1  = 参数错误
    2  = hipSPARSE 调用失败 (C++ exit 不会返回, 但若被信号杀死也视为失败)
"""

import sys
import os
from pathlib import Path

_TEST_DIR = str(Path(__file__).resolve().parent.parent)
if _TEST_DIR not in sys.path:
    sys.path.insert(0, _TEST_DIR)

import torch
import numpy as np

from standalone.data_stub import safe_load
from load_dataset import dataset_load, dataset_prop
from lib.cusparse_test import cusp_run
import utils

try:
    import rabbit
    HAS_RABBIT = True
except ImportError:
    HAS_RABBIT = False

os.environ.setdefault("CUDA_VISIBLE_DEVICES", '0')


def main():
    if len(sys.argv) != 6:
        print("ERROR: expected 5 args: <mode> <dataset.pt> <in_dim> <seed> <out.pt>")
        sys.exit(1)

    mode = sys.argv[1]
    dataset_dir = sys.argv[2]
    in_dim = int(sys.argv[3])
    seed = int(sys.argv[4])
    out_path = sys.argv[5]

    if mode not in ('SpMM', 'SDDMM'):
        print("ERROR: mode must be 'SpMM' or 'SDDMM', got '{}'".format(mode))
        sys.exit(1)

    try:
        import KGGNN
    except ImportError:
        print("ERROR: KGGNN extension not built")
        sys.exit(2)

    graph_data = safe_load(dataset_dir)
    _, _ = dataset_prop(graph_data)

    torch.manual_seed(seed)

    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    graph_data = graph_data.to(device)

    reorder = HAS_RABBIT
    graph_csr = utils.graph_to_csr(graph_data, show_degree=True, reorder=reorder)

    if mode == 'SpMM':
        input_feature = torch.randn(graph_data.num_nodes, in_dim).to(device)
        out, test_time = cusp_run('SpMM', graph_csr, input_feature, in_dim, device)
    else:
        input_feature = torch.randn(2, graph_data.num_nodes, in_dim).to(device)
        out, test_time = cusp_run('SDDMM', graph_csr, input_feature, in_dim, device)

    print("cuSPARSE_TIME_US:{}".format(test_time))
    print("cuSPARSE_OUT_SHAPE:{}".format(list(out.shape)))
    print("cuSPARSE_OUT_NORM:{:.6f}".format(torch.norm(out).item()))

    torch.save(out.cpu(), out_path)
    sys.exit(0)


if __name__ == "__main__":
    main()
