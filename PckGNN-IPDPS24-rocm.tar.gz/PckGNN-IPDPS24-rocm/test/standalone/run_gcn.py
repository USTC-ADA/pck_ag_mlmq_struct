"""
run_gcn.py — 独立 GCN 基准测试 (不依赖 DGL/PyG)

用法:
    python3 run_gcn.py <dataset.pt> [outcsv_name]

或通过 cmd2.sh:
    bash cmd2.sh st-gcn <dataset.pt> [outcsv_name]

测试内容:
    - KGGNN GCN 2层前向 (balance=-1 auto, balance=6 bin-packing)
    - 可选: UBG GCN (若 UBGGNN .so 已构建)
    - 小图 (< 10万边): naive torch 参考实现正确性校验
"""

import sys
import os
from pathlib import Path

_TEST_DIR = str(Path(__file__).resolve().parent.parent)
if _TEST_DIR not in sys.path:
    sys.path.insert(0, _TEST_DIR)

import torch
import torch.nn.functional as F
import numpy as np

from standalone.data_stub import safe_load
from standalone.naive_ref import naive_gcn_forward, check_correctness
from load_dataset import dataset_load, dataset_prop
from lib.kg_test import kg_run_tmp
from perf_time import perf_time_init, perf_time_start, perf_time_end, perf_time_tofile
import utils

try:
    import rabbit
    HAS_RABBIT = True
except ImportError:
    HAS_RABBIT = False
    print("Warning: rabbit extension not built. Reordering will be disabled.")

try:
    from lib.ubg_test import ubg_model_run
    HAS_UBG = True
except Exception:
    HAS_UBG = False
    print("Warning: UBGGNN not available. UBG baseline will be skipped.")

os.environ.setdefault("CUDA_VISIBLE_DEVICES", '0')

USAGE = "Usage: python3 run_gcn.py <dataset.pt> [outcsv_name]"


def main():
    if len(sys.argv) < 2 or len(sys.argv) > 3:
        print(USAGE)
        sys.exit(1)

    dataset_dir = sys.argv[1]
    outcsv_name = sys.argv[2] if len(sys.argv) == 3 else None

    gcn_hidden = 64
    out_dim = 32

    graph_data = safe_load(dataset_dir)
    in_dim, out_dim = dataset_prop(graph_data)
    out_dim = int((out_dim + 31) / 32) * 32

    print("dataset:", dataset_dir, "in_dim:", in_dim, "out_dim:", out_dim)

    random_seed = 123
    torch.manual_seed(random_seed)
    weight0 = torch.randn(in_dim, gcn_hidden)
    weight1 = torch.randn(gcn_hidden, out_dim)
    bias0 = torch.randn(gcn_hidden)
    bias1 = torch.randn(out_dim)
    paras = {'w0': weight0, 'w1': weight1, 'b0': bias0, 'b1': bias1}

    input_feature = torch.randn(graph_data.num_nodes, in_dim)

    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    graph_data = graph_data.to(device)
    input_feature = input_feature.to(device)
    print("device:", device)

    perf_time_init(dataset_dir)

    reorder = HAS_RABBIT
    graph_csr = utils.graph_to_csr(graph_data, reorder=reorder)

    # ---- KGGNN GCN: balance=-1 (auto) ----
    print("\n=== KGGNN GCN (balance=-1, auto) ===")
    out_kg_auto, _ = kg_run_tmp(
        graph_csr, input_feature, in_dim, gcn_hidden, out_dim, device,
        balance=-1, paras=paras, detail_test=0, reorder=False,
        time_label='KG auto')

    out_kg_auto, _ = kg_run_tmp(
        graph_csr, input_feature, in_dim, gcn_hidden, out_dim, device,
        balance=-1, paras=paras, detail_test=1, reorder=False,
        time_label='KG auto')

    # ---- KGGNN GCN: balance=6 (bin-packing) ----
    print("\n=== KGGNN GCN (balance=6, bin-packing) ===")
    out_kg_bp, _ = kg_run_tmp(
        graph_csr, input_feature, in_dim, gcn_hidden, out_dim, device,
        balance=6, paras=paras, detail_test=0, reorder=False,
        time_label='KG binpack')

    out_kg_bp, _ = kg_run_tmp(
        graph_csr, input_feature, in_dim, gcn_hidden, out_dim, device,
        balance=6, paras=paras, detail_test=1, reorder=False,
        time_label='KG binpack')

    # ---- UBG GCN (可选) ----
    if HAS_UBG:
        print("\n=== UBG GCN ===")
        try:
            out_ubg, _ = ubg_model_run(
                "GCN", graph_csr, in_dim, gcn_hidden, out_dim,
                input_feature, device, paras=paras, detail_test=1)
        except Exception as e:
            print("  UBG GCN failed: {}".format(e))
            out_ubg = None
    else:
        out_ubg = None

    # ---- 正确性校验 (小图) ----
    num_edges = len(graph_csr.indices)
    print("\n=== Correctness Check (num_edges={}) ===".format(num_edges))
    if num_edges < 100000:
        rowptr = torch.tensor(graph_csr.indptr)
        indices = torch.tensor(graph_csr.indices)
        degree = 1.0 / torch.tensor(
            graph_csr.indptr[1:] - graph_csr.indptr[:-1], dtype=torch.float32)
        num_nodes = graph_data.num_nodes if hasattr(graph_data, 'num_nodes') \
            else graph_data.x.size(0)

        with torch.no_grad():
            out_ref = naive_gcn_forward(
                rowptr, indices, input_feature.cpu(),
                weight0.cpu(), bias0.cpu(), weight1.cpu(), bias1.cpu(),
                degree.cpu(), num_nodes)

        check_correctness(out_kg_auto, out_ref, name="KGGNN auto")
        check_correctness(out_kg_bp, out_ref, name="KGGNN binpack")
        if out_ubg is not None:
            check_correctness(out_ubg, out_ref, name="UBG")
    else:
        print("  Skipped (graph too large for naive reference, >100k edges)")

    # ---- 输出摘要 ----
    print("\n=== Output Summary ===")
    print("  KGGNN auto:    shape={}, norm={:.6f}".format(
        out_kg_auto.shape, torch.norm(out_kg_auto).item()))
    print("  KGGNN binpack: shape={}, norm={:.6f}".format(
        out_kg_bp.shape, torch.norm(out_kg_bp).item()))
    if not torch.isnan(out_kg_auto).any():
        print("  KGGNN auto vs binpack norm diff: {:.6f}".format(
            torch.norm(out_kg_auto - out_kg_bp).item()))

    if outcsv_name:
        perf_time_tofile(outcsv_name)


if __name__ == "__main__":
    main()
