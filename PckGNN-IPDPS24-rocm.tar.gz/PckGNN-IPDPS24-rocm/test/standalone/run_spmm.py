"""
run_spmm.py — 独立 SpMM kernel 基准测试 (不依赖 DGL/PyG)

用法:
    python3 run_spmm.py <dataset.pt> <in_dim> [outcsv_name]

或通过 cmd2.sh:
    bash cmd2.sh st-spmm <dataset.pt> <in_dim> [outcsv_name]

测试内容:
    - KGGNN SpMM (balance=1, balance=2, balance=6 bin-packing)
    - GESpMM (dgSPARSE)
    - cuSPARSE (via KGGNN wrapper)
    - 小图 (< 10万边): naive torch SpMM 正确性校验
"""

import sys
import os
import subprocess
import tempfile
from pathlib import Path

_TEST_DIR = str(Path(__file__).resolve().parent.parent)
if _TEST_DIR not in sys.path:
    sys.path.insert(0, _TEST_DIR)

import torch
import numpy as np

from standalone.data_stub import safe_load
from standalone.naive_ref import naive_spmm, check_correctness
from load_dataset import dataset_load, dataset_prop
from lib.kg_test import kg_run_kernel
from perf_time import perf_time_init, perf_time_tofile
import utils

try:
    import rabbit
    HAS_RABBIT = True
except ImportError:
    HAS_RABBIT = False
    print("Warning: rabbit extension not built. Reordering will be disabled.")

try:
    from lib.ge_test import ge_spmm_run, HAS_GESPMM
except Exception:
    HAS_GESPMM = False
    print("Warning: GESpMM not available. GE-SpMM baseline will be skipped.")

try:
    import KGGNN
    HAS_KGGNN_CUSP = True
except ImportError:
    HAS_KGGNN_CUSP = False
    print("Warning: KGGNN extension not built. cuSPARSE baseline will be skipped.")

os.environ.setdefault("CUDA_VISIBLE_DEVICES", '0')

USAGE = "Usage: python3 run_spmm.py <dataset.pt> <in_dim> [outcsv_name]"


def _run_cusp_subprocess(mode, dataset_dir, in_dim, seed):
    """在子进程中运行 cuSPARSE/hipSPARSE, 隔离 C++ exit() 防止主进程被杀。

    KGGNN 的 CUSPARSE_CHECK 宏在 hipSPARSE 出错时调用 C 的 exit(),
    Python try/except 无法捕获。通过子进程隔离, exit() 只杀子进程。

    Returns:
        (out_tensor or None, time_us or 0.0)
    """
    script = str(Path(__file__).resolve().parent / '_cusp_subprocess.py')
    with tempfile.NamedTemporaryFile(suffix='.pt', delete=False) as f:
        out_path = f.name
    try:
        proc = subprocess.run(
            [sys.executable, script, mode, dataset_dir,
             str(in_dim), str(seed), out_path],
            capture_output=True, text=True, timeout=300)
        if proc.returncode != 0:
            print("  cuSPARSE subprocess exited with code {} (hipSPARSE error)".format(
                proc.returncode))
            if proc.stdout:
                for line in proc.stdout.strip().splitlines():
                    print("  [subprocess] {}".format(line))
            if proc.stderr:
                for line in proc.stderr.strip().splitlines()[-5:]:
                    print("  [subprocess stderr] {}".format(line))
            return None, 0.0

        time_us = 0.0
        for line in proc.stdout.strip().splitlines():
            if line.startswith('cuSPARSE_TIME_US:'):
                time_us = float(line.split(':')[1])
            elif line.startswith('cuSPARSE_OUT_'):
                print("  {}".format(line))
        out = torch.load(out_path)
        return out, time_us
    except subprocess.TimeoutExpired:
        print("  cuSPARSE subprocess timed out (>300s)")
        return None, 0.0
    except Exception as e:
        print("  cuSPARSE subprocess failed: {}".format(e))
        return None, 0.0
    finally:
        if os.path.exists(out_path):
            os.remove(out_path)


def main():
    if len(sys.argv) < 3 or len(sys.argv) > 4:
        print(USAGE)
        sys.exit(1)

    dataset_dir = sys.argv[1]
    in_dim = int(sys.argv[2])
    outcsv_name = sys.argv[3] if len(sys.argv) == 4 else None
    out_dim = in_dim

    graph_data = safe_load(dataset_dir)
    _, _ = dataset_prop(graph_data)

    print("dataset:", dataset_dir, "dim:", out_dim)

    # Fixed seed for input_feature generation (must match _cusp_subprocess.py)
    feat_seed = 123
    torch.manual_seed(feat_seed)
    input_feature = torch.randn(graph_data.num_nodes, in_dim)

    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    graph_data = graph_data.to(device)
    input_feature = input_feature.to(device)
    print("device:", device)

    perf_time_init(dataset_dir)

    reorder = HAS_RABBIT
    graph_csr = utils.graph_to_csr(graph_data, show_degree=True, reorder=reorder)

    # ---- KGGNN SpMM ----
    print("\n=== KGGNN SpMM ===")
    out_kg1, _ = kg_run_kernel(
        'SpMM', graph_csr, input_feature, out_dim, device,
        balance=1, detail_test=0)
    out_kg1, _ = kg_run_kernel(
        'SpMM', graph_csr, input_feature, out_dim, device,
        balance=1, detail_test=1, time_label='KG balance1')

    out_kg2, _ = kg_run_kernel(
        'SpMM', graph_csr, input_feature, out_dim, device,
        balance=2, detail_test=0)
    out_kg2, _ = kg_run_kernel(
        'SpMM', graph_csr, input_feature, out_dim, device,
        balance=2, detail_test=1, time_label='KG balance2')

    out_kg6, _ = kg_run_kernel(
        'SpMM', graph_csr, input_feature, out_dim, device,
        balance=6, detail_test=0)
    out_kg6, _ = kg_run_kernel(
        'SpMM', graph_csr, input_feature, out_dim, device,
        balance=6, detail_test=1, time_label='KG binpack')

    # ---- GESpMM ----
    out_ge = None
    if HAS_GESPMM:
        print("\n=== GESpMM ===")
        try:
            out_ge, ge_time = ge_spmm_run(graph_csr, out_dim, input_feature)
            out_ge = out_ge.to(device)
            print("  GE best time: {:.3f} ms".format(ge_time))
        except Exception as e:
            print("  GESpMM failed: {}".format(e))

    # ---- cuSPARSE (子进程隔离, 防止 hipSPARSE exit() 杀死主进程) ----
    out_cusp = None
    if HAS_KGGNN_CUSP:
        print("\n=== cuSPARSE (hipSPARSE) ===")
        out_cusp, cusp_time = _run_cusp_subprocess(
            'SpMM', dataset_dir, in_dim, seed=feat_seed)
        if out_cusp is not None:
            out_cusp = out_cusp.to(device)
            print("  cuSPARSE time: {:.3f} ms".format(cusp_time / 1000))
        else:
            print("  cuSPARSE baseline skipped (see warning above)")

    # ---- 正确性校验 (小图) ----
    num_edges = len(graph_csr.indices)
    print("\n=== Correctness Check (num_edges={}) ===".format(num_edges))
    if num_edges < 100000:
        rowptr = torch.tensor(graph_csr.indptr)
        indices = torch.tensor(graph_csr.indices)
        num_nodes = graph_data.num_nodes if hasattr(graph_data, 'num_nodes') \
            else graph_data.x.size(0)

        with torch.no_grad():
            out_ref = naive_spmm(
                rowptr, indices, input_feature.cpu(), num_nodes)

        check_correctness(out_kg1, out_ref, name="KGGNN balance1")
        check_correctness(out_kg2, out_ref, name="KGGNN balance2")
        check_correctness(out_kg6, out_ref, name="KGGNN binpack")
        if out_ge is not None:
            check_correctness(out_ge, out_ref, name="GESpMM")
        if out_cusp is not None:
            check_correctness(out_cusp, out_ref, name="cuSPARSE")
    else:
        print("  Skipped (graph too large for naive reference, >100k edges)")

    # ---- 输出摘要 ----
    print("\n=== Output Summary ===")
    print("  KGGNN balance1:  shape={}, norm={:.6f}".format(
        out_kg1.shape, torch.norm(out_kg1).item()))
    print("  KGGNN balance2:  shape={}, norm={:.6f}".format(
        out_kg2.shape, torch.norm(out_kg2).item()))
    print("  KGGNN binpack:   shape={}, norm={:.6f}".format(
        out_kg6.shape, torch.norm(out_kg6).item()))
    if out_ge is not None:
        print("  GESpMM:          shape={}, norm={:.6f}".format(
            out_ge.shape, torch.norm(out_ge).item()))
    if out_cusp is not None:
        print("  cuSPARSE:        shape={}, norm={:.6f}".format(
            out_cusp.shape, torch.norm(out_cusp).item()))

    if outcsv_name:
        perf_time_tofile(outcsv_name)


if __name__ == "__main__":
    main()
