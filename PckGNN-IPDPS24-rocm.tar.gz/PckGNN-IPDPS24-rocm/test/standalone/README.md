# Standalone 测试套件 — 不依赖 DGL/PyG/ogb 的 GNN kernel 基准测试

## 概述

本目录提供一套独立的 GNN kernel 性能基准测试, 复用项目自有的 KGGNN / UBG /
GESpMM / cuSPARSE HIP 扩展, 但 **不依赖** DGL、PyTorch Geometric、ogb、
datasketch、tqdm 等第三方 Python 包。

超算环境中仅需 **PyTorch 1.10.1+rocm4.0.1 + numpy** (均已预装), 即可运行全部测试。

## 用法

通过 `cmd2.sh` (推荐):

```bash
bash cmd2.sh build                       # 先编译 HIP 扩展
bash cmd2.sh st-gcn    <dataset.pt>      # GCN 2层前向
bash cmd2.sh st-gat    <dataset.pt>      # GAT 2层前向
bash cmd2.sh st-gin    <dataset.pt>      # GIN 2层前向
bash cmd2.sh st-spmm   <dataset.pt> 64   # SpMM kernel (指定 feature 维度)
bash cmd2.sh st-sddmm  <dataset.pt> 64   # SDDMM kernel
bash cmd2.sh st-mm                      # Dense MM (矩阵乘法)
```

直接运行 (需手动设置 PYTHONPATH, 或由 cmd2.sh 自动处理):

```bash
cd test/standalone
python3 run_gcn.py ~/scd/data/pckgnn/BlogCatalog.pt
python3 run_spmm.py ~/scd/data/pckgnn/BlogCatalog.pt 64
python3 run_mm.py 1024 1024 1024
```

## 文件清单

| 文件 | 作用 | 依赖的 HIP 扩展 |
|------|------|----------------|
| `data_stub.py` | PyG Data 对象 stub, 使 torch.load 能反序列化 .pt 文件 | 无 |
| `naive_ref.py` | 纯 torch 参考实现 (SpMM/SDDMM/GCN/GIN), 用于正确性校验 | 无 |
| `_cusp_subprocess.py` | 隔离的 cuSPARSE/hipSPARSE 运行器 (子进程) | KGGNN |
| `run_gcn.py` | GCN 2层前向基准 (KGGNN + 可选 UBG) | KGGNN, UBGGNN (可选) |
| `run_gat.py` | GAT 2层前向基准 (KGGNN + 可选 UBG) | KGGNN, UBGGNN (可选) |
| `run_gin.py` | GIN 2层前向基准 (KGGNN) | KGGNN |
| `run_spmm.py` | SpMM kernel 基准 (KGGNN + GESpMM + cuSPARSE) | KGGNN, GESpMM (可选) |
| `run_sddmm.py` | SDDMM kernel 基准 (KGGNN + cuSPARSE) | KGGNN |
| `run_mm.py` | Dense MM 基准 (torch.mm vs KGGNN) | KGGNN |

## 工作原理

### 数据加载 (`data_stub.py`)

项目原始数据集 (`dataset/Planetoid.py`, `OGB.py`, `AttributedGraph.py`) 使用
PyG 的 `Data(x=, y=, edge_index=)` 构造图对象, 再用 `torch.save` 保存为 `.pt` 文件。
在未安装 PyG 的环境中, `torch.load` 会因找不到 `torch_geometric.data.data.Data`
类而抛 `ModuleNotFoundError`。

`data_stub.py` 通过 `sys.modules` 注入兼容的 `DataStub` / `_StorageStub` 类,
使 `torch.load` 能正常反序列化。stub 类的 `__setstate__` / `__getattr__` 语义
与 PyG 2.0.3 源码一致。若环境已安装真实 PyG, 则不注入 stub, `safe_load`
等价于 `torch.load`。

### 正确性校验 (`naive_ref.py`)

使用 PyTorch 原生算子 (`index_add_`, `repeat_interleave`, `mm`) 实现简单的
参考 SpMM / SDDMM / GCN / GIN 前向传播, 作为 ground truth 与 kernel 输出对比。

- 小图 (< 10 万边): 自动运行 naive 参考并打印 `torch.norm(out_kernel - out_naive)`
- 大图: 跳过 naive 校验 (避免 Python 端 OOM 或过慢), 仅打印输出摘要

### 复用的现有代码

以下模块 **不做修改**, 直接通过 `from lib.* import *` 复用:

- `test/lib/kg_test.py` — KGGNN kernel 调用 (`kg_run_tmp`, `kg_run_kernel`)
- `test/lib/ubg_test.py` — UBG kernel 调用 (`ubg_model_run`)
- `test/lib/ge_test.py` — GESpMM kernel 调用 (`ge_spmm_run`)
- `test/lib/cusparse_test.py` — hipSPARSE 调用 (`cusp_run`)
- `test/utils.py` — CSR 构建 (`graph_to_csr`, 纯 numpy, 不依赖 scipy)
- `test/perf_time.py` — 计时工具

## 缺点与局限

> 以下是相比原始 `test/test_gcn.py` 等测试套件的不足之处。

### 1. 无 DGL/PyG 跨框架正确性对比

原始测试通过 `torch.norm(out_dgl - out_kg)` 将 KGGNN 输出与 DGL 官方实现
逐元素对比, 提供权威的正确性验证。本套件改用纯 torch naive 实现
(`index_add_` / `repeat_interleave`) 作为参考, 仅校验核心 SpMM/SDDMM/MM 算子
的数值一致性。

- **影响**: naive 实现虽然逻辑简单, 但并非框架级权威实现; 若 KGGNN kernel
  与 DGL 在聚合语义上有细微差异 (如自环处理、度归一化顺序), naive 实现可能
  与两者都不完全一致, 导致校验结果仅供启发式参考。
- **缓解**: `naive_ref.py` 的实现严格遵循 KGGNN `kg_test.py` 中的计算流程
  (MM → D^{-1}·SpMM → ReLU → MM → D^{-1}·SpMM → log_softmax), 且使用
  容差 `tol=1e-2` 的相对范数判断。

### 2. GAT 未做数值正确性对比

GAT 的注意力机制涉及 softmax 归一化、LeakyReLU (负斜率 0.2)、按边计算
注意力权重等复杂操作, naive 实现难以精确复现 KGGNN kernel 的每一步。
`run_gat.py` 仅检查输出是否含 NaN/Inf, 不做数值范数对比。

**注意: GAT 在高维特征数据集上的数值溢出**

GAT 注意力得分 `e_ij = LeakyReLU(feat[i]·att_src + feat[j]·att_dst)` 在
高维输入 (如 BlogCatalog `in_dim=8189`) 下量级可达 ±500+, 导致 kernel 内部
`exp(e_ij)` 溢出, softmax 产生 0/0 → NaN。原始 `test_gat.py` 在相同参数下
也会产生 NaN (只是没有显式检查, 会直接打印 `tensor([[nan, nan, ...]])`)。

`run_gat.py` 对输入特征做了 `1/sqrt(in_dim)` 缩放以避免溢出。这会改变数值
结果 (不同于原始测试), 但使 GAT kernel 能正常运行并产生有效的计时数据。
若需要与原始测试完全一致的数值行为, 注释掉 `run_gat.py` 中的 `feat_scale` 行即可。

### 3. GNNAdvisor (GNNA) kernel 未纳入

GNNA 的测试 harness (`GNNAdvisor/dataset.py:5`) 硬依赖 `import dgl`, 且
`custom_dataset2.init_edges` 调用 `dgl.graph()` 构造图对象。在未安装 dgl 的
环境中无法使用。如需测试 GNNA kernel, 需先给 `GNNAdvisor/dataset.py` 去除
dgl 依赖 (不在本套件范围)。

### 4. 仅前向推理计时

与原始 `test_*.py` 一致, 本套件仅测量前向推理 (forward pass) 的 kernel 耗时,
不包含训练精度 / loss / 反向传播。这与项目定位 (kernel 性能基准) 一致,
但不适合需要端到端训练评估的场景。

### 5. `data_stub` 对 .pt 文件格式的假设

stub 假设 `.pt` 文件由 PyG `Data(x=, y=, edge_index=)` 保存 (已核实
`dataset/Planetoid.py`, `OGB.py`, `AttributedGraph.py` 均如此)。

- 若存在非此格式的外部 `.pt` 文件 (如 DGL `DGLGraph` 直接保存), `safe_load`
  无法处理, 需额外适配。
- `DataStub.to(device)` 遍历 `_store._mapping` 移动 tensor, 与 PyG `Data.to`
  语义一致, 但不处理嵌套容器 (list/dict 内的 tensor)。当前数据集无此情况。

### 6. rabbit 重排序为可选项

若 `rabbit` 扩展未编译, 测试自动跳过图重排序 (`reorder=False`)。这会影响
部分 kernel 的缓存局部性优化效果, 导致计时结果与重排序后不同。原始测试中
`reorder=True` 为默认值, 建议尽量编译 rabbit 以获得可比结果。

### 7. cuSPARSE/hipSPARSE 在子进程中运行

KGGNN 的 `CUSPARSE_CHECK` 宏 (`KG_GNN/core/include/utils.h:19`) 在 hipSPARSE
返回错误时调用 C 的 `exit(EXIT_FAILURE)`, 直接终止整个进程。Python 的
`try/except` **无法捕获** C 层的 `exit()`, 会导致整个测试脚本在 cuSPARSE
失败时立即退出, 后续的正确性校验和输出摘要永远不会执行。

为隔离此行为, `run_spmm.py` 和 `run_sddmm.py` 将 cuSPARSE 调用放入
**独立子进程** (`_cusp_subprocess.py`) 中运行:

- 子进程成功: 主进程加载子进程保存的输出 tensor, 继续正确性校验
- 子进程失败 (hipSPARSE `exit()`): 只杀子进程, 主进程打印警告并继续后续测试

**已知问题**: ROCm 4.0.1 的旧版 hipSPARSE `hipsparseScsrmm` API 在某些
数据集上返回 `HIPSPARSE_STATUS_INVALID_VALUE` (错误码 3), 导致 cuSPARSE
基线不可用。这是 hipSPARSE 库本身的兼容性问题, 非 standalone 测试的 bug。
遇到此情况时, KGGNN/GESpMM/naive 的计时和校验仍正常进行。

**子进程开销**: 子进程需重新加载 .pt 数据集并构建 CSR, 有约 1-2 秒的
额外开销。这不影响 cuSPARSE kernel 本身的计时 (计时在子进程内完成)。

## 与原始测试的对应关系

| 原始测试 | 独立测试 | 主要差异 |
|----------|----------|----------|
| `test/test_gcn.py` | `standalone/run_gcn.py` | 去除 DGL/PyG 对比, 加 naive 校验 |
| `test/test_gat.py` | `standalone/run_gat.py` | 去除 DGL/PyG 对比, 仅 NaN/Inf 检查 |
| `test/test_gin.py` | `standalone/run_gin.py` | 去除 DGL/PyG 对比, 加 naive 校验 |
| `test/test_spmm.py` | `standalone/run_spmm.py` | 去除 GNNA/UBG (可选保留 UBG), 加 naive 校验 |
| `test/test_sddmm.py` | `standalone/run_sddmm.py` | 去除 UBG, 加 naive 校验 |
| `test/test_mm.py` | `standalone/run_mm.py` | 去除无用的 import, 可配置矩阵尺寸 |
