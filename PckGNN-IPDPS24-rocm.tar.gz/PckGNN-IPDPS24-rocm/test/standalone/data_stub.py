"""
data_stub.py — PyG Data 对象的轻量 stub, 用于在未安装 torch_geometric 的环境中
加载由 PyG 保存的 .pt 数据集文件。

原理:
    项目原始数据集 (dataset/Planetoid.py, OGB.py, AttributedGraph.py) 使用
    torch_geometric.data.Data(x=, y=, edge_index=) 构造图对象, 再用 torch.save
    保存为 .pt 文件。在未安装 PyG 的超算环境中, torch.load 会因找不到
    torch_geometric.data.data.Data 和 torch_geometric.data.storage.GlobalStorage
    类而抛 ModuleNotFoundError。

    本模块通过 sys.modules 注入兼容的 stub 类, 使 torch.load 能正常反序列化。
    stub 类的 __setstate__ / __getattr__ 语义与 PyG 2.0.3 源码一致:
      - Data.__getstate__() 返回 self.__dict__ = {'_store': GlobalStorage}
      - GlobalStorage.__getstate__() 返回 {'_mapping': {...字段...}, '_parent': ...}

用法:
    from standalone.data_stub import safe_load
    graph_data = safe_load("path/to/dataset.pt")

    # 或手动控制:
    from standalone.data_stub import install_pyg_stub
    install_pyg_stub()      # 注入 stub (仅当真实 PyG 不存在时)
    data = torch.load(path)

    # 若环境已安装真实 PyG, install_pyg_stub 不会覆盖, safe_load 等价于 torch.load。
"""

import sys
import types
import torch

_STUB_INSTALLED = False


class _StorageStub:
    """模拟 torch_geometric.data.storage.GlobalStorage。

    PyG 的 GlobalStorage 继承自 BaseStorage(MutableMapping), 内部用 _mapping
    字典存储所有字段 (x, y, edge_index 等), 用 _parent 弱引用指向父 Data 对象。
    本 stub 简化为普通 dict + 强引用, 足以满足反序列化和属性访问需求。
    """

    def __init__(self, mapping=None):
        self._mapping = dict(mapping) if mapping else {}
        self._parent = None

    def __setstate__(self, state):
        self.__dict__.update(state)

    def __getattr__(self, key):
        if key.startswith('_'):
            raise AttributeError(
                "'{}' object has no attribute '{}'".format(
                    type(self).__name__, key))
        try:
            return self._mapping[key]
        except KeyError:
            raise AttributeError(
                "'{}' object has no attribute '{}'".format(
                    type(self).__name__, key))

    def __setattr__(self, key, value):
        if key.startswith('_'):
            self.__dict__[key] = value
        else:
            self._mapping[key] = value

    def __getitem__(self, key):
        return self._mapping[key]

    def __setitem__(self, key, value):
        if value is None:
            self._mapping.pop(key, None)
        else:
            self._mapping[key] = value

    def __contains__(self, key):
        return key in self._mapping

    def __iter__(self):
        return iter(self._mapping)

    def __len__(self):
        return len(self._mapping)

    def keys(self):
        return self._mapping.keys()

    def values(self):
        return self._mapping.values()

    def items(self):
        return self._mapping.items()


class DataStub:
    """模拟 torch_geometric.data.Data。

    保留 PyG Data 的核心接口:
      - 属性访问: data.x, data.y, data.edge_index (委托给 _store._mapping)
      - num_nodes: 从 x.size(0) 或 edge_index 推断
      - .to(device): 移动所有 tensor 字段到目标设备, 返回 self
      - .to() / .cpu() / .cuda(): 设备转移
    """

    def __init__(self, x=None, edge_index=None, edge_attr=None, y=None,
                 pos=None, **kwargs):
        self.__dict__['_store'] = _StorageStub()
        if x is not None:
            self.x = x
        if edge_index is not None:
            self.edge_index = edge_index
        if edge_attr is not None:
            self.edge_attr = edge_attr
        if y is not None:
            self.y = y
        if pos is not None:
            self.pos = pos
        for key, value in kwargs.items():
            setattr(self, key, value)

    def __getattr__(self, key):
        if key == '_store':
            raise AttributeError(key)
        store = self.__dict__.get('_store')
        if store is None:
            raise AttributeError(
                "'DataStub' object has no attribute '{}'".format(key))
        return getattr(store, key)

    def __setattr__(self, key, value):
        store = self.__dict__.get('_store')
        if store is not None and not key.startswith('_'):
            store._mapping[key] = value
        else:
            self.__dict__[key] = value

    def __setstate__(self, state):
        self.__dict__.update(state)

    @property
    def num_nodes(self):
        store = self.__dict__.get('_store')
        if store is None:
            return None
        mapping = store._mapping
        if 'num_nodes' in mapping and mapping['num_nodes'] is not None:
            return int(mapping['num_nodes'])
        if 'x' in mapping and mapping['x'] is not None:
            return mapping['x'].size(0)
        if 'pos' in mapping and mapping['pos'] is not None:
            return mapping['pos'].size(0)
        if 'edge_index' in mapping and mapping['edge_index'] is not None:
            return int(mapping['edge_index'].max().item()) + 1
        return None

    def to(self, device, **kwargs):
        store = self.__dict__.get('_store')
        if store is not None:
            for key, value in list(store._mapping.items()):
                if isinstance(value, torch.Tensor):
                    store._mapping[key] = value.to(device, **kwargs)
        return self

    def cpu(self):
        return self.to('cpu')

    def cuda(self, device=None, **kwargs):
        if device is None:
            device = 'cuda'
        return self.to(device, **kwargs)

    def keys(self):
        store = self.__dict__.get('_store')
        if store is not None:
            return store._mapping.keys()
        return []

    def __repr__(self):
        store = self.__dict__.get('_store')
        if store is not None:
            attrs = ', '.join(
                '{}={}'.format(k, repr(v)[:20])
                for k, v in store._mapping.items())
            return 'DataStub({})'.format(attrs)
        return 'DataStub()'


def install_pyg_stub():
    """注入 PyG stub 类到 sys.modules, 使 torch.load 能反序列化 .pt 文件。

    仅当真实 torch_geometric 不可用时才注入; 若已安装 PyG 则不做任何操作。
    多次调用安全 (幂等)。
    """
    global _STUB_INSTALLED

    if _STUB_INSTALLED:
        return

    try:
        import torch_geometric
        return
    except Exception:
        pass

    pkg = types.ModuleType('torch_geometric')
    data_pkg = types.ModuleType('torch_geometric.data')
    data_mod = types.ModuleType('torch_geometric.data.data')
    storage_mod = types.ModuleType('torch_geometric.data.storage')

    data_mod.Data = DataStub
    storage_mod.GlobalStorage = _StorageStub
    storage_mod.BaseStorage = _StorageStub
    storage_mod.NodeStorage = _StorageStub
    storage_mod.EdgeStorage = _StorageStub
    storage_mod.BaseData = DataStub

    data_pkg.Data = DataStub
    data_pkg.data = data_mod
    data_pkg.storage = storage_mod

    pkg.data = data_pkg
    pkg.__path__ = []

    sys.modules['torch_geometric'] = pkg
    sys.modules['torch_geometric.data'] = data_pkg
    sys.modules['torch_geometric.data.data'] = data_mod
    sys.modules['torch_geometric.data.storage'] = storage_mod

    _STUB_INSTALLED = True


def safe_load(path):
    """加载 .pt 数据集文件, 自动注入 PyG stub (若需要)。

    Args:
        path: .pt 文件路径 (由 torch_geometric.data.Data 保存)

    Returns:
        DataStub 或 真实 PyG Data 对象
    """
    install_pyg_stub()
    return torch.load(path)
