"""
run_gat.py — 独立 GAT 基准测试 (不依赖 DGL/PyG)

用法:
    python3 run_gat.py <dataset.pt> [outcsv_name]

或通过 cmd2.sh:
    bash cmd2.sh st-gat <dataset.pt> [outcsv_name]

测试内容:
    - KGGNN GAT 2层前向 (balance=1, balance=2)
    - 可选: UBG GAT (若 UBGGNN .so 已构建)
    - 输出非 NaN/Inf 检查 (GAT 注意力机制复杂, 不做数值对比)
"""

import sys
import os
from pathlib import Path

_TEST_DIR = str(Path(__file__).resolve().parent.parent)
if _TEST_DIR not in sys.path:
    sys.path.insert(0, _TEST_DIR)

import torch
import numpy as np

from standalone.data_stub import safe_load
from load_dataset import dataset_load, dataset_prop
from lib.kg_test import kg_run_tmp
from perf_time import perf_time_init, perf_time_start, perf_time_end, perf_time_tofile
import utils

try:
    import rabbit
    HAS_RABBIT = True
except ImportError:
    HAS_RABBIT = False
    print("Warning: rabbit extension not built. Reordering will be disabled.")

try:
    from lib.ubg_test import ubg_model_run
    HAS_UBG = True
except Exception:
    HAS_UBG = False
    print("Warning: UBGGNN not available. UBG baseline will be skipped.")

os.environ.setdefault("CUDA_VISIBLE_DEVICES", '0')

USAGE = "Usage: python3 run_gat.py <dataset.pt> [outcsv_name]"


def main():
    if len(sys.argv) < 2 or len(sys.argv) > 3:
        print(USAGE)
        sys.exit(1)

    dataset_dir = sys.argv[1]
    outcsv_name = sys.argv[2] if len(sys.argv) == 3 else None

    gcn_hidden = 32
    out_dim = 32

    graph_data = safe_load(dataset_dir)
    in_dim, _ = dataset_prop(graph_data)

    print("dataset:", dataset_dir, "layers:", in_dim, gcn_hidden, out_dim)

    random_seed = 123
    torch.manual_seed(random_seed)
    weight0 = torch.randn(in_dim, gcn_hidden)
    weight1 = torch.randn(gcn_hidden, out_dim)
    att_src0 = torch.randn(1, 1, gcn_hidden)
    att_dst0 = torch.randn(1, 1, gcn_hidden)
    att_src1 = torch.randn(1, 1, out_dim)
    att_dst1 = torch.randn(1, 1, out_dim)
    bias0 = torch.randn(gcn_hidden)
    bias1 = torch.randn(out_dim)
    paras = {
        'w0': weight0, 'w1': weight1, 'b0': bias0, 'b1': bias1,
        'as0': att_src0, 'ad0': att_dst0, 'as1': att_src1, 'ad1': att_dst1,
    }

    input_feature = torch.randn(graph_data.num_nodes, in_dim)
    # Scale features by 1/sqrt(in_dim) to prevent GAT attention overflow
    # on high-dimensional datasets (e.g. BlogCatalog in_dim=8189).
    # Without this, exp(e_ij) in softmax overflows -> NaN.
    feat_scale = 1.0 / (in_dim ** 0.5)
    input_feature = input_feature * feat_scale
    print("  feature scale: 1/sqrt(in_dim) = {:.6f}".format(feat_scale))

    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    graph_data = graph_data.to(device)
    input_feature = input_feature.to(device)
    print("device:", device)

    perf_time_init(dataset_dir)

    reorder = HAS_RABBIT
    graph_csr = utils.graph_to_csr(graph_data, reorder=reorder)

    # ---- KGGNN GAT: balance=1 ----
    print("\n=== KGGNN GAT (balance=1) ===")
    out_kg1, _ = kg_run_tmp(
        graph_csr, input_feature, in_dim, gcn_hidden, out_dim, device,
        balance=1, paras=paras, detail_test=0, reorder=False,
        time_label='KG balance1', name='GAT')

    out_kg1, _ = kg_run_tmp(
        graph_csr, input_feature, in_dim, gcn_hidden, out_dim, device,
        balance=1, paras=paras, detail_test=2, reorder=False,
        time_label='KG balance1', name='GAT')

    # ---- KGGNN GAT: balance=2 ----
    print("\n=== KGGNN GAT (balance=2) ===")
    out_kg2, _ = kg_run_tmp(
        graph_csr, input_feature, in_dim, gcn_hidden, out_dim, device,
        balance=2, paras=paras, detail_test=0, reorder=False,
        time_label='KG balance2', name='GAT')

    out_kg2, _ = kg_run_tmp(
        graph_csr, input_feature, in_dim, gcn_hidden, out_dim, device,
        balance=2, paras=paras, detail_test=2, reorder=False,
        time_label='KG balance2', name='GAT')

    # ---- UBG GAT (可选) ----
    if HAS_UBG:
        print("\n=== UBG GAT ===")
        try:
            out_ubg, _ = ubg_model_run(
                "GAT", graph_csr, in_dim, gcn_hidden, out_dim,
                input_feature, device, paras=paras, detail_test=2)
        except Exception as e:
            print("  UBG GAT failed: {}".format(e))
            out_ubg = None
    else:
        out_ubg = None

    # ---- 正确性检查 (NaN/Inf) ----
    print("\n=== Sanity Check ===")
    for name, out in [("KGGNN balance1", out_kg1),
                       ("KGGNN balance2", out_kg2),
                       ("UBG", out_ubg)]:
        if out is None:
            print("  {}: skipped (None)".format(name))
            continue
        has_nan = torch.isnan(out).any().item()
        has_inf = torch.isinf(out).any().item()
        tag = "OK" if not (has_nan or has_inf) else "BAD"
        print("  {} -- {}  shape={}  norm={:.6f}  has_nan={}  has_inf={}".format(
            name, tag, out.shape, torch.norm(out).item(), has_nan, has_inf))

    # ---- 输出摘要 ----
    print("\n=== Output Summary ===")
    print("  KGGNN balance1: shape={}, norm={:.6f}".format(
        out_kg1.shape, torch.norm(out_kg1).item()))
    print("  KGGNN balance2: shape={}, norm={:.6f}".format(
        out_kg2.shape, torch.norm(out_kg2).item()))

    if outcsv_name:
        perf_time_tofile(outcsv_name)


if __name__ == "__main__":
    main()
