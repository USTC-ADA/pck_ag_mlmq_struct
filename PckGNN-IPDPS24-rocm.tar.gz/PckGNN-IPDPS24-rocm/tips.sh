#!/bin/bash
# ============================================================
# tips.sh — 全面 import 检查 (gcn / gat / gin / spmm / sddmm / mm)
#
# 逐一验证六个测试的所有 import, 报告哪些成功 / 哪些失效。
# 不会修改任何文件, 不会 export 污染全局环境。
#
# 用法 (在超算项目根目录下执行):
#   bash tips.sh
# ============================================================
set -e

PROJ_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "${PROJ_DIR}"

# -- 颜色定义 --
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

PASS="${GREEN}[PASS]${NC}"
FAIL="${RED}[FAIL]${NC}"
WARN="${YELLOW}[WARN]${NC}"

# 计数
TOTAL=0
PASS_COUNT=0
FAIL_COUNT=0
WARN_COUNT=0

# -- 构建 PYTHONPATH (仅作为局部变量, 不 export) --
_build_pythonpath() {
    local pybuild_plat pyver build_lib
    pybuild_plat=$(python3 -c "import sysconfig; print(sysconfig.get_platform())" 2>/dev/null || echo "linux-x86_64")
    pyver=$(python3 -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')" 2>/dev/null || echo "3.6")
    build_lib="lib.${pybuild_plat}-${pyver}"

    _PYTHONPATH="${PROJ_DIR}/pkgs"
    _PYTHONPATH+=":${PROJ_DIR}"
    _PYTHONPATH+=":${PROJ_DIR}/GNNAdvisor"
    _PYTHONPATH+=":${PROJ_DIR}/GNNAdvisor/GNNConv"
    _PYTHONPATH+=":${PROJ_DIR}/GNNAdvisor/GNNConv/build/${build_lib}"
    _PYTHONPATH+=":${PROJ_DIR}/KG_GNN"
    _PYTHONPATH+=":${PROJ_DIR}/KG_GNN/core"
    _PYTHONPATH+=":${PROJ_DIR}/KG_GNN/core/build/${build_lib}"
    _PYTHONPATH+=":${PROJ_DIR}/UBG"
    _PYTHONPATH+=":${PROJ_DIR}/UBG/build/${build_lib}"
    _PYTHONPATH+=":${PROJ_DIR}/dgSPARSE/example/ge-spmm"
    _PYTHONPATH+=":${PROJ_DIR}/dgSPARSE/example/ge-spmm/build/${build_lib}"
    _PYTHONPATH+=":${PROJ_DIR}/rabbit_module"
    _PYTHONPATH+=":${PROJ_DIR}/rabbit_module/src"
    _PYTHONPATH+=":${PROJ_DIR}/rabbit_module/src/build/${build_lib}"
    _PYTHONPATH+=":${PROJ_DIR}/test"
    _PYTHONPATH+=":${PROJ_DIR}/test/lib"
    if [ -n "${PYTHONPATH}" ]; then
        _PYTHONPATH+=":${PYTHONPATH}"
    fi
}

# -- 运行 python3, 仅在本次调用中设置 PYTHONPATH (不污染父 shell) --
_run_py() {
    PYTHONPATH="${_PYTHONPATH}" python3 "$@"
}

# -- 辅助函数 --
check_import() {
    # $1 = 模块名 (用于 import 语句)
    # $2 = 描述
    # $3 = required / optional
    local mod="$1"
    local desc="$2"
    local required="${3:-required}"

    TOTAL=$((TOTAL + 1))
    printf "  %-45s " "${desc}"

    local result rc
    result=$(_run_py -c "import ${mod}" 2>&1)
    rc=$?

    if [ $rc -eq 0 ]; then
        echo -e "${PASS}"
        PASS_COUNT=$((PASS_COUNT + 1))
    elif [ "${required}" = "optional" ]; then
        echo -e "${WARN} (optional)"
        WARN_COUNT=$((WARN_COUNT + 1))
    else
        echo -e "${FAIL}"
        echo "                                    └─ ${result}" >&2
        FAIL_COUNT=$((FAIL_COUNT + 1))
    fi
}

check_import_statement() {
    # $1 = 完整 import 语句 (如 "from lib.kg_test import *")
    # $2 = 描述
    # $3 = required / optional
    local stmt="$1"
    local desc="$2"
    local required="${3:-required}"

    TOTAL=$((TOTAL + 1))
    printf "  %-45s " "${desc}"

    local result rc
    result=$(_run_py -c "${stmt}" 2>&1)
    rc=$?

    if [ $rc -eq 0 ]; then
        echo -e "${PASS}"
        PASS_COUNT=$((PASS_COUNT + 1))
    elif [ "${required}" = "optional" ]; then
        echo -e "${WARN} (optional)"
        WARN_COUNT=$((WARN_COUNT + 1))
    else
        echo -e "${FAIL}"
        echo "                                    └─ ${result}" >&2
        FAIL_COUNT=$((FAIL_COUNT + 1))
    fi
}

# ============================================================
# Phase 1: 环境概览
# ============================================================
show_env() {
    echo "=== Phase 1: 环境概览 ==="
    echo ""
    echo "  Project:  ${PROJ_DIR}"
    echo "  Python:   $(python3 --version 2>&1)"
    echo "  torch:    $(python3 -c 'import torch; print(torch.__version__)' 2>/dev/null || echo 'NOT FOUND')"
    echo "  hipcc:    $(which hipcc 2>/dev/null || echo 'NOT FOUND')"
    echo ""
}

# ============================================================
# Phase 2: 基础 Python 环境检查
# ============================================================
check_basic_env() {
    echo "=== Phase 2: 基础 Python 环境检查 ==="
    echo ""

    check_import "torch"                    "torch (PyTorch)"
    check_import "torch.nn"                 "torch.nn"
    check_import "torch.nn.functional"      "torch.nn.functional"
    check_import "numpy"                    "numpy"
    check_import "sys"                      "sys (stdlib)"
    check_import "time"                     "time (stdlib)"
    check_import "os"                       "os (stdlib)"
    check_import "csv"                      "csv (stdlib)"
    check_import "pathlib"                  "pathlib (stdlib)"
    check_import "ctypes"                   "ctypes (stdlib)"
    check_import "math"                     "math (stdlib)"

    echo ""
}

# ============================================================
# Phase 3: C 扩展 (.so) 检查
# ============================================================
check_extensions() {
    echo "=== Phase 3: C 扩展 (.so) 检查 ==="
    echo ""

    check_import "rabbit"                   "rabbit (CPU reorder)"
    check_import "GNNAdvisor"              "GNNAdvisor (HIP)"
    check_import "KGGNN"                   "KGGNN (HIP)"
    check_import "UBGGNN"                  "UBGGNN (HIP)"
    check_import "GESpMM"                  "GESpMM (HIP)"

    echo ""
}

# ============================================================
# Phase 4: test/ 目录内的 Python 模块
# ============================================================
check_test_modules() {
    echo "=== Phase 4: test/ 目录内模块检查 ==="
    echo ""

    check_import "load_dataset"             "load_dataset.py"
    check_import "utils"                    "utils.py"
    check_import "perf_time"                "perf_time.py"

    echo ""
}

# ============================================================
# Phase 5: test/lib/ 子模块检查
# ============================================================
check_lib_modules() {
    echo "=== Phase 5: test/lib/ 子模块检查 ==="
    echo ""

    # ---- 5a. lib.dgl_test (依赖 dgl) ----
    echo "--- lib.dgl_test (需 dgl) ---"
    check_import "dgl"                      "  dgl (第三方库)" "optional"
    check_import_statement "from lib.dgl_test import *" \
                                            "  lib.dgl_test" "optional"

    # ---- 5b. lib.pyg_test (依赖 torch_geometric) ----
    echo "--- lib.pyg_test (需 torch_geometric) ---"
    check_import "torch_geometric"          "  torch_geometric (stub)" "optional"
    check_import_statement "from torch_geometric.nn import GCNConv, GATConv, GINConv" \
                                            "  torch_geometric.nn" "optional"
    check_import_statement "from lib.pyg_test import *" \
                                            "  lib.pyg_test" "optional"

    # ---- 5c. lib.gnna_test (依赖 GNNAdvisor .so) ----
    echo "--- lib.gnna_test (需 GNNAdvisor .so) ---"
    if _run_py -c "import GNNAdvisor" 2>/dev/null; then
        check_import_statement "from lib.gnna_test import *" \
                                            "  lib.gnna_test"
    else
        check_import_statement "from lib.gnna_test import *" \
                                            "  lib.gnna_test (GNNAdvisor 未构建)" "optional"
    fi

    # ---- 5d. lib.ubg_test (依赖 UBGGNN .so) ----
    echo "--- lib.ubg_test (需 UBGGNN .so) ---"
    if _run_py -c "import UBGGNN" 2>/dev/null; then
        check_import_statement "from lib.ubg_test import *" \
                                            "  lib.ubg_test"
    else
        check_import_statement "from lib.ubg_test import *" \
                                            "  lib.ubg_test (UBGGNN 未构建)" "optional"
    fi

    # ---- 5e. lib.kg_test (依赖 KGGNN .so) ----
    echo "--- lib.kg_test (需 KGGNN .so) ---"
    if _run_py -c "import KGGNN" 2>/dev/null; then
        check_import_statement "from lib.kg_test import *" \
                                            "  lib.kg_test"
    else
        check_import_statement "from lib.kg_test import *" \
                                            "  lib.kg_test (KGGNN 未构建)" "optional"
    fi

    # ---- 5f. lib.ge_test (依赖 GESpMM .so) ----
    echo "--- lib.ge_test (需 GESpMM .so) ---"
    if _run_py -c "import GESpMM" 2>/dev/null; then
        check_import_statement "from lib.ge_test import *" \
                                            "  lib.ge_test"
    else
        check_import_statement "from lib.ge_test import *" \
                                            "  lib.ge_test (GESpMM 未构建)" "optional"
    fi

    # ---- 5g. lib.cusparse_test (依赖 KGGNN .so) ----
    echo "--- lib.cusparse_test (需 KGGNN .so) ---"
    if _run_py -c "import KGGNN" 2>/dev/null; then
        check_import_statement "from lib.cusparse_test import *" \
                                            "  lib.cusparse_test"
    else
        check_import_statement "from lib.cusparse_test import *" \
                                            "  lib.cusparse_test (KGGNN 未构建)" "optional"
    fi

    echo ""
}

# ============================================================
# Phase 6: 按测试文件汇总
# ============================================================
check_per_test() {
    echo "=== Phase 6: 按测试文件汇总 ==="
    echo ""

    # 格式: "import_statement|描述|required"

    # ---- GCN ----
    local -a GCN_IMPORTS=(
        "import torch|torch|required"
        "import torch.nn.functional|torch.nn.functional|required"
        "from load_dataset import *|load_dataset|required"
        "from lib.gnna_test import *|lib.gnna_test|required"
        "from lib.ubg_test import *|lib.ubg_test|required"
        "from lib.kg_test import *|lib.kg_test|required"
        "import utils|utils|required"
        "from perf_time import *|perf_time|required"
        "import rabbit|rabbit|required"
        "from lib.dgl_test import *|lib.dgl_test|optional"
        "from lib.pyg_test import *|lib.pyg_test|optional"
    )

    # ---- GAT ----
    local -a GAT_IMPORTS=(
        "import torch|torch|required"
        "import torch.nn.functional|torch.nn.functional|required"
        "from load_dataset import *|load_dataset|required"
        "from lib.ubg_test import *|lib.ubg_test|required"
        "from lib.kg_test import *|lib.kg_test|required"
        "import utils|utils|required"
        "from perf_time import *|perf_time|required"
        "import rabbit|rabbit|required"
        "from lib.dgl_test import *|lib.dgl_test|optional"
        "from lib.pyg_test import *|lib.pyg_test|optional"
    )

    # ---- GIN ----
    local -a GIN_IMPORTS=(
        "import torch|torch|required"
        "import torch.nn.functional|torch.nn.functional|required"
        "from load_dataset import *|load_dataset|required"
        "from lib.gnna_test import *|lib.gnna_test|required"
        "from lib.kg_test import *|lib.kg_test|required"
        "import utils|utils|required"
        "from perf_time import *|perf_time|required"
        "import rabbit|rabbit|required"
        "from lib.dgl_test import *|lib.dgl_test|optional"
        "from lib.pyg_test import *|lib.pyg_test|optional"
    )

    # ---- SpMM ----
    local -a SPMM_IMPORTS=(
        "import torch|torch|required"
        "from load_dataset import *|load_dataset|required"
        "from lib.gnna_test import *|lib.gnna_test|required"
        "from lib.ubg_test import *|lib.ubg_test|required"
        "from lib.kg_test import *|lib.kg_test|required"
        "from lib.ge_test import *|lib.ge_test|required"
        "import utils|utils|required"
        "from perf_time import *|perf_time|required"
        "import rabbit|rabbit|required"
        "import csv|csv|required"
        "from lib.dgl_test import *|lib.dgl_test|optional"
        "from lib.pyg_test import *|lib.pyg_test|optional"
    )

    # ---- SDDMM ----
    local -a SDDMM_IMPORTS=(
        "import torch|torch|required"
        "from load_dataset import *|load_dataset|required"
        "from lib.gnna_test import *|lib.gnna_test|required"
        "from lib.ubg_test import *|lib.ubg_test|required"
        "from lib.kg_test import *|lib.kg_test|required"
        "from lib.ge_test import *|lib.ge_test|required"
        "from lib.cusparse_test import *|lib.cusparse_test|required"
        "import utils|utils|required"
        "from perf_time import *|perf_time|required"
        "import rabbit|rabbit|required"
        "import csv|csv|required"
        "from lib.dgl_test import *|lib.dgl_test|optional"
        "from lib.pyg_test import *|lib.pyg_test|optional"
    )

    # ---- MM ----
    local -a MM_IMPORTS=(
        "import torch|torch|required"
        "import torch.nn.functional|torch.nn.functional|required"
        "from load_dataset import *|load_dataset|required"
        "import numpy as np|numpy|required"
        "import utils|utils|required"
        "from perf_time import *|perf_time|required"
        "import rabbit|rabbit|required"
        "import KGGNN|KGGNN (直接 import)|optional"
    )

    local test_name
    for test_name in "GCN" "GAT" "GIN" "SpMM" "SDDMM" "MM"; do
        echo ""
        echo -e "${BLUE}━━━ ${test_name} 测试 ━━━${NC}"

        local -n imports="${test_name}_IMPORTS"
        local test_fail=0

        local entry stmt desc req result rc
        for entry in "${imports[@]}"; do
            IFS='|' read -r stmt desc req <<< "${entry}"

            TOTAL=$((TOTAL + 1))
            printf "  %-45s " "${desc}"

            result=$(_run_py -c "${stmt}" 2>&1)
            rc=$?

            if [ $rc -eq 0 ]; then
                echo -e "${PASS}"
                PASS_COUNT=$((PASS_COUNT + 1))
            elif [ "${req}" = "optional" ]; then
                echo -e "${WARN} (optional)"
                WARN_COUNT=$((WARN_COUNT + 1))
            else
                echo -e "${FAIL}"
                echo "                                    └─ ${result}" >&2
                FAIL_COUNT=$((FAIL_COUNT + 1))
                test_fail=1
            fi
        done

        if [ $test_fail -eq 0 ]; then
            echo -e "  ${GREEN}→ ${test_name}: 所有必需 import 通过${NC}"
        else
            echo -e "  ${RED}→ ${test_name}: 存在必需 import 失败!${NC}"
        fi
    done

    echo ""
}

# ============================================================
# 汇总报告
# ============================================================
print_summary() {
    echo "============================================"
    echo "           Import 检查汇总报告"
    echo "============================================"
    echo ""
    echo -e "  总计检查: ${TOTAL}"
    echo -e "  通过:     ${PASS_COUNT} ${GREEN}✓${NC}"
    echo -e "  失败:     ${FAIL_COUNT} ${RED}✗${NC}"
    echo -e "  警告:     ${WARN_COUNT} ${YELLOW}△${NC} (optional)"
    echo ""
    if [ $FAIL_COUNT -gt 0 ]; then
        echo -e "  ${RED}存在 ${FAIL_COUNT} 个必需 import 失败, 请检查上述错误信息!${NC}"
        echo ""
        echo "  常见解决方法:"
        echo "    1. 检查 .so 文件是否已构建: bash cmd2.sh build"
        echo "    2. 检查 ROCm / PyTorch 模块是否正确加载"
        echo "    3. 确认当前目录为项目根目录: cd ${PROJ_DIR}"
    else
        echo -e "  ${GREEN}所有必需 import 均通过! 可以运行测试。${NC}"
    fi
    echo ""
    echo "============================================"
}

# ============================================================
# Main
# ============================================================
_build_pythonpath
show_env
check_basic_env
check_extensions
check_test_modules
check_lib_modules
check_per_test
print_summary
