#!/bin/bash
# ============================================================
# PckGNN ROCm/HIP Build and Test Commands (setup.py version)
# Target environment: compiler/rocm/4.0.1 + PyTorch 1.10.1
#
# This script replaces Makefile-based compilation with setup.py
# for each module. All extensions are built in-place (no global
# path changes), and PYTHONPATH is set to ensure all imports
# resolve within the project directory.
#
# Usage:
#   bash cmd2.sh build              -- build all extensions via setup.py
#   bash cmd2.sh build-rabbit       -- build only rabbit extension
#   bash cmd2.sh build-gnna         -- build only GNNAdvisor extension
#   bash cmd2.sh build-kggnn        -- build only KGGNN extension
#   bash cmd2.sh build-ubg          -- build only UBGGNN extension
#   bash cmd2.sh build-gespmm       -- build only GESpMM extension
#   bash cmd2.sh clean              -- clean all build artifacts
#   bash cmd2.sh test-gcn    <dataset> [outcsv]
#   bash cmd2.sh test-gat    <dataset> [outcsv]
#   bash cmd2.sh test-gin    <dataset> [outcsv]
#   bash cmd2.sh test-spmm   <dataset> <in_dim> [outcsv]
#   bash cmd2.sh test-sddmm  <dataset> <in_dim> [outcsv]
#   bash cmd2.sh test-mm
#   bash cmd2.sh info               -- show environment info
# ============================================================

set -e
set -o pipefail

# -- Locale: prefer UTF-8 to avoid UnicodeEncodeError in Python scripts --
#    The C locale forces ASCII encoding, which breaks import_check.py's Chinese
#    output.  Fall back to C only if no UTF-8 locale is available.
_utf8_locale=""
for _try in en_US.UTF-8 en_US.utf8 C.UTF-8 C.utf8; do
    if locale -a 2>/dev/null | grep -qi "^${_try}$"; then
        _utf8_locale="${_try}"
        break
    fi
done
if [ -n "${_utf8_locale}" ]; then
    export LC_ALL="${_utf8_locale}"
    export LANG="${_utf8_locale}"
else
    export LC_ALL=C
    export LANG=C
fi

# -- Project root directory --
PROJ_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "${PROJ_DIR}"

# -- GPU Architecture --
export AMDGPU_TARGET="${AMDGPU_TARGET:-gfx906}"

# Restrict PyTorch cpp_extension to only compile for the target GPU architecture.
# Without this, PyTorch auto-detects all ROCm-supported architectures (which may
# include unsupported targets like gfx803/gfx900) and hipcc fails.
export PYTORCH_ROCM_ARCH="${AMDGPU_TARGET}"
export TORCH_CUDA_ARCH_LIST="${AMDGPU_TARGET}"

# -- Fix polluted ROCM_PATH (PyTorch module appends DTK path) --
export ROCM_PATH="${ROCM_PATH%%:*}"

# -- Fix non-standard ROCm layout: hipcc may be in $ROCM_PATH/hip/bin/ --
#    PyTorch's cpp_extension hardcodes $ROCM_PATH/bin/hipcc, but some cluster
#    installations put hipcc under $ROCM_PATH/hip/bin/.  We detect this and
#    try to create the expected symlink in situ.
_fix_rocm_hipcc() {
    local _rocm="${ROCM_PATH%%:*}"
    # Standard layout — nothing to do
    [ -x "${_rocm}/bin/hipcc" ] && return 0
    # Not a non-standard layout either
    [ -x "${_rocm}/hip/bin/hipcc" ] || return 0

    echo "[cmd2.sh] Non-standard ROCm layout detected (hipcc in hip/bin/)"

    # Strategy A: create $ROCM_PATH/bin/hipcc → ../hip/bin/hipcc  (cleanest,
    # requires write permission on the ROCm install tree)
    if mkdir -p "${_rocm}/bin" 2>/dev/null; then
        ln -sf "${_rocm}/hip/bin/hipcc"     "${_rocm}/bin/hipcc"     2>/dev/null || true
        ln -sf "${_rocm}/hip/bin/hipconfig" "${_rocm}/bin/hipconfig" 2>/dev/null || true
    fi
    [ -x "${_rocm}/bin/hipcc" ] && { echo "[cmd2.sh]   created ${_rocm}/bin/hipcc"; return 0; }

    # Strategy B: can't write to ROCm tree — fall back to a full-tree symlink
    # wrapper under the project build directory.
    local _wrap="${PROJ_DIR}/build/rocm-wrap"
    rm -rf "${_wrap}"
    mkdir -p "${_wrap}/bin"

    # hipcc / hipconfig — these live in a non-standard spot
    ln -sf "${_rocm}/hip/bin/hipcc"     "${_wrap}/bin/hipcc"
    ln -sf "${_rocm}/hip/bin/hipconfig" "${_wrap}/bin/hipconfig" 2>/dev/null || true

    # Also symlink every other tool from hip/bin/ into bin/ so that hipcc
    # can find extractkernel, hipdemangle, etc. when it references $ROCM_PATH/bin
    local _name
    for _tool in "${_rocm}/hip/bin/"*; do
        [ -f "${_tool}" ] || continue
        _name="$(basename "${_tool}")"
        [ "${_name}" = hipcc ] || [ "${_name}" = hipconfig ] && continue
        ln -sf "${_tool}" "${_wrap}/bin/${_name}" 2>/dev/null || true
    done

    # Symlink ALL top-level directories from the original ROCm root into the
    # wrap so that hipcc and its child clang++ can find everything they need
    # (--rocm-path is set to the wrap, so clang++ looks here for device
    # libraries in amdgcn/bitcode/, headers in include/, etc.).
    # We skip "bin" because we already populated it with hipcc symlinks above.
    for _dir in "${_rocm}"/*/; do
        [ -d "${_dir}" ] || continue
        _name="$(basename "${_dir}")"
        [ "${_name}" = bin ] && continue
        ln -sfn "${_rocm}/${_name}" "${_wrap}/${_name}" 2>/dev/null || true
    done

    export ROCM_PATH="${_wrap}"
    echo "[cmd2.sh]   using local rocm-wrap at ${_wrap}"
}
_fix_rocm_hipcc

export HIP_CLANG_PATH="${ROCM_PATH}/llvm/bin"

# -- Fix non-standard ROCm layout: HIP runtime libraries (libamdhip64.so, etc.)
#    may be in $ROCM_PATH/hip/lib/ rather than $ROCM_PATH/lib/.
#    PyTorch cpp_extension only adds -L$ROCM_PATH/lib, so the g++ linker
#    cannot find libamdhip64.  LIBRARY_PATH is respected by g++/ld.
export LIBRARY_PATH="${ROCM_PATH}/hip/lib:${ROCM_PATH}/lib:${LIBRARY_PATH}"

# -- Fix non-standard ROCm layout: HIP/HSA headers (hip_runtime_api.h, etc.)
#    may be under $ROCM_PATH/hip/include/ rather than $ROCM_PATH/include/.
#    hipcc adds these automatically, but gcc/g++ compiling .cpp files does not.
#    CPATH is searched by gcc/g++ after command-line -I flags.
export CPATH="${ROCM_PATH}/hip/include:${ROCM_PATH}/hsa/include:${CPATH}"

# -- Build and test log files --
BUILD_LOG="${PROJ_DIR}/build.log"

# -- Compute the build output subdirectory (e.g., lib.linux-x86_64-3.6) --
#    build_ext --inplace should copy .so files to the source directory,
#    but on some platforms the copy silently fails (zero-length destination).
#    Adding the build/lib.*/ directories as a fallback ensures imports work
#    regardless of whether the in-place copy succeeded.
PYBUILD_PLAT=$(python3 -c "import sysconfig; print(sysconfig.get_platform())" 2>/dev/null || echo "linux-x86_64")
PYVER=$(python3 -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')" 2>/dev/null || echo "3.6")
BUILD_LIB="lib.${PYBUILD_PLAT}-${PYVER}"

# -- PYTHONPATH: include all module directories so imports resolve --
#    This is the key to avoiding "import GNNAdvisor" failures.
#    Each extension .so is built in-place alongside its setup.py.
#    pkgs/ contains third-party packages installed with pip --target,
#    so they are project-local and never pollute the global environment.
export PYTHONPATH="${PROJ_DIR}/pkgs"\
":${PROJ_DIR}"\
":${PROJ_DIR}/GNNAdvisor"\
":${PROJ_DIR}/GNNAdvisor/GNNConv"\
":${PROJ_DIR}/GNNAdvisor/GNNConv/build/${BUILD_LIB}"\
":${PROJ_DIR}/KG_GNN"\
":${PROJ_DIR}/KG_GNN/core"\
":${PROJ_DIR}/KG_GNN/core/build/${BUILD_LIB}"\
":${PROJ_DIR}/UBG"\
":${PROJ_DIR}/UBG/build/${BUILD_LIB}"\
":${PROJ_DIR}/dgSPARSE/example/ge-spmm"\
":${PROJ_DIR}/dgSPARSE/example/ge-spmm/build/${BUILD_LIB}"\
":${PROJ_DIR}/rabbit_module"\
":${PROJ_DIR}/rabbit_module/src"\
":${PROJ_DIR}/rabbit_module/src/build/${BUILD_LIB}"\
":${PROJ_DIR}/test"\
":${PROJ_DIR}/test/lib"\
":${PYTHONPATH}"

# ============================================================
# Logging helpers
# ============================================================
log() {
    grep -v -E '(perl: warning|/bin/bash: warning|sh: warning|perl: warning: Please|LANGUAGE =|LC_ALL =|LC_CTYPE =|LANG =|are supported and installed|perl: warning: Falling back|warning: setlocale)' || true
}

log_ts() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*" | tee -a "${BUILD_LOG}"
}

# ============================================================
# Build: rabbit (CPU-only, no ROCm needed)
# ============================================================
build_rabbit() {
    log_ts "=== Building rabbit extension (CPU-only) ==="
    cd "${PROJ_DIR}/rabbit_module/src"

    # Clean previous build artifacts
    rm -rf build/ dist/ *.egg-info/ rabbit.so rabbit.cpython-*.so

    # Try with tcmalloc_minimal first, fall back without it
    if python3 setup.py build_ext --inplace 2>&1 | tee -a "${BUILD_LOG}"; then
        log_ts "rabbit extension built successfully."
    else
        log_ts "rabbit build with tcmalloc_minimal failed, trying without..."
        # Patch setup.py to remove tcmalloc_minimal dependency
        python3 -c "
import re
with open('setup.py','r') as f: content = f.read()
content = content.replace('\"tcmalloc_minimal\"','')
content = re.sub(r'libraries=\[\"numa\"\s*,\s*\]', 'libraries=[\"numa\"]', content)
with open('setup.py','w') as f: f.write(content)
"
        python3 setup.py build_ext --inplace 2>&1 | tee -a "${BUILD_LOG}" || {
            log_ts "ERROR: rabbit extension build failed."
            cd "${PROJ_DIR}"
            return 1
        }
        log_ts "rabbit extension built successfully (without tcmalloc)."
    fi

    # Verify the .so exists
    if [ -f "rabbit.so" ] || [ -f "rabbit.cpython-"*.so ]; then
        log_ts "rabbit.so found in $(pwd)"
    else
        log_ts "WARNING: rabbit.so not found after build. Check build output."
    fi

    cd "${PROJ_DIR}"
}

# ============================================================
# Build: GNNAdvisor (HIP extension, needs ROCm + PyTorch)
# ============================================================
build_gnna() {
    log_ts "=== Building GNNAdvisor extension ==="
    cd "${PROJ_DIR}/GNNAdvisor/GNNConv"

    # Clean previous build artifacts
    rm -rf build/ dist/ *.egg-info/ GNNAdvisor.so GNNAdvisor.cpython-*.so

    python3 setup.py build_ext --inplace 2>&1 | tee -a "${BUILD_LOG}" || {
        log_ts "ERROR: GNNAdvisor extension build failed."
        cd "${PROJ_DIR}"
        return 1
    }

    # Verify the .so exists
    if [ -f "GNNAdvisor.so" ] || [ -f "GNNAdvisor.cpython-"*.so ]; then
        log_ts "GNNAdvisor.so found in $(pwd)"
    else
        log_ts "WARNING: GNNAdvisor.so not found after build. Check build output."
    fi

    log_ts "GNNAdvisor extension built successfully."
    cd "${PROJ_DIR}"
}

# ============================================================
# Build: KGGNN (HIP extension, needs ROCm + PyTorch)
# ============================================================
build_kggnn() {
    log_ts "=== Building KGGNN extension ==="
    cd "${PROJ_DIR}/KG_GNN/core"

    # Clean previous build artifacts
    rm -rf build/ dist/ *.egg-info/ KGGNN.so KGGNN.cpython-*.so

    python3 setup.py build_ext --inplace 2>&1 | tee -a "${BUILD_LOG}" || {
        log_ts "ERROR: KGGNN extension build failed."
        cd "${PROJ_DIR}"
        return 1
    }

    # Verify the .so exists
    if [ -f "KGGNN.so" ] || [ -f "KGGNN.cpython-"*.so ]; then
        log_ts "KGGNN.so found in $(pwd)"
    else
        log_ts "WARNING: KGGNN.so not found after build. Check build output."
    fi

    log_ts "KGGNN extension built successfully."
    cd "${PROJ_DIR}"
}

# ============================================================
# Build: UBGGNN (HIP extension, needs ROCm + PyTorch)
# ============================================================
build_ubg() {
    log_ts "=== Building UBGGNN extension ==="
    cd "${PROJ_DIR}/UBG"

    # Clean previous build artifacts
    rm -rf build/ dist/ *.egg-info/ UBGGNN.so UBGGNN.cpython-*.so

    python3 setup.py build_ext --inplace 2>&1 | tee -a "${BUILD_LOG}" || {
        log_ts "ERROR: UBGGNN extension build failed."
        cd "${PROJ_DIR}"
        return 1
    }

    # Verify the .so exists
    if [ -f "UBGGNN.so" ] || [ -f "UBGGNN.cpython-"*.so ]; then
        log_ts "UBGGNN.so found in $(pwd)"
    else
        log_ts "WARNING: UBGGNN.so not found after build. Check build output."
    fi

    log_ts "UBGGNN extension built successfully."
    cd "${PROJ_DIR}"
}

# ============================================================
# Build: GESpMM (HIP extension, needs ROCm + PyTorch)
# ============================================================
build_gespmm() {
    log_ts "=== Building GESpMM extension ==="
    cd "${PROJ_DIR}/dgSPARSE/example/ge-spmm"

    # Clean previous build artifacts
    rm -rf build/ dist/ *.egg-info/ GESpMM.so GESpMM.cpython-*.so

    python3 setup.py build_ext --inplace 2>&1 | tee -a "${BUILD_LOG}" || {
        log_ts "ERROR: GESpMM extension build failed."
        cd "${PROJ_DIR}"
        return 1
    }

    # Verify the .so exists
    if [ -f "GESpMM.so" ] || [ -f "GESpMM.cpython-"*.so ]; then
        log_ts "GESpMM.so found in $(pwd)"
    else
        log_ts "WARNING: GESpMM.so not found after build. Check build output."
    fi

    log_ts "GESpMM extension built successfully."
    cd "${PROJ_DIR}"
}

# ============================================================
# Build: all extensions
# ============================================================
build_all() {
    echo "============================================"
    echo "Building PckGNN extensions via setup.py"
    echo "AMD GPU Target: ${AMDGPU_TARGET}"
    echo "Date: $(date)"
    echo "Project Dir: ${PROJ_DIR}"
    echo "PYTHONPATH: ${PYTHONPATH}"
    echo "============================================"

    # Reset build.log
    > "${BUILD_LOG}"

    local failed=""

    # Build rabbit first (CPU-only, fastest, no ROCm dependency)
    build_rabbit || failed="${failed} rabbit"

    # Build HIP extensions (order doesn't matter, they're independent)
    build_gnna    || failed="${failed} gnna"
    build_kggnn   || failed="${failed} kggnn"
    build_ubg     || failed="${failed} ubg"
    build_gespmm  || failed="${failed} gespmm"

    echo "============================================"
    if [ -n "${failed}" ]; then
        echo "Build completed with failures:${failed}"
        echo "Check build.log for details."
    else
        echo "All extensions built successfully."
    fi
    echo "Build log: ${BUILD_LOG}"
    echo "============================================"

    # Print summary of built .so files
    echo ""
    echo "Built extension locations:"
    find "${PROJ_DIR}" -maxdepth 1 -name "*.so" -o \
        -path "*/GNNAdvisor/GNNConv/*.so" -o \
        -path "*/KG_GNN/core/*.so" -o \
        -path "*/UBG/*.so" -o \
        -path "*/dgSPARSE/example/ge-spmm/*.so" -o \
        -path "*/rabbit_module/src/*.so" 2>/dev/null | while read -r f; do
        echo "  ${f}"
    done
}

# ============================================================
# Test functions
# ============================================================
test_gcn() {
    local dataset="${1}"
    if [ -z "${dataset}" ]; then
        echo "Usage: bash cmd2.sh test-gcn <dataset_path> [outcsv_name]"
        echo "  dataset_path: path to .pt dataset file (e.g. dataset/Cora.pt)"
        return 1
    fi
    log_ts "=== Running GCN test: ${dataset} ==="
    cd "${PROJ_DIR}/test"
    python3 test_gcn.py "$@" 2>&1 | log | tee -a "${BUILD_LOG}"
    cd "${PROJ_DIR}"
}

test_gat() {
    local dataset="${1}"
    if [ -z "${dataset}" ]; then
        echo "Usage: bash cmd2.sh test-gat <dataset_path> [outcsv_name]"
        echo "  dataset_path: path to .pt dataset file"
        return 1
    fi
    log_ts "=== Running GAT test: ${dataset} ==="
    cd "${PROJ_DIR}/test"
    python3 test_gat.py "$@" 2>&1 | log | tee -a "${BUILD_LOG}"
    cd "${PROJ_DIR}"
}

test_gin() {
    local dataset="${1}"
    if [ -z "${dataset}" ]; then
        echo "Usage: bash cmd2.sh test-gin <dataset_path> [outcsv_name]"
        echo "  dataset_path: path to .pt dataset file"
        return 1
    fi
    log_ts "=== Running GIN test: ${dataset} ==="
    cd "${PROJ_DIR}/test"
    python3 test_gin.py "$@" 2>&1 | log | tee -a "${BUILD_LOG}"
    cd "${PROJ_DIR}"
}

test_spmm() {
    local dataset="${1}"
    local in_dim="${2}"
    if [ -z "${dataset}" ] || [ -z "${in_dim}" ]; then
        echo "Usage: bash cmd2.sh test-spmm <dataset_path> <in_dim> [outcsv_name]"
        echo "  dataset_path: path to .pt dataset file"
        echo "  in_dim: input feature dimension (e.g. 32, 128, 512)"
        return 1
    fi
    log_ts "=== Running SpMM test: ${dataset} dim=${in_dim} ==="
    cd "${PROJ_DIR}/test"
    python3 test_spmm.py "$@" 2>&1 | log | tee -a "${BUILD_LOG}"
    cd "${PROJ_DIR}"
}

test_sddmm() {
    local dataset="${1}"
    local in_dim="${2}"
    if [ -z "${dataset}" ] || [ -z "${in_dim}" ]; then
        echo "Usage: bash cmd2.sh test-sddmm <dataset_path> <in_dim> [outcsv_name]"
        echo "  dataset_path: path to .pt dataset file"
        echo "  in_dim: input feature dimension (e.g. 32, 128, 512)"
        return 1
    fi
    log_ts "=== Running SDDMM test: ${dataset} dim=${in_dim} ==="
    cd "${PROJ_DIR}/test"
    python3 test_sddmm.py "$@" 2>&1 | log | tee -a "${BUILD_LOG}"
    cd "${PROJ_DIR}"
}

test_mm() {
    log_ts "=== Running MM test ==="
    cd "${PROJ_DIR}/test"
    python3 test_mm.py 2>&1 | log | tee -a "${BUILD_LOG}"
    cd "${PROJ_DIR}"
}

# ============================================================
# Standalone tests (no DGL/PyG/ogb dependency)
#   These tests use test/standalone/ scripts that load .pt datasets
#   via a PyG Data stub and do not require third-party packages.
# ============================================================
st_gcn() {
    local dataset="${1}"
    if [ -z "${dataset}" ]; then
        echo "Usage: bash cmd2.sh st-gcn <dataset_path> [outcsv_name]"
        echo "  Standalone GCN test (no DGL/PyG needed)"
        return 1
    fi
    log_ts "=== Running standalone GCN test: ${dataset} ==="
    cd "${PROJ_DIR}/test"
    python3 standalone/run_gcn.py "$@" 2>&1 | log | tee -a "${BUILD_LOG}"
    cd "${PROJ_DIR}"
}

st_gat() {
    local dataset="${1}"
    if [ -z "${dataset}" ]; then
        echo "Usage: bash cmd2.sh st-gat <dataset_path> [outcsv_name]"
        echo "  Standalone GAT test (no DGL/PyG needed)"
        return 1
    fi
    log_ts "=== Running standalone GAT test: ${dataset} ==="
    cd "${PROJ_DIR}/test"
    python3 standalone/run_gat.py "$@" 2>&1 | log | tee -a "${BUILD_LOG}"
    cd "${PROJ_DIR}"
}

st_gin() {
    local dataset="${1}"
    if [ -z "${dataset}" ]; then
        echo "Usage: bash cmd2.sh st-gin <dataset_path> [outcsv_name]"
        echo "  Standalone GIN test (no DGL/PyG needed)"
        return 1
    fi
    log_ts "=== Running standalone GIN test: ${dataset} ==="
    cd "${PROJ_DIR}/test"
    python3 standalone/run_gin.py "$@" 2>&1 | log | tee -a "${BUILD_LOG}"
    cd "${PROJ_DIR}"
}

st_spmm() {
    local dataset="${1}"
    local in_dim="${2}"
    if [ -z "${dataset}" ] || [ -z "${in_dim}" ]; then
        echo "Usage: bash cmd2.sh st-spmm <dataset_path> <in_dim> [outcsv_name]"
        echo "  Standalone SpMM kernel test (no DGL/PyG needed)"
        return 1
    fi
    log_ts "=== Running standalone SpMM test: ${dataset} dim=${in_dim} ==="
    cd "${PROJ_DIR}/test"
    python3 standalone/run_spmm.py "$@" 2>&1 | log | tee -a "${BUILD_LOG}"
    cd "${PROJ_DIR}"
}

st_sddmm() {
    local dataset="${1}"
    local in_dim="${2}"
    if [ -z "${dataset}" ] || [ -z "${in_dim}" ]; then
        echo "Usage: bash cmd2.sh st-sddmm <dataset_path> <in_dim> [outcsv_name]"
        echo "  Standalone SDDMM kernel test (no DGL/PyG needed)"
        return 1
    fi
    log_ts "=== Running standalone SDDMM test: ${dataset} dim=${in_dim} ==="
    cd "${PROJ_DIR}/test"
    python3 standalone/run_sddmm.py "$@" 2>&1 | log | tee -a "${BUILD_LOG}"
    cd "${PROJ_DIR}"
}

st_mm() {
    log_ts "=== Running standalone MM test ==="
    cd "${PROJ_DIR}/test"
    python3 standalone/run_mm.py "$@" 2>&1 | log | tee -a "${BUILD_LOG}"
    cd "${PROJ_DIR}"
}

# ============================================================
# Clean
# ============================================================
clean() {
    echo "Cleaning build artifacts (setup.py extensions + build/ directories)..."

    # Clean each extension's build artifacts
    for dir in \
        "${PROJ_DIR}/rabbit_module/src" \
        "${PROJ_DIR}/GNNAdvisor/GNNConv" \
        "${PROJ_DIR}/KG_GNN/core" \
        "${PROJ_DIR}/UBG" \
        "${PROJ_DIR}/dgSPARSE/example/ge-spmm"; do
        if [ -d "${dir}" ]; then
            cd "${dir}"
            rm -rf build/ dist/ *.egg-info/ 2>/dev/null || true
            cd "${PROJ_DIR}"
        fi
    done

    # Remove in-place .so files from extension source directories only
    rm -f "${PROJ_DIR}"/GNNAdvisor/GNNConv/GNNAdvisor*.so 2>/dev/null || true
    rm -f "${PROJ_DIR}"/KG_GNN/core/KGGNN*.so 2>/dev/null || true
    rm -f "${PROJ_DIR}"/UBG/UBGGNN*.so 2>/dev/null || true
    rm -f "${PROJ_DIR}"/dgSPARSE/example/ge-spmm/GESpMM*.so 2>/dev/null || true
    rm -f "${PROJ_DIR}"/rabbit_module/src/rabbit*.so 2>/dev/null || true

    # Remove top-level build directory
    rm -rf "${PROJ_DIR}/build"

    # Reset build log
    > "${BUILD_LOG}"

    echo "Clean complete. build.log has been reset."
}

# ============================================================
# Environment info
# ============================================================
info() {
    echo "============================================"
    echo "PckGNN ROCm/HIP - Environment Info (setup.py)"
    echo "============================================"
    echo "Project Dir:  ${PROJ_DIR}"
    echo "GPU Target:   ${AMDGPU_TARGET}"
    echo "Date:         $(date)"
    echo "PYTHONPATH:   ${PYTHONPATH}"
    echo ""
    echo "Required Modules (supercomputer):"
    echo "  1) compiler/devtoolset/7.3.1"
    echo "  2) compiler/rocm/4.0.1"
    echo "  3) mpi/hpcx/2.11.0/gcc-7.3.1"
    echo "  4) apps/PyTorch/1.10.1a0/pytorch_1.10.1-rocm_4.0.1"
    echo ""
    echo "Compilers:"
    echo "  hipcc:     $(which hipcc 2>/dev/null || echo 'NOT FOUND')"
    echo "  g++:       $(which g++ 2>/dev/null || echo 'NOT FOUND')"
    echo "  python3:   $(which python3 2>/dev/null || echo 'NOT FOUND')"
    echo "  pip3:      $(which pip3 2>/dev/null || echo 'NOT FOUND')"
    echo ""
    echo "Python:"
    echo "  version:   $(python3 --version 2>/dev/null || echo 'NOT FOUND')"
    echo "  torch:     $(python3 -c 'import torch; print(torch.__version__)' 2>/dev/null || echo 'NOT FOUND')"
    echo "  torch cuda: $(python3 -c 'print(torch.cuda.is_available())' 2>/dev/null || echo 'NOT FOUND')"
    echo ""
    echo "GPU Architectures:"
    echo "  gfx906 = MI50 / MI60 (Vega 20)"
    echo "  gfx908 = MI100 (Arcturus)"
    echo "  gfx90a = MI200 (Aldebaran)"
    echo ""
    echo "Extension .so files found:"
    find "${PROJ_DIR}" -maxdepth 4 -name "*.so" 2>/dev/null | while read -r f; do
        echo "  ${f}"
    done
    echo "============================================"
}

# ============================================================
# Quick verify: test that all extensions can be imported
# ============================================================
verify_imports() {
    echo "=== Verifying all imports (import_check.py) ==="
    cd "${PROJ_DIR}"
    python3 import_check.py 2>&1 | tee -a "${BUILD_LOG}"
}

# ============================================================
# Help
# ============================================================
show_help() {
    echo "PckGNN ROCm/HIP - Command Reference (setup.py version)"
    echo "======================================================="
    echo ""
    echo "Environment (on supercomputer):"
    echo "  module load compiler/devtoolset/7.3.1"
    echo "  module load compiler/rocm/4.0.1"
    echo "  module load mpi/hpcx/2.11.0/gcc-7.3.1"
    echo "  module load apps/PyTorch/1.10.1a0/pytorch_1.10.1-rocm_4.0.1"
    echo ""
    echo "Build Commands:"
    echo "  bash cmd2.sh build              Build all extensions via setup.py"
    echo "  bash cmd2.sh build-rabbit       Build rabbit extension only"
    echo "  bash cmd2.sh build-gnna         Build GNNAdvisor extension only"
    echo "  bash cmd2.sh build-kggnn        Build KGGNN extension only"
    echo "  bash cmd2.sh build-ubg          Build UBGGNN extension only"
    echo "  bash cmd2.sh build-gespmm       Build GESpMM extension only"
    echo ""
    echo "Test Commands (require prior build):"
    echo "  bash cmd2.sh test-gcn    <dataset> [outcsv]"
    echo "  bash cmd2.sh test-gat    <dataset> [outcsv]"
    echo "  bash cmd2.sh test-gin    <dataset> [outcsv]"
    echo "  bash cmd2.sh test-spmm   <dataset> <in_dim> [outcsv]"
    echo "  bash cmd2.sh test-sddmm  <dataset> <in_dim> [outcsv]"
    echo "  bash cmd2.sh test-mm"
    echo ""
    echo "Standalone Tests (no DGL/PyG/ogb needed, use test/standalone/):"
    echo "  bash cmd2.sh st-gcn    <dataset> [outcsv]"
    echo "  bash cmd2.sh st-gat    <dataset> [outcsv]"
    echo "  bash cmd2.sh st-gin    <dataset> [outcsv]"
    echo "  bash cmd2.sh st-spmm   <dataset> <in_dim> [outcsv]"
    echo "  bash cmd2.sh st-sddmm  <dataset> <in_dim> [outcsv]"
    echo "  bash cmd2.sh st-mm     [m] [n] [k]"
    echo ""
    echo "Utility Commands:"
    echo "  bash cmd2.sh verify-imports      Verify all extensions can be imported"
    echo "  bash cmd2.sh clean               Remove all build artifacts"
    echo "  bash cmd2.sh info                Show environment information"
    echo ""
    echo "Log Files:"
    echo "  build.log    All build and test output"
    echo ""
    echo "Quick Start:"
    echo "  1. module load compiler/rocm/4.0.1 apps/PyTorch/1.10.1a0/pytorch_1.10.1-rocm_4.0.1"
    echo "  2. bash cmd2.sh build"
    echo "  3. bash cmd2.sh verify-imports"
    echo "  4. bash cmd2.sh test-gcn dataset/Cora.pt"
}

# ============================================================
# Main
# ============================================================
case "${1}" in
    build)
        build_all
        ;;
    build-rabbit)
        > "${BUILD_LOG}"
        build_rabbit
        ;;
    build-gnna)
        > "${BUILD_LOG}"
        build_gnna
        ;;
    build-kggnn)
        > "${BUILD_LOG}"
        build_kggnn
        ;;
    build-ubg)
        > "${BUILD_LOG}"
        build_ubg
        ;;
    build-gespmm)
        > "${BUILD_LOG}"
        build_gespmm
        ;;
    test-gcn)
        shift
        test_gcn "$@"
        ;;
    test-gat)
        shift
        test_gat "$@"
        ;;
    test-gin)
        shift
        test_gin "$@"
        ;;
    test-spmm)
        shift
        test_spmm "$@"
        ;;
    test-sddmm)
        shift
        test_sddmm "$@"
        ;;
    test-mm)
        test_mm
        ;;
    st-gcn)
        shift
        st_gcn "$@"
        ;;
    st-gat)
        shift
        st_gat "$@"
        ;;
    st-gin)
        shift
        st_gin "$@"
        ;;
    st-spmm)
        shift
        st_spmm "$@"
        ;;
    st-sddmm)
        shift
        st_sddmm "$@"
        ;;
    st-mm)
        shift
        st_mm "$@"
        ;;
    verify-imports)
        verify_imports
        ;;
    clean)
        clean
        ;;
    info)
        info
        ;;
    *)
        show_help
        ;;
esac
