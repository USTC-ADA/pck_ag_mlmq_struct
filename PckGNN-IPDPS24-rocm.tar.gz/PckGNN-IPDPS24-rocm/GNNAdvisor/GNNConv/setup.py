import os
from setuptools import setup
from torch.utils.cpp_extension import BuildExtension, CUDAExtension

# 只适配 gfx906, 避免 hipcc 因 gfx803/gfx900 等不受支持的目标失败
if not os.environ.get('PYTORCH_ROCM_ARCH'):
    os.environ['PYTORCH_ROCM_ARCH'] = 'gfx906'

setup(
    name='GNNAdvisor',
    ext_modules=[
        CUDAExtension(
        name='GNNAdvisor',
        sources=[
                    'GNNAdvisor.cpp',
                    'GNNAdvisor_kernel.cu'
                ]
        )
    ],
    cmdclass={
        'build_ext': BuildExtension
    })