#ifndef KG_UTILS__
#define KG_UTILS__

#include <hip/hip_runtime_api.h>   // cudaEvent APIs

#define kg_max(a, b) (((a) >= (b))? (a): (b))
#define kg_min(a, b) (((a) < (b))? (a): (b))

#define CUDA_CHECK_ERROR(call)\
{\
	hipError_t _error = (hipError_t)(call);\
	if(_error != hipSuccess)\
	{\
		printf("*** CUDA Error *** at [%s:%d] error=%d, reason:%s \n",\
			__FILE__, __LINE__, _error, hipGetErrorString(_error));\
	}\
}

#define CUSPARSE_CHECK(func)                                                   \
{                                                                              \
    hipsparseStatus_t status = (func);                                          \
    if (status != HIPSPARSE_STATUS_SUCCESS) {                                   \
        printf("HIPSPARSE API failed at line %d with error: %d\n",              \
               __LINE__, (int)status);                                          \
        exit(EXIT_FAILURE) ;                                                   \
    }                                                                          \
}

// Encapsule CUDA timing APIs.
// 
// Usage:
//   GpuTimer timer; // create
//   timer.start();  // when you start recording
//   timer.stop();   // when  you stop recording
//   float dur = timer.elapsed_msecs(); // duration in milliseconds

struct GpuTimer
{
    hipEvent_t startEvent;
    hipEvent_t stopEvent;

    GpuTimer() {
        hipEventCreate(&startEvent);
        hipEventCreate(&stopEvent);
    }

    ~GpuTimer() 
    {
        hipEventDestroy(startEvent);
        hipEventDestroy(stopEvent);
    }

    void start()
    {
        hipEventRecord(startEvent, 0);
    }

    void stop()
    {
        hipEventRecord(stopEvent, 0);
        hipEventSynchronize(stopEvent);
    }

    float elapsed_msecs()
    {
        float elapsed;
        hipEventElapsedTime(&elapsed, startEvent, stopEvent);
        return elapsed;
    }
};

#endif
