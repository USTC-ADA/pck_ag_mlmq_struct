#ifndef DATA_H
#define DATA_H
#include "util.h"
// #include "partition.h"

float *createCudaMatrixRandom(int n, const char *name = NULL);

template <class T>
T *createCudaMatrixCopy(T *d, int n)
{
    T *p_d;
    // cudaMallocManaged(&p_d, n * sizeof(T));
    hipMalloc2((void **)&p_d, n * sizeof(T));
    hipMemcpy(p_d, d, n * sizeof(T), hipMemcpyHostToDevice);
    return p_d;
}

template <class T>
void convert(T *a, int l1, int l2);

template <class T>
void testGPUBuffer(int gpuid, T *dptr, int outnum = 64)
{
    checkHipErrors(hipSetDevice(gpuid));
    checkHipErrors(hipDeviceSynchronize());
    const int nums = outnum;
    T temp[nums];
    checkHipErrors(hipMemcpy(temp, dptr, nums * sizeof(T), hipMemcpyDeviceToHost));
    checkHipErrors(hipDeviceSynchronize());
    printf("gpu %d\n", gpuid);
    for (int j = 0; j < nums; ++j)
    {
        if (j % 32 == 0)
            cout << endl;
        cout << temp[j] << ' ';
    }
    cout << '\n';
}

float *createLabelCPU();

float *createLabel();

void reorderCSR(int *ptr, int *index, int *map, int *reverse_map);

void load_graph(std::string dset, int &num_v, int &num_e, int *&indptr, int *&indices, bool shuffle = true, std::string reoreder_subfix = "");

void prepareDataMulti();

void prepareGraphMultiFast();

void prepareGraphMulti();

void prepareGraphPartial();

void prepareGraphPartial4All();

void prepareData();
#endif
