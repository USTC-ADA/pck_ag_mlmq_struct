#include <stdio.h>
#include <stdlib.h>
#include <hipsparse.h>
#include <hip/hip_runtime.h>

#define CHECK_HIP(cmd) do { \
    hipError_t err = cmd; \
    if (err != hipSuccess) { \
        fprintf(stderr, "HIP error: %s\n", hipGetErrorString(err)); \
        exit(1); \
    } \
} while(0)

void cutest_run(int m, int nnz, int featlen, int *RowPtr, int *ColIdx,
float *Vals, float *output)
{
    // hipSPARSE
    hipsparseHandle_t cusparse_handler;
    hipsparseStatus_t ErrorStatus;
    ErrorStatus = hipsparseCreate(&cusparse_handler);

    hipsparseMatDescr_t desc;
    ErrorStatus = hipsparseCreateMatDescr(&desc);
    hipsparseSetMatIndexBase(desc, HIPSPARSE_INDEX_BASE_ZERO);
    hipsparseSetMatFillMode(desc, HIPSPARSE_FILL_MODE_LOWER);
    hipsparseSetMatDiagType(desc, HIPSPARSE_DIAG_TYPE_NON_UNIT);

    const float alpha = 1.0f;
    const float beta  = 0.0f;
    const int   blockSize = 1;
    hipsparseSbsrmm(cusparse_handler,
        HIPSPARSE_DIRECTION_ROW,
        HIPSPARSE_OPERATION_NON_TRANSPOSE,
        HIPSPARSE_OPERATION_NON_TRANSPOSE,
        m, featlen, m, nnz,
        &alpha, desc,
        Vals, RowPtr, ColIdx,
        blockSize,
        NULL, m,
        &beta,
        output, m);
}

int main(int argc, char **argv)
{
    if (argc < 4) {
        printf("Usage: %s <m> <nnz> <featlen>\n", argv[0]);
        return 0;
    }
    int m = atoi(argv[1]);
    int nnz = atoi(argv[2]);
    int featlen = atoi(argv[3]);

    int *h_RowPtr = (int*)malloc((m + 1) * sizeof(int));
    int *h_ColIdx = (int*)malloc(nnz * sizeof(int));
    float *h_Vals  = (float*)malloc(nnz * sizeof(float));
    float *h_output = (float*)malloc(m * featlen * sizeof(float));

    for (int i = 0; i <= m; i++)
        h_RowPtr[i] = (int)((long long)nnz * i / m);
    for (int i = 0; i < nnz; i++) {
        h_ColIdx[i] = i % m;
        h_Vals[i] = 1.0f;
    }

    int *d_RowPtr, *d_ColIdx;
    float *d_Vals, *d_output;
    CHECK_HIP(hipMalloc(&d_RowPtr, (m + 1) * sizeof(int)));
    CHECK_HIP(hipMalloc(&d_ColIdx, nnz * sizeof(int)));
    CHECK_HIP(hipMalloc(&d_Vals, nnz * sizeof(float)));
    CHECK_HIP(hipMalloc(&d_output, m * featlen * sizeof(float)));

    CHECK_HIP(hipMemcpy(d_RowPtr, h_RowPtr, (m + 1) * sizeof(int), hipMemcpyHostToDevice));
    CHECK_HIP(hipMemcpy(d_ColIdx, h_ColIdx, nnz * sizeof(int), hipMemcpyHostToDevice));
    CHECK_HIP(hipMemcpy(d_Vals, h_Vals, nnz * sizeof(float), hipMemcpyHostToDevice));

    cutest_run(m, nnz, featlen, d_RowPtr, d_ColIdx, d_Vals, d_output);

    CHECK_HIP(hipDeviceSynchronize());

    CHECK_HIP(hipFree(d_RowPtr));
    CHECK_HIP(hipFree(d_ColIdx));
    CHECK_HIP(hipFree(d_Vals));
    CHECK_HIP(hipFree(d_output));
    free(h_RowPtr);
    free(h_ColIdx);
    free(h_Vals);
    free(h_output);

    printf("cuSPARSE HIP test passed.\n");
    return 0;
}
