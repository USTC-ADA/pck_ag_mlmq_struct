# PckGNN-IPDPS24 ROCm/HIP 适配

## 项目概述

本项目是 PckGNN-IPDPS24-2080（CUDA 版本）的 ROCm/HIP 适配版本，使用 `hipify-perl` 工具自动转换 CUDA 代码为 HIP 代码，并进行了手动修复以兼容 `compiler/rocm/4.0.1` 环境。

- **原始项目**: `/home/hdz/testpath/rocm/PckGNN/PckGNN-IPDPS24-2080` (CUDA)
- **适配项目**: `/home/hdz/testpath/rocm/PckGNN/PckGNN-IPDPS24-rocm` (HIP)
- **目标环境**: compiler/rocm/4.0.1, compiler/devtoolset/7.3.1
- **目标 GPU**: gfx906 (MI50/MI60)

## 项目结构

```
PckGNN-IPDPS24-rocm/
├── Makefile                    # 顶层 Makefile (旧版, 不再推荐使用)
├── cmd.sh                      # Makefile 编译/测试脚本 (旧版)
├── cmd2.sh                     # setup.py 编译/测试脚本 (新版, 推荐使用)
├── READMEv1.md                 # 本文件
├── build.log                   # 编译/测试日志
│
├── dgSPARSE/                   # 稀疏算子库 (HIP 适配)
│   ├── example/ge-spmm/
│   │   └── setup.py            # GESpMM 扩展编译
│   └── src/
│       ├── ge-spmm/            # GE-SpMM 内核
│       └── sddmm/              # SDDMM 内核
│
├── KG_GNN/                     # KG-GNN 框架 (HIP 适配)
│   ├── KG_GNN.py               # Python 封装
│   └── core/
│       ├── setup.py            # KGGNN 扩展编译
│       ├── include/            # 头文件
│       └── src/                # 源文件 (.cu + .cpp)
│
├── GNNAdvisor/                 # GNNAdvisor 框架 (HIP 适配)
│   ├── __init__.py             # 包初始化
│   ├── gnn_conv.py             # PyTorch GNN 层封装
│   ├── param.py                # 参数自动调优
│   ├── dataset.py              # 数据集加载
│   └── GNNConv/
│       ├── setup.py            # GNNAdvisor 扩展编译
│       ├── GNNAdvisor_kernel.cu
│       └── GNNAdvisor.cpp
│
├── UBG/                        # UBG 框架 (HIP 适配)
│   ├── setup.py                # UBGGNN 扩展编译
│   ├── include/                # 头文件
│   └── src/                    # 源文件
│
├── rabbit_module/              # Rabbit Order 重排序 (CPU-only)
│   ├── rabbit_order.py         # Python 封装
│   └── src/
│       └── setup.py            # rabbit 扩展编译 (CppExtension)
│
├── cuSPARSE/                   # cuSPARSE HIP 测试 (独立二进制)
│   └── Makefile
│
├── test/                       # Python 测试脚本
│   ├── test_gcn.py             # GCN 测试
│   ├── test_gat.py             # GAT 测试
│   ├── test_gin.py             # GIN 测试
│   ├── test_spmm.py            # SpMM 测试
│   ├── test_sddmm.py           # SDDMM 测试
│   ├── test_mm.py              # MM 测试
│   └── lib/                    # 测试辅助模块
│       ├── gnna_test.py        # GNNAdvisor 测试 harness
│       ├── kg_test.py          # KG-GNN 测试 harness
│       ├── ubg_test.py         # UBG 测试 harness
│       ├── ge_test.py          # GE-SpMM 测试 harness
│       └── cusparse_test.py    # cuSPARSE 测试 harness
│
├── dataset/                    # 数据集预处理脚本
└── pic/                        # 图表生成
```

## 编译说明

### v1 版编译方式 (setup.py, 推荐)

v1 版本使用 `setup.py build_ext --inplace` 编译所有 Python C++ 扩展，替代了原有的 Makefile 编译方式。

**优势**:
- 无需更改全局路径，所有 `.so` 文件在项目目录内就地生成
- 通过 `PYTHONPATH` 统一管理模块导入，解决 `import GNNAdvisor` 等导入失败问题
- 单命令统筹编译和测试，输出写入 `build.log`

**扩展模块列表**:

| 模块 | setup.py 位置 | 类型 | 用途 |
|------|---------------|------|------|
| `rabbit` | `rabbit_module/src/` | CPU (CppExtension) | 图重排序 |
| `GNNAdvisor` | `GNNAdvisor/GNNConv/` | HIP (CUDAExtension) | 参数自适应 SpMM/GNN |
| `KGGNN` | `KG_GNN/core/` | HIP (CUDAExtension) | KG-GNN SpMM/SDDMM/MM |
| `UBGGNN` | `UBG/` | HIP (CUDAExtension) | UBG GNN 编译/运行时 |
| `GESpMM` | `dgSPARSE/example/ge-spmm/` | HIP (CUDAExtension) | GE-SpMM |

### 超算环境准备

```bash
# 加载所需模块
module load compiler/devtoolset/7.3.1
module load compiler/rocm/4.0.1
module load mpi/hpcx/2.11.0/gcc-7.3.1
module load apps/PyTorch/1.10.1a0/pytorch_1.10.1-rocm_4.0.1

# 设置 GPU 架构（可选，默认 gfx906）
export AMDGPU_TARGET=gfx906
```

### quick cmd (超算部署与测试)

```bash
# === 本地打包 ===
ssh -p65010 sunjw@60.245.128.10

cd /home/hdz/testpath/rocm/PckGNN/
rm -rf PckGNN-IPDPS24-rocm.tar.gz
tar czf PckGNN-IPDPS24-rocm.tar.gz PckGNN-IPDPS24-rocm
scp -P65010 /home/hdz/testpath/rocm/PckGNN/PckGNN-IPDPS24-rocm.tar.gz sunjw@60.245.128.10:~/scd

# === 超算解压 ===
cd ~/scd
rm -rf PckGNN-IPDPS24-rocm
tar xzf PckGNN-IPDPS24-rocm.tar.gz -C ~/scd
cd ~/scd/PckGNN-IPDPS24-rocm

# === 进入计算节点 ===
srun -p debug -N 1 -n 1 --gres=dcu:1 --pty bash

# 重新加载模块 (计算节点环境不同)
module unload compiler/rocm/dtk/22.10.1
module load compiler/rocm/4.0.1
module load apps/PyTorch/1.10.1a0/pytorch_1.10.1-rocm_4.0.1
module list

# === 编译所有扩展 ===
bash cmd2.sh build

# === 验证导入 ===
bash cmd2.sh verify-imports

# === 运行测试 ===
bash cmd2.sh test-gcn ~/scd/data/pckgnn/BlogCatalog.pt
bash cmd2.sh test-spmm ~/scd/data/pckgnn/BlogCatalog.pt 64
bash cmd2.sh test-mm

# === 查看日志 ===
cat build.log

# === 下载日志到本地 ===
# 在本地执行:
scp -P65010 sunjw@60.245.128.10:/public/home/sunjw/scd/PckGNN-IPDPS24-rocm/build.log /home/hdz/testpath/rocm/PckGNN/PckGNN-IPDPS24-rocm
```

### cmd2.sh 命令参考

```bash
# 编译
bash cmd2.sh build              # 编译所有扩展
bash cmd2.sh build-rabbit       # 仅编译 rabbit
bash cmd2.sh build-gnna         # 仅编译 GNNAdvisor
bash cmd2.sh build-kggnn        # 仅编译 KGGNN
bash cmd2.sh build-ubg          # 仅编译 UBGGNN
bash cmd2.sh build-gespmm       # 仅编译 GESpMM

# 测试 (需要先编译)
bash cmd2.sh test-gcn ~/scd/data/pckgnn/BlogCatalog.pt  

bash cmd2.sh test-gcn    <dataset.pt> [outcsv]
bash cmd2.sh test-gat    <dataset.pt> [outcsv]
bash cmd2.sh test-gin    <dataset.pt> [outcsv]
bash cmd2.sh test-spmm   <dataset.pt> <in_dim> [outcsv]
bash cmd2.sh test-sddmm  <dataset.pt> <in_dim> [outcsv]
bash cmd2.sh test-mm

#独立测试
bash cmd2.sh st-gcn    <dataset.pt> [outcsv]
bash cmd2.sh st-gat    <dataset.pt> [outcsv]
bash cmd2.sh st-gin    <dataset.pt> [outcsv]
bash cmd2.sh st-spmm   <dataset.pt> <in_dim> [outcsv]
bash cmd2.sh st-sddmm  <dataset.pt> <in_dim> [outcsv]
bash cmd2.sh st-mm     [m] [n] [k]

# 工具
bash cmd2.sh verify-imports     # 验证所有扩展可导入
bash cmd2.sh clean              # 清理编译产物
bash cmd2.sh info               # 查看环境信息
```

### PYTHONPATH 说明

`cmd2.sh` 会自动设置 `PYTHONPATH` 包含以下目录:

```
${PROJ_DIR}                         # 项目根目录
${PROJ_DIR}/GNNAdvisor              # Python 模块 (gnn_conv, param, dataset)
${PROJ_DIR}/GNNAdvisor/GNNConv      # GNNAdvisor.so (--inplace 编译产物)
${PROJ_DIR}/KG_GNN                  # KG_GNN.py
${PROJ_DIR}/KG_GNN/core             # KGGNN.so (--inplace 编译产物)
${PROJ_DIR}/UBG                     # UBGGNN.so (--inplace 编译产物)
${PROJ_DIR}/dgSPARSE/example/ge-spmm # GESpMM.so (--inplace 编译产物)
${PROJ_DIR}/rabbit_module           # rabbit_order.py
${PROJ_DIR}/rabbit_module/src       # rabbit.so (--inplace 编译产物)
${PROJ_DIR}/test                    # 测试模块 (load_dataset, utils 等)
${PROJ_DIR}/test/lib                # 测试 harness (gnna_test, kg_test 等)
```

这使得所有模块导入都在项目内部解析，无需 `pip install --user` 或修改系统路径。

## 测试说明

### Python 测试

```bash
# GCN 测试
bash cmd2.sh test-gcn ~/scd/data/pckgnn/BlogCatalog.pt

# GAT 测试
bash cmd2.sh test-gat ~/scd/data/pckgnn/BlogCatalog.pt

# GIN 测试
bash cmd2.sh test-gin ~/scd/data/pckgnn/BlogCatalog.pt

# SpMM 测试 (需要指定输入维度)
bash cmd2.sh test-spmm ~/scd/data/pckgnn/BlogCatalog.pt 64

# SDDMM 测试 (需要指定输入维度)
bash cmd2.sh test-sddmm ~/scd/data/pckgnn/BlogCatalog.pt 64

# MM 测试
bash cmd2.sh test-mm

# 查看日志
cat build.log
```

### 批量测试

```bash
# 使用 run_*.sh 脚本进行批量测试
bash run_gcn.sh   matrix_sample <output_dir>
bash run_gat.sh   matrix_sample <output_dir>
bash run_gin.sh   matrix_sample <output_dir>
bash run_spmm.sh  matrix_sample <output_dir>
bash run_sddmm.sh matrix_sample <output_dir>
```

### 直接运行 Python 测试脚本

```bash
cd test
python3 test_gcn.py   <dataset.pt> [outcsv]
python3 test_gat.py   <dataset.pt> [outcsv]
python3 test_gin.py   <dataset.pt> [outcsv]
python3 test_spmm.py  <dataset.pt> <in_dim> [outcsv]
python3 test_sddmm.py <dataset.pt> <in_dim> [outcsv]
python3 test_mm.py
```

## 适配内容

### hipify-perl 自动转换

使用 `hipify-perl --inplace` 对以下类型的文件进行了批量转换：

- `.cu` 文件: CUDA kernel 代码
- `.cuh` 文件: CUDA header-only 代码
- `.h` 文件: 包含 CUDA API 的头文件
- `.cpp` / `.cc` 文件: 包含 CUDA API 的 C++ 代码

自动转换内容包括：
- `cuda_runtime.h` → `hip/hip_runtime.h`
- `cudaMalloc` → `hipMalloc`, `cudaFree` → `hipFree`
- `cudaMemcpy` → `hipMemcpy`
- `cudaDeviceSynchronize` → `hipDeviceSynchronize`
- `cudaSetDevice` → `hipSetDevice`
- `cudaEvent*` → `hipEvent*` 系列
- `<<<>>>` kernel 启动语法 → `hipLaunchKernelGGL`
- `cusparse.h` → `hipsparse.h`
- `cublas_v2.h` → `hipblas.h`
- `curand_kernel.h` → `hiprand_kernel.h`

### 手动修复

hipify-perl 无法自动处理的转换，需要手动修复：

#### 1. Warp Shuffle 内建函数
```cpp
// CUDA
__shfl_down_sync(FULLMASK, val, offset)
__shfl_sync(FULLMASK, val, src)
__shfl_xor_sync(FULLMASK, val, mask)

// HIP
__shfl_down(val, offset)
__shfl(val, src)
__shfl_xor(val, mask)
```

#### 2. cuBLAS → hipBLAS
```cpp
cublasHandle_t → hipblasHandle_t
cublasCreate → hipblasCreate
cublasDestroy → hipblasDestroy
cublasSgemm → hipblasSgemm
CUBLAS_OP_T → HIPBLAS_OP_T
```

#### 3. cuRAND → hipRAND
```cpp
curandState → hiprandState
curand_init → hiprand_init
#include <curand_kernel.h> → #include <hiprand_kernel.h>
```

#### 4. cuSPARSE 常量
```cpp
CUSPARSE_INDEX_32I → HIPSPARSE_INDEX_32I
CUSPARSE_STATUS_SUCCESS → HIPSPARSE_STATUS_SUCCESS
```

#### 5. `__ldg` 纹理加载
```cpp
// CUDA
int start = __ldg(csrRowPtr + row);
// HIP
int start = *(csrRowPtr + row);
```

#### 6. `cudaFuncSetAttribute` 动态共享内存
```cpp
cudaFuncSetAttribute → hipFuncSetAttribute
cudaFuncAttributeMaxDynamicSharedMemorySize → hipFuncAttributeMaxDynamicSharedMemorySize
```

#### 7. 自定义函数/宏重命名
```cpp
cudaMalloc2 → hipMalloc2
checkCudaErrors → checkHipErrors
```

#### 8. cuda_profiler_api.h
移除 `#include <cuda_profiler_api.h>`（ROCm 使用 roctx）。

## 已知问题与注意事项

1. **ROCm 4.0.1 支持**:
   - `__syncwarp()` 原生支持，无需兼容宏
   - hipsparse 完整支持 BSR 格式

2. **PyTorch 依赖**:
   - 所有 HIP 扩展需要 PyTorch ROCm 版本
   - `cmd2.sh build` 使用 `setup.py build_ext --inplace`，自动处理 PyTorch include 路径

3. **GPU 架构**:
   - 默认目标为 gfx906 (MI50/MI60)
   - 可通过 `export AMDGPU_TARGET=gfx908` 切换为 MI100
   - 可通过 `export AMDGPU_TARGET=gfx90a` 切换为 MI200

4. **`__ldg` 替换**:
   - `__ldg` 替换为普通加载可能会影响某些访问模式的性能
   - 如需优化，可考虑使用 `__builtin_nontemporal_load`

5. **rabbit 扩展编译**:
   - rabbit 依赖 `libnuma` 和 `libtcmalloc_minimal`
   - 如果 `tcmalloc_minimal` 不可用，`cmd2.sh` 会自动回退并重试编译

6. **v0 → v1 迁移**:
   - v0 使用 Makefile 编译为静态库 (`.a`) + `setup.py install --user`
   - v1 统一使用 `setup.py build_ext --inplace` 在项目内生成 `.so`
   - 旧的 `cmd.sh` 和 `Makefile` 保留但不再推荐使用

## 适配统计

| 类别 | 文件数 |
|------|--------|
| 自动 hipify 的 .cu 文件 | 25 |
| 自动 hipify 的 .cuh 文件 | 3 |
| 自动 hipify 的 .h 文件 | 17 |
| 自动 hipify 的 .cpp/.cc 文件 | 7 |
| setup.py 文件 | 5 |
| 新建 cmd2.sh | 1 |
| 新建 __init__.py | 1 |
| 手动修复的类型数 | 8 |

## 参考

- [ROCm HIP Documentation](https://rocm.docs.amd.com/projects/HIP/en/latest/)
- [hipify-perl User Guide](https://rocm.docs.amd.com/projects/HIPIFY/en/latest/)
- 参考项目: `/home/hdz/testpath/rocm/agsptrsv_rocm`
- 原始项目: `/home/hdz/testpath/rocm/PckGNN/PckGNN-IPDPS24-2080`
