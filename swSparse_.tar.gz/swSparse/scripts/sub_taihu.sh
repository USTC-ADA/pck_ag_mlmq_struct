#! /bin/bash

FIFO=run/outfile

DATA_ROOT="/home/export/online1/mdt00/shisuan/swSparse/sw26020_data"
PRO_ROOT=`pwd`

data_dir=${DATA_ROOT}/${ver_dir}/data
result_dir=${DATA_ROOT}/${ver_dir}/result
offset_dir=${DATA_ROOT}/${ver_dir}/offset

if [ ${data_type} == "real" ]
then
    if [ ${matrix_type} == "l" ]
    then
#        matrix_dir=${DATA_ROOT}/SuiteSparse_mat
        matrix_dir=../benchmark_csr
    elif [ ${matrix_type} == "m" ]
    then
        matrix_dir=${DATA_ROOT}/SuiteSparse_mat
#        matrix_dir=${PRO_ROOT}
    elif [ ${matrix_type} == "tl" ]
    then
        matrix_dir=${DATA_ROOT}/lu/mat_l
    elif [ ${matrix_type} == "tu" ]
    then
        matrix_dir=${DATA_ROOT}/lu/mat_u
    fi
elif [ ${data_type} == "cmp" ]
then
    matrix_dir=${DATA_ROOT}/SuiteSparse_mat
fi

mkdir -p out_files_${test_name}

queue_name=q_sw_expr
    
if [ ${test_name} == "trsv" ]
then
    if [ ${parallel} == "par" ]
    then
        exe_file=sptrsv_hetero_test
    else
        exe_file=sptrsv_sequential_test
    fi

    if [ ${test_type} == "file" ]
    then
        bsub -I -p -b  -q ${queue_name} -shared -n 1 -np 1 -cgsp 64 -J sptrsv -host_stack 256 -share_size 10240 -cross_size 0  ./install/bin/${exe_file} -${matrix_type} ${matrix_dir}/$1 -o ${FIFO} ${data_dir}/$1 ${result_dir}/$1 ${offset_dir}/$1 $1   > ./out_files_${test_name}/$1.out 2>&1  
    elif [ ${test_type} == "dir" ]
    then
        bsub -I -p -b  -q ${queue_name} -shared -n 1 -np 1 -cgsp 64 -J sptrsv -host_stack 256 -share_size 10240 -cross_size 0  ./install/bin/${exe_file} -${matrix_type} ${matrix_dir}/$1 -o ${FIFO} ${data_dir}/$1 ${result_dir}/$1 ${offset_dir}/$1 $1
    fi

elif [ ${test_name} == "trsm" ]
then

    if [ ${parallel} == "par" ]
    then
        exe_file=sptrsm_hetero_test
    else
        exe_file=sptrsm_sequential_test
    fi

    if [ ${test_type} == "file" ]
    then
        bsub -I -p -b  -q ${queue_name} -shared -n 1 -np 1 -cgsp 64 -J tridiagonal -host_stack 256 -share_size 10240 -cross_size 0  ./install/bin/${exe_file} -${matrix_type}  ${matrix_dir}/$1 -o ${FIFO} ${data_dir}/$1 ${result_dir}/$1 ${offset_dir}/$1 $1   > ./out_files_${test_name}/$1.out 2>&1  
    elif [ ${test_type} == "dir" ]
    then
        bsub -I -p -b  -q ${queue_name} -shared -n 1 -np 1 -cgsp 64 -J tridiagonal -host_stack 256 -share_size 10240 -cross_size 0  ./install/bin/${exe_file} -${matrix_type}  ${matrix_dir}/$1 -o ${FIFO} ${data_dir}/$1 ${result_dir}/$1 ${offset_dir}/$1 $1   
    fi
fi

ret=$?

if [ $ret == 50 ]
then
    echo $1 >> ./out_files_${test_name}/pass_mat
    echo $1 success
elif [ $ret == 51 ]
then
    echo $1 >> ./out_files_${test_name}/result_error_mat
    echo $1 error
elif [ $ret == 52 ]
then
    echo $1 >> ./out_files_${test_name}/complex_mat
    echo $1 complex element
elif [ $ret == 53 ]
then
    echo $1 >> ./out_files_${test_name}/data_error_mat
    echo $1 data error
elif [ $ret == 54 ]
then
    echo $1 >> ./out_files_${test_name}/zero_mat
    echo $1 zero in diagonal
elif [ $ret == 55 ]
then
    echo $1 >> ./out_files_${test_name}/seq_mat
	echo $1 seq
elif [ $ret == 56 ]
then
    echo $1 >> ./out_files_${test_name}/par_32_mat
	echo $1 par 32
elif [ $ret == 57 ]
then
    echo $1 >> ./out_files_${test_name}/par_64_mat
	echo $1 par 64
elif [ $ret == 102 ]
then
    echo $1 >> ./out_files_${test_name}/kill_mat
    echo $1 kill mat
else
    echo $1 exit_code = $ret >> ./out_files_${test_name}/other_error_mat
    echo $1 other error   exit_code = $ret
fi
