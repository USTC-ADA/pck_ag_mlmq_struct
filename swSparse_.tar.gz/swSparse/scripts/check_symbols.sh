#! /bin/awk -f

# swSparse_ for C functions
# _ZN8swSparse for C++ functions
# swsparse_ for Fortran functions
# .rodata.swSparse_ for constant global variables
{
    if( $0~/\sg\s/ && 
            $0!~/\s\.rodata\.swSparse_/ && 
            $0!~/\sswSparse_/ && 
            $0!~/\sswsparse_/ && 
            $0!~/\sslave_swSparse_/ && 
            $0!~/\s_ZN8swSparse/ &&
            $0!~/\s_ZNK8swSparse/ &&
            $0!~/\sslave__ZNK8swSparse/ &&
            $0!~/\sslave__ZN8swSparse/ ) {
        print "WARNING: exported symbol ", $0
    }
}