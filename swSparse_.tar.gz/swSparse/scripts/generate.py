
# element-size 4 (single real)
#        lda: 128, 256, 544, 1040, 1024
#  ldb & ldc: 256, 320, 544, 1040, 2056

# element-size 8 (double real / single complex)
#        lda: 128, 288, 528,  512
#  ldb & ldc: 192, 288, 528, 1032

# element-size 16 (double complex)
#        lda:  64, 128, 144, 264, 256
#  ldb & ldc: 128, 160, 144, 264, 520

load_template = "vldd   {reg}, {offset}({ptr})"
store_template = "vstd   {reg}, {offset}({ptr})"
zero_template = "vcpys   $31, $31, {reg}"

mm_24_template = [
    "subl_c {k}, 8, {k_8}",
    "bge    {k_8}, {label_nloop}",

    "{label_nloop_small_k}:",     # for(int j = 0; j < n; ++j)
        "mov    {m}, {inner_m}",
        "mov    {c}, {inner_c}",
        "mov    {a}, {mid_a}",
        "{label_mloop_small_k}:",      # for(int i = 0; i < m; ++i)
            "ldi    {temp}, 0x7($31)",
            "wcsr   {temp}, 0x92",
            "mov    {mid_a}, {inner_a}",
            "mov    {b}, {inner_b}",
            "mov    {k}, {inner_k}",
            "{load_c_24_}",
            "vldd   {b00}, {boff00}({inner_b})",
            "vldd   {a00}, {aoff00}({inner_a})",
            "vldd   {a10}, {aoff10}({inner_a})",
            "vldd   {b01}, {boff01}({inner_b})",
            "vldd   {b02}, {boff02}({inner_b})",
            "vlenma  {b00}, {a00}, {c00_}, {c00}",
            "vldd    {b03}, {boff03}({inner_b})",
            "vlenma  {b00}, {a10}, {c10_}, {c10}",
            "vldd    {a01}, {aoff01}({inner_a})",
            "vlenma  {b01}, {a00}, {c01_}, {c01}",
            "vldd    {a11}, {aoff11}({inner_a})",
            "vlenma  {b01}, {a10}, {c11_}, {c11}",
            "vlenma  {b02}, {a00}, {c02_}, {c02}",
            "vlenma  {b02}, {a10}, {c12_}, {c12}",
            "subl_c  {inner_k}, 1, {inner_k}",        # k -= 1
            "vlenma  {b03}, {a00}, {c03_}, {c03}",
            "ldi     {inner_a}, {aoff02}({inner_a})", # move ptr A += 2 col
            "vlenma  {b03}, {a10}, {c13_}, {c13}",
            "beq     {inner_k}, {label_store_small_k}",         # if k == 0
            "{label_inner_small_k}:",
                "vlenma  {b00}, {a01}, {c00}, {c00}",
                "vlenma  {b01}, {a01}, {c01}, {c01}",
                "subl_c  {inner_k}, 1, {inner_k}",    # k -= 1
                "vlenma  {b02}, {a01}, {c02}, {c02}",
                "vldd    {a00}, 0*64({inner_a})",    
                "vlenma  {b03}, {a01}, {c03}, {c03}",
                "vldd    {a10}, 1*64({inner_a})",    
                "vlenma  {b00}, {a11}, {c10}, {c10}",
                "vlenma  {b01}, {a11}, {c11}, {c11}",
                "vlenma  {b02}, {a11}, {c12}, {c12}",
                "vlenma  {b03}, {a11}, {c13}, {c13}",
                "beq     {inner_k}, {label_store_small_k}",     # if k == 0
                "vlenma  {b00}, {a00}, {c00}, {c00}",
                "vlenma  {b01}, {a00}, {c01}, {c01}",
                "vlenma  {b02}, {a00}, {c02}, {c02}",
                "vldd    {a01}, {aoff01}({inner_a})",
                "vlenma  {b03}, {a00}, {c03}, {c03}",
                "vldd    {a11}, {aoff11}({inner_a})",
                "vlenma  {b00}, {a10}, {c10}, {c10}",
                "subl_c  {inner_k}, 1, {inner_k}",    # k -= 1
                "vlenma  {b01}, {a10}, {c11}, {c11}",
                "ldi     {inner_a}, {aoff02}({inner_a})", # move ptr A += 2 col
                "vlenma  {b02}, {a10}, {c12}, {c12}",
                "vlenma  {b03}, {a10}, {c13}, {c13}",
                "bgt     {inner_k}, {label_inner_small_k}",        # if k > 0
            "{label_store_small_k}:",
                "{store_c_24}",
                "subl_c  {inner_m}, 16, {inner_m}",   # m -= 16
                "ldi     {inner_c}, {coff20}({inner_c})",   # move ptr C += 16
                "ldi     {mid_a}, {aoff20}({mid_a})",   # move ptr outer A += 16
                "bgt     {inner_m}, {label_mloop_small_k}",   # m loop
                "subl_c  {n}, 4, {n}",   # n -= 4
                "ldi     {c}, {coff04}({c})",   # move ptr outer C += 4 col
                "ldi     {b}, {boff04}({b})",   # move ptr outer B += 4 col
                "bgt     {n}, {label_nloop_small_k}",   # n loop
                "br      {label_return}", #"jmp     {zero},{ra},0x1",
    "{label_nloop}:",     # for(int j = 0; j < n; ++j)
        "mov    {m}, {inner_m}",
        "mov    {c}, {inner_c}",
        "mov    {a}, {mid_a}",
        "{label_mloop}:",      # for(int i = 0; i < m; ++i)
            "ldi    {temp}, 0x7($31)",
            "wcsr   {temp}, 0x92",
            "mov    {mid_a}, {inner_a}",
            "mov    {b}, {inner_b}",
            "mov    {k_8}, {inner_k_8}",
            "{load_c_24}",
            "vldd   {b00}, {boff00}({inner_b})",
            "vldd   {a00}, {aoff00}({inner_a})",
            "vldd   {a10}, {aoff10}({inner_a})",
            "vldd   {b01}, {boff01}({inner_b})",
            "vldd   {b02}, {boff02}({inner_b})",
            "{label_unroll}:",
                "vlenma  {b00}, {a00}, {c00}, {c00}",
                "vldd    {b03}, {boff03}({inner_b})",
                "vlenma  {b00}, {a10}, {c10}, {c10}",
                "vldd    {a01}, {aoff01}({inner_a})",
                "vlenma  {b01}, {a00}, {c01}, {c01}",
                "vldd    {a11}, {aoff11}({inner_a})",
                "vlenma  {b01}, {a10}, {c11}, {c11}",
                "vlenma  {b02}, {a00}, {c02}, {c02}",
                "vlenma  {b02}, {a10}, {c12}, {c12}",
                "ldi     {inner_a}, {aoff02}({inner_a})", # move ptr A += 2 col
                "vlenma  {b03}, {a00}, {c03}, {c03}",
                "ldi     {temp}, 6({zero})",    # counter = 6
                "vlenma  {b03}, {a10}, {c13}, {c13}",
                "{label_inner1}:",
                    "vlenma  {b00}, {a01}, {c00}, {c00}",
                    "subl_c  {temp}, 2, {temp}", # counter -= 2
                    "vlenma  {b01}, {a01}, {c01}, {c01}",
                    "vlenma  {b02}, {a01}, {c02}, {c02}",
                    "vldd    {a00}, {aoff00}({inner_a})",
                    "vlenma  {b03}, {a01}, {c03}, {c03}",
                    "vldd    {a10}, {aoff10}({inner_a})",
                    "vlenma  {b00}, {a11}, {c10}, {c10}",
                    "vlenma  {b01}, {a11}, {c11}, {c11}",
                    "vlenma  {b02}, {a11}, {c12}, {c12}",
                    "vlenma  {b03}, {a11}, {c13}, {c13}",
                    "vlenma  {b00}, {a00}, {c00}, {c00}",
                    "vlenma  {b01}, {a00}, {c01}, {c01}",
                    "vlenma  {b02}, {a00}, {c02}, {c02}",
                    "vldd    {a01}, {aoff01}({inner_a})",
                    "vlenma  {b03}, {a00}, {c03}, {c03}",
                    "vldd    {a11}, {aoff11}({inner_a})",
                    "vlenma  {b00}, {a10}, {c10}, {c10}",
                    "vlenma  {b01}, {a10}, {c11}, {c11}",
                    "ldi     {inner_a}, {aoff02}({inner_a})", # move ptr A += 2 col
                    "vlenma  {b02}, {a10}, {c12}, {c12}",
                    "vlenma  {b03}, {a10}, {c13}, {c13}",
                    "bgt     {temp}, {label_inner1}", # while c > 0
                "vlenma  {b00}, {a01}, {c00}, {c00}",
                "ldi     {inner_b}, 64({inner_b})", # move ptr B += 8
                "vlenma  {b01}, {a01}, {c01}, {c01}",
                "mov     {inner_k_8}, {inner_k}",
                "vlenma  {b02}, {a01}, {c02}, {c02}",
                "subl    {inner_k_8}, 8, {inner_k_8}", # k - 8
                "vlenma  {b03}, {a01}, {c03}, {c03}",
                "vldd    {a00}, {aoff00}({inner_a})",
                "vlenma  {b00}, {a11}, {c10}, {c10}",
                "vldd    {a10}, {aoff10}({inner_a})",
                "vlenma  {b01}, {a11}, {c11}, {c11}",
                "vldd    {b00}, {boff00}({inner_b})",
                "vlenma  {b02}, {a11}, {c12}, {c12}",
                "vldd    {b01}, {boff01}({inner_b})",
                "vlenma  {b03}, {a11}, {c13}, {c13}",
                "vldd    {b02}, {boff02}({inner_b})",
                "bge     {inner_k_8}, {label_unroll}", # if k >= 8
                "beq     {inner_k}, {label_store}", # if k == 0
            "{label_remainder}:",
                "vlenma  {b00}, {a00}, {c00}, {c00}",
                "vldd    {b03}, {boff03}({inner_b})",
                "vlenma  {b00}, {a10}, {c10}, {c10}",
                "vldd    {a01}, {aoff01}({inner_a})",
                "vlenma  {b01}, {a00}, {c01}, {c01}",
                "vldd    {a11}, {aoff11}({inner_a})",
                "vlenma  {b01}, {a10}, {c11}, {c11}",
                "vlenma  {b02}, {a00}, {c02}, {c02}",
                "vlenma  {b02}, {a10}, {c12}, {c12}",
                "subl_c  {inner_k}, 1, {inner_k}",        # k -= 1
                "vlenma  {b03}, {a00}, {c03}, {c03}",
                "ldi     {inner_a}, {aoff02}({inner_a})", # move ptr A += 2 col
                "vlenma  {b03}, {a10}, {c13}, {c13}",
                "beq     {inner_k}, {label_store}",         # if k == 0
                "{label_inner2}:",
                    "vlenma  {b00}, {a01}, {c00}, {c00}",
                    "vlenma  {b01}, {a01}, {c01}, {c01}",
                    "subl_c  {inner_k}, 1, {inner_k}",    # k -= 1
                    "vlenma  {b02}, {a01}, {c02}, {c02}",
                    "vldd    {a00}, 0*64({inner_a})",    
                    "vlenma  {b03}, {a01}, {c03}, {c03}",
                    "vldd    {a10}, 1*64({inner_a})",    
                    "vlenma  {b00}, {a11}, {c10}, {c10}",
                    "vlenma  {b01}, {a11}, {c11}, {c11}",
                    "vlenma  {b02}, {a11}, {c12}, {c12}",
                    "vlenma  {b03}, {a11}, {c13}, {c13}",
                    "beq     {inner_k}, {label_store}",     # if k == 0
                    "vlenma  {b00}, {a00}, {c00}, {c00}",
                    "vlenma  {b01}, {a00}, {c01}, {c01}",
                    "vlenma  {b02}, {a00}, {c02}, {c02}",
                    "vldd    {a01}, {aoff01}({inner_a})",
                    "vlenma  {b03}, {a00}, {c03}, {c03}",
                    "vldd    {a11}, {aoff11}({inner_a})",
                    "vlenma  {b00}, {a10}, {c10}, {c10}",
                    "subl_c  {inner_k}, 1, {inner_k}",    # k -= 1
                    "vlenma  {b01}, {a10}, {c11}, {c11}",
                    "ldi     {inner_a}, {aoff02}({inner_a})", # move ptr A += 2 col
                    "vlenma  {b02}, {a10}, {c12}, {c12}",
                    "vlenma  {b03}, {a10}, {c13}, {c13}",
                    "bgt     {inner_k}, {label_inner2}",        # if k > 0
        "{label_store}:",
            "{store_c_24}",
            "subl_c  {inner_m}, 16, {inner_m}",   # m -= 16
            "ldi     {inner_c}, {coff20}({inner_c})",   # move ptr C += 16
            "ldi     {mid_a}, {aoff20}({mid_a})",   # move ptr outer A += 16
            "bgt     {inner_m}, {label_mloop}",   # m loop
        "subl_c  {n}, 4, {n}",          # n -= 4,              the variable has changed value
        "ldi     {c}, {coff04}({c})",   # move ptr C += 4 col, the variable has changed value
        "ldi     {b}, {boff04}({b})",   # move ptr B += 4 col, the variable has changed value
        "bgt     {n}, {label_nloop}",   # n loop
    "{label_return}:"
]
mm_24_vars = ["inner_m", "inner_n", "inner_k", "k_8", "inner_k_8", "inner_a", "mid_a", 
            "inner_b", "inner_c", "temp" ]
mm_24_labels = ["label_nloop_small_k", "label_mloop_small_k", "label_inner_small_k", 
            "label_store_small_k", "label_nloop", "label_mloop", "label_unroll", "label_inner1",
            "label_inner2", "label_remainder", "label_store", "label_return"]

special_registers = {
    "m" : "%0", "n" : "%1", "k" : "%2", "a" : "%3", "b" : "%4", "c" : "%5", "ra" : "$26", "zero" : "$31"
}

integer_registers = [
    "$1", "$2", "$3", "$4", "$5", "$6", "$7", "$8", "$22", "$23", "$24", "$25", "$27", # t0 ~ t12, caller saved
    "$0", "$28", # v0, at, caller saved
    "$9", "$10","$11","$12","$13","$14" # s0 ~ s5, callee saved
]

def allocate_simd_registers(nrow, ncol, table, init_option):
    idx = 32
    regs = []
    for row in range(nrow):
        for col in range(ncol):
            regname = "${}".format(idx)
            table["c{}{}".format(row, col)] = regname
            regs.append("\"" + regname + "\",")
            idx = idx + 1
    
    for row in range(nrow):
        for k in range(2):
            regname = "${}".format(idx)
            table["a{}{}".format(row, k)] = regname
            regs.append("\"" + regname + "\",")
            idx = idx + 1

    for col in range(ncol):
        regname = "${}".format(idx)
        table["b0{}".format(col)] = regname
        regs.append("\"" + regname + "\",")
        idx = idx + 1
    if idx > 64:
        print("Error: not enough SIMD registers")
    return "".join(regs)

def allocate_int_registers(vars, table):
    idx = 0
    regs = []
    for v in vars:
        if idx > len(integer_registers):
            print("Error: not enough integer registers")
        regname = integer_registers[idx]
        table[v] = regname
        idx = idx + 1
        regs.append("\"" + regname + "\",")
    return "".join(regs)

class Label:
    def __init__(self):
        self.count = 0
    def get(self):
        s = "$L{}BLAS".format(self.count)
        self.count = self.count + 1
        return s

label_allocator = Label()

def allocate_labels(labels, table):
    for l in labels:
        table[l] = label_allocator.get()

def generate_mm(file, init_c, lda, ldb, ldc): 
    head = "void {}(int m, int n, int k, const double*a, const double*b, const double*c) {{\n  asm volatile(\n"
    tail1 = "    :: \"r\"(m), \"r\"(n), \"r\"(k), \"r\"(a), \"r\"(b), \"r\"(c):\n    \"%0\", \"%1\", \"%2\", \"%3\", \"%4\", \"%5\",\n    "
    tail2 = "\n    \"memory\"\n  );\n}\n"
    table = special_registers.copy()
    intreg = allocate_int_registers(mm_24_vars, table)
    simdreg = allocate_simd_registers(2, 4, table)
    allocate_labels(mm_24_labels, table)
    funcname = "mm_{}_{}_{}_{}".format(init_c, lda, ldb, ldc)

    for row in range(2):
        for col in range(4):
            offset = row * 64 + col * 8 * ldb
            table["boff{}{}".format(row, col)] = offset
            if row > 0:
                col8 = row * 4 + col
                offset = col8 * 8 * ldb
                table["boff0{}".format(col8)] = offset
    
    for row in range(2):
        for k in range(2):
            table["aoff{}{}".format(row, k)] = row * 64 + k * 8 * lda

    table["aoff20"] = 2*64
    table["aoff02"] = lda*8*2
    table["coff20"] = 2*64
    table["coff04"] = ldc*8*4
    load_code = []
    store_code = []
    for col in range(4):
        for row in range(2):
            offset = row*64+ldc*8*col
            regname = table["c{}{}".format(row, col)]
            if init_c == 0:
                table["c{}{}_".format(row, col)] = table["zero"]
                load_code.append(zero_template.format(reg=regname))
            else:
                table["c{}{}_".format(row, col)] = table[regname]
                load_code.append(load_template.format(reg=regname, offset=offset, ptr=table["inner_c"]))
            store_code.append(store_template.format(reg=regname, offset=offset, ptr=table["inner_c"]))
        if init_c == 0:
            table["load_c_2{}".format(col+1)] = "\\n\"\n    \"".join(load_code)
            table["load_c_2{}_".format(col+1)] = ""
        else:
            table["load_c_2{}".format(col+1)] = "\\n\"\n    \"".join(load_code)
        table["store_c_2{}".format(col+1)] = "\\n\"\n    \"".join(store_code)
    load_code = []
    store_code = []
    for col in range(4):
        offset = ldc*8*col
        regname = table["c{}{}".format(row, col)]
        load_code.append(load_template.format(reg=regname, offset=offset, ptr=table["inner_c"]))
        store_code.append(store_template.format(reg=regname, offset=offset, ptr=table["inner_c"]))
        table["load_c_1{}".format(col+1)] = "\\n\"\n    \"".join(load_code)
        table["store_c_1{}".format(col+1)] = "\\n\"\n    \"".join(store_code)
    code = [head.format(funcname)]
    for line in mm_24_template:
        code.append("    \"")
        code.append(line.format(**table))
        code.append("\\n\"\n")
    code.append(tail1)
    code.append(intreg)
    code.append("\n    ")
    code.append(simdreg)
    code.append(tail2)
    file.write("".join(code))

with open("source/heterogeneous/CPE/BLAS_kernels/dgemm.inl", "w") as file:
    generate_mm(file, 0, 288, 288, 288)
    generate_mm(file, 0, 128, 192, 192)
    generate_mm(file, 1, 288, 288, 288)
    generate_mm(file, 1, 128, 192, 192)
    generate_mm(file, 1, 520, 520, 520)
    generate_mm(file, 1, 512, 1032, 1032)
