#! /bin/bash
# execution command on Sunway TaihuLight

#FIFO=run/fifo
FIFO=run/outfile

# test_name=$1      trsv|spmv|trsm等    测试功能名称
# matrix_type=$2    l: csr ;  m: mtx ; t: txt    输入矩阵文件格式
# data_type=$3      real  |  cmp    矩阵数据类型，实数或者复数
# test_type=$4      file  |  dir    输入file：从某个文件中读取矩阵数据名称 ，输入dir：从矩阵数据目录中获取矩阵名称
# parallel=$5       par   |  seq    并行还是串行
# # '''
# test with the data of intel
DATA_ROOT="/home/export/online1/mdt00/shisuan/swSparse/sw26020_data"
PRO_ROOT=`pwd`

if [ $# != 5 ]
then
    echo the count of para is not correct!
    exit
fi

echo test: $1 $2 $3 $4 $5

export test_name=$1
export matrix_type=$2    # l: csr ;  m: mtx ; t: txt
export data_type=$3      # real  |  cmp
export test_type=$4      # file  |  dir
export parallel=$5       # par   |  seq

if [ $1 == "trsv" ]
then
    export ver_dir=gen_data/sptrsv
#    export ver_dir=gen_data/sptrsv_s
    sleep_time=30
elif [ $1 == "trsm" ] 
then
    export ver_dir=gen_data/sptrsm
    sleep_time=30
fi

length=0

if [ ${test_type} == "file" ]
then
    if [ ${data_type} == "real" ]
    then
        if [ ${matrix_type} == "l" ]
        then
            for line in `cat ../mtx_list/real_mat_csr`
            do
                file_array[$length]=$line
                length=`expr $length + 1`
            done
        elif [ ${matrix_type} == "m" ]
        then
#        else
            for line in `cat ../swSparse_data/mtx_list/part`
#            for line in `cat ./other_error_mat`
            do
                file_array[$length]=$line
                length=`expr $length + 1`
            done
        fi
    elif [ ${data_type} == "cmp" ]
    then
#            for line in `cat ../mtx_list/trsv_error_mat_z`
            for line in `cat ../mtx_list/trsm_error_mat_z`
            do
                file_array[$length]=$line
                length=`expr $length + 1`
            done
    fi
elif [ ${test_type} == "dir" ]
then
#    data_dir=${DATA_ROOT}/${ver_dir}/data
    data_dir=${DATA_ROOT}/SuiteSparse_mat

    cd ${data_dir}

#all_b=`ls`
#    all_b=`ls my_matrix.mtx`
#    all_b=`ls c-big*`
    all_b='adder_dcop_05*'
    for b in ${all_b}
    do
    #    file_name=${b%.*}
    #    file_array[$length]=$file_name.bin
        file_array[$length]=$b
        length=`expr $length + 1`
    done
fi

echo the matrix account: $length

#for((i=0;i<${length};i++))
#do
#cp $matrix_dir/${file_array[i]}* $matrix_dir2/
#    sh scripts/sub_taihu.sh  ${file_array[i]}  
#done

cd ${PRO_ROOT}
#rm -f ./out_files/*mat   ./out_files/*bin.out
rm -f ./out_files_trsv/offset_out

for ((i=0;i<${length};i+=1))
	do
        echo test the:${file_array[i]} 
		./scripts/sub_taihu.sh  ${file_array[i]}  
	    
	done

echo All test finished.
