#! /bin/bash

DEBUG_INFO=1
#DEBUG_INFO=2
COMPLEX_SAFE_NUMERICS=0
LINK_LIBMETIS=OFF
METIS_PATH=/home/export/online1/mdt00/shisuan/swSparse/liukan/metis-5.1.0/install
LINK_LIBM_SLAVE=OFF  # libmslave bug when we use too much LDM
VERBOSE= # "VERBOSE=1"

function print_help() {
    echo "USAGE: $1 compile"
    echo "    OR $1 install <path prefix>"
}

CURRENT=`pwd`
ARG_STATUS=1

if [ "$#" \< 1 ]; then
    print_help $0
    ARG_STATUS=0
else
    if [ "$1" == "compile" ]; then
        TARGET=
        INSTALL_PREFIX=install
    elif [ "$1" == "install" ]; then
        if [ "$#" \< 2 ]; then
            print_help $0
            ARG_STATUS=0
        else
            INSTALL_PREFIX=${CURRENT}/$2
            TARGET=install
        fi
    elif [ "$1" == "help" ]; then
        print_help $0
        ARG_STATUS=0
    else
        print_help $0
        ARG_STATUS=0
    fi
fi

if [ "$ARG_STATUS" == 1 ]; then
    #python ./scripts/generate.py

    if [ ! -d build ]
    then
        mkdir build
    fi
    cd build

    cmake .. -DCMAKE_INSTALL_PREFIX=${INSTALL_PREFIX} -DDEBUG_INFO=${DEBUG_INFO} \
        -DCOMPLEX_SAFE_NUMERICS=${COMPLEX_SAFE_NUMERICS} -DLINK_LIBMETIS=${LINK_LIBMETIS} \
        -DLINK_LIBM_SLAVE=${LINK_LIBM_SLAVE} -DMETIS_PATH=${METIS_PATH} && make -j ${TARGET} $VERBOSE

    cd ..

    if [ "$TARGET" == "install" ]; then
        cd ${INSTALL_PREFIX}/lib
        AWK_SCRIPT=${CURRENT}/scripts/check_symbols.sh
        objdump -t libswsparse.a     | awk -f ${AWK_SCRIPT}
        objdump -t libswsparse_seq.a | awk -f ${AWK_SCRIPT}
    fi
fi

cd ${CURRENT}
