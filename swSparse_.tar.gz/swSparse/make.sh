#!bash/bin
sh ./scripts/build.sh install install
