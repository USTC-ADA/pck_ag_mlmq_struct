#include <limits>
#include "swSparse.h"
#include "internal/rename.h"
#include "internal/reorder.h"
#include "internal/memory.h"
#include "internal/debug.h"
#include "internal/utils.h"
#include "internal/templates.h"
#include "internal/spblas_common.h"
#include "internal/third_party.h"
#include "internal/sptrf_common.h"

namespace swSparse {

#ifdef LU_PRINT_STATS
#define DECL_TIMER struct timeval begin, end
#define TIMER_BEGIN gettimeofday(&begin, nullptr)
#define TIMER_END   gettimeofday(&end, nullptr)
#define PRINT_MC64_TIME     swSparse_set_lu_timing(&begin, &end, LU_TIMING_MC64)
#else
#define DECL_TIMER
#define TIMER_BEGIN
#define TIMER_END
#define PRINT_MC64_TIME
#endif


static constexpr const char *singular = "Error: matrix singular, there are zero rows or columns\n";
#define PRINT_SINGULAR DEBUG_PRINTF(singular)
static constexpr const char *zero_diag_msg = "Error: there are structrual zeros on the diagnal, it is recommended to:\n"\
											 "    1. use SWSPARSE_MATCHING_MC64 option (may destroy structural symmetry)\n"\
											 "    2. or fill the diagnal with numeric zero (do this only if it will be a fill-in)\n";
#define PRINT_ZERO_DIAG DEBUG_PRINTF(zero_diag_msg)

inline void print_diag(preprocess_status_t d) {
	switch (d) {
	case STATUS_ZERO_DIAG:
		PRINT_ZERO_DIAG;
		break;
	case STATUS_SINGULAR:
		PRINT_SINGULAR;
		break;
	}
}

// equilibrate if required, compute the 1-norm, reorder
template<typename DATA_T>
ErrorStatus sptrf_preprocess_same_pattern(Matrix a, Matrix pa, preprocess_result_t<real_t<DATA_T>>* result, \
		real_t<DATA_T>* rscale, real_t<DATA_T>* cscale, const swSparseTRFOptions* options) {
	preprocess_status_t diag;
	Int n = a->n, nnz = a->nnz;
	const Int *a_idx = a->matrix.csrc->indices, *a_off = a->matrix.csrc->offsets;
	DATA_T *a_val = VALUES(a->matrix.csrc, DATA_T);
	DATA_T *eq_val = a_val;

	if(options->equilibrate == SWSPARSE_EQUILIBRATE) {
		eq_val = (DATA_T *)swSparse_malloc(sizeof(DATA_T) * nnz);
		IF_ERR(eq_val == nullptr) { return MALLOC_ERROR; }
		result->perterb_threshold = norm_1_sparse_rescale_colmax(n, nnz, a_off, a_idx, a_val, eq_val, rscale, cscale);
		if(result->perterb_threshold == 0.0) {
			diag = STATUS_SINGULAR;
		}
	} else {
		diag = norm_1_check_diagonal(n, nnz, a_off, a_idx, a_val, &result->perterb_threshold);
	}
	// the previous factorization applies supernodal diagonal block pivoting, the diagonal may has zero.
	IF_ERR(diag == STATUS_SINGULAR) {
		PRINT_SINGULAR;
		if(eq_val != a_val) {
			swSparse_free(eq_val);
		} 
		return SWSPARSE_INVALID_ARGS;
	}
	
	if(options->perturbate == SWSPARSE_PERTURBATE_1) {
		result->perterb_threshold *= precision<real_t<DATA_T>>::epsilon;
	} else {
		result->perterb_threshold *= precision<real_t<DATA_T>>::sqrt_epsilon;
	}

	MatrixFormatType f = a->format_type;
	void *v = a->matrix.csrc->values;
	a->format_type = CSC;
	a->matrix.csrc->values = eq_val;

	Matrix tmp;
	ErrorStatus ret = reorder_row_col(a, &tmp, result->riperm, result->ciperm);
	a->format_type = f;
	a->matrix.csrc->values = v;
	if(ret == SWSPARSE_SUCCESS) {
		memcpy(pa, tmp, sizeof(MatrixData));
		swSparse_free(tmp);
	}
	if(eq_val != a_val) {
		swSparse_free(eq_val);
	} 
	return ret;
}


template<typename DATA_T>
ErrorStatus sptrf_preprocess(Matrix a, Matrix pa, preprocess_result_t<real_t<DATA_T>>* result, \
		real_t<DATA_T>* rscale, real_t<DATA_T>* cscale, const swSparseTRFOptions* options) {
	Int *match_riperm = nullptr, *fillin_iperm, *etree, *colcnt, *rowcnt, *part_super;
	col_status_t* status;
	Int n = a->n, nnz = a->nnz;
	const Int *a_idx = a->matrix.csrc->indices, *a_off = a->matrix.csrc->offsets;
	DATA_T *a_val = VALUES(a->matrix.csrc, DATA_T);
	ErrorStatus ret;
	DECL_TIMER;
	// preprocessing to improve numeric stability: 
	// MATCHING, EQUILIBRATATION and calculate the threshold for PERTURBATATION

	if(options->matching == SWSPARSE_NO_MATCHING) {
		preprocess_status_t diag;
		if(options->equilibrate == SWSPARSE_EQUILIBRATE) {
			real_t<DATA_T> *rwork = (real_t<DATA_T>*) swSparse_malloc(sizeof(real_t<DATA_T>) * (nnz + n));
			IF_ERR(rwork == nullptr) { return MALLOC_ERROR; }
			diag = scaling_factor_check_diagonal(n, nnz, a_off, a_idx, a_val, rscale, cscale, rwork);
			swSparse_free(rwork);
		} else {
			diag = norm_1_check_diagonal(n, nnz, a_off, a_idx, a_val, &result->perterb_threshold);
		}
		IF_ERR(diag != STATUS_GOOD) {  // symbolic factorize assume no zero on the diagonal
			print_diag(diag);
			return SWSPARSE_INVALID_ARGS;
		}
	}

	ret = init_csrc(pa, n, n, n, nnz, TYPE_ARG(DATA_T));
	pa->format_type = CSC;
	IF_ERR(ret != SWSPARSE_SUCCESS) {
		return ret;
	}
	swSparse_memcpy(pa->matrix.csrc->offsets, a_off, sizeof(Int) * (n + 1));

	DATA_T *pa_val = VALUES(pa->matrix.csrc, DATA_T);
	Int *pa_idx = pa->matrix.csrc->indices;

	if(options->matching != SWSPARSE_NO_MATCHING) {
		match_riperm = (Int*)swSparse_malloc(sizeof(Int) * (n + 1));
		IF_ERR(match_riperm == nullptr) {
			ret = MALLOC_ERROR;
		} else {
			TIMER_BEGIN;
			ret = HSL::mc64a(n, nnz, a_off, a_idx, a_val, \
				match_riperm, rscale, cscale, &result->perterb_threshold, options);
			TIMER_END;
			PRINT_MC64_TIME;
		}
		IF_ERR(ret != SWSPARSE_SUCCESS) {
			swSparse_destruct(pa);
			return clean_return(ret, match_riperm);
		}
        ASSERT(swSparse_valid_permutation(n, match_riperm, pa_idx));
		ewise_exp(n, rscale, cscale);// offload exp computation
		gather_by_indices(nnz, match_riperm, pa_idx, a_idx);

	} else {
		swSparse_memcpy(pa_idx, a_idx, sizeof(Int) * (a->nnz));
		pa->matrix.csrc->ordered = true;
	}
	
	if(options->equilibrate == SWSPARSE_EQUILIBRATE) {
		// recalculate 1-norm, it is different from the one calculted in mc64a, because the matrix is scaled 
		result->perterb_threshold = norm_1_sparse_scale(n, nnz, a_off, a_idx, a_val, pa_val, rscale, cscale);
	} else {
		swSparse_memcpy(pa_val, a_val, sizeof(DATA_T) * nnz);
	}

	/*
	 * how do we calculate the 1-norm:
	 * 	MC64 + EQUILIBRATE: calculated in mc64a, recalculated in norm_1_sparse_scale
	 * 	MC64 + NO_EQUILIBRATE: calculated in mc64a
	 * 	NO_MATCHING + EQUILIBRATE: calculated in norm_1_sparse_scale
	 * 	NO_MATCHING + NO_EQUILIBRATE: calculated in norm_1_check_diagonal
	 */
	if(options->perturbate == SWSPARSE_PERTURBATE_1) {
		result->perterb_threshold *= precision<real_t<DATA_T>>::epsilon;
	} else {
		result->perterb_threshold *= precision<real_t<DATA_T>>::sqrt_epsilon;
	}
		
	ret = swSparse_ensure_order(pa);
	IF_ERR(ret != SWSPARSE_SUCCESS) {
		swSparse_destruct(pa);
		return clean_return(ret, match_riperm);
	}

	fillin_iperm = result->ciperm;  // `ciperm` from user argument

	etree = (Int*)swSparse_malloc(sizeof(Int) * n * 4);
	part_super = etree + n;
	rowcnt = part_super + n;
	colcnt = rowcnt + n;
	IF_ERR(etree == nullptr) {
		swSparse_destruct(pa);
		return clean_return(MALLOC_ERROR, match_riperm);
	}

	status = (col_status_t*)swSparse_malloc(sizeof(col_status_t) * n);
	IF_ERR(status == nullptr) {
		swSparse_destruct(pa);
		return clean_return(MALLOC_ERROR, etree, match_riperm);
	}

	// result->riperm is not used in `swSparse_symmetric_analysis`
	result->status = status;
	result->etree  = etree;
	result->part_super = part_super;
	result->rowcnt = rowcnt;
	result->colcnt = colcnt;

	ret = swSparse_symmetric_analysis(n, pa->matrix.csrc->offsets, pa_idx, result, options->reorder);
	IF_ERR(ret != SWSPARSE_SUCCESS) {
		swSparse_destruct(pa);
		return clean_return(ret, etree, status, match_riperm);
	}

	// compose two permutations
	Int *iwork = result->to_clean;  // reuse allocated memory
	ASSERT(swSparse_valid_permutation(n, fillin_iperm, iwork));
	if(match_riperm != nullptr) {
		if(options->reorder != SWSPARSE_NATURAL_ORDER) {
			iperm_compose(n, match_riperm, fillin_iperm, iwork);
			result->riperm = iwork;
			iwork = match_riperm;
		} else {
			result->riperm = match_riperm;
		}
		result->to_clean = result->riperm;
	} else {                 // NO_MATCHING
		result->riperm = fillin_iperm;
		result->to_clean = nullptr;
	}
	swSparse_free(iwork);

	/* apply fill-in reduction permutation */
	if(options->reorder != SWSPARSE_NATURAL_ORDER) {
		ret = reorder_row_col(pa, SWSPARSE_IN_PLACE, fillin_iperm, fillin_iperm);
		IF_ERR(ret != SWSPARSE_SUCCESS) {
			swSparse_destruct(pa);
			return clean_return(ret, etree, status, result->to_clean);
		}
	}

	return SWSPARSE_SUCCESS;
}

#define INSTANTIATE(type) \
template ErrorStatus sptrf_preprocess<type>(Matrix a, Matrix pa, preprocess_result_t<real_t<type>>* result, \
		real_t<type>* rscale, real_t<type>* cscale, const swSparseTRFOptions* options);\
template ErrorStatus sptrf_preprocess_same_pattern<type>(Matrix a, Matrix pa, preprocess_result_t<real_t<type>>* result, \
		real_t<type>* rscale, real_t<type>* cscale, const swSparseTRFOptions* options);

INSTANTIATE(float)
INSTANTIATE(double)
INSTANTIATE(SComplex)
INSTANTIATE(DComplex)

} // namespace swSparse
