#include "swSparse_base.h"
#include "internal/rename.h"
#include "internal/memory.h"
#include "internal/utils.h"

void swSparse_level_csr_lower(Int n, const Int *row_offsets, const Int *column_indices, Int *levels) {
    Int i;
    swSparse_memset(levels, 0, sizeof(Int) * n);
    
    for(i = 0; i < n; ++i) {
        Int k;
        for(k = row_offsets[i]; k < row_offsets[i+1] && column_indices[k] < i; ++k) {
            Int j = column_indices[k];
            levels[i] = max(levels[i], levels[j] + 1);
        }
    }
}

void swSparse_level_csc_lower(Int n, const Int *column_offsets, const Int *row_indices, Int *levels) {
    Int i;
    swSparse_memset(levels, 0, sizeof(Int) * n);
    
    for(i = 0; i < n; ++i) {
        Int k;
        for(k = column_offsets[i+1] - 1; k >= column_offsets[i] && row_indices[k] > i; --k) {
            Int j = row_indices[k];
            levels[j] = max(levels[j], levels[i] + 1);
        }
    }
}
/*
void swSparse_level_csr_upper(Int n, const Int *row_offsets, const Int *column_indices, Int *levels) {
    Int i;
    swSparse_memset(levels, 0, sizeof(Int) * n);
    
    for(i = 0; i < n; ++i) {
        Int k;
        for(k = row_offsets[i+1] - 1; k >= row_offsets[i] && column_indices[k] > i; --k) {
            Int j = column_indices[k];
            levels[j] = max(levels[j], levels[i] + 1);
        }
    }
}

void swSparse_level_csc_upper(Int n, const Int *column_offsets, const Int *row_indices, Int *levels) {
    Int i;
    swSparse_memset(levels, 0, sizeof(Int) * n);
    
    for(i = 0; i < n; ++i) {
        Int k;
        for(k = column_offsets[i]; k < column_offsets[i+1] && row_indices[k] < i; ++k) {
            Int j = row_indices[k];
            levels[i] = max(levels[i], levels[j] + 1);
        }
    }
}
*/

void swSparse_level_csr_upper_reverse(Int n, const Int *row_offsets, const Int *column_indices, Int *levels) {
    Int i;
    swSparse_memset(levels, 0, sizeof(Int) * n);
    
    for(i = n - 1; i >= 0; --i) {
        Int k;
        for(k = row_offsets[i+1] - 1; k >= row_offsets[i] && column_indices[k] > i; --k) {
            Int j = column_indices[k];
            levels[i] = max(levels[i], levels[j] + 1);
        }
    }
}

void swSparse_level_csc_upper_reverse(Int n, const Int *column_offsets, const Int *row_indices, Int *levels) {
    Int i;
    swSparse_memset(levels, 0, sizeof(Int) * n);
    
    for(i = n - 1; i >= 0; --i) {
        Int k;
        for(k = column_offsets[i]; k < column_offsets[i+1] && row_indices[k] < i; ++k) {
            Int j = row_indices[k];
            levels[j] = max(levels[j], levels[i] + 1);
        }
    }
}
