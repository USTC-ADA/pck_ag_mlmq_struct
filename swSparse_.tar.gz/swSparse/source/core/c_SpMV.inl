#include "internal/utils.h"
#include "internal/multicompile.h"
#include "internal/debug.h"
#include "internal/rename.h"
#include "internal/memory.h"
#include "internal/templates.h"
#include "internal/spmv_common.h"
#include "swSparse_options.h"
#include "swSparse_matrix.h"


ErrorStatus FUNCNAME(mv_execute)(DATA_T alpha , Matrix mat, const DATA_T *x, DATA_T beta , DATA_T *y , const swSparseMVOptions* options) {
    
    ErrorStatus ret = SWSPARSE_SUCCESS;

    MatrixCSRC *mat_a;
    int i;

    if(alpha == ZERO) {
        swSparse::vector_scale(beta, mat->m, y, y);
        return SWSPARSE_SUCCESS;
    }

    if(mat->element_type != ELEMENT_TYPE) {
        DEBUG_PRINTF("error: The matrix element is not %s\n", TYPENAME_STR); 
    }


    using conj = conjugate<DATA_T>;
    using noconj = not_conjugate<DATA_T>;
    switch(mat->format_type) {
    case CSR:
    {   
        mat_a = mat->matrix.csrc; 
        if ( (options->transpose & SWSPARSE_CONJUGATE) == SWSPARSE_CONJUGATE ){
            ret = mv_execute_csr<DATA_T,noconj>(mat->m , mat->n ,  alpha , mat_a , x, beta , y , options);
        }
        else{
			ret = mv_execute_csr<DATA_T,conj>(mat->m , mat->n ,  alpha , mat_a , x, beta , y , options); 
        }
        return ret;
    }
    case SWCOO:
        /* call SWCOO functions */
        ret = mv_execute_swcoo<DATA_T,noconj>(alpha, mat, x, beta, y, options);
        return ret;
    default:
        return SWSPARSE_INVALID_ARGS;
    }
}

ErrorStatus FUNCNAME(mm_execute)(DATA_T alpha , Matrix mat, Int nvec, const DATA_T *x, Int step_x, DATA_T beta , DATA_T *y, Int step_y , const swSparseMMOptions* options) {
    Int i;
    ErrorStatus ret = SWSPARSE_SUCCESS;
    MatrixCSRC *mat_a;
    swSparseMVOptions mv_options;

    using conj = conjugate<DATA_T>;
    using noconj = not_conjugate<DATA_T>;
    
    if(alpha == ZERO) {
        swSparse::dense_scale(beta, mat->m, nvec, y, step_y, y, step_y);
        return SWSPARSE_SUCCESS;
    }
    if(mat->element_type != ELEMENT_TYPE) {
        DEBUG_PRINTF("error: The matrix element is not %s\n", TYPENAME_STR); 
    }
    switch(mat->format_type) {
    case CSR:
    {   
        mat_a = mat->matrix.csrc; 
        mv_options.transpose =  options->transpose;
        if ( (options->transpose & SWSPARSE_CONJUGATE) == SWSPARSE_CONJUGATE ){
            for(i = 0; i < nvec; ++i) {
                //ret = mv_execute_csr<DATA_T,noconj>(mat->m , mat->n , alpha , mat_a, x + step_x * i, beta , y + step_y * i , &mv_options);
            }
        }
        else{
            for(i = 0; i < nvec; ++i) {
                //ret = mv_execute_csr<DATA_T,conj>(mat->m , mat->n , alpha , mat_a, x + step_x * i, beta , y + step_y * i , &mv_options);
            }            
        }
        return ret;
    }
    case SWCOO:
        /* call SWCOO functions */
        ret = mm_execute_swcoo<DATA_T,noconj>(alpha,mat,nvec,x,step_x,beta,y,step_y,options);
        return ret;
    default:
        return SWSPARSE_INVALID_ARGS;
    }
}

ErrorStatus FUNCNAME(struct_mv) (DATA_T alpha, const DATA_T *aa, const DATA_T *xx, DATA_T beta,  DATA_T *bb, const swSparseInt *dim ,  swSparseInt rnnz , const swSparseInt (*inpos)[3]){
    using conj = conjugate<DATA_T>;
    using noconj = not_conjugate<DATA_T>;
    ErrorStatus ret = SWSPARSE_SUCCESS;
    ret = struct_mv_execute<DATA_T,noconj>(alpha,aa,xx,beta,bb,dim,rnnz,inpos);
    return ret;

}


