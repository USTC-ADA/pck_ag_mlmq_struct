#include"swSparse.h"
#include"internal/rename.h"
#include"internal/memory.h"
#include"internal/templates.h"

namespace swSparse {

// TODO: call SpMV and supernodal-TRSV

/* may use static iteration (SpMV + LUSolve per step)
 *    iterate:
 *        r = b - A * x;
 *        if ( norm(r) < tolerance ) {
 *            return x;
 *        }
 *        x = x + lusolve(r);
 * 
 * or BiCGStab (2 SpMV + 2 LUSolve per step)
 *    r     = b - A * x_0;
 *    rho   = dot(r, r);
 *    if ( norm(r) < tolerance ) { return x_0; }
 *    r_tld = r;
 *    p = r;
 *    iterate:
 *        p_hat = lusolve(p);
 *        v     = A * p_hat;
 *        alpha = rho / dot(r_tld, v);
 *        s     = r - alpha * v;
 *        if ( norm(s) < tolerance ) {
 *            x = x + alpha * p_hat;
 *            return x;
 *        }
 *        s_hat = lusolve(s);
 *        t     = A * s_hat;
 *        omega = dot(t, s) / dot(t, t);
 *        x     = x + alpha * p_hat + omega * s_hat;
 *        r     = s - omega * t;
 *        if ( norm(r) < tolerance ) {
 *            return x;
 *        }
 *        if ( omega == 0.0 ) {
 *            restart with a new x_0;
 *        }
 *        rho_1 = rho;
 *        rho   = dot(r_tld, r);
 *        if ( rho == 0.0 ) {
 *            restart with a new x_0;
 *        }
 *        beta  = (rho * alpha) / (rho_1 * omega);
 *        p     = r + beta * ( p - omega * v );
 */

template<typename DATA_T>
ErrorStatus iterative_refine(Matrix ap, Matrix lu, const DATA_T* b, DATA_T* x) {
    return SWSPARSE_SUCCESS;
}

}
