#include "swSparse.h"
#include "internal/rename.h"
#include "internal/memory.h"
#include "internal/debug.h"
#include "internal/transform.h"
#include "internal/spblas_common.h"

#if DEBUG_LEVEL == 0
#define PRINT_TRANS_ERROR(op)
#define PRINT_FORMAT_ERROR(id, type)
#define PRINT_NULL_ERROR(x, y, type, add)
#else
static const char swSparse_trans_error[] = "Invalid option in %s: must have either SWSPARSE_NON_TRANPOSE or SWSPARSE_TRANPOSE (exclusive)\n";
#define PRINT_TRANS_ERROR(op) DEBUG_PRINTF(swSparse_trans_error, op);
static const char swSparse_format_error[] = "Invalid format for input matrix in swSparse_%c_%s\n";
#define PRINT_FORMAT_ERROR(id, type) DEBUG_PRINTF(swSparse_format_error, id, type);
static const char swSparse_null_error[] = "Error: %c and %c are nullptr in swSparse_%c_%s\n";
#define PRINT_NULL_ERROR(x, y, type, add) DEBUG_PRINTF(swSparse_null_error, x, y, type, add);
#endif

using namespace swSparse;

inline MatrixFormatType get_output_format(MatrixFormatType a, Int transa, MatrixFormatType b, Int transb) {
    Bool sa = (transa & NO_TRANS);
    Bool sb = (transb & NO_TRANS);
    Bool ra = (a == CSR) ? sa : !sa;
    Bool rb = (b == CSR) ? sb : !sb;
    if(((a != CSR) && (a != CSC)) || ((b != CSR) && (b != CSC))) {
        return COO; // COO for invalid
    }
    if(ra == rb) {
        return ra ? CSR : CSC;
    } else if(sa && !sb) {
        return ra ? CSR : CSC;
    } else if(!sa && sb) {
        return rb ? CSR : CSC;
    } else return COO; // COO for invalid
}

inline Bool check_trans_exclusive(Int trans) {
    if((trans & NO_TRANS) == 0 && (trans & TRANS) == 0) {
        return true;
    }
    return (trans & SWSPARSE_MAYBE_TRANSPOSE) == SWSPARSE_MAYBE_TRANSPOSE;
}

template<typename DATA_T>
inline ErrorStatus ATB(DATA_T alpha, DATA_T beta, Int m, Int n, Int k, \
    MatrixCSRC *a, MatrixCSRC *b, MatrixCSRC *d, MatrixCSRC *c, Bool a_conj, Bool b_conj) {
    MatrixCSRC at;
    ErrorStatus ret = transpose_csr_x<DATA_T>(m, k, a, &at);
    IF_ERR(ret != SWSPARSE_SUCCESS) {
        return ret;
    }
    ret = gemm_csr<DATA_T>(alpha, beta, m, n, k, &at, b, d, c, a_conj, b_conj);
    return clean_return(ret, at.offsets, at.indices, at.values);
}

template<typename DATA_T>
inline ErrorStatus ABT(DATA_T alpha, DATA_T beta, Int m, Int n, Int k, \
    MatrixCSRC *a, MatrixCSRC *b, MatrixCSRC *d, MatrixCSRC *c, Bool a_conj, Bool b_conj) {
    MatrixCSRC bt;
    ErrorStatus ret = transpose_csr_x<DATA_T>(k, n, b, &bt);
    IF_ERR(ret != SWSPARSE_SUCCESS) {
        return ret;
    }
    ret = gemm_csr<DATA_T>(alpha, beta, m, n, k, a, &bt, d, c, a_conj, b_conj);
    return clean_return(ret, bt.offsets, bt.indices, bt.values);
}

template<typename DATA_T>
inline ErrorStatus ATplusB(DATA_T alpha, DATA_T beta, Int m, Int n, \
    MatrixCSRC *a, MatrixCSRC *b, MatrixCSRC *c, Bool a_conj, Bool b_conj) {
    MatrixCSRC at;
    ErrorStatus ret = transpose_csr_x<DATA_T>(m, n, a, &at);
    IF_ERR(ret != SWSPARSE_SUCCESS) {
        return ret;
    }
    ret = add_csr<DATA_T>(alpha, beta, m, n, &at, b, c, a_conj, b_conj);
    return clean_return(ret, at.offsets, at.indices, at.values);
}

template<typename DATA_T>
inline ErrorStatus AplusBT(DATA_T alpha, DATA_T beta, Int m, Int n, \
    MatrixCSRC *a, MatrixCSRC *b, MatrixCSRC *c, Bool a_conj, Bool b_conj) {
    MatrixCSRC bt;
    ErrorStatus ret = transpose_csr_x<DATA_T>(m, n, b, &bt);
    IF_ERR(ret != SWSPARSE_SUCCESS) {
        return ret;
    }
    ret = add_csr(alpha, beta, m, n, a, &bt, c, a_conj, b_conj);
    return clean_return(ret, bt.offsets, bt.indices, bt.values);
}

template<typename T>
INLINE Bool equals_zero(T x) {
    return (x == T(0.0)) || (x == T(-0.0));
}

template<typename T>
INLINE Bool equals_zero(const complex<T>& x) {
    return equals_zero(x.real) && equals_zero(x.imag);
}

#define DATA_TYPE_S
#include "c_ADDGEMM.inl"
#undef DATA_TYPE_S
#define DATA_TYPE_D
#include "c_ADDGEMM.inl"
#undef DATA_TYPE_D
#define DATA_TYPE_C
#include "c_ADDGEMM.inl"
#undef DATA_TYPE_C
#define DATA_TYPE_Z
#include "c_ADDGEMM.inl"
#undef DATA_TYPE_Z
