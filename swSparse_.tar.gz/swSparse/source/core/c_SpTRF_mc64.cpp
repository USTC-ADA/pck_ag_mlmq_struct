#include <limits>
#include <algorithm>
#include "swSparse.h"
#include "internal/rename.h"
#include "internal/memory.h"
#include "internal/debug.h"
#include "internal/templates.h"
#include "internal/sptrf_common.h"
#include "internal/spblas_common.h"
#include "internal/third_party.h"

#define EMPTY (-1)

/*
 * This file is translated from Fortran code src/common.f in HSL-MC64
 */


namespace swSparse {
namespace HSL {
/*
 * Liu Kan: 
 * mc64d, mc64e and mc64f are heap operations
 * 
 * mc64d - push an element into the heap
 * mc64e - pull an element from the top of the heap
 * mc64f - pull an element from somewhere in the heap
 * 
 * heap in Fortran 1-based index: 
 *                       1
 *           2                       3
 *     4           5           6           7
 *  8     9    10    11    12    13    14    15
 * parent(i) = i / 2
 * left_child(i) = i * 2
 * right_child(i) = i * 2 + 1
 * 
 * heap in C 0-based index: 
 *                       0
 *           1                       2
 *     3           4           5           6
 *  7     8     9    10    11    12    13    14
 * parent(i) = (i - 1) / 2
 * left_child(i) = i * 2 + 1
 * right_child(i) = i * 2 + 2
 */

/*
 * Translated from Fortran, with iway = 2

C *** Copyright (c) 1999  Council for the Central Laboratory of the
C     Research Councils                                             ***
C *** Although every effort has been made to ensure robustness and  ***
C *** reliability of the subroutines in this MC64 suite, we         ***
C *** disclaim any liability arising through the use or misuse of   ***
C *** any of the subroutines.                                       ***
C *** Any problems?   Contact ...                                   ***
C     Iain Duff (I.Duff@rl.ac.uk) or                                ***
C     Jacko Koster (jacko.koster@uninett.no)                        ***
 */
template<typename DATA_T>
static void mc64d(Int i, Int* RSTR q, DATA_T* RSTR d, Int* RSTR l) {
    constexpr Int k = 2;
    Int pos = l[i];
    if(pos > 0) {
        DATA_T di = d[i];
        while(pos > 0) {
            Int posk = (pos - 1) / k; // 0-base indexing
            Int qk = q[posk];
            if(di >= d[qk]) break;
            q[pos] = qk;
            l[qk] = pos;
            pos = posk;
        }
    }
    q[pos] = i;
    l[i] = pos;
}


/*
 * Translated from Fortran, with iway = 2

C *** Copyright (c) 1999  Council for the Central Laboratory of the
C     Research Councils                                             ***
C *** Although every effort has been made to ensure robustness and  ***
C *** reliability of the subroutines in this MC64 suite, we         ***
C *** disclaim any liability arising through the use or misuse of   ***
C *** any of the subroutines.                                       ***
C *** Any problems?   Contact ...                                   ***
C     Iain Duff (I.Duff@rl.ac.uk) or                                ***
C     Jacko Koster (jacko.koster@uninett.no)                        ***
 */
template<typename DATA_T>
static Int mc64e(Int qlen, Int* RSTR q, DATA_T* RSTR d, Int* RSTR l) {
    constexpr Int k = 2;
    Int i = q[qlen], pos = 0; //  0-base indexing
    DATA_T di = d[i], dk, dr;
    qlen = qlen - 1; // Fortran argument is passed by reference
    for(;;) {
        Int posk = pos * k + 1; // 0-base indexing
        if(posk > qlen) break;
        dk = d[q[posk]];
        if(posk < qlen) {
            dr = d[q[posk+1]];
            if(dk > dr) {
                posk += 1;
                dk = dr;
            }
        }
        if(di < dk) break;
        q[pos] = q[posk];
        l[q[pos]] = pos;
        pos = posk;
    }
    q[pos] = i;
    l[i] = pos;
    return qlen; // Fortran argument is passed by reference
}

/*
 * Translated from Fortran, with iway = 2

C *** Copyright (c) 1999  Council for the Central Laboratory of the
C     Research Councils                                             ***
C *** Although every effort has been made to ensure robustness and  ***
C *** reliability of the subroutines in this MC64 suite, we         ***
C *** disclaim any liability arising through the use or misuse of   ***
C *** any of the subroutines.                                       ***
C *** Any problems?   Contact ...                                   ***
C     Iain Duff (I.Duff@rl.ac.uk) or                                ***
C     Jacko Koster (jacko.koster@uninett.no)                        ***
 */
template<typename DATA_T>
static Int mc64f(Int pos0, Int qlen, Int*q, DATA_T* d, Int* l) {
    constexpr Int k = 2;
    Int i, pos, qk;
    DATA_T di, dk, dr;
    if(qlen == pos0) {
        return qlen - 1;
    }
    i = q[qlen];
    di = d[i];
    qlen = qlen - 1;
    pos = pos0;
    while(pos > 0) {
        Int posk = (pos - 1) / k; // 0-base indexing
        qk = q[posk];
        if(di >= d[qk]) break;
        q[pos] = qk;
        l[qk] = pos;
        pos = posk;
    }
    q[pos] = i;
    l[i] = pos;
    if(pos == pos0) {
        for(;;) {
            Int posk = pos * k + 1; // 0-base indexing
            if(posk > qlen) break;
            dk = d[q[posk]];
            if(posk < qlen) {
                dr = d[q[posk + 1]];
                if(dk > dr) {
                    posk += 1;
                    dk = dr;
                }
            }
            if(di <= dk) break;
            qk = q[posk];
            q[pos] = qk;
            l[qk] = pos;
            pos = posk;
        }
        q[pos] = i;
        l[i] = pos;

    }
    return qlen;
}

/*
 * Translated from Fortran

C *** Copyright (c) 1999  Council for the Central Laboratory of the
C     Research Councils                                             ***
C *** Although every effort has been made to ensure robustness and  ***
C *** reliability of the subroutines in this MC64 suite, we         ***
C *** disclaim any liability arising through the use or misuse of   ***
C *** any of the subroutines.                                       ***
C *** Any problems?   Contact ...                                   ***
C     Iain Duff (I.Duff@rl.ac.uk) or                                ***
C     Jacko Koster (jacko.koster@uninett.no)                        ***
 */
template<typename DATA_T>
static Int mc64w(Int n, Int nnz, const Int* RSTR col_ptr, const Int* RSTR row_idx, const DATA_T* RSTR values, \
                          Int* RSTR iperm, Int* RSTR jperm, Int* RSTR out, Int* RSTR pr, Int* RSTR q, Int* RSTR l, \
                          DATA_T* RSTR u, DATA_T* RSTR d) {
    constexpr DATA_T rinf = std::numeric_limits<DATA_T>::max(), zero = 0;
    Int num = 0;
    DATA_T di;
#ifdef SWSPARSE_HAS_ASSERT
#define ASSERT_VALID_MATCHING(row) {\
    Int col = iperm[row], pos = jperm[col]; \
    ASSERT_LESS_EQUAL(col_ptr[col], pos);  \
    ASSERT_LESS(pos, col_ptr[col+1]); \
    ASSERT_EQUAL(row_idx[pos], row);  \
}
#else
#define ASSERT_VALID_MATCHING(row)
#endif

    for(Int j = 0; j < n; ++j) {
        u[j] = rinf;
        d[j] = zero;
        iperm[j] = EMPTY;
        jperm[j] = EMPTY;
        pr[j] = col_ptr[j];
        l[j] = EMPTY;
    }
    // Liu Kan: maximum entry in each row
    
    for(Int j = 0; j < n; ++j) {
        for(Int k = col_ptr[j]; k < col_ptr[j+1]; ++k) {
            Int i = row_idx[k];
            if(values[k] <= u[i]) {
                u[i] = values[k];
                iperm[i] = j;
                l[i] = k;
            }
        }
    }

    // initial matching
    for(Int i = 0; i < n; ++i) {
        Int j = iperm[i];
        if(j != EMPTY) {
            // Row I is not empty
            iperm[i] = EMPTY;
            // Liu Kan: if j is already matched with another row, cancel the matching (i,j) to maintain uniqueness
            if(jperm[j] == EMPTY) {
                // Don't choose cheap assignment from dense columns
                if((col_ptr[j+1] - col_ptr[j] <= n / 10) || (n <= 50)) {
                    // Assignment of column J to row I
                    num += 1;
                    iperm[i] = j;
                    jperm[j] = l[i];
                    ASSERT_VALID_MATCHING(i);
                }
            }
        }
    }
    if(num != n) {
        // Scan unassigned columns; improve assignment
        for(Int j = 0; j < n; ++j) {
            Int k1 = col_ptr[j];
            Int k2 = col_ptr[j+1];
            // JPERM(J) ne 0 iff column J is already assigned
            // Continue only if column J is not empty
            if((jperm[j] == EMPTY) && (k1 < k2)) {
                //       vj = rinf;
                // Changes made to allow for NaNs
                Int i0 = row_idx[k1];
                DATA_T vj = values[k1] - u[i0];
                Int k0 = k1;
                for(Int k = k1 + 1; k < k2; ++k) {
                    Int i = row_idx[k];
                    di = values[k] - u[i];
                    if(di <= vj) {
                        // Liu Kan: di == vj means a[i][j] and a[i0][j] are both minimun in their rows
                        if((di >= vj) && (di != rinf)) { 
                            // Liu Kan: multiple minimums, choose the unmatched
                            if((iperm[i] != EMPTY) || (iperm[i0] == EMPTY)) {
                                continue;
                            }
                        }
                        vj = di;
                        i0 = i;
                        k0 = k;
                    }
                }
                d[j] = vj;
                Int k = k0, i = i0;
                if(iperm[i] != EMPTY) {
                    for(k = k0; k < k2; ++k) {
                        i = row_idx[k];
                        if(values[k] - u[i] <= vj) {
                            Int jj = iperm[i];
                            Int kk1 = pr[jj];
                            Int kk2 = col_ptr[jj+1];
                            for(Int kk = kk1; kk < kk2; ++kk) {
                                Int ii = row_idx[kk];
                                if((iperm[ii] == EMPTY) && (values[kk] - u[ii] <= d[jj])) {
                                    iperm[ii] = jj;
                                    jperm[jj] = kk;
                                    pr[jj] = kk + 1;                    
                                    ASSERT_VALID_MATCHING(ii);
                                    goto break_nested_loops;
                                }
                            }
                        }
                    }
                    continue;
                }
            break_nested_loops:
                num += 1;
                iperm[i] = j;
                jperm[j] = k;
                ASSERT_VALID_MATCHING(i);
                pr[j] = k + 1;
            }
        }
    }

    if(num != n) {
        // Prepare for main loop
        for(Int i = 0; i < n; ++i) {
            d[i] = rinf;
            l[i] = EMPTY;
        }
        
        // Main loop ... each pass round this loop is similar to Dijkstra's
        // algorithm for solving the single source shortest path problem
        for(Int jord = 0; jord < n; ++jord) {
            if(jperm[jord] == EMPTY) {
                // JORD is next unmatched column
                // DMIN is the length of shortest path in the tree
                // CSP is the cost of the shortest augmenting path to unassigned row
                // IRN(ISP). The corresponding column index is JSP.
                DATA_T dmin = rinf, csp = rinf;
                Int isp, jsp;
                Int qlen = EMPTY, low = n, up = n;
                // Build shortest path tree starting from unassigned column (root) JORD
                Int j = jord;
                pr[j] = -2;
                
                // Scan column J
                // LiuKan: find the best unmatched `i` as `sp`, and all the matched i that is better than `sp`
                for(Int k = col_ptr[j]; k < col_ptr[j+1]; ++k) {
                    Int i = row_idx[k];
                    DATA_T dnew = values[k] - u[i];
                    if(dnew < csp) {
                        if(iperm[i] == EMPTY) {
                            csp = dnew;
                            isp = k;
                            jsp = j;
                        } else {
                            if(dnew < dmin) {
                                dmin = dnew;
                            }
                            d[i] = dnew;
                            qlen += 1;
                            q[qlen] = k;
                        }
                    }
                }

                // Initialize heap Q and Q2 with rows held in Q(1:QLEN)
                Int q0 = qlen;
                qlen = EMPTY;
                for(Int kk = 0; kk <= q0; ++kk) {  // LiuKan note: <= is not <
                    Int k = q[kk];
                    Int i = row_idx[k];
                    if(csp <= d[i]) {
                        d[i] = rinf;
                        continue;
                    }
                    if(d[i] <= dmin) {     // LiuKan: put in q2
                        low -= 1;
                        q[low] = i;
                        l[i] = low;        // LiuKan: l[i] is the position of `i` in `q`
                    } else {               // LiuKan: put in q
                        qlen += 1;
                        l[i] = qlen;       // LiuKan: l[i] is the position of `i` in `q`
                        mc64d(i, q, d, l); // LiuKan: init heap
                    }
                    // Update tree
                    Int jj = iperm[i];
                    out[jj] = k;
                    pr[jj] = j;
                }

                for(Int jdum = 0; jdum < num; ++ jdum) {
                    // If Q2 is empty, extract rows from Q
                    if(low == up) {
                        if(qlen == EMPTY) break;
                        Int i = q[0];
                        if(d[i] >= csp) break;
                        dmin = d[i];
                        do {                              // LiuKan: extract multiple minimums at a time
                            qlen = mc64e(qlen, q, d, l);  // LiuKan: extract from heap
                            low -= 1;
                            q[low] = i;
                            l[i] = low;
                            i = q[0];
                        } while((d[i] <= dmin) && (qlen != EMPTY));
                    }   

                    // Q0 is row whose distance D(Q0) to the root is smallest
                    q0 = q[up-1];              // LiuKan: extract from q2
                    DATA_T vj, dq0 = d[q0];
                    // Exit loop if path to Q0 is longer than the shortest augmenting path
                    if (dq0 >= csp) break;
                    up = up - 1;

                    // Scan column that matches with row Q0
                    j = iperm[q0];
                    vj = dq0 - values[jperm[j]] + u[q0];
                    for(Int k = col_ptr[j]; k < col_ptr[j + 1]; ++k) {
                        Int i = row_idx[k];
                        if(l[i] < up) {  // LiuKan: l[i] >= up means `i` is already in the augmented path
                            // DNEW is new cost
                            DATA_T dnew = vj + values[k] - u[i];
                            // Do not update D(I) if DNEW ge cost of shortest path
                            if(dnew < csp) {
                                if(iperm[i] == EMPTY) {
                                    // Row I is unmatched; update shortest path info
                                    csp = dnew;
                                    isp = k;
                                    jsp = j;
                                } else {
                                    // Row I is matched; do not update D(I) if DNEW is larger
                                    di = d[i];
                                    if((di > dnew) && (l[i] < low)) { // LiuKan: l[i] >= low means `i` is already in the augmented path or in the queue
                                        d[i] = dnew;
                                        if(dnew <= dmin) {
                                            Int lpos = l[i];
                                            if (lpos != EMPTY) {
                                                ASSERT(qlen != EMPTY);
                                                qlen = mc64f(lpos, qlen, q, d, l);
                                            }
                                            low = low - 1;
                                            q[low] = i;
                                            l[i] = low;
                                        } else {
                                            if(l[i] == EMPTY) {
                                                qlen = qlen + 1;
                                                l[i] = qlen;
                                            }
                                            mc64d(i, q, d, l);
                                        }
                                        // Update tree
                                        Int jj = iperm[i];
                                        out[jj] = k;
                                        pr[jj] = j;
                                    }
                                }
                            }
                        }
                    }
                }
                
                // If CSP = RINF, no augmenting path is found
                if(csp != rinf) {
                    // Find augmenting path by tracing backward in PR; update IPERM,JPERM
                    Int jj, k, i = row_idx[isp];
                    iperm[i] = jsp;
                    jperm[jsp] = isp;
                    ASSERT_VALID_MATCHING(i);
                    j = jsp;
                    num = num + 1;
                    for(;;) {
                        jj = pr[j];
                        if(jj == -2) break;
                        k = out[j];
                        i = row_idx[k];
                        iperm[i] = jj;
                        jperm[jj] = k;
                        ASSERT_VALID_MATCHING(i);
                        j = jj;
                    }
                    for(Int kk = up; kk < n; ++kk) {
                        i = q[kk];
                        u[i] = u[i] + d[i] - csp;
                    }
                }
                for(Int kk = low; kk < n; ++kk) {
                    Int i = q[kk];
                    d[i] = rinf;
                    l[i] = EMPTY;
                }
                for(Int kk = 0; kk <= qlen; ++kk) {
                    Int i = q[kk];
                    d[i] = rinf;
                    l[i] = EMPTY;
                }
                ASSERT(std::all_of(l, l + n, [](Int li) { return li == EMPTY; }));

            }
        } // End of main loop
    }
    // Set dual column variable in D(1:N)
    for(Int j = 0; j < n; ++j) {
        Int k = jperm[j];

        if(k != EMPTY) {
            ASSERT_EQUAL(iperm[row_idx[k]], j);
            d[j] = values[k] - u[row_idx[k]];
        } else {
            d[j] = zero;
        }
        if(iperm[j] == EMPTY) {
            u[j] = zero;
        }
    }
    return num;
}


/*
 * Translated from Fortran, with job = 5

C *** Copyright (c) 1999  Council for the Central Laboratory of the
C     Research Councils                                             ***
C *** Although every effort has been made to ensure robustness and  ***
C *** reliability of the subroutines in this MC64 suite, we         ***
C *** disclaim any liability arising through the use or misuse of   ***
C *** any of the subroutines.                                       ***
C *** Any problems?   Contact ...                                   ***
C     Iain Duff (I.Duff@rl.ac.uk) or                                ***
C     Jacko Koster (jacko.koster@uninett.no)                        ***
C
C  Purpose
C  =======
C
C This subroutine attempts to find a column permutation for an NxN
C sparse matrix A = {a_ij} that makes the permuted matrix have N
C entries on its diagonal.
C If the matrix is structurally nonsingular, the subroutine optionally
C returns a column permutation that maximizes the smallest element
C on the diagonal, maximizes the sum of the diagonal entries, or
C maximizes the product of the diagonal entries of the permuted matrix.
C For the latter option, the subroutine also finds scaling factors
C that may be used to scale the matrix so that the nonzero diagonal
C entries of the permuted matrix are one in absolute value and all the
C off-diagonal entries are less than or equal to one in absolute value.
C The natural logarithms of the scaling factors u(i), i=1..N, for the
C rows and v(j), j=1..N, for the columns are returned so that the
C scaled matrix B = {b_ij} has entries b_ij = a_ij * EXP(u_i + v_j).
C
C  Parameters
C  ==========
C
      INTEGER JOB,N,NE,NUM,LIW,LDW
      INTEGER IP(N+1),IRN(NE),CPERM(N),IW(LIW),ICNTL(10),INFO(10)
      DOUBLE PRECISION A(NE),DW(LDW)
C
C JOB is an INTEGER variable which must be set by the user to
C control the action. It is not altered by the subroutine.
C Possible values for JOB are:
C   1 Compute a column permutation of the matrix so that the
C     permuted matrix has as many entries on its diagonal as possible.
C     The values on the diagonal are of arbitrary size. HSL subroutine
C     MC21A/AD is used for this. See [1].
C   2 Compute a column permutation of the matrix so that the smallest
C     value on the diagonal of the permuted matrix is maximized.
C     See [3].
C   3 Compute a column permutation of the matrix so that the smallest
C     value on the diagonal of the permuted matrix is maximized.
C     The algorithm differs from the one used for JOB = 2 and may
C     have quite a different performance. See [2].
C   4 Compute a column permutation of the matrix so that the sum
C     of the diagonal entries of the permuted matrix is maximized.
C     See [3].
C   5 Compute a column permutation of the matrix so that the product
C     of the diagonal entries of the permuted matrix is maximized
C     and vectors to scale the matrix so that the nonzero diagonal
C     entries of the permuted matrix are one in absolute value and
C     all the off-diagonal entries are less than or equal to one in
C     absolute value. See [3].
C  Restriction: 1 <= JOB <= 5.
C
C N is an INTEGER variable which must be set by the user to the
C   order of the matrix A. It is not altered by the subroutine.
C   Restriction: N >= 1.
C
C NE is an INTEGER variable which must be set by the user to the
C   number of entries in the matrix. It is not altered by the
C   subroutine.
C   Restriction: NE >= 1.
C
C IP is an INTEGER array of length N+1.
C   IP(J), J=1..N, must be set by the user to the position in array IRN
C   of the first row index of an entry in column J. IP(N+1) must be set
C   to NE+1. It is not altered by the subroutine.
C
C IRN is an INTEGER array of length NE.
C   IRN(K), K=1..NE, must be set by the user to hold the row indices of
C   the entries of the matrix. Those belonging to column J must be
C   stored contiguously in the positions IP(J)..IP(J+1)-1. The ordering
C   of the row indices within each column is unimportant. Repeated
C   entries are not allowed. The array IRN is not altered by the
C   subroutine.
C
C A is a DOUBLE PRECISION array of length NE.
C   The user must set A(K), K=1..NE, to the numerical value of the
C   entry that corresponds to IRN(K).
C   It is not used by the subroutine when JOB = 1.
C   It is not altered by the subroutine.
C
C NUM is an INTEGER variable that need not be set by the user.
C   On successful exit, NUM will be the number of entries on the
C   diagonal of the permuted matrix.
C   If NUM < N, the matrix is structurally singular.
C
C CPERM is an INTEGER array of length N that need not be set by the
C   user. On successful exit, CPERM contains the column permutation.
C   Column ABS(CPERM(J)) of the original matrix is column J in the
C   permuted matrix, J=1..N. For the N-NUM  entries of CPERM that are
C   not matched the permutation array is set negative so that a full
C   permutation of the matrix is obtained even in the structurally
C   singular case.
C
C LIW is an INTEGER variable that must be set by the user to
C   the dimension of array IW. It is not altered by the subroutine.
C   Restriction:
C     JOB = 1 :  LIW >= 5N
C     JOB = 2 :  LIW >= 4N
C     JOB = 3 :  LIW >= 10N + NE
C     JOB = 4 :  LIW >= 5N
C     JOB = 5 :  LIW >= 5N
C
C IW is an INTEGER array of length LIW that is used for workspace.
C
C LDW is an INTEGER variable that must be set by the user to the
C   dimension of array DW. It is not altered by the subroutine.
C   Restriction:
C     JOB = 1 :  LDW is not used
C     JOB = 2 :  LDW >= N
C     JOB = 3 :  LDW >= NE
C     JOB = 4 :  LDW >= 2N + NE
C     JOB = 5 :  LDW >= 3N + NE
C
C DW is a DOUBLE PRECISION array of length LDW
C   that is used for workspace. If JOB = 5, on return,
C   DW(i) contains u_i, i=1..N, and DW(N+j) contains v_j, j=1..N.
C
C ICNTL is an INTEGER array of length 10. Its components control the
C   output of MC64A/AD and must be set by the user before calling
C   MC64A/AD. They are not altered by the subroutine.
C
C   ICNTL(1) must be set to specify the output stream for
C   error messages. If ICNTL(1) < 0, messages are suppressed.
C   The default value set by MC46I/ID is 6.
C
C   ICNTL(2) must be set by the user to specify the output stream for
C   warning messages. If ICNTL(2) < 0, messages are suppressed.
C   The default value set by MC46I/ID is 6.
C
C   ICNTL(3) must be set by the user to specify the output stream for
C   diagnostic messages. If ICNTL(3) < 0, messages are suppressed.
C   The default value set by MC46I/ID is -1.
C
C   ICNTL(4) must be set by the user to a value other than 0 to avoid
C   checking of the input data.
C   The default value set by MC46I/ID is 0.
C
C INFO is an INTEGER array of length 10 which need not be set by the
C   user. INFO(1) is set non-negative to indicate success. A negative
C   value is returned if an error occurred, a positive value if a
C   warning occurred. INFO(2) holds further information on the error.
C   On exit from the subroutine, INFO(1) will take one of the
C   following values:
C    0 : successful entry (for structurally nonsingular matrix).
C   +1 : successful entry (for structurally singular matrix).
C   +2 : the returned scaling factors are large and may cause
C        overflow when used to scale the matrix.
C        (For JOB = 5 entry only.)
C   -1 : JOB < 1 or JOB > 5.  Value of JOB held in INFO(2).
C   -2 : N < 1.  Value of N held in INFO(2).
C   -3 : NE < 1. Value of NE held in INFO(2).
C   -4 : the defined length LIW violates the restriction on LIW.
C        Value of LIW required given by INFO(2).
C   -5 : the defined length LDW violates the restriction on LDW.
C        Value of LDW required given by INFO(2).
C   -6 : entries are found whose row indices are out of range. INFO(2)
C        contains the index of a column in which such an entry is found.
C   -7 : repeated entries are found. INFO(2) contains the index of a
C        column in which such entries are found.
C  INFO(3) to INFO(10) are not currently used and are set to zero by
C        the routine.
C
C References:
C  [1]  I. S. Duff, (1981),
C       "Algorithm 575. Permutations for a zero-free diagonal",
C       ACM Trans. Math. Software 7(3), 387-390.
C  [2]  I. S. Duff and J. Koster, (1998),
C       "The design and use of algorithms for permuting large
C       entries to the diagonal of sparse matrices",
C       SIAM J. Matrix Anal. Appl., vol. 20, no. 4, pp. 889-901.
C  [3]  I. S. Duff and J. Koster, (1999),
C       "On algorithms for permuting large entries to the diagonal
C       of sparse matrices",
C       Technical Report RAL-TR-1999-030, RAL, Oxfordshire, England.
 */

static constexpr const char *ssingular_matrix_msg = "Error in MC64: structural singular matrix\n";
static constexpr const char *singular_matrix_msg = "Error in MC64: singular matrix\n";
static constexpr const char *out_of_range_format = "symmetric diagnal threshold should be in (0, 1): given %lf\n";
#define PRINT_SINGULAR DEBUG_PRINTF(ssingular_matrix_msg)
#define PRINT_NUMERIC_SINGULAR DEBUG_PRINTF(singular_matrix_msg)

template<typename DATA_T>
ErrorStatus mc64a(Int n, Int nnz, const Int* RSTR col_ptr, const Int* RSTR row_idx, const DATA_T* RSTR values, \
                          Int* riperm, real_t<DATA_T>* RSTR r, real_t<DATA_T>* RSTR c, real_t<DATA_T>* real_ptr, \
                          const swSparseTRFOptions* options) {
    using real_ptr_t = real_t<DATA_T>*;
    using intp_t = Int*;
    constexpr real_t<DATA_T> rinf = std::numeric_limits<real_t<DATA_T>>::max(), zero = 0;
    constexpr real_t<DATA_T> log_min = static_cast<real_t<DATA_T>>(-0x1.6233p+9); // -1023*log(2) < log_min < -1022*log(2)
    real_t<DATA_T> norm1 = 0, rinf_n = rinf / n;
    ErrorStatus ret = SWSPARSE_SUCCESS;
    real_ptr_t rwork, u, d, abs_max, nz_abs;
    intp_t jperm, out, pr, q, l, iwork;
    rwork = (real_ptr_t)swSparse_malloc(sizeof(real_t<DATA_T>) * (n + nnz));
    IF_ERR(rwork == nullptr) {
        return MALLOC_ERROR;
    }
    iwork = (intp_t)swSparse_malloc(sizeof(Int) * 5 * n);
    IF_ERR(iwork == nullptr) {
        return clean_return(MALLOC_ERROR, rwork);
    }
    jperm   = iwork;
    out     = iwork + n;
    pr      = iwork + n * 2;
    q       = iwork + n * 3;
    l       = iwork + n * 4;
    abs_max = rwork;
    nz_abs  = rwork + n;

    norm1 = mc64_preprocess(n, nnz, col_ptr, values, nz_abs, abs_max); // offload log computation

    for(Int j = 0; j < n; ++j) {
        real_t<DATA_T> fact = abs_max[j];
        IF_ERR(fact < log_min) {
            PRINT_NUMERIC_SINGULAR;
            return clean_return(SWSPARSE_INVALID_ARGS, rwork, iwork);
        }
        for(Int p = col_ptr[j]; p < col_ptr[j+1]; ++p) {
            nz_abs[p] = (nz_abs[p] >= log_min) ? (fact - nz_abs[p]) : rinf_n;
        }
    }

    Int num = mc64w(n, nnz, col_ptr, row_idx, nz_abs, riperm, jperm, out, pr, q, l, r, c);

    swSparse_free(iwork);

    if(num == n) {
        for(Int j = 0; j < n; ++j) {
            real_t<DATA_T> cj = c[j], cmax = abs_max[j];
            c[j] = cj - cmax;
        }
        // abs_max is not used now
        if(options->matching == SWSPARSE_MATCHING_MC64_SYM) {
            matrix_symmetrizer_t sym;
            ret = sym.select_candidates(n, nnz, col_ptr, row_idx, nz_abs, r, abs_max);
            swSparse_free(rwork);
            IF_ERR(ret != SWSPARSE_SUCCESS) {
                return ret;
            }
            ret = sym.symmetrize_matching(n, nnz, col_ptr, row_idx, riperm);
        } else {
            swSparse_free(rwork);
        }
    } else {
        PRINT_SINGULAR;
        ret = SWSPARSE_INVALID_ARGS;
    }
    *real_ptr = norm1;
    return ret;
}


template ErrorStatus mc64a<float>(Int n, Int nnz, \
    const Int* col_ptr, const Int* row_idx, const float* values, \
    Int* riperm, float* R, float* C, float* norm_1, const swSparseTRFOptions* options);
template ErrorStatus mc64a<double>(Int n, Int nnz, \
    const Int* col_ptr, const Int* row_idx, const double* values, \
    Int* riperm, double* R, double* C, double* norm_1, const swSparseTRFOptions* options);
template ErrorStatus mc64a<SComplex>(Int n, Int nnz, \
    const Int* col_ptr, const Int* row_idx, const SComplex* values, \
    Int* riperm, float* R, float* C, float* norm_1, const swSparseTRFOptions* options);
template ErrorStatus mc64a<DComplex>(Int n, Int nnz, \
    const Int* col_ptr, const Int* row_idx, const DComplex* values, \
    Int* riperm, double* R, double* C, double* norm_1, const swSparseTRFOptions* options);

} // namespace HSL_MC64

} // namespace swSparse