#include <stdarg.h>
#include <string.h>
#include <stdio.h>
#include "swSparse_base.h"
#include "internal/memory.h"
#include "internal/debug.h"

ErrorStatus swSparse_clean_return(ErrorStatus err, void *ptr, ...) {
    va_list args;
    va_start(args, ptr);
    while(ptr != NULL) {
        swSparse_free(ptr);
        ptr = va_arg(args, void*);
    }
    va_end(args);
    return err;
}

ErrorStatus swSparse_clean_return_s(ErrorStatus err, size_t size, void **ptr) {
	for(size_t i = 0; i < size; ++i) {
        swSparse_free_if(ptr[i]);
    }
    return err;
}

#if DEBUG_LEVEL > 0
// export
// common strings
const char swSparse_cstr_float[14] = "complex float";
const char swSparse_cstr_double[15] = "complex double";
const char swSparse_malloc_error_msg[58] = "swSparse out of memory: request %lu bytes in %s, line %d\n";
const char swSparse_int32_overflow[86] = "int32_t overflow with %lld. int64_t for nnz is not supported yet.\nin file %s line %d\n";
#endif
