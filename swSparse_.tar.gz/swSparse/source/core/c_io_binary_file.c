#include <stdio.h>
#include "swSparse_matrix.h"
#include "swSparse_auxiliary.h"
#include "internal/memory.h"
#include "internal/rename.h"
#include "internal/debug.h"
#include "internal/utils.h"

ErrorStatus swSparse_read_binary(Matrix *mat, const char *file_name) {
    ErrorStatus ret;
    FILE *file;
    file = fopen(file_name, "rb");
    IF_ERR(file == NULL) {
        DEBUG_PRINTF("Cannot open file %s\n", file_name);
        return SWSPARSE_IO_ERROR;
    }
    ret = swSparse_read_binary_opened(mat, file, file_name);
    fclose(file);
    return ret;
}

ErrorStatus swSparse_write_binary(Matrix mat, const char *file_name) {
    ErrorStatus ret;
    FILE *file;
    file = fopen(file_name, "wb");
    IF_ERR(file == NULL) {
        DEBUG_PRINTF("Cannot open file %s\n", file_name);
        return SWSPARSE_IO_ERROR;
    }
    ret = swSparse_write_binary_opened(mat, file, file_name);
    fclose(file);
    return ret;
}

typedef struct {
    Int rows, cols, nonzeros;
    MatrixFormatType format_type;
    MatrixElementType element_type;
    MatrixStatus status;
} header_t; 

ErrorStatus swSparse_read_binary_opened(Matrix *mat, FILE *file, const char *file_name) {
    header_t header;
    Matrix created;
    ErrorStatus ret;
    size_t esize, count = fread(&header, sizeof(header_t), 1, file);
    if(count != 1) {
        DEBUG_PRINTF("Error in reading file %s: failed to read header\n", file_name);
        return SWSPARSE_IO_ERROR;
    }
    esize = element_size(header.element_type);
    if((header.format_type == CSR) || (header.format_type == CSC)) {
#if DEBUG_LEVEL > 0
        const char *dim_names[2] = { "row", "column" };
        Int first = (header.format_type == CSR) ? 0 : 1;
#endif
        Int first_dim = (header.format_type == CSR) ? header.rows : header.cols;
        Int ordered;

        ret = new_csrc(&created, header.rows, header.cols, first_dim, header.nonzeros, header.element_type, esize);
        IF_ERR(ret != SWSPARSE_SUCCESS) {
            return ret;
        }
        count = fread(&ordered, sizeof(Int), 1, file);
        if(count != 1) {
            DEBUG_PRINTF("Error in reading file %s: failed to read ordered bit\n", file_name);
            swSparse_destroy(created);
            return SWSPARSE_IO_ERROR;
        }
        created->matrix.csrc->ordered = ordered;
        count = fread(created->matrix.csrc->offsets, sizeof(Int), first_dim + 1, file);
        if(count != (first_dim + 1)) {
            DEBUG_PRINTF("Error in reading file %s: failed to read %s offsets\n", file_name, dim_names[first]);
            swSparse_destroy(created);
            return SWSPARSE_IO_ERROR;
        }
        count = fread(created->matrix.csrc->indices, sizeof(Int), header.nonzeros, file);
        if(count != header.nonzeros) {
            DEBUG_PRINTF("Error in reading file %s: failed to read %s indices\n", file_name, dim_names[1 ^ first]);
            swSparse_destroy(created);
            return SWSPARSE_IO_ERROR;
        }
        count = fread(created->matrix.csrc->values, esize, header.nonzeros, file);
        if(count != header.nonzeros) {
            DEBUG_PRINTF("Error in reading file %s: failed to read values\n", file_name);
            swSparse_destroy(created);
            return SWSPARSE_IO_ERROR;
        }
    } else if(header.format_type == COO) {
        ret = new_coo(&created, header.rows, header.cols, header.nonzeros, header.element_type, esize);
        IF_ERR(ret != SWSPARSE_SUCCESS) {
            return ret;
        }
        count = fread(created->matrix.coo->row_indices, sizeof(Int), header.nonzeros, file);
        if(count != header.nonzeros) {
            DEBUG_PRINTF("Error in reading file %s: failed to read row offsets\n", file_name);
            swSparse_destroy(created);
            return SWSPARSE_IO_ERROR;
        }
        count = fread(created->matrix.coo->column_indices, sizeof(Int), header.nonzeros, file);
        if(count != header.nonzeros) {
            DEBUG_PRINTF("Error in reading file %s: failed to read column indices\n", file_name);
            swSparse_destroy(created);
            return SWSPARSE_IO_ERROR;
        }
        count = fread(created->matrix.coo->values, esize, header.nonzeros, file);
        if(count != header.nonzeros) {
            DEBUG_PRINTF("Error in reading file %s: failed to read values\n", file_name);
            swSparse_destroy(created);
            return SWSPARSE_IO_ERROR;
        }
    } else {
        DEBUG_PRINTF("Error in reading file %s: only CSR, CSC and COO are supported\n", file_name);
        return SWSPARSE_INVALID_ARGS;
    }

    created->status = header.status;
    created->format_type = header.format_type;
    *mat = created;
    return SWSPARSE_SUCCESS;
}

ErrorStatus swSparse_write_binary_opened(Matrix mat, FILE *file, const char *file_name) {
    header_t header;
    size_t esize, count;
    header.rows = mat->m;
    header.cols = mat->n;
    header.nonzeros = mat->nnz;
    header.element_type = mat->element_type;
    header.format_type = mat->format_type;
    header.status = mat->status;

    count = fwrite(&header, sizeof(header_t), 1, file);
    if(count != 1) {
        DEBUG_PRINTF("Error in reading file %s: failed to read header\n", file_name);
        return SWSPARSE_IO_ERROR;
    }
    esize = element_size(header.element_type);
    if((header.format_type == CSR) || (header.format_type == CSC)) {
#if DEBUG_LEVEL > 0
        const char *dim_names[2] = { "row", "column" };
        Int first = (header.format_type == CSR) ? 0 : 1;
#endif
        Int first_dim = (header.format_type == CSR) ? header.rows : header.cols;
        Int ordered = mat->matrix.csrc->ordered;

        count = fwrite(&ordered, sizeof(Int), 1, file);
        if(count != 1) {
            DEBUG_PRINTF("Error in writing file %s: failed to write ordered bit\n", file_name);
            return SWSPARSE_IO_ERROR;
        }
        count = fwrite(mat->matrix.csrc->offsets, sizeof(Int), first_dim + 1, file);
        if(count != (first_dim + 1)) {
            DEBUG_PRINTF("Error in writing file %s: failed to write %s offsets\n", file_name, dim_names[first]);
            return SWSPARSE_IO_ERROR;
        }
        count = fwrite(mat->matrix.csrc->indices, sizeof(Int), header.nonzeros, file);
        if(count != header.nonzeros) {
            DEBUG_PRINTF("Error in writing file %s: failed to write %s indices\n", file_name, dim_names[1 ^ first]);
            return SWSPARSE_IO_ERROR;
        }
        count = fwrite(mat->matrix.csrc->values, esize, header.nonzeros, file);
        if(count != header.nonzeros) {
            DEBUG_PRINTF("Error in writing file %s: failed to write values\n", file_name);
            return SWSPARSE_IO_ERROR;
        }
    } else if(header.format_type == COO) {
        count = fwrite(mat->matrix.coo->row_indices, sizeof(Int), header.nonzeros, file);
        if(count != header.nonzeros) {
            DEBUG_PRINTF("Error in writing file %s: failed to write row indices\n", file_name);
            return SWSPARSE_IO_ERROR;
        }
        count = fwrite(mat->matrix.coo->column_indices, sizeof(Int), header.nonzeros, file);
        if(count != header.nonzeros) {
            DEBUG_PRINTF("Error in writing file %s: failed to write column indices\n", file_name);
            return SWSPARSE_IO_ERROR;
        }
        count = fwrite(mat->matrix.coo->values, esize, header.nonzeros, file);
        if(count != header.nonzeros) {
            DEBUG_PRINTF("Error in writing file %s: failed to write values\n", file_name);
            return SWSPARSE_IO_ERROR;
        }
    } else {
        DEBUG_PRINTF("Error in writing file %s: only CSR, CSC and COO are supported\n", file_name);
        return SWSPARSE_INVALID_ARGS;
    }

    return SWSPARSE_SUCCESS;
}
