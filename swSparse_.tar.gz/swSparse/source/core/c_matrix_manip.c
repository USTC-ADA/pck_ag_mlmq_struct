#include<complex.h>
#include"swSparse_matrix.h"
#include"internal/memory.h"
#include"internal/rename.h"
#include"internal/utils.h"

ErrorStatus init_csrc_data(MatrixCSRC *matrix, Int m, Int n, Int ld, Int nnz, size_t value_size) {
    Int *copy_offsets;
    Int *copy_indices;
    void *copy_values;
    copy_offsets = (Int*)swSparse_malloc(sizeof(Int) * (ld + 1));
    IF_ERR(copy_offsets == NULL) {
        return MALLOC_ERROR;
    }
    if(nnz != 0) {
        copy_indices = (Int*)swSparse_malloc(sizeof(Int) * nnz);
        IF_ERR(copy_indices == NULL) {
            return clean_return(MALLOC_ERROR, copy_offsets);
        }
        copy_values = swSparse_malloc(value_size * nnz);
        IF_ERR(copy_values == NULL) {
            return clean_return(MALLOC_ERROR, copy_indices, copy_offsets);
        }
    } else {
        copy_indices = copy_values = NULL;
    }
    matrix->offsets = copy_offsets;
    matrix->indices = copy_indices;
    matrix->values = copy_values;
    matrix->ordered = false;
    matrix->ref_count = 1;
    return SWSPARSE_SUCCESS;
}

static ErrorStatus alloc_csrc(Matrix matrix, Int m, Int n, Int ld, Int nnz, size_t value_size) {
    ErrorStatus ret;         
    matrix->matrix.csrc = (MatrixCSRC*)swSparse_malloc(sizeof(MatrixCSRC));
    if(matrix->matrix.csrc == NULL) {
        return MALLOC_ERROR;
    }
    ret = init_csrc_data(matrix->matrix.csrc, m, n, ld, nnz, value_size);
    IF_ERR(ret != SWSPARSE_SUCCESS) {
        return clean_return(ret, matrix->matrix.csrc);
    }
    return SWSPARSE_SUCCESS;
}

ErrorStatus init_csrc(Matrix matrix, Int m, Int n, Int ld, Int nnz, \
                      MatrixElementType type, size_t value_size) {
    ErrorStatus ret = alloc_csrc(matrix, m, n, ld, nnz, value_size);
    if(ret == SWSPARSE_SUCCESS) {
        matrix->status = 0;
        matrix->m = m;
        matrix->n = n;
        matrix->nnz = nnz;
        matrix->element_type = type;
    }
    return ret;
}

ErrorStatus init_coo_data(MatrixCOO *matrix, Int m, Int n, Int nnz, size_t value_size) {
    Int *copy_row_indices;
    Int *copy_column_indices;
    void *copy_values;

    if(nnz != 0) {
        copy_row_indices = (Int*)swSparse_malloc(sizeof(Int) * nnz);
        IF_ERR(copy_row_indices == NULL) {  
            return MALLOC_ERROR;
        }
        copy_column_indices = (Int*)swSparse_malloc(sizeof(Int) * nnz);
        IF_ERR(copy_column_indices == NULL) {
            return clean_return(MALLOC_ERROR, copy_row_indices);
        }
        copy_values = swSparse_malloc(value_size * nnz);
        IF_ERR(copy_values == NULL) {
            return clean_return(MALLOC_ERROR, copy_column_indices, copy_row_indices);
        }
    } else {
        copy_row_indices = copy_column_indices = copy_values = NULL;
    }
    matrix->row_indices = copy_row_indices;
    matrix->column_indices = copy_column_indices;
    matrix->values = copy_values;
    matrix->ref_count = 1;
    return SWSPARSE_SUCCESS;
}

static ErrorStatus alloc_coo(Matrix matrix, Int m, Int n, Int nnz, size_t value_size) {
    ErrorStatus ret;
    matrix->matrix.coo = (MatrixCOO*)swSparse_malloc(sizeof(MatrixCOO));
    if(matrix->matrix.coo == NULL) {
        return MALLOC_ERROR;
    }
    ret = init_coo_data(matrix->matrix.coo, m, n, nnz, value_size);
    IF_ERR(ret != SWSPARSE_SUCCESS) {
        return clean_return(ret, matrix->matrix.coo);
    }
    return SWSPARSE_SUCCESS;
}

ErrorStatus init_coo(Matrix matrix, Int m, Int n, Int nnz, \
                     MatrixElementType type, size_t value_size) {
    ErrorStatus ret = alloc_coo(matrix, m, n, nnz, value_size);
    if(ret == SWSPARSE_SUCCESS) {
        matrix->status = 0;
        matrix->m = m;
        matrix->n = n;
        matrix->nnz = nnz;
        matrix->element_type = type;
        matrix->format_type = COO;
    }
    return ret;
}

ErrorStatus new_csrc(Matrix *matrix, Int m, Int n, Int ld, Int nnz, \
                          MatrixElementType type, size_t value_size) {
    Matrix created;
    ErrorStatus ret;

    created = (Matrix)swSparse_malloc(sizeof(MatrixData));
    IF_ERR(created == NULL) {
        return MALLOC_ERROR;
    }
    ret = init_csrc(created, m, n, ld, nnz, type, value_size);
    IF_ERR(ret != SWSPARSE_SUCCESS) {
        swSparse_free(created);
        return ret;
    }
    *matrix = created;
    return SWSPARSE_SUCCESS;
}

ErrorStatus new_coo(Matrix *matrix, Int m, Int n, Int nnz, \
                    MatrixElementType type, size_t value_size) {
    Matrix created;
    ErrorStatus ret;

    created = (Matrix)swSparse_malloc(sizeof(MatrixData));
    IF_ERR(created == NULL) {
        return MALLOC_ERROR;
    }
    ret = init_coo(created, m, n, nnz, type, value_size);
    IF_ERR(ret != SWSPARSE_SUCCESS) {
        swSparse_free(created);
        return ret;
    }
    *matrix = created;
    return SWSPARSE_SUCCESS;
}

static ErrorStatus create_csrc(Matrix *matrix, Int m, Int n, Int ld, Int nnz, \
                       Int *offsets, Int *indices, void *values, \
                       MatrixElementType type, size_t value_size) {
    ErrorStatus ret = new_csrc(matrix, m, n, ld, nnz, type, value_size);
    if(ret == SWSPARSE_SUCCESS) {
        Matrix created = *matrix;
        swSparse_memcpy(created->matrix.csrc->offsets, offsets, sizeof(Int) * (ld + 1));
        swSparse_memcpy(created->matrix.csrc->indices, indices, sizeof(Int) * nnz);
        swSparse_memcpy(created->matrix.csrc->values, values, value_size * nnz);
    }
    return ret;
}

static ErrorStatus create_coo(Matrix *matrix, Int m, Int n, Int nnz, \
                              Int *row_indices, Int *column_indices, void *values, \
                              MatrixElementType type, size_t value_size) {
    ErrorStatus ret = new_coo(matrix, m, n, nnz, type, value_size);
    if(ret == SWSPARSE_SUCCESS) {
        Matrix created = *matrix;
        swSparse_memcpy(created->matrix.coo->row_indices, row_indices, sizeof(Int) * nnz);
        swSparse_memcpy(created->matrix.coo->column_indices, column_indices, sizeof(Int) * nnz);
        swSparse_memcpy(created->matrix.coo->values, values, value_size * nnz);
    }
    return ret;
}


ErrorStatus swSparse_ensure_ownership_csrc(Matrix mat) {
    MatrixCSRC* data = mat->matrix.csrc;
    ErrorStatus ret = SWSPARSE_SUCCESS;
    int ld = (mat->format_type == CSR) ? mat->m : mat->n;
    if(data->ref_count > 1) {
        size_t value_size = element_size(mat->element_type);
        ret = alloc_csrc(mat, mat->m, mat->n, ld, mat->nnz, value_size);
        if(ret == SWSPARSE_SUCCESS) {
            swSparse_memcpy(mat->matrix.csrc->offsets, data->offsets, sizeof(Int) * (ld + 1));
            swSparse_memcpy(mat->matrix.csrc->indices, data->indices, sizeof(Int) * mat->nnz);
            swSparse_memcpy(mat->matrix.csrc->values, data->values, value_size * mat->nnz);
            mat->matrix.csrc->ordered = data->ordered;
            -- data->ref_count;
        }
    }
    return ret;
}

ErrorStatus swSparse_ensure_ownership_coo(Matrix mat) {
    MatrixCOO* data = mat->matrix.coo;
    ErrorStatus ret = SWSPARSE_SUCCESS;
    if(data->ref_count > 1) {
        size_t value_size = element_size(mat->element_type);
        ret = alloc_coo(mat, mat->m, mat->n, mat->nnz, value_size);
        if(ret == SWSPARSE_SUCCESS) {
            swSparse_memcpy(mat->matrix.coo->row_indices, data->row_indices, sizeof(Int) * mat->nnz);
            swSparse_memcpy(mat->matrix.coo->column_indices, data->column_indices, sizeof(Int) * mat->nnz);
            swSparse_memcpy(mat->matrix.coo->values, data->values, value_size * mat->nnz);
            -- data->ref_count;
        }
    }
    return ret;
}

#define DATA_TYPE_S
#include "c_matrix_manip.inl"
#undef DATA_TYPE_S
#define DATA_TYPE_D
#include "c_matrix_manip.inl"
#undef DATA_TYPE_D
#define DATA_TYPE_C
#include "c_matrix_manip.inl"
#undef DATA_TYPE_C
#define DATA_TYPE_Z
#include "c_matrix_manip.inl"
#undef DATA_TYPE_Z

static inline size_t decrease_ref_csrc(MatrixCSRC* matrix, void **to_free) {
    if(--(matrix->ref_count) == 0) {
        to_free[0] = matrix;
        to_free[1] = matrix->offsets;
        to_free[2] = matrix->values;
        to_free[3] = matrix->indices;
        return 4;
    }
    return 0;
}

static inline size_t decrease_ref_coo(MatrixCOO* matrix, void **to_free) {
    if(--(matrix->ref_count) == 0) {
        to_free[0] = matrix;
        to_free[1] = matrix->values;
        to_free[2] = matrix->row_indices;
        to_free[3] = matrix->column_indices;
        return 4;
    }
    return 0;
}

ErrorStatus swSparse_destruct(Matrix matrix) {
    void *to_free[10];
    size_t size = 0;
    ErrorStatus ret = SWSPARSE_SUCCESS;
    switch(matrix->format_type) {
    case CSR:
    case CSC:
        size = decrease_ref_csrc(matrix->matrix.csrc, to_free);
        break;
    case COO:
        size = decrease_ref_coo(matrix->matrix.coo, to_free);
        break;
    case SWCOO:
        to_free[0] = matrix->matrix.swcoo;
        to_free[1] = matrix->matrix.swcoo->row_idx;
        to_free[2] = matrix->matrix.swcoo->col_idx;
        to_free[3] = matrix->matrix.swcoo->value;
        to_free[4] = matrix->matrix.swcoo->tasks;
        size = 5;
        break;
    case SLTCOO:
        to_free[0] = matrix->matrix.sltcoo;
        to_free[1] = matrix->matrix.sltcoo->level;
        to_free[2] = matrix->matrix.sltcoo->plevel;
        to_free[3] = matrix->matrix.sltcoo->_cnt;
        to_free[4] = matrix->matrix.sltcoo->_idx;
        to_free[5] = matrix->matrix.sltcoo->values;
        to_free[6] = matrix->matrix.sltcoo->row_indices;
        to_free[7] = matrix->matrix.sltcoo->column_indices;
        size = 8;
        break;
    case LU_SUPERNODES:
        to_free[0] = matrix->matrix.lusuper;
        to_free[1] = matrix->matrix.lusuper->l_values;
        to_free[2] = matrix->matrix.lusuper->l_indices;
        to_free[3] = matrix->matrix.lusuper->l_i_offsets;
        to_free[4] = matrix->matrix.lusuper->u_values;
        to_free[5] = matrix->matrix.lusuper->u_col_offsets;
        to_free[6] = matrix->matrix.lusuper->subtrees;
        to_free[7] = matrix->matrix.lusuper->snode_status;
        to_free[8] = matrix->matrix.lusuper->task_queue;
        size = 9;
        break;
    default:
        ret = SWSPARSE_INVALID_ARGS;
    }
    return swSparse_clean_return_s(ret, size, to_free);
}

ErrorStatus swSparse_destroy(Matrix matrix) {
    swSparse_destruct(matrix);
	swSparse_free(matrix);
    return SWSPARSE_SUCCESS;
}

ErrorStatus swSparse_copy(Matrix old_mat, Matrix *new_mat) {
    Matrix created;
    switch(old_mat->format_type) {
    case CSR:
    case CSC:
        created = (Matrix)swSparse_malloc(sizeof(MatrixData));
        IF_ERR(created == NULL) {
            return MALLOC_ERROR;
        }
        created->m = old_mat->m;
        created->n = old_mat->n;
        created->nnz = old_mat->nnz;
        created->format_type = old_mat->format_type;
        created->element_type = old_mat->element_type;
        created->status = old_mat->status;
        created->matrix.csrc = old_mat->matrix.csrc;
        old_mat->matrix.csrc->ref_count ++;
        break;
    case COO:
        created = (Matrix)swSparse_malloc(sizeof(MatrixData));
        IF_ERR(created == NULL) {
            return MALLOC_ERROR;
        }
        created->m = old_mat->m;
        created->n = old_mat->n;
        created->nnz = old_mat->nnz;
        created->format_type = old_mat->format_type;
        created->element_type = old_mat->element_type;
        created->status = old_mat->status;
        created->matrix.coo = old_mat->matrix.coo;
        old_mat->matrix.coo->ref_count ++;
        break;
    default:
        DEBUG_PRINTF("Invalid matrix format: only CSR, CSC and COO are supported in matrix copy\n");
        return SWSPARSE_INVALID_ARGS;
    }
    *new_mat = created;
    return SWSPARSE_SUCCESS;
}

ErrorStatus swSparse_deep_copy(Matrix old_mat, Matrix *new_mat) {
    Matrix temp;
    ErrorStatus ret = swSparse_copy(old_mat, &temp);
    if(ret == SWSPARSE_SUCCESS) {
        switch (old_mat->format_type) {
        case CSR:
        case CSC:
            ret = swSparse_ensure_ownership_csrc(temp);
            break;
        case COO:
            ret = swSparse_ensure_ownership_coo(temp);
            break;
        default:
            break;
        }
    }
    if(ret == SWSPARSE_SUCCESS) {
        *new_mat = temp;
    }
    return ret;
}
