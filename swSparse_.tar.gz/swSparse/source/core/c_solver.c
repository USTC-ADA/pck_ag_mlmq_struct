#include "swSparse.h"
#include "internal/rename.h"
#include "internal/memory.h"
#include "internal/debug.h"
#include "internal/spblas_common.h"

#define DATA_TYPE_S
#include "c_solver.inl"
#undef DATA_TYPE_S
#define DATA_TYPE_D
#include "c_solver.inl"
#undef DATA_TYPE_D
#define DATA_TYPE_C
#include "c_solver.inl"
#undef DATA_TYPE_C
#define DATA_TYPE_Z
#include "c_solver.inl"
#undef DATA_TYPE_Z

ErrorStatus
swSparse_create_solver(swSparseSolver *solver, swSparseMatrix a, \
                       const swSparseSolverOptions* options) {
    ErrorStatus ret; 
    Int n = a->n; 
    swSparseSolver s = (swSparseSolver)swSparse_malloc(sizeof(swSparseSolverData)); 
    IF_ERR(s == NULL) { 
        return MALLOC_ERROR; 
    }
    if((options->solver_type == SWSPARSE_LOWER_TRI) || (options->solver_type == SWSPARSE_UPPER_TRI)) {
        s->xiperm = (Int*)swSparse_malloc(sizeof(Int) * n * 2); 
        s->biperm = s->xiperm + n; 
        IF_ERR(s->xiperm == NULL) { 
            return clean_return(ret, s); 
        } 
    

        swSparseTRSVOptions trsv_options;
        trsv_options.expected_ncall = options->expected_ncall;
        trsv_options.transpose      = options->transpose;
        trsv_options.uplo           = options->solver_type;
        trsv_options.diagnal        = SWSPARSE_GENERAL_DIAG;
            
        ret = swSparse_trsv_inspect(a, &s->lu, s->xiperm, s->biperm, &trsv_options); 
        IF_ERR(ret != SWSPARSE_SUCCESS) { 
            return clean_return(ret, s, s->xiperm); 
        } 
    }
    //s->solve_options = (void*)options;
    swSparseTRSMOptions tmp_options;
	tmp_options.expected_nvec = options->expected_nvec;
    tmp_options.expected_ncall = options->expected_ncall;
    tmp_options.transpose = options->transpose;
    tmp_options.uplo = options->uplo;
    tmp_options.diagnal = options->diagnal;
    s->solve_options = tmp_options;
	
	*solver = s; 
    return SWSPARSE_SUCCESS;
}

ErrorStatus
swSparse_destroy_solver(swSparseSolver solver) {
    //swSparse_destroy(solver->lu);
    if(solver->lu != NULL) {
        swSparse_destroy(solver->lu);
    }
    if(solver->rscale != NULL) {
        swSparse_free(solver->rscale);
    }
    swSparse_free(solver->xiperm);
    swSparse_free(solver);
    return SWSPARSE_SUCCESS;
}

