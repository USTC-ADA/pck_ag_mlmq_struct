#include "swSparse.h"
#include "internal/rename.h"
#include "internal/memory.h"
#include "internal/debug.h"
#include "internal/transform.h"
#include "internal/spblas_common.h"
#include "internal/spmv_common.h"
#include "internal/spmv_param.h"


using namespace swSparse;

//预处理函数入口,输入参数为CSR格式的稀疏矩阵
ErrorStatus swSparse_mv_inspect(Matrix old_mat, Matrix *new_mat,const swSparseMVOptions* options) {
    switch(old_mat->format_type) {
    case CSR:
        if (old_mat->nnz < seq_nnz){
            //此处为结合自动调优的分支,当矩阵内非零元数小于阈值时,直接在主核执行串行CSR计算更快,直接调用将CSR格式拷贝一遍的函数
            return swSparse_mv_inspect_to_csr(old_mat, new_mat, options);
        }
        else{
            //当矩阵内非零元数足够大时,使用swcoo计算性能显著高于主核CSR,调用转换至swcoo的预处理函数
            return swSparse_mv_inspect_to_swcoo(old_mat, new_mat, options);
        }
    default:
        return SWSPARSE_INVALID_ARGS;
    }
}


#define DATA_TYPE_S
#include "c_SpMV.inl"
#undef DATA_TYPE_S
#define DATA_TYPE_D
#include "c_SpMV.inl"
#undef DATA_TYPE_D
#define DATA_TYPE_C
#include "c_SpMV.inl"
#undef DATA_TYPE_C
#define DATA_TYPE_Z
#include "c_SpMV.inl"
#undef DATA_TYPE_Z