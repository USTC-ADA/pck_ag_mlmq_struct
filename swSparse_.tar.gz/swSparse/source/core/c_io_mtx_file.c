#include <stdio.h>
#include <string.h>
#include <complex.h>
#include "swSparse_matrix.h"
#include "swSparse_auxiliary.h"
#include "internal/memory.h"
#include "internal/rename.h"
#include "internal/debug.h"
#include "internal/utils.h"


static const char format_error[] = "in %s: Invalid format, use default COO. (The format can only be CSR, CSC or COO)\n";

typedef enum {
    REAL, COMPLEX, PATTERN
} value_t;
typedef enum {
    GENERAL, SYMMETRIC, SKEW_SYMMETRIC, HERMITIAN
} sym_t;


#define MY_CMPLX(x, y) ((x) + I * (y))

#define READ_ELEMENTS_SYM(ELEMENT_TYPE, DATA_T, REAL_T, VALUE, SYM, NMEMBER, FORMAT, ...)  { \
        ret = new_coo(&created, rows, cols, nonzeros * 2, ELEMENT_TYPE, sizeof(DATA_T)); \
        if(ret == SWSPARSE_SUCCESS) { \
            Int *row_idx = created->matrix.coo->row_indices; \
            Int *col_idx = created->matrix.coo->column_indices; \
            DATA_T *values = (DATA_T*)created->matrix.coo->values; \
            for(i = 0, j = nonzeros; i < nonzeros; ++i) { \
                REAL_T real, imag; \
                if(fscanf(file, FORMAT, __VA_ARGS__) != NMEMBER) { \
                    DEBUG_PRINTF("Format error in file %s: Failed to read the %d-th nonzero\n", file_name, i); \
                    swSparse_destroy(created); \
                    return SWSPARSE_IO_ERROR; \
                } \
                values[i] = VALUE; \
                --row_idx[i]; \
                --col_idx[i]; \
                if(row_idx[i] != col_idx[i]) { \
                    values[j] = SYM; \
                    row_idx[j] = col_idx[i]; \
                    col_idx[j] = row_idx[i]; \
                    ++j; \
                } \
            } \
            created->nnz = j; \
            if(j > 0) { \
                created->matrix.coo->row_indices =    (Int*)shrink_alloc(row_idx, sizeof(Int) * j, sizeof(Int) * 2 * nonzeros); \
                created->matrix.coo->column_indices = (Int*)shrink_alloc(col_idx, sizeof(Int) * j, sizeof(Int) * 2 * nonzeros); \
                created->matrix.coo->values =               shrink_alloc(values, sizeof(DATA_T) * j, sizeof(DATA_T) * 2 * nonzeros); \
            } \
        } \
    } 
    
#define READ_ELEMENTS_GEN(ELEMENT_TYPE, DATA_T, REAL_T, VALUE, NMEMBER, FORMAT, ...)  { \
        ret = new_coo(&created, rows, cols, nonzeros, ELEMENT_TYPE, sizeof(DATA_T)); \
        if(ret == SWSPARSE_SUCCESS) { \
            Int *row_idx = created->matrix.coo->row_indices; \
            Int *col_idx = created->matrix.coo->column_indices; \
            DATA_T *values = (DATA_T*)created->matrix.coo->values; \
            for(i = 0; i < nonzeros; ++i) { \
                REAL_T real, imag; \
                if(fscanf(file, FORMAT, __VA_ARGS__) != NMEMBER) { \
                    DEBUG_PRINTF("Format error in file %s: Failed to read the %d-th nonzero\n", file_name, i); \
                    swSparse_destroy(created); \
                    return SWSPARSE_IO_ERROR; \
                } \
                values[i] = VALUE; \
                --row_idx[i]; \
                --col_idx[i]; \
            } \
        } \
    }
        
        
static ErrorStatus read_mtx_file_impl(Matrix *mat, FILE *file, const char *file_name, Bool single, MatrixFormatType out_format) {
    static const char delim[7] = { 0x20, 0x0c, 0x0a, 0x0d, 0x09, 0x0b, '\0' };
    char line[1024];
    char *head, *type, *format, *value_type, *symmetry;
    Int i, j, rows, cols, nonzeros;
    value_t vt;
    sym_t st;
    ErrorStatus ret = SWSPARSE_SUCCESS;
    Matrix created;

    if(NULL == fgets(line, 1024, file)){
        DEBUG_PRINTF("Format error in file %s: No header has been found in the first line\n", file_name);
        return SWSPARSE_IO_ERROR;
    }
    str_to_lower(line);
    head = strtok(line, delim);
    type = strtok(NULL, delim);
    format = strtok(NULL, delim);
    value_type = strtok(NULL, delim);
    symmetry = strtok(NULL, delim);

    if(strcmp(head, "%%matrixmarket") != 0 || strcmp(type, "matrix") != 0 || strcmp(format, "coordinate") != 0) {
        DEBUG_PRINTF("Format error in file %s: Must be Matrix Market coordinate matrix\n", file_name);
        return SWSPARSE_IO_ERROR;
    }

    if((strcmp(value_type, "real") == 0) || (strcmp(value_type, "integer") == 0)) {
        vt = REAL;
    } else if (strcmp(value_type, "complex") == 0) {
        vt = COMPLEX;
    } else if (strcmp(value_type, "pattern") == 0) {
        vt = PATTERN;
    } else {
        DEBUG_PRINTF("Format error in file %s: Unrecognized value type %s\n", file_name, value_type);
        return SWSPARSE_IO_ERROR;
    }

    if(strcmp(symmetry, "general") == 0) {
        st = GENERAL;
    } else if (strcmp(symmetry, "symmetric") == 0) {
        st = SYMMETRIC;
    } else if (strcmp(symmetry, "skew-symmetric") == 0) {
        st = SKEW_SYMMETRIC;
    } else if (strcmp(symmetry, "hermitian") == 0) {
        st = HERMITIAN;
    } else {
        DEBUG_PRINTF("Format error in file %s: Unrecognized symmetry type %s\n", file_name, symmetry);
        return SWSPARSE_IO_ERROR;
    }
    
    /* skip comments */
    while(strstr(line, "%") != NULL) {
        if(NULL == fgets(line, 1024, file)){
            DEBUG_PRINTF("Format error in file %s: The number of rows, columns and nonzeros cannot be found\n", file_name);
            return SWSPARSE_IO_ERROR;
        }
    }
    if(sscanf(line, "%d%d%d", &rows, &cols, &nonzeros) != 3) {
        DEBUG_PRINTF("Format error in file %s: The number of rows, columns and nonzeros cannot be found\n", file_name);
        return SWSPARSE_IO_ERROR;
    }

    if(single) {
        switch (vt) {
        case REAL:
            switch (st) {
            case GENERAL:
                READ_ELEMENTS_GEN(REAL_SINGLE, float, float, real, \
                    3, "%d%d%f", &row_idx[i], &col_idx[i], &real) 
                break;
            case SYMMETRIC:
                READ_ELEMENTS_SYM(REAL_SINGLE, float, float, real, real, \
                    3, "%d%d%f", &row_idx[i], &col_idx[i], &real) 
                break;
            case SKEW_SYMMETRIC:
                READ_ELEMENTS_SYM(REAL_SINGLE, float, float, real, -real, \
                    3, "%d%d%f", &row_idx[i], &col_idx[i], &real) 
                break;
            default:
                UNREACHABLE;
            }
            break;
        case COMPLEX:
            switch (st) {
            case GENERAL:
                READ_ELEMENTS_GEN(COMPLEX_SINGLE, float complex, float, MY_CMPLX(real, imag),  \
                    4, "%d%d%f%f", &row_idx[i], &col_idx[i], &real, &imag) 
                break;
            case SYMMETRIC:
                READ_ELEMENTS_SYM(COMPLEX_SINGLE, float complex, float, \
                    MY_CMPLX(real, imag), MY_CMPLX(real, imag), \
                    4, "%d%d%f%f", &row_idx[i], &col_idx[i], &real, &imag) 
                break;
            case SKEW_SYMMETRIC:
                READ_ELEMENTS_SYM(COMPLEX_SINGLE, float complex, float, \
                    MY_CMPLX(real, imag), MY_CMPLX(-real, -imag), \
                    4, "%d%d%f%f", &row_idx[i], &col_idx[i], &real, &imag) 
                break;
            case HERMITIAN:
                READ_ELEMENTS_SYM(COMPLEX_SINGLE, float complex, float, \
                    MY_CMPLX(real, imag), MY_CMPLX(real, -imag), \
                    4, "%d%d%f%f", &row_idx[i], &col_idx[i], &real, &imag) 
                break;
            default:
                UNREACHABLE;
            }
            break;
        case PATTERN:
            switch (st) {
            case GENERAL:
                READ_ELEMENTS_GEN(REAL_SINGLE, float, float, 1.0f, \
                    2, "%d%d", &row_idx[i], &col_idx[i]) 
                break;
            case SYMMETRIC:
                READ_ELEMENTS_SYM(REAL_SINGLE, float, float, 1.0f, 1.0f, \
                    2, "%d%d", &row_idx[i], &col_idx[i]) 
                break;
            case SKEW_SYMMETRIC:
                READ_ELEMENTS_SYM(REAL_SINGLE, float, float, 1.0f, -1.0f, \
                    2, "%d%d", &row_idx[i], &col_idx[i]) 
                break;\
            default:
                UNREACHABLE;
            }
            break;
        default:
            UNREACHABLE;
        }
    } else {
        switch (vt) {
        case REAL:
            switch (st) {
            case GENERAL:
                READ_ELEMENTS_GEN(REAL_DOUBLE, double, double, real, \
                    3, "%d%d%lf", &row_idx[i], &col_idx[i], &real) 
                break;
            case SYMMETRIC:
                READ_ELEMENTS_SYM(REAL_DOUBLE, double, double, real, real, \
                    3, "%d%d%lf", &row_idx[i], &col_idx[i], &real) 
                break;
            case SKEW_SYMMETRIC:
                READ_ELEMENTS_SYM(REAL_DOUBLE, double, double, real, -real, \
                    3, "%d%d%lf", &row_idx[i], &col_idx[i], &real) 
                break;
            default:
                UNREACHABLE;
            }
            break;
        case COMPLEX:
            switch (st) {
            case GENERAL:
                READ_ELEMENTS_GEN(COMPLEX_DOUBLE, double complex, double, MY_CMPLX(real, imag),  \
                    4, "%d%d%lf%lf", &row_idx[i], &col_idx[i], &real, &imag) 
                break;
            case SYMMETRIC:
                READ_ELEMENTS_SYM(COMPLEX_DOUBLE, double complex, double, \
                    MY_CMPLX(real, imag), MY_CMPLX(real, imag), \
                    4, "%d%d%lf%lf", &row_idx[i], &col_idx[i], &real, &imag) 
                break;
            case SKEW_SYMMETRIC:
                READ_ELEMENTS_SYM(COMPLEX_DOUBLE, double complex, double, \
                    MY_CMPLX(real, imag), MY_CMPLX(-real, -imag), \
                    4, "%d%d%lf%lf", &row_idx[i], &col_idx[i], &real, &imag) 
                break;
            case HERMITIAN:
                READ_ELEMENTS_SYM(COMPLEX_DOUBLE, double complex, double, \
                    MY_CMPLX(real, imag), MY_CMPLX(real, -imag), \
                    4, "%d%d%lf%lf", &row_idx[i], &col_idx[i], &real, &imag) 
                break;
            default:
                UNREACHABLE;
            }
            break;
        case PATTERN:
            switch (st) {
            case GENERAL:
                READ_ELEMENTS_GEN(REAL_DOUBLE, double, double, 1.0, \
                    2, "%d%d", &row_idx[i], &col_idx[i]) 
                break;
            case SYMMETRIC:
                READ_ELEMENTS_SYM(REAL_DOUBLE, double, double, 1.0, 1.0, \
                    2, "%d%d", &row_idx[i], &col_idx[i]) 
                break;
            case SKEW_SYMMETRIC:
                READ_ELEMENTS_SYM(REAL_DOUBLE, double, double, 1.0, -1.0, \
                    2, "%d%d", &row_idx[i], &col_idx[i]) 
                break;\
            default:
                UNREACHABLE;
            }
            break;
        default:
            UNREACHABLE;
        }
    }
    
    if(out_format == SWSPARSE_CSC) {
        ret = swSparse_convert_csc(created, mat);
        swSparse_destroy(created);
    } else if(out_format == SWSPARSE_CSR) {
        ret = swSparse_convert_csr(created, mat);
        swSparse_destroy(created);
    } else {
        if(out_format != SWSPARSE_COO) {
            DEBUG_PRINTF(format_error, "swSparse_read_mtx_impl");
        }
        *mat = created;
    }

    return ret;
}


ErrorStatus swSparse_read_mtx_opened(Matrix *mat, FILE *file, const char *file_name, Int prec, MatrixFormatType format) {
    if(prec == SWSPARSE_DOUBLE){
        return read_mtx_file_impl(mat, file, file_name, false, format);
    } else if(prec == SWSPARSE_SINGLE) {
        return read_mtx_file_impl(mat, file, file_name, true, format);
    } else return SWSPARSE_INVALID_ARGS;
}

ErrorStatus swSparse_read_mtx(Matrix *mat, const char *file_name, Int prec, MatrixFormatType format) {
    ErrorStatus ret;
    FILE *file;
    if((prec != SWSPARSE_SINGLE) && (prec != SWSPARSE_DOUBLE)) {
        return SWSPARSE_INVALID_ARGS;
    }
    file = fopen(file_name, "r");
    IF_ERR(file == NULL) {
        DEBUG_PRINTF("Cannot open file %s\n", file_name);
        return SWSPARSE_IO_ERROR;
    }
    ret = swSparse_read_mtx_opened(mat, file, file_name, prec, format);
    fclose(file);
    return ret;
}


ErrorStatus swSparse_read_mtx_cached(Matrix *mat, const char *file_name, const char *directory, \
                Int prec, MatrixFormatType format) {
    ErrorStatus ret = SWSPARSE_SUCCESS, cache_ret = SWSPARSE_SUCCESS;
    char cache_file_name[1024], suffix[] = ".dcsr";
    int l1, l2, p, q, file_name_len;

    if(prec == SWSPARSE_SINGLE) {
        suffix[1] = 's';
    } else if(prec != SWSPARSE_DOUBLE) {
        return SWSPARSE_INVALID_ARGS;
    }

    if(format == SWSPARSE_CSC) {
        suffix[4] = 'c';
    } else if(format != SWSPARSE_CSR) {
        suffix[3] = suffix[4] = 'o';
        if(format != SWSPARSE_COO) {
            DEBUG_PRINTF(format_error, "swSparse_read_mtx_cached");
        }
    }

    l1 = strlen(file_name);
    l2 = strlen(directory);
    for(p = l1 - 1; p > 0 && file_name[p-1] != '/'; -- p);
    file_name_len = l1 - p;
    if(file_name_len + l2 + 7 > 1024) {
        DEBUG_PRINTF("in swSparse_read_mtx_cached: file path to long.\n");
        return SWSPARSE_IO_ERROR;
    }
    strcpy(cache_file_name, directory);
    q = l2;
    cache_file_name[q++] = '/';
    strcpy(cache_file_name + q, file_name + p);
    q += file_name_len;
    strcpy(cache_file_name + q, suffix);
    
    // try to read cache file
    FILE *file = fopen(cache_file_name, "r");
    IF_ERR(file == NULL) { // first time
        cache_ret = SWSPARSE_IO_ERROR;
    } else {
        cache_ret = swSparse_read_binary_opened(mat, file, cache_file_name);
        fclose(file);
    }

    IF_ERR(cache_ret != SWSPARSE_SUCCESS) {
        DEBUG_PRINTF("Cannot read cache file %s Read original file %s\n", cache_file_name, file_name);
        ret = swSparse_read_mtx(mat, file_name, prec, format);
        if(ret == SWSPARSE_SUCCESS) {
            cache_ret = swSparse_write_binary(*mat, cache_file_name);
            IF_ERR(cache_ret != SWSPARSE_SUCCESS) {
                DEBUG_PRINTF("Cannot write cache file %s (Ignored)\n", cache_file_name, file_name);
            }
        }
    }

    return ret;
}
