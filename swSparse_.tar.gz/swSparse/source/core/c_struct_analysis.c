#include "swSparse.h"
#include "internal/rename.h"
#include "internal/memory.h"
#include "internal/debug.h"

ErrorStatus
swSparse_ilu_analysis(swSparseInt iluk, swSparseInt npoints, \
                    const swSparseInt (*stencil)[3], swSparseInt *l_npoints, swSparseInt (**l_stencil_pos)[3], \
                    swSparseInt *u_npoints, swSparseInt (**u_stencil_pos)[3])
{
	if (iluk == 1)
	{
		int i, j, k;
		int oi, oj, ok;
		int ti, tj, tk;
		int v[7][7][7];
		int nnz = npoints, lnz, rnz;
		int annz = 0, alnz, arnz;
		for (i = 0; i < 7; i++)
		for (j = 0; j < 7; j++)
		for (k = 0; k < 7; k++)
		{
			v[i][j][k] = -1;
		}

		//get lnz
		lnz = 0;
		for (lnz = 0; lnz < nnz; lnz++)
		{
			oi = stencil[lnz][0];
			oj = stencil[lnz][1];
			ok = stencil[lnz][2];
			if (oi < -1 || oi > 1 || oj < -1 || oj > 1 || ok < -1 || ok > 1)
			{
				DEBUG_PRINTF("Error: Invalid stencil case! Ilu1 does not support stencil beyond a 3-3-3 cube!\n");
				return SWSPARSE_INVALID_ARGS;
			}
			if (oi * 100 + oj * 10 + ok >= 0) break;
		}
		rnz = nnz - lnz;
		for (i = 0; i < nnz; i++)
		{
			oi = stencil[i][0];
			oj = stencil[i][1];
			ok = stencil[i][2];
			v[oi + 3][oj + 3][ok + 3] = 1;
			if (i < lnz)
				for (j = lnz + 1; j < nnz; j++)
				{
					ti = oi + stencil[j][0] + 3;
					tj = oj + stencil[j][1] + 3;
					tk = ok + stencil[j][2] + 3;
					v[ti][tj][tk] = 1;
				}
		}

		for (i = 0; i < 7; i++)
		for (j = 0; j < 7; j++)
		for (k = 0; k < 7; k++)
		{
			if (v[i][j][k] == 1) v[i][j][k] = (annz++);
		}

		alnz = -1;
		alnz = v[3][3][3];
		if (alnz == -1) return SWSPARSE_INVALID_ARGS;
		arnz = annz - alnz;

		*l_npoints = alnz;
		*u_npoints = arnz;

		int (*tlpos)[3], (*trpos)[3];
		tlpos = (int (*)[3])swSparse_malloc(sizeof(int)*alnz*3);
		trpos = (int (*)[3])swSparse_malloc(sizeof(int)*arnz*3);

		int sum1 = 0, sum2 = 0;
		for (i = 0; i < 7; i++)
		for (j = 0; j < 7; j++)
		for (k = 0; k < 7; k++)
		{
			if (v[i][j][k] != -1)
			{
				if ((i-3)*100+(j-3)*10+k-3 < 0)
				{
					tlpos[sum1][0] = i - 3;
					tlpos[sum1][1] = j - 3;
					tlpos[sum1++][2] = k - 3;
				}
				else
				{
					trpos[sum2][0] = i - 3;
					trpos[sum2][1] = j - 3;
					trpos[sum2++][2] = k - 3;
				}
			}
		}
		*l_stencil_pos = tlpos;
		*u_stencil_pos = trpos;
	}
	else
	{
		return SWSPARSE_INVALID_ARGS;
	}
	
	return SWSPARSE_SUCCESS;
}
