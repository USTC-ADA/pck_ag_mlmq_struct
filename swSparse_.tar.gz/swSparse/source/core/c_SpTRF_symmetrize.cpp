#include <algorithm>
#include "swSparse.h"
#include "internal/rename.h"
#include "internal/memory.h"
#include "internal/templates.h"
#include "internal/debug.h"
#include "internal/third_party.h"
#include "internal/sptrf_common.h"
#include "internal/algorithm_heap.h"

namespace swSparse {
inline constexpr Int high_bit_mask = 0x80000000;

struct cycle4_t {
    Int row1, row2, gain;
};

static void init_cycle_heap(Int n, cycle4_t* cycle_heap) {
    init_heap_max(n, cycle_heap, [](const cycle4_t& cycle) { return cycle.gain; });
}

INLINE void adjust_cycle_heap_down(Int i, Int n, cycle4_t* cycle_heap) {
    adjust_heap_max_down(i, n, cycle_heap, [](const cycle4_t& cycle) { return cycle.gain; });
}

INLINE void adjust_cycle_heap_up(Int i, cycle4_t* cycle_heap) {
    adjust_heap_max_up(i, cycle_heap, [](const cycle4_t& cycle) { return cycle.gain; });
}

INLINE Int erase_cycle_heap(Int i, Int n, cycle4_t* cycle_heap) {
    Int new_size = n - 1, old_gain = cycle_heap[i].gain, new_gain = cycle_heap[new_size].gain;
    cycle_heap[i] = cycle_heap[new_size];
    if (new_gain > old_gain) {
        adjust_cycle_heap_up(i, cycle_heap);
    } else if (new_gain < old_gain) {
        adjust_cycle_heap_down(i, new_size, cycle_heap);
    }
    return new_size;
}

INLINE void mark_all(const Int* indices, Int begin, Int end, Int* marker, Int value) {
    for(Int p = begin; p < end; ++p) {
        marker[indices[p]] = value;
    }
}
INLINE void mark_all_except(const Int* indices, Int begin, Int end, Int* marker, Int value, Int except) {
    for(Int p = begin; p < end; ++p) {
        Int* pmark = &marker[indices[p]];
        *pmark = (*pmark == except) ? (-1) : value;
    }
}

static void recover_matching(Int n, Bool* RSTR diag_candidate, Int* RSTR imate, Int* RSTR jmate, Int* RSTR iwork) {
    for(Int i = 0; i < n; ++i) {
        Int j = i, path_length = 0;
        while(diag_candidate[j]) {
            j = imate[j];
            iwork[path_length++] = j;
            if(j == i) {  // find a cycle
                for(Int k = 0; k < path_length; ++k) {
                    j = iwork[k];
                    imate[j] = jmate[j] = j;
                    diag_candidate[j] = false;
                }
                break;
            }
        }
    }
}

static void prepare_symmetrize(Int n, Int nnz, \
               const Int* RSTR a_col_off, const Int* RSTR a_row_idx, const Bool* RSTR a_values, \
               Int* RSTR at_col_off, Int* RSTR at_row_idx, Bool* RSTR at_values, \
               Int* RSTR imate, Int* RSTR jmate) {
    Int* RSTR at_col_ends = at_col_off + 1;
    Int a_nonzero, a_col, at_col, prefix;

    swSparse_memset(at_col_off, 0, sizeof(Int) * (n + 1));
    swSparse_memset(at_values, 0, sizeof(Bool) * n);
    for(a_col = 0; a_col < n; ++a_col) {
        const Int begin = a_col_off[a_col], end = a_col_off[a_col+1];
        for(a_nonzero = begin; a_nonzero < end; ++ a_nonzero) {
            Int a_row = a_row_idx[a_nonzero];
            ++ at_col_ends[a_row];
            if(a_row == a_col && a_values[a_nonzero] && jmate[a_col] != a_col) {  // diagonal is a candidate
                at_values[a_col] = true;
            }
        }
    }
    recover_matching(n, at_values, imate, jmate, at_row_idx);
    prefix = 0;
    for(at_col = 0; at_col < n; ++at_col) {
        Int next = prefix + at_col_ends[at_col];
        at_col_ends[at_col] = prefix;
        prefix = next;
    }

    for(a_col = 0; a_col < n; ++a_col) {
        for(a_nonzero = a_col_off[a_col]; a_nonzero < a_col_off[a_col+1]; ++ a_nonzero) {
            Int at_nonzero = at_col_ends[a_row_idx[a_nonzero]] ++;
            at_row_idx[at_nonzero] = a_col;
            at_values[at_nonzero] = a_values[a_nonzero];
        }
    }
}
                
static Int find_C4(Int n, Int dense_thres, \
                const Int* RSTR col_ptr, const Int* RSTR row_idx, const Bool* RSTR csc_candidate, const Int* RSTR i_mate, \
                const Int* RSTR row_ptr, const Int* RSTR col_idx, const Bool* RSTR csr_candidate, const Int* RSTR j_mate, \
                cycle4_t* RSTR cycles, Int* RSTR contributions, Int* RSTR marker_1, Int* RSTR marker_2) {
    constexpr Int candidate_mask = high_bit_mask, value_mask = ~high_bit_mask;
    Int n_cycles = 0;
    for(Int i = 0; i < n; ++i) {
        marker_1[i] = -1;
        marker_2[i] = -1;
    }
    for(Int i1 = 0; i1 < n; ++i1) {  // compute initial score and find C4
        const Int j1 = i_mate[i1];
        const Int i1_begin = row_ptr[i1], i1_end = row_ptr[i1 + 1];
        const Int j1_begin = col_ptr[j1], j1_end = col_ptr[j1 + 1];
        Int contri = 0;
        if(UNLIKELY(i1_end - i1_begin > dense_thres || j1_end - j1_begin > dense_thres)) {
            contributions[i1] = 0;
            continue;
        }
        // mark neighbors of j1
        for(Int p1 = j1_begin; p1 < j1_end; ++p1) {
            Int i2 = row_idx[p1];
            marker_1[i2] = j1 | (static_cast<Int>(csc_candidate[p1]) << 31);  // marker_1[i2] == j1 means j1 -> i2
        }
        
        for(Int p2 = i1_begin; p2 < i1_end; ++p2) {
            const Int j2 = col_idx[p2], j2_begin = col_ptr[j2], j2_end = col_ptr[j2 + 1];
            const Int i2 = j_mate[j2],  i2_begin = row_ptr[i2], i2_end = row_ptr[i2 + 1];
            if(UNLIKELY(i2_end - i2_begin > dense_thres || j2_end - j2_begin > dense_thres)) {
                continue;
            }
            const Int imark = marker_1[i2];  // i2 is visited in random order, markers are necessary
            if((imark & value_mask) == j1) { // form a cycle: i1 => j1 -> i2 => j2 -> i1
                contri += 1;
                if((csr_candidate[p2]) && (i1 < i2 /* no duplicated C4 */) && ((imark & candidate_mask) != 0)) {  // form an alternable C4
                    Int gain = 0;
                    // neighbors of j1 has already been marked
                    for(Int p3 = i2_begin; p3 < i2_end; ++p3) {  // find i2 => j1 -> i3 => j3 -> i2
                        Int j3 = col_idx[p3];
                        Int i3 = j_mate[j3];
                        gain += ((marker_1[i3] & value_mask) == j1);
                    }
                    // mark neighbors of j2
                    mark_all(row_idx, j2_begin, j2_end, marker_2, n_cycles);  // marker_2[i3] == n_cycles means j2 -> i3

                    for(Int p3 = i1_begin; p3 < i1_end; ++p3) {  // find i1 => j2 -> i3 => j3 -> i1
                        Int j3 = col_idx[p3];
                        Int i3 = j_mate[j3];
                        gain += (marker_2[i3] == n_cycles);
                    }

                    cycles[n_cycles].row1 = i1;
                    cycles[n_cycles].row2 = i2;
                    cycles[n_cycles].gain = gain;
                    ++ n_cycles;
                }
            }
        }
        contributions[i1] = contri;
    }
    for(Int p = 0; p < n_cycles; ++p) {
        Int row1 = cycles[p].row1;
        Int row2 = cycles[p].row2;
        cycles[p].gain -= (contributions[row1] + contributions[row2]);
    }
    init_cycle_heap(n_cycles, cycles);
    return n_cycles;
}

INLINE Bool find_conflict(Int r1, Int r2, Int rr1, Int rr2) {
    return (r1 == rr1) || (r2 == rr2) || (r1 == rr2) || (r2 == rr1);
}

static Int sieve_cycles(Int n_cycles, cycle4_t* cycles, Int r1, Int r2, Int c1, Int c2, const Int* i_mate) {
    for(Int p = n_cycles - 1; p >= 1; ) {
        if(find_conflict(r1, r2, cycles[p].row1, cycles[p].row2)) {
            n_cycles = erase_cycle_heap(p, n_cycles, cycles);
        } else {
            ASSERT(i_mate[cycles[p].row1] != c1);
            ASSERT(i_mate[cycles[p].row2] != c1);
            ASSERT(i_mate[cycles[p].row1] != c2);
            ASSERT(i_mate[cycles[p].row2] != c2);
            --p;
        }
    }
    n_cycles = erase_cycle_heap(0, n_cycles, cycles);
    return n_cycles;
}

template<typename COUNTER>
INLINE Int gain_increment(Int r, Int c1, Int c2, Int mr1, Int mr2, Int mc1, Int mc2) {
    COUNTER counter;
    if(mc1 == r) {
        if(mc2 != r) {
            counter.increment(mr1 == c1);
            counter.decrement(mr1 == c2);
            counter.increment(mr2 == c2);
            counter.decrement(mr2 == c1);
        }
    } else if(mc2 == r) {
        if(mc1 != r) {
            counter.increment(mr1 == c2);
            counter.decrement(mr1 == c1);
            counter.increment(mr2 == c1);
            counter.decrement(mr2 == c2);
        }
    }
    return counter.value();
}

struct CounterBase {
    Int val;
    CounterBase() : val(0) {}
    INLINE Int value() const { return val; }
};

struct PositiveCounter : public CounterBase {
    INLINE void increment(Int delta) { this->val += delta; }
    INLINE void decrement(Int delta) { this->val -= delta; }
};
struct NegativeCounter : public CounterBase {
    INLINE void increment(Int delta) { this->val -= delta; }
    INLINE void decrement(Int delta) { this->val += delta; }
};

static void update_gains(Int n_cycles, cycle4_t* RSTR cycles, Int r1, Int r2, Int c1, Int c2, \
    const Int* i_mate, const Int* marker_r, const Int* marker_c) {
    constexpr Int updated_mask = high_bit_mask, reset_mask = ~updated_mask;
    for(Int p = 0; p < n_cycles; ) {
        if((cycles[p].row1 & updated_mask) == 0) {
            Int rr1 = cycles[p].row1, cc1 = i_mate[rr1];
            Int rr2 = cycles[p].row2, cc2 = i_mate[rr2];
            Int mr1 = marker_c[rr1], mc1 = marker_r[cc1];
            Int mr2 = marker_c[rr2], mc2 = marker_r[cc2];
            Int increment = gain_increment<PositiveCounter>(r1, c1, c2, mr1, mr2, mc1, mc2) \
                          + gain_increment<NegativeCounter>(r2, c1, c2, mr1, mr2, mc1, mc2);
            if(increment != 0) {
                cycles[p].gain += increment;
                if(increment < 0) {
                    cycles[p].row1 |= updated_mask; // mark as already updated
                    adjust_cycle_heap_down(p, n_cycles, cycles);
                    continue;         // p is not increased
                } else {              // increment > 0
                    adjust_cycle_heap_up(p, cycles);
                }
            }
        } else {
            cycles[p].row1 &= reset_mask;
        }
        ++ p;  // avoid increasing p when continue
    }
}

/* j = i_mate[i] means row i matches column j */
ErrorStatus matrix_symmetrizer_t::symmetrize_matching(Int n, Int nnz, const Int* RSTR col_ptr, const Int* RSTR row_idx, Int* RSTR i_mate) {
    constexpr Int rebuild_heap_threshold_1 = 50;
    constexpr Int rebuild_heap_threshold_2 = 5;  // 5 / 1024
    constexpr Int end_threshold = 20;
    const Int capacity = (nnz - n) >> 1;
    int64_t best_score, current_score, initial_score;
    Int n_cycles;
    void *iwork = swSparse_malloc(sizeof(cycle4_t) * capacity + sizeof(Int) * (n * 5 + 1 + nnz) + sizeof(Bool) * nnz);
    Bool* candidate = this->a_candidate;
    cycle4_t *cycles = reinterpret_cast<cycle4_t*>(iwork);
    Int *contributions = reinterpret_cast<Int*>(cycles + capacity);
    Int *marker_r = contributions + n;
    Int *marker_c = marker_r      + n;
    Int *j_mate   = marker_c      + n;
    Int *row_ptr  = j_mate        + n;
    Int *col_idx  = row_ptr   + 1 + n;
    Bool *AT_candidate = reinterpret_cast<Bool*>(col_idx + nnz);
    IF_ERR(iwork == nullptr) {
        return clean_return(SWSPARSE_MALLOC_ERROR, candidate);
    }
    prepare_symmetrize(n, nnz, col_ptr, row_idx, candidate, row_ptr, col_idx, AT_candidate, i_mate, j_mate);
    swSparse_perm_invert(n, i_mate, j_mate);
    n_cycles = find_C4(n, dense_threshold, \
            col_ptr, row_idx, candidate, i_mate, \
            row_ptr, col_idx, AT_candidate, j_mate, \
            cycles, contributions, marker_r, marker_c);
    initial_score = 0;
    for(Int i = 0; i < n; ++i) {
        initial_score += contributions[i];
    }

    for(;;) {
        const Int rebuild_heap_threshold = min(rebuild_heap_threshold_1, (n_cycles * rebuild_heap_threshold_2) >> 10);
        Int current_move = capacity;
        Int best_move = capacity;
        best_score = current_score = initial_score;
        for(Int i = 0; i < n; ++i) {
            marker_r[i] = -1;
            marker_c[i] = -1;
        }
        
        while(n_cycles > 0) {
            const cycle4_t& max_cycle = cycles[0];
            Int r1 = max_cycle.row1, c1 = i_mate[r1];
            Int r2 = max_cycle.row2, c2 = i_mate[r2];
            current_score += (max_cycle.gain << 1);            // gain has been reduced a factor 2
            n_cycles = sieve_cycles(n_cycles, cycles, r1, r2, c1, c2, i_mate);  // remove cycles[0] and intersecting cycles
            /* apply and record move */
            j_mate[c1] = r2;
            j_mate[c2] = r1;
            i_mate[r1] = c2;
            i_mate[r2] = c1;
            --current_move;
            ASSERT_LESS_EQUAL(0, current_move);
            cycles[current_move].row1 = r1;
            cycles[current_move].row2 = r2;
            if(current_score > best_score) {
                best_score = current_score;
                best_move = current_move;
            }
            if(best_move - current_move >= rebuild_heap_threshold) {
                break;
            }

            mark_all(       row_idx, col_ptr[c1], col_ptr[c1 + 1], marker_c, c1);
            mark_all_except(row_idx, col_ptr[c2], col_ptr[c2 + 1], marker_c, c2, c1);
            mark_all(       col_idx, row_ptr[r1], row_ptr[r1 + 1], marker_r, r1);
            mark_all_except(col_idx, row_ptr[r2], row_ptr[r2 + 1], marker_r, r2, r1);
            update_gains(n_cycles, cycles, r1, r2, c1, c2, i_mate, marker_r, marker_c);
        }

        /* rollback to the best */
        for(Int step = current_move; step < best_move; ++step) {
            Int row1 = cycles[step].row1, column1 = i_mate[row1];
            Int row2 = cycles[step].row2, column2 = i_mate[row2];
            j_mate[column1] = row2;
            j_mate[column2] = row1;
            i_mate[row1] = column2;
            i_mate[row2] = column1;
        }

        if((best_score - initial_score) * end_threshold <= initial_score) {  // if the whole matrix is dense, the score = 0
            break;
        }
        initial_score = best_score;
        /* re-build C4 */
        n_cycles = find_C4(n, dense_threshold, \
                    col_ptr, row_idx, candidate, i_mate, \
                    row_ptr, col_idx, AT_candidate, j_mate, \
                    cycles, contributions, marker_r, marker_c);
#ifdef SWSPARSE_HAS_ASSERT
        current_score = best_score;
        for(Int i = 0; i < n; ++i) {
            current_score -= contributions[i];
        }
        ASSERT_EQUAL(current_score, 0);
#endif
    }
    return clean_return(SWSPARSE_SUCCESS, iwork, candidate);
}

template<typename REAL_T>
ErrorStatus matrix_symmetrizer_t::select_candidates(Int n, Int nnz, const Int* RSTR col_ptr, const Int* RSTR row_idx, \
        REAL_T* RSTR minus_log, const REAL_T* RSTR rlogscale, REAL_T* RSTR rwork) {
    Bool *candidate = (Bool*)swSparse_malloc(sizeof(Bool) * nnz);
    if(candidate == nullptr) {
        return MALLOC_ERROR;
    }
    dense_threshold = static_cast<Int>(5.0 * sqrt((double)n));
    for(Int j = 0; j < n; ++j) {
        Int begin = col_ptr[j], end = col_ptr[j+1], size = end - begin, ncandidate = size >> 1;
        if((size > dense_threshold) || (ncandidate <= 1)) {   // don't move this column if too dense or too sparse
            memset(candidate + begin, 0, sizeof(Bool) * size);
        } else {
            REAL_T thres, *pthres = rwork + ncandidate;
            for(Int p_ = 0; p_ < size; ++p_) {
                Int p = p_ + begin;
                REAL_T scaled = minus_log[p] - rlogscale[row_idx[p]];
                rwork[p_] = scaled;
                minus_log[p] = scaled;
            }
            std::nth_element(rwork, pthres, rwork + size);
            thres = *pthres;
            for(Int p = begin; p < end; ++p) { // don't move if all the same value
                candidate[p] = (minus_log[p] < thres);
#ifdef SWSPARSE_HAS_ASSERT
                if(row_idx[p] == j) {
                    ASSERT(candidate[p]);
                }
#endif
            }
        }
    }
    this->a_candidate = candidate;
    return SWSPARSE_SUCCESS;
}

template ErrorStatus matrix_symmetrizer_t::select_candidates<float>(Int n, Int nnz, const Int* RSTR col_ptr, const Int* RSTR row_idx, \
        float* RSTR minus_log, const float* RSTR rlogscale, float* RSTR rwork); \
template ErrorStatus matrix_symmetrizer_t::select_candidates<double>(Int n, Int nnz, const Int* RSTR col_ptr, const Int* RSTR row_idx, \
        double* RSTR minus_log, const double* RSTR rlogscale, double* RSTR rwork); \

template<typename Function>
static void at_plus_a(Int n, const Int* RSTR col_off, const Int *RSTR row_idx, Int* RSTR temp, Function&& insert_nonzero) {
    for (Int k = 0 ; k < n ; k++) {
	    Int p1 = col_off [k] ;
	    Int p2 = col_off [k+1] ;
        Int p;
        
        /* construct A+A' */
        for (p = p1 ; p < p2 ; ) {
            /* scan the upper triangular part of A */
            Int pj, pj2, j = row_idx [p] ;
            if (j < k) {
                insert_nonzero(j, k);
                p++ ;
            } else if (j == k) {
                p++ ;
                break ;
            } else /* j > k */ {
                break ;
            }
            /* scan lower triangular part of A, in column j until reaching
            * row k.  Start where last scan left off. */
            pj2 = col_off [j+1];
            for (pj = temp [j] ; pj < pj2 ; ) {
                Int i = row_idx [pj] ;
                if (i < k) {
                    insert_nonzero(i, j);
                    pj++ ;
                } else if (i == k) {
                    pj++ ;
                    break ;
                } else /* i > k */ {
                    break ;
                }
            }
            temp [j] = pj ;
        }
        /* Tp [k] points to the entry just below the diagonal in column k */
        temp [k] = p ;
    }
    for (Int j = 0 ; j < n ; j++) {
        for (Int pj = temp [j] ; pj < col_off [j+1] ; pj++) {
            insert_nonzero(row_idx [pj], j);
        }
    }
}

} // namespace swSparse

Int AT_PLUS_A_COUNT(Int n, const Int* RSTR a_col_off, const Int *RSTR a_row_idx, Int* RSTR b_col_off, Int* RSTR b_col_nz, Int* RSTR temp) {
    Int* b_col_ends = b_col_off + 1;
    Int prefix = 0;
    swSparse_memset(b_col_nz, 0, sizeof(Int) * n);
    swSparse::at_plus_a(n, a_col_off, a_row_idx, temp, [=](Int i, Int j) {
        b_col_nz[i] ++ ;
        b_col_nz[j] ++ ;
    });

    b_col_off[0] = 0;
    for(Int at_row = 0; at_row < n; ++at_row) {
        b_col_ends[at_row] = prefix;
        prefix += b_col_nz[at_row];
    }
    return prefix;
}

void AT_PLUS_A(Int n, const Int* RSTR a_col_off, const Int *RSTR a_row_idx, Int* RSTR b_col_off, Int* RSTR b_row_idx, Int* RSTR temp) {
    Int *col_ends = b_col_off + 1;
    swSparse::at_plus_a(n, a_col_off, a_row_idx, temp, [=](Int i, Int j) {
        b_row_idx[col_ends[i] ++] = j;
        b_row_idx[col_ends[j] ++] = i;
    });
}