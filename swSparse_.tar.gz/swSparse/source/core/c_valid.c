#include <math.h>
#include "swSparse_base.h"
#include "internal/rename.h"
#include "internal/reorder.h"
#include "internal/memory.h"
#include "internal/utils.h"
#include "internal/debug.h"


static Bool out_of_range(Int x, Int a, Int b, const char *msg) {
    if(x < a || x > b) {
        DEBUG_PRINTF("%s: %d\n", msg, x);
        return true;
    }
    return false;
}

static Bool out_of_range_1(Int x, Int a, const char *msg) {
    if(x < a) {
        DEBUG_PRINTF("%s: %d\n", msg, x);
        return true;
    }
    return false;
}

#if DEBUG_LEVEL > 0
#define OUT_OF_RANGE(x, a, b, msg) out_of_range(x, a, b, msg)
#define NEGATIVE(x, msg)           out_of_range_1(x, 0, msg)
#define NON_POSITIVE(x, msg)       out_of_range_1(x, 1, msg)
#define VALID_CSR(m, n, nnz, off, idx, ordered)  valid_csr(m, n, nnz, off, idx, ordered, "Row")
#define VALID_CSC(m, n, nnz, off, idx, ordered)  valid_csr(m, n, nnz, off, idx, ordered, "Column")
#else
#define OUT_OF_RANGE(x, a, b, msg) out_of_range(x, a, b, NULL)
#define NEGATIVE(x, msg)           out_of_range_1(x, 0, NULL)
#define NON_POSITIVE(x, msg)       out_of_range_1(x, 1, NULL)
#define VALID_CSR(m, n, nnz, off, idx, ordered)  valid_csr(m, n, nnz, off, idx, ordered, NULL)
#define VALID_CSC(m, n, nnz, off, idx, ordered)  valid_csr(m, n, nnz, off, idx, ordered, NULL)
#endif

static Bool clean_ret(Bool ret, void *p) {
    if(p) swSparse_free(p);
    return ret;
}

static Bool valid_coo(Int m, Int n, Int nnz, const Int* row_idx, const Int* col_idx) {
    for(Int p = 0; p < nnz; ++p) {
        if(OUT_OF_RANGE(row_idx[p], 0, m-1, "Row indices out of range")) {
            DEBUG_PRINTF("\tat row_indices[%d]\n", p);
            return false;
        }
        if(OUT_OF_RANGE(col_idx[p], 0, n-1, "Column indices out of range")) {
            DEBUG_PRINTF("\tat row_indices[%d]\n", p);
            return false;
        }
    }
    return true;
}

static Bool valid_csr(Int m, Int n, Int nnz, const Int* off, const Int* idx, Bool ordered, const char* row) {
    Int *temp = NULL;
    if(off[0] != 0) {
        DEBUG_PRINTF("offsets[0] != 0\n");
        return false;
    }
    if(off[m] != nnz) {
        DEBUG_PRINTF("offsets[%d] != %d (nnz)\n", m, nnz);
        return false;
    }

    if(!ordered) {
        temp = (Int*)swSparse_malloc(sizeof(Int) * n);
        IF_ERR(temp == NULL) {
            DEBUG_PRINTF("Not enough memory while checking matrix validity\n");
            return false;
        }
        for(Int i = 0; i < n; ++i) {
            temp[i] = -1;
        }
    }

    for(Int i = 0; i < m; ++i) {
        if(off[i] > off[i+1]) {
            DEBUG_PRINTF("Offsets decreasing: offsets[%d](%d) > offsets[%d](%d)\n", i, off[i], i+1, off[i+1]);
            return clean_ret(false, temp);
        }
        for(Int p = off[i]; p < off[i+1]; ++p) {
            if(OUT_OF_RANGE(idx[p], 0, n-1, "Indices out of range")) {
                DEBUG_PRINTF("\tat %s %d (%d~%d), indices[%d]\n", row, i, off[i], off[i+1], p);
                return clean_ret(false, temp);
            }
        }
        if(ordered) {
            for(Int p = off[i] + 1; p < off[i+1]; ++p) {
                Int last = p - 1;
                if(idx[last] > idx[p]) {
                    DEBUG_PRINTF("%s %d (%d~%d), while the matrix is labeled as ordered:\n\t"\
                        "Unoredered indices: indices[%d](%d) > indices[%d](%d)\n", \
                        row, i, off[i], off[i+1], last, idx[last], p, idx[p]);
                    return false;
                }
                if(idx[last] == idx[p]) {
                    DEBUG_PRINTF("%s %d (%d~%d):\n\tDuplicated entry: indices[%d](%d) = indices[%d](%d)\n", \
                        row, i, off[i], off[i+1], last, idx[last], p, idx[p]);
                    return false;
                }
            }
        } else {
            for(Int p = off[i]; p < off[i+1]; ++p) {
                Int last = temp[idx[p]];
                if(last != -1) {
                    DEBUG_PRINTF("%s %d (%d~%d):\n\tDuplicated entry: indices[%d](%d) = indices[%d](%d)\n", \
                        row, i, off[i], off[i+1], last, idx[last], p, idx[p]);
                    return clean_ret(false, temp);
                }
                temp[idx[p]] = p;
            }
            for(Int p = off[i]; p < off[i+1]; ++p) {
                temp[idx[p]] = -1;
            }
        }
    }
    return clean_ret(true, temp);
}

#if DEBUG_LEVEL > 0
static const char valueinfo[] = "Matrix has %s value\n", naninfo[] = "NaN", infinfo[] = "infinity";
#endif

static Bool s_valid_value(Int nnz, const float* values) {
    for(Int i = 0; i < nnz; ++i) {
        if(isnan(values[i])) {
            DEBUG_PRINTF(valueinfo, naninfo);
            return false;
        }
        if(isinf(values[i])) {
            DEBUG_PRINTF(valueinfo, infinfo);
            return false;
        }
    }
    return true;
}

static Bool d_valid_value(Int nnz, const double* values) {
    for(Int i = 0; i < nnz; ++i) {
        if(isnan(values[i])) {
            DEBUG_PRINTF(valueinfo, naninfo);
            return false;
        }
        if(isinf(values[i])) {
            DEBUG_PRINTF(valueinfo, infinfo);
            return false;
        }
    }
    return true;
}

static Bool valid_value(Int nnz, const void* values, MatrixElementType type) {
    switch (type) {
    case SWSPARSE_COMPLEX_SINGLE:
        nnz = nnz << 1; // fall through
    case SWSPARSE_REAL_SINGLE:
        return s_valid_value(nnz, values);
    case SWSPARSE_COMPLEX_DOUBLE:
        nnz = nnz << 1; // fall through
    case SWSPARSE_REAL_DOUBLE:
        return d_valid_value(nnz, values);
    default:
        UNREACHABLE;
    }
}

Bool swSparse_valid(Matrix a) {
    if(OUT_OF_RANGE(a->format_type,  SWSPARSE_CSR, SWSPARSE_SLTCOO, "Invalid format")) {
        return false;
    }
    if(OUT_OF_RANGE(a->element_type, SWSPARSE_REAL_SINGLE, SWSPARSE_COMPLEX_DOUBLE, "Invalid element type")) {
        return false;
    }
    if(NON_POSITIVE(a->m, "Invalid number of rows")) {
        return false;
    }
    if(NON_POSITIVE(a->n, "Invalid number of columns")) {
        return false;
    }
    if(NEGATIVE(a->nnz, "Invalid number of nonzeros")) {
        return false;
    }
    switch (a->format_type) {
    case CSR:
        return VALID_CSR(a->m, a->n, a->nnz, a->matrix.csrc->offsets, a->matrix.csrc->indices, a->matrix.csrc->ordered) \
            && valid_value(a->nnz, a->matrix.csrc->values, a->element_type);
    case CSC:
        return VALID_CSC(a->n, a->m, a->nnz, a->matrix.csrc->offsets, a->matrix.csrc->indices, a->matrix.csrc->ordered) \
            && valid_value(a->nnz, a->matrix.csrc->values, a->element_type);
    case COO:
        return valid_coo(a->m, a->n, a->nnz, a->matrix.coo->row_indices, a->matrix.coo->column_indices) \
            && valid_value(a->nnz, a->matrix.coo->values, a->element_type);
    default:
        DEBUG_PRINTF("Unable to check non-standard formats\n");
        return false;
    }
}

Bool swSparse_valid_permutation(Int n, const Int* perm, Int* work) {
    Bool valid = true;
    swSparse_memset(work, -1, n * sizeof(int));
    for(int i = 0; i < n; ++i) {
        if(perm[i] < 0 || perm[i] >= n) {
            DEBUG_PRINTF("Invalid permutation: perm[%d] = %d is out of range\n", i, perm[i]);
            valid = false;
            break;
        }
        if(work[perm[i]] >= 0) {
            DEBUG_PRINTF("Invalid permutation: perm[%d] = %d = perm[%d]\n", i, perm[i], work[perm[i]]);
            valid = false;
            break;
        }
        work[perm[i]] = i;
    }
    return valid;
}
