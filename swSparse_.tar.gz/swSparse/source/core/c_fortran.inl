#include "internal/multicompile.h"
#ifdef F_FUNCNAME
#undef F_FUNCNAME
#endif

#if   defined(DATA_TYPE_S)
#define F_FUNCNAME(name) swsparse_s_##name##_
#elif defined(DATA_TYPE_D)
#define F_FUNCNAME(name) swsparse_d_##name##_
#elif defined(DATA_TYPE_C)
#define F_FUNCNAME(name) swsparse_c_##name##_
#elif defined(DATA_TYPE_Z)
#define F_FUNCNAME(name) swsparse_z_##name##_
#endif

EXTERN void F_FUNCNAME(mv_execute)(const DATA_T* alpha, const FortranMatrix* matrix, const DATA_T *x, \
                                const DATA_T* beta, DATA_T *y, const swSparseMVOptions* options, Int *error) {
    *error = FUNCNAME(mv_execute)(*alpha, (swSparseMatrix)*matrix, x, *beta, y, options);
}


EXTERN void F_FUNCNAME(mm_execute)(const DATA_T* alpha, const FortranMatrix* matrix, const Int* n_vec, \
                                const DATA_T *x, const Int* ldx, \
                                const DATA_T* beta, DATA_T *y, const Int* ldy, \
                                const swSparseMMOptions* options, Int *error) {
    *error = FUNCNAME(mm_execute)(*alpha, (swSparseMatrix)*matrix, *n_vec, x, *ldx, *beta, y, *ldy, options);
}
