#ifdef SWSPARSE_USE_METIS
#include <metis.h>
#endif
#include "swSparse.h"
#include "internal/rename.h"
#include "internal/memory.h"
#include "internal/debug.h"
#include "internal/utils.h"
#include "internal/reorder.h"
#include "internal/sptrf_suprelax.h"
#include "internal/third_party.h"
#define LU_PRINT_STATS
#include "internal/sptrf_common.h"


#ifdef LU_PRINT_STATS
#define DECL_TIMER struct timeval begin, end
#define TIMER_BEGIN gettimeofday(&begin, NULL)
#define TIMER_END   gettimeofday(&end, NULL)
#define PRINT_FILLIN_TIME     swSparse_set_lu_timing(&begin, &end, LU_TIMING_FILL)
#else
#define DECL_TIMER
#define TIMER_BEGIN
#define TIMER_END
#define PRINT_FILLIN_TIME
#endif

static void swSparse_etree(Int nrow, const Int *RSTR a_c_begin, const Int *RSTR a_c_end, const Int *RSTR a_r_idx, \
        const Int* RSTR iperm, Int *RSTR etree, Int *RSTR iwork);
static void swSparse_relax0_snode(Int n, const Int* etree, const Int *nchild, Int *part_super, col_status_t* status, Int* desc/* length n + 1*/);

static ErrorStatus call_amd(Int n, Int nnz, const Int* col_off, Int *col_cnt, const Int* row_idx, Int* iperm, Int* iwork /* length n + 1 */) {
	Int slen = AMD_IWLEN(n, nnz);
    Int *s = (Int*)swSparse_malloc(sizeof(Int) * slen);
    IF_ERR(s == NULL) {
        return MALLOC_ERROR;
    }
    swSparse_memcpy(s, row_idx, sizeof(Int) * nnz);
    swSparse_memcpy(iwork, col_off, sizeof(Int) * (n + 1));
    AMD(n, iwork, col_cnt, s, slen, iperm);
    swSparse_free(s);
    return SWSPARSE_SUCCESS;
}

/* METIS declarations do not have const qualifiers */
static ErrorStatus call_metis(Int n, /*const*/ Int* col_off, /*const*/ Int* row_idx, Int* perm, Int* iperm) {
#ifdef SWSPARSE_USE_METIS 
    Int ret, options[METIS_NOPTIONS];
    METIS_SetDefaultOptions(options);
    ret = METIS_NodeND(&n, col_off, row_idx, NULL, options, perm, iperm);
    if(ret == METIS_ERROR_INPUT) {
        return SWSPARSE_INVALID_ARGS;
    } else if(ret == METIS_ERROR_MEMORY) {
        DEBUG_PRINTF("Metis error: out of memory.\n");
        return SWSPARSE_MALLOC_ERROR;
    } else if(ret == METIS_ERROR) {
        return SWSPARSE_UNKNOWN_ERROR;
    } else {
        return SWSPARSE_SUCCESS;
    }
#else
    DEBUG_PRINTF("METIS not supported, please recompile swSparse with LINK_LIBMETIS option\n");
    return SWSPARSE_NOT_SUPPORTED;
#endif
}

/*
 * analysis on the symmetric matrix AT + A 
 */
ErrorStatus swSparse_symmetric_analysis(Int n, const Int* offsets, const Int* indices, sym_analysis_result_t* result, uint8_t algorithm) {
    ErrorStatus ret;
	Int *etree = result->etree;
	Int *iperm = result->ciperm;
	Int *part_super = result->part_super;
	Int *rowcnt = result->rowcnt;
	Int *colcnt = result->colcnt;
	uint8_t* status = result->status;
    Int *iperm_1   = etree;
    Int *iwork, *iwork2, *b_col_nz, *perm, *iperm_2, *nchild, *etree_tmp, *b_row_idx, *b_col_off, *b_col_begin, *b_col_end, *ndesc;
    Int b_nnz, nnz = offsets[n];
    DECL_TIMER;
    
    b_col_off = (Int*)swSparse_malloc(sizeof(Int) * (n + 1));
    IF_ERR(b_col_off == NULL) {
        return MALLOC_ERROR;
    }
    iwork = (Int*)swSparse_malloc(sizeof(Int) * (n * 2 + 1));
    IF_ERR(iwork == NULL) {
        return clean_return(MALLOC_ERROR, b_col_off);
    }
    b_col_nz  = iwork + n + 1;
    b_nnz = AT_PLUS_A_COUNT(n, offsets, indices, b_col_off, b_col_nz, iwork);
    b_row_idx = (Int*)swSparse_malloc(sizeof(Int) * b_nnz);
    IF_ERR(b_row_idx == NULL) {
        return clean_return(MALLOC_ERROR, b_col_off, iwork);
    }
    AT_PLUS_A(n, offsets, indices, b_col_off, b_row_idx, iwork);

    TIMER_BEGIN;
    switch (algorithm) {
    case SWSPARSE_NATURAL_ORDER:
        create_id_perm(n, iperm_1);
        break;
    case SWSPARSE_REORDER_AMD:
		ret = call_amd(n, b_nnz, b_col_off, b_col_nz, b_row_idx, iperm_1, iwork);
        IF_ERR(ret != SWSPARSE_SUCCESS) {
            return clean_return(ret, b_row_idx, b_col_off, iwork);
        }
        break;
    case SWSPARSE_REORDER_METIS:
        ret = call_metis(n, b_col_off, b_row_idx, iwork, iperm_1);
        IF_ERR(ret != SWSPARSE_SUCCESS) {
            return clean_return(ret, b_row_idx, b_col_off, iwork);
        }
        break;
    default:
        DEBUG_PRINTF("Unrecognized option for reorder algorithm: %d\n", (Int)algorithm);
        return clean_return(SWSPARSE_INVALID_ARGS, b_row_idx, b_col_off, iwork);
    }
    TIMER_END;
    PRINT_FILLIN_TIME;

    // etree related analysis
    iwork2 = (Int*)swSparse_malloc(sizeof(Int) * (n * 6 + 3));
    IF_ERR(iwork == NULL) {
        return clean_return(MALLOC_ERROR, b_col_off, b_row_idx, iwork);
    }
    b_col_begin = iwork;
    b_col_end   = iwork + n;
    etree_tmp   = iwork2 + (n + 1) * 2;
    iperm_2     = iwork2 + (n + 1) * 3;
    swSparse_i_iperm_apply(n, b_col_off, b_col_begin, iperm_1);
    swSparse_i_iperm_apply(n, b_col_off + 1, b_col_end, iperm_1);
    swSparse_etree(n, b_col_begin, b_col_end, b_row_idx, iperm_1, etree_tmp, iwork2);

    // iperm_2 has length n + 1, for iperm_2[n] = n;
    ETREE_POST(n, etree_tmp, iperm_2, iwork2);
    iperm_compose(n, iperm_1, iperm_2, iperm);

    // etree[iperm_2[i]] = iperm_2[etree_tmp[i]];
    gather_by_indices(n, iperm_2, iwork2, etree_tmp);
    swSparse_i_iperm_apply(n, iwork2, etree, iperm_2);

    perm = iwork;
    nchild = iwork + n;
    swSparse_perm_invert(n, iperm, perm);
    result->etree_height = CHOLNZCNT(n, b_col_off, b_row_idx, perm, iperm, etree, colcnt, rowcnt, nchild, iwork2);

	ndesc = iwork2;
	swSparse_relax0_snode(n, etree, nchild, part_super, status, ndesc);
    
    result->to_clean = b_col_off; // defered free
    return clean_return(SWSPARSE_SUCCESS, b_row_idx, iwork, iwork2);
}

/* create etree of a permuted matrix */
/* etree[c] == nrow means c is a root */
/* iwork[nrow] */
static void swSparse_etree(Int nrow, const Int *RSTR a_c_begin, const Int *RSTR a_c_end, const Int *RSTR a_r_idx, \
        const Int* RSTR iperm, Int *RSTR etree, Int *RSTR iwork) {
    Int c, p, r, r_temp;
    for(c = 0; c < nrow; ++c){
        etree[c] = nrow;
        iwork[c] = nrow;
    }
    for(c = 0; c < nrow; ++c ){
        for(p = a_c_begin[c]; p < a_c_end[c]; ++p) {
            r = iperm[a_r_idx[p]];
            if(r < c) {
                while(iwork[r] != nrow) {
                    r_temp = iwork[r];
                    iwork[r] = c; // path compression
                    r = r_temp;
                }
                if(r != c) {
                    iwork[r] = c;
                    etree[r] = c;
                }
            }
        }
    }
}


/*
 *  part_super is not fundamental supernodes, it only means the branching point
 *      we only use fundumental supernodes of original L, and do not use fundumental supernodes of symmetrized L
 */
static void swSparse_relax0_snode(Int n, const Int* etree, const Int *nchild, Int * RSTR part_super, col_status_t* status, Int* desc/* length n + 1*/) {
    Int xsup = 0;
	/* Compute the number of descendants of each node in the etree */
    swSparse_memset(desc, 0, sizeof(Int) * (n + 1));
	for (Int j = 0; j < n; j++) {
		Int parent = etree[j];
		desc[parent] += desc[j] + 1;
	}
    swSparse_memset(part_super, 0, sizeof(Int) * n);
    swSparse_memset(status, 0, sizeof(col_status_t) * n);

	/* Identify the relaxed supernodes by postorder traversal of the etree. */
	for (Int j = 0; j < n;) {
		Int parent = etree[j];
		Int first = j, j_next, j_probe = j;
        col_status_t depth = 1, d_probe = 1;
		while (parent != n && desc[parent] < RELAX_SIZE_0) {
			j_probe = parent;
            ++ d_probe;
			parent = etree[j_probe];
            IF_ACCEPT_RELAX_LEAF(nchild[parent]) {
                j = j_probe;
                depth = d_probe;
            }
		}

        j_next = j + 1;

		/* found a supernode with j being the last column. */
        status[first] = depth;
        part_super[first] = j_next - first; // size
        for(Int k = first + 1; k < j_next; ++k) {
            part_super[k] = first - k;      // offset
        }

        if(xsup < first) {
            ASSERT_EQUAL(part_super[xsup], 0);
            part_super[xsup] = first - xsup;
        }
        xsup = j_next;
        
		/* Search for a new leaf */
		for (j = j_next; nchild[j] != 0 && j < n; ++j) {
            if( nchild[j] > 1) {
                ASSERT_EQUAL(part_super[xsup], 0);
                part_super[xsup] = j - xsup;  // mark branching point
                status[xsup] = -1;
                xsup = j;
            }
        }
	}
    if(xsup < n) { // no need to relax on the last supernode
        part_super[xsup] = n - xsup;  // mark branching point
        status[xsup] = -1;
    }
    //check
#ifdef SWSPARSE_HAS_ASSERT
	for (Int j = 0; j < n;) {
        ASSERT_LESS(0, part_super[j]);
        if(status[j] > 0) {
            for(Int i = j + 1; i < j + part_super[j]; ++i) {
                ASSERT_EQUAL(part_super[i], j - i);
            }
        } else {
            for(Int i = j + 1; i < j + part_super[j]; ++i) {
                ASSERT_EQUAL(part_super[i], 0);
            }
        }
        j = j + part_super[j];
    }
#endif
}
