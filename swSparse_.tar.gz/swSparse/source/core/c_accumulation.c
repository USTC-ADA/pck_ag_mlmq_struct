#include "internal/utils.h"

/* 
 * pairwise sum to mnimize the floating point error.
 * ((a[0] + a[1]) + (a[2] + a[3])) + ((a[4] + a[5]) + (a[6] + a[7])) + ...
 * we can use SIMD to further optimize, e.g.

    floatv4 stack[64] = {0.0f};
    ...
    for(i = 0; i < (n & ~15); i += 16) {
        floatv4 err0 = simd_loadu(a + i) - simd_loadu(b + i);
        floatv4 err1 = simd_loadu(a + i + 4) - simd_loadu(b + i + 4);
        floatv4 err2 = simd_loadu(a + i + 8) - simd_loadu(b + i + 8);
        floatv4 err3 = simd_loadu(a + i + 12) - simd_loadu(b + i + 12);
        ...
    }

 * However these routines are used in checking the result correctness.
 * We prefer portability rather than performance.
 */

#define MAX_STACK 32
#define LOOP_UNROLL 4
#define LOOP_UNROLL_MASK ~3

float swSparse_s_mse(int n, const float *a, const float *b) {
    float stack[MAX_STACK] = {0.0f};
    float s = 0.0f;
    int i, bit, top = 0;
    for(i = 0; i < (n & LOOP_UNROLL_MASK); i += LOOP_UNROLL) {
        float err0 = a[i] - b[i];
        float err1 = a[i+1] - b[i+1];
        float err2 = a[i+2] - b[i+2];
        float err3 = a[i+3] - b[i+3];
        float x = err0 * err0 + err1 * err1;
        float y = err2 * err2 + err3 * err3;
        float v = x + y;
        for(bit = LOOP_UNROLL; (i & bit) != 0; bit = bit << 1) {
            v += stack[--top];
        }
        stack[top++] = v;
    }
    for(; i < n; ++i) {
        float err = a[i] - b[i];
        s += err * err;
    }
    for(i = top - 1; i >= 0; --i) {
        s += stack[i];
    }
    return s;
}

double swSparse_d_mse(int n, const double *a, const double *b) {
    double stack[MAX_STACK] = {0.0};
    double s = 0.0;
    int i, bit, top = 0;
    for(i = 0; i < (n & LOOP_UNROLL_MASK); i += LOOP_UNROLL) {
        double err0 = a[i] - b[i];
        double err1 = a[i+1] - b[i+1];
        double err2 = a[i+2] - b[i+2];
        double err3 = a[i+3] - b[i+3];
        double x = err0 * err0 + err1 * err1;
        double y = err2 * err2 + err3 * err3;
        double v = x + y;
        for(bit = LOOP_UNROLL; (i & bit) != 0; bit = bit << 1) {
            v += stack[--top];
        }
        stack[top++] = v;
    }
    for(; i < n; ++i) {
        double err = a[i] - b[i];
        s += err * err;
    }
    for(i = top - 1; i >= 0; --i) {
        s += stack[i];
    }
    return s;
}

float swSparse_s_norm_2(int n, const float *a) {
    float stack[MAX_STACK] = {0.0f};
    float s = 0.0f;
    int i, bit, top = 0;
    for(i = 0; i < (n & LOOP_UNROLL_MASK); i += LOOP_UNROLL) {
        float err0 = a[i];
        float err1 = a[i+1];
        float err2 = a[i+2];
        float err3 = a[i+3];
        float x = err0 * err0 + err1 * err1;
        float y = err2 * err2 + err3 * err3;
        float v = x + y;
        for(bit = LOOP_UNROLL; (i & bit) != 0; bit = bit << 1) {
            v += stack[--top];
        }
        stack[top++] = v;
    }
    for(; i < n; ++i) {
        float err = a[i];
        s += err * err;
    }
    for(i = top - 1; i >= 0; --i) {
        s += stack[i];
    }
    return s;
}

double swSparse_d_norm_2(int n, const double *a) {
    double stack[MAX_STACK] = {0.0};
    double s = 0.0;
    int i, bit, top = 0;
    for(i = 0; i < (n & LOOP_UNROLL_MASK); i += LOOP_UNROLL) {
        double err0 = a[i];
        double err1 = a[i+1];
        double err2 = a[i+2];
        double err3 = a[i+3];
        double x = err0 * err0 + err1 * err1;
        double y = err2 * err2 + err3 * err3;
        double v = x + y;
        for(bit = LOOP_UNROLL; (i & bit) != 0; bit = bit << 1) {
            v += stack[--top];
        }
        stack[top++] = v;
    }
    for(; i < n; ++i) {
        double err = a[i];
        s += err * err;
    }
    for(i = top - 1; i >= 0; --i) {
        s += stack[i];
    }
    return s;
}
