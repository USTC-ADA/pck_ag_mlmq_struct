#include <stdio.h>
#include <string.h>
#include <math.h>
#include "swSparse_base.h"
#include "internal/rename.h"
#include "internal/reorder.h"
#include "internal/utils.h"
#include "internal/debug.h"

#define DOUBLE_TOL 1e-10
#define SINGLE_TOL 1e-5f

Bool swSparse_s_compare_vec(Int n, const float *a, const float *b) {
    float err = sqrtf(swSparse_s_mse(n, a, b));
    if(err != 0.0f) {
        float norm = sqrtf(swSparse_s_norm_2(n, a)), re = err / norm;
        fprintf(stderr, "Floating point error exists: relative RMSE = %e (%e / %e)\n", re, err, norm);
        if(err < SINGLE_TOL * norm) {
            return true;
        } else {
            return false;
        }
    } else return true;
}

Bool swSparse_d_compare_vec(Int n, const double *a, const double *b) {
    double err = sqrt(swSparse_d_mse(n, a, b));
    if(err != 0.0f) {
        double norm = sqrt(swSparse_d_norm_2(n, a)), re = err / norm;
        fprintf(stderr, "Floating point error exists: relative RMSE = %e (%e / %e)\n", re, err, norm);
        if(err < DOUBLE_TOL * norm) {
            return true;
        } else {
            return false;
        }
    } else return true;
}

Bool swSparse_compare(Matrix a, Matrix b) {
    void *va;
    void *vb;
    if(a->format_type != b->format_type) {
        DEBUG_PRINTF("Different formats\n");
        return false;
    }
    if(a->element_type != b->element_type) {
        DEBUG_PRINTF("Different data types of values\n");
        return false;
    }
    if(a->status != b->status) {
        DEBUG_PRINTF("Different status\n");
        return false;
    }
    if(a->m != b->m) {
        DEBUG_PRINTF("Different sizes: %d != %d\n", a->m, b->m);
        return false;
    }
    if(a->n != b->n) {
        DEBUG_PRINTF("Different sizes: %d != %d\n", a->n, b->n);
        return false;
    }
    if(a->nnz != b->nnz) {
        DEBUG_PRINTF("Different number of nonzeros: %d != %d\n", a->nnz, b->nnz);
        return false;
    }
    ErrorStatus ret = swSparse_ensure_order(a);
    if(ret != SWSPARSE_SUCCESS) {
        DEBUG_PRINTF("Fail in sort\n");
        return ret;
    }
    ret = swSparse_ensure_order(b);
    if(ret != SWSPARSE_SUCCESS) {
        DEBUG_PRINTF("Fail in sort\n");
        return ret;
    }
    switch (a->format_type) {
    case CSR:
        if(memcmp(a->matrix.csrc->offsets, b->matrix.csrc->offsets, sizeof(Int) * (a->m + 1)) != 0) {
            DEBUG_PRINTF("Different row offsets\n");
            return false;
        }
        if(memcmp(a->matrix.csrc->indices, b->matrix.csrc->indices, sizeof(Int) * a->nnz) != 0) {
            DEBUG_PRINTF("Different column indices\n");
            return false;
        }
        va = a->matrix.csrc->values;
        vb = b->matrix.csrc->values;
        break;
    case CSC:
        if(memcmp(a->matrix.csrc->offsets, b->matrix.csrc->offsets, sizeof(Int) * (a->n + 1)) != 0) {
            DEBUG_PRINTF("Different column offsets\n");
            return false;
        }
        if(memcmp(a->matrix.csrc->indices, b->matrix.csrc->indices, sizeof(Int) * a->nnz) != 0) {
            DEBUG_PRINTF("Different row indices\n");
            return false;
        }
        va = a->matrix.csrc->values;
        vb = b->matrix.csrc->values;
        break;
    case COO:
        if(memcmp(a->matrix.coo->row_indices, b->matrix.coo->row_indices, sizeof(Int) * a->nnz) != 0) {
            DEBUG_PRINTF("Different row indices\n");
            return false;
        }
        if(memcmp(a->matrix.coo->column_indices, b->matrix.coo->column_indices, sizeof(Int) * a->nnz) != 0) {
            DEBUG_PRINTF("Different column indices\n");
            return false;
        }
        va = a->matrix.coo->values;
        vb = b->matrix.coo->values;
    break;
    
    default:
        DEBUG_PRINTF("Unable to compare non-standard formats\n");
        return false;
    }
    switch (a->element_type) {
        case REAL_SINGLE:
            return swSparse_s_compare_vec(a->nnz, va, vb);
        case REAL_DOUBLE:
            return swSparse_d_compare_vec(a->nnz, va, vb);
        case COMPLEX_SINGLE:
            return swSparse_s_compare_vec(a->nnz * 2, va, vb);
        case COMPLEX_DOUBLE:
            return swSparse_d_compare_vec(a->nnz * 2, va, vb);
        default:
            return false;
    }
}
