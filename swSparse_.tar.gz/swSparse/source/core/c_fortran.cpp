#include "swSparse.h"
#include "internal/spblas_common.h"

#ifndef EXTERN
#define EXTERN extern "C"
#endif
using FortranMatrix = uintptr_t;

#define DATA_TYPE_S
#include "c_fortran.inl"
#undef DATA_TYPE_S
#define DATA_TYPE_D
#include "c_fortran.inl"
#undef DATA_TYPE_D
#define DATA_TYPE_C
#include "c_fortran.inl"
#undef DATA_TYPE_C
#define DATA_TYPE_Z
#include "c_fortran.inl"
#undef DATA_TYPE_Z

EXTERN void swsparse_index_fortran_to_c_(const Int* in_index, Int* out_index, const Int* n) {
    swSparse::index_shift(*n, in_index, out_index, -1);
}

EXTERN void swsparse_index_c_to_fortran_(const Int* in_index, Int *out_index, const Int* n) {
    swSparse::index_shift(*n, in_index, out_index, 1);
}
