#include "internal/multicompile.h"
#include "internal/memory.h"
#include "internal/templates.h"

static ErrorStatus scale(DATA_T alpha, Matrix old_mat, Matrix* new_mat, bool trans) {
    if((old_mat->format_type == CSC) || (old_mat->format_type == CSR)) {
        Matrix cc;
        ErrorStatus ret;
        if(trans ^ (old_mat->format_type == CSC)) {
            ret = FUNCNAME(allocate_csc)(&cc, old_mat->m, old_mat->n, old_mat->nnz);
        } else {
            ret = FUNCNAME(allocate_csr)(&cc, old_mat->m, old_mat->n, old_mat->nnz);
        }
        if(ret == SWSPARSE_SUCCESS) {
            Int nnz = old_mat->nnz;
            swSparse_memcpy(cc->matrix.csrc->offsets, old_mat->matrix.csrc->offsets, (old_mat->m + 1) * sizeof(Int));
            swSparse_memcpy(cc->matrix.csrc->indices, old_mat->matrix.csrc->indices, old_mat->nnz * sizeof(Int));
            vector_scale<DATA_T>(alpha, nnz, VALUES(old_mat->matrix.csrc, DATA_T), VALUES(cc->matrix.csrc, DATA_T));
            *new_mat = cc;
        }
        return ret;
    } else {
        PRINT_FORMAT_ERROR(type_traits<DATA_T>::name_short, "scale");
        return SWSPARSE_INVALID_ARGS;
    }
}

#if defined(DATA_TYPE_S) || defined(DATA_TYPE_D)
INLINE ErrorStatus scale_conjugate(DATA_T alpha, Matrix old_mat, Matrix* new_mat, bool trans) {
    return scale(alpha, old_mat, new_mat, trans);
}
#else
static ErrorStatus scale_conjugate(DATA_T alpha, Matrix old_mat, Matrix* new_mat, bool trans) {
    if((old_mat->format_type == CSC) || (old_mat->format_type == CSR)) {
        Matrix cc;
        ErrorStatus ret;
        if(trans ^ (old_mat->format_type == CSC)) {
            ret = FUNCNAME(allocate_csc)(&cc, old_mat->m, old_mat->n, old_mat->nnz);
        } else {
            ret = FUNCNAME(allocate_csr)(&cc, old_mat->m, old_mat->n, old_mat->nnz);
        }
        if(ret == SWSPARSE_SUCCESS) {
            Int nnz = old_mat->nnz;
            swSparse_memcpy(cc->matrix.csrc->offsets, old_mat->matrix.csrc->offsets, (old_mat->m + 1) * sizeof(Int));
            swSparse_memcpy(cc->matrix.csrc->indices, old_mat->matrix.csrc->indices, old_mat->nnz * sizeof(Int));
            vector_scale_conj<DATA_T>(alpha, nnz, VALUES(old_mat->matrix.csrc, DATA_T), VALUES(cc->matrix.csrc, DATA_T));
            *new_mat = cc;
        }
        return ret;
    } else {
        PRINT_FORMAT_ERROR(type_traits<DATA_T>::name_short, "scale_conjugate");
        return SWSPARSE_INVALID_ARGS;
    }
}
#endif

ErrorStatus FUNCNAME(gemm)(DATA_T alpha, Matrix a, Matrix b, DATA_T beta, Matrix d, Matrix *c, const swSparseGEMMOptions* options) {
    if(check_trans_exclusive(options->transpose_A)) {
        PRINT_TRANS_ERROR("swSparseGEMMOptions::transpose_A");
        return SWSPARSE_INVALID_ARGS;
    }
    if(check_trans_exclusive(options->transpose_B)) {
        PRINT_TRANS_ERROR("swSparseGEMMOptions::transpose_B");
        return SWSPARSE_INVALID_ARGS;
    }
    if((options->order_C != SWSPARSE_ORDERED) && (options->order_C != SWSPARSE_UNORDERED)) {
        DEBUG_PRINTF("Invalid option in swSparseGEMMOptions::order_C: must be SWSPARSE_ORDERED or SWSPARSE_UNORDERED\n");
        return SWSPARSE_INVALID_ARGS;
    }
    if((!equals_zero(beta)) && (d == SWSPARSE_MATRIX_NULL)) {
        DEBUG_PRINTF("Error: D is NULL while beta is not zero in swSparse_%c_gemm\n", TYPENAME_CHAR);
        return SWSPARSE_INVALID_ARGS;
    }
    if(equals_zero(alpha)) {
        if(equals_zero(beta)) {
            MatrixFormatType format;
            Int m, n;
            if(d == SWSPARSE_MATRIX_NULL) {
                if(a == SWSPARSE_MATRIX_NULL) {
                    PRINT_NULL_ERROR('A', 'D', TYPENAME_CHAR, "gemm");
                    return SWSPARSE_INVALID_ARGS;
                }
                if(b == SWSPARSE_MATRIX_NULL) {
                    PRINT_NULL_ERROR('B', 'D', TYPENAME_CHAR, "gemm");
                    return SWSPARSE_INVALID_ARGS;
                }
                format = get_output_format(a->format_type, options->transpose_A, \
                                           b->format_type, options->transpose_B);
                m = a->m;
                n = b->n;
            } else {
                format = d->format_type;
                m = d->m;
                n = b->n;
            }
            switch(format) {
            case CSR:
                return FUNCNAME(allocate_csr)(c, m, n, 0);
            case CSC:
                return FUNCNAME(allocate_csc)(c, m, n, 0);
            default:
                PRINT_FORMAT_ERROR(TYPENAME_CHAR, "gemm");
                return SWSPARSE_INVALID_ARGS;
            }
        } else {
            return scale(beta, d, c, false);
        }
    } else {
        MatrixCSRC dummy = {NULL, NULL, NULL, 1, 1};
        ErrorStatus ret = SWSPARSE_SUCCESS;
        MatrixCSRC *a_mat = a->matrix.csrc;
        MatrixCSRC *b_mat = b->matrix.csrc;
        MatrixCSRC *d_mat = (equals_zero(beta)) ? &dummy : d->matrix.csrc;
        Matrix created;
        Int c_ld = 0;
        Bool rc;
        Bool ca = (options->transpose_A & SWSPARSE_CONJUGATE) != 0;
        Bool cb = (options->transpose_B & SWSPARSE_CONJUGATE) != 0;
        Bool sa = (options->transpose_A & NO_TRANS) != 0;
        Bool sb = (options->transpose_B & NO_TRANS) != 0;
        Bool ra = (a->format_type == CSR) ? sa : !sa;
        Bool rb = (b->format_type == CSR) ? sb : !sb;
        Int a_m = sa ? a->m : a->n;
        Int a_n = sa ? a->n : a->m;
        Int b_m = sb ? b->m : b->n;
        Int b_n = sb ? b->n : b->m;
        MatrixFormatType format;

        if(ELEMENT_TYPE != b->element_type || ELEMENT_TYPE != a->element_type) {
            DEBUG_PRINTF("Invalid value types in swSparse_%c_gemm\n", TYPENAME_CHAR);
            return SWSPARSE_INVALID_ARGS;
        } 
        if (a_n != b_m) {
            DEBUG_PRINTF("Matrix sizes are not matched in swSparse_%c_gemm\n", TYPENAME_CHAR);
            return SWSPARSE_INVALID_ARGS;
        }
        if(((a->format_type != CSR) && (a->format_type != CSC)) || ((b->format_type != CSR) && (b->format_type != CSC))) {
            PRINT_FORMAT_ERROR(TYPENAME_CHAR, "gemm");
            return SWSPARSE_INVALID_ARGS;
        }
        created = (Matrix)swSparse_malloc(sizeof(MatrixData));
        IF_ERR(created == NULL) {
            return MALLOC_ERROR;
        } 
        created->matrix.csrc = (MatrixCSRC*)swSparse_malloc(sizeof(MatrixCSRC));
        IF_ERR(created->matrix.csrc == NULL) {
            return clean_return(MALLOC_ERROR, created);
        }
        created->matrix.csrc->ref_count = 1;
        created->matrix.csrc->ordered = (options->order_C == SWSPARSE_ORDERED);
        if(ra == rb) {
            rc = ra;
        } else if(sa && !sb) {
            rc = ra;
        } else if(!sa && sb) {
            rc = rb;
        } else {
            PRINT_FORMAT_ERROR(TYPENAME_CHAR, "gemm");
            return SWSPARSE_INVALID_ARGS;
        }

        if(rc) {
            created->format_type = CSR;
            c_ld = a_m;
            if((!equals_zero(beta)) && (d->format_type != CSR)) {
                PRINT_FORMAT_ERROR(TYPENAME_CHAR, "gemm");
                return SWSPARSE_INVALID_ARGS;
            }
            if(ra) {
                if(rb) {
                    ret = gemm_csr<DATA_T>(alpha, beta, a_m, b_n, b_m, a_mat, b_mat, d_mat, created->matrix.csrc, ca, cb);
                } else {
                    ret = ABT<DATA_T>(alpha, beta, a_m, b_n, b_m, a_mat, b_mat, d_mat, created->matrix.csrc, ca, cb);
                }
            } else {
                ret = ATB<DATA_T>(alpha, beta, a_m, b_n, b_m, a_mat, b_mat, d_mat, created->matrix.csrc, ca, cb);
            }
        } else {
            created->format_type = CSC;
            c_ld = b_n;
            if((!equals_zero(beta)) && (d->format_type != CSC)) {
                PRINT_FORMAT_ERROR(TYPENAME_CHAR, "gemm");
                return SWSPARSE_INVALID_ARGS;
            }
            if(ra) {
                ret = ABT<DATA_T>(alpha, beta, b_n, a_m, a_n, b_mat, a_mat, d_mat, created->matrix.csrc, ca, cb);
            } else {
                if(rb) {
                    ret = ATB<DATA_T>(alpha, beta, b_n, a_m, a_n, b_mat, a_mat, d_mat, created->matrix.csrc, ca, cb);
                } else {
                    ret = gemm_csr<DATA_T>(alpha, beta, b_n, a_m, a_n, b_mat, a_mat, d_mat, created->matrix.csrc, ca, cb);
                }
            }
        }

        IF_ERR(ret != SWSPARSE_SUCCESS) {
            return clean_return(ret, created, created->matrix.csrc);
        }
        created->m = a_m;
        created->n = b_n;
        created->nnz = created->matrix.csrc->offsets[c_ld];
        created->element_type = ELEMENT_TYPE;
        created->status = 0;
        *c = created;
        return SWSPARSE_SUCCESS;
    }
}


ErrorStatus FUNCNAME(add)(DATA_T alpha, Matrix a, DATA_T beta, Matrix b, Matrix *c, const swSparseADDOptions* options) {
    if(check_trans_exclusive(options->transpose_A)) {
        PRINT_TRANS_ERROR("swSparseADDOptions::transpose_A");
        return SWSPARSE_INVALID_ARGS;
    }
    if(check_trans_exclusive(options->transpose_B)) {
        PRINT_TRANS_ERROR("swSparseADDOptions::transpose_B");
        return SWSPARSE_INVALID_ARGS;
    }
    if(equals_zero(alpha)) {
        if(equals_zero(beta)) {
            MatrixFormatType format;
            Int m, n;
            if(a == SWSPARSE_MATRIX_NULL) {
                if(b == SWSPARSE_MATRIX_NULL) {
                    PRINT_NULL_ERROR('A', 'B', TYPENAME_CHAR, "add");
                    return SWSPARSE_INVALID_ARGS;
                } else {
                    if(options->transpose_B) {
                        format = (b->format_type == CSR) ? CSC : ((b->format_type == CSC) ? CSR : COO);
                    } else {
                        format = b->format_type;
                    }
                }
            } else {
                if(b == SWSPARSE_MATRIX_NULL) {
                    if(options->transpose_A) {
                        format = (a->format_type == CSR) ? CSC : ((a->format_type == CSC) ? CSR : COO);
                    } else {
                        format = a->format_type;
                    }
                } else {
                    format = get_output_format(a->format_type, options->transpose_A, \
                                               b->format_type, options->transpose_B);
                }
            }
            switch(format) {
            case CSR:
                return FUNCNAME(allocate_csr)(c, m, n, 0);
            case CSC:
                return FUNCNAME(allocate_csc)(c, m, n, 0);
            default:
                PRINT_FORMAT_ERROR(TYPENAME_CHAR, "add");
                return SWSPARSE_INVALID_ARGS;
            }
        } else {
            bool trans = (options->transpose_B & SWSPARSE_TRANSPOSE) == SWSPARSE_TRANSPOSE;
            if((options->transpose_B & SWSPARSE_CONJUGATE) == SWSPARSE_CONJUGATE) {
                return scale_conjugate(beta, b, c, trans);
            } else {
                return scale(beta, b, c, trans);
            }
        }
    } else {
        if(equals_zero(beta)) {
            bool trans = (options->transpose_A & SWSPARSE_TRANSPOSE) == SWSPARSE_TRANSPOSE;
            if((options->transpose_A & SWSPARSE_CONJUGATE) == SWSPARSE_CONJUGATE) {
                return scale_conjugate(alpha, a, c, trans);
            } else {
                return scale(alpha, a, c, trans);
            }
        } else {
            ErrorStatus ret = SWSPARSE_SUCCESS;
            MatrixCSRC *a_mat = a->matrix.csrc;
            MatrixCSRC *b_mat = b->matrix.csrc;
            Matrix created;
            Int c_ld = 0;
            Bool rc;
            Bool ca = (options->transpose_A & SWSPARSE_CONJUGATE) != 0;
            Bool cb = (options->transpose_B & SWSPARSE_CONJUGATE) != 0;
            Bool sa = (options->transpose_A & NO_TRANS) != 0;
            Bool sb = (options->transpose_B & NO_TRANS) != 0;
            Bool ra = (a->format_type == CSR) ? sa : !sa;
            Bool rb = (b->format_type == CSR) ? sb : !sb;
            Int a_m = sa ? a->m : a->n;
            Int a_n = sa ? a->n : a->m;
            Int b_m = sb ? b->m : b->n;
            Int b_n = sb ? b->n : b->m;
            MatrixFormatType format;

            if(ELEMENT_TYPE != b->element_type || ELEMENT_TYPE != a->element_type) {
                DEBUG_PRINTF("Invalid value types in swSparse_%c_add\n", TYPENAME_CHAR);
                return SWSPARSE_INVALID_ARGS;
            } 
            if ((a_m != b_m) || (a_n != b_n)) {
                DEBUG_PRINTF("Matrix sizes are not matched in swSparse_%c_add\n", TYPENAME_CHAR);
                return SWSPARSE_INVALID_ARGS;
            }
            created = (Matrix)swSparse_malloc(sizeof(MatrixData));
            IF_ERR(created == NULL) {
                return MALLOC_ERROR;
            } 
            created->matrix.csrc = (MatrixCSRC*)swSparse_malloc(sizeof(MatrixCSRC));
            IF_ERR(created->matrix.csrc == NULL) {
                return clean_return(MALLOC_ERROR, created);
            }
            created->matrix.csrc->ref_count = 1;
            if(ra == rb) {
                rc = ra;
            } else if(sa && !sb) {
                rc = ra;
            } else if(!sa && sb) {
                rc = rb;
            } else {
                PRINT_FORMAT_ERROR(TYPENAME_CHAR, "add");
                return SWSPARSE_INVALID_ARGS;
            }

            if(rc) {
                created->format_type = CSR;
                c_ld = a_m;
                if(ra) {
                    if(rb) {
                        ret = add_csr<DATA_T>(alpha, beta, a_m, b_n, a_mat, b_mat, created->matrix.csrc, ca, cb);
                    } else {
                        ret = AplusBT<DATA_T>(alpha, beta, a_m, b_n, a_mat, b_mat, created->matrix.csrc, ca, cb);
                    }
                } else {
                    ret = ATplusB(alpha, beta, a_m, b_n, a_mat, b_mat, created->matrix.csrc, ca, cb);
                }
            } else {
                created->format_type = CSC;
                c_ld = b_n;
                if(ra) {
                    ret = AplusBT<DATA_T>(alpha, beta, b_n, a_m, a_mat, b_mat, created->matrix.csrc, ca, cb);
                } else {
                    if(rb) {
                        ret = ATplusB<DATA_T>(alpha, beta, b_n, a_m, a_mat, b_mat, created->matrix.csrc, ca, cb);
                    } else {
                        ret = add_csr<DATA_T>(alpha, beta, b_n, a_m, a_mat, b_mat, created->matrix.csrc, ca, cb);
                    }
                }
            }

            IF_ERR(ret != SWSPARSE_SUCCESS) {
                return clean_return(ret, created, created->matrix.csrc);
            }
            created->m = a_m;
            created->n = b_n;
            created->nnz = created->matrix.csrc->offsets[c_ld];
            created->element_type = ELEMENT_TYPE;
            created->status = 0;
            *c = created;
            return SWSPARSE_SUCCESS;
        }
    }
}

