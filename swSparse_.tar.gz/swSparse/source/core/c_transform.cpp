#include "swSparse_base.h"
#include "swSparse_matrix.h"
#include "internal/rename.h"
#include "internal/memory.h"
#include "internal/transform.h"
#include "internal/templates.h"

namespace swSparse {

static inline void copy_matrix_csrc(Matrix old_mat, Matrix new_mat) {
    new_mat->m = old_mat->m;
    new_mat->n = old_mat->n;
    new_mat->nnz = old_mat->nnz;
    new_mat->format_type = old_mat->format_type;
    new_mat->element_type = old_mat->element_type;
    new_mat->status = old_mat->status;
    new_mat->matrix.csrc = old_mat->matrix.csrc;
}

template<typename DATA_T>
ErrorStatus transpose_csr_x(Int m, Int n, MatrixCSRC *a, MatrixCSRC *at) {
    Int nnz = a->offsets[n];
    ErrorStatus ret = init_csrc_data(at, m, n, m, nnz, sizeof(DATA_T));
    IF_ERR(ret != SWSPARSE_SUCCESS) {
        return ret;
    }
    ret = transpose_csr(m, n, nnz, a->offsets, a->indices, VALUES(a, DATA_T), \
                            at->offsets, at->indices, VALUES(at, DATA_T));
    IF_ERR(ret != SWSPARSE_SUCCESS) {
        return clean_return(ret, at->offsets, at->indices, at->values);
    }
    at->ordered = true;
    return SWSPARSE_SUCCESS;
}

// convert template functions to C functions
template ErrorStatus transpose_csr_x<float>(Int m, Int n, MatrixCSRC *a, MatrixCSRC *at);
template ErrorStatus transpose_csr_x<double>(Int m, Int n, MatrixCSRC *a, MatrixCSRC *at);
template ErrorStatus transpose_csr_x<SComplex>(Int m, Int n, MatrixCSRC *a, MatrixCSRC *at);
template ErrorStatus transpose_csr_x<DComplex>(Int m, Int n, MatrixCSRC *a, MatrixCSRC *at);

template<typename DATA_T>
static ErrorStatus csc2csr(Matrix old_mat, Matrix *new_mat) {
    MatrixData created;
    const Int m = old_mat->m, n = old_mat->n, nnz = old_mat->nnz;
    Int *offsets = old_mat->matrix.csrc->offsets;
    Int *indices = old_mat->matrix.csrc->indices;
    DATA_T *values = VALUES(old_mat->matrix.csrc, DATA_T);
    ErrorStatus ret = init_csrc(&created, m, n, m, nnz, TYPE_ARG(DATA_T));
    IF_ERR(ret != SWSPARSE_SUCCESS) {
        return ret;
    }
    created.format_type = CSR;
    created.matrix.csrc->ordered = 1;
    ret = transpose_csr(n, m, nnz, offsets, indices, values, \
                        created.matrix.csrc->offsets, created.matrix.csrc->indices, \
                        VALUES(created.matrix.csrc, DATA_T));
    IF_ERR(ret != SWSPARSE_SUCCESS) {
        swSparse_destruct(&created);
        return ret;
    }
    
    if(new_mat != SWSPARSE_IN_PLACE) {
        Matrix created_mat = (Matrix)swSparse_malloc(sizeof(MatrixData));
        IF_ERR(created_mat == nullptr) {
            swSparse_destruct(&created);
            return MALLOC_ERROR;
        }
        copy_matrix_csrc(&created, created_mat);
        *new_mat = created_mat;
    } else {
        swSparse_destruct(old_mat);
        copy_matrix_csrc(&created, old_mat);
    }
    return SWSPARSE_SUCCESS;
}

template<typename DATA_T>
static ErrorStatus csr2csc(Matrix old_mat, Matrix *new_mat) {
    MatrixData created;
    const Int m = old_mat->m, n = old_mat->n, nnz = old_mat->nnz;
    Int *offsets = old_mat->matrix.csrc->offsets;
    Int *indices = old_mat->matrix.csrc->indices;
    DATA_T *values = VALUES(old_mat->matrix.csrc, DATA_T);
    ErrorStatus ret = init_csrc(&created, m, n, n, nnz, TYPE_ARG(DATA_T));
    IF_ERR(ret != SWSPARSE_SUCCESS) {
        return ret;
    }
    created.format_type = CSC;
    created.matrix.csrc->ordered = 1;
    ret = transpose_csr(m, n, nnz, offsets, indices, values, \
                        created.matrix.csrc->offsets, created.matrix.csrc->indices, \
                        VALUES(created.matrix.csrc, DATA_T));
    IF_ERR(ret != SWSPARSE_SUCCESS) {
        swSparse_destruct(&created);
        return ret;
    }
    
    if(new_mat != SWSPARSE_IN_PLACE) {
        Matrix created_mat = (Matrix)swSparse_malloc(sizeof(MatrixData));
        IF_ERR(created_mat == nullptr) {
            swSparse_destruct(&created);
            return MALLOC_ERROR;
        }
        copy_matrix_csrc(&created, created_mat);
        *new_mat = created_mat;
    } else {
        swSparse_destruct(old_mat);
        copy_matrix_csrc(&created, old_mat);
    }
    return SWSPARSE_SUCCESS;
}

template<typename DATA_T>
static ErrorStatus coo2csr(Matrix old_mat, Matrix *new_mat) {
    MatrixData created;
    const Int m = old_mat->m, n = old_mat->n, nnz = old_mat->nnz;
    Int *row_indices = old_mat->matrix.coo->row_indices;
    Int *column_indices = old_mat->matrix.coo->column_indices;
    DATA_T *values = VALUES(old_mat->matrix.coo, DATA_T);
    ErrorStatus ret = init_csrc(&created, m, n, m, nnz, TYPE_ARG(DATA_T));
    IF_ERR(ret != SWSPARSE_SUCCESS) {
        return ret;
    }
    created.format_type = CSR;
    created.matrix.csrc->ordered = 1;
    ret = convert_coo2csr(m, n, nnz, row_indices, column_indices, values, \
                        created.matrix.csrc->offsets, created.matrix.csrc->indices, \
                        VALUES(created.matrix.csrc, DATA_T));
    IF_ERR(ret != SWSPARSE_SUCCESS) {
        swSparse_destruct(&created);
        return ret;
    }
    
    if(new_mat != SWSPARSE_IN_PLACE) {
        Matrix created_mat = (Matrix)swSparse_malloc(sizeof(MatrixData));
        IF_ERR(created_mat == nullptr) {
            swSparse_destruct(&created);
            return MALLOC_ERROR;
        }
        copy_matrix_csrc(&created, created_mat);
        *new_mat = created_mat;
    } else {
        swSparse_destruct(old_mat);
        copy_matrix_csrc(&created, old_mat);
    }
    return SWSPARSE_SUCCESS;
}

template<typename DATA_T>
static ErrorStatus coo2csc(Matrix old_mat, Matrix *new_mat) {
    MatrixData created;
    const Int m = old_mat->m, n = old_mat->n, nnz = old_mat->nnz;
    Int *row_indices = old_mat->matrix.coo->row_indices;
    Int *column_indices = old_mat->matrix.coo->column_indices;
    DATA_T *values = VALUES(old_mat->matrix.coo, DATA_T);
    ErrorStatus ret = init_csrc(&created, m, n, n, nnz, TYPE_ARG(DATA_T));
    IF_ERR(ret != SWSPARSE_SUCCESS) {
        return ret;
    }
    created.format_type = CSC;
    created.matrix.csrc->ordered = 1;
    ret = convert_coo2csr(n, m, nnz, column_indices, row_indices, values, \
                        created.matrix.csrc->offsets, created.matrix.csrc->indices, \
                        VALUES(created.matrix.csrc, DATA_T));
    IF_ERR(ret != SWSPARSE_SUCCESS) {
        swSparse_destruct(&created);
        return ret;
    }
    
    if(new_mat != SWSPARSE_IN_PLACE) {
        Matrix created_mat = (Matrix)swSparse_malloc(sizeof(MatrixData));
        IF_ERR(created_mat == nullptr) {
            swSparse_destruct(&created);
            return MALLOC_ERROR;
        }
        copy_matrix_csrc(&created, created_mat);
        *new_mat = created_mat;
    } else {
        swSparse_destruct(old_mat);
        copy_matrix_csrc(&created, old_mat);
    }
    return SWSPARSE_SUCCESS;
}

template<typename DATA_T>
static ErrorStatus csr2coo(Matrix old_mat, Matrix *new_mat) {
    const Int m = old_mat->m, n = old_mat->n, nnz = old_mat->nnz;
    Int *offsets = old_mat->matrix.csrc->offsets;
    Int *column_indices = old_mat->matrix.csrc->indices;
    DATA_T *values = VALUES(old_mat->matrix.csrc, DATA_T);
    if(new_mat != SWSPARSE_IN_PLACE) {
        Matrix created;
        ErrorStatus ret = new_coo(&created, m, n, nnz, TYPE_ARG(DATA_T));
        IF_ERR(ret != SWSPARSE_SUCCESS) {
            return ret;
        }
        created->format_type = COO;
        swSparse_memcpy(created->matrix.coo->column_indices, column_indices, sizeof(Int) * nnz);
        swSparse_memcpy(created->matrix.coo->values, values, sizeof(DATA_T) * nnz);
        convert_csr2coo(m, offsets, created->matrix.coo->row_indices);
        *new_mat = created;
    } else {
        Int *row_indices = (Int*)swSparse_malloc(sizeof(Int) * nnz);
        IF_ERR(row_indices == nullptr) {
            return MALLOC_ERROR;
        }
        old_mat->format_type = COO;
        convert_csr2coo(m, offsets, row_indices);
        swSparse_free(offsets);
        old_mat->matrix.coo->row_indices = row_indices;
        old_mat->matrix.coo->column_indices = column_indices;
        old_mat->matrix.coo->values = values;
    }
    return SWSPARSE_SUCCESS;
}

template<typename DATA_T>
static ErrorStatus csc2coo(Matrix old_mat, Matrix *new_mat) {
    const Int m = old_mat->m, n = old_mat->n, nnz = old_mat->nnz;
    Int *offsets = old_mat->matrix.csrc->offsets;
    Int *row_indices = old_mat->matrix.csrc->indices;
    DATA_T *values = VALUES(old_mat->matrix.csrc, DATA_T);
    if(new_mat != SWSPARSE_IN_PLACE) {
        Matrix created;
        ErrorStatus ret = new_coo(&created, m, n, nnz, TYPE_ARG(DATA_T));
        IF_ERR(ret != SWSPARSE_SUCCESS) {
            return ret;
        }
        created->format_type = COO;
        swSparse_memcpy(created->matrix.coo->row_indices, row_indices, sizeof(Int) * nnz);
        swSparse_memcpy(created->matrix.coo->values, values, sizeof(DATA_T) * nnz);
        convert_csr2coo(n, offsets, created->matrix.coo->column_indices);
        *new_mat = created;
    } else {
        Int *column_indices = (Int*)swSparse_malloc(sizeof(Int) * nnz);
        IF_ERR(column_indices == nullptr) {
            return MALLOC_ERROR;
        }
        old_mat->format_type = COO;
        convert_csr2coo(n, offsets, column_indices);
        swSparse_free(offsets);
        old_mat->matrix.coo->row_indices = row_indices;
        old_mat->matrix.coo->column_indices = column_indices;
        old_mat->matrix.coo->values = values;
    }
    return SWSPARSE_SUCCESS;
}

template<typename DATA_T>
static ErrorStatus trans_coo(Matrix old_mat, Matrix new_mat) {
    Int nnz = old_mat->nnz;
    ErrorStatus ret = init_coo(new_mat, old_mat->n, old_mat->m, old_mat->nnz, TYPE_ARG(DATA_T));
    IF_ERR(ret != SWSPARSE_SUCCESS) {
        return ret;
    }
    swSparse_memcpy(new_mat->matrix.coo->column_indices, old_mat->matrix.coo->row_indices, sizeof(Int) * nnz);
    swSparse_memcpy(new_mat->matrix.coo->row_indices, old_mat->matrix.coo->column_indices, sizeof(Int) * nnz);
    swSparse_memcpy(new_mat->matrix.coo->values, old_mat->matrix.coo->values, sizeof(DATA_T) * nnz);
    return SWSPARSE_SUCCESS;
}

} //namespace swSparse

using namespace swSparse;

ErrorStatus swSparse_convert_csr(Matrix old_mat, Matrix *new_mat) {
    switch(old_mat->format_type) {
    case CSC:
        switch(old_mat->element_type) {
        case REAL_SINGLE:
            return csc2csr<float>(old_mat, new_mat);
        case REAL_DOUBLE:
            return csc2csr<double>(old_mat, new_mat);
        case COMPLEX_SINGLE:
            return csc2csr<SComplex>(old_mat, new_mat);
        case COMPLEX_DOUBLE:
            return csc2csr<DComplex>(old_mat, new_mat);
        default:
            return SWSPARSE_INVALID_ARGS;

        }
    case COO:
        switch(old_mat->element_type) {
        case REAL_SINGLE:
            return coo2csr<float>(old_mat, new_mat);
        case REAL_DOUBLE:
            return coo2csr<double>(old_mat, new_mat);
        case COMPLEX_SINGLE:
            return coo2csr<SComplex>(old_mat, new_mat);
        case COMPLEX_DOUBLE:
            return coo2csr<DComplex>(old_mat, new_mat);
        default:
            return SWSPARSE_INVALID_ARGS;
        }
    case CSR:
        if(new_mat == SWSPARSE_IN_PLACE) {
            return SWSPARSE_SUCCESS;
        } else {
            return swSparse_copy(old_mat, new_mat);
        }
    default:
        return SWSPARSE_INVALID_ARGS;
    }
}


ErrorStatus swSparse_convert_csc(Matrix old_mat, Matrix *new_mat) {
    switch(old_mat->format_type) {
    case CSR:
        switch(old_mat->element_type) {
        case REAL_SINGLE:
            return csr2csc<float>(old_mat, new_mat);
        case REAL_DOUBLE:
            return csr2csc<double>(old_mat, new_mat);
        case COMPLEX_SINGLE:
            return csr2csc<SComplex>(old_mat, new_mat);
        case COMPLEX_DOUBLE:
            return csr2csc<DComplex>(old_mat, new_mat);
        default:
            return SWSPARSE_INVALID_ARGS;

        }
    case COO:
        switch(old_mat->element_type) {
        case REAL_SINGLE:
            return coo2csc<float>(old_mat, new_mat);
        case REAL_DOUBLE:
            return coo2csc<double>(old_mat, new_mat);
        case COMPLEX_SINGLE:
            return coo2csc<SComplex>(old_mat, new_mat);
        case COMPLEX_DOUBLE:
            return coo2csc<DComplex>(old_mat, new_mat);
        default:
            return SWSPARSE_INVALID_ARGS;
        }
    case CSC:
        if(new_mat == SWSPARSE_IN_PLACE) {
            return SWSPARSE_SUCCESS;
        } else {
            return swSparse_copy(old_mat, new_mat);
        }
    default:
        return SWSPARSE_INVALID_ARGS;
    }
}

ErrorStatus swSparse_convert_coo(Matrix old_mat, Matrix *new_mat) {
    switch(old_mat->format_type) {
    case CSR:
        switch(old_mat->element_type) {
        case REAL_SINGLE:
            return csr2coo<float>(old_mat, new_mat);
        case REAL_DOUBLE:
            return csr2coo<double>(old_mat, new_mat);
        case COMPLEX_SINGLE:
            return csr2coo<SComplex>(old_mat, new_mat);
        case COMPLEX_DOUBLE:
            return csr2coo<DComplex>(old_mat, new_mat);
        default:
            return SWSPARSE_INVALID_ARGS;
        }
    case CSC:
        switch(old_mat->element_type) {
        case REAL_SINGLE:
            return csc2coo<float>(old_mat, new_mat);
        case REAL_DOUBLE:
            return csc2coo<double>(old_mat, new_mat);
        case COMPLEX_SINGLE:
            return csc2coo<SComplex>(old_mat, new_mat);
        case COMPLEX_DOUBLE:
            return csc2coo<DComplex>(old_mat, new_mat);
        default:
            return SWSPARSE_INVALID_ARGS;
        }
    case COO:
        if(new_mat == SWSPARSE_IN_PLACE) {
            return SWSPARSE_SUCCESS;
        } else {
            return swSparse_copy(old_mat, new_mat);
        }
    default:
        return SWSPARSE_INVALID_ARGS;
    }
}

ErrorStatus swSparse_transpose(Matrix old_mat, Matrix *new_mat) {
    switch(old_mat->format_type) {
    case COO:
        if(new_mat == SWSPARSE_IN_PLACE) {
            if(old_mat->matrix.coo->ref_count > 1) {
                MatrixData temp;
                ErrorStatus ret;
                switch (old_mat->element_type) {
                case REAL_SINGLE:
                    ret = trans_coo<float>(old_mat, &temp);
                    break;
                case REAL_DOUBLE:
                    ret = trans_coo<double>(old_mat, &temp);
                    break;
                case COMPLEX_SINGLE:
                    ret = trans_coo<SComplex>(old_mat, &temp);
                    break;
                case COMPLEX_DOUBLE:
                    ret = trans_coo<DComplex>(old_mat, &temp);
                    break;
                default:
                    ret = SWSPARSE_INVALID_ARGS;
                }
                IF_ERR(ret != SWSPARSE_SUCCESS) {
                    return ret;
                }
                old_mat->matrix.coo->ref_count --;
                old_mat->matrix.coo = temp.matrix.coo;
            } else {
                Int m = old_mat->m, n = old_mat->n;
                Int *tmp = old_mat->matrix.coo->column_indices;
                old_mat->matrix.coo->column_indices = old_mat->matrix.coo->row_indices;
                old_mat->matrix.coo->row_indices = tmp;
                old_mat->m = n;
                old_mat->n = m;
            }
            return SWSPARSE_SUCCESS;
        } else {
            Matrix temp = (Matrix)swSparse_malloc(sizeof(MatrixData));
            ErrorStatus ret;
            IF_ERR(temp == nullptr) {
                return MALLOC_ERROR;
            }
            switch (old_mat->element_type) {
            case REAL_SINGLE:
                ret = trans_coo<float>(old_mat, temp);
                break;
            case REAL_DOUBLE:
                ret = trans_coo<double>(old_mat, temp);
                break;
            case COMPLEX_SINGLE:
                ret = trans_coo<SComplex>(old_mat, temp);
                break;
            case COMPLEX_DOUBLE:
                ret = trans_coo<DComplex>(old_mat, temp);
                break;
            default:
                ret = SWSPARSE_INVALID_ARGS;
            }
            IF_ERR(ret != SWSPARSE_SUCCESS) {
                return clean_return(ret, temp);
            }
            *new_mat = temp;
            return ret;
        }
    case CSR:
        {
            Int m = old_mat->m, n = old_mat->n;
            ErrorStatus ret;
            switch (old_mat->element_type) {
            case REAL_SINGLE:
                ret = csr2csc<float>(old_mat, new_mat);
                break;
            case REAL_DOUBLE:
                ret = csr2csc<double>(old_mat, new_mat);
                break;
            case COMPLEX_SINGLE:
                ret = csr2csc<SComplex>(old_mat, new_mat);
                break;
            case COMPLEX_DOUBLE:
                ret = csr2csc<DComplex>(old_mat, new_mat);
                break;
            default:
                ret = SWSPARSE_INVALID_ARGS;
            }
            IF_ERR(ret != SWSPARSE_SUCCESS) {
                return ret;
            }
            if(new_mat == SWSPARSE_IN_PLACE) {
                old_mat->format_type = CSR;
                old_mat->n = m;
                old_mat->m = n;
            } else {
                Matrix created = *new_mat;
                created->format_type = CSR;
                created->n = m;
                created->m = n;
            }
            return SWSPARSE_SUCCESS;
        }
    case CSC:
        {
            Int m = old_mat->m, n = old_mat->n;
            ErrorStatus ret;
            switch (old_mat->element_type) {
            case REAL_SINGLE:
                ret = csc2csr<float>(old_mat, new_mat);
                break;
            case REAL_DOUBLE:
                ret = csc2csr<double>(old_mat, new_mat);
                break;
            case COMPLEX_SINGLE:
                ret = csc2csr<SComplex>(old_mat, new_mat);
                break;
            case COMPLEX_DOUBLE:
                ret = csc2csr<DComplex>(old_mat, new_mat);
                break;
            default:
                ret = SWSPARSE_INVALID_ARGS;
            }
            IF_ERR(ret != SWSPARSE_SUCCESS) {
                return ret;
            }
            if(new_mat == SWSPARSE_IN_PLACE) {
                old_mat->format_type = CSC;
                old_mat->n = m;
                old_mat->m = n;
            } else {
                Matrix created = *new_mat;
                created->format_type = CSC;
                created->n = m;
                created->m = n;
            }
            return SWSPARSE_SUCCESS;
        }
        break;
    default:
        return SWSPARSE_INVALID_ARGS;
    }
}
