#include <cmath>
#include "swSparse.h"
#include "internal/rename.h"
#include "internal/memory.h"
#include "internal/debug.h"
#include "internal/utils.h"
#include "internal/templates.h"
#include "internal/sptrf_common.h"

// these routines can be parallel, but are not implemented yet
namespace swSparse {
/*
// multiplication by a power-of-2 has no rounding error
template<typename REAL_T>
INLINE REAL_T column_scaling_factor(REAL_T col_max) {
	if (col_max >= static_cast<REAL_T>(0.5) && col_max <= static_cast<REAL_T>(2.0)) {
		return reciprocal(col_max);
	} else {
		return std::scalbn(static_cast<REAL_T>(1), -std::ilogb(m));
	}
}
*/

template<typename REAL_T>
inline REAL_T div_sqrt(REAL_T num, REAL_T square_den) {
	return num / std::sqrt(square_den);
}

template<typename REAL_T>
inline Bool check_converge(REAL_T x) {
	return fabs(x - static_cast<REAL_T>(1)) > precision<REAL_T>::sqrt_epsilon;
}

//   not parallel for now
//   find the scaling factor for equlibration, from alternating directions: column -> row -> column -> row -> ...
// NOTE: this routine is only called when [MC64 is disabled] OR when [refact on the same pattern]
template<typename DATA_T>
preprocess_status_t scale_alternate_direction(Int n, Int nnz, const Int* RSTR offsets, const Int* RSTR indices, \
    const DATA_T* RSTR values, real_t<DATA_T>* RSTR rscale, real_t<DATA_T>* RSTR cscale, real_t<DATA_T>* RSTR rwork) {
	using REAL = real_t<DATA_T>;
	real_t<DATA_T>* RSTR row_max = rwork;
	real_t<DATA_T>* RSTR eq_abs = rwork + n;
	preprocess_status_t ret = STATUS_GOOD;
	Bool not_converge = false;
	
	// first run, check zeros, init rscale and cscale
	swSparse_memset(row_max, 0, sizeof(REAL) * n);
	for(Int i = 0; i < n; ++i) {
		Bool diag_zero = true;

		// find column max
		REAL col_max = 0;
		for(Int p = offsets[i]; p < offsets[i + 1]; ++p) {
			REAL val = fabs(values[p]);
			col_max = (col_max > val) ? col_max : val;
			eq_abs[p] = val;
		}
		IF_ERR(col_max == 0) {
			return STATUS_SINGULAR;
		} 
		REAL s = reciprocal(col_max);
		cscale[i] = s;
		
		// update row max
		for(Int p = offsets[i]; p < offsets[i + 1]; ++p) {
			Int idx = indices[p];
			REAL val = eq_abs[p] * s, rm = row_max[idx];
			row_max[idx] = (rm > val) ? rm : val;
			eq_abs[p] = val;
			if(idx == i) {
				diag_zero = false;
			}
		}
		if(diag_zero) {
			ret = STATUS_ZERO_DIAG;
		}
	}
	for(Int i = 0; i < n; ++i) {
		REAL rm = row_max[i];
		IF_ERR(rm == 0) {
			return STATUS_SINGULAR;
		} else {
			REAL s = reciprocal(rm);
			rscale[i] = s;
			row_max[i] = s;
			not_converge |= check_converge(rm);
		}
	}
	while(not_converge) {
		not_converge = false;
		for(Int i = 0; i < n; ++i) {
			REAL col_max = 0;
			for(Int p = offsets[i]; p < offsets[i + 1]; ++p) {
				Int idx = indices[p];
				REAL val = eq_abs[p] * row_max[idx];  // row_max saves row scalars in the last round
				col_max = (col_max > val) ? col_max : val;
				eq_abs[p] = val;
			}
			if(check_converge(col_max)) {
				REAL s = reciprocal(col_max);
				cscale[i] *= s;
				not_converge = true;
				for(Int p = offsets[i]; p < offsets[i + 1]; ++p) {
					eq_abs[p] *= s;
				}
			}
		}
		if(not_converge) {
			not_converge = false;
			swSparse_memset(row_max, 0, sizeof(REAL) * n);
			for(Int i = 0; i < n; ++i) {
				for(Int p = offsets[i]; p < offsets[i + 1]; ++p) {
					Int idx = indices[p];
					REAL val = eq_abs[p], rm = row_max[idx];
					row_max[idx] = (rm > val) ? rm : val;
				}
			}
			for(Int i = 0; i < n; ++i) {
				REAL rm = row_max[i];
				if(check_converge(rm)) {
					REAL s = reciprocal(rm);
					rscale[i] *= s;
					row_max[i] = s;
					not_converge = true;	
				}
			}
		}
	}
	return ret;
}

//   very slow in sequential
//   not parallel for now
//   find the scaling factor for equlibration, from alternating directions: column -> row -> column -> row -> ...
// NOTE: this routine is only called when [MC64 is disabled] OR when [refact on the same pattern]
template<typename DATA_T>
preprocess_status_t scale_symmetric(Int n, Int nnz, const Int* RSTR offsets, const Int* RSTR indices, \
    const DATA_T* RSTR values, real_t<DATA_T>* RSTR rscale, real_t<DATA_T>* RSTR cscale, real_t<DATA_T>* RSTR rwork) {
	using REAL = real_t<DATA_T>;
	real_t<DATA_T>* RSTR row_max = rwork;
	real_t<DATA_T>* RSTR eq_abs = rwork + n;
	preprocess_status_t ret = STATUS_GOOD;
	Bool not_converge;

	// first run, check zeros, init rscale and cscale
	swSparse_memset(row_max, 0, sizeof(REAL) * n);
	for(Int i = 0; i < n; ++i) {
		Bool diag_zero = true;
		// find row column max
		REAL col_max = 0;
		for(Int p = offsets[i]; p < offsets[i + 1]; ++p) {
			Int idx = indices[p];
			REAL val = fabs(values[p]), rm = row_max[idx];
			row_max[idx] = (rm > val) ? rm : val;
			col_max = (col_max > val) ? col_max : val;
			eq_abs[p] = val;
			if(idx == i) {
				diag_zero = false;
			}
		}
		if(diag_zero) {
			ret = STATUS_ZERO_DIAG;
		}
		IF_ERR(col_max == 0) {
			return STATUS_SINGULAR;
		} 
		cscale[i] = div_sqrt(REAL(1), col_max);
	}
	for(Int i = 0; i < n; ++i) {
		REAL rm = row_max[i];
		IF_ERR(rm == 0) {
			return STATUS_SINGULAR;
		} else {
			rscale[i] = div_sqrt(REAL(1), rm);
		}
	}
	do {
		not_converge = false;
		swSparse_memset(row_max, 0, sizeof(REAL) * n);
		for(Int i = 0; i < n; ++i) {
			REAL col_max = 0, cs = cscale[i];
			for(Int p = offsets[i]; p < offsets[i + 1]; ++p) {
				Int idx = indices[p];
				REAL rm = row_max[idx], val = eq_abs[p] * cs * rscale[idx];
				row_max[idx] = (rm > val) ? rm : val;
				col_max = (col_max > val) ? col_max : val;
			}
			cscale[i] = div_sqrt(cs, col_max);
			not_converge |= check_converge(col_max);
		}
		for(Int i = 0; i < n; ++i) {
			REAL rm = row_max[i];
			rscale[i] = div_sqrt(rscale[i], rm);
			not_converge |= check_converge(rm);
		}
	} while(not_converge);
	return ret;
}



template<typename DATA_T>
preprocess_status_t norm_1_check_diagonal(Int n, Int nnz, const Int* RSTR offsets, const Int* RSTR indices, const DATA_T* RSTR values, real_t<DATA_T> *norm_1_ptr) {
	real_t<DATA_T> norm_1 = 0;
	preprocess_status_t ret = STATUS_GOOD;
	for(Int i = 0; i < n; ++i) {
		real_t<DATA_T> sum = 0;
		Bool diag_zero = true;
		for(Int p = offsets[i]; p < offsets[i + 1]; ++p) {
			if(indices[p] == i) {
				diag_zero = false;
			}
			sum += fabs(values[p]);
		}
		if(diag_zero) {
			ret = STATUS_ZERO_DIAG;
		}
		if(sum == 0.0) {
			return STATUS_SINGULAR;
		}
		norm_1 = (norm_1 > sum) ? norm_1 : sum;
	}
	*norm_1_ptr = norm_1;
	return ret;
}



#define INSTANTIATE(type) \
template preprocess_status_t norm_1_check_diagonal<type>(Int n, Int nnz, const Int* RSTR offsets, const Int* RSTR indices, \
	const type* RSTR values, real_t<type> *norm_1_ptr); \
template preprocess_status_t scale_alternate_direction<type>(Int n, Int nnz, const Int* RSTR offsets, const Int* RSTR indices, \
    const type* RSTR values, real_t<type>* RSTR rscale, real_t<type>* RSTR cscale, real_t<type>* RSTR rwork); \
template preprocess_status_t scale_symmetric<type>(Int n, Int nnz, const Int* RSTR offsets, const Int* RSTR indices, \
    const type* RSTR values, real_t<type>* RSTR rscale, real_t<type>* RSTR cscale, real_t<type>* RSTR rwork);

INSTANTIATE(float)
INSTANTIATE(double)
INSTANTIATE(SComplex)
INSTANTIATE(DComplex)

} // namespace swSparse
