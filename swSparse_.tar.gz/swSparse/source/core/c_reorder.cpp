#include "swSparse_reorder.h"
#include "internal/reorder.h"
#include "internal/rename.h"
#include "internal/memory.h"
#include "internal/debug.h"
#include "internal/utils.h"
#include "internal/templates.h"

using namespace swSparse;

// export ABI
ErrorStatus swSparse_perm_compose(Int n, const Int *first, const Int *second, Int *composed) {
    return perm_compose(n, first, second, composed);
}
ErrorStatus swSparse_iperm_compose(Int n, const Int *first, const Int *second, Int *composed) {
    return iperm_compose(n, first, second, composed);
}

#if DEBUG_LEVEL == 0
#define PRINT_FORMAT_ERROR
#else
static const char* format_error_message = "Invalid format: only CSR, CSC and COO are supported.\n";
#define PRINT_FORMAT_ERROR DEBUG_PRINTF(format_error_message);
#endif

/* for CSR, reorder rows */
template<typename DATA_T>
static void reorder_first_dim_impl(Int n, const Int *a_offsets, const Int *a_indices, const DATA_T *a_values, \
    Int *temp, Int *b_offsets, Int *b_indices, DATA_T *b_values, const Int *iperm) {
    Int * b_begins = temp;
    Int * b_ends = temp + n;
    swSparse_i_iperm_apply(n, a_offsets, b_begins, iperm);
    swSparse_i_iperm_apply(n, a_offsets + 1, b_ends, iperm);
    csr423(n, a_offsets[n], b_begins, b_ends, a_indices, a_values, b_offsets, b_indices, b_values);
}

/* for CSR, reorder rows and sort elements in each row */
template<typename DATA_T>
static ErrorStatus reorder_first_then_second(Int n, const Int *a_offsets, Int *a_indices, DATA_T *a_values, \
    Int *temp, Int *b_offsets, Int *b_indices, DATA_T *b_values, const Int *iperm1, const Int *iperm2) {
    Int * b_begins = temp;
    Int * b_ends = temp + n;
    swSparse_i_iperm_apply(n, a_offsets, b_begins, iperm1);
    swSparse_i_iperm_apply(n, a_offsets + 1, b_ends, iperm1);
    return csr423_perm(n, a_offsets[n], b_begins, b_ends, a_indices, a_values, iperm2, b_offsets, b_indices, b_values);
}

static ErrorStatus reorder_second_dim(Matrix old_mat, Matrix new_mat, \
                                    const Int *iperm, Int ld, MatrixElementType etype, size_t esize) {
    ErrorStatus ret;
    Int m = old_mat->m, n = old_mat->n, nnz = old_mat->nnz;
    MatrixCSRC *tmp1;
    MatrixCSRC *tmp2;
    ret = init_csrc(new_mat, m, n, ld, nnz, etype, esize);
    IF_ERR(ret != SWSPARSE_SUCCESS) {
        return ret;
    }
    new_mat->format_type = old_mat->format_type;
    tmp1 = old_mat->matrix.csrc;
    tmp2 = new_mat->matrix.csrc;
    swSparse_memcpy(tmp2->offsets, tmp1->offsets, sizeof(Int) * (ld + 1));
    swSparse_memcpy(tmp2->values, tmp1->values, esize * nnz);
    gather_by_indices(nnz, iperm, tmp2->indices, tmp1->indices);
    tmp2->ordered = false;
    return SWSPARSE_SUCCESS;
}

template<typename DATA_T>
static ErrorStatus reorder_first_dim(Matrix old_mat, Matrix new_mat, const Int *iperm, Int ld) {
    ErrorStatus ret;
    Int m = old_mat->m, n = old_mat->n, nnz = old_mat->nnz;
    MatrixCSRC *tmp1;
    MatrixCSRC *tmp2;
    Int *buffer;
    ret = init_csrc(new_mat, m, n, ld, nnz, TYPE_ARG(DATA_T));
    IF_ERR(ret != SWSPARSE_SUCCESS) {
        return ret;
    }
    new_mat->format_type = old_mat->format_type;
    tmp1 = old_mat->matrix.csrc;
    tmp2 = new_mat->matrix.csrc;
    buffer = (Int*)swSparse_malloc(sizeof(Int) * 2 * ld);
    IF_ERR(buffer == nullptr) {
        swSparse_destruct(new_mat);
        return MALLOC_ERROR;
    }
    reorder_first_dim_impl(ld, tmp1->offsets, tmp1->indices, (DATA_T*)tmp1->values, \
                            buffer, tmp2->offsets, tmp2->indices, (DATA_T*)tmp2->values, iperm);
    swSparse_free(buffer);
    return SWSPARSE_SUCCESS;
}

template<typename DATA_T>
static ErrorStatus reorder_both_dim(Matrix old_mat, Matrix new_mat, \
                                   const Int *iperm1, const Int *iperm2, Int ld) {
    ErrorStatus ret;
    Int m = old_mat->m, n = old_mat->n, nnz = old_mat->nnz;
    MatrixCSRC *tmp1;
    MatrixCSRC *tmp2;
    Int *buffer;
    ret = init_csrc(new_mat, m, n, ld, nnz, TYPE_ARG(DATA_T));
    IF_ERR(ret != SWSPARSE_SUCCESS) {
        return ret;
    }
    new_mat->format_type = old_mat->format_type;
    tmp1 = old_mat->matrix.csrc;
    tmp2 = new_mat->matrix.csrc;
    buffer = (Int*)swSparse_malloc(sizeof(Int) * 2 * ld);
    IF_ERR(buffer == nullptr) {
        swSparse_destruct(new_mat);
        return MALLOC_ERROR;
    }
    ret = reorder_first_then_second(ld, tmp1->offsets, tmp1->indices, (DATA_T*)tmp1->values, \
                                buffer, tmp2->offsets, tmp2->indices, (DATA_T*)tmp2->values, iperm1, iperm2);
    swSparse_free(buffer);
    return ret;
}

struct identity_t {};

inline void gather_or_copy(Int nnz, const Int* src, Int* dst, const Int* iperm) {
    gather_by_indices(nnz, src, dst, iperm);
}

inline void gather_or_copy(Int nnz, identity_t src, Int* dst, const Int* iperm) {
    swSparse_memcpy(dst, iperm, sizeof(Int) * nnz);
}

template<typename RIPERM, typename CIPERM>
static ErrorStatus reorder_coo(Matrix old_mat, Matrix new_mat, RIPERM riperm, CIPERM ciperm, \
                               MatrixElementType etype, size_t esize) {
    ErrorStatus ret;
    Int m = old_mat->m, n = old_mat->n, nnz = old_mat->nnz;
    MatrixCOO *tmp1;
    MatrixCOO *tmp2;
    ret = init_coo(new_mat, m, n, nnz, etype, esize);
    IF_ERR(ret != SWSPARSE_SUCCESS) {
        return ret;
    }
    new_mat->format_type = COO;
    tmp1 = old_mat->matrix.coo;
    tmp2 = new_mat->matrix.coo;
    swSparse_memcpy(tmp2->values, tmp1->values, esize * nnz);
    gather_or_copy(nnz, riperm, tmp2->row_indices,    tmp1->row_indices);
    gather_or_copy(nnz, ciperm, tmp2->column_indices, tmp1->column_indices);
    return SWSPARSE_SUCCESS;
}


template<typename DATA_T>
static ErrorStatus reorder_rows_impl(Matrix old_mat, Matrix* new_mat, const Int *riperm) {
    ErrorStatus ret;
    Matrix created = (Matrix)swSparse_malloc(sizeof(MatrixData));
    IF_ERR(created == nullptr) {
        return MALLOC_ERROR;
    }
    switch(old_mat->format_type) {
    case CSR:
        ret = reorder_first_dim<DATA_T>(old_mat, created, riperm, old_mat->m);
        break;
    case CSC:
        ret = reorder_second_dim(old_mat, created, riperm, old_mat->n, TYPE_ARG(DATA_T));
        break;
    case COO:
        ret = reorder_coo(old_mat, created, riperm, identity_t(), TYPE_ARG(DATA_T));
        break;
    default:
        PRINT_FORMAT_ERROR;
        ret = SWSPARSE_INVALID_ARGS;
        break;
    }
    if(ret == SWSPARSE_SUCCESS) {
        *new_mat = created;
    } else {
        swSparse_free(created);
    }
    return ret;
}


template<typename DATA_T>
static ErrorStatus reorder_columns_impl(Matrix old_mat, Matrix* new_mat, const Int *ciperm) {
    ErrorStatus ret;
    Matrix created = (Matrix)swSparse_malloc(sizeof(MatrixData));
    IF_ERR(created == nullptr) {
        return MALLOC_ERROR;
    }
    switch(old_mat->format_type) {
    case CSR:
        ret = reorder_second_dim(old_mat, created, ciperm, old_mat->m, TYPE_ARG(DATA_T));
        break;
    case CSC:
        ret = reorder_first_dim<DATA_T>(old_mat, created, ciperm, old_mat->n);
        break;
    case COO:
        ret = reorder_coo(old_mat, created, identity_t(), ciperm, TYPE_ARG(DATA_T));
        break;
    default:
        PRINT_FORMAT_ERROR;
        ret = SWSPARSE_INVALID_ARGS;
        break;
    }
    if(ret == SWSPARSE_SUCCESS) {
        *new_mat = created;
    } else {
        swSparse_free(created);
    }
    return ret;
}

template<typename DATA_T>
static ErrorStatus reorder_row_col_impl(Matrix old_mat, Matrix* new_mat, const Int* riperm, const Int* ciperm) {
    ErrorStatus ret;
    Matrix created = (Matrix)swSparse_malloc(sizeof(MatrixData));
    IF_ERR(created == nullptr) {
        return MALLOC_ERROR;
    }
    switch(old_mat->format_type) {
    case CSR:
        ret = reorder_both_dim<DATA_T>(old_mat, created, riperm, ciperm, old_mat->m);
        break;
    case CSC:
        ret = reorder_both_dim<DATA_T>(old_mat, created, ciperm, riperm, old_mat->n);
        break;
    case COO:
        ret = reorder_coo(old_mat, created, riperm, ciperm, TYPE_ARG(DATA_T));
        break;
    default:
        PRINT_FORMAT_ERROR;
        ret = SWSPARSE_INVALID_ARGS;
        break;
    }
    if(ret == SWSPARSE_SUCCESS) {
        *new_mat = created;
    } else {
        swSparse_free(created);
    }
    return ret;
}

template<typename DATA_T>
static ErrorStatus reorder_rows_inplace(Matrix old_mat, const Int *riperm) {
    MatrixData created;
    ErrorStatus ret;
    switch(old_mat->format_type) {
    case CSR:
        ret = reorder_first_dim<DATA_T>(old_mat, &created, riperm, old_mat->m);
        if(ret == SWSPARSE_SUCCESS) {
            swSparse_destruct(old_mat);
            old_mat->matrix.csrc = created.matrix.csrc;
        }
        break;
    case CSC:
        gather_by_indices(old_mat->nnz, riperm, old_mat->matrix.csrc->indices, old_mat->matrix.csrc->indices);
        old_mat->matrix.csrc->ordered = false;
        break;
    case COO:
        gather_by_indices(old_mat->nnz, riperm, old_mat->matrix.coo->row_indices, old_mat->matrix.coo->row_indices);
        break;
    default:
        PRINT_FORMAT_ERROR;
        ret = SWSPARSE_INVALID_ARGS;
        break;
    }
    return ret;
}

template<typename DATA_T>
static ErrorStatus reorder_column_inplace(Matrix old_mat, const Int *ciperm) {
    MatrixData created;
    ErrorStatus ret;
    switch(old_mat->format_type) {
    case CSR:
        gather_by_indices(old_mat->nnz, ciperm, old_mat->matrix.csrc->indices, old_mat->matrix.csrc->indices);
        old_mat->matrix.csrc->ordered = false;
        break;
    case CSC:
        ret = reorder_first_dim<DATA_T>(old_mat, &created, ciperm, old_mat->n);
        if(ret == SWSPARSE_SUCCESS) {
            swSparse_destruct(old_mat);
            old_mat->matrix.csrc = created.matrix.csrc;
        }
        break;
    case COO:
        gather_by_indices(old_mat->nnz, ciperm, old_mat->matrix.coo->column_indices, old_mat->matrix.coo->column_indices);
        break;
    default:
        PRINT_FORMAT_ERROR;
        ret = SWSPARSE_INVALID_ARGS;
        break;
    }
    return ret;
}

template<typename DATA_T>
static ErrorStatus reorder_row_col_inplace(Matrix old_mat, const Int* riperm, const Int *ciperm) {
    MatrixData created;
    ErrorStatus ret;
    switch(old_mat->format_type) {
    case CSR:
        ret = reorder_both_dim<DATA_T>(old_mat, &created, riperm, ciperm, old_mat->m);
        if(ret == SWSPARSE_SUCCESS) {
            swSparse_destruct(old_mat);
            old_mat->matrix.csrc = created.matrix.csrc;
        }
        break;
    case CSC:
        ret = reorder_both_dim<DATA_T>(old_mat, &created, ciperm, riperm, old_mat->n);
        if(ret == SWSPARSE_SUCCESS) {
            swSparse_destruct(old_mat);
            old_mat->matrix.csrc = created.matrix.csrc;
        }
        break;
    case COO:
        gather_by_indices(old_mat->nnz, riperm, old_mat->matrix.coo->row_indices, old_mat->matrix.coo->row_indices);
        gather_by_indices(old_mat->nnz, ciperm, old_mat->matrix.coo->column_indices, old_mat->matrix.coo->column_indices);
        break;
    default:
        PRINT_FORMAT_ERROR;
        ret = SWSPARSE_INVALID_ARGS;
        break;
    }
    return ret;
}

ErrorStatus reorder_rows(Matrix old_mat, Matrix *new_mat, const Int *riperm) {
    ErrorStatus ret = SWSPARSE_SUCCESS;
    if(new_mat == SWSPARSE_IN_PLACE) {
        switch(old_mat->element_type) {
        case REAL_SINGLE:
            ret = reorder_rows_inplace<float>(old_mat, riperm);
            break;
        case REAL_DOUBLE:
            ret = reorder_rows_inplace<double>(old_mat, riperm);
            break;
        case COMPLEX_SINGLE:
            ret = reorder_rows_inplace<SComplex>(old_mat, riperm);
            break;
        case COMPLEX_DOUBLE:
            ret = reorder_rows_inplace<DComplex>(old_mat, riperm);
            break;
        }
    } else {
        switch(old_mat->element_type) {
        case REAL_SINGLE:
            ret = reorder_rows_impl<float>(old_mat, new_mat, riperm);
            break;
        case REAL_DOUBLE:
            ret = reorder_rows_impl<double>(old_mat, new_mat, riperm);
            break;
        case COMPLEX_SINGLE:
            ret = reorder_rows_impl<SComplex>(old_mat, new_mat, riperm);
            break;
        case COMPLEX_DOUBLE:
            ret = reorder_rows_impl<DComplex>(old_mat, new_mat, riperm);
            break;
        }
    }
    return ret;
}


ErrorStatus reorder_row_col(Matrix old_mat, Matrix *new_mat, const Int *riperm, const Int *ciperm) {
    ErrorStatus ret = SWSPARSE_SUCCESS;
    if(new_mat == SWSPARSE_IN_PLACE) {
        switch(old_mat->element_type) {
        case REAL_SINGLE:
            ret = reorder_row_col_inplace<float>(old_mat, riperm, ciperm);
            break;
        case REAL_DOUBLE:
            ret = reorder_row_col_inplace<double>(old_mat, riperm, ciperm);
            break;
        case COMPLEX_SINGLE:
            ret = reorder_row_col_inplace<SComplex>(old_mat, riperm, ciperm);
            break;
        case COMPLEX_DOUBLE:
            ret = reorder_row_col_inplace<DComplex>(old_mat, riperm, ciperm);
            break;
        }
    } else {
        switch(old_mat->element_type) {
        case REAL_SINGLE:
            ret = reorder_row_col_impl<float>(old_mat, new_mat, riperm, ciperm);
            break;
        case REAL_DOUBLE:
            ret = reorder_row_col_impl<double>(old_mat, new_mat, riperm, ciperm);
            break;
        case COMPLEX_SINGLE:
            ret = reorder_row_col_impl<SComplex>(old_mat, new_mat, riperm, ciperm);
            break;
        case COMPLEX_DOUBLE:
            ret = reorder_row_col_impl<DComplex>(old_mat, new_mat, riperm, ciperm);
            break;
        }
    }
    return ret;
}

ErrorStatus reorder_columns(Matrix old_mat, Matrix *new_mat, const Int *ciperm) {
    ErrorStatus ret = SWSPARSE_SUCCESS;
    if(new_mat == SWSPARSE_IN_PLACE) {
        switch(old_mat->element_type) {
        case REAL_SINGLE:
            ret = reorder_column_inplace<float>(old_mat, ciperm);
            break;
        case REAL_DOUBLE:
            ret = reorder_column_inplace<double>(old_mat, ciperm);
            break;
        case COMPLEX_SINGLE:
            ret = reorder_column_inplace<SComplex>(old_mat, ciperm);
            break;
        case COMPLEX_DOUBLE:
            ret = reorder_column_inplace<DComplex>(old_mat, ciperm);
            break;
        }
    } else {
        switch(old_mat->element_type) {
        case REAL_SINGLE:
            ret = reorder_columns_impl<float>(old_mat, new_mat, ciperm);
            break;
        case REAL_DOUBLE:
            ret = reorder_columns_impl<double>(old_mat, new_mat, ciperm);
            break;
        case COMPLEX_SINGLE:
            ret = reorder_columns_impl<SComplex>(old_mat, new_mat, ciperm);
            break;
        case COMPLEX_DOUBLE:
            ret = reorder_columns_impl<DComplex>(old_mat, new_mat, ciperm);
            break;
        }
    }
    return ret;
}

ErrorStatus swSparse_set_order(Matrix mat, Bool ordered) {
    ErrorStatus ret;
    switch(mat->format_type) {
    case CSC:
    case CSR:
        ret = swSparse_ensure_ownership_csrc(mat);
        IF_ERR(ret != SWSPARSE_SUCCESS) {
            return ret;
        }
        mat->matrix.csrc->ordered = ordered;
        break;
    default:
        return SWSPARSE_INVALID_ARGS;
    }
    return SWSPARSE_SUCCESS;
}

ErrorStatus swSparse_set_nnz(Matrix mat, Int nnz) {
    ErrorStatus ret;
    Int value_size = element_size(mat->element_type), old_nnz = mat->nnz;
    switch(mat->format_type) {
    case CSC:
    case CSR:
        ret = swSparse_ensure_ownership_csrc(mat);
        IF_ERR(ret != SWSPARSE_SUCCESS) {
            return ret;
        }
        mat->matrix.csrc->indices = (Int*)resize_alloc(mat->matrix.csrc->indices, nnz * sizeof(Int), old_nnz * sizeof(Int));
        IF_ERR(mat->matrix.csrc->indices == nullptr) {
            return MALLOC_ERROR;
        }
        mat->matrix.csrc->values = resize_alloc(mat->matrix.csrc->values, nnz * value_size, old_nnz * value_size);
        IF_ERR(mat->matrix.csrc->values == nullptr) {
            return MALLOC_ERROR;
        }
        break;
    case COO:
        ret = swSparse_ensure_ownership_coo(mat);
        IF_ERR(ret != SWSPARSE_SUCCESS) {
            return ret;
        }
        mat->matrix.coo->row_indices = (Int*)resize_alloc(mat->matrix.coo->row_indices, nnz * sizeof(Int), old_nnz * sizeof(Int));
        IF_ERR(mat->matrix.coo->row_indices == nullptr) {
            return MALLOC_ERROR;
        }
        mat->matrix.coo->column_indices = (Int*)resize_alloc(mat->matrix.coo->column_indices, nnz * sizeof(Int), old_nnz * sizeof(Int));
        IF_ERR(mat->matrix.coo->column_indices == nullptr) {
            return MALLOC_ERROR;
        }
        mat->matrix.coo->values = resize_alloc(mat->matrix.coo->values, nnz * value_size, old_nnz * value_size);
        IF_ERR(mat->matrix.coo->values == nullptr) {
            return MALLOC_ERROR;
        }
        break;

    default:
        return SWSPARSE_INVALID_ARGS;
    }
    mat->nnz = nnz;
    return SWSPARSE_SUCCESS;
}

ErrorStatus swSparse_ensure_order(Matrix a) {
    ErrorStatus ret = SWSPARSE_SUCCESS;
    switch (a->format_type) {
    case CSR:
    case CSC:
        if(!a->matrix.csrc->ordered) {
            switch (a->element_type) {
            case REAL_SINGLE:
                ret = sort_elements(a->n, a->matrix.csrc->offsets, \
                                    a->matrix.csrc->indices, (float*)a->matrix.csrc->values);
                break;
            case REAL_DOUBLE:
                ret = sort_elements(a->n, a->matrix.csrc->offsets, \
                                    a->matrix.csrc->indices, (double*)a->matrix.csrc->values);
                break;
            case COMPLEX_SINGLE:
                ret = sort_elements(a->n, a->matrix.csrc->offsets, \
                                    a->matrix.csrc->indices, (SComplex*)a->matrix.csrc->values);
                break;
            case COMPLEX_DOUBLE:
                ret = sort_elements(a->n, a->matrix.csrc->offsets, \
                                    a->matrix.csrc->indices, (DComplex*)a->matrix.csrc->values);
                break;
            default:
                return SWSPARSE_INVALID_ARGS;
            }
        }
        if(ret == SWSPARSE_SUCCESS) {
            a->matrix.csrc->ordered = true;
        }
        return ret;
    default:
        return SWSPARSE_INVALID_ARGS;
    }
}
