#include "swSparse.h"
#include "internal/rename.h"
#include "internal/debug.h"
#include <math.h>

//结构化SpTRSV预处理，构造了数组，说明了运行时从核内的通信关系
//forward下三角预处理
static int swSparse_nonzero_analysis_f(int nnz, const int (*pos)[3], int *skew, int *halo, int (*p)[2], int *col_m, int *off_m)
{

    int i, j;

    *skew = -999999;
    *halo = 0;
    int cols = 0;
    for (i = 0; i < nnz; i++)
    {
        int x = pos[i][0],
        y = pos[i][1],
        z = pos[i][2];
        int tmp = x * 100 + y * 10 + z;
        if (tmp >= 0) return -1;
        if (abs(x) > 3 || abs(y) > 3 || abs(z) > 3) return -1;
        if (y > *skew) *skew = y;
        if (abs(z) > *halo) *halo = abs(z);
    }

	
    
    int flag[11][11];
    for (i = 0; i < 11; i++)
    for (j = 0; j < 11; j++)
        flag[i][j] = 0;

    for (i = 0; i < nnz; i++)
    {
        int x = pos[i][0],
        y = pos[i][1],
        z = pos[i][2];
        if (!flag[x+5][y+5])
        {
            flag[x+5][y+5] = 1;
        }
    }

    for (i = 0; i < 11; i++)
    for (j = 0; j < 11; j++)
    {
        if (flag[i][j])
        {
            if (i < 5 || i == 5 && j < 5)
            {
                p[cols][0] = i - 5;
                p[cols][1] = j - 5;
                cols++;
            }
        }
    }

    for (i = 0; i < nnz; i++)
    {
        if (pos[i][0] == 0 && pos[i][1] == 0)
        {
            col_m[i] = cols;
            off_m[i] = pos[i][2];
        }
        else
            for (j = 0; j < cols; j++)
            {
                if (pos[i][0] == p[j][0] && pos[i][1] == p[j][1])
                {
                    col_m[i] = j;
                    off_m[i] = pos[i][2];
                    break;
                }
            }
    }
    return cols;
}

//backward上三角预处理
static int swSparse_nonzero_analysis_fb(int nnz, const int (*pos)[3], int *skew, int *halo, int (*p)[2], int *col_m, int *off_m)
{

    int i, j;
    *skew = 0;
    *halo = 0;
    int cols = 0;
    for (i = 0; i < nnz; i++)
    {
        int x = pos[i][0],
        y = pos[i][1],
        z = pos[i][2];
        int tmp = x * 100 + y * 10 + z;
        if (tmp < 0) return -1;
        if (abs(x) > 3 || abs(y) > 3 || abs(z) > 3) return -1;
		if (y!=0&&y < *skew) {
			*skew = -y;
		}
        if (abs(z) > *halo) *halo = abs(z);
    }
    
    int flag[11][11];
    for (i = 0; i < 11; i++)
    for (j = 0; j < 11; j++)
        flag[i][j] = 0;

    for (i = 0; i < nnz; i++)
    {
        int x = -pos[i][0],
        y = -pos[i][1],
        z = pos[i][2];
        if (!flag[x+5][y+5])
        {
            flag[x+5][y+5] = 1;
        }
    }

    for (i = 0; i < 11; i++)
    for (j = 0; j < 11; j++)
    {
        if (flag[i][j])
        {
            if (i < 5 || i == 5 && j < 5)
            {
                p[cols][0] = i - 5;
                p[cols][1] = j - 5;
                cols++;
            }
        }
    }

    for (i = 0; i < nnz; i++)
    {
        if (pos[i][0] == 0 && pos[i][1] == 0)
        {
            col_m[i] = cols;
            off_m[i] = pos[i][2];
        }
        else
            for (j = 0; j < cols; j++)
            {
                if (-pos[i][0] == p[j][0] && -pos[i][1] == p[j][1])
                {
                    col_m[i] = j;
                    off_m[i] = pos[i][2];
                    break;
                }
            }
    }
    return cols;
}

#define DATA_TYPE_S
#include "c_struct_SpTRSV.inl"
#undef DATA_TYPE_S
#define DATA_TYPE_D
#include "c_struct_SpTRSV.inl"
#undef DATA_TYPE_D
