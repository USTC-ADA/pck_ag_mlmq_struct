#include"swSparse_matrix.h"
#include"internal/debug.h"
#include"internal/memory.h"
#include"internal/rename.h"
#include"internal/multicompile.h"

ErrorStatus FUNCNAME(create_csr)(Matrix *matrix, Int m, Int n, Int nnz, \
                                 Int *row_offsets, Int *column_indices, DATA_T *values) {
    if((m <= 0) || (n <= 0)) {
        return SWSPARSE_INVALID_ARGS;
    } else {
        ErrorStatus ret = create_csrc(matrix, m, n, m, nnz, row_offsets, column_indices, values, \
                        ELEMENT_TYPE, sizeof(DATA_T));
        if(ret == SWSPARSE_SUCCESS) {
            Matrix created = *matrix;
            created->format_type = CSR;
        }
        return ret;
    }
}

ErrorStatus FUNCNAME(create_csc)(Matrix *matrix, Int m, Int n, Int nnz, \
                                 Int *column_offsets, Int *row_indices, DATA_T *values) {
    if((m <= 0) || (n <= 0)) {
        return SWSPARSE_INVALID_ARGS;
    } else {
        ErrorStatus ret = create_csrc(matrix, m, n, n, nnz, column_offsets, row_indices, values, \
                        ELEMENT_TYPE, sizeof(DATA_T));
        if(ret == SWSPARSE_SUCCESS) {
            Matrix created = *matrix;
            created->format_type = CSC;
        }
        return ret;
    }
}

ErrorStatus FUNCNAME(create_coo)(Matrix *matrix, Int m, Int n, Int nnz, \
                                 Int *row_indices, Int *column_indices, DATA_T *values) {
    if((m <= 0) || (n <= 0)) {
        return SWSPARSE_INVALID_ARGS;
    } else {
        return create_coo(matrix, m, n, nnz, row_indices, column_indices, values, \
                        ELEMENT_TYPE, sizeof(DATA_T));
    }
}


ErrorStatus FUNCNAME(allocate_csr)(Matrix *matrix, Int m, Int n, Int nnz) {
    if((m <= 0) || (n <= 0)) {
        return SWSPARSE_INVALID_ARGS;
    } else {
        ErrorStatus ret = new_csrc(matrix, m, n, m, nnz, ELEMENT_TYPE, sizeof(DATA_T));
        if(ret == SWSPARSE_SUCCESS) {
            Matrix created = *matrix;
            created->format_type = CSR;
        }
        return ret;
    }
}

ErrorStatus FUNCNAME(allocate_csc)(Matrix *matrix, Int m, Int n, Int nnz) {  
    if((m <= 0) || (n <= 0)) {
        return SWSPARSE_INVALID_ARGS;
    } else {
        ErrorStatus ret = new_csrc(matrix, m, n, n, nnz, ELEMENT_TYPE, sizeof(DATA_T));
        if(ret == SWSPARSE_SUCCESS) {
            Matrix created = *matrix;
            created->format_type = CSC;
        }
        return ret;
    }
}

ErrorStatus FUNCNAME(allocate_coo)(Matrix *matrix, Int m, Int n, Int nnz) {
    if((m <= 0) || (n <= 0)) {
        return SWSPARSE_INVALID_ARGS;
    } else {
        return new_coo(matrix, m, n, nnz, ELEMENT_TYPE, sizeof(DATA_T));
    }
}


#if DEBUG_LEVEL == 0
#define PRINT_FORMAT_ERROR(mode, fs, fl)
#define PRINT_TYPE_ERROR(mode, fs)
#else
#ifndef ERROR_MESSAGE_DEFINED
#define ERROR_MESSAGE_DEFINED
static const char swSparse_err_msg_fmt[] = "Invalid matrix %s in swSparse_%c_r%c_export_%s: must be %s\n";
static const char str_type[] = "element type", str_format[] = "format";
static const char str_csr[] = "csr", str_csc[] = "csc", str_coo[] = "coo";
static const char str_CSR[] = "CSR (compressed sparse rows)";
static const char str_CSC[] = "CSC (compressed sparse columns)";
static const char str_COO[] = "COO (coordinates)";
#else
#undef PRINT_FORMAT_ERROR
#undef PRINT_TYPE_ERROR
#endif
#define PRINT_FORMAT_ERROR(mode, fs, fl) DEBUG_PRINTF(swSparse_err_msg_fmt, str_format, TYPENAME_CHAR, mode, fs, fl)
#define PRINT_TYPE_ERROR(mode, fs)       DEBUG_PRINTF(swSparse_err_msg_fmt, str_type, TYPENAME_CHAR, mode, fs, TYPENAME_STR)
#endif


ErrorStatus FUNCNAME(ro_export_csr)(Matrix matrix, Int *m, Int *n, Int *nnz, \
                                 const Int **row_offsets, const Int **column_indices, const DATA_T **values) {
    if(matrix->format_type != CSR) {
        PRINT_FORMAT_ERROR('o', str_csr, str_CSR);
        return SWSPARSE_INVALID_ARGS;
    } 
    if(matrix->element_type != ELEMENT_TYPE) {
        PRINT_TYPE_ERROR('o', str_csr);
        return SWSPARSE_INVALID_ARGS;
    } 
    *m = matrix->m;
    *n = matrix->n;
    *nnz = matrix->nnz;
    *row_offsets = matrix->matrix.csrc->offsets;
    *column_indices = matrix->matrix.csrc->indices;
    *values = matrix->matrix.csrc->values;
    return SWSPARSE_SUCCESS;
}

ErrorStatus FUNCNAME(ro_export_csc)(Matrix matrix, Int *m, Int *n, Int *nnz, \
                                 const Int **column_offsets, const Int **row_indices, const DATA_T **values) {
    if(matrix->format_type != CSC) {
        PRINT_FORMAT_ERROR('o', str_csc, str_CSC);
        return SWSPARSE_INVALID_ARGS;
    } 
    if(matrix->element_type != ELEMENT_TYPE) {
        PRINT_TYPE_ERROR('o', str_csc);
        return SWSPARSE_INVALID_ARGS;
    } 
    *m = matrix->m;
    *n = matrix->n;
    *nnz = matrix->nnz;
    *column_offsets = matrix->matrix.csrc->offsets;
    *row_indices = matrix->matrix.csrc->indices;
    *values = matrix->matrix.csrc->values;
    return SWSPARSE_SUCCESS;
}

ErrorStatus FUNCNAME(ro_export_coo)(Matrix matrix, Int *m, Int *n, Int *nnz, \
                                 const Int **row_indices, const Int **column_indices, const DATA_T **values) {
    if(matrix->format_type != COO) {
        PRINT_FORMAT_ERROR('o', str_coo, str_COO);
        return SWSPARSE_INVALID_ARGS;
    } 
    if(matrix->element_type != ELEMENT_TYPE) {
        PRINT_TYPE_ERROR('o', str_coo);
        return SWSPARSE_INVALID_ARGS;
    } 
    *m = matrix->m;
    *n = matrix->n;
    *nnz = matrix->nnz;
    *row_indices = matrix->matrix.coo->row_indices;
    *column_indices = matrix->matrix.coo->column_indices;
    *values = matrix->matrix.coo->values;
    return SWSPARSE_SUCCESS;
}


ErrorStatus FUNCNAME(rw_export_csr)(Matrix matrix, Int *m, Int *n, Int *nnz, \
                                 Int **row_offsets, Int **column_indices, DATA_T **values) {
    if(matrix->format_type != CSR) {
        PRINT_FORMAT_ERROR('w', str_csr, str_CSR);
        return SWSPARSE_INVALID_ARGS;
    } 
    if(matrix->element_type != ELEMENT_TYPE) {
        PRINT_TYPE_ERROR('w', str_csr);
        return SWSPARSE_INVALID_ARGS;
    } 
    swSparse_ensure_ownership_csrc(matrix);
    *m = matrix->m;
    *n = matrix->n;
    *nnz = matrix->nnz;
    *row_offsets = matrix->matrix.csrc->offsets;
    *column_indices = matrix->matrix.csrc->indices;
    *values = matrix->matrix.csrc->values;
    return SWSPARSE_SUCCESS;
}

ErrorStatus FUNCNAME(rw_export_csc)(Matrix matrix, Int *m, Int *n, Int *nnz, \
                                 Int **column_offsets, Int **row_indices, DATA_T **values) {
    if(matrix->format_type != CSC) {
        PRINT_FORMAT_ERROR('w', str_csc, str_CSC);
        return SWSPARSE_INVALID_ARGS;
    } 
    if(matrix->element_type != ELEMENT_TYPE) {
        PRINT_TYPE_ERROR('w', str_csc);
        return SWSPARSE_INVALID_ARGS;
    } 
    swSparse_ensure_ownership_csrc(matrix);
    *m = matrix->m;
    *n = matrix->n;
    *nnz = matrix->nnz;
    *column_offsets = matrix->matrix.csrc->offsets;
    *row_indices = matrix->matrix.csrc->indices;
    *values = matrix->matrix.csrc->values;
    return SWSPARSE_SUCCESS;
}

ErrorStatus FUNCNAME(rw_export_coo)(Matrix matrix, Int *m, Int *n, Int *nnz, \
                                 Int **row_indices, Int **column_indices, DATA_T **values) {
    if(matrix->format_type != COO) {
        PRINT_FORMAT_ERROR('w', str_coo, str_COO);
        return SWSPARSE_INVALID_ARGS;
    } 
    if(matrix->element_type != ELEMENT_TYPE) {
        PRINT_TYPE_ERROR('w', str_coo);
        return SWSPARSE_INVALID_ARGS;
    } 
    swSparse_ensure_ownership_coo(matrix);
    *m = matrix->m;
    *n = matrix->n;
    *nnz = matrix->nnz;
    *row_indices = matrix->matrix.coo->row_indices;
    *column_indices = matrix->matrix.coo->column_indices;
    *values = matrix->matrix.coo->values;
    return SWSPARSE_SUCCESS;
}

ErrorStatus FUNCNAME(modify_element)(Matrix mat, int row_idx, int col_idx, DATA_T delta_){
    
    ErrorStatus ret = SWSPARSE_SUCCESS;
    Int m = mat->m;
    Int n = mat->n;
    Int nnz = mat->nnz;
    
    switch(mat->format_type) {
        case COO:
            break;
        
        case CSR:
            break;
        
        case CSC:
            break;

        case SWCOO:{
            CDATA_T *value = mat->matrix.swcoo->value;
            int i;
            int mask = (row_idx << 16) + col_idx;
            for (i = 0 ; i < nnz ; i++){
              //printf("%d %d %d\n",i,mat->matrix.swcoo.row_idx[i],mask);
              if (mat->matrix.swcoo->row_idx[i] == mask){
                CONVERT_VALUE(delta, delta_)
                value[i] = delta;
                break;
              }
            }
        }
        default:
            return SWSPARSE_INVALID_ARGS;
    }

    return ret;
}


