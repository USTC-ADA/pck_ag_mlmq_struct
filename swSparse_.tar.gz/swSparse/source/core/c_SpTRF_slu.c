#include "swSparse.h"
#include "internal/rename.h"
#include "internal/memory.h"
#include "internal/debug.h"
#include "internal/utils.h"
#include "internal/sptrf_common.h"
#include "internal/third_party.h"

/* subroutines from SuperLU and SuperLU_MT */

/*
     5/20/95  X.S. Li:
         Translated from fcnthn.f using f2c
         Modified to use 0-based indexing in C
         Initialize xsup = 0 as suggested by B. Peyton

     10/17/07 X.S. Li:
	 Modified to record supernode partition of L in part_super_L[*]:
	     part_super_L[k] = size of the supernode beginning at column k;
 	                     = 0, elsewhere.
         
   
   ***********************************************************************   
   ***********************************************************************   

     Version:        0.3   
     Last modified:  January 12, 1995   
     Authors:        Esmond G. Ng and Barry W. Peyton   

     Mathematical Sciences Section, Oak Ridge National Laboratoy   

   ***********************************************************************   
   ***********************************************************************   
   **************     FCNTHN  ..... FIND NONZERO COUNTS    ***************   
   ***********************************************************************   
   ***********************************************************************   

     PURPOSE:   
         THIS SUBROUTINE DETERMINES THE ROW COUNTS AND COLUMN COUNTS IN   
         THE CHOLESKY FACTOR.  IT USES A DISJOINT SET UNION ALGORITHM.   

         TECHNIQUES:   
         1) SUPERNODE DETECTION.   
         2) PATH HALVING.   
         3) NO UNION BY RANK.   

     NOTES:   
         1) ASSUMES A POSTORDERING OF THE ELIMINATION TREE.   

     INPUT PARAMETERS:   
         (I) NEQNS       -   NUMBER OF EQUATIONS.   
         (I) XADJ(*)     -   ARRAY OF LENGTH NEQNS+1, CONTAINING POINTERS   
                             TO THE ADJACENCY STRUCTURE.   
         (I) ADJNCY(*)   -   ARRAY OF LENGTH XADJ(NEQNS+1)-1, CONTAINING   
                             THE ADJACENCY STRUCTURE.   
         (I) PERM(*)     -   ARRAY OF LENGTH NEQNS, CONTAINING THE   
                             POSTORDERING.   
         (I) INVP(*)     -   ARRAY OF LENGTH NEQNS, CONTAINING THE   
                             INVERSE OF THE POSTORDERING.   
         (I) ETPAR(*)    -   ARRAY OF LENGTH NEQNS, CONTAINING THE   
                             ELIMINATION TREE OF THE POSTORDERED MATRIX.   

     OUTPUT PARAMETERS:   
         (I) ROWCNT(*)   -   ARRAY OF LENGTH NEQNS, CONTAINING THE NUMBER   
                             OF NONZEROS IN EACH ROW OF THE FACTOR,   
                             INCLUDING THE DIAGONAL ENTRY.   
         (I) COLCNT(*)   -   ARRAY OF LENGTH NEQNS, CONTAINING THE NUMBER   
                             OF NONZEROS IN EACH COLUMN OF THE FACTOR,   
                             INCLUDING THE DIAGONAL ENTRY.   
         (I) NLNZ        -   NUMBER OF NONZEROS IN THE FACTOR, INCLUDING   
                             THE DIAGONAL ENTRIES.
	 (I) PART_SUPER_L   SUPERNODE PARTITION IN THE FACTORED MATRIX L.

     WORK PARAMETERS:   
         (I) SET(*)      -   ARRAY OF LENGTH NEQNS USED TO MAINTAIN THE   
                             DISJOINT SETS (I.E., SUBTREES).   
         (I) PRVLF(*)    -   ARRAY OF LENGTH NEQNS USED TO RECORD THE   
                             PREVIOUS LEAF OF EACH ROW SUBTREE.   
         (I) LEVEL(*)    -   ARRAY OF LENGTH NEQNS+1 CONTAINING THE LEVEL   
                             (DISTANCE FROM THE ROOT).   
         (I) WEIGHT(*)   -   ARRAY OF LENGTH NEQNS+1 CONTAINING WEIGHTS   
                             USED TO COMPUTE COLUMN COUNTS.   
         (I) FDESC(*)    -   ARRAY OF LENGTH NEQNS+1 CONTAINING THE   
                             FIRST (I.E., LOWEST-NUMBERED) DESCENDANT.   
         (I) NCHILD(*)   -   ARRAY OF LENGTH NEQNS+1 CONTAINING THE   
                             NUMBER OF CHILDREN.   
         (I) PRVNBR(*)   -   ARRAY OF LENGTH NEQNS USED TO RECORD THE   
                             PREVIOUS ``LOWER NEIGHBOR'' OF EACH NODE.   

     FIRST CREATED ON    APRIL 12, 1990.   
     LAST UPDATED ON     JANUARY 12, 1995.   

   ***********************************************************************   
*/

#define ROOT (neqns)
#define EMPTY (-1)

/* LiuKan modifications:
 *    part_super is NOT determined here
 *    returns the etree height
 */
Int CHOLNZCNT(Int neqns, const Int *xadj, const Int *adjncy,
                const Int *perm, const Int *iperm, const Int *etpar,
                Int *colcnt, Int *rowcnt, Int *nchild /* length n+1 */, Int *iwork)
{
    /* Local variables */
    // Int nlnz;
    Int temp, xsup, last1, last2, j, k, pleaf, hinbr, jstop,
        jstrt, ifdesc, oldnbr, parent, lownbr, lca, etree_height;
    Bool lflag;

    /* Work arrays */
	Int *set    = iwork;
	Int *prvlf  = iwork + neqns;
	Int *level  = iwork + neqns * 2;      /* length n+1 */
	Int *weight = iwork + neqns * 3 + 1;  /* length n+1 */
	Int *fdesc  = iwork + neqns * 4 + 2;  /* length n+1 */
	Int *prvnbr  = iwork + neqns * 5 + 3;

    /*   --------------------------------------------------   
         COMPUTE LEVEL(*), FDESC(*), NCHILD(*).   
         INITIALIZE ROWCNT(*), COLCNT(*),   
                    SET(*), PRVLF(*), WEIGHT(*), PRVNBR(*).   
         --------------------------------------------------   */
    level[ROOT] = etree_height = 0;
    for (k = neqns - 1; k >= 0; --k)
    {
        rowcnt[k] = 1;
        colcnt[k] = 0;
        set[k] = k;
        prvlf[k] = EMPTY;
        level[k] = level[etpar[k]] + 1;
        weight[k] = 1;
        fdesc[k] = k;
        nchild[k] = 0;
        prvnbr[k] = EMPTY;
        //part_super_L[k] = 0;
        etree_height = (etree_height > level[k]) ? etree_height : level[k];
    }
    nchild[ROOT] = 0;
    fdesc[ROOT] = EMPTY;
    for (k = 0; k < neqns; ++k)
    {
        parent = etpar[k];
        weight[parent] = 0;
        ++nchild[parent];
        ifdesc = fdesc[k];
        if (ifdesc < fdesc[parent])
        {
            fdesc[parent] = ifdesc;
        }
    }

    xsup = 0; /* BUG FIX */

    /*   ------------------------------------   
         FOR EACH ``LOW NEIGHBOR'' LOWNBR ...   
         ------------------------------------ */
    for (lownbr = 0; lownbr < neqns; ++lownbr)
    {
        lflag = 0;
        ifdesc = fdesc[lownbr];
        oldnbr = perm[lownbr];
        jstrt = xadj[oldnbr];
        jstop = xadj[oldnbr + 1];
        /*   -----------------------------------------------   
             FOR EACH ``HIGH NEIGHBOR'', HINBR OF LOWNBR ...   
             ----------------------------------------------- */
        for (j = jstrt; j < jstop; ++j)
        {
            hinbr = iperm[adjncy[j]];
            if (hinbr > lownbr)
            {
                if (ifdesc > prvnbr[hinbr])  // LiuKan: always prvnbr[hinbr] < lownbr, therefore ifdesc > prvnbr[hinbr] means a new leaf
                {
                    /*  -------------------------   
			INCREMENT WEIGHT(LOWNBR).   
			------------------------- */
                    ++weight[lownbr];
                    pleaf = prvlf[hinbr];
                    /*  -----------------------------------------   
			IF HINBR HAS NO PREVIOUS ``LOW NEIGHBOR'' THEN ...   
			----------------------------------------- */
                    if (pleaf == EMPTY)
                    {
                        /* -----------------------------------------   
			   ... ACCUMULATE LOWNBR-->HINBR PATH LENGTH   
			       IN ROWCNT(HINBR).   
			   ----------------------------------------- */
                        rowcnt[hinbr] = rowcnt[hinbr] +
                                        level[lownbr] - level[hinbr];
                    }
                    else
                    {
                        /* -----------------------------------------   
			   ... OTHERWISE, LCA <-- FIND(PLEAF), WHICH   
                               IS THE LEAST COMMON ANCESTOR OF PLEAF   
                               AND LOWNBR. (PATH HALVING.)   
			   ----------------------------------------- */
                        last1 = pleaf;
                        last2 = set[last1];
                        lca = set[last2];
                        while (lca != last2)
                        {
                            set[last1] = lca;
                            last1 = lca;
                            last2 = set[last1];
                            lca = set[last2];
                        }
                        /* -------------------------------------   
			   ACCUMULATE PLEAF-->LCA PATH LENGTH IN   
			   ROWCNT(HINBR). DECREMENT WEIGHT(LCA).   
			   ------------------------------------- */
                        rowcnt[hinbr] = rowcnt[hinbr] +
                                        level[lownbr] - level[lca];
                        --weight[lca];
                    }
                    /* ----------------------------------------------   
		       LOWNBR NOW BECOMES ``PREVIOUS LEAF'' OF HINBR.   
		       ---------------------------------------------- */
                    prvlf[hinbr] = lownbr;
                    lflag = 1;
                }
                /* --------------------------------------------------   
		   LOWNBR NOW BECOMES ``PREVIOUS NEIGHBOR'' OF HINBR.   
		   -------------------------------------------------- */
                prvnbr[hinbr] = lownbr;
            }
        }
        /* ----------------------------------------------------   
	   DECREMENT WEIGHT ( PARENT(LOWNBR) ).   
	   SET ( P(LOWNBR) ) <-- SET ( P(LOWNBR) ) + SET(XSUP).   
	   ---------------------------------------------------- */
        parent = etpar[lownbr];
        --weight[parent];
        if (lflag == 1 || nchild[lownbr] >= 2)
        {
            /* lownbr is the first vertex of a supernode */
            xsup = lownbr;
        }
        set[xsup] = parent;
    }

    /* ---------------------------------------------------------   
       USE WEIGHTS TO COMPUTE COLUMN (AND TOTAL) NONZERO COUNTS.   
       --------------------------------------------------------- */
    for (k = 0; k < neqns; ++k)
    {
        temp = colcnt[k] + weight[k];
        colcnt[k] = temp;
        parent = etpar[k];
        if (parent != neqns /* 0, LiuKan: cholnzcnt is not used in SuperLU_MT, but here is a bug */)
        {
            colcnt[parent] += temp;
        }
    }
    return etree_height;
} /* cholnzcnt */

#define TREE_EMPTY (-1)
#define END_DFS    (-7)

/*
 * Depth-first search from vertex n.
 * iperm[n + 1]
 * iwork[2 * n + 2]
 * NOTE: `perm` in SuperLU is `iperm` in swSparse
 */
void ETREE_POST(Int n, const Int *RSTR parent, Int *RSTR iperm, Int *RSTR iwork) {
	/* For linked list of children.	*/
	Int *first_child = iwork;
	Int *next_sibling = iwork + n + 1;

	/* Set up structure describing children */
	for (Int v = 0; v <= n; first_child[v++] = TREE_EMPTY);
	next_sibling[n] = END_DFS;
	for (Int v = n-1; v >= 0; v--) {
		Int p = parent[v];
		next_sibling[v] = first_child[p];
		first_child[p] = v;
	}

    for (Int post_index = 0, current = n; post_index < n; ){
        Int next;

		/* find the first leaf */
		for (Int first = first_child[current]; first != TREE_EMPTY; first = first_child[first]) {
            current = first;
		}

        /* number this leaf */
        iperm[current] = post_index++;

        /* look for the next */
		/* next_sibling[n] == END_DFS ends this loop */
        for (next = next_sibling[current]; next == TREE_EMPTY; next = next_sibling[current]) {

            /* no more kids : back to the parent node */
            current = parent[current];

            /* number the parent node */
			iperm[current] = post_index++;
		}

        /* go to the next */
        current = next;
    }
}
