#include "internal/multicompile.h"

ErrorStatus FUNCNAME(elementwise_multiply)(swSparseInt n, const DATA_T* src, DATA_T* dst, const REAL_T* scale) {
	swSparse::ewise_mul(n, src, dst, scale);
	return SWSPARSE_SUCCESS;
}


ErrorStatus FUNCNAME(trf)(Matrix a, Matrix *lu, Int *riperm, Int *ciperm, \
		REAL_T* rscale, REAL_T* cscale, const swSparseTRFOptions* options) {
	/* TODO: input check, options, transpose, CSR */
	return swSparse::trf_csc<DATA_T>(a, lu, riperm, ciperm, rscale, cscale, options);
}
