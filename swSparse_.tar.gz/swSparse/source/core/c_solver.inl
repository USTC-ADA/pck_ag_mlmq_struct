#include "swSparse_reorder.h"
#include "internal/multicompile.h"

ErrorStatus
FUNCNAME(solve_v)(DATA_T alpha, swSparseSolver solver, const DATA_T *b, DATA_T *x) {
    /* apply permutations */
    swSparseTRSVOptions trsv_options;
    trsv_options.expected_ncall = solver->solve_options.expected_ncall; 
    trsv_options.transpose      = solver->solve_options.transpose; 
    trsv_options.uplo           = solver->solve_options.uplo; 
    trsv_options.diagnal        = solver->solve_options.diagnal; 

    if(solver->lu->format_type == SWSPARSE_SLTCOO) {
        Int n = solver->lu->n;
        DATA_T *b_tmp = (DATA_T *) swSparse_malloc(2 * n * sizeof(DATA_T));
        DATA_T *x_tmp = b_tmp + n;
        IF_ERR(b_tmp == NULL) {
            return MALLOC_ERROR;
        }

        FUNCNAME(iperm_apply)(n, b, b_tmp, solver->biperm);
        FUNCNAME(trsv_execute)(alpha, solver->lu, b_tmp, x_tmp, &trsv_options);
        FUNCNAME(iperm_apply)(n, x_tmp, x, solver->xiperm);    
        swSparse_free(b_tmp);
    }else {
		FUNCNAME(trsv_execute)(alpha, solver->lu, b, x, &trsv_options);
    }

    return SWSPARSE_SUCCESS;
}

ErrorStatus
FUNCNAME(solve_m)(DATA_T alpha, swSparseSolver solver, Int nvec, \
                    const DATA_T *b, Int ldb, DATA_T *x, Int ldx) {
    /* apply permutations */
    Int n = solver->lu->n;
    Int i;

    DATA_T *b_tmp = (DATA_T *) swSparse_malloc(2 * n * sizeof(DATA_T));
    DATA_T *x_tmp = b_tmp + n;
    IF_ERR(b_tmp == NULL) {
        return MALLOC_ERROR;
    }

    for(i = 0; i < nvec; i++) {
        FUNCNAME(iperm_apply)(n, b+i*ldb, b_tmp, solver->biperm);
        FUNCNAME(trsm_execute)(alpha, solver->lu, 1, b_tmp, n, x_tmp, n, &solver->solve_options);
        //put x
        FUNCNAME(iperm_apply)(n, x_tmp, x+i*ldx, solver->xiperm); 
    }
    swSparse_free(b_tmp);

    return SWSPARSE_SUCCESS;
}

