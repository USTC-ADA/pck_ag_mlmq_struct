#include "internal/rename.h"
#include "internal/multicompile.h"
#include "internal/templates.h"
#include "internal/stsSpTRSV.h"

//下三角计算
ErrorStatus FUNCNAME(struct_sptrsv_forward)(const DATA_T* a, DATA_T *x, const DATA_T* b, const int dim[3], int nnz, const int (*pos)[3]){
    int i;

    if (nnz <= 0) {
        printf("Forward nnz error!\n");
        return SWSPARSE_INVALID_ARGS;
    }
    //C99标准中，变长数组的大小是在运行时确定的
    int col_id[nnz], z_off[nnz];
    int p[nnz][2];
    int skew, halo;
    int cols;
    //将函数结果赋值给变量cols。然后将赋值表达式的结果与0进行比较
    if ((cols = swSparse_nonzero_analysis_f(nnz, pos, &skew, &halo, p, col_id, z_off)) < 0)
    {
        return SWSPARSE_INVALID_ARGS;
    }

    ststrsv_forward_execute<DATA_T>(a, x, b, dim, nnz, p, col_id, z_off, halo, cols, skew);

    return SWSPARSE_SUCCESS;
}

//上三角计算
ErrorStatus FUNCNAME(struct_sptrsv_backward)(const DATA_T* a, DATA_T *x, const DATA_T* b, const int dim[3], int nnz, const int (*pos)[3])
{
    int i;

    if (nnz <= 0) {
        printf("Backward nnz error!\n");
        return SWSPARSE_INVALID_ARGS;
    }
    //C99标准中，变长数组的大小是在运行时确定的
    int col_id[nnz], z_off[nnz];
    int p[nnz][2];
    int skew, halo;
    int cols;
    //将函数结果赋值给变量cols。然后将赋值表达式的结果与0进行比较
    if ((cols = swSparse_nonzero_analysis_fb(nnz, pos, &skew, &halo, p, col_id, z_off)) < 0)
    {
        printf("Backward data args error!\n");
        return SWSPARSE_INVALID_ARGS;
    }

    ststrsv_backward_execute<DATA_T>(a, x, b, dim, nnz, p, col_id, z_off, halo, cols, skew);

    return SWSPARSE_SUCCESS;
}
