#include <stdio.h>
#include <limits>
#include "swSparse.h"
#include "internal/rename.h"
#include "internal/reorder.h"
#include "internal/memory.h"
#include "internal/debug.h"
#include "internal/utils.h"
#include "internal/templates.h"
#include "internal/spblas_common.h"
#include "internal/third_party.h"
#include "internal/sptrf_common.h"

#ifdef LU_PRINT_STATS
#define DECL_TIMER struct timeval begin, end
#define TIMER_BEGIN gettimeofday(&begin, nullptr)
#define TIMER_END   gettimeofday(&end, nullptr)
#define PRINT_PREPROCESS_TIME             swSparse_set_lu_timing(&begin, &end, LU_TIMING_PRE)
#define PRINT_PREPROCESS_PATTERN_TIME     swSparse_set_lu_timing(&begin, &end, LU_TIMING_REPRE)
#define PRINT_SYMBOLIC_TIME               swSparse_set_lu_timing(&begin, &end, LU_TIMING_SYMBOL)
#define PRINT_NUMERIC_TIME                swSparse_set_lu_timing(&begin, &end, LU_TIMING_NUM_ALL); \
	swSparse_trf_stat.set_numeric_stats(nr.interchange_count, nr.perturbation_count, pr.perterb_threshold)

#define MAX_RECORD 10
static const char * const swSparse_trf_timing_names[LU_TIMING_SIZE] = {"MC64", "Fill-in", "Preprocess", "Preprocess refact", \
	"Symbolic", "Numeric"};
static const char * const swSparse_trf_counter_names[2] = {"Interchange", "Perturbation"};

struct LU_STATISTICS {
	double time[LU_TIMING_SIZE][MAX_RECORD];
	bool valid[LU_TIMING_SIZE][MAX_RECORD];
	int numeric_stats[MAX_RECORD][2];
	int ntree, nsuptree, nsupqueue, nlvltree, iter;
	float wtree, wqueue;
	LU_STATISTICS() : iter(0), nsupqueue(0), nsuptree(0) {
		memset(this->time, 0, sizeof(this->time));
		memset(this->valid, 0, sizeof(this->valid));
	}
	void set_numeric_stats(int interchange_count, int perturb_count, double threshold) {
		numeric_stats[iter][0] = interchange_count;
		numeric_stats[iter][1] = perturb_count;
		iter ++;
	}
	void set_timing(const struct timeval* begin, const struct timeval* end, int index) {
		time[index][iter] = 1e3 * (end->tv_sec - begin->tv_sec) + 1e-3 * (end->tv_usec - begin->tv_usec);
		valid[index][iter] = true;
	}
	void print() const {
		if(nsuptree > 0) {
			printf("Subtrees: %d trees, %d supernodes, %e weight\n", ntree, nsuptree, wtree);
		}
		if(nsupqueue > 0) {
			printf("Queue: %d levels, %d supernodes, %e weight\n", nlvltree, nsupqueue, wqueue);
		}
		for(int i = 0; i < LU_TIMING_SIZE; ++ i) {
			const char* name = swSparse_trf_timing_names[i];
			double first = time[i][0], total = 0;
			int c = 0;
			for(int j = 0; j < iter; ++j) {
				if(valid[i][j]) {
					total += time[i][j];
					++c;
				}
			}
			if(c == 1) {
				printf("%18s time: %.3lf ms\n", name, total);
			} else if(c > 1) {
				printf("%18s time: %.3lf ms, %.6lf ms\n", name, first, total / c);
			}
		}
		for(int i = 0; i < iter; ++i) {
			for(int j = 0; j < 2; ++j) {
				printf("%17s count: %d\n", swSparse_trf_counter_names[j], numeric_stats[i][j]);
			}
		}
	}
};

static LU_STATISTICS swSparse_trf_stat;

void swSparse_set_lu_timing(const struct timeval* begin, const struct timeval* end, int index) {
	swSparse_trf_stat.set_timing(begin, end, index);
}

void swSparse_set_lu_stats(int ntree, int nsuptree, float wtree, int nsupqueue, int nlvltree, float wqueue) {
	swSparse_trf_stat.ntree = ntree;
	swSparse_trf_stat.nsuptree = nsuptree;
	swSparse_trf_stat.wtree = wtree;
	swSparse_trf_stat.nsupqueue = nsupqueue;
	swSparse_trf_stat.nlvltree = nlvltree;
	swSparse_trf_stat.wqueue = wqueue;
}

void swSparse_fact_time(double* t) {
	t[0] = swSparse_trf_stat.time[LU_TIMING_NUM_ALL][0];
	t[1] = swSparse_trf_stat.time[LU_TIMING_NUM_ALL][swSparse_trf_stat.iter - 1];
}

void swSparse_print_trf_info() { swSparse_trf_stat.print(); }

#else
#define DECL_TIMER
#define TIMER_BEGIN
#define TIMER_END
#define PRINT_PREPROCESS_TIME
#define PRINT_SYMBOLIC_TIME
#define PRINT_NUMERIC_TIME
#endif

namespace swSparse {

inline ErrorStatus check_order(LUSup* lu) {
    if ( ! lu->l_ordered) {
        lu->l_ordered = true;
		return sort_elements_in_pattern(lu->nsuper, lu->l_i_offsets, lu->l_indices);
    }
	return SWSPARSE_SUCCESS;
}

inline ErrorStatus allocate_lu_values(LUSup* lu, size_t lsize, size_t usize) {
	lu->l_values = swSparse_malloc(lsize);
	IF_ERR(lu->l_values == nullptr) {
		lu->u_values = nullptr;
		return MALLOC_ERROR;
	}
	lu->u_values = swSparse_malloc(usize);
	return (lu->u_values != nullptr) ? SWSPARSE_SUCCESS : MALLOC_ERROR;
}

template<typename TEMPLATE_T>
ErrorStatus trf_csc(Matrix a, Matrix *lu, Int *riperm, Int *ciperm, \
		real_t<TEMPLATE_T>* rscale, real_t<TEMPLATE_T>* cscale, const swSparseTRFOptions* options) {
	DECL_TIMER;
	ErrorStatus ret;
	MatrixData pa;
	preprocess_result_t<real_t<TEMPLATE_T>> pr;
	numeric_result_t nr;
	Int n = a->n, m = a->m, nnz = a->nnz;

	if (options->pattern == SWSPARSE_SAME_PATTERN) {
		Int *riperm_1, *riperm_2;
		pr.ciperm = ciperm;
		pr.riperm = riperm;

		ret = check_order((*lu)->matrix.lusuper);
		IF_ERR(ret != SWSPARSE_SUCCESS) {
			return ret;
		}

		TIMER_BEGIN;
		ret = swSparse::sptrf_preprocess_same_pattern<TEMPLATE_T>(a, &pa, &pr, rscale, cscale, options);
		TIMER_END;
		PRINT_PREPROCESS_PATTERN_TIME;
		IF_ERR(ret != SWSPARSE_SUCCESS) {
			return ret;
		}

		riperm_1 = (Int*) swSparse_malloc(sizeof(Int) * n * 2);
		IF_ERR(riperm_1 == NULL) {
			return MALLOC_ERROR;
		}
		riperm_2 = riperm_1 + n;

		TIMER_BEGIN;
		ret = swSparse::sptrf_numeric<TEMPLATE_T>(&pa, (*lu)->matrix.lusuper, \
				pr.perterb_threshold, riperm_2, &nr, options);
		TIMER_END;
		PRINT_NUMERIC_TIME;
		swSparse_destruct(&pa);
		if (LIKELY(ret == SWSPARSE_SUCCESS)) {
			swSparse_memcpy(riperm_1, riperm, sizeof(Int) * n);
			ASSERT(swSparse_valid_permutation(n, riperm_2, riperm));
			ret = iperm_compose(n, riperm_1, riperm_2, riperm);
			ASSERT(swSparse_valid_permutation(n, riperm, riperm_2));
		}

		return clean_return(ret, riperm_1);
	} else {
		Matrix temp_lu;
		Int *riperm_1, *riperm_2, *etree, *part_super, *rowcnt, *colcnt;
		Int lnnz, unnz;
		col_status_t* status;
		LUSup* lu_data;

		pr.ciperm = ciperm;

		TIMER_BEGIN;
		ret = swSparse::sptrf_preprocess<TEMPLATE_T>(a, &pa, &pr, rscale, cscale, options);
		TIMER_END;
		PRINT_PREPROCESS_TIME;
		
		IF_ERR(ret != SWSPARSE_SUCCESS) {
			return ret;
		}
		status = pr.status;
		riperm_1 = pr.riperm;
		etree  = pr.etree;
		part_super = pr.part_super;
		rowcnt = pr.rowcnt;
		colcnt = pr.colcnt;

		temp_lu = (Matrix)swSparse_malloc(sizeof(MatrixData));
		IF_ERR(temp_lu == nullptr) {
			swSparse_destruct(&pa);
			return clean_return(MALLOC_ERROR, etree, pr.to_clean);
		}

		lu_data = (LUSup*)swSparse_malloc(sizeof(LUSup));
		IF_ERR(lu_data == nullptr) {
			swSparse_destruct(&pa);
			return clean_return(MALLOC_ERROR, etree, temp_lu, pr.to_clean);
		}


		temp_lu->matrix.lusuper = lu_data;
		temp_lu->m = n;
		temp_lu->n = n;
		temp_lu->format_type = SWSPARSE_LU_SUPERNODES;
		temp_lu->element_type = type_traits<TEMPLATE_T>::element_type;
		temp_lu->status = 0;

		TIMER_BEGIN;
		ret = swSparse_sptrf_symbolic(&pa, lu_data, &pr, options);
		TIMER_END;
		PRINT_SYMBOLIC_TIME;
		swSparse_free(status);
		swSparse_free(etree);
		
		IF_ERR(ret != SWSPARSE_SUCCESS) {
			swSparse_destruct(&pa);
			return clean_return(ret, temp_lu, lu_data, pr.to_clean);
		}
		lu_data->snode_status = nullptr;
		lu_data->subtrees = nullptr;
		lu_data->task_queue = nullptr;
		ret = trf_static_schedule(lu_data);
		IF_ERR(ret != SWSPARSE_SUCCESS) {
			swSparse_destruct(&pa);
			swSparse_destroy(temp_lu);
			return clean_return(ret, pr.to_clean);
		}

		riperm_2 = (Int*)swSparse_malloc(sizeof(Int) * n);
		IF_ERR(riperm_2 == nullptr) {
			swSparse_destruct(&pa);
			swSparse_destroy(temp_lu);
			return clean_return(ret, pr.to_clean);
		}
		
		lnnz = lu_data->l_v_offsets[lu_data->nsuper];
		unnz = lu_data->u_seg_offsets[lu_data->u_col_offsets[n]];
		temp_lu->nnz = lnnz + unnz;
		ret = allocate_lu_values(lu_data, lnnz * sizeof(TEMPLATE_T), unnz * sizeof(TEMPLATE_T));
		IF_ERR(ret != SWSPARSE_SUCCESS) {
			swSparse_destroy(temp_lu);
			return clean_return(ret, riperm_2, pr.to_clean);
		}

		TIMER_BEGIN;
		ret = swSparse::sptrf_numeric<TEMPLATE_T>(&pa, lu_data, pr.perterb_threshold, riperm_2, &nr, options);
		TIMER_END;
		PRINT_NUMERIC_TIME;
		ASSERT(swSparse_valid_permutation(n, riperm_2, riperm));

		swSparse_destruct(&pa);
		IF_ERR(ret != SWSPARSE_SUCCESS) {
			swSparse_destroy(temp_lu);
			return clean_return(ret, riperm_2, pr.to_clean);
		}
		ret = iperm_compose(n, riperm_1, riperm_2, riperm);
		ASSERT(swSparse_valid_permutation(n, riperm, riperm_2));

		// currently only block-restricted column pivoting is implemented
		// swSparse_iperm_compose(n, ciperm_1, ciperm_2, ciperm);
		*lu = temp_lu;
		return clean_return(ret, riperm_2, pr.to_clean);
	}
}

} // namespace swSparse

#define DATA_TYPE_S
#include "c_SpTRF.inl"
#undef  DATA_TYPE_S
#define DATA_TYPE_D
#include "c_SpTRF.inl"
#undef  DATA_TYPE_D
#define DATA_TYPE_C
#include "c_SpTRF.inl"
#undef  DATA_TYPE_C
#define DATA_TYPE_Z
#include "c_SpTRF.inl"
#undef  DATA_TYPE_Z
