#include "swSparse_base.h"
#include "swSparse_matrix.h"
#include "internal/rename.h"
#include "internal/memory.h"
#include "internal/reorder.h"
#include "internal/templates.h"
#include "internal/transform.h"

extern "C" void SLAVE_FUN(swSparse_idx2off_kernel)(void*);
extern "C" void SLAVE_FUN(swSparse_off2idx_kernel)(void*);

namespace swSparse {
#define ATHREAD_SPAWN(fun, arg) __real_athread_spawn((void*)SLAVE_FUN(fun), arg, 1)

INLINE void index_to_offset(Int rows, Int nnz, const Int* row_idx, Int* output_offset) {
    idx2off_arg_t Info;
    Info.m = rows;
    Info.nnz = nnz;
    Info.idx = row_idx;
    Info.offset = output_offset;
    ATHREAD_SPAWN(swSparse_idx2off_kernel, &Info);
    athread_join();
}

INLINE void offset_to_index(Int m, const Int *offsets, Int *indices) {
    off2idx_arg_t Info;
    Info.m = m;
    Info.idx = indices;
    Info.offset = offsets;
    ATHREAD_SPAWN(swSparse_off2idx_kernel, &Info);
    athread_join();
}

/* TODO: parallel radix binning */
template<typename DATA_T>
ErrorStatus transpose_csr(Int m, Int n, Int nnz, \
               const Int* RSTR a_row_offsets, const Int* RSTR a_column_indices, const DATA_T* RSTR a_values, \
               Int* RSTR at_row_offsets, Int* RSTR at_column_indices, DATA_T* RSTR at_values) {
    Int* RSTR at_row_ends = at_row_offsets + 1;
    Int a_nonzero, a_row, at_row, prefix;

    swSparse_memset(at_row_offsets, 0, sizeof(Int) * (n + 1));
    for(a_nonzero = 0; a_nonzero < nnz; ++ a_nonzero) {
        ++ at_row_ends[a_column_indices[a_nonzero]];
    }

    prefix = 0;
    for(at_row = 0; at_row < n; ++at_row) {
        Int next = prefix + at_row_ends[at_row];
        at_row_ends[at_row] = prefix;
        prefix = next;
    }

    for(a_row = 0; a_row < m; ++a_row) {
        for(a_nonzero = a_row_offsets[a_row]; a_nonzero < a_row_offsets[a_row+1]; ++ a_nonzero) {
            Int at_nonzero = at_row_ends[a_column_indices[a_nonzero]] ++;
            at_column_indices[at_nonzero] = a_row;
            at_values[at_nonzero] = a_values[a_nonzero];
        }
    }
    return SWSPARSE_SUCCESS;
}

template<typename DATA_T>
ErrorStatus convert_coo2csr(Int m, Int n, Int nnz, \
               const Int* RSTR row_indices, const Int* RSTR coo_column_indices, const DATA_T* RSTR coo_values, \
               Int* RSTR row_offsets, Int* RSTR csr_column_indices, DATA_T* RSTR csr_values) {
    Int* RSTR row_ends = row_offsets + 1;
    Int coo_nonzero, row, prefix;

    swSparse_memset(row_offsets, 0, sizeof(Int) * (m + 1));
    for(coo_nonzero = 0; coo_nonzero < nnz; ++ coo_nonzero) {
        ++ row_ends[row_indices[coo_nonzero]];
    }

    prefix = 0;
    for(row = 0; row < m; ++row) {
        Int next = prefix + row_ends[row];
        row_ends[row] = prefix;
        prefix = next;
    }

    for(coo_nonzero = 0; coo_nonzero < nnz; ++ coo_nonzero) {
        Int csr_nonzero = row_ends[row_indices[coo_nonzero]] ++;
        csr_column_indices[csr_nonzero] = coo_column_indices[coo_nonzero];
        csr_values[csr_nonzero] = coo_values[coo_nonzero];
    }

    sort_elements(m, row_offsets, csr_column_indices, csr_values);
    return SWSPARSE_SUCCESS;
}

void convert_csr2coo(Int m, Int* RSTR row_offsets, Int* RSTR row_indices) {
    offset_to_index(m, row_offsets, row_indices);
}

#define EXPORT_TEMPLATES(type) \
template ErrorStatus transpose_csr<type>(Int m, Int n, Int nnz, \
               const Int* RSTR a_row_offsets, const Int* RSTR a_column_indices, const type* RSTR a_values, \
               Int* RSTR at_row_offsets, Int* RSTR at_column_indices, type* RSTR at_values); \
template ErrorStatus convert_coo2csr<type>(Int m, Int n, Int nnz, \
               const Int* RSTR row_indices, const Int* RSTR coo_column_indices, const type* RSTR coo_values, \
               Int* RSTR row_offsets, Int* RSTR csr_column_indices, type* RSTR csr_values);

EXPORT_TEMPLATES(float)
EXPORT_TEMPLATES(double)
EXPORT_TEMPLATES(SComplex)
EXPORT_TEMPLATES(DComplex)

}  // namespace swSparse
