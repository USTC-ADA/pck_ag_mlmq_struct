#include <crts.h>
#include "internal/kernel_args.h"
#include "internal/memory.h"
#include "internal/debug.h"

/* MPE cache size */
#define MPE_CACHE_SIZE 65536
#define MPE_CACHE_HALF_SIZE 32768

extern void SLAVE_FUN(swSparse_memcpy_kernel)(void*);
extern void SLAVE_FUN(swSparse_memset_kernel)(void*);

void swSparse_memset(void *dst, int value, size_t size) {
    if(size < MPE_CACHE_SIZE) {
        memset(dst, value, size);
    } else { 
        /* probably not in cache, use CPE to get higher bandwidth */
        size_t mis_align_1 = (4 - (size_t)dst & 3) & 3;
        size_t mis_align_2 = (size_t)(dst + size) & 3;
        memset_arg_t args;
        args.dst = dst + mis_align_1;
        args.size = size - mis_align_1 - mis_align_2;
        args.value = value;
        athread_spawn(swSparse_memset_kernel, &args);
        athread_join();
        memset(dst, value, mis_align_1);
        memset(dst + size - mis_align_2, value, mis_align_2);
    }
}

void swSparse_memcpy(void *dst, const void *src, size_t size) {
    if(size < MPE_CACHE_HALF_SIZE) {
        memcpy(dst, src, size);
    } else if((((size_t)dst ^ (size_t)src) & 3) != 0) {
        DEBUG_PRINTF("Performance warning: `src` and `dst` are not aligned in memcpy\n");
        memcpy(dst, src, size);
    } else {
        /* probably not in cache, use CPE to get higher bandwidth */
        size_t mis_align_1 = (4 - (size_t)dst & 3) & 3;
        size_t mis_align_2 = (size_t)(dst + size) & 3;
        memcpy_arg_t args;
        args.dst = dst + mis_align_1;
        args.src = src + mis_align_1;
        args.size = size - mis_align_1 - mis_align_2;
        athread_spawn(swSparse_memcpy_kernel, &args);
        athread_join();
        memcpy(dst, src, mis_align_1);
        memcpy(dst + size - mis_align_2, src + size - mis_align_2, mis_align_2);
    }
}

void swSparse_memmove(void *dst, const void *src, size_t size) {
    if(size < MPE_CACHE_HALF_SIZE) {
        memmove(dst, src, size);
    } else {
        /* TODO: parallel memmove */
        DEBUG_PRINTF("Performance warning: memmove is done by MPE with low bandwidth\n");
        memmove(dst, src, size);
    }
}
