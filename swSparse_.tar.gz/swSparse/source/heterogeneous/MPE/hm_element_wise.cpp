#include <limits>
#include <crts.h>
#include "internal/templates.h"
#include "internal/kernel_args.h"
#include "internal/memory.h"
#include "internal/debug.h"
#include "internal/sptrf_common.h" // equilibration routines

/* MPE cache size */
#define MPE_CACHE_SIZE 131072
#define MPE_CACHE_HALF_SIZE 65536

ATHREAD_SPAWN_CONCRETE_ARGTYPE(index_shift_kernel, index_shift_arg_t)
ATHREAD_SPAWN_TEMPLATE_ARGTYPE(scale_kernel,       scale_arg_t)
ATHREAD_SPAWN_TEMPLATE_ARGTYPE(dense_scale_kernel, dense_scale_arg_t)
ATHREAD_SPAWN_TEMPLATE_ARGTYPE(ewise_scale_kernel, ewise_scale_arg_t)
ATHREAD_SPAWN_TEMPLATE_ARGTYPE(mc64_preprocess_kernel, mc64_preprocess_arg_t)
ATHREAD_SPAWN_TEMPLATE_ARGTYPE(sparse_rescale_colmax_kernel, sparse_rescale_colmax_arg_t)
ATHREAD_SPAWN_TEMPLATE_ARGTYPE(sparse_scale_kernel, sparse_scale_arg_t)
ATHREAD_SPAWN_KERNEL(scale_conj_kernel, scale_arg_t<SComplex>, SLAVE_FUN(swSparse_c_scale_conj_kernel))
ATHREAD_SPAWN_KERNEL(scale_conj_kernel, scale_arg_t<DComplex>, SLAVE_FUN(swSparse_z_scale_conj_kernel))
ATHREAD_SPAWN_KERNEL(ewise_exp_kernel, ewise_exp_arg_t<float>, SLAVE_FUN(swSparse_s_ewise_exp_kernel))
ATHREAD_SPAWN_KERNEL(ewise_exp_kernel, ewise_exp_arg_t<double>, SLAVE_FUN(swSparse_d_ewise_exp_kernel))

namespace swSparse {

template<typename DATA_T>
void vector_scale(DATA_T alpha, Int n, const DATA_T* RSTR x, DATA_T* RSTR y) {
    if(n < MPE_CACHE_HALF_SIZE / sizeof(DATA_T)) {
        for(Int i = 0; i < n; ++i) {
            y[i] = alpha * x[i];
        }
    } else {
        scale_arg_t<DATA_T> args;
        args.alpha = alpha;
        args.src = x;
        args.dst = y;
        args.n   = n;
        athread_spawn_scale_kernel(&args);
        athread_join();
    }
}

template<typename REAL_T>
void ewise_exp(Int n, REAL_T* RSTR x, REAL_T* RSTR y) {  // always offload exp computations
    ewise_exp_arg_t<REAL_T> args;
    args.rscale = x;
    args.cscale = y;
    args.n   = n;
    athread_spawn_ewise_exp_kernel(&args);
    athread_join();
}

template<typename DATA_T>
real_t<DATA_T> mc64_preprocess(Int n, Int nnz, const Int* RSTR offsets, const DATA_T* x, real_t<DATA_T>* y, real_t<DATA_T>* col_max) {// always offload log computations
    mc64_preprocess_arg_t<DATA_T> args;
    args.offsets = offsets;
    args.src = x;
    args.dst = y;
    args.col_max = col_max;
    args.n   = n;
    args.nnz = nnz;
    athread_spawn_mc64_preprocess_kernel(&args);
    athread_join();    
    return args.norm_1;
}

template<typename DATA_T>
real_t<DATA_T> norm_1_sparse_scale(Int n, Int nnz, const Int* RSTR offsets, const Int* RSTR indices, \
    const DATA_T* RSTR src, DATA_T* RSTR dst, const real_t<DATA_T>* RSTR rscale, const real_t<DATA_T>* RSTR cscale) {
    sparse_scale_arg_t<DATA_T> args;
    args.offsets = offsets;
    args.indices = indices;
    args.src = src;
    args.dst = dst;
    args.rscale = rscale;
    args.cscale = cscale;
    args.n   = n;
    args.nnz = nnz;
    athread_spawn_sparse_scale_kernel(&args);
    athread_join();    
    return args.norm_1;
}

template<typename DATA_T>
real_t<DATA_T> norm_1_sparse_rescale_colmax(Int n, Int nnz, const Int* RSTR offsets, const Int* RSTR indices, \
    const DATA_T* RSTR src, DATA_T* RSTR dst, const real_t<DATA_T>* RSTR rscale, real_t<DATA_T>* RSTR cscale) {
    sparse_rescale_colmax_arg_t<DATA_T> args;
    args.offsets = offsets;
    args.indices = indices;
    args.src = src;
    args.dst = dst;
    args.rscale = rscale;
    args.cscale = cscale;
    args.n   = n;
    args.nnz = nnz;
    athread_spawn_sparse_rescale_colmax_kernel(&args);
    athread_join();
    return args.norm_1;
}

template<typename DATA_T>
void ewise_mul(Int n, const DATA_T* y, DATA_T* z, const real_t<DATA_T>* x) {
    if(n < MPE_CACHE_HALF_SIZE / sizeof(DATA_T)) {
        for(Int i = 0; i < n; ++i) {
            z[i] = y[i] * x[i];
        }
    } else {
        ewise_scale_arg_t<DATA_T> args;
        args.scale = x;
        args.src = y;
        args.dst = z;
        args.n   = n;
        athread_spawn_ewise_scale_kernel(&args);
        athread_join();
    }
}

template<typename DATA_T>
void vector_scale_conj(DATA_T alpha, Int n, const DATA_T* RSTR x, DATA_T* RSTR y) {
    if(n < MPE_CACHE_HALF_SIZE / sizeof(DATA_T)) {
        for(Int i = 0; i < n; ++i) {
            y[i] = alpha * conj(x[i]);
        }
    } else {
        scale_arg_t<DATA_T> args;
        args.alpha = alpha;
        args.src = x;
        args.dst = y;
        args.n   = n;
        athread_spawn_scale_conj_kernel(&args);
        athread_join();
    }
}


template<typename DATA_T>
void dense_scale(DATA_T alpha, Int n, Int nvec, const DATA_T* RSTR x, Int ldx, DATA_T* RSTR y, Int ldy) {
    if(nvec * n < MPE_CACHE_HALF_SIZE / sizeof(DATA_T)) {
        for(Int j = 0; j < nvec; ++j) {
            for(Int i = 0; i < n; ++i) {
                y[i + ldy * j] = alpha * x[i + ldx * j];
            }
        }
    } else {
        dense_scale_arg_t<DATA_T> args;
        args.alpha = alpha;
        args.src = x;
        args.dst = y;
        args.n   = n;
        args.ldx = ldx;
        args.ldy = ldy;
        args.n_vec = nvec;
        athread_spawn_dense_scale_kernel(&args);
        athread_join();
    }
}

void index_shift(Int n, const Int *in_index, Int* RSTR out_index, Int delta) {
    if(n < MPE_CACHE_SIZE / sizeof(Int)) {
        for(Int i = 0; i < n; ++i) {
            out_index[i] = in_index[i] + delta;
        }
    } else {
        index_shift_arg_t args;
        args.delta     = delta;
        args.n         = n;
        args.in_index  = in_index;
        args.out_index = out_index;
        athread_spawn_index_shift_kernel(&args);
        athread_join();
    }
}

#define EXPORT_TEMPLATES(type)  \
template void vector_scale<type>(type alpha, Int n, const type* RSTR x, type* RSTR y); \
template void dense_scale<type>(type alpha, Int n, Int nvec, const type* RSTR x, Int ldx, type* RSTR y, Int ldy); \
template void ewise_mul<type>(Int n, const type* RSTR y, type* RSTR z, const real_t<type>* RSTR x); \
template real_t<type> mc64_preprocess<type>(Int n, Int nnz, const Int* RSTR offsets, const type* x, real_t<type>* y, real_t<type>* z); \
template real_t<type> norm_1_sparse_rescale_colmax(Int n, Int nnz, const Int* RSTR offsets, const Int* RSTR indices, \
    const type* RSTR src, type* RSTR dst, const real_t<type>* RSTR rscale, real_t<type>* RSTR cscale); \
template real_t<type> norm_1_sparse_scale(Int n, Int nnz, const Int* RSTR offsets, const Int* RSTR indices, \
    const type* RSTR src, type* RSTR dst, const real_t<type>* RSTR rscale, const real_t<type>* RSTR cscale);

EXPORT_TEMPLATES(float)
EXPORT_TEMPLATES(double)
EXPORT_TEMPLATES(SComplex)
EXPORT_TEMPLATES(DComplex)

template void vector_scale_conj<SComplex>(SComplex alpha, Int n, const SComplex* RSTR x, SComplex* RSTR y);
template void vector_scale_conj<DComplex>(DComplex alpha, Int n, const DComplex* RSTR x, DComplex* RSTR y);

template void ewise_exp<float>(Int n, float* RSTR x, float* RSTR y);
template void ewise_exp<double>(Int n, double* RSTR x, double* RSTR y);

}
