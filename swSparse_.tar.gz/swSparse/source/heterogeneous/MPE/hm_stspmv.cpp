#include "swSparse.h"
#include "swSparse_blas.h"
#include "swSparse_matrix.h"
#include "swSparse_options.h"
#include "internal/rename.h"
#include "internal/memory.h"
#include "internal/debug.h"
#include "internal/reorder.h"
#include "internal/spblas_common.h"
#include "internal/spmv_common.h"
#include "internal/crts.hpp"
#include "internal/multicompile.h"
#include "internal/utils.h"
#include "internal/rename.h"
#include "internal/templates.h"
#include "internal/kernel_args.h"

ATHREAD_SPAWN_TEMPLATE_ARGTYPE(call_27_kernel, stspmv_kernel_arg_t)
ATHREAD_SPAWN_TEMPLATE_ARGTYPE(call_125_kernel, stspmv_kernel_arg_t)
ATHREAD_SPAWN_TEMPLATE_ARGTYPE(call_343_kernel, stspmv_kernel_arg_t)

namespace swSparse {

//结构化SpMV入口函数
template<typename DATA_T , typename Conj>
ErrorStatus struct_mv_execute(DATA_T alpha, const DATA_T *aa, const DATA_T *xx, DATA_T beta,  DATA_T *bb, const swSparseInt *dim ,  swSparseInt rnnz , const swSparseInt (*inpos)[3]){
    

    int i,j,k,p;
    int offset;
    int max_mn,max_l;
    int *pos = (int*)inpos;

    //统计在水平维和高度维上的最大偏移距离
    max_mn = 0;
    max_l  = 0;
    for (i=0;i<rnnz;i++){
        max_mn = max( max_mn , max( abs(pos[i*3]) , abs(pos[i*3+1]) ) );
        max_l  = max( max_l , abs(pos[i*3 + 2]) );
    }

    //将参数数据写入从核信息结构体参数    
    stspmv_kernel_arg_t<DATA_T> data;

    //矩阵向量信息
    data.b = bb;
    data.a = aa;
    data.x = xx;
    //三维大小
    data.lm = dim[0];
    data.ln = dim[1];
    data.ll = dim[2];
    //每行非零元数和偏移位置矩阵
    data.rnnz = rnnz;
    data.pos  = pos;
    //垂向halo宽度
    data.height = 4;//(max_l + 1) / 2;
    data.row = 2;
    data.col = 2;   
    
    //根据水平维度偏移距离,调用不同空间范围内的从核计算函数
    if (max_mn <=1){
        athread_spawn_call_27_kernel(&data);
        athread_join();
    }
    else if (max_mn <=2){
        athread_spawn_call_125_kernel(&data);
        athread_join();
    }
    else{
        athread_spawn_call_343_kernel(&data);
        athread_join();
    }

    swSparse_free(pos);

    return SWSPARSE_SUCCESS;
}

template ErrorStatus struct_mv_execute<float,ID>(float alpha, const float *aa, const float *xx, float beta,  float *bb, const swSparseInt *dim ,  swSparseInt rnnz , const swSparseInt (*inpos)[3]);
template ErrorStatus struct_mv_execute<double,ID>(double alpha, const double *aa, const double *xx, double beta,  double *bb, const swSparseInt *dim ,  swSparseInt rnnz , const swSparseInt (*inpos)[3]);
template ErrorStatus struct_mv_execute<SComplex,ID>(SComplex alpha, const SComplex *aa, const SComplex *xx, SComplex beta,  SComplex *bb, const swSparseInt *dim ,  swSparseInt rnnz , const swSparseInt (*inpos)[3]);
template ErrorStatus struct_mv_execute<DComplex,ID>(DComplex alpha, const DComplex *aa, const DComplex *xx, DComplex beta,  DComplex *bb, const swSparseInt *dim ,  swSparseInt rnnz , const swSparseInt (*inpos)[3]);
template ErrorStatus struct_mv_execute<SComplex,CJ>(SComplex alpha, const SComplex *aa, const SComplex *xx, SComplex beta,  SComplex *bb, const swSparseInt *dim ,  swSparseInt rnnz , const swSparseInt (*inpos)[3]);
template ErrorStatus struct_mv_execute<DComplex,CJ>(DComplex alpha, const DComplex *aa, const DComplex *xx, DComplex beta,  DComplex *bb, const swSparseInt *dim ,  swSparseInt rnnz , const swSparseInt (*inpos)[3]);

} //namespace 