#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <sys/time.h>
#include "internal/rename.h"
#include "internal/memory.h"
#include "internal/swSpMV.h"
#include "internal/utils.h"
#include "internal/reorder.h"
#include "internal/debug.h"
#include "internal/multicompile.h"
#include "internal/spmv_param.h"
#include "swSparse.h"


//#define Pa_Inspect

#define TIME(a,b) (1.0*((b).tv_sec-(a).tv_sec)+0.000001*((b).tv_usec-(a).tv_usec))

//生成矩阵结构基本信息,信息来源为宏定义或输入参数
inline void FUNCNAME(SWCOO_Format_Config)(SpMV_Format_Config *c , int para_tile_size, int para_element_size, int para_cache_element_size){


  c->nworkers = worker_number;
  c->nslavers = slaver_number;
  c->tile_size = para_tile_size;
  c->tolerate = ins_tolerate;
  c->avg_blocks = ins_avg_blocks;
  c->element_size = para_element_size;
  c->cache_element_size = para_cache_element_size;

}

//统计在SWCOO格式下的实际访存总量
long long FUNCNAME(Sum_Real_Mem)(SpMV_CSR_TASK_SIMPLE *tasks, int ntasks){
    printf("ntaskNum:%d\n",ntasks); 
    long long result = ntasks * sizeof(SpMV_Slave_TASK);
    for(int i = 0; i < ntasks; i ++){
      result += (sizeof(DATA_T)+sizeof(int)) * tasks[i].nnz;        //each nnz need (value + 2 index)
      result += sizeof(DATA_T) * tasks[i].col_length;               //the vector X each task need
      result += (tasks[i].put_id == -1 ? (sizeof(DATA_T) * tasks[i].row_length) : 0);  //whether this task need to write vector b to memory
    }
    return result;

}

inline void FUNCNAME(Init_Matrix)(MatrixSWCOO *newMatrix,swSparseMatrixData *Matrix_ , SpMV_Format_Config *cc){

  newMatrix->tile_num = (Matrix_->m + cc->tile_size - 1) / cc->tile_size;

}

//根据矩阵转换信息,将最优的划分格式转存成为SWCOO格式,并完成内存中的数据重排
long long FUNCNAME(Fillin_Info)(MatrixSWCOO *info, SpMV_CSR_TASK_SIMPLE *tasks, int ntasks, int *row_ptr, int *col_idx, DATA_T *value, int rows, int cols, int nnz, int nworkers, int nslavers, int tile_size){

  struct timeval t1, t2;
  //声明从核参数信息结构体,并赋值,如长,宽,非零元数,任务数(小矩阵块数量)
  DATA_T *info_value = (DATA_T*)swSparse_malloc(nnz * sizeof(DATA_T));
  info->rows    = rows;
  info->cols    = cols;
  info->ntasks  = ntasks;
  info->nnz     = nnz;
  info->row_idx = (int*)swSparse_malloc(nnz * sizeof(int));
  info->col_idx = NULL;//malloc(nnz * sizeof(int));
  info->value   = info_value;
  info->tasks   = (swSparse_SpMV_Slave_TASK*)swSparse_malloc(ntasks * sizeof(swSparse_SpMV_Slave_TASK));
  int snnt[8][8], snnz[8][8];
  int i, j, k, l;

  if (info_value == NULL || info->row_idx == NULL || info->tasks == NULL) return -1;

  for(i = 0; i < nworkers; i ++)
    for(j = 0; j < nslavers; j ++)
      snnz[i][j] = snnt[i][j] = 0;

  long long result = ntasks * sizeof(SpMV_Slave_TASK);

  for(i = 0; i < ntasks; i ++){
    snnz[tasks[i].worker_id][tasks[i].slaver_id] += tasks[i].nnz; //the nnzs of each slavers
    snnt[tasks[i].worker_id][tasks[i].slaver_id] ++;              //the tasks of each slavers
    result += (sizeof(DATA_T)+sizeof(int)) * tasks[i].nnz;        //each nnz need (value + 2 index)
    result += sizeof(DATA_T) * tasks[i].col_length;               //the vector X each task need
    result += (tasks[i].put_id == -1 ? (sizeof(DATA_T) * tasks[i].row_length) : 0);  //whether this task need to write vector b to memory
  }

  int snnt_offset = 0, snnz_offset = 0;
  for(i = 0; i < 8; i ++)
    for(j = 0; j < 8; j ++)
      info->infos[i][j].ntasks = 0;

  //转换为每个从核一个参数结构体,记录该从核的所有计算任务,信息同上,只是从任务数组转入从核数组
  for(i = 0; i < nworkers; i ++){
    for(j = 0; j < nslavers; j ++){
        info->infos[i][j].row_idx = info->row_idx;
        info->infos[i][j].col_idx = info->col_idx;
        info->infos[i][j].value   = info_value;
        info->infos[i][j].tasks   = info->tasks + snnt_offset; //put tasks together
        info->infos[i][j].rows    = rows;
        info->infos[i][j].cols    = cols;
        info->infos[i][j].ntasks  = snnt[i][j];
        info->infos[i][j].nnz_offset = snnz_offset;
        info->infos[i][j].nnz_length = snnz[i][j];
        info->infos[i][j].tile_size  = tile_size;
        snnt_offset += snnt[i][j];
        snnz_offset += snnz[i][j];
    }
  }
    
    for(i = 0; i < nworkers; i ++)
        for(j = 0; j < nslavers; j ++)
            snnz[i][j] = snnt[i][j] = 0;
    
    //遍历每一个小块计算任务,根据小块的分配方案,填入每个从核的信息结构体中,变量含义同上
    for(i = 0; i < ntasks; i ++){
        //int rrr = 1;;
        //info->infos[tasks[i].worker_id][tasks[i].slaver_id].tasks[snnt[tasks[i].worker_id][tasks[i].slaver_id]].row_offset = rrr;
        info->infos[tasks[i].worker_id][tasks[i].slaver_id].tasks[snnt[tasks[i].worker_id][tasks[i].slaver_id]].row_offset = tasks[i].row_offset;
        info->infos[tasks[i].worker_id][tasks[i].slaver_id].tasks[snnt[tasks[i].worker_id][tasks[i].slaver_id]].row_length = tasks[i].row_length;
        info->infos[tasks[i].worker_id][tasks[i].slaver_id].tasks[snnt[tasks[i].worker_id][tasks[i].slaver_id]].col_offset = tasks[i].col_offset;
        info->infos[tasks[i].worker_id][tasks[i].slaver_id].tasks[snnt[tasks[i].worker_id][tasks[i].slaver_id]].col_length = tasks[i].col_length;
        info->infos[tasks[i].worker_id][tasks[i].slaver_id].tasks[snnt[tasks[i].worker_id][tasks[i].slaver_id]].nnz_offset = info->infos[tasks[i].worker_id][tasks[i].slaver_id].nnz_offset + snnz[tasks[i].worker_id][tasks[i].slaver_id];
        info->infos[tasks[i].worker_id][tasks[i].slaver_id].tasks[snnt[tasks[i].worker_id][tasks[i].slaver_id]].nnz_length = tasks[i].nnz;
        //info->infos[tasks[i].worker_id][tasks[i].slaver_id].tasks[snnt[tasks[i].worker_id][tasks[i].slaver_id]].get_id = tasks[i].get_id;
        //info->infos[tasks[i].worker_id][tasks[i].slaver_id].tasks[snnt[tasks[i].worker_id][tasks[i].slaver_id]].put_id = tasks[i].put_id;
        info->infos[tasks[i].worker_id][tasks[i].slaver_id].tasks[snnt[tasks[i].worker_id][tasks[i].slaver_id]].reduce_root = tasks[i].reduce_root;
        info->infos[tasks[i].worker_id][tasks[i].slaver_id].tasks[snnt[tasks[i].worker_id][tasks[i].slaver_id]].reduce_ncpe = tasks[i].reduce_ncpe;
        info->infos[tasks[i].worker_id][tasks[i].slaver_id].tasks[snnt[tasks[i].worker_id][tasks[i].slaver_id]].reduce_flag = tasks[i].reduce_flag;
        info->infos[tasks[i].worker_id][tasks[i].slaver_id].tasks[snnt[tasks[i].worker_id][tasks[i].slaver_id]].store_flag = tasks[i].store_flag;
        info->infos[tasks[i].worker_id][tasks[i].slaver_id].tasks[snnt[tasks[i].worker_id][tasks[i].slaver_id]].job = tasks[i].job;
        snnz[tasks[i].worker_id][tasks[i].slaver_id] += tasks[i].nnz;
        snnt[tasks[i].worker_id][tasks[i].slaver_id] ++;
    }

  #ifdef DEBUGS
    int _sum1 = 0, _sum2 = 0;
    fprintf(stderr , "=================================\n");
    for(i = 0; i < nworkers; i ++)
    {
        for(j = 0; j < nslavers; j ++)
        {
            fprintf(stderr , "(%8d %6d) ", info->infos[i][j].nnz_offset, info->infos[i][j].nnz_length);
        }
        fprintf(stderr , "\n");
    }
    fprintf(stderr , "CHECK %d %d\n", info->infos[7][7].tasks[info->infos[7][7].ntasks - 1].nnz_offset, info->infos[7][7].tasks[info->infos[7][7].ntasks - 1].nnz_length);
    fprintf(stderr , "=================================\n");
  #endif

   
    //进行内存中数据重排,因原矩阵是CSR格式的,将其先转换成CSC矩阵,再通过两种格式的行列偏移索引,夹出某一宽度下的矩阵块内的非零元信息
    int *csc_col_ptr = (int*)swSparse_malloc((cols+1)*sizeof(int));
    int *csc_row_idx = (int*)swSparse_malloc(nnz*sizeof(int));
    DATA_T *csc_value = (DATA_T*)swSparse_malloc(nnz*sizeof(DATA_T));


    if (csc_col_ptr == NULL || csc_row_idx == NULL || csc_value == NULL) return -1;

    for(i = 0; i <= cols; i ++) csc_col_ptr[i] = 0;
    for(i = 0; i < rows; i ++)
        for(j = row_ptr[i]; j < row_ptr[i+1]; j ++)
            csc_col_ptr[col_idx[j]+1] ++;
    for(i = 0; i < cols; i ++) csc_col_ptr[i+1] += csc_col_ptr[i];

    int  **csc_row_idx_ptr0 = swSparse_malloc(cols*sizeof(int*));
    DATA_T **csc_value_ptr0 = swSparse_malloc(cols*sizeof(DATA_T*));
    int  **csc_row_idx_ptr1 = swSparse_malloc(cols*sizeof(int*));
    DATA_T **csc_value_ptr1 = swSparse_malloc(cols*sizeof(DATA_T*));

    //if (csc_row_idx_ptr0 == NULL || csc_value_ptr0 == NULL || csc_row_idx_ptr1 == NULL || csc_value_ptr1 == NULL) return -1;
    
    #ifdef Pa_Inspect
      gettimeofday(&t1, NULL);
    #endif

    for(i = 0; i < cols; i ++)
    {
        csc_row_idx_ptr0[i] = csc_row_idx_ptr1[i] = csc_row_idx + csc_col_ptr[i];
        csc_value_ptr0[i]   = csc_value_ptr1[i]   = csc_value   + csc_col_ptr[i];
    }

    int row_offset_record = -1;
    int task_id = 0;
    int slave_task_id[8][8];
    for(i = 0; i < 8; i ++)
        for(j = 0; j < 8; j ++)
            slave_task_id[i][j] = 0;
    //遍历每个小块任务
    for(task_id = 0; task_id < ntasks; task_id ++)
    {
      if (tasks[task_id].job == 0) {
        slave_task_id[tasks[task_id].worker_id][tasks[task_id].slaver_id] ++;
        continue;
      }
       
       if(tasks[task_id].row_offset != row_offset_record)
       {
           row_offset_record = tasks[task_id].row_offset;
           int row_length_record = tasks[task_id].row_length;
           for(i = row_offset_record; i < row_offset_record + row_length_record; i ++)
           {  
               for(j = row_ptr[i]; j < row_ptr[i+1]; j ++)
               {   //转换成CSC格式,记录列偏移和非零元值
                   *csc_row_idx_ptr1[col_idx[j]] ++ = i;
                   *csc_value_ptr1[col_idx[j]] ++ = value[j];
               }
           }
       }
       //确定从核行号和从核号
       i = tasks[task_id].worker_id;
       j = tasks[task_id].slaver_id;
       int ll = 0;
       //通过列号检索非零元
       for(k = tasks[task_id].col_offset; k < tasks[task_id].col_offset + tasks[task_id].col_length; k ++)
       {
           int sub_len = csc_value_ptr1[k] - csc_value_ptr0[k];
           for(l = 0; l < sub_len; l ++)
           {    
              //压缩非零元的行列坐标,压在一个int32内
              int rid_idx_value = csc_row_idx_ptr0[k][l] - info->infos[i][j].tasks[slave_task_id[i][j]].row_offset;
              int col_idx_value = k - info->infos[i][j].tasks[slave_task_id[i][j]].col_offset;
              int rid_col_idx_compress = (rid_idx_value << COL_IDX_DIGITS) + col_idx_value;
              //保存COO下的非零元坐标和值
              info->row_idx[info->infos[i][j].tasks[slave_task_id[i][j]].nnz_offset + ll] = rid_col_idx_compress;
              info_value  [info->infos[i][j].tasks[slave_task_id[i][j]].nnz_offset + ll] = csc_value_ptr0[k][l];
              ll ++;
           }
           csc_row_idx_ptr0[k] = csc_row_idx_ptr1[k];
           csc_value_ptr0[k]   = csc_value_ptr1[k];
       }
       slave_task_id[i][j] ++;
    }
    
    #ifdef Pa_Inspect
      gettimeofday(&t2, NULL);
        printf("<Inspect Fill in Last> Time: %.10lfs\n",TIME(t1,t2));
    #endif



  #ifdef DEBUGS
    // DATA_T original_sum = ZERO, reorder_sum = ZERO;
    // for(i = 0; i < rows; i ++)
    //     for(j = row_ptr[i]; j < row_ptr[i+1]; j ++)
    //         original_sum = original_sum + value[j];
    // for(i = 0; i < 8; i ++)
    //     for(j = 0; j < 8; j ++)
    //         for(k = 0; k < info->infos[i][j].ntasks; k ++)
    //             for(l = info->infos[i][j].tasks[k].nnz_offset; l < info->infos[i][j].tasks[k].nnz_offset + info->infos[i][j].tasks[k].nnz_length; l ++)
    //                 reorder_sum = reorder_sum + info_value[l];
    // fprintf(stderr , "Check sum : %.8f, %.8f\n", original_sum,reorder_sum);
  #endif


    swSparse_free(csc_col_ptr);
    swSparse_free(csc_row_idx);
    swSparse_free(csc_value);
    swSparse_free(csc_row_idx_ptr0);
    swSparse_free(csc_value_ptr0);
    swSparse_free(csc_row_idx_ptr1);
    swSparse_free(csc_value_ptr1);
    return result;
}

long long FUNCNAME(spmv_inspect)(swSparseMatrix Matrix_ , MatrixSWCOO *SpMV_Format , int* best_para_element_size , int* best_para_cache_element_size ){
  
  struct timeval t1, t2;
  SpMV_Format_Config cc;
  //存放矩阵带信息数组
  SpMV_Matrix_tile *Matrix_tile;
  //真实访存量与调优时的中间保存量
  long long real_mem , tmp_mem , min_mem;
  int para_tile_size,para_element_size,para_cache_element_size,para_element_min,para_cache_element_min;
  int task_count_best;
  SpMV_CSR_TASK_SIMPLE *task_best;
  bool flag;
  int i , j;

  //矩阵带宽度与矩阵块宽度赋初值
  para_tile_size = min(ins_tile_size , max(1024 , Matrix_->m / 8));
  para_element_size = ins_element_size;
  para_cache_element_size = ins_cache_element_size;
  flag = 0;
  real_mem = -1;
  min_mem = Matrix_->nnz*(sizeof(DATA_T) + sizeof(int)) + Matrix_->m*(sizeof(int) + sizeof(DATA_T)) + Matrix_->n*sizeof(DATA_T);

  #ifdef Pa_Inspect
    gettimeofday(&t1, NULL);
  #endif

  para_element_min = 16;
  para_cache_element_min = 8;


  //爆搜所有可使用的element_size和cache_element_size值,并保留最小实际访存量的分块策略
  for (para_element_size = ins_element_size ; para_element_size >=para_element_min ; para_element_size = para_element_size/2){
    for (para_cache_element_size = ins_cache_element_size ; para_cache_element_size >=para_cache_element_min ; para_cache_element_size = para_cache_element_size/2){
        //生成基本矩阵结构信息
        FUNCNAME(SWCOO_Format_Config)(&cc,para_tile_size,para_element_size,para_cache_element_size);
        //根据基本信息中的矩阵宽度,计算矩阵中的矩阵带数量
        FUNCNAME(Init_Matrix)(SpMV_Format,Matrix_,&cc);

        // Array of all tile_information order by worker number
        int *worker_tiles = (int*)swSparse_malloc(cc.nworkers * sizeof(int)); //number of tiles each worker do
        int *order_nnzs  =  (int*)swSparse_malloc(SpMV_Format->tile_num * sizeof(int)); //nnz of each tile
        int *order_tiles =  (int*)swSparse_malloc(SpMV_Format->tile_num * sizeof(int)); //tile Id
        int *masks =  (int*)swSparse_malloc(SpMV_Format->tile_num * sizeof(int));
        int *number_workers = (int*)swSparse_malloc(SpMV_Format->tile_num * sizeof(int));
        //------------------------------------------------------
        //调用生成矩阵带信息的函数
        Create_Tiles(Matrix_ ,SpMV_Format->tile_num,cc.tile_size,cc.nworkers,worker_tiles, order_tiles , order_nnzs );
        SpMV_CSR_Tile csr_tile[64];
        int p = 0;
        //根据矩阵带分配信息,再反向整理回各行从核,包括统计每行从核的矩阵带数量,非零元数等
        for ( i = 0; i < cc.nworkers ; i++){
          csr_tile[i].numbers = worker_tiles[i];
          csr_tile[i].nnzs = order_nnzs + p;
          csr_tile[i].tiles = order_tiles + p;
          csr_tile[i].number_workers = number_workers + p;
          csr_tile[i].masks = masks + p;
          p += worker_tiles[i];
        }
        int sum = 0; //all slavers used(times)

        //将矩阵带进一步划分成子矩阵,注意这里的子矩阵即给行内从核的任务分配而非最底层coo小矩阵块的划分
        for (i = 0;i < cc.nworkers; i++){
          sum += Create_SubMatrix(&csr_tile[i] , cc.nslavers , cc.avg_blocks , cc.tolerate);
        }

        //声明最小计算单元矩阵块的数组信息
        int block_offset = 0;
        SpMV_CSR_BLOCK *blocks = (SpMV_CSR_BLOCK*)swSparse_malloc(sum*sizeof(SpMV_CSR_BLOCK));
        int task_max = 8*sum;
        int task_count = 0;
        SpMV_CSR_TASK_SIMPLE *task_simple = (SpMV_CSR_TASK_SIMPLE*)swSparse_malloc(task_max*sizeof(SpMV_CSR_TASK_SIMPLE));
        int read_x_size = 0;

        //为每行从核进一步划分成最小矩阵块
        for(i = 0; i < cc.nworkers; i ++){
          for(j = 0; j < csr_tile[i].numbers; j ++){
              //划分子矩阵块并接受读X向量大小用于计算实际访存
              read_x_size += Create_CSR_Block(blocks+block_offset, Matrix_->matrix.csrc->offsets, Matrix_->matrix.csrc->indices, csr_tile[i].tiles[j]*cc.tile_size, min(cc.tile_size, Matrix_->m-csr_tile[i].tiles[j]*cc.tile_size), Matrix_->n, csr_tile[i].masks[j], csr_tile[i].number_workers[j], i, &task_simple, &task_count, &task_max, cc.element_size, cc.cache_element_size);
              block_offset += csr_tile[i].number_workers[j];
          }
              //break;
        }

        #ifdef DEBUGS
          int check_nnz = 0;
          for(i = 0; i < task_count; i ++) check_nnz += task_simple[i].nnz;
          fprintf(stderr , "Real nnz is %d Check nnz: %d\n",Matrix_->nnz ,  check_nnz);
          //fprintf(stderr , "task_count: %d, task_max: %d, read_x_size: %d\n", task_count, task_max, read_x_size);
        #endif

        //调用计算真实总访存量的函数
        tmp_mem = FUNCNAME(Sum_Real_Mem)(task_simple, task_count);
        printf("tmp_mem = %d block = %d*%d\n",tmp_mem , para_element_size , para_cache_element_size);
        //保存更优的调优参数下的新矩阵格式信息
        if (real_mem == -1 || real_mem > tmp_mem){
          swSparse_free(task_best);
          task_best = (SpMV_CSR_TASK_SIMPLE*)swSparse_malloc(task_max*sizeof(SpMV_CSR_TASK_SIMPLE));
          for (i = 0 ; i < task_count ; i++) memcpy(&task_best[i] , &task_simple[i] , sizeof(SpMV_CSR_TASK_SIMPLE));
          task_count_best = task_count;
          *best_para_element_size = para_element_size; 
          *best_para_cache_element_size = para_cache_element_size;
          real_mem = tmp_mem;
          //根据本参数格式下实际访存量情况,调整参数,开始下一轮格式转换尝试
          if (tmp_mem < 2 * min_mem) flag = 1;
          else if (tmp_mem <5 * min_mem / 2){
            para_element_min = 32;
            para_cache_element_min = 32;
          }
          else if (tmp_mem <4 * min_mem ){
            para_element_min = 16;
            para_cache_element_min = 16;
          }
          else{
            para_element_min = 16;
            para_cache_element_min = 8;
          }
        }

        swSparse_free(worker_tiles);
        swSparse_free(order_nnzs);
        swSparse_free(order_tiles);
        swSparse_free(masks);
        swSparse_free(number_workers);
        swSparse_free(blocks); 
        swSparse_free(task_simple); 
        if (flag) break;
    }
    if (flag) break;
  }

  #ifdef Pa_Inspect
    gettimeofday(&t2, NULL);
    printf("<Inspect Auto-Tuning> Time: %.10lfs\n",TIME(t1,t2));
  #endif

  #ifdef Pa_Inspect
      gettimeofday(&t1, NULL);
  #endif

  //根据矩阵转换信息,将最优的划分格式转存成为SWCOO格式,并完成内存中的数据重排
  DATA_T * v = Matrix_->matrix.csrc->values;
  real_mem = FUNCNAME(Fillin_Info)(SpMV_Format , task_best, task_count_best, Matrix_->matrix.csrc->offsets ,Matrix_->matrix.csrc->indices, v , Matrix_->m , Matrix_->n , Matrix_->nnz, cc.nworkers, cc.nslavers, cc.tile_size);
  printf("Finish fill_in.\n");

  #ifdef Pa_Inspect
    gettimeofday(&t2, NULL);
    printf("<Inspect Fillin_Info> Time: %.10lfs\n",TIME(t1,t2));
  #endif

  // swSparse_free(worker_tiles);
  // swSparse_free(order_nnzs);
  // swSparse_free(order_tiles);
  // swSparse_free(masks);
  // swSparse_free(number_workers);
  // swSparse_free(blocks);
  swSparse_free(task_best);

  printf("Finish free. %d %d %d\n",real_mem , tmp_mem , min_mem);

  return real_mem;
}

//不同精度的spmv预处理函数,并由多重编译支持不同精度
static ErrorStatus FUNCNAME(SpMV_inspect_call) (swSparseMatrix  *Ins_Matrix, swSparseMatrix Old_Matrix) {
    //转换后swcoo格式矩阵
    MatrixSWCOO SpMV_Format;
    int i,j;
    //自动调优参数,调整矩阵块的长度
    int best_para_element_size , best_para_cache_element_size;

    //声明转换后的新矩阵并开辟内存空间
    Matrix New_Matrix        = (Matrix) swSparse_malloc(sizeof(MatrixData));
    New_Matrix->matrix.swcoo = (swSparseMatrixSWCOO*)swSparse_malloc(sizeof(swSparseMatrixSWCOO));

    //如无法为新矩阵开辟内存空间,返回错误码
    if (New_Matrix               == NULL) return SWSPARSE_MALLOC_ERROR; 
    if (New_Matrix->matrix.swcoo == NULL) return SWSPARSE_MALLOC_ERROR; 

    //将原CSR矩阵和新开辟的矩阵作为参数传入预处理函数,并接受返回值,返回值为转换后的矩阵在计算中的真实访存量
    New_Matrix->matrix.swcoo->real_mem = (double)(FUNCNAME(spmv_inspect)(Old_Matrix,&SpMV_Format,&best_para_element_size,&best_para_cache_element_size));
    if (New_Matrix->matrix.swcoo->real_mem == -1) return SWSPARSE_MALLOC_ERROR;
    New_Matrix->matrix.swcoo->real_mem *=0.000001; 

    //将swcoo信息赋入新开辟的矩阵格式结构体中
    New_Matrix->n   = Old_Matrix->n;
    New_Matrix->m   = Old_Matrix->m;
    New_Matrix->nnz = Old_Matrix->nnz;
    New_Matrix->element_type = Old_Matrix->element_type;
    New_Matrix->format_type = SWSPARSE_SWCOO;

    New_Matrix->matrix.swcoo->mem_size = 0.000001 * ( New_Matrix->nnz*(sizeof(DATA_T) + sizeof(int)) + New_Matrix->m*(sizeof(int) + sizeof(DATA_T)) + New_Matrix->n*sizeof(DATA_T) );
    New_Matrix->matrix.swcoo->compute_size = 0.000000001*2.0*New_Matrix->nnz ;

    printf("real_mem = %.8f mem_size = %.8f block = %d*%d \n",New_Matrix->matrix.swcoo->real_mem,New_Matrix->matrix.swcoo->mem_size,best_para_element_size,best_para_cache_element_size);

  
    New_Matrix->matrix.swcoo->tile_num                     = SpMV_Format.tile_num; 
    New_Matrix->matrix.swcoo->row_idx                      = SpMV_Format.row_idx;  
    New_Matrix->matrix.swcoo->col_idx                      = SpMV_Format.col_idx;  
    New_Matrix->matrix.swcoo->value                        = SpMV_Format.value;    
    New_Matrix->matrix.swcoo->tasks                        = SpMV_Format.tasks;   
    New_Matrix->matrix.swcoo->rows                         = SpMV_Format.rows;
    New_Matrix->matrix.swcoo->cols                         = SpMV_Format.cols;
    New_Matrix->matrix.swcoo->nnz                          = SpMV_Format.nnz;
    New_Matrix->matrix.swcoo->ntasks                       = SpMV_Format.ntasks;
    New_Matrix->matrix.swcoo->best_para_element_size       = best_para_element_size;
    New_Matrix->matrix.swcoo->best_para_cache_element_size = best_para_cache_element_size;

    //同时将矩阵基本信息赋给info数组,info数组有8*8 64个,在计算时每个从核读取自己的计算信息
    for (i=0;i<8;i++)
      for (j=0;j<8;j++)
        New_Matrix->matrix.swcoo->infos[i][j] = SpMV_Format.infos[i][j];

    *Ins_Matrix = New_Matrix;

    return SWSPARSE_SUCCESS;
}
