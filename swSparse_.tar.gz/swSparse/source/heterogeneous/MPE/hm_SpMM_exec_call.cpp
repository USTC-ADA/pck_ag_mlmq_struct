#include "swSparse.h"
#include "swSparse_blas.h"
#include "swSparse_matrix.h"
#include "swSparse_options.h"
#include "internal/rename.h"
#include "internal/memory.h"
#include "internal/swSpMV.h"
#include "internal/debug.h"
#include "internal/reorder.h"
#include "internal/spmv_param.h"
#include "internal/spblas_common.h"
#include "internal/spmv_common.h"
#include "internal/crts.hpp"
#include "internal/multicompile.h"
#include "internal/utils.h"
#include "internal/rename.h"
#include "internal/templates.h"
#include "internal/kernel_args.h"

ATHREAD_SPAWN_TEMPLATE_ARGTYPE(spmm_cpe, spmv_kernel_arg_t)

namespace swSparse {

    template<typename DATA_T , typename Conj>
    ErrorStatus mm_execute_swcoo(DATA_T alpha, swSparseMatrix New_Matrix, swSparseInt nvec, const DATA_T *x, swSparseInt ldx, DATA_T beta, DATA_T *y, swSparseInt ldy, const swSparseMMOptions* options){

        int i,j;
        spmv_kernel_arg_t<DATA_T> args;
        swSparseMatrixSWCOO SpMV_Format;
        swSparseErrorStatus ret = SWSPARSE_SUCCESS;
        DATA_T ratio[2];

        using conj = conjugate<DATA_T>;
        using noconj = not_conjugate<DATA_T>;

        if (New_Matrix->format_type != SWCOO) return SWSPARSE_INVALID_ARGS;
        
        #ifdef DEBUGS
            //printf("Complex calculate in.\n");
        #endif

        SpMV_Format.tile_num = New_Matrix->matrix.swcoo->tile_num;
        SpMV_Format.row_idx  = New_Matrix->matrix.swcoo->row_idx;
        SpMV_Format.col_idx  = New_Matrix->matrix.swcoo->col_idx;
        SpMV_Format.value    = New_Matrix->matrix.swcoo->value;
        SpMV_Format.tasks    = New_Matrix->matrix.swcoo->tasks;
        SpMV_Format.ntasks   = New_Matrix->matrix.swcoo->ntasks;
        SpMV_Format.rows     = New_Matrix->matrix.swcoo->rows;
        SpMV_Format.cols     = New_Matrix->matrix.swcoo->cols;
        SpMV_Format.nnz      = New_Matrix->matrix.swcoo->nnz;

        ratio[0] = alpha;
        ratio[1] = beta;

        for (i=0;i<8;i++)
            for (j=0;j<8;j++){
                args.infos[i][j] = New_Matrix->matrix.swcoo->infos[i][j];
                args.infos[i][j].x = x;
                args.infos[i][j].b = y;
                args.infos[i][j].ratio = ratio;
                args.infos[i][j].vector_cols = nvec;
                args.infos[i][j].ldx = ldx;
                args.infos[i][j].ldy = ldy;
            }

        //ret = SpMV_Slave_run<DATA_T,noconj>(y , x, &SpMV_Format, ratio);

        athread_spawn_spmm_cpe(&args);
        athread_join();
        printf("Finish SpMM_Slave_run\n");

        return SWSPARSE_SUCCESS;

    }




template ErrorStatus mm_execute_swcoo<float,ID>(float alpha , swSparseMatrix New_Matrix, swSparseInt nvec, const float *x, swSparseInt ldx, float beta , float *y , swSparseInt ldy, const swSparseMMOptions* options);
template ErrorStatus mm_execute_swcoo<double,ID>(double alpha , swSparseMatrix New_Matrix, swSparseInt nvec, const double *x, swSparseInt ldx,double beta , double *y , swSparseInt ldy, const swSparseMMOptions* options);
template ErrorStatus mm_execute_swcoo<SComplex,ID>(SComplex alpha , swSparseMatrix New_Matrix, swSparseInt nvec,const SComplex *x, swSparseInt ldx, SComplex beta , SComplex *y , swSparseInt ldy, const swSparseMMOptions* options);
template ErrorStatus mm_execute_swcoo<DComplex,ID>(DComplex alpha , swSparseMatrix New_Matrix, swSparseInt nvec,const DComplex *x, swSparseInt ldx, DComplex beta , DComplex *y , swSparseInt ldy, const swSparseMMOptions* options);
template ErrorStatus mm_execute_swcoo<SComplex,CJ>(SComplex alpha , swSparseMatrix New_Matrix, swSparseInt nvec,const SComplex *x, swSparseInt ldx, SComplex beta , SComplex *y , swSparseInt ldy, const swSparseMMOptions* options);
template ErrorStatus mm_execute_swcoo<DComplex,CJ>(DComplex alpha , swSparseMatrix New_Matrix, swSparseInt nvec,const DComplex *x, swSparseInt ldx, DComplex beta , DComplex *y , swSparseInt ldy, const swSparseMMOptions* options);

} //namespace


