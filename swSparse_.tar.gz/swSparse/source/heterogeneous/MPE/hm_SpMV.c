#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "swSparse.h"
#include "internal/rename.h"
#include "internal/memory.h"
#include "internal/swSpMV.h"
#include "internal/utils.h"
#include "internal/debug.h"
#include "internal/reorder.h"
#include "internal/spmv_param.h"
#include "internal/spblas_common.h"
#include "internal/spmv_common.h"



#define DEBUGS

static int Get_MinId(int *a, int n){

  int now,id;
  int i;

  now = a[0];
  id = 0;

  for (i = 1; i < n ; i++){
    if (a[i] < now){
        now = a[i];
        id = i;
    }
  }

  return id;
}

//快速排序
static void Sort_Matrix_Tiles(SpMV_Matrix_tile *A , int l , int r){

  SpMV_Matrix_tile x , y;
  int k;
  int i,j;

  i = l;
  j = r;
  k = A[(i+j)>>1].tile_nnz;
  do{
    while (A[i].tile_nnz > k ) i++;
    while (A[j].tile_nnz < k ) j--;
    if (i<=j){
        x = A[i];
        A[i] = A[j];
        A[j] = x;
        i++;
        j--;
    }
  }while (i <= j);
  if (l<j) Sort_Matrix_Tiles(A,l,j);
  if (i<r) Sort_Matrix_Tiles(A,i,r);

}

static void Create_Tiles(swSparseMatrixData *Matrix_ ,int tile_num, int tile_size , int worker_num,int *worker_tiles, int *order_tiles , int *order_nnzs){

  //声明矩阵带信息数组
  SpMV_Matrix_tile *Matrix_tile = (SpMV_Matrix_tile*)swSparse_malloc(tile_num * sizeof(SpMV_Matrix_tile));
  int *_tiles_id_worker = (int*)swSparse_malloc(tile_num*worker_num*sizeof(int));
  int *tiles_id_worker[64];
  //nnz sun of each workers ; number of tiles each workers do
  int sums[64], sums2[64], counts[64];
  int i, j;

  for (i = 0; i < worker_num; i ++) tiles_id_worker[i] = _tiles_id_worker + i*tile_num;
  for (i = 0; i < worker_num; i ++) sums[2] = sums[i] = counts[i] = 0;

  //划分矩阵带并计算各各矩阵带中的非零元数量
  for (i = 0;i < tile_num ; i++){
    Matrix_tile[i].id = i;
    Matrix_tile[i].tile_nnz =  Matrix_->matrix.csrc->offsets[min( (i+1)*tile_size , Matrix_->m )] - Matrix_->matrix.csrc->offsets[i * tile_size];

  //  DEBUG_PRINT("Tile ID %d  nnz %d\n",i,Matrix_tile[i].tile_nnz);
  }

  //将矩阵带根据非零元数量从大到小排序
  Sort_Matrix_Tiles(Matrix_tile,0,tile_num - 1);

  //按贪心策略将所有矩阵带分配给不同从核行,具体策略见技术报告
  for (i = 0; i < tile_num ; i++){
    int id;
    id = Get_MinId(sums , worker_num);
    sums [id] += Matrix_tile[i].tile_nnz;
    tiles_id_worker[id][counts[id]++] = Matrix_tile[i].id;

    //printf("Worker ID = %d  Worker NNZ = %d\n",id,sums[id]);
  }


  //整理分配结果,整理分配后的矩阵带顺序与非零元数量
  int count = 0; 
  for (i = 0; i < worker_num ; i++){
    worker_tiles[i] = counts[i];
    for (j = 0;j < counts[i];j++){
        int tile_id = tiles_id_worker[i][j];
        order_nnzs[count] = Matrix_->matrix.csrc->offsets[min( (tile_id+1)*tile_size , Matrix_->m )] - Matrix_->matrix.csrc->offsets[tile_id*tile_size];
        order_tiles[count] = tile_id;
        count ++;
    }

  }

  swSparse_free(Matrix_tile);
  swSparse_free(_tiles_id_worker);
}

//生成矩阵带内的子矩阵
static int Create_SubMatrix(SpMV_CSR_Tile *tile, int slavers, int avg_blocks, double tolerate){

  int i, j , k;
  int tot_nnz = 0;
  int avg_nnz, min_nnz, max_nnz ;
  int sums[64];
  int sum = 0;
  int ids[64];

  //求和总非零元数
  for (i = 0; i< tile->numbers ; i++) tot_nnz += tile->nnzs[i];
  
  //求出平均每个从核的非零元数量
  avg_nnz = tot_nnz / (slavers * avg_blocks);
  //如果非零元数过少,则不再划分,只分给一个从核
  if (tot_nnz < 20) avg_nnz = tot_nnz;
  min_nnz = max(1,(1 - tolerate) * avg_nnz);
  max_nnz = max(1,(1 + tolerate) * avg_nnz);
  
  //给每个从核计算量赋初值
  for (i = 0; i < slavers ; i++){
    sums[i] = 0;
    ids[i] = i;
  }

  //逐一分配
  for (i = 0;i<tile->numbers ; i++){

    int result = 0;
    int nnz = tile->nnzs[i];
    int c = 1;

    //根据矩阵带中的非零元数和子矩阵中最大非零元的阈值,求出矩阵带交由几个从核计算
    while (nnz / c > max_nnz && c < slavers) c = c << 1;
    //给各个从核分配信息
    for (j = c - 1 ; j >= 0 ; j--){
        result += 1 << ids[j];
        sums[ids[j]] += nnz / c ;
        for (k = j+1 ; k < slavers ; k++){
           if (sums[ids[k-1]] > sums[ids[k]]){
              int tmp;
              tmp = ids[k - 1];
              ids[k - 1] = ids[k];
              ids[k] = tmp;
           }
           else break;
        }
    }

    //mask保存该矩阵带由从核行中的那些从核计算,number_workers保存由矩阵带由几个从核计算
    tile->masks[i] = result;
    tile->number_workers[i] = c;
    sum += c;
  }
  return sum;
}

//在子矩阵内继续划分出底层计算时的COO块
static int Create_CSR_Block(SpMV_CSR_BLOCK *blocks, int *row_ptr, int *col_idx, int row_offset, int row_length, int cols, int mask, int nworks, int worker_id, SpMV_CSR_TASK_SIMPLE **task, int *task_count, int *task_max, int element_size_, int cache_element_size){

  int result = 0;
  int element_cols = (cols + element_size_ - 1) / element_size_;
  int i, j, k, l;
  int task_root,task_ncpe;

  for(i = 0; i < nworks; i ++){
    blocks[i].row_offset = row_offset;
    blocks[i].row_length = row_length;
    blocks[i].worker_id = worker_id;
    blocks[i].mask = mask;
  }

  task_root = 0;
  task_ncpe = 0;

  //根据mask信息求出由哪些从核计算并记录从核根以在计算中汇总右端向量
  for (i = 0 ; i < 8 ; i++){
    if ( (1 << i) & mask ){
      task_root = i;
      task_ncpe ++;
    }
  }


  int *signal_ = (int*)swSparse_malloc(element_cols * sizeof(int));

  for(i = 0; i < element_cols; i ++) signal_[i] = 0;
  for(i = row_offset; i < row_offset+row_length; i ++)
    for(j = row_ptr[i]; j < row_ptr[i+1]; j ++){
      signal_[col_idx[j]/element_size_] ++;
    }


  int total_nnz = row_ptr[row_offset+row_length] - row_ptr[row_offset];
  int average_nnz = total_nnz / nworks;
  int left = 0, right = 0, slaver_id = 0;

  for(i = 0; i < nworks; i ++){
    int count = 0;
    int sub_tasks_count = 0;

    //根据宽度信息,求出每个小块的宽度和在原矩阵内的偏移量,同时保存该小块内的非零元数和负责的从核号
    while((i == nworks-1 || count < average_nnz) && right < element_cols) count += signal_[right++];
    while(!(mask & (1<<slaver_id))) slaver_id ++;
    blocks[i].col_offset = min(cols, left*element_size_);
    blocks[i].col_length = min(cols, right*element_size_) - min(cols, left*element_size_);
    blocks[i].nnz        = count;
    blocks[i].slaver_id  = slaver_id;


    j = left;
    while(j < right){
      //printf("In worker %d\n",i);
      int task_nnz = 0;
      //从最大宽度开始,从左右向内部缩,缩减掉没有一个非零元的矩阵区域,缩减后的宽度即为当前coo块的宽度
      while(j < right && signal_[j] == 0) j ++;
      if(j == right) break;
      k = j + cache_element_size - 1;
      while(k >= right || signal_[k] == 0) k --;
      k ++;


      //统计总非零元数
      for(l = j; l < k; l ++) task_nnz += signal_[l];
      // while (task_nnz > 1024){
      //   k--;
      //   task_nnz -= signal_[k];
      // }

      //从核需要计算的矩阵块数量+1,并给改矩阵块赋值信息,包括矩阵块在原矩阵中的行列偏移和长宽,从核行和从核号,非零元数量
      sub_tasks_count ++;
      (*task)[*task_count].row_offset = row_offset;
      (*task)[*task_count].row_length = row_length;
      (*task)[*task_count].col_offset = min(cols, j*element_size_);
      (*task)[*task_count].col_length = min(cols, k*element_size_) - min(cols, j*element_size_);
      (*task)[*task_count].worker_id  = worker_id;
      (*task)[*task_count].slaver_id  = slaver_id;
      (*task)[*task_count].nnz        = task_nnz;
      (*task)[*task_count].job        = 1;
      result += (*task)[*task_count].col_length;

      //如果从核非零元数量超过预开辟空间大小则扩容
      *task_count = *task_count + 1;
      if(*task_count == *task_max){
        *task_max = *task_max * 2;
        *task = swSparse_realloc(*task, *task_max*sizeof(SpMV_CSR_TASK_SIMPLE));
      }

      j = k;
    }

    if(sub_tasks_count > 0){
      //对于非第一个矩阵块,则只需保存根从核号
      for(j = *task_count - sub_tasks_count; j < *task_count; j ++){
      //  (*task)[j].get_id = slaver_id;
      //  (*task)[j].put_id = slaver_id;
        (*task)[j].reduce_flag = 0;
        (*task)[j].reduce_root = slaver_id;
        (*task)[j].reduce_ncpe = 1;
        (*task)[j].store_flag  = 0;
      }
      
      (*task)[*task_count - 1].reduce_flag = 1;
      (*task)[*task_count - 1].reduce_root = task_root;
      (*task)[*task_count - 1].reduce_ncpe = task_ncpe;
      //如果从核为根从核,则将flag变1代表在计算时需要累加右端向量并写过内存
      if (slaver_id == task_root) (*task)[j].store_flag = 1;

            //set get_id
      //if((1<<slaver_id) <= (mask-(1<<slaver_id))) (*task)[*task_count - 1].get_id = slaver_id + 1;
            //set put_id
      //int first_one = 1;
      //for(j = 0; j < slaver_id; j ++) if(mask & (1<<j)) first_one = 0;
      //if(first_one) (*task)[*task_count - 1].put_id = -1;
      //else          (*task)[*task_count - 1].put_id = slaver_id - 1;
    }
    else{
      //对于第一个矩阵块还需要额外保存矩阵块信息,具体信息同上
      (*task)[*task_count].row_offset = row_offset;
      (*task)[*task_count].row_length = row_length;
      (*task)[*task_count].col_offset = cols;
      (*task)[*task_count].col_length = 0;
      (*task)[*task_count].worker_id  = worker_id;
      (*task)[*task_count].slaver_id  = slaver_id;
      (*task)[*task_count].nnz = 0;
      (*task)[*task_count].job = 0;
      *task_count = *task_count + 1;
      if(*task_count == *task_max){
        //printf("task_max # = %d \n",*task_max);
        *task_max = *task_max * 2;
        //printf("task_max & = %d \n",*task_max);
        *task = swSparse_realloc(*task, *task_max*sizeof(SpMV_CSR_TASK_SIMPLE));
      }

      (*task)[*task_count - 1].reduce_flag = 1;
      (*task)[*task_count - 1].reduce_root = task_root;
      (*task)[*task_count - 1].reduce_ncpe = task_ncpe;
      if (slaver_id == task_root) (*task)[j].store_flag = 1;
      //(*task)[*task_count - 1].get_id = (*task)[*task_count - 1].slaver_id;
    }

    
    // printf("task_count %d subtask %d left %d right %d\n",*task_count , sub_tasks_count , left , right);
    // printf("rowoff %d rowlen %d coloff %d collen %d\n", (*task)[i].row_offset,(*task)[i].row_length,(*task)[i].col_offset,(*task)[i].col_length);
    // printf("worker %d slave %d nnz %d job %d\n",(*task)[i].worker_id,(*task)[i].slaver_id,(*task)[i].nnz,(*task)[i].job);
    // printf("\n");

    left = right;
    slaver_id ++;
  }

  swSparse_free(signal_);
  return result;
}

#define DATA_TYPE_S
#include "hm_SpMV.inl"
#undef DATA_TYPE_S
#define DATA_TYPE_D
#include "hm_SpMV.inl"
#undef DATA_TYPE_D
#define DATA_TYPE_C
#include "hm_SpMV.inl"
#undef DATA_TYPE_C
#define DATA_TYPE_Z
#include "hm_SpMV.inl"
#undef DATA_TYPE_Z

//直接拷贝CSR格式矩阵的预处理函数
ErrorStatus swSparse_mv_inspect_to_csr(Matrix old_mat, Matrix *new_mat,const swSparseMVOptions* options) {
    switch(old_mat->format_type) {
    case CSR:
        return swSparse_copy(old_mat, new_mat);
    default:
        return SWSPARSE_INVALID_ARGS;
    }
}

//转化至swcoo格式矩阵的预处理函数
ErrorStatus swSparse_mv_inspect_to_swcoo(swSparseMatrix Old_Matrix ,swSparseMatrix  *Ins_Matrix , const swSparseMVOptions* options){
  
  //检查输入矩阵是否为CSR格式
  if (Old_Matrix->format_type != CSR) return SWSPARSE_INVALID_ARGS;
  
  swSparseErrorStatus ret = SWSPARSE_SUCCESS;
  // ret = swSparse_ensure_order(Old_Matrix);
  
  //根据输入矩阵不同数据类型,分别调用不同数据类型的预处理函数
  if (Old_Matrix->element_type == REAL_DOUBLE){
    ret = swSparse_d_SpMV_inspect_call(Ins_Matrix, Old_Matrix); 
  }
  else if (Old_Matrix->element_type == REAL_SINGLE){
    ret = swSparse_s_SpMV_inspect_call(Ins_Matrix, Old_Matrix);
  }
  else if (Old_Matrix->element_type == COMPLEX_DOUBLE){
    ret = swSparse_z_SpMV_inspect_call(Ins_Matrix, Old_Matrix);
  }
  else if (Old_Matrix->element_type == COMPLEX_SINGLE){
    ret = swSparse_c_SpMV_inspect_call(Ins_Matrix, Old_Matrix);
  }

  return ret;

}

ErrorStatus swSparse_mm_inspect(swSparseMatrix Old_Matrix ,swSparseMatrix  *Ins_Matrix , const swSparseMMOptions* options){
  
  if (Old_Matrix->format_type != CSR) return SWSPARSE_INVALID_ARGS;
  
  swSparseErrorStatus ret = SWSPARSE_SUCCESS;
  // ret = swSparse_ensure_order(Old_Matrix);
    
  if (Old_Matrix->element_type == REAL_DOUBLE){
    ret = swSparse_d_SpMV_inspect_call(Ins_Matrix, Old_Matrix); 
  }
  else if (Old_Matrix->element_type == REAL_SINGLE){
    ret = swSparse_s_SpMV_inspect_call(Ins_Matrix, Old_Matrix);
  }
  else if (Old_Matrix->element_type == COMPLEX_DOUBLE){
    ret = swSparse_z_SpMV_inspect_call(Ins_Matrix, Old_Matrix);
  }
  else if (Old_Matrix->element_type == COMPLEX_SINGLE){
    ret = swSparse_c_SpMV_inspect_call(Ins_Matrix, Old_Matrix);
  }

  return ret;

}



