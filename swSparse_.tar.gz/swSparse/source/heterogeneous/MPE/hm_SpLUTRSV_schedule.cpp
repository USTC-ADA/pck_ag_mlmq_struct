#include <algorithm>
#include "swperf.h"
#include "internal/templates.h"
#include "internal/memory.h"
#include "internal/rename.h"
#include "internal/reorder.h"
#include "internal/utils.h"
#include "internal/debug.h"
#include "internal/sptrf_param.h"
#include "internal/algorithm_heap.h"
#include "internal/splutrsv_param.h"
#include "swSparse_splutrsv.h"

// #define ATHREAD_SPAWN(fun, arg) __real_athread_spawn((void*)SLAVE_FUN(fun), arg, 1)
// extern "C" void SLAVE_FUN(splutrsv_static_estimate_kernel)(void*);

namespace swSparse {

ATHREAD_SPAWN_CONCRETE_ARGTYPE(sort_subtrees_kernel, sort_subtrees_arg_t)
ATHREAD_SPAWN_CONCRETE_ARGTYPE(lutrsv_static_estimate_kernel, lutrsv_static_estimate_arg_t)

static void athread_join_sort_subtrees(const sort_subtrees_arg_t& args) {
    if(UNLIKELY(args.temp != nullptr)) {
        swSparse_free(args.temp);
        athread_join();
    }
}

static void sort_subtree_host(const Int* offset, trf_subtree_t* subtrees) {
    for(Int tid = 0; tid < 64; ++ tid) {
        std::sort(subtrees + offset[tid], subtrees + offset[tid+1]);
    }
}

using weight_t = lutrsv_weight_t;

struct weight_heap_t {
    weight_t weight;
    Int id;
};

struct get_weight_t {
    weight_t operator()(const weight_heap_t& h) const { return h.weight; }
};

inline constexpr get_weight_t get_weight;
inline constexpr Int etree_empty = -1;

class queue_scheduler {
    const Int* next_sibling;
    const weight_t* sup_weight;
    Int* snode_status;
    trf_task_t *result_queue;
public:
    queue_scheduler(const Int* next, const weight_t* weight, Int* status, trf_task_t *queue) :
        next_sibling(next), sup_weight(weight), snode_status(status), result_queue(queue) {}

    Int enqueue(Int parent_queue_id, Int first_child, Int queue_tail) {
        Int current_right = queue_tail, left_id, right_id;
        for(Int isup = first_child; isup != etree_empty; isup = next_sibling[isup]) {
            Int status = snode_status[isup];
            if(status == 0) {
                result_queue[queue_tail].parent = parent_queue_id;
                result_queue[queue_tail--].sup_id = isup;
            }
        }
        for(left_id = queue_tail + 1, right_id = current_right; left_id < right_id; ++left_id, --right_id) {
            Int left_i = result_queue[left_id].sup_id, right_i = result_queue[right_id].sup_id;
            Int left_p = result_queue[left_id].parent, right_p = result_queue[right_id].parent;
            snode_status[right_i] = left_id;
            snode_status[left_i] = right_id;
            result_queue[left_id].sup_id = right_i;
            result_queue[right_id].sup_id = left_i;
            result_queue[left_id].parent = right_p;
            result_queue[right_id].parent = left_p;
        }
        if(left_id == right_id) {
            snode_status[result_queue[left_id].sup_id] = left_id;
        }
        return queue_tail;
    }

    void set_level_info(Int q_head, Int q_tail) const {
        weight_t level_sum_weight = 0;
        for(Int queue_id = q_head; queue_id > q_tail; --queue_id) {
            Int sup_id = result_queue[queue_id].sup_id;
            level_sum_weight += sup_weight[sup_id];
        }
        for(Int queue_id = q_head; queue_id > q_tail; --queue_id) {
            Int sup_id = result_queue[queue_id].sup_id;
            // 根据在同一 level 中负载比例决定分配核心上限
            Int max_core_num = cpe_for_subtree * sup_weight[sup_id] / level_sum_weight;
            result_queue[queue_id].level_id = std::min(cpe_for_subtree, std::max(max_core_num, 1));
        }
    }
};

// 估计 L 和 U 超节点的负载，L = U ^ T, U = L ^ T, 也即视为行主顺序
static void static_estimate(Int nsuper, weight_t *lweight, weight_t *uweight, LUSup* lu) {
    // flop: compute, alpha: dense mem, beta: sparse mem
    const weight_t flop = 1, alpha = 14.56789f, beta = 123.456789f;
    if(nsuper < CPE_ESTIMATE_NSUPER) {
        const Int *sup2col = lu->sup2col, *col2sup = lu->col2sup;
        const Int *l_v_offsets = lu->l_v_offsets,  *l_i_offsets = lu->l_i_offsets;
        const Int *u_col_offsets = lu->u_col_offsets, *u_seg_offsets = lu->u_seg_offsets;
        for(Int isup = 0; isup < nsuper; ++isup) {
            Int isup_begin = sup2col[isup], isup_end = sup2col[isup + 1];
            Int isup_useg_begin = u_col_offsets[isup_begin], isup_useg_end = u_col_offsets[isup_end];
            Int sc = isup_end - isup_begin;
            Int si = l_i_offsets[isup + 1] - l_i_offsets[isup];
            Int ss = isup_useg_end - isup_useg_begin;
            Int sv = u_seg_offsets[isup_useg_end] - u_seg_offsets[isup_useg_begin];
            // flops + dense mem + sparse mem
            // L: (sv + sc * sc / 2) + (sv * 2 + sc * sc - ss) * alpha + ss * beta
            // maybe (sv + sc * sc / 2) * (1 + alpha) + (ss + sc) * beta
            lweight[isup] = 4 * alpha + float(sv + sc * sc / 2) * (flop + 2 * alpha) + float(ss) * (beta - alpha);
            // U: (sv + sc * sc / 2) + (sv * 2 + sc * sc - si) * alpha + si * beta
            uweight[isup] = 4 * alpha + float(si * sc + sc * sc / 2) * (flop + 2 * alpha) + float(si) * (beta - alpha);
        }
        lweight[nsuper] = uweight[nsuper] = 0;
    } else {
        lutrsv_static_estimate_arg_t static_estimate_arg;
        static_estimate_arg.nsuper = nsuper;
        static_estimate_arg.lweight = lweight;
        static_estimate_arg.uweight = uweight;
        static_estimate_arg.lu = lu;
        
        static_estimate_arg.flop = flop;
        static_estimate_arg.alpha = alpha;
        static_estimate_arg.beta = beta;
        athread_spawn_lutrsv_static_estimate_kernel(&static_estimate_arg);
        athread_join();
    }
}

ErrorStatus lutrsv_lstatic_schedule(lutrsv_static_schedule_arg_t* args, LUSup* lu, const weight_t *lweight) {
    Int nsuper = lu->nsuper;
    const Int* first_child = args->first_child;
    const Int* next_sibling = args->next_sibling;
    const Int *sup_parent = lu->sup_etree_parent;

    /* 计算各个子树的权重 */
    weight_t *lsubtree_weight = (weight_t*)swSparse_malloc(sizeof(weight_t) * (nsuper + 1) + sizeof(weight_heap_t) * nsuper);
    // heap_1: 保存子树权重的大根堆
    weight_heap_t *heap_1 = reinterpret_cast<weight_heap_t*>(lsubtree_weight + nsuper + 1);
    IF_ERR(lsubtree_weight == nullptr) {
        return MALLOC_ERROR; 
    }
    memcpy(lsubtree_weight, lweight, sizeof(weight_t) * (nsuper + 1));
    for(Int isup = 0; isup < nsuper; ++isup) {
        lsubtree_weight[sup_parent[isup]] += lsubtree_weight[isup];
    }

    /* 调度子树 */
    weight_t sum_weight = lsubtree_weight[nsuper];
    heap_1[0].id = nsuper;
    heap_1[0].weight = sum_weight;
    // heap_size: 堆的大小
    Int heap_size = 1;
    // ichain: 排除的链的索引起始位置
    Int ichain = nsuper;
    while (heap_size > 0 && heap_1[0].weight * cpe_for_subtree > sum_weight) {
        Int t = heap_1[0].id, f = first_child[t];
        // 沿链移动到叶节点或分支
        while (f != etree_empty && next_sibling[f] == etree_empty) {
            t = f;
            f = first_child[t];
        }
        // 暂时排除无分叉的长链，t: 分支, f: first child of t
        if (f == etree_empty) { 
            heap_1[--ichain] = heap_1[0];
            heap_1[0] = heap_1[--heap_size];
            adjust_heap_max_down(0, heap_size, heap_1, get_weight);
        } else {
            Int ch = first_child[t];
            sum_weight -= heap_1[0].weight;
            heap_1[0].id = ch;
            heap_1[0].weight = lsubtree_weight[ch];
            sum_weight += heap_1[0].weight;
            adjust_heap_max_down(0, heap_size, heap_1, get_weight);
            while (next_sibling[ch] != etree_empty) {
                ch = next_sibling[ch];
                heap_1[heap_size].id = ch;
                heap_1[heap_size].weight = lsubtree_weight[ch];
                sum_weight += heap_1[heap_size].weight;
                adjust_heap_max_up(heap_size++, heap_1, get_weight);
            }
        }
    }
    
    Int nsubtree = heap_size + nsuper - ichain;
    // 将排除的链状子树加入 heap_1
    for(Int i = heap_size; i < nsubtree; ++ i) {
        heap_1[i] = heap_1[ichain ++];
        adjust_heap_max_up(i, heap_1, get_weight);
    }
    heap_size = nsubtree;
    // 缩短最长的长链
    while (heap_size >= cpe_for_subtree && heap_1[0].weight * cpe_for_subtree > sum_weight) {
        Int t = heap_1[0].id;
        sum_weight -= lsubtree_weight[t];
        t = first_child[t];
        if (t == etree_empty) {
            heap_1[0] = heap_1[--heap_size];
        } else {
            heap_1[0].id = t;
            heap_1[0].weight = lsubtree_weight[t];
            sum_weight += heap_1[0].weight;
        }
        adjust_heap_max_down(0, heap_size, heap_1, get_weight);
    }

    Int nsuper_subtree;
    trf_subtree_t* lsubtrees;

    Int* lsubtree_offsets = (Int*)swSparse_malloc(sizeof(Int) * ((cpe_for_subtree + 1) * 2 + nsuper));
    Int* ltask_offsets = lsubtree_offsets + cpe_for_subtree + 1;
    Int nsubtree_per_cpe[cpe_for_subtree] = {0};
    Int lntask_per_cpe[cpe_for_subtree] = {0};
    // lnode_status: 节点状态，在子树阶段则 < 0(为 tid - 64)，在任务队列阶段则 >= 0(为任务索引)
    Int* lnode_status = ltask_offsets + cpe_for_subtree + 1;
    // heap_2: 核心权重的小根堆
    weight_heap_t heap_2[cpe_for_subtree] = {0};
    if(lsubtree_offsets == nullptr) {
        return clean_return(MALLOC_ERROR, lsubtree_weight); 
    }
    memset(lsubtree_offsets, 0, sizeof(Int) * ((cpe_for_subtree + 1) * 2 + nsuper));
    
    // 子树太少，全部进入队列处理
    if(heap_size < cpe_for_subtree) {
        nsuper_subtree = nsubtree = heap_size = 0;
        lsubtrees = nullptr;
        for(Int i = 0; i <= cpe_for_subtree; ++i) {
            lsubtree_offsets[i] = 0;
        }
        for(Int i = 0; i < cpe_for_subtree; ++i) {
            heap_2[i].id = i;
        }
    } else {
        nsubtree = heap_size;
        /* schedule subtrees
        * heap_1 = { weight : weight, id : root of subtree }
        * heap_2 = { weight : weight, id : CPE id }
        */
        for(Int tid = 0; tid < cpe_for_subtree; ++ tid) {
            lnode_status[heap_1[0].id] = tid - 64;
            ++nsubtree_per_cpe[tid];
            heap_2[cpe_for_subtree - 1 - tid].id = tid;
            heap_2[cpe_for_subtree - 1 - tid].weight = heap_1[0].weight;
            auto tmp = heap_1[--heap_size];
            heap_1[heap_size] = heap_1[0];
            heap_1[0] = tmp;
            adjust_heap_max_down(0, heap_size, heap_1, get_weight);
        }
        // heap_2 already sorted
        // init_heap_min(cpe_for_subtree, heap_2, get_weight);
        while(heap_size > 0) {
            Int tid = heap_2[0].id;
            lnode_status[heap_1[0].id] = tid - 64;
            ++nsubtree_per_cpe[tid];
            heap_2[0].weight += heap_1[0].weight;
            auto tmp = heap_1[--heap_size];
            heap_1[heap_size] = heap_1[0];
            heap_1[0] = tmp;
            adjust_heap_max_down(0, heap_size, heap_1, get_weight);
            adjust_heap_min_down(0, cpe_for_subtree, heap_2, get_weight);
        }
        // here heap_1 is sorted

        lsubtrees = (trf_subtree_t*)swSparse_malloc(sizeof(trf_subtree_t) * nsubtree);
        IF_ERR(lsubtrees == nullptr) {
            return clean_return(MALLOC_ERROR, lsubtree_weight, lsubtree_offsets);
        }

        // schedule subtrees
        Int temp = 0;
        for(Int i = 0; i < cpe_for_subtree; ++i) {
            temp += nsubtree_per_cpe[i];
            lsubtree_offsets[i] = temp;
        }
        lsubtree_offsets[cpe_for_subtree] = temp;
        nsuper_subtree = 0;
        for(Int i = 0; i < nsubtree; ++i) {
            Int root = heap_1[i].id;
            Int status = lnode_status[root];
            Int tid = status + 64;
            Int pos = --(lsubtree_offsets[tid]);
            Int end = root + 1;
            Int begin = root;
            lsubtrees[pos].sup_end = end;
            while(first_child[begin] != etree_empty) {
                begin = first_child[begin];
            }
            lsubtrees[pos].sup_begin = begin;
            lsubtrees[pos].parent_task = 0;
            nsuper_subtree += end - begin;
            for(Int j = begin; j < end; ++j) {
                lnode_status[j] = status;
            }
        }
    }
    Int nsuper_queue = nsuper - nsuper_subtree;

    // extremely rare: matrix is balanced reducible, no need to sort subtrees
    if(UNLIKELY(nsuper_queue == 0)) {  
        args->lnode_status = lnode_status;
        args->lsubtrees = lsubtrees;
        args->lsubtree_offsets = lsubtree_offsets;
        args->ltasks = nullptr;
        args->ltask_offsets = ltask_offsets;
        args->ltask_queue = nullptr;

        swSparse_free(lsubtree_weight);

        return SWSPARSE_SUCCESS;
    } else {
        Int q_head, q_tail, q_level;

        // 根据 sup_begin 排序子树
        sort_subtrees_arg_t sort_subtree_args;
        if(LIKELY(nsubtree < cpe_for_subtree * 8)) {
            sort_subtree_args.temp = nullptr;
            sort_subtree_host(lsubtree_offsets, lsubtrees);
        } else {
            // so many subtrees that need CPE to sort
            sort_subtree_args.temp = (trf_subtree_t*)swSparse_malloc_raw(sizeof(trf_subtree_t) * nsubtree);
            sort_subtree_args.subtrees = lsubtrees;
            sort_subtree_args.subtree_offsets = lsubtree_offsets;
            athread_spawn_sort_subtrees_kernel(&sort_subtree_args);
            athread_join_sort_subtrees(sort_subtree_args);
            swSparse_free(sort_subtree_args.temp);
        }

        auto result_queue = (trf_task_t*)swSparse_malloc(sizeof(trf_task_t) * nsuper_queue);
        IF_ERR(result_queue == nullptr) {
            fprintf(stderr, "result_queue_malloc_err\n");
            return clean_return(MALLOC_ERROR, lsubtree_weight, lsubtree_offsets, lsubtrees);
        }

        auto ltask_queue = (lutrsv_task_t*)swSparse_malloc(sizeof(lutrsv_task_t) * nsuper_queue);
        IF_ERR(ltask_queue == nullptr) {
            fprintf(stderr, "task_queue_malloc_err\n");
            return clean_return(MALLOC_ERROR, lsubtree_weight, lsubtree_offsets, lsubtrees, result_queue); 
        }

        // enqueue supernodes in level-set order
        q_head = nsuper_queue - 1;
        q_tail = q_head;
        queue_scheduler sched(next_sibling, lweight, lnode_status, result_queue);

        q_tail = sched.enqueue(nsuper, first_child[nsuper], q_tail);
        sched.set_level_info(q_head, q_tail);
        q_level = 1;
        while(q_head != q_tail) {
            Int begin = q_head, end = q_tail;
            q_head = q_tail;
            for(Int queue_id = begin; queue_id > end; --queue_id) {
                q_tail = sched.enqueue(queue_id, first_child[result_queue[queue_id].sup_id], q_tail);
            }
            sched.set_level_info(q_head, q_tail);
            q_level += 1;
        }
        ASSERT_EQUAL(q_head, -1);
        ASSERT_EQUAL(q_tail, -1);
       
        /* 调度 task_queue */
        Int q, req, part_size, shift;
        weight_t sync_weight = 123.456789f;
        for(Int i = 0; i < nsuper_queue; ++i) {
            // 确定使用的核数
            Int sup_id = result_queue[i].sup_id;
            ltask_queue[i].sup_id = sup_id;
            ltask_queue[i].queue_id = i;
            shift = block_cycle_shift;
            ltask_queue[i].stride = (1 << shift);

            q = result_queue[i].level_id;
            req = ceiling_sra(lu->sup2col[sup_id + 1] - lu->sup2col[sup_id], shift);
            if(req <= q) {
                ltask_queue[i].group.npart = req;

                Int isup_begin = lu->sup2col[sup_id], isup_end = lu->sup2col[sup_id + 1];
                Int isup_useg_begin = lu->u_col_offsets[isup_begin], isup_useg_end = lu->u_col_offsets[isup_end];
                Int sc = isup_end - isup_begin;
                Int sv = lu->u_seg_offsets[isup_useg_end] - lu->u_seg_offsets[isup_useg_begin];
                part_size = std::min(q / req, (sv / sc) / (1 << shift));
                part_size = std::max(part_size, 1);
                
                ltask_queue[i].group.size = part_size * req;
            } else {
                ltask_queue[i].group.npart = q;
                ltask_queue[i].group.size = q;
            }

            // 确定使用的核心
            heap_size = 64;
            weight_heap_t tmp;
            Int j;

            Int isup_begin = lu->sup2col[sup_id], isup_end = lu->sup2col[sup_id + 1];
            Int npart = ltask_queue[i].group.npart;

            for(j = 0; j < ltask_queue[i].group.size; ++j) {
                Int tid = heap_2[0].id;
                ltask_queue[i].group.partner[j] = tid;
                ++lntask_per_cpe[tid];
                --heap_size;
                tmp = heap_2[0];
                heap_2[0] = heap_2[heap_size];
                heap_2[heap_size] = tmp;
                adjust_heap_min_down(0, heap_size, heap_2, get_weight);
            }

            tmp.weight += (lweight[sup_id] / ltask_queue[i].group.size) + req * sync_weight;;
            for(; j > 0; --j) {
                heap_2[heap_size].weight = tmp.weight;
                adjust_heap_min_up(heap_size, heap_2, get_weight);
                ++heap_size;
            }
        }

        swSparse_free(result_queue);

        Int temp = 0;
        for(Int i = 0; i < cpe_for_subtree; ++i) {
            ltask_offsets[i] = temp;
            temp += lntask_per_cpe[i];
        }

        auto ltasks = (lutrsv_task_t*)swSparse_malloc(sizeof(lutrsv_task_t) * temp);
        IF_ERR(ltasks == nullptr) {
            return clean_return(MALLOC_ERROR, lsubtree_weight, lsubtree_offsets, lsubtrees, result_queue, ltask_queue); 
        }
        for(Int i = 0; i < nsuper_queue; ++i) {
            for(Int j = 0; j < ltask_queue[i].group.size; ++j) {
                Int& offset = ltask_offsets[ltask_queue[i].group.partner[j]];
                ltasks[offset] = ltask_queue[i];
                ltasks[offset].group.id = j;
                ++offset;
            }
        }
        for(Int i = cpe_for_subtree; i > 0; --i) {
            ltask_offsets[i] = ltask_offsets[i - 1];
        }
        ltask_offsets[0] = 0;

        args->lnode_status = lnode_status;
        args->lsubtrees = lsubtrees;
        args->lsubtree_offsets = lsubtree_offsets;
        args->ltasks = ltasks;
        args->ltask_offsets = ltask_offsets;
        args->ltask_queue = ltask_queue;

        swSparse_free(lsubtree_weight);
        return SWSPARSE_SUCCESS;
    }
}

ErrorStatus lutrsv_ustatic_schedule(lutrsv_static_schedule_arg_t* args, LUSup* lu, const weight_t *uweight) {
    Int nsuper = lu->nsuper;
    const Int* first_child = args->first_child;
    const Int* next_sibling = args->next_sibling;
    const Int *sup_parent = lu->sup_etree_parent;

    /* 计算各个子树的权重 */
    weight_t *usubtree_weight = (weight_t*)swSparse_malloc(sizeof(weight_t) * (nsuper + 1) + sizeof(weight_heap_t) * nsuper);
    // heap_1: 保存子树权重的大根堆
    weight_heap_t *heap_1 = reinterpret_cast<weight_heap_t*>(usubtree_weight + nsuper + 1);
    IF_ERR(usubtree_weight == nullptr) {
        return MALLOC_ERROR; 
    }
    memcpy(usubtree_weight, uweight, sizeof(weight_t) * (nsuper + 1));
    for(Int isup = 0; isup < nsuper; ++isup) {
        usubtree_weight[sup_parent[isup]] += usubtree_weight[isup];
    }

    /* 调度子树 */
    weight_t sum_weight = usubtree_weight[nsuper];
    heap_1[0].id = nsuper;
    heap_1[0].weight = sum_weight;
    // heap_size: 堆的大小
    Int heap_size = 1;
    // ichain: 排除的链的索引起始位置
    Int ichain = nsuper;
    while (heap_size > 0 && heap_1[0].weight * cpe_for_subtree > sum_weight) {
        Int t = heap_1[0].id, f = first_child[t];
        // 沿链移动到叶节点或分支
        while (f != etree_empty && next_sibling[f] == etree_empty) {
            t = f;
            f = first_child[t];
        }
        // 暂时排除无分叉的长链，t: 分支, f: first child of t
        if (f == etree_empty) { 
            heap_1[--ichain] = heap_1[0];
            heap_1[0] = heap_1[--heap_size];
            adjust_heap_max_down(0, heap_size, heap_1, get_weight);
        } else {
            Int ch = first_child[t];
            sum_weight -= heap_1[0].weight;
            heap_1[0].id = ch;
            heap_1[0].weight = usubtree_weight[ch];
            sum_weight += heap_1[0].weight;
            adjust_heap_max_down(0, heap_size, heap_1, get_weight);
            while (next_sibling[ch] != etree_empty) {
                ch = next_sibling[ch];
                heap_1[heap_size].id = ch;
                heap_1[heap_size].weight = usubtree_weight[ch];
                sum_weight += heap_1[heap_size].weight;
                adjust_heap_max_up(heap_size++, heap_1, get_weight);
            }
        }
    }
    
    Int nsubtree = heap_size + nsuper - ichain;
    // 将排除的链状子树加入 heap_1
    for(Int i = heap_size; i < nsubtree; ++ i) {
        heap_1[i] = heap_1[ichain ++];
        adjust_heap_max_up(i, heap_1, get_weight);
    }
    heap_size = nsubtree;
    // 缩短最长的长链
    while (heap_size >= cpe_for_subtree && heap_1[0].weight * cpe_for_subtree > sum_weight) {
        Int t = heap_1[0].id;
        sum_weight -= usubtree_weight[t];
        t = first_child[t];
        if (t == etree_empty) {
            heap_1[0] = heap_1[--heap_size];
        } else {
            heap_1[0].id = t;
            heap_1[0].weight = usubtree_weight[t];
            sum_weight += heap_1[0].weight;
        }
        adjust_heap_max_down(0, heap_size, heap_1, get_weight);
    }

    Int nsuper_subtree;
    trf_subtree_t* usubtrees;

    Int* usubtree_offsets = (Int*)swSparse_malloc(sizeof(Int) * ((cpe_for_subtree + 1) * 2 + nsuper));
    Int* utask_offsets = usubtree_offsets + cpe_for_subtree + 1;
    Int nsubtree_per_cpe[cpe_for_subtree] = {0};
    Int untask_per_cpe[cpe_for_subtree] = {0};
    // unode_status: 节点状态，在子树阶段则 < 0(为 tid - 64)，在任务队列阶段则 >= 0(为任务索引)
    Int* unode_status = utask_offsets + cpe_for_subtree + 1;
    // heap_2: 核心权重的小根堆
    weight_heap_t heap_2[cpe_for_subtree] = {0};
    if(usubtree_offsets == nullptr) {
        return clean_return(MALLOC_ERROR, usubtree_weight); 
    }
    memset(usubtree_offsets, 0, sizeof(Int) * ((cpe_for_subtree + 1) * 2 + nsuper));
    
    // 子树太少，全部进入队列处理
    if(heap_size < cpe_for_subtree) {
        nsuper_subtree = nsubtree = heap_size = 0;
        usubtrees = nullptr;
        for(Int i = 0; i <= cpe_for_subtree; ++i) {
            usubtree_offsets[i] = 0;
        }
        for(Int i = 0; i < cpe_for_subtree; ++i) {
            heap_2[i].id = i;
        }
    } else {
        nsubtree = heap_size;
        /* schedule subtrees
        * heap_1 = { weight : weight, id : root of subtree }
        * heap_2 = { weight : weight, id : CPE id }
        */
        for(Int tid = 0; tid < cpe_for_subtree; ++ tid) {
            unode_status[heap_1[0].id] = tid - 64;
            ++nsubtree_per_cpe[tid];
            heap_2[cpe_for_subtree - 1 - tid].id = tid;
            heap_2[cpe_for_subtree - 1 - tid].weight = heap_1[0].weight;
            auto tmp = heap_1[--heap_size];
            heap_1[heap_size] = heap_1[0];
            heap_1[0] = tmp;
            adjust_heap_max_down(0, heap_size, heap_1, get_weight);
        }
        // heap_2 already sorted
        // init_heap_min(cpe_for_subtree, heap_2, get_weight);
        while(heap_size > 0) {
            Int tid = heap_2[0].id;
            unode_status[heap_1[0].id] = tid - 64;
            ++nsubtree_per_cpe[tid];
            heap_2[0].weight += heap_1[0].weight;
            auto tmp = heap_1[--heap_size];
            heap_1[heap_size] = heap_1[0];
            heap_1[0] = tmp;
            adjust_heap_max_down(0, heap_size, heap_1, get_weight);
            adjust_heap_min_down(0, cpe_for_subtree, heap_2, get_weight);
        }
        // here heap_1 is sorted

        usubtrees = (trf_subtree_t*)swSparse_malloc(sizeof(trf_subtree_t) * nsubtree);
        IF_ERR(usubtrees == nullptr) {
            return clean_return(MALLOC_ERROR, usubtree_weight, usubtree_offsets); 
        }

        // schedule subtrees
        Int temp = 0;
        for(Int i = 0; i < cpe_for_subtree; ++i) {
            temp += nsubtree_per_cpe[i];
            usubtree_offsets[i] = temp;
        }
        usubtree_offsets[cpe_for_subtree] = temp;
        nsuper_subtree = 0;
        for(Int i = 0; i < nsubtree; ++i) {
            Int root = heap_1[i].id;
            Int status = unode_status[root];
            Int tid = status + 64;
            Int pos = --(usubtree_offsets[tid]);
            Int end = root + 1;
            Int begin = root;
            usubtrees[pos].sup_end = end;
            while(first_child[begin] != etree_empty) {
                begin = first_child[begin];
            }
            usubtrees[pos].sup_begin = begin;
            usubtrees[pos].parent_task = 0;
            nsuper_subtree += end - begin;
            for(Int j = begin; j < end; ++j) {
                unode_status[j] = status;
            }
        }
    }
    Int nsuper_queue = nsuper - nsuper_subtree;

    // extremely rare: matrix is balanced reducible, no need to sort subtrees
    if(UNLIKELY(nsuper_queue == 0)) {  
        args->unode_status = unode_status;
        args->usubtrees = usubtrees;
        args->usubtree_offsets = usubtree_offsets;
        args->utasks = nullptr;
        args->utask_offsets = utask_offsets;
        args->utask_queue = nullptr;

        swSparse_free(usubtree_weight);
        return SWSPARSE_SUCCESS;
    } else {
        Int q_head, q_tail, q_level;

        // 根据 sup_begin 排序子树
        sort_subtrees_arg_t sort_subtree_args;
        if(LIKELY(nsubtree < cpe_for_subtree * 8)) {
            sort_subtree_args.temp = nullptr;
            sort_subtree_host(usubtree_offsets, usubtrees);
        } else {
            // so many subtrees that need CPE to sort
            sort_subtree_args.temp = (trf_subtree_t*)swSparse_malloc_raw(sizeof(trf_subtree_t) * nsubtree);
            sort_subtree_args.subtrees = usubtrees;
            sort_subtree_args.subtree_offsets = usubtree_offsets;
            athread_spawn_sort_subtrees_kernel(&sort_subtree_args);
            athread_join_sort_subtrees(sort_subtree_args);
            swSparse_free(sort_subtree_args.temp);
        }
    
        auto result_queue = (trf_task_t*)swSparse_malloc(sizeof(trf_task_t) * nsuper_queue);
        IF_ERR(result_queue == nullptr) {
            fprintf(stderr, "result_queue_malloc_err\n");
            return clean_return(MALLOC_ERROR, usubtree_weight, usubtree_offsets, usubtrees);
        }

        auto utask_queue = (lutrsv_task_t*)swSparse_malloc(sizeof(lutrsv_task_t) * nsuper_queue);
        IF_ERR(utask_queue == nullptr) {
            fprintf(stderr, "task_queue_malloc_err\n");
            return clean_return(MALLOC_ERROR, usubtree_weight, usubtree_offsets, usubtrees, result_queue); 
        }

        // enqueue supernodes in level-set order
        q_head = nsuper_queue - 1;
        q_tail = q_head;
        queue_scheduler sched(next_sibling, uweight, unode_status, result_queue);

        q_tail = sched.enqueue(nsuper, first_child[nsuper], q_tail);
        sched.set_level_info(q_head, q_tail);
        q_level = 1;
        while(q_head != q_tail) {
            Int begin = q_head, end = q_tail;
            q_head = q_tail;
            for(Int queue_id = begin; queue_id > end; --queue_id) {
                q_tail = sched.enqueue(queue_id, first_child[result_queue[queue_id].sup_id], q_tail);
            }
            sched.set_level_info(q_head, q_tail);
            q_level += 1;
        }
        ASSERT_EQUAL(q_head, -1);
        ASSERT_EQUAL(q_tail, -1);

        // 记录子树部分各个核心的权重
        weight_t subtrees_weight_per_core[cpe_for_subtree];
        for(Int i = 0; i < cpe_for_subtree; ++i) {
            subtrees_weight_per_core[heap_2[i].id] = heap_2[i].weight;
        }
        
        /* 调度 task_queue */
        Int q, req, part_size, shift;
        weight_t sync_weight = 123.456789f;
        for(Int i = nsuper_queue - 1; i >= 0; --i) {
            // 确定使用的核数
            Int sup_id = result_queue[i].sup_id;
            utask_queue[i].sup_id = sup_id;
            utask_queue[i].queue_id = i;
            shift = block_cycle_shift;
            utask_queue[i].stride = (1 << shift);

            q = result_queue[i].level_id;
            req = ceiling_sra(lu->sup2col[sup_id + 1] - lu->sup2col[sup_id], shift);
            if(req <= q) {
                utask_queue[i].group.npart = req;

                Int si = lu->l_i_offsets[sup_id + 1] - lu->l_i_offsets[sup_id];
                part_size = std::min(q / req, si / (1 << shift));
                part_size = std::max(part_size, 1);

                utask_queue[i].group.size = part_size * req;
            } else {
                utask_queue[i].group.npart = q;
                utask_queue[i].group.size = q;
            }

            // 确定使用的核心
            heap_size = 64;
            weight_heap_t tmp;
            weight_t max_tasks_weight = -1;
            Int j;
            for(j = 0; j < utask_queue[i].group.size; ++j) {
                Int tid = heap_2[0].id;
                utask_queue[i].group.partner[j] = tid;
                ++untask_per_cpe[tid];
                --heap_size;
                tmp = heap_2[0];
                // 找到使用核心的最大的任务负载
                max_tasks_weight = std::max(max_tasks_weight, tmp.weight - subtrees_weight_per_core[tid]);
                heap_2[0] = heap_2[heap_size];
                heap_2[heap_size] = tmp;
                adjust_heap_min_down(0, heap_size, heap_2, get_weight);
            }
            // 更新最大任务负载
            max_tasks_weight += (uweight[sup_id] / utask_queue[i].group.size) + req * sync_weight;;
            for(; j > 0; --j) {
                // 由于同步，使用核心的任务负载全部更新为最大任务负载
                heap_2[heap_size].weight = subtrees_weight_per_core[heap_2[heap_size].id] + max_tasks_weight;
                adjust_heap_min_up(heap_size, heap_2, get_weight);
                ++heap_size;
            }
        }

        swSparse_free(result_queue);

        Int temp = 0;
        for(Int i = 0; i < cpe_for_subtree; ++i) {
            utask_offsets[i] = temp;
            temp += untask_per_cpe[i];
        }

        auto utasks = (lutrsv_task_t*)swSparse_malloc(sizeof(lutrsv_task_t) * temp);
        IF_ERR(utasks == nullptr) {
            return clean_return(MALLOC_ERROR, usubtree_weight, usubtree_offsets, usubtrees, result_queue, utask_queue); 
        }
        for(Int i = 0; i < nsuper_queue; ++i) {
            for(Int j = 0; j < utask_queue[i].group.size; ++j) {
                Int& offset = utask_offsets[utask_queue[i].group.partner[j]];
                utasks[offset] = utask_queue[i];
                utasks[offset].group.id = j;
                ++offset;
            }
        }

        for(Int i = cpe_for_subtree; i > 0; --i) {
            utask_offsets[i] = utask_offsets[i - 1];
        }
        utask_offsets[0] = 0;

        for(Int i = 0; i < utask_offsets[1]; ++i) {
            if(utasks[i].stride > 16) {
                printf("offset: %d, stride: %d\n", i, utask_offsets[i]);
                exit(1);
            }
        }

        args->unode_status = unode_status;
        args->usubtrees = usubtrees;
        args->usubtree_offsets = usubtree_offsets;
        args->utasks = utasks;
        args->utask_offsets = utask_offsets;
        args->utask_queue = utask_queue;

        swSparse_free(usubtree_weight);
        return SWSPARSE_SUCCESS;
    }
}

ErrorStatus lutrsv_static_schedule(LUSup* lu, lutrsv_static_schedule_arg_t* args) {
    Int nsuper = lu->nsuper;
    // 估计 L 和 U 各个超节点的权重
    weight_t *lnode_weight = (weight_t*)swSparse_malloc(sizeof(weight_t) * (nsuper * 2 + 2));
    weight_t *unode_weight = lnode_weight + nsuper + 1;
    IF_ERR(lnode_weight == nullptr) {
        return MALLOC_ERROR; 
    }
    static_estimate(nsuper, lnode_weight, unode_weight, lu);

    // 计算 first_child and sibllings，next_sibling 顺序为从左到右
    const Int *sup_parent = lu->sup_etree_parent;
    Int* first_child = (Int*)swSparse_malloc(sizeof(Int) * (nsuper * 2 + 2));
    Int* next_sibling = first_child + nsuper + 1;
    IF_ERR(first_child == nullptr) {
        return clean_return(MALLOC_ERROR, lnode_weight); 
    }
    args->first_child = first_child;
    args->next_sibling = next_sibling;
    for(Int isup = 0; isup <= nsuper; ++isup) {
        first_child[isup] = next_sibling[isup] = etree_empty;
    }
    for(Int isup = nsuper - 1; isup >= 0; --isup) { 
        Int p = sup_parent[isup], f = first_child[p];
        next_sibling[isup] = f;
        first_child[p] = isup;
    }

    // 调度 L
    auto ret = lutrsv_lstatic_schedule(args, lu, lnode_weight);
    IF_ERR(ret != SWSPARSE_SUCCESS) {
        return ret;
    }

    // 调度 U
    ret = lutrsv_ustatic_schedule(args, lu, unode_weight);
    IF_ERR(ret != SWSPARSE_SUCCESS) {
        return ret;
    }

    swSparse_free(lnode_weight);

    return SWSPARSE_SUCCESS;
}

void lutrsv_destroy_static_schedule_arg(lutrsv_static_schedule_arg_t* schedule_args) {
    swSparse_free(schedule_args->first_child);
    swSparse_free(schedule_args->lsubtree_offsets);
    swSparse_free(schedule_args->lsubtrees);
    swSparse_free(schedule_args->ltasks);
    swSparse_free(schedule_args->ltask_queue);
    swSparse_free(schedule_args->usubtree_offsets);
    swSparse_free(schedule_args->usubtrees);
    swSparse_free(schedule_args->utasks);
    swSparse_free(schedule_args->utask_queue);
}

}