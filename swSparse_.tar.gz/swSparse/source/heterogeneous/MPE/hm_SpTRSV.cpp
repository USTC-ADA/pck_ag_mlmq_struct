#include <algorithm>
#include <vector>
#include "internal/crts.hpp"
#include "swSparse_blas.h"
#include "internal/rename.h"
#include "internal/spblas_common.h"
#include "internal/templates.h"
#include "internal/memory.h"
#include "internal/debug.h"
#include "internal/utils.h"
#include "internal/reorder.h"
#include "internal/dependency.h"
#include "internal/SpTRSV.h"

//#define SLT_DEBUG
//#define SWAPS_TEST

ATHREAD_SPAWN_TEMPLATE_ARGTYPE(trsv_kernel, trsv_arg_t)

namespace swSparse  {

//TODO:auto tune
//load_balance
//matrix scale
template<typename DATA_T>
static ErrorStatus trsv_auto_tune_args_csc(trsv_tune_t *tune, Int *column_offsets, Int n, Int nnz, Int levels) {
	tune->cache_x_log2		= 12;
	//the number of cpe
	if(nnz / levels < 600) {
		tune->couples_log2	= 5;
	} else {
		tune->couples_log2	= 5;
	}
	//the width of super-node
	if(n / levels < 3) {
		tune->vector_log2	= 2;
	} else {
		tune->vector_log2	= 0;
	}
    //the range of communication
	std::vector<Int> max_nnzs(n);
	for(Int i = 0; i < n; i++) {
		max_nnzs[i] = column_offsets[i+1] - column_offsets[i];
	}
	std::sort(max_nnzs.begin(), max_nnzs.end());
	Int top_sum = 0;
	for(Int i = n-1; i > n-n/10; i--) {
		top_sum += max_nnzs[i];
	}
	double rate = (double)top_sum / (double)nnz * 100;
	if(rate > 50) {
		tune->comm_part_log2 = 2;
	} else {
		tune->comm_part_log2 = 1;
	}

//	printf("top_sum = %d, percent = %.2f%%\n", top_sum, rate);

	return SWSPARSE_SUCCESS;
}

template<>
ErrorStatus trsv_auto_tune_args_csc<SComplex>(trsv_tune_t *tune, Int *column_offsets, Int n, Int nnz, Int levels) {
	tune->couples_log2				= 5;
	tune->vector_log2				= 1;
	tune->cache_x_log2				= 10;
	tune->comm_part_log2			= 1;
	return SWSPARSE_SUCCESS;
}

template<>
ErrorStatus trsv_auto_tune_args_csc<DComplex>(trsv_tune_t *tune, Int *column_offsets, Int n, Int nnz, Int levels) {
	tune->couples_log2				= 5;
	tune->vector_log2				= 1;
	tune->cache_x_log2				= 9;
	tune->comm_part_log2			= 1;
	return SWSPARSE_SUCCESS;
}

template<typename DATA_T>
static ErrorStatus create_lower_slt_from_csc(Matrix *slt, Int n, Int *column_offsets, Int *row_indices, \
		DATA_T *values, const swSparseTRSVOptions* options, Int *perm, Int *iperm, Int max_level) {

	Int vector,      vector_log2,      vector_2num;
	Int couples,     couples_log2,     couples_2num;
	Int big_block,   big_block_log2,   big_block_2num;
	Int big_block_v, big_block_v_log2, big_block_v_2num;
	Int cache_x,     cache_x_log2;

    Matrix created        	= (Matrix) swSparse_malloc(sizeof(MatrixData));
	created->matrix.sltcoo  = (swSparseMatrixSLTCOO*) swSparse_malloc(sizeof(swSparseMatrixSLTCOO));
    if(created == NULL)
        return SWSPARSE_MALLOC_ERROR; 
    *slt                  	= created;
    created->format_type 	= SLTCOO;
	created->element_type	= type_traits<DATA_T>::element_type;
    created->m 				= created->n   = n; 
    Int nnz 				= created->nnz = column_offsets[n];

	trsv_tune_t *tune = (trsv_tune_t *) swSparse_malloc(sizeof(trsv_tune_t));
	trsv_auto_tune_args_csc<DATA_T>(tune, column_offsets, n, nnz, max_level);
	created->matrix.sltcoo->trsv_tune = (void *) tune;

	vector_log2      = tune->vector_log2;      
	couples_log2     = tune->couples_log2;     
	cache_x_log2     = tune->cache_x_log2;     
	big_block_log2   = cache_x_log2 + couples_log2; 
	big_block_v_log2 = big_block_log2 - vector_log2;
	vector  	     = 1 << vector_log2; 
	couples 	     = 1 << couples_log2;
	cache_x          = 1 << cache_x_log2;
	big_block        = 1 << big_block_log2;
	big_block_v      = 1 << big_block_v_log2;
	vector_2num      = vector      - 1;
	couples_2num     = couples     - 1;
	big_block_2num   = big_block   - 1;
	big_block_v_2num = big_block_v - 1;

	Int part_width,	 part_width_log2,  part_width_2num;
	Int core_cols,	 core_cols_log2,   core_cols_2num;
	Int comm_part,   comm_part_log2,   comm_part_2num;

	comm_part_log2	 = couples  > 4 ? tune->comm_part_log2              : 0;
	comm_part_log2	 = couples == 1 ? 0                   				: comm_part_log2;
	part_width_log2  = couples  > 4 ? (CORE_COLS_LOG2 - comm_part_log2) : couples_log2-comm_part_log2;
	core_cols_log2   = couples  > 4 ?  CORE_COLS_LOG2                   : couples_log2;
	comm_part		 = 1 << comm_part_log2; 
	part_width 		 = 1 << part_width_log2;
	core_cols		 = 1 << core_cols_log2;
	comm_part_2num   = comm_part    - 1;
	part_width_2num  = part_width   - 1;
	core_cols_2num	 = core_cols    - 1;
	
	Int diag_block_part = comm_part+1;

#ifdef SLT_DEBUG
//	for(Int i = 0; i < n; i++)
//		printf("iperm[%d] = %d\n", i, iperm[i]);
	printf("vector      = %4d, vector_log2      = %4d, vector_2num      = %4d\n", vector,      vector_log2,      vector_2num);
	printf("couples     = %4d, couples_log2     = %4d, couples_2num     = %4d\n", couples,     couples_log2,     couples_2num);
	printf("cache_x     = %4d, cache_x_log2     = %4d\n",                         cache_x,     cache_x_log2);
	printf("big_block   = %4d, big_block_log2   = %4d, big_block_2num   = %4d\n", big_block,   big_block_log2,   big_block_2num);
	printf("big_block_v = %4d, big_block_v_log2 = %4d, big_block_v_2num = %4d\n", big_block_v, big_block_v_log2, big_block_v_2num);
	printf("comm_part   = %4d, part_width       = %4d, core_cols        = %4d\n", comm_part,   part_width,       core_cols);
#endif
	
    Int n_vec 				= (n+vector_2num) >> vector_log2; 
    Int add_n				= (n_vec << vector_log2) - n;
    if((options->diagnal & SWSPARSE_UNIT_DIAG) != 0)
        nnz += n;

	created->status			= options->diagnal; 
	created->matrix.sltcoo->n_vec          = n_vec;
    created->matrix.sltcoo->row_indices    = (Int *)   swSparse_malloc((nnz+add_n) * sizeof(Int)); 
    created->matrix.sltcoo->column_indices = (Int *)   swSparse_malloc((nnz+add_n) * sizeof(Int)); 
    created->matrix.sltcoo->values         = (DATA_T *)swSparse_malloc((nnz+add_n) * sizeof(DATA_T)); 
    if(created->matrix.sltcoo->column_indices == NULL || created->matrix.sltcoo->row_indices == NULL 
			|| created->matrix.sltcoo->values == NULL ) {
        swSparse_destroy(created);
        return SWSPARSE_MALLOC_ERROR; 
    }

	Int bn = ((n_vec << vector_log2) + big_block_2num) >> big_block_log2;
	Int sp_id;
	//Re-Reorder
	{
		Int pn = n_vec >> couples_log2;
		Int dn = n_vec &  couples_2num;
		sp_id  = (dn + couples_2num) & couples_2num;
		for(Int k = 0; k < n; k++) {
			Int i = iperm[k];
			Int id = (i >> vector_log2) & couples_2num;
			Int offset = id * pn + (id < dn ? id : dn) + (i >> (vector_log2 + couples_log2));
			Int j = offset * vector + (i & vector_2num);
			if(id > sp_id)
				j -= add_n;
			iperm[k] = j;
			perm[j] = k;
		}
	}
    
	//tmp : compute the level of vector columns
    Int *tmp = (Int *)swSparse_malloc(n_vec*sizeof(Int));
    if(tmp == NULL) {
        swSparse_destroy(created);
        return SWSPARSE_MALLOC_ERROR; 
    }
    for(Int i = 0; i < n_vec; i++) 
		tmp[i] = 0;
    for(Int i = 0; i < n; i++)
		for(Int j = column_offsets[i]; j < column_offsets[i+1]; j++)
			if(row_indices[j] < n) {
				if((i >> vector_log2) != (row_indices[j] >> vector_log2)) {
					Int level = tmp[i >> vector_log2] + 1;
					if(level > tmp[row_indices[j] >> vector_log2]) 
						tmp[row_indices[j] >> vector_log2] = level;
				}
			}
    //count BN levels
	Int levels = 0;
	{
		Int c = tmp[0];
		Int t = 1;
		for(Int i = 1; i < n_vec; i++) {
			if(tmp[i] != c) {
				levels++;
				t = 0;
			} else if(t == big_block_v) { //TODO:is neccesary?
				levels++;
				t = 0;
			} else if((i%big_block_v) == 0) {
				levels ++;
				t = 0;
			}
			c = tmp[i];
			t ++;
		}
		if(t > 0) {
			levels ++;
		}
	}

	created->matrix.sltcoo->levels = levels;
	created->matrix.sltcoo->level  = (Int *)swSparse_malloc(levels*sizeof(Int));
	if(created->matrix.sltcoo->level == NULL) {
		swSparse_destroy(created);
		swSparse_free(tmp);
		return SWSPARSE_MALLOC_ERROR; 
	}
    
	//Set created->matrix.sltcoo.level:the number of vector columns of each BN level
	{
		levels = 0;
		Int c = tmp[0];
		Int t = 1;
		for(Int i = 1; i < n_vec; i++) {
			if(tmp[i] != c) {
				created->matrix.sltcoo->level[levels++] = t;
				t = 0;
			} else if(t == big_block_v) {
				created->matrix.sltcoo->level[levels++] = t;
				t = 0;
			} else if((i % big_block_v) == 0) {
				created->matrix.sltcoo->level[levels++] = t;
				t = 0;
			}
			c = tmp[i];
			t ++;
		}
		if(t > 0) {
			created->matrix.sltcoo->level[levels++] = t;
		}
	}

    created->matrix.sltcoo->_cnt = (Int *)swSparse_malloc(couples*levels*MAX_PRODUCERS*sizeof(Int));
    if(created->matrix.sltcoo->_cnt == NULL) {
        swSparse_destroy(created);
        swSparse_free(tmp);
        return SWSPARSE_MALLOC_ERROR; 
    }
    for(Int i = 0; i < couples; i++) {
			created->matrix.sltcoo->cnt[i]= created->matrix.sltcoo->_cnt + i*levels*MAX_PRODUCERS;
			for(Int j = 0; j < levels*MAX_PRODUCERS; j++) 
				created->matrix.sltcoo->cnt[i][j] = 0;
    }
	//
    Int *len0 = (Int *)swSparse_malloc(		   bn*bn*sizeof(Int));  //non_diag nnz of each  big_block
    Int *len1 = (Int *)swSparse_malloc(couples*bn*bn*comm_part*sizeof(Int));  //non_diag nnz of producers in each big_block
	Int *len2 = (Int *)swSparse_malloc(couples*levels*diag_block_part*sizeof(Int));
    Int *len3 = (Int *)swSparse_malloc(couples*couples*bn*bn*sizeof(Int));  //non_diag: times of consumer updating b in each big_block from every producer
//    Int *len4 = (Int *)swSparse_malloc(couples*levels*MAX_PRODUCERS*sizeof(Int));  //diag bottom part: times of consumer updating b in each big_block from every producer
    if(len0 == NULL || len1 == NULL || len2 == NULL || len3 == NULL) {
        swSparse_destroy(created);
        free_all(tmp, len0, len1, len2, len3);
        return SWSPARSE_MALLOC_ERROR; 
    }
    for(Int i = 0; i <         bn*bn;    i++) len0[i] = 0;
    for(Int i = 0; i < couples*bn*bn*comm_part; i++) len1[i] = 0;
    for(Int i = 0; i < couples*levels*diag_block_part; i++) len2[i] = 0;
    for(Int i = 0; i < couples*couples*bn*bn;    	   i++) len3[i] = 0;
    //set len0 1 2 3
	for(Int begin = 0, l = 0; l < levels; l++) {
		Int nn = created->matrix.sltcoo->level[l];  /* number of vector-columns in a level */
		Int offset = (begin+nn)*vector;
		for(Int i = 0; i < nn; i++) { /* for each vector-column in the level */
			Int pid = (i+begin)&couples_2num;    // the producer id of computing the 4-column
			Int id0 = (pid&core_cols_2num)>>part_width_log2;// the producer comm_part id
			for(Int j = (i+begin)*vector; j < (i+1+begin)*vector; j++) { //for each column 
				//the last row of the last level need special solution.
				if(j < n) {
					if(options->diagnal & SWSPARSE_UNIT_DIAG) {
						//TODO: UNIT_DIAG
						len2[pid*levels*diag_block_part + l*diag_block_part + 0]++;
					}
					for(Int k = column_offsets[j]; k < column_offsets[j+1]; k++) { //for each nonzero in the column
						//nonzero (aj, j)
						Int aj = row_indices[k]; 
						if(aj < n) {
							if(aj-offset >= big_block) { // is non-diagnal block
								len0[(aj>>big_block_log2)*bn+(j>>big_block_log2)]++;// the number of non-diagonal-block nnz in every BIG_BLOCK
								/* len1[pid][aj>>BIG_BLOCK_LOG2][j>>BIG_BLOCK_LOG2][_level] */
								//the owner_id (producer) of A(aj, j)
								//row BIG_BLOCK id
								//col BIG_BLOCK id
								Int cid	   = (aj>>vector_log2)&couples_2num;  //the consumer id "b(aj) -= A(aj,j) * x(j)"
								Int id1    = (cid&core_cols_2num)>>part_width_log2;// the consumer comm_part id
								Int _level = (id1-id0+comm_part)&comm_part_2num; //distance between comm_parts
								Int owner  = ((pid>>core_cols_log2)<<core_cols_log2)+((pid+_level*part_width)&core_cols_2num);//the pid of the nz's owner
								len1[owner*bn*bn*comm_part + (aj>>big_block_log2)*bn*comm_part + (j>>big_block_log2)*comm_part + _level]++;
								/* len3[(aj>>VECTOR_LOG2)&CONSUMERS_2NUM][pid][aj>>BIG_BLOCK_LOG2][j>>BIG_BLOCK_LOG2] */
								len3[((aj>>vector_log2)&couples_2num)*couples*bn*bn + owner*bn*bn + (aj>>big_block_log2)*bn + (j>>big_block_log2)]++;
							} else if(aj < (i+1+begin)*vector) { /* the nnz in the top-part of the diagonal-block, including diagonal element and non-diagonal element */
								/* len2[pid][l][0]*/
								len2[pid*levels*diag_block_part + l*diag_block_part + 0]++;
							} else { /* the nnz in the bottom-part of the diagnal block */
								
								Int cid	   = (aj>>vector_log2)&couples_2num;  //the consumer id "b(aj) -= A(aj,j) * x(j)"
								Int id1    = (cid&core_cols_2num)>>part_width_log2;// the consumer comm_part id
								Int _level = (id1-id0+comm_part)&comm_part_2num; //distance between comm_parts
								Int owner  = ((pid>>core_cols_log2)<<core_cols_log2)+((pid+_level*part_width)&core_cols_2num);//the pid of the nz's owner
								len2[owner*levels*diag_block_part + l*diag_block_part + _level+1]++;

								created->matrix.sltcoo->cnt[(aj>>vector_log2)&couples_2num][l*MAX_PRODUCERS+owner]++;
							}
						}
					}
				} else if(j >= n && j < n+add_n) {
					//TODO: UNIT_DIAG
					len2[pid*levels*diag_block_part + l*diag_block_part + 0]++;
				}
			}
		}
		begin += nn;
    }

	created->matrix.sltcoo->plevels = levels;
	for(Int i = 0; i < bn*bn; i++) 
		if(len0[i] > 0) 
			created->matrix.sltcoo->plevels++;   //plevels: the number of all blocks, including diagonal and non-diagnonal blocks
	created->matrix.sltcoo->plevel = (Int *)swSparse_malloc(created->matrix.sltcoo->plevels*sizeof(Int));
	if(created->matrix.sltcoo->plevel == NULL) {
		swSparse_destroy(created);
		free_all(tmp, len0, len1, len2, len3);
		return SWSPARSE_MALLOC_ERROR; 
	}
    //Set created->matrix.sltcoo.plevel
	//diag_block: the number of vector_col
	//non_diag_block: minus col_id of big_block
	{
		Int *plevel = created->matrix.sltcoo->plevel;
		Int begin = 0;
		for(Int l = 0; l < levels; l++) {
			Int nn = created->matrix.sltcoo->level[l];
			*plevel++ = nn;
			begin += nn;
			if((begin&big_block_v_2num) == 0 && l < (levels-1)) {
				Int *ll = len0 + (begin>>big_block_v_log2)*bn;
				for(Int i = 0; i < bn; i++)
					if(ll[i] > 0) *plevel++ = -i;
			}
		}
	}

    Int plevels = created->matrix.sltcoo->plevels;
    created->matrix.sltcoo->_idx = (Int *)swSparse_malloc((couples*plevels*diag_block_part+1)*sizeof(Int)); //created->matrix.sltcoo._idx[32][plevels][2]
    if(created->matrix.sltcoo->_idx == NULL) {
        swSparse_destroy(created);
        free_all(tmp, len0, len1, len2, len3);
        return SWSPARSE_MALLOC_ERROR; 
    }
    for(Int i = 0; i < couples; i++) 
		created->matrix.sltcoo->idx[i]  = created->matrix.sltcoo->_idx + i*plevels*diag_block_part;
    for(Int i = 0; i <= couples*plevels*diag_block_part; i++)
		created->matrix.sltcoo->_idx[i] = 0;
    
    /* nondiagonal */
    Int    **ai1 = (Int **)   swSparse_malloc(couples*bn*bn*comm_part*sizeof(Int*));     //[32][bn][bn]
    Int    **aj1 = (Int **)   swSparse_malloc(couples*bn*bn*comm_part*sizeof(Int*));     //[32][bn][bn]
    DATA_T **aa1 = (DATA_T **)swSparse_malloc(couples*bn*bn*comm_part*sizeof(DATA_T*));  //[32][bn][bn]
    /* diagonal */
    Int    **ai2 = (Int **)   swSparse_malloc(couples*levels*diag_block_part*sizeof(Int*));    //[32][levels][2]
    Int    **aj2 = (Int **)   swSparse_malloc(couples*levels*diag_block_part*sizeof(Int*));    //[32][levels][2]
    DATA_T **aa2 = (DATA_T **)swSparse_malloc(couples*levels*diag_block_part*sizeof(DATA_T*)); //[32][levels][2]
    if(ai1 == NULL || aj1 == NULL || aa1 == NULL || ai2 == NULL || aj2 == NULL || aa2 == NULL) {
        swSparse_destroy(created);
        free_all(tmp, len0, len1, len2, len3, ai1, aj1, aa1, ai2, aj2, aa2);
        return SWSPARSE_MALLOC_ERROR; 
    }
    //Set ai1, aj1, aai, ai2, aj2, aa2 and idx
	{
		Int    *_idx = created->matrix.sltcoo->_idx + 1;
		Int    *_ai  = created->matrix.sltcoo->column_indices;
		Int    *_aj  = created->matrix.sltcoo->row_indices;
		DATA_T *_aa  = (DATA_T *)created->matrix.sltcoo->values;
		Int pl_idx = 0;
		for(Int i = 0; i < couples; i++) {
			Int begin = 0;
			for(Int l = 0; l < levels; l++) {
				Int nn = created->matrix.sltcoo->level[l];
				for(Int j = 0; j < diag_block_part; j++) { //diagnal-block
					/* set a2[i][l][j], jump _a by len2[i][l][j] */
					ai2[i*levels*diag_block_part+l*diag_block_part+j] = _ai; _ai += len2[i*levels*diag_block_part+l*diag_block_part+j];
					aj2[i*levels*diag_block_part+l*diag_block_part+j] = _aj; _aj += len2[i*levels*diag_block_part+l*diag_block_part+j];
					aa2[i*levels*diag_block_part+l*diag_block_part+j] = _aa; _aa += len2[i*levels*diag_block_part+l*diag_block_part+j];

					/* add len2[i][l][j] to _idx */
					*_idx++ = len2[i*levels*diag_block_part+l*diag_block_part+j];
				}
				begin += nn;
				if((begin&big_block_v_2num) == 0 && l < (levels-1)) { //non-diagonal-block
					Int ii = begin >> big_block_v_log2; //current big_block
					for(Int k = 0; k < bn; k++) {
						for(Int j = 0; j < comm_part; j++) {
							/* set a1[i][ii][k], jump _a by len1[i][ii][k]*/
							ai1[i*bn*bn*comm_part + ii*bn*comm_part + k*comm_part + j] = _ai; _ai += len1[i*bn*bn*comm_part + ii*bn*comm_part + k*comm_part + j];
							aj1[i*bn*bn*comm_part + ii*bn*comm_part + k*comm_part + j] = _aj; _aj += len1[i*bn*bn*comm_part + ii*bn*comm_part + k*comm_part + j];
							aa1[i*bn*bn*comm_part + ii*bn*comm_part + k*comm_part + j] = _aa; _aa += len1[i*bn*bn*comm_part + ii*bn*comm_part + k*comm_part + j];
						}
						if(len0[ii*bn+k] > 0)
						{
							*_idx++ = 0; // why current is 0? diagonal-block = top and bottom; non-diagonal: only bottom
							for(Int j = 0; j < comm_part; j++)
								*_idx++ = len1[i*bn*bn*comm_part + ii*bn*comm_part + k*comm_part + j];

							for(Int p = 0; p < couples; p++) {
								created->matrix.sltcoo->cnt[i][l*MAX_PRODUCERS+p] += len3[i*couples*bn*bn+ p*bn*bn + ii*bn + k];
//								*_cnt++ = len3[i*MAX_PRODUCERS*bn*bn + p*bn*bn + ii*bn + k];
							}
						}
					}
				}
			}
		}
		for(Int i = 0; i < couples*diag_block_part*plevels; i++) 
			created->matrix.sltcoo->_idx[i+1] += created->matrix.sltcoo->_idx[i];
	}

	for(Int begin = 0, l = 0; l < levels; l++) {
		Int nn = created->matrix.sltcoo->level[l];
		Int base   = (begin+nn) << vector_log2; //TODO: base = offset?
		Int offset = (begin+nn) << vector_log2;
		for(Int i = 0; i < nn; i++) {
			Int pid = (i+begin)&couples_2num;
			Int id0 = (pid&core_cols_2num)>>part_width_log2;// the producer comm_part id
			for(Int j = (i+begin)*vector; j < (i+1+begin)*vector; j++) {
				if(j < n) {
					if(options->diagnal & SWSPARSE_UNIT_DIAG) {
						//TODO UNIT_DIAG
						Int    ai = j;
						Int    aj = j;
						DATA_T aa = DATA_T(1);
						Int aai = ((((ai>>vector_log2)-begin)>>couples_log2)<<vector_log2)+(ai&vector_2num);
						Int aaj = ((((aj>>vector_log2)-begin)>>couples_log2)<<vector_log2)+(aj&vector_2num);
						*aj2[pid * levels * diag_block_part+l * diag_block_part + 0]++ = aaj + (aai<<big_block_log2);
						*ai2[pid * levels * diag_block_part+l * diag_block_part + 0]++ = ai;
						*aa2[pid * levels * diag_block_part+l * diag_block_part + 0]++ = aa;
					}
					for(Int k = column_offsets[j]; k < column_offsets[j+1]; k++) {
						//a new nonzero element ai, aj, aa: (aj, ai) = aa
						Int    ai = j;
						Int    aj = row_indices[k];
						DATA_T aa = values[k];
						if(aj < n) {
							if((aj-offset) >= big_block) { //non_diagnal block
								Int cid	   = (aj>>vector_log2)&couples_2num;  //the consumer id "b(aj) -= A(aj,j) * x(j)"
								Int id1    = (cid&core_cols_2num)>>part_width_log2;// the consumer comm_part id
								Int _level = (id1-id0+comm_part)&comm_part_2num; //distance between comm_parts
								Int owner  = ((pid>>core_cols_log2)<<core_cols_log2)+((pid+_level*part_width)&core_cols_2num);//the pid of the nz's owner
								//aai: in the current big_block, the in-producer-column_indices of the nonzero
								Int aai    = (((ai&big_block_2num)>>(couples_log2+vector_log2))<<vector_log2)+(ai&vector_2num);
								Int aaj    =    aj&big_block_2num; //aaj: int the current big_block, the big_block-row_indices of the nonzero
								*aj1[owner*bn*bn*comm_part + (aj>>big_block_log2)*bn*comm_part + (j>>big_block_log2)*comm_part + _level]++ = aaj + (aai<<big_block_log2) + (_level<<(big_block_log2+cache_x_log2));; // one var including three inner-indices
								*ai1[owner*bn*bn*comm_part + (aj>>big_block_log2)*bn*comm_part + (j>>big_block_log2)*comm_part + _level]++ = ai; //the real column_indices
								*aa1[owner*bn*bn*comm_part + (aj>>big_block_log2)*bn*comm_part + (j>>big_block_log2)*comm_part + _level]++ = aa;
							} else if(aj < (i+1+begin)*vector) { //diagnal block top part
								//aai: in the current level, the producer-column-indices of the nonzero
								Int aai = ((((ai>>vector_log2)-begin)>>couples_log2)<<vector_log2)+(ai&vector_2num);
								//aaj: in the current level, the producer-row-indices of the nonzero
								Int aaj = ((((aj>>vector_log2)-begin)>>couples_log2)<<vector_log2)+(aj&vector_2num);
								*aj2[pid*levels*diag_block_part + l*diag_block_part + 0]++ = aaj + (aai<<big_block_log2); // one var including tow inner-indices
								*ai2[pid*levels*diag_block_part + l*diag_block_part + 0]++ = ai;
								*aa2[pid*levels*diag_block_part + l*diag_block_part + 0]++ = aa;
							} else { //diagnal block bottom part
								Int cid	   = (aj>>vector_log2)&couples_2num;  //the consumer id "b(aj) -= A(aj,j) * x(j)"
								Int id1    = (cid&core_cols_2num)>>part_width_log2;// the consumer comm_part id
								Int _level = (id1-id0+comm_part)&comm_part_2num; //distance between comm_parts
								Int owner  = ((pid>>core_cols_log2)<<core_cols_log2)+((pid+_level*part_width)&core_cols_2num);//the pid of the nz's owner
								//aai: in the current level, the producer-column-indices of the nonzero
								Int aai = ((((ai>>vector_log2)-begin)>>couples_log2)<<vector_log2)+(ai&vector_2num);
								Int aaj = aj-base; //the bottom-row-indices

								*aj2[owner*levels*diag_block_part + l*diag_block_part + _level+1]++ = aaj + (aai<<big_block_log2) +(_level<<(big_block_log2+cache_x_log2));
								*ai2[owner*levels*diag_block_part + l*diag_block_part + _level+1]++ = ai;
								*aa2[owner*levels*diag_block_part + l*diag_block_part + _level+1]++ = aa;
							}
						}
					}
				} else if(j >= n && j < n+add_n) {
					//TODO UNIT_DIAG
					Int ai = j;
					Int aj = ai;
					DATA_T aa = DATA_T(1);
					Int aai = ((((ai>>vector_log2)-begin)>>couples_log2)<<vector_log2)+(ai&vector_2num);
					Int aaj = ((((aj>>vector_log2)-begin)>>couples_log2)<<vector_log2)+(aj&vector_2num);
					*aj2[pid*levels*diag_block_part + l*diag_block_part + 0]++ = aaj + (aai<<big_block_log2);
					*ai2[pid*levels*diag_block_part + l*diag_block_part + 0]++ = ai;
					*aa2[pid*levels*diag_block_part + l*diag_block_part + 0]++ = aa;
				}
			}
		}
		begin += nn;
	}

    free_all(tmp, len0, len1, len2, len3, ai1, aj1, aa1, ai2, aj2, aa2);

	return SWSPARSE_SUCCESS;
}

template<typename DATA_T>
static ErrorStatus trsv_inspect_csr(Matrix old_mat, Matrix *new_mat, Int *perm, Int *iperm, const swSparseTRSVOptions* options) {

	ErrorStatus ret;
	Matrix created;
	MatrixFormatType format = CSR;
	Int i, j, k;
	Int m = old_mat->m, n = old_mat->n, nnz = old_mat->nnz;
	Int* old_levels;
	Int* old_indices;
	Int* new_levels;

	const MatrixCSRC *otmp = old_mat->matrix.csrc;
//	const DATA_T *oval = (DATA_T*) otmp->values; 

	new_levels = (Int*)swSparse_malloc(sizeof(Int) * n * 3);
	old_levels = new_levels + n;
	old_indices = old_levels + n;

	create_id_perm(n, old_indices);

	if((options->transpose & SWSPARSE_NON_TRANSPOSE) == SWSPARSE_NON_TRANSPOSE && options->uplo == SWSPARSE_LOWER_TRI) {
		swSparse_level_csr_lower(n, otmp->offsets, otmp->indices, old_levels);
	} else if((options->transpose & SWSPARSE_TRANSPOSE) == SWSPARSE_TRANSPOSE     && options->uplo == SWSPARSE_UPPER_TRI) {
		format = CSC;
		swSparse_level_csc_lower(n, otmp->offsets, otmp->indices, old_levels);
	} else if((options->transpose & SWSPARSE_NON_TRANSPOSE) == SWSPARSE_NON_TRANSPOSE && options->uplo == SWSPARSE_UPPER_TRI) {
		// reverse permutation, transform UPPER to LOWER
		swSparse_level_csr_upper_reverse(n, otmp->offsets, otmp->indices, old_levels);
	} else if((options->transpose & SWSPARSE_TRANSPOSE) == SWSPARSE_TRANSPOSE     && options->uplo == SWSPARSE_LOWER_TRI) {
		format = CSC;
		swSparse_level_csc_upper_reverse(n, otmp->offsets, otmp->indices, old_levels);
	}

	//compute max_level
	Int max_level = 0;
	for(i = 0; i < n; i++) {
		max_level = max(max_level, old_levels[i]);
	}

	Int parallel = nnz / max_level;
	if(n < 500 || parallel < 50 || (parallel < 95 && n <=10000 && nnz/n <= 10)) {
		//sequential algorithm
		*new_mat = old_mat;
		old_mat->status = options->uplo | options->diagnal; // override
		swSparse_free(new_levels);
		create_id_perm(n, perm);
		swSparse_perm_invert(n, perm, iperm);

		return SWSPARSE_SUCCESS;
	}

	sort_levels(n, old_levels, old_indices, new_levels, perm);
	swSparse_free(new_levels);
	swSparse_perm_invert(n, perm, iperm);
	ret = swSparse_reorder_row_col(old_mat, &created, iperm, iperm);
	if(ret == SWSPARSE_SUCCESS) {
		*new_mat = created;
		created->status = SWSPARSE_LOWER_TRI | options->diagnal; // override
		created->format_type = format;
	}
	//TODO:create SLT format matrix

	return ret;
}

template<typename DATA_T>
static ErrorStatus trsv_inspect_csc(Matrix old_mat, Matrix *new_mat, Int *perm, Int *iperm, const swSparseTRSVOptions* options) {

	ErrorStatus ret;
	Matrix created;
	MatrixFormatType format = CSC;
	Int m = old_mat->m, n = old_mat->n, nnz = old_mat->nnz;

	Int* old_levels;
	Int* old_indices;
	Int* new_levels;

	const MatrixCSRC *otmp = old_mat->matrix.csrc;
//	const DATA_T *oval = (DATA_T*) otmp->values; 

	new_levels = (Int*)swSparse_malloc(sizeof(Int) * n * 3);
	//TODO malloc error
	if(new_levels == NULL) {
		return SWSPARSE_MALLOC_ERROR;
	}
	old_levels = new_levels + n;
	old_indices = old_levels + n;

	create_id_perm(n, old_indices);

	if((options->transpose & SWSPARSE_NON_TRANSPOSE) == SWSPARSE_NON_TRANSPOSE && options->uplo == SWSPARSE_LOWER_TRI) {
		swSparse_level_csc_lower(n, otmp->offsets, otmp->indices, old_levels);
	} else if((options->transpose & SWSPARSE_TRANSPOSE) == SWSPARSE_TRANSPOSE  && options->uplo == SWSPARSE_UPPER_TRI) {
		format = CSR;
		swSparse_level_csr_lower(n, otmp->offsets, otmp->indices, old_levels);
	} else if((options->transpose & SWSPARSE_NON_TRANSPOSE) == SWSPARSE_NON_TRANSPOSE && options->uplo == SWSPARSE_UPPER_TRI) {
		// reverse permutation, transform UPPER to LOWER
		swSparse_level_csc_upper_reverse(n, otmp->offsets, otmp->indices, old_levels); 
	} else if((options->transpose & SWSPARSE_TRANSPOSE) == SWSPARSE_TRANSPOSE  && options->uplo == SWSPARSE_LOWER_TRI) {
		format = CSR;
		swSparse_level_csr_upper_reverse(n, otmp->offsets, otmp->indices, old_levels); 
	}

	//compute max_level
	Int max_level = 0;
	for(Int i = 0; i < n; i++) {
		max_level = max(max_level, old_levels[i]);
	}

	Int parallel = nnz / max_level;
	if(n < 500 || parallel < 50 || (parallel < 95 && n <=10000 && nnz/n <= 10)) {
		//sequential algorithm
		*new_mat = old_mat;
		old_mat->status = options->uplo | options->diagnal; // override
		swSparse_free(new_levels);
		create_id_perm(n, perm);
		swSparse_perm_invert(n, perm, iperm);

		return SWSPARSE_SUCCESS;
	}

	sort_levels(n, old_levels, old_indices, new_levels, perm);
	swSparse_free(new_levels);
	swSparse_perm_invert(n, perm, iperm);
	ret = swSparse_reorder_row_col(old_mat, &created, iperm, iperm);
	if(ret == SWSPARSE_SUCCESS) {
		*new_mat = created;
		created->status = SWSPARSE_LOWER_TRI | options->diagnal; // override
		created->format_type = format;
	}
	//create SLT format matrix
    ret = create_lower_slt_from_csc<DATA_T>(new_mat, n, created->matrix.csrc->offsets, \
			created->matrix.csrc->indices, (DATA_T*)created->matrix.csrc->values, options, perm, iperm, max_level);
	return ret;
}

template<typename DATA_T, typename Conj, typename Alpha = DATA_T>
static void trsv_execute_csr_upper(Alpha alpha, Matrix u, const DATA_T *b, DATA_T *x, const swSparseTRSVOptions* options) {
	const Int n = u->n;
	Int i;
	const Int *u_row_offsets = u->matrix.csrc->offsets;
	const Int *u_column_indices = u->matrix.csrc->indices;
	const DATA_T *u_values = (const DATA_T*)u->matrix.csrc->values;

	if((u->status & SWSPARSE_UNIT_DIAG) != 0) {
		for(i = n - 1; i >= 0; --i) {
			const Int begin = u_row_offsets[i], end = u_row_offsets[i+1];
			Int k;
			DATA_T tmp_x = alpha * b[i];
			for(k = end; k > begin; --k) {
				Int j = u_column_indices[k];
				tmp_x -= x[j] * Conj::value(u_values[k]);
			}
			x[i] = tmp_x;
		}
	} else if((u->status & SWSPARSE_RECP_DIAG) != 0) {
		for(i = n - 1; i >= 0; --i) {
			const Int begin = u_row_offsets[i], end = u_row_offsets[i+1]-1;
			Int k;
			DATA_T tmp_x = alpha * b[i];
			for(k = end; k > begin; --k) {
				Int j = u_column_indices[k];
				tmp_x -= x[j] * Conj::value(u_values[k]);
			}
			x[i] = tmp_x * Conj::value(u_values[begin]);
		}
	} else {
		for(i = n - 1; i >= 0; --i) {
			const Int begin = u_row_offsets[i], end = u_row_offsets[i+1]-1;
			Int k;
			DATA_T tmp_x = alpha * b[i];
			for(k = end; k > begin; --k) {
				Int j = u_column_indices[k];
				tmp_x -= x[j] * Conj::value(u_values[k]);
			}
			x[i] = tmp_x / Conj::value(u_values[begin]);
		}
	}
}

template<typename DATA_T, typename Conj, typename Alpha = DATA_T>
static void trsv_execute_csr_lower(Alpha alpha, Matrix l, const DATA_T *b, DATA_T *x, const swSparseTRSVOptions* options) {
	const Int n = l->n;
	Int i;
	const Int *l_row_offsets = l->matrix.csrc->offsets;
	const Int *l_column_indices = l->matrix.csrc->indices;
	const DATA_T *l_values = (const DATA_T*)l->matrix.csrc->values;

	if((l->status & SWSPARSE_UNIT_DIAG) != 0) {
		for(i = 0; i < n; ++i) {
			const Int begin = l_row_offsets[i], end = l_row_offsets[i+1];
			Int k;
			DATA_T tmp_x = alpha * b[i];
			for(k = begin; k < end; ++k) {
				Int j = l_column_indices[k];
				tmp_x -= x[j] * Conj::value(l_values[k]);
			}
			x[i] = tmp_x;
		}
	} else if((l->status & SWSPARSE_RECP_DIAG) != 0) {
		for(i = 0; i < n; ++i) {
			const Int begin = l_row_offsets[i], end = l_row_offsets[i+1];
			Int k;
			DATA_T tmp_x = alpha * b[i];
			for(k = begin; k < end-1; ++k) {
				Int j = l_column_indices[k];
				tmp_x -= x[j] * Conj::value(l_values[k]);
			}
			x[i] = tmp_x * Conj::value(l_values[end-1]);
		}
	} else {
		for(i = 0; i < n; ++i) {
			const Int begin = l_row_offsets[i], end = l_row_offsets[i+1];
			Int k;
			DATA_T tmp_x = alpha * b[i];
			for(k = begin; k < end-1; ++k) {
				Int j = l_column_indices[k];
				tmp_x -= x[j] * Conj::value(l_values[k]);
			}
			x[i] = tmp_x / Conj::value(l_values[end-1]);
		}
	}
}

template<typename DATA_T, typename Conj, typename Alpha = DATA_T>
static void trsv_execute_csc_upper(Alpha alpha, Matrix u, const DATA_T *b, DATA_T *x, const swSparseTRSVOptions* options) {
	const Int n = u->n;
	Int i;
	const Int *u_column_offsets = u->matrix.csrc->offsets;
	const Int *u_row_indices = u->matrix.csrc->indices;
	const DATA_T *u_values = (const DATA_T*)u->matrix.csrc->values;

//	swSparse_memcpy(x, b, n * sizeof(DATA_T));
	vector_scale(alpha, n, b, x);

	if((u->status & SWSPARSE_UNIT_DIAG) != 0) {

		for(i = n - 1; i >= 0; --i) {
			const Int begin = u_column_offsets[i], end = u_column_offsets[i+1];
			Int k;
			x[i] = x[i];
			for(k = begin; k < end; ++k) {
				Int j = u_row_indices[k];
				x[j] -= x[i] * Conj::value(u_values[k]);
			}
		}
	} else if((u->status & SWSPARSE_RECP_DIAG) != 0) {

		for(i = n - 1; i >= 0; --i) {
			const Int begin = u_column_offsets[i], end = u_column_offsets[i+1]-1;
			Int k;
			x[i] = x[i] * Conj::value(u_values[end]);
			for(k = begin; k < end; ++k) {
				Int j = u_row_indices[k];
				x[j] -= x[i] * Conj::value(u_values[k]);
			}
		}
	} else {

		for(i = n - 1; i >= 0; --i) {
			const Int begin = u_column_offsets[i], end = u_column_offsets[i+1]-1;
			Int k;
			x[i] = x[i] / Conj::value(u_values[end]);
			for(k = begin; k < end; ++k) {
				Int j = u_row_indices[k];
				x[j] -= x[i] * Conj::value(u_values[k]);
			}
		}
	}
}

template<typename DATA_T, typename Conj, typename Alpha = DATA_T>
static void trsv_execute_csc_lower(Alpha alpha, Matrix l, const DATA_T *b, DATA_T *x, const swSparseTRSVOptions* options) {
	const Int n = l->n;
	Int i;
	const Int *l_column_offsets = l->matrix.csrc->offsets;
	const Int *l_row_indices = l->matrix.csrc->indices;
	const DATA_T *l_values = (const DATA_T*)l->matrix.csrc->values;

//	swSparse_memcpy(x, b, n * sizeof(DATA_T));
	vector_scale(alpha, n, b, x);

	if((l->status & SWSPARSE_UNIT_DIAG) != 0) {

		for(i = 0; i < n; ++i) {
			const Int begin = l_column_offsets[i], end = l_column_offsets[i+1];
			Int k;
			x[i] = x[i];
			for(k = begin; k < end; ++k) {
				Int j = l_row_indices[k];
				x[j] -= x[i] * Conj::value(l_values[k]);
			}
		}
	} else if((l->status & SWSPARSE_RECP_DIAG) != 0) {

		for(i = 0; i < n; ++i) {
			const Int begin = l_column_offsets[i], end = l_column_offsets[i+1];
			Int k;
			x[i] = x[i] * Conj::value(l_values[begin]);
			for(k = begin + 1; k < end; ++k) {
				Int j = l_row_indices[k];
				x[j] -= x[i] * Conj::value(l_values[k]);
			}
		}
	} else {

		for(i = 0; i < n; ++i) {
			const Int begin = l_column_offsets[i], end = l_column_offsets[i+1];
			Int k;
			x[i] = x[i] / Conj::value(l_values[begin]);
			for(k = begin + 1; k < end; ++k) {
				Int j = l_row_indices[k];
				x[j] -= x[i] * Conj::value(l_values[k]);
			}
		}
	}
}

template<typename DATA_T>
INLINE ErrorStatus trsv_execute(DATA_T alpha, Matrix mat, const DATA_T *b, DATA_T *x, const swSparseTRSVOptions* options) {

	if(mat->m != mat->n) {
		DEBUG_PRINTF("error: The matrix is not square\n"); 
		return SWSPARSE_INVALID_ARGS;
	}
	if(mat->element_type != type_traits<DATA_T>::element_type) {
		DEBUG_PRINTF("error: The matrix element is not %s\n", type_traits<DATA_T>::name_short); 
		return SWSPARSE_INVALID_ARGS;
	}
	using conj = conjugate<DATA_T>;
	using noconj = not_conjugate<DATA_T>;

	if(alpha == DATA_T(0)) {
		swSparse_memset(x, 0, sizeof(DATA_T) * mat->m);
		return SWSPARSE_SUCCESS;
	}

    if(mat->format_type == SWSPARSE_SLTCOO) {
		trsv_arg_t<DATA_T> args;  
		
		args.alpha	   = alpha;
		args.x         = x;
		args.b         = b;
		args.N         = mat->n;
		args.status    = mat->status;
		args.n         = mat->matrix.sltcoo->n_vec;
		args.levels    = mat->matrix.sltcoo->levels;
		args.plevels   = mat->matrix.sltcoo->plevels;
		args.aa        = (DATA_T *)mat->matrix.sltcoo->values;
		args.ai        = mat->matrix.sltcoo->column_indices;
		args.aj        = mat->matrix.sltcoo->row_indices;
		args._idx      = mat->matrix.sltcoo->_idx;
		args.level     = mat->matrix.sltcoo->level;
		args.plevel    = mat->matrix.sltcoo->plevel;
		args.trsv_tune = (trsv_tune_t *)mat->matrix.sltcoo->trsv_tune;
		
		Int couples= 1 << args.trsv_tune->couples_log2;
		for(Int i = 0; i < couples; i++) {
			args.idx[i] = mat->matrix.sltcoo->idx[i];
			args.cnt[i] = mat->matrix.sltcoo->cnt[i];
#ifdef SWAPS_TEST
			args.pro_swaps[i] = &mat->matrix.sltcoo->pro_swaps[i];
			args.con_swaps[i] = &mat->matrix.sltcoo->con_swaps[i];
#endif
		}

		athread_spawn_trsv_kernel(&args);
		athread_join();

		return SWSPARSE_SUCCESS;
	} else {
//        DEBUG_PRINTF("error: The format_type of the matrix is not SLTCOO\n");
//        return SWSPARSE_INVALID_ARGS;

		//sequential alogrithm
		if(mat->status == SWSPARSE_LOWER_TRI) { // override
			switch(mat->format_type) {
				case CSC:
					trsv_execute_csc_lower<DATA_T, noconj>(alpha, mat, b, x, options);
					return SWSPARSE_SUCCESS;
				case CSR:
					trsv_execute_csr_lower<DATA_T, noconj>(alpha, mat, b, x, options);
					return SWSPARSE_SUCCESS;
				default:
					return SWSPARSE_INVALID_ARGS;
			}
		} else if((options->transpose & SWSPARSE_NON_TRANSPOSE) == SWSPARSE_NON_TRANSPOSE) {

			if((mat->status & SWSPARSE_UPPER_TRI)) {
				switch(mat->format_type) {
					case CSC:
						trsv_execute_csc_upper<DATA_T, noconj>(alpha, mat, b, x, options);
						return SWSPARSE_SUCCESS;
					case CSR:
						trsv_execute_csr_upper<DATA_T, noconj>(alpha, mat, b, x, options);
						return SWSPARSE_SUCCESS;
					default:
						return SWSPARSE_INVALID_ARGS;
				}

			} else if ((mat->status & SWSPARSE_LOWER_TRI)) {
				switch(mat->format_type) {
					case CSC:
						trsv_execute_csc_lower<DATA_T, noconj>(alpha, mat, b, x, options);
						return SWSPARSE_SUCCESS;
					case CSR:
						trsv_execute_csr_lower<DATA_T, noconj>(alpha, mat, b, x, options);
						return SWSPARSE_SUCCESS;
					default:
						return SWSPARSE_INVALID_ARGS;
				}
			} else {
				return SWSPARSE_INVALID_ARGS;
			}
		} else if((options->transpose & SWSPARSE_TRANSPOSE) == SWSPARSE_TRANSPOSE) {

			if((mat->status & SWSPARSE_UPPER_TRI)) {
				switch(mat->format_type) {
					case CSC:
						trsv_execute_csr_lower<DATA_T, noconj>(alpha, mat, b, x, options);
						return SWSPARSE_SUCCESS;
					case CSR:
						trsv_execute_csc_lower<DATA_T, noconj>(alpha, mat, b, x, options);
						return SWSPARSE_SUCCESS;
					default:
						return SWSPARSE_INVALID_ARGS;
				}

			} else if ((mat->status & SWSPARSE_LOWER_TRI)) {
				switch(mat->format_type) {
					case CSC:
						trsv_execute_csr_upper<DATA_T, noconj>(alpha, mat, b, x, options);
						return SWSPARSE_SUCCESS;
					case CSR:
						trsv_execute_csc_upper<DATA_T, noconj>(alpha, mat, b, x, options);
						return SWSPARSE_SUCCESS;
					default:
						return SWSPARSE_INVALID_ARGS;
				}
			} else {
				return SWSPARSE_INVALID_ARGS;
			}
		} else {
			DEBUG_PRINTF("error: invalid value of options.transpose in swSparse_%s_trsv.\n", type_traits<DATA_T>::name_short); 
			return SWSPARSE_INVALID_ARGS;
		}
    }
}

template<typename DATA_T>
INLINE ErrorStatus trsm_execute(DATA_T alpha, Matrix mat, swSparseInt nvec, \
		const DATA_T *b, swSparseInt ldb, DATA_T *x, swSparseInt ldx, const swSparseTRSMOptions* options) {
	if(mat->m != mat->n) {
		DEBUG_PRINTF("error: The matrix is not square\n"); 
		return SWSPARSE_INVALID_ARGS;
	}
	if(mat->element_type != type_traits<DATA_T>::element_type) {
		DEBUG_PRINTF("error: The matrix element is not %s\n"); 
		return SWSPARSE_INVALID_ARGS;
	}
	swSparseTRSVOptions trsv_options;
	trsv_options.expected_ncall = options->expected_ncall;
	trsv_options.uplo           = options->uplo;
	trsv_options.transpose      = options->transpose;
	trsv_options.diagnal        = options->diagnal;

	for(Int i = 0; i < nvec; ++i) {
		trsv_execute<DATA_T>(alpha, mat, b + ldb * i, x + ldx * i, &trsv_options);
	}

	return SWSPARSE_SUCCESS;
}

} // namespcae swSparse

ErrorStatus swSparse_trsv_inspect(Matrix old_mat, Matrix *new_mat, Int *perm, Int *iperm, const swSparseTRSVOptions* options) {
	ErrorStatus ret;
	if(old_mat->m != old_mat->n) {
		DEBUG_PRINTF("The matirx must be square.\n");
		return SWSPARSE_INVALID_ARGS;
	}
	if(options->uplo != SWSPARSE_UPPER_TRI && options->uplo != SWSPARSE_LOWER_TRI) {
		DEBUG_PRINTF("The matrix should be upper tridiagnal or lower tridiagnal.\n");
		return SWSPARSE_INVALID_ARGS;
	}
	if(options->diagnal != SWSPARSE_GENERAL_DIAG && options->diagnal != SWSPARSE_UNIT_DIAG && 
			options->diagnal != SWSPARSE_RECP_DIAG) {
		DEBUG_PRINTF("The matrix diagnal option is invalid.\n");
		return SWSPARSE_INVALID_ARGS;
	}
	if(options->transpose != SWSPARSE_TRANSPOSE && options->transpose != SWSPARSE_NON_TRANSPOSE &&
			options->transpose != SWSPARSE_MAYBE_TRANSPOSE) {
		DEBUG_PRINTF("The matrix transpose option is invalid.\n");
		return SWSPARSE_INVALID_ARGS;
	}

	ret = swSparse_ensure_order(old_mat);
	if(ret == SWSPARSE_SUCCESS) {
		switch(old_mat->format_type) {
			case CSC:
				switch(old_mat->element_type) {
					case REAL_SINGLE:
						return swSparse::trsv_inspect_csc<float>(old_mat, new_mat, perm, iperm, options);
					case REAL_DOUBLE:
						return swSparse::trsv_inspect_csc<double>(old_mat, new_mat, perm, iperm, options);
					case COMPLEX_SINGLE:
						return swSparse::trsv_inspect_csc<SComplex>(old_mat, new_mat, perm, iperm, options);
					case COMPLEX_DOUBLE:
						return swSparse::trsv_inspect_csc<DComplex>(old_mat, new_mat, perm, iperm, options);
				}
			case CSR:
				switch(old_mat->element_type) {
					case REAL_SINGLE:
						return swSparse::trsv_inspect_csr<float>(old_mat, new_mat, perm, iperm, options);
					case REAL_DOUBLE:
						return swSparse::trsv_inspect_csr<double>(old_mat, new_mat, perm, iperm, options);
					case COMPLEX_SINGLE:
						return swSparse::trsv_inspect_csr<SComplex>(old_mat, new_mat, perm, iperm, options);
					case COMPLEX_DOUBLE:
						return swSparse::trsv_inspect_csr<DComplex>(old_mat, new_mat, perm, iperm, options);
				}
			default:
				return SWSPARSE_INVALID_ARGS;
		}
	} else {
		return ret;
	}
}

ErrorStatus swSparse_trsm_inspect(Matrix old_mat, Matrix *new_mat, Int *perm, Int *iperm, const swSparseTRSMOptions* options) {
	swSparseTRSVOptions trsv_options;
	trsv_options.expected_ncall = options->expected_ncall;
	trsv_options.transpose= options->transpose;
	trsv_options.uplo= options->uplo;
	trsv_options.diagnal= options->diagnal;

	return swSparse_trsv_inspect(old_mat, new_mat, perm, iperm, &trsv_options);
}

#define TRS_EXECUTE_CPP_TO_C(type, prefix) \
	ErrorStatus prefix##trsv_execute(type alpha, Matrix mat, const type *b, type *x, const swSparseTRSVOptions* options) \
{ swSparse::trsv_execute<type>(alpha, mat, b, x, options); return SWSPARSE_SUCCESS;} \
ErrorStatus prefix##trsm_execute(type alpha, Matrix mat, swSparseInt nvec, \
		const type *b, swSparseInt ldb, type *x, swSparseInt ldx, const swSparseTRSMOptions* options) \
{ swSparse::trsm_execute<type>(alpha, mat, nvec, b, ldb, x, ldx, options); return SWSPARSE_SUCCESS;}

	TRS_EXECUTE_CPP_TO_C(float, swSparse_s_)
	TRS_EXECUTE_CPP_TO_C(double, swSparse_d_)
	TRS_EXECUTE_CPP_TO_C(SComplex, swSparse_c_)
	TRS_EXECUTE_CPP_TO_C(DComplex, swSparse_z_)
