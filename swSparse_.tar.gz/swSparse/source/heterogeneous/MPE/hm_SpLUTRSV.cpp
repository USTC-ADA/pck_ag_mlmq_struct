#include <stdio.h>
#include <algorithm>
#include <cassert>
#include <sys/time.h>
#include "internal/rename.h"
#include "internal/memory.h"
#include "internal/templates.h"
#include "internal/sptrf_common.h"
#include "internal/splutrsv_param.h"
#include "swSparse_splutrsv.h"

static swSparse::lutrsv_static_schedule_arg_t swSparse_lutrsv_schedule_args;
// EXTERN void lutrsv_destroy() {
//     swSparse::lutrsv_destroy_static_schedule_arg(&swSparse_lutrsv_schedule_args);
// }

#ifdef LUTRSV_STATISTIC
#define DECL_TIMER struct timeval begin, end;
#define TIMER_BEGIN gettimeofday(&begin, nullptr);
#define TIMER_END   gettimeofday(&end, nullptr);

struct LUTRSV_STATISTICS {
	double time_[LUTRSV_STAGE_NUM];
    const char * const swSparse_lutrsv_timing_names_[LUTRSV_STAGE_NUM] = {
        "lutrsv_preprocess", "lutrsv_lsolve", "lutrsv_usolve"
    };
	int64_t lmemory_, lflop_, umemory_, uflop_;
	LUTRSV_STATISTICS() {
		memset(time_, 0, sizeof(time_));
        lflop_ = 0;
        uflop_ = 0;
        lmemory_ = 0;
        umemory_ = 0;
	}
    void set_time(const struct timeval* begin, const struct timeval* end, int stage) {
		time_[stage] = 1e3 * (end->tv_sec - begin->tv_sec) + 1e-3 * (end->tv_usec - begin->tv_usec);
	}
	void add_time(const struct timeval* begin, const struct timeval* end, int stage) {
		time_[stage] += 1e3 * (end->tv_sec - begin->tv_sec) + 1e-3 * (end->tv_usec - begin->tv_usec);
	}
    // 前代回代之后再调用此函数，确保静态调度成功
    void get_flop_and_memory(Int n, swSparseMatrix *lu, size_t size_of_type) {
        swSparseLUSupernodes* lusup = (*lu)->matrix.lusuper;
        swSparse::lutrsv_static_schedule(lusup, &swSparse_lutrsv_schedule_args);

        // flop
        Int* sup2col = lusup->sup2col;
        Int* col2sup = lusup->col2sup;
        Int* l_v_offsets = lusup->l_v_offsets;
        Int* l_i_offsets = lusup->l_i_offsets;
        Int* u_seg_offsets = lusup->u_seg_offsets;
        Int* u_col_offsets = lusup->u_col_offsets;
        Int nsup = lusup->nsuper;
        Int lnnz = l_v_offsets[nsup], unnz = u_seg_offsets[u_col_offsets[n]];
        int64_t uflop = (lnnz << 1), lflop = (unnz << 1);    
        for(Int i = 0; i < nsup; ++i) {
            Int j_sup_begin = sup2col[i], j_sup_end = sup2col[i+1];
            Int supsize = j_sup_end - j_sup_begin;
            int64_t _tmp = (supsize + 1) * supsize;
            uflop -= _tmp;
            lflop += (_tmp - supsize);
        }
        lflop_ = lflop;
        uflop_ = uflop;

        // memory
        lmemory_ = (nsup + 1) * sizeof(Int) * 3;   // sup2col, l_i_offsets, l_v_offsets
        lmemory_ += (n + 1) * sizeof(Int); // u_col_offsets
        lmemory_ += u_col_offsets[n] * sizeof(Int) * 2;  // u_seg_offsets, u_seg_indices
        lmemory_ += ((lflop + n) >> 1) * size_of_type;
        Int* lsubtree_offsets = swSparse_lutrsv_schedule_args.lsubtree_offsets;
        Int* ltask_offsets = swSparse_lutrsv_schedule_args.ltask_offsets;
        lmemory_ += (CPE_FOR_LUTRSV + 1) * sizeof(Int) * 2; // lsubtree_offsets, ltasks_offsets
        lmemory_ += lsubtree_offsets[CPE_FOR_LUTRSV] * sizeof(Int) * 2; // lsubtrees
        // ltasks，粗略估计，忽略 group.partner
        lmemory_ += ltask_offsets[CPE_FOR_LUTRSV] * sizeof(Int) * 8; // first_child, snode_status

        umemory_ = (nsup + 1) * sizeof(Int) * 3;   // sup2col, l_i_offsets, l_v_offsets
        umemory_ += l_i_offsets[nsup] * sizeof(Int); // l_indice
        umemory_ += (uflop >> 1) * size_of_type;
        Int* usubtree_offsets = swSparse_lutrsv_schedule_args.usubtree_offsets;
        Int* utask_offsets = swSparse_lutrsv_schedule_args.utask_offsets;
        umemory_ += (CPE_FOR_LUTRSV + 1) * sizeof(Int) * 2; // usubtree_offsets, utasks_offsets
        umemory_ += usubtree_offsets[CPE_FOR_LUTRSV] * sizeof(Int) * 3; // usubtrees, snode_parent
        // utasks，粗略估计，忽略 group.partner
        umemory_ += utask_offsets[CPE_FOR_LUTRSV] * sizeof(Int) * 7; // first_child
        
        swSparse::lutrsv_destroy_static_schedule_arg(&swSparse_lutrsv_schedule_args);
    }
	void print() const {
		for(int i = 0; i < LUTRSV_STAGE_NUM; ++ i) {
			const char* name = swSparse_lutrsv_timing_names_[i];
			printf("%18s time: %.3lf ms\n", name, time_[i]);
		}
        printf("lutrsv lflop: %lld, lmemeory: %lld, uflop: %lld, umemory: %lld\n", \
            lflop_, lmemory_, uflop_, umemory_);
	}
};

static LUTRSV_STATISTICS swSparse_lutrsv_stat;
void swSparse_lutrsv_get_flop_and_memory(Int n, swSparseMatrix* lu, size_t size_of_type) {
	swSparse_lutrsv_stat.get_flop_and_memory(n, lu, size_of_type);
}
void swSparse_print_lutrsv_info() { swSparse_lutrsv_stat.print(); }

#else
#define DECL_TIMER
#define TIMER_BEGIN
#define TIMER_END
#endif


namespace swSparse {

ATHREAD_SPAWN_TEMPLATE_ARGTYPE(lutrsv_iperm_kernel, lutrsv_iperm_arg_t)
ATHREAD_SPAWN_TEMPLATE_ARGTYPE(lutrsv_lsolve_kernel, splutrsv_arg_t)
ATHREAD_SPAWN_TEMPLATE_ARGTYPE(lutrsv_usolve_kernel, splutrsv_arg_t)

template <typename DATA_T>
void lutrsv_iperm(Int n, DATA_T* src, DATA_T* dst, Int* iperm) {
    if(n < CPE_IPERM_N) {
        // swSparse_(type)_iperm_apply
        for(Int i = 0; i < n; ++i) {
            dst[iperm[i]] = src[i];
        }
    } else {
        lutrsv_iperm_arg_t<DATA_T> arg;
        arg.dst = dst;
        arg.iperm = iperm;
        arg.src = src;
        arg.n = n;

        athread_spawn_lutrsv_iperm_kernel(&arg);
        athread_join();
    }
}

template <typename DATA_T>
ErrorStatus lutrsv_execute(Int n, swSparseLUSupernodes* lusup, const DATA_T* b, DATA_T *x, Int* riperm, Int* ciperm, const real_t<DATA_T>* rscale, const real_t<DATA_T>* cscale, DATA_T* work)
{   
    if constexpr (std::is_same<DATA_T, float>::value) {
        swSparse_s_elementwise_multiply(n, b, work, cscale);
    } else if constexpr (std::is_same<DATA_T, double>::value) { 
        swSparse_d_elementwise_multiply(n, b, work, cscale);
    } else if constexpr (std::is_same<DATA_T, SComplex>::value) { 
        swSparse_c_elementwise_multiply(n, b, work, cscale);
    } else if constexpr (std::is_same<DATA_T, DComplex>::value) { 
        swSparse_z_elementwise_multiply(n, b, work, cscale);
    } else {                                   
        fprintf(stderr, "Unsupported type\n");
        return SWSPARSE_NOT_SUPPORTED;
    }   
    lutrsv_iperm<DATA_T>(n, work, x, ciperm);

#ifdef LUTRSV_STATISTIC    
    DECL_TIMER
    TIMER_BEGIN
#endif
    // set args
    splutrsv_arg_t<DATA_T> args;
    args.n = n;
    args.x = x;
    args.lusup = lusup;
    args.first_child = swSparse_lutrsv_schedule_args.first_child;
    args.next_sibling = swSparse_lutrsv_schedule_args.next_sibling;
    
    args.snode_status = swSparse_lutrsv_schedule_args.lnode_status;
    args.subtrees = swSparse_lutrsv_schedule_args.lsubtrees;
    args.subtree_offsets = swSparse_lutrsv_schedule_args.lsubtree_offsets;
    args.tasks = swSparse_lutrsv_schedule_args.ltasks;
    args.task_offsets = swSparse_lutrsv_schedule_args.ltask_offsets;
    args.task_queue = swSparse_lutrsv_schedule_args.ltask_queue;
        
    // 求解 L * y = b
    athread_spawn_lutrsv_lsolve_kernel(&args);
    athread_join();
#ifdef LUTRSV_STATISTIC
    TIMER_END
    swSparse_lutrsv_stat.set_time(&begin, &end, LUTRSV_LSOLVE);
    TIMER_BEGIN
#endif

    args.snode_status = swSparse_lutrsv_schedule_args.unode_status;
    args.subtrees = swSparse_lutrsv_schedule_args.usubtrees;
    args.subtree_offsets = swSparse_lutrsv_schedule_args.usubtree_offsets;
    args.tasks = swSparse_lutrsv_schedule_args.utasks;
    args.task_offsets = swSparse_lutrsv_schedule_args.utask_offsets;
    args.task_queue = swSparse_lutrsv_schedule_args.utask_queue;

    // 求解 U * x = y
    athread_spawn_lutrsv_usolve_kernel(&args);
    athread_join();
#ifdef LUTRSV_STATISTIC
    TIMER_END
    swSparse_lutrsv_stat.set_time(&begin, &end, LUTRSV_USOLVE);
#endif

    if constexpr (std::is_same<DATA_T, float>::value) {
        swSparse_s_perm_apply(n, x, work, riperm);
        swSparse_s_elementwise_multiply(n, work, x, rscale);
    } else if constexpr (std::is_same<DATA_T, double>::value) { 
        swSparse_d_perm_apply(n, x, work, riperm);
        swSparse_d_elementwise_multiply(n, work, x, rscale);
    } else if constexpr (std::is_same<DATA_T, SComplex>::value) { 
        swSparse_c_perm_apply(n, x, work, riperm);
        swSparse_c_elementwise_multiply(n, work, x, rscale);
    } else if constexpr (std::is_same<DATA_T, DComplex>::value) { 
        swSparse_z_perm_apply(n, x, work, riperm);
        swSparse_z_elementwise_multiply(n, work, x, rscale);
    } else {                                   
        fprintf(stderr, "Unsupported type\n");
        return SWSPARSE_NOT_SUPPORTED;
    }

    return SWSPARSE_SUCCESS;
}

// 只支持行主顺序
template <typename DATA_T>
ErrorStatus lutrsv(Int n, swSparseMatrix *lu, const DATA_T* b, DATA_T *x, Int* riperm, Int* ciperm, const real_t<DATA_T>* rscale, const real_t<DATA_T>* cscale)
{  
#ifdef LUTRSV_STATISTIC    
    DECL_TIMER
    TIMER_BEGIN
#endif
    // 预处理，创建调度数组
    swSparseLUSupernodes* lusup = (*lu)->matrix.lusuper;
    ErrorStatus ret = lutrsv_static_schedule(lusup, &swSparse_lutrsv_schedule_args);
    if(ret != SWSPARSE_SUCCESS) {
        fprintf(stderr, "swSparse_lutrsv_schedule error\n");
        return ret;
    }
#ifdef LUTRSV_STATISTIC
    TIMER_END
    swSparse_lutrsv_stat.set_time(&begin, &end, LUTRSV_PREPROCESS);
#endif

    // 用于 b 向量重排的缓冲区
    size_t malloc_size = sizeof(DATA_T) * n;
    DATA_T* work = (DATA_T*)swSparse_malloc(malloc_size);
    IF_ERR(work == nullptr) {
        return SWSPARSE_MALLOC_ERROR;
    }

    // 前代回代过程，迭代精校时可多次调用
    ret = lutrsv_execute<DATA_T>(n, lusup, b, x, riperm, ciperm, rscale, cscale, work);
    if(ret != SWSPARSE_SUCCESS) {
        fprintf(stderr, "swSparse_lutrsv_excute error\n", ret);
        return ret;
    }

    // 释放内存
    swSparse_free(work);
    lutrsv_destroy_static_schedule_arg(&swSparse_lutrsv_schedule_args);
    return SWSPARSE_SUCCESS;
}

}  // namespace swSparse

#define DATA_TYPE_S
#include "hm_SpLUTRSV.inl"
#undef  DATA_TYPE_S
#define DATA_TYPE_D
#include "hm_SpLUTRSV.inl"
#undef  DATA_TYPE_D
#define DATA_TYPE_C
#include "hm_SpLUTRSV.inl"
#undef  DATA_TYPE_C
#define DATA_TYPE_Z
#include "hm_SpLUTRSV.inl"
#undef  DATA_TYPE_Z