#include <algorithm>
#include <crts.h>
#include "swSparse_base.h"
#include "internal/rename.h"
#include "internal/templates.h"
#include "internal/utils.h"
#include "internal/memory.h"
#include "internal/kernel_args.h"
#include "internal/reorder.h"

ATHREAD_SPAWN_CONCRETE_ARGTYPE(id_perm_kernel, id_perm_args_t)
ATHREAD_SPAWN_CONCRETE_ARGTYPE(rowwise_sort_pattern_kernel, rowwise_sort_arg_t<dummy_t>)
ATHREAD_SPAWN_TEMPLATE_ARGTYPE(csr423_kernel, csr423_arg_t)
ATHREAD_SPAWN_TEMPLATE_ARGTYPE(rowwise_sort_kernel, rowwise_sort_arg_t)
ATHREAD_SPAWN_TEMPLATE_ARGTYPE(csr423_perm_kernel, csr423_perm_arg_t)
ATHREAD_SPAWN_TEMPLATE_ARGTYPE(gather_kernel, gather_arg_t)
ATHREAD_SPAWN_KERNEL(gather_kernel, gather_arg_t<Int>, SLAVE_FUN(swSparse_i_gather_kernel))


void swSparse_create_id_perm(Int n, Int *perm) {
    if(n < 8192) {
        for(Int i = 0; i < n; ++i) {
            perm[i] = i;
        }
    } else {
        id_perm_args_t args;
        args.n = n;
        args.perm = perm;
        athread_spawn_id_perm_kernel(&args);
        athread_join();
    }
}

/*
 * TODO: bucket-based parallel permutation
 */
ErrorStatus swSparse_perm_invert(Int n, const Int *perm, Int *iperm) {
    for(Int i = 0; i < n; ++i) {
        iperm[perm[i]] = i;
    }
    return SWSPARSE_SUCCESS;
}

namespace swSparse {
/*
 * TODO: bucket-based parallel permutation
 */
template<typename DATA_T>
INLINE void iperm_apply(Int n, const DATA_T *RSTR src, DATA_T *RSTR dst, const Int *RSTR iperm) {
    for(Int i = 0; i < n; ++i) {
        dst[iperm[i]] = src[i];
    }
}

template<typename DATA_T>
INLINE void perm_apply(Int n, const DATA_T *RSTR src, DATA_T *RSTR dst, const Int *RSTR perm) {
    if(n < 8192) {
        for(Int i = 0; i < n; ++i) {
            dst[i] = src[perm[i]];
        }
    } else {
        gather_arg_t<DATA_T> args;
        args.dst = dst;
        args.indices = perm;
        args.src = src;
        args.n = n;
        athread_spawn_gather_kernel(&args);
        athread_join();
    }
}

template<typename DATA_T>
void csr423(Int first_dim, Int nnz, 
                    const Int *RSTR begins, const Int *RSTR ends, const Int *RSTR indices4, const DATA_T *RSTR values4,
                    Int *RSTR offsets, Int *RSTR indices3, DATA_T *RSTR values3) {
    if(nnz <= 8192) {
        Int i, j, k;
        offsets[0] = 0;
        for(i = 0; i < first_dim; ++i) {
            for(j = begins[i], k = offsets[i]; j < ends[i]; ++j, ++k) {
                indices3[k] = indices4[j];
                values3[k] = values4[j];
            }
            offsets[i+1] = k;
        }
    } else {
        csr423_arg_t<DATA_T> args;
        args.first_dim = first_dim;
        args.nnz = nnz;
        args.begins = begins;
        args.ends = ends;
        args.offsets = offsets;
        args.indices4 = indices4;
        args.values4 = values4;
        args.indices3 = indices3;
        args.values3 = values3;
        offsets[0] = 0;
        athread_spawn_csr423_kernel(&args);
        athread_join();
    }
}

template<typename DATA_T>
ErrorStatus csr423_perm(Int first_dim, Int nnz, 
                    const Int *RSTR begins, const Int *RSTR ends,  const Int *RSTR indices4, const DATA_T *RSTR values4, const Int* RSTR iperm, 
                    Int *RSTR offsets, Int *RSTR indices3, DATA_T *RSTR values3) {
    csr423_perm_arg_t<DATA_T> args;
    DATA_T* temp = (DATA_T*)swSparse_malloc((sizeof(Int) + sizeof(DATA_T)) * nnz);
    IF_ERR(temp == nullptr) {
        return MALLOC_ERROR;
    }
    args.first_dim = first_dim;
    args.nnz = nnz;
    args.begins = begins;
    args.ends = ends;
    args.offsets = offsets;
    args.indices4 = indices4;
    args.values4 = values4;
    args.indices3 = indices3;
    args.values3 = values3;
    args.temp_values3 = temp;
    args.iperm = iperm;
    args.temp_indices3 = reinterpret_cast<Int*>(temp + nnz);
    offsets[0] = 0;
    athread_spawn_csr423_perm_kernel(&args);
    athread_join();
    swSparse_free(temp);
    return SWSPARSE_SUCCESS;
}

template<typename DATA_T>
ErrorStatus sort_elements(Int first_dim, const Int *RSTR offsets,\
                             Int *RSTR indices, DATA_T *RSTR values) {
    rowwise_sort_arg_t<DATA_T> args;
    Int nnz = offsets[first_dim];
    DATA_T* temp = (DATA_T*)swSparse_malloc((sizeof(Int) + sizeof(DATA_T)) * nnz);
    IF_ERR(temp == nullptr) {
        return MALLOC_ERROR;
    }
    args.m = first_dim;
    args.nnz = nnz;
    args.offsets = offsets;
    args.values = values;
    args.indices = indices;
    args.temp_values = temp;
    args.temp_indices = reinterpret_cast<Int*>(temp + nnz);
    athread_spawn_rowwise_sort_kernel(&args);
    athread_join();
    swSparse_free(temp);
    return SWSPARSE_SUCCESS;
}

void sort_int(Int *a, Int n) {
    //swSparse::sort_index_value(a, dummy_ptr, n);
    std::sort(a, a + n);
}

ErrorStatus sort_elements_in_pattern(Int first_dim, const Int *RSTR offsets,Int *RSTR indices) {
    rowwise_sort_arg_t<dummy_t> args;
    Int nnz = offsets[first_dim];
    Int* temp_indices = (Int*)swSparse_malloc(sizeof(Int) * nnz);
    IF_ERR(temp_indices == nullptr) {
        return MALLOC_ERROR;
    }
    args.m = first_dim;
    args.nnz = nnz;
    args.offsets = offsets;
    args.values = nullptr;
    args.indices = indices;
    args.temp_values = nullptr;
    args.temp_indices = temp_indices;
    athread_spawn_rowwise_sort_pattern_kernel(&args);
    athread_join();
    swSparse_free(temp_indices);
    return SWSPARSE_SUCCESS;
}


/*
 * TODO: parallel sort
 */

static Int count_levels(Int size, const Int* RSTR old_levels, Int* RSTR counter) {
    Int max_levels = 0;
    swSparse_memset(counter, 0, sizeof(Int) * size);
    for(int i = 0; i < size; ++i) {
        counter[old_levels[i]]++;
        max_levels = max(max_levels, old_levels[i]);
    }
    return max_levels;
}

ErrorStatus sort_levels(Int size, const Int* RSTR old_levels, const Int *RSTR old_indices, Int* RSTR new_levels, Int* RSTR new_indices) {
    Int max_levels;
    Int *counter = (Int*)swSparse_malloc(sizeof(Int) * size);
    IF_ERR(counter == nullptr) {
        return MALLOC_ERROR;
    }
    max_levels = count_levels(size, old_levels, counter);
    for(int level = 0, prefix = 0; level <= max_levels; ++level) {
        Int current = counter[level];
        counter[level] = prefix;
        prefix += current;
    }
    for(int i = 0; i < size; ++i) {
        Int new_position = counter[old_levels[i]]++;
        new_indices[new_position] = old_indices[i];
    }
    swSparse_free(counter);
    return SWSPARSE_SUCCESS;
}

ErrorStatus sort_levels_reverse(Int size, const Int* RSTR old_levels, const Int* RSTR old_indices, Int* RSTR new_levels, Int* RSTR new_indices) {
    Int max_levels;
    Int *counter = (Int*)swSparse_malloc(sizeof(Int) * size);
    IF_ERR(counter == nullptr) {
        return MALLOC_ERROR;
    }
    max_levels = count_levels(size, old_levels, counter);
    for(int level = 0, prefix = 0; level <= max_levels; ++level) {
        Int current = counter[level];
        prefix += current;
        counter[level] = prefix;
    }
    for(int i = 0; i < size; ++i) {
        Int new_position = --counter[old_levels[i]];
        new_indices[new_position] = old_indices[i];
    }
    swSparse_free(counter);
    return SWSPARSE_SUCCESS;
}

#define EXPORT_TEMPLATE(type) \
template ErrorStatus sort_elements<type>(Int a, const Int* RSTR b, Int* RSTR c, type* RSTR d); \
template void csr423<type>(Int a, Int b,  const Int* RSTR c, const Int* RSTR d, const Int* RSTR e, const type* RSTR f, Int* RSTR g, Int* RSTR h, type* RSTR i); \
template ErrorStatus csr423_perm<type>(Int a, Int b,  const Int* RSTR c, const Int* RSTR d, const Int* RSTR e, const type* RSTR f, const Int* RSTR p, Int* RSTR g, Int* RSTR h, type* RSTR i);

EXPORT_TEMPLATE(float)
EXPORT_TEMPLATE(double)
EXPORT_TEMPLATE(SComplex)
EXPORT_TEMPLATE(DComplex)\

}

// convert template functions to C functions
#define PERM_CPP_TO_C(type, prefix) \
ErrorStatus prefix##perm_apply(Int n, const type *src, type *dst, const Int *perm) \
    { swSparse::perm_apply<type>(n, src, dst, perm); return SWSPARSE_SUCCESS; } \
ErrorStatus prefix##iperm_apply(Int n, const type *src, type *dst, const Int *iperm) \
    { swSparse::iperm_apply<type>(n, src, dst, iperm); return SWSPARSE_SUCCESS;  }
PERM_CPP_TO_C(float, swSparse_s_)
PERM_CPP_TO_C(double, swSparse_d_)
PERM_CPP_TO_C(SComplex, swSparse_c_)
PERM_CPP_TO_C(DComplex, swSparse_z_)
PERM_CPP_TO_C(Int, swSparse_i_)
