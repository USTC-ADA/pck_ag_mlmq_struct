#include "swSparse_trf.h"
#include "internal/memory.h"
#include "internal/rename.h"
#include "internal/templates.h"
#include "internal/kernel_args.h"
#include "internal/reorder.h"
#include "internal/utils.h"
#include "internal/debug.h"
#include "internal/sptrf_param.h"
#include "internal/sptrf_common.h"

namespace swSparse {
ATHREAD_SPAWN_TEMPLATE_ARGTYPE(trf_numeric_kernel, sptrf_arg_t)

template<typename DATA_T>
INLINE ErrorStatus sptrf_numeric_impl(Matrix a, LUSup* lu, real_t<DATA_T> perterb_thres, Int* riperm, \
    numeric_result_t* res, const swSparseTRFOptions* options) {
    sptrf_arg_t<DATA_T> args;
    args.n         = a->n;
    args.a_col_off = a->matrix.csrc->offsets;
    args.a_row_idx = a->matrix.csrc->indices;
    args.a_val     = VALUES(a->matrix.csrc, DATA_T);
    args.nsuper    = lu->nsuper;
    args.sup2col   = lu->sup2col;
    args.col2sup   = lu->col2sup;
    args.l_i_off   = lu->l_i_offsets;
    args.l_v_off   = lu->l_v_offsets;
    args.l_row_idx = lu->l_indices;
    args.l_val     = static_cast<DATA_T*>(lu->l_values);
    args.u_col_off = lu->u_col_offsets;
    args.u_seg_off = lu->u_seg_offsets;
    args.u_seg_idx = lu->u_seg_indices;
    args.u_val     = static_cast<DATA_T*>(lu->u_values);
    args.ipiv      = riperm;
    args.subtree_offsets = lu->subtree_offsets;
    args.subtrees        = (trf_subtree_t*)lu->subtrees;
    args.task_queue      = (trf_task_t*)lu->task_queue;
    args.task_queue_size = lu->task_queue_size;
    args.snode_status    = lu->snode_status;
    args.perturb_threshold = perterb_thres;
    args.rcp_thres = reciprocal(perterb_thres);
    args.numstats[0] = args.numstats[1] = 0;
    args.options = 0;
    if(options->perturbate != SWSPARSE_NO_PERTURBATE) {
        if(options->perturbate == SWSPARSE_PERTURBATE_0) {
            args.options |= options_perturb_zero;
        } else {
            args.options |= options_perturb_tiny;
        } 
    }
    if((options->transpose & SWSPARSE_CONJUGATE) != 0) {
        args.options |= options_conj;
    }
#ifdef SWSPARSE_LU_USE_SPA
    args.spa_cols = 128;
    do {
        args.spa = (DATA_T*)swSparse_malloc_raw(sizeof(DATA_T) * args.n * 64 * args.spa_cols);
        if(args.spa == NULL) {
            args.spa_cols >>= 1;
        } else break;
    } while(args.spa_cols >= 8);
#endif
    athread_spawn_trf_numeric_kernel(&args);
    athread_join();
    res->interchange_count = args.numstats[0];
    res->perturbation_count = args.numstats[1];
#ifdef SWSPARSE_LU_USE_SPA
    swSparse_free_if(args.spa);
#endif
    return SWSPARSE_SUCCESS;
}

template<typename DATA_T>
ErrorStatus sptrf_numeric(Matrix a, LUSup* lu, real_t<DATA_T> perterb_thres, Int* riperm, \
    numeric_result_t* res, const swSparseTRFOptions* options) {
    Int n = a->n, nsup = lu->nsuper;
    Int l_nnz = lu->l_v_offsets[nsup], u_nnz = lu->u_seg_offsets[lu->u_col_offsets[n]];
    const Int* sup2col = lu->sup2col, *l_i_offsets = lu->l_i_offsets;
    Int *l_indices = lu->l_indices;
    ErrorStatus ret;
    DATA_T *l_val = (DATA_T*) lu->l_values, *u_val = (DATA_T*) lu->u_values;

#ifdef SWSPARSE_HAS_ASSERT
    swSparse_memset(riperm, -1, sizeof(Int) * n);
    //swSparse_memset(l_val, -1, sizeof(DATA_T) * l_nnz);
    //swSparse_memset(u_val, -1, sizeof(DATA_T) * u_nnz);
#endif

    ret = sptrf_numeric_impl<DATA_T>(a, lu, perterb_thres, riperm, res, options);
    IF_ERR(ret != SWSPARSE_SUCCESS) {
        return ret;
    }
    lu->l_ordered = (res->interchange_count == 0);
    return SWSPARSE_SUCCESS;
}

#define INSTANTIATE(type) \
template ErrorStatus sptrf_numeric<type>(Matrix a, LUSup* lu, real_t<type> perterb_thres, \
    Int* riperm, numeric_result_t*, const swSparseTRFOptions* options);

INSTANTIATE(float)
INSTANTIATE(double)
INSTANTIATE(SComplex)
INSTANTIATE(DComplex)

}