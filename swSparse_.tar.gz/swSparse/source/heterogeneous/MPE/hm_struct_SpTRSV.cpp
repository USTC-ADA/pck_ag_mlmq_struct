#include <athread.h>
#include "swSparse_base.h"
#include "swSparse_blas.h"
#include "internal/rename.h"
#include "internal/memory.h"
#include "internal/kernel_args.h"
#include "internal/templates.h"
#include "internal/stsSpTRSV.h"

//宏定义声明不同数据类型的从核kernel函数
ATHREAD_SPAWN_TEMPLATE_ARGTYPE(struct_sptrsv_cross_entry, struct_info)
ATHREAD_SPAWN_TEMPLATE_ARGTYPE(struct_back_sptrsv_cross_entry, struct_info)
ATHREAD_SPAWN_TEMPLATE_ARGTYPE(struct_sptrsv_entry, struct_info)
ATHREAD_SPAWN_TEMPLATE_ARGTYPE(struct_back_sptrsv_entry, struct_info)

//下三角计算
template<typename DATA_T>
void ststrsv_forward_execute(const DATA_T* a, DATA_T *x, const DATA_T* b, \
                                    const int dim[3], int nnz, const int (*p)[2],\
                                    int *col_id, int *z_off, int halo, int cols, int skew)
{
    struct_info<DATA_T> info;
    info.a = a;
    info.x = x;
    info.b = b;
    info.M = dim[0];
    info.N = dim[1];
    info.L = dim[2];
    info.nnz = nnz;
    info.p = (int*)p;
    info.col_id = col_id;
    info.z_off = z_off;
    info.halo = halo;
    info.cols = cols;
    info.skew = skew;
    printf("skew:%d  halo:%d\n",skew,halo);
    int spawn_ret;
    if (skew == 0) {
		spawn_ret = athread_spawn_struct_sptrsv_cross_entry(&info);
    }
	else {
		spawn_ret = athread_spawn_struct_sptrsv_entry(&info);
    }
    if (spawn_ret != 0) {
        printf("athread_spawn failed with ret=%d\n", spawn_ret);
    }
	athread_join();
    athread_halt();


}

//上三角计算
template<typename DATA_T>
void ststrsv_backward_execute(const DATA_T* a, DATA_T *x, const DATA_T* b, \
                                    const int dim[3], int nnz, const int (*p)[2],\
                                    int *col_id, int *z_off, int halo, int cols, int skew)
{
    struct_info<DATA_T> info;
    info.a = a;
    info.x = x;
    info.b = b;
    info.M = dim[0];
    info.N = dim[1];
    info.L = dim[2];
    info.nnz = nnz;
    info.p = (int*)p;
    info.col_id = col_id;
    info.z_off = z_off;
    info.halo = halo;
    info.cols = cols;
    info.skew = skew;
    printf("skew:%d  halo:%d\n",skew,halo);
    int spawn_ret;
    if (skew == 0) {
		spawn_ret = athread_spawn_struct_back_sptrsv_cross_entry(&info);
    }
	else {
		spawn_ret = athread_spawn_struct_back_sptrsv_entry(&info);
    }
    if (spawn_ret != 0) {
        printf("athread_spawn failed with ret=%d\n", spawn_ret);
    }
	athread_join();
    athread_halt();

}

template void ststrsv_forward_execute<double>(const double* a, double *x, const double* b, const int dim[3], int nnz, const int (*p)[2],int *col_id, int *z_off, int halo, int cols, int skew);
template void ststrsv_forward_execute<float>(const float* a, float *x, const float* b, const int dim[3], int nnz, const int (*p)[2],int *col_id, int *z_off, int halo, int cols, int skew);
template void ststrsv_backward_execute<double>(const double* a, double *x, const double* b, const int dim[3], int nnz, const int (*p)[2],int *col_id, int *z_off, int halo, int cols, int skew);
template void ststrsv_backward_execute<float>(const float* a, float *x, const float* b, const int dim[3], int nnz, const int (*p)[2],int *col_id, int *z_off, int halo, int cols, int skew);
