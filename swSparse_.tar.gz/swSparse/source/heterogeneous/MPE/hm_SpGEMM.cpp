#include <limits>
#include <stdio.h>
#include <omp.h>
#include <sys/time.h>
#include <swperf.h>
#include "swSparse_blas.h"
#include "internal/memory.h"
#include "internal/templates.h"
#include "internal/debug.h"
#include "internal/spgemm_param.h"
#include "internal/spblas_common.h"
#include "internal/utils.h"
#include "internal/reorder.h"

//#define PROFILE_SPGEMM_MULTICG
#ifdef PROFILE_SPGEMM_MULTICG
#define TIMER_SET(timer) gettimeofday(&timer, nullptr);
#define TIMER_GET(varname, t1, t2)  varname = 1e6 * (t2.tv_sec - t1.tv_sec) + (t2.tv_usec - t1.tv_usec);

struct SpGEMM_perthread_profile {
    double preprocess, compute, postprocess, total;
    int64_t cache_miss, cache_hit;
};

struct SpGEMM_profile {
    SpGEMM_perthread_profile thread[6];
    int esize, n, annz, cnnz, compute_ncg, preprocess_ncg;
    SpGEMM_profile() : n(0) {}
    void show() {
        if(n != 0) {
            double total = thread[0].total, preprocess = thread[0].preprocess;
            double compute = thread[0].compute, postprocess = thread[0].postprocess;
            int64_t cache_miss = 0, cache_hit = 0, dma_read, dma_write;
            for(int i = 0; i < compute_ncg || i < preprocess_ncg; ++i) {
                cache_miss += thread[i].cache_miss;
                cache_hit += thread[i].cache_hit;
            }
            int64_t offset_n = (n + 1) * sizeof(Int);
            dma_read = offset_n * 2; // count_flops + scan_partition
            dma_write = offset_n;    // count_flops
            dma_read += offset_n * 2 + annz * (esize + sizeof(Int));  // a_off, nflops, a_idx, a_val
            dma_write += n * sizeof(Int) + cnnz * (esize + sizeof(Int));  // c_rnz, c_idx, c_val
            dma_read += n * sizeof(Int) + cnnz * (esize + sizeof(Int));  // c_rnz, c_idx, c_val
            dma_write += n * sizeof(Int) + cnnz * (esize + sizeof(Int));  // c_off, c_idx, c_val
            printf("n:%d, annz:%d, cnnz:%d, total:%.0lf, preprocess:%.0lf, compute:%.0lf, postprocess:%.0lf, cache_hit:%lld, cache_miss:%lld, dma_read:%lld, dma_write:%lld\n", \
                    n, annz, cnnz, total, preprocess, compute, postprocess, cache_hit, cache_miss, dma_read, dma_write);
        }
    }
} swSparse_profile;

extern "C" void swSparse_gemm_print_profile() {
    swSparse_profile.show();
}

#else
#define TIMER_SET(timer)
#define TIMER_GET(varname, t1, t2)
struct SpGEMM_Access_profile {
    double preprocess, compute, postprocess, total;
};
struct SpGEMM_profile {
    SpGEMM_Access_profile thread[6];
    int esize, n, annz, cnnz, compute_ncg, preprocess_ncg;
    SpGEMM_profile() : n(0) {}
    double show_dmaAccess() {
        //如果矩阵列数不为0
        if(n != 0) {
            double total = thread[0].total, preprocess = thread[0].preprocess;
            double compute = thread[0].compute, postprocess = thread[0].postprocess;
            int64_t  dma_read, dma_write;
            int64_t offset_n = (n + 1) * sizeof(Int);
            dma_read = offset_n * 2; // count_flops + scan_partition
            dma_write = offset_n;    // count_flops
            dma_read += offset_n * 2 + annz * (esize + sizeof(Int));  // a_off, nflops, a_idx, a_val
            dma_write += n * sizeof(Int) + cnnz * (esize + sizeof(Int));  // c_rnz, c_idx, c_val
            dma_read += n * sizeof(Int) + cnnz * (esize + sizeof(Int));  // c_rnz, c_idx, c_val
            dma_write += n * sizeof(Int) + cnnz * (esize + sizeof(Int));  // c_off, c_idx, c_val
            printf("n:%d, annz:%d, cnnz:%d, total:%.0lf, preprocess:%.0lf, compute:%.0lf, postprocess:%.0lf, dma_read:%lld, dma_write:%lld\n", \
                    n, annz, cnnz, total, preprocess, compute, postprocess, dma_read, dma_write);
            return dma_read + dma_write;//DQADD
        }
        return 0;
    }
} swSparse_profile;
extern "C" double swSparse_gemm_print_profile() {
    return swSparse_profile.show_dmaAccess();
}

#endif


namespace swSparse {

namespace I {

#define MALLOC_MASK 0x80
#define ID_MASK 0x7f
typedef uint8_t chunk_tag_t;

inline void clean_chunks(Int n, void **chunks, chunk_tag_t *chunk_id) {
    for(Int i = 0; i < n; ++i) {
        if((chunk_id[i] & MALLOC_MASK) != 0) {
            swSparse_free(chunks[i]);
        }
    }
}

ATHREAD_SPAWN_MULTICG_TEMPLATE_ARGTYPE(spgemm_hash_multicg_kernel, spgemm::arg_t)

#define PRINT_OVERFLOW \
    DEBUG_PRINTF("number of chunks too many: please set a bigger `spgemm_params::chunk_size_shift` in internal/spgemm_param.h\n")
#define MAX_CHUNK_NUM 4096

inline void check_sum(const Int* cnt, Int begin, Int end, Int expected) { // for debug
    Int s = 0;
    for(Int i = begin; i < end; ++i) { s += cnt[i]; }
    if(expected != s) {
        for(Int i = begin; i < end; ++i) {
            DEBUG_PRINTF("count[%d] = %d\n", i, cnt[i]);
        }
    }
    ASSERT_EQUAL(s, expected);
}

template<typename DATA_T>
ErrorStatus gemm_hash_omp(spgemm::arg_t<DATA_T>* args) {
    const Int cncg = args->compute_args.config & CONFIG_MASK_COMPUTE_NCG;
    const Int pncg = (args->compute_args.config & CONFIG_MASK_PREPROCESS_NCG) >> CONFIG_SHIFT_PREPROCESS_NCG;
    const Int first_cg = (args->compute_args.config & CONFIG_MASK_FIRST_CG) >> CONFIG_SHIFT_FIRST_CG;
    Int nmpe_threads = max(cncg, pncg);
    #pragma omp parallel num_threads(nmpe_threads)
    {
        Int tid = omp_get_thread_num(), cgid = tid + first_cg;
        SET_TO_SWCG(cgid);
#ifdef PROFILE_SPGEMM_MULTICG
        struct timeval timer1, timer2, timer3, timer4;
        unsigned long cache_miss[64] = {0}, cache_hit[64] = {0};
        penv_slave1_dcache_access_init();
        penv_slave2_dcache_miss_init();
#endif
        Int alloc[64], cpe_nnz[64], cgmask = 1 << cgid;
        void *buffer;
        void *chunks[MAX_CHUNK_NUM];
        void *result_chunks[MAX_CHUNK_NUM];
        uint8_t chunk_id[MAX_CHUNK_NUM];
        uint8_t *p;
        Int chunk_num = 0;
        int64_t total_c_nnz;
        auto per_thread = &args->per_thread[tid * 64];
        auto& sync_signal = args->exchange_buffer[tid].sync_signal;
        TIMER_SET(timer1)
        if(tid < cncg) {
            sync_signal = SYNC_SIGNAL_INITIAL;
            p = (uint8_t*)swSparse_malloc((sizeof(Int) + sizeof(DATA_T)) * chunk_size<DATA_T> * 64);
            IF_ERR(p == nullptr) {
                sync_signal = SYNC_SIGNAL_EXCEPT;
            } else {
                for(Int id = 0; id < 64; ++id) {
                    chunks[id] = p + (sizeof(Int) + sizeof(DATA_T)) * chunk_size<DATA_T> * id;
                    chunk_id[id] = id;
                    DATA_T *chunk = reinterpret_cast<DATA_T*>(chunks[id]);
                    // per_thread.buffer
                    per_thread[id].buffer.chunk_val = chunk;
                    per_thread[id].buffer.chunk_idx = reinterpret_cast<Int*>(chunk + chunk_size<DATA_T>);
                }
                chunk_id[0] = MALLOC_MASK;
                chunk_num = 64;
                mem_fence();
                
                athread_spawn_spgemm_hash_multicg_kernel(args, cgmask);
                while(sync_signal == SYNC_SIGNAL_INITIAL);
            }
        } else {  // then tid < pncg must hold
            // actually unreachable: always pncg <= cncg
            athread_spawn_spgemm_hash_multicg_kernel(args, cgmask);
            while(sync_signal == SYNC_SIGNAL_INITIAL);
        }

    #pragma omp barrier
        for(Int id = 0; id < cncg; ++ id) {
            if(args->exchange_buffer[id].sync_signal == SYNC_SIGNAL_EXCEPT) {
                if(sync_signal != SYNC_SIGNAL_EXCEPT) {
                    sync_signal = SYNC_SIGNAL_EXCEPT;
                    goto OMP_EXIT0; // 自己的从核已启动，需要终止
                }
                goto OMP_EXIT1;
            }
        }

        if(tid == 0) {  // prefix sum, collect partition points
#ifndef SPGEMM_PARTITION_ANNZ  // partition by flops, prefix sum, or partition by A-nnz
            int64_t prev = 0;
            // prefix sum of nflops
            for(Int id = 0; id < pncg; ++ id) {
                for(Int tid_ = 0; tid_ < 64; ++tid_) {
                    int64_t tmp_sum = args->exchange_buffer[id].i64[tid_];
                    args->exchange_buffer[id].i64[tid_] = prev;
                    prev += tmp_sum;
                }
            }
            args->exchange_buffer[0].i64[65] = prev;
            
            // sync with CPE
            mem_fence();
            for(Int id = 0; id < pncg; ++ id) {
                args->exchange_buffer[id].sync_signal = SYNC_SIGNAL_BDIST;
            }
            // CPE search dist
            for(Int id = 0; id < pncg; ++ id) {
                while(args->exchange_buffer[id].sync_signal == SYNC_SIGNAL_BDIST);
                ASSERT_EQUAL(args->exchange_buffer[id].sync_signal, SYNC_SIGNAL_EDIST);
            }
#endif      // else, signal is already SYNC_SIGNAL_EDIST
            Int cncpe = cncg * 64;  // number of CPEs in compute phase
            for(Int tid_ = 0; tid_ < cncpe; ++ tid_) {
                for(Int id = 1; id < pncg; ++ id) {  // gather the results from preprocessing CPEs
                    args->exchange_buffer[0].dist[tid_] |= args->exchange_buffer[id].dist[tid_];
                    args->exchange_buffer[0].i32[tid_] = max(args->exchange_buffer[0].i32[tid_], args->exchange_buffer[id].i32[tid_]);
                }
            }
            args->exchange_buffer[0].dist[0] = 0;
            for(Int gid = 1; gid < cncpe; ++ gid) {
                if(args->exchange_buffer[0].dist[gid] == 0) {
                    args->exchange_buffer[0].dist[gid] = args->exchange_buffer[0].dist[gid-1];
                    args->exchange_buffer[0].i32[gid] = max(args->exchange_buffer[0].i32[gid], args->exchange_buffer[0].i32[gid-1]);
                    args->exchange_buffer[0].i32[gid-1] = 0;
                }
            }
    #ifdef SWSPARSE_HAS_ASSERT
            ASSERT_EQUAL(args->exchange_buffer[0].dist[0], 0);
            for(Int gid = 0; gid < cncpe; ++ gid) {
                Int rbegin = args->exchange_buffer[0].dist[gid];
                Int rend = (gid == cncpe - 1) ? args->compute_args.m : args->exchange_buffer[0].dist[gid+1];
                Int rmax = args->exchange_buffer[0].i32[gid];
                ASSERT_LESS_EQUAL(rbegin, rend);
                if(rmax < args->compute_args.n) {
                    for(Int r = rbegin; r < rend; ++r) {
                        ASSERT_LESS_EQUAL(args->compute_args.c_row_off[r + 1], rmax);
                    }
                }
            }
    #endif
            TIMER_SET(timer2)
        }
    #pragma omp barrier
        if(tid < cncg) {
            // CPE first compute
            Int temp_size = 64 * L1_hash_size<DATA_T>, temp_off;
            for(Int id = 0; id < 64; ++id) {
                Int rmax = args->exchange_buffer[0].i32[id + tid * 64];
                cpe_nnz[id] = L2_max_size<DATA_T>(rmax);
                temp_size += cpe_nnz[id];
                ASSERT_LESS_EQUAL(rmax, args->compute_args.n);
            }
            buffer = swSparse_malloc((sizeof(Int) + sizeof(DATA_T)) * temp_size);
            if(buffer == nullptr) {
                sync_signal = SYNC_SIGNAL_EXCEPT;
            } else {
                DATA_T* temp_val = reinterpret_cast<DATA_T*>(buffer);
                Int* temp_idx = reinterpret_cast<Int*>(temp_val + temp_size);
                for(Int id = 0; id < 64; ++id) {
                    per_thread[id].buffer.L1_dump_val = temp_val;
                    per_thread[id].buffer.L1_dump_idx = temp_idx;
                    temp_val += L1_hash_size<DATA_T>;
                    temp_idx += L1_hash_size<DATA_T>;
                    per_thread[id].buffer.L2_val = temp_val;
                    per_thread[id].buffer.L2_idx = temp_idx;
                    temp_val += cpe_nnz[id];
                    temp_idx += cpe_nnz[id];
                }
                mem_fence();
                sync_signal = SYNC_SIGNAL_BCOMP;
                while(sync_signal == SYNC_SIGNAL_BCOMP);
                ASSERT_EQUAL(sync_signal, SYNC_SIGNAL_MCOMP);
                
                // perthread.state
                Int alloc_num = 0;
                for(Int id = 0; id < 64; ++id) {
                    if (per_thread[id].state.complete) {
                        cpe_nnz[id] = per_thread[id].state.total_nnz;
                        #ifdef SWSPARSE_HAS_ASSERT
                            Int gid = tid * 64 + id, rbegin = args->exchange_buffer[0].dist[gid];
                            Int rend = (gid + 1 == cncg * 64) ? args->compute_args.m : args->exchange_buffer[0].dist[gid + 1];
                            check_sum(args->compute_args.c_row_off + 1, rbegin, rend, cpe_nnz[id]);
                        #endif
                    } else {
                        alloc[alloc_num++] = id;
                    }
                }

                while(alloc_num > 0) {
                    p = (uint8_t*)swSparse_malloc((sizeof(Int) + sizeof(DATA_T)) * chunk_size<DATA_T> * alloc_num);
                    IF_ERR(p == nullptr) {
                        sync_signal = SYNC_SIGNAL_EXCEPT;
                        break;
                    }
                    IF_ERR(chunk_num >= MAX_CHUNK_NUM) {
                        PRINT_OVERFLOW;
                        sync_signal = SYNC_SIGNAL_EXCEPT;
                        break;
                    }
                    
                    for(Int id = 0; id < 64; ++id) {
                        per_thread[id].buffer.chunk_val = nullptr;
                    }
                    for(Int i = 0; i < alloc_num; ++i) {
                        chunks[chunk_num + i] = p + (sizeof(Int) + sizeof(DATA_T)) * chunk_size<DATA_T> * i;
                        chunk_id[chunk_num + i] = alloc[i];
                        DATA_T* chunk = reinterpret_cast<DATA_T*>(chunks[chunk_num + i]);
                        per_thread[alloc[i]].buffer.chunk_val = chunk;
                        per_thread[alloc[i]].buffer.chunk_idx = reinterpret_cast<Int*>(chunk + chunk_size<DATA_T>);
                    }
                    chunk_id[chunk_num] |= MALLOC_MASK;
                    chunk_num += alloc_num;
                    
                    mem_fence();
                    sync_signal = SYNC_SIGNAL_BCOMP;
                    while(sync_signal == SYNC_SIGNAL_BCOMP);
                    ASSERT_EQUAL(sync_signal, SYNC_SIGNAL_MCOMP);

                    Int count = 0;
                    for(Int i = 0; i < alloc_num; ++i) {
                        Int id = alloc[i];
                        if (per_thread[id].state.complete) {
                            cpe_nnz[id] = per_thread[id].state.total_nnz;
                            #ifdef SWSPARSE_HAS_ASSERT
                                Int gid = tid * 64 + id, rbegin = args->exchange_buffer[0].dist[gid];
                                Int rend = (gid + 1 == cncg * 64) ? args->compute_args.m : args->exchange_buffer[0].dist[gid + 1];
                                check_sum(args->compute_args.c_row_off + 1, rbegin, rend, cpe_nnz[id]);
                            #endif
                        } else {
                            alloc[count++] = id;
                        }
                    }
                    alloc_num = count;
                }

                int64_t cg_c_nnz = 0;
                for(Int id = 0; id < 64; ++id) {
                    cg_c_nnz += cpe_nnz[id];
                }
                args->exchange_buffer[2].i64[tid * 32] = cg_c_nnz;
            }
        }
    #pragma omp barrier
        TIMER_SET(timer3)
        for(Int id = 0; id < cncg; ++ id) {
            if(args->exchange_buffer[id].sync_signal == SYNC_SIGNAL_EXCEPT) {
                sync_signal = SYNC_SIGNAL_EXCEPT;
                goto OMP_EXIT0;
            }
        }
        if(tid == 0) {
            int64_t prev = 0;
            for(Int id = 0; id < cncg; ++ id) {
                int64_t tmp = args->exchange_buffer[2].i64[id * 32];
                args->exchange_buffer[2].i64[id * 32] = prev;
                prev += tmp;
            }
            total_c_nnz = prev;
        }    
    #pragma omp barrier
        if(tid < cncg) {
            int64_t previous_c_nnz = args->exchange_buffer[2].i64[tid * 32];
            Int tmp_chunk_num = 0;
            for(Int id = 0; id < 64; ++id) {
                Int cpe_c_nnz = cpe_nnz[id];
                per_thread[id].result.buffers = result_chunks + tmp_chunk_num;
                per_thread[id].result.tgt_offset = previous_c_nnz;
                per_thread[id].result.nfull = cpe_c_nnz >> chunk_size_shift<DATA_T>;
                per_thread[id].result.last = cpe_c_nnz & chunk_size_mask<DATA_T>;
                alloc[id] = tmp_chunk_num;
                tmp_chunk_num += per_thread[id].result.nfull + 1;
                previous_c_nnz += cpe_c_nnz;
            }
            #ifdef SWSPARSE_HAS_ASSERT
            Int verify_alloc[64];
            for(Int i = 0; i < 64; ++i) {
                verify_alloc[i] = alloc[i];
            }
            #endif
            
            for(Int i = 0; i < chunk_num; ++i) {
                result_chunks[alloc[chunk_id[i] & ID_MASK]++] = chunks[i];
            }
            #ifdef SWSPARSE_HAS_ASSERT
            for(Int i = 1; i < 64; ++i) {
                ASSERT_EQUAL(alloc[i-1], verify_alloc[i]);
            }
            #endif

            // COMMENT 20221118: `buffer` is accessed through CPE cache
            swSparse_free(buffer);
            
    #ifdef SWSPARSE_HAS_ASSERT
            Int gid_begin = tid * 64, rbegin_0 = args->exchange_buffer[0].dist[gid_begin], verify_previous_c_nnz = 0, cncpe = cncg * 64;
            for(Int r = 1; r <= rbegin_0; ++r) {
                verify_previous_c_nnz += args->compute_args.c_row_off[r];
            }
            for(Int id = 0; id < 64; ++id) {
                Int perthread_offset = per_thread[id].result.tgt_offset;
                ASSERT_EQUAL(verify_previous_c_nnz, perthread_offset);
                verify_previous_c_nnz += cpe_nnz[id];
            }
    #endif
        }

    #pragma omp barrier
        if(tid == 0) {
            if(total_c_nnz > 0) {
                // COMMENT 20221118: previously free'd `buffer` may be allocated again
                auto indices = (Int*)swSparse_malloc(sizeof(Int) * total_c_nnz);
                IF_ERR(indices == nullptr) {
                    sync_signal = SYNC_SIGNAL_EXCEPT;
                    goto MALLOC_FAILURE;
                }
                auto values = (DATA_T*)swSparse_malloc(sizeof(DATA_T) * total_c_nnz);
                IF_ERR(values == nullptr) {
                    sync_signal = SYNC_SIGNAL_EXCEPT;
                    swSparse_free(indices);
                    goto MALLOC_FAILURE;
                } 
                if(total_c_nnz > std::numeric_limits<Int>::max()) {
                    DEBUG_PRINTF(swSparse_int32_overflow, total_c_nnz, __FILE__, __LINE__);
                    sync_signal = SYNC_SIGNAL_EXCEPT;
                    swSparse_free(indices);
                    swSparse_free(values);
                    goto MALLOC_FAILURE;
                } 
                args->postprocess_args.c_col_idx = indices;
                args->postprocess_args.c_values = values;
                mem_fence();
                sync_signal = SYNC_SIGNAL_BPOST;
            } else {  // C is zero matrix
                args->postprocess_args.c_col_idx = nullptr;
                args->postprocess_args.c_values = nullptr;
                sync_signal = SYNC_SIGNAL_BPOST;
            }
    MALLOC_FAILURE:;
        }
    #pragma omp barrier
        if(tid != 0 && tid < cncg) {
            sync_signal = args->exchange_buffer[0].sync_signal;
        }
OMP_EXIT0:
        athread_join_cgmask(cgmask);
OMP_EXIT1:
        clean_chunks(chunk_num, chunks, chunk_id); // chunk_num == 0 if not a compute CG
#ifdef PROFILE_SPGEMM_MULTICG
    #pragma omp barrier
        TIMER_SET(timer4)
        TIMER_GET(swSparse_profile.thread[tid].preprocess, timer1, timer2)
        TIMER_GET(swSparse_profile.thread[tid].compute, timer2, timer3)
        TIMER_GET(swSparse_profile.thread[tid].postprocess, timer3, timer4)
        TIMER_GET(swSparse_profile.thread[tid].total, timer1, timer4)
        penv_slave1_dcache_access_count(cache_hit);
        penv_slave2_dcache_miss_count(cache_miss);
        unsigned long total_cache_miss = 0, total_cache_hit = 0;
        for(int i = 0; i < 64; ++i) {
            total_cache_miss += cache_miss[i];
            total_cache_hit += cache_hit[i];
        } 
        swSparse_profile.thread[tid].cache_miss = total_cache_miss;
        swSparse_profile.thread[tid].cache_hit = total_cache_hit;
#endif
    }
    for(Int id = 0; id < nmpe_threads; ++ id) {
        if(args->exchange_buffer[id].sync_signal == SYNC_SIGNAL_EXCEPT) {
            return MALLOC_ERROR;
        }
    }
    return SWSPARSE_SUCCESS;
}

inline int spgemm_compute_ncg_select(int n, int nnz) {
#ifdef MULTIPLE_CORE_GROUPS
    if (nnz <= 11050) {
        return (nnz <= 417) ? 1 : 2;
    } 
    return (nnz < min(6 * n, 156320)) ? 3 : 6;
#else
    return 1;
#endif
}

inline int spgemm_preprocess_ncg_select(int n, int nnz) {
#ifdef MULTIPLE_CORE_GROUPS
    if(nnz <= 238565) {
        return 1;
    } 
    return (nnz <= 477916) ? 3 : 6;
#else
    return 1;
#endif
}

static int spgemm_set_config(int n, int nnz, bool aconj, bool bconj) {
    int config = spgemm_compute_ncg_select(n, nnz) \
             | (spgemm_preprocess_ncg_select(n, nnz) << CONFIG_SHIFT_PREPROCESS_NCG) \
             | (current_array_id() << CONFIG_SHIFT_FIRST_CG);
    if(aconj) {
        config |= CONFIG_MASK_A_CONJUGATE;
    }
    if(bconj) {
        config |= CONFIG_MASK_B_CONJUGATE;
    }
    return config;
}

template<typename DATA_T>
ErrorStatus gemm_hash_multicg( \
    DATA_T alpha, DATA_T beta, Int m, Int n, Int k, \
    MatrixCSRC *a, MatrixCSRC *b, MatrixCSRC *d, MatrixCSRC *c, Bool a_conj, Bool b_conj) {
    spgemm::arg_t<DATA_T>* args = (spgemm::arg_t<DATA_T>*)swSparse_malloc(sizeof(spgemm::arg_t<DATA_T>));
    IF_ERR(args == nullptr) {
        return MALLOC_ERROR;
    }

    Int* offsets = (Int*)swSparse_malloc(sizeof(Int) * (m + 1));
    IF_ERR(offsets == nullptr) {
        return clean_return(MALLOC_ERROR, args);
    }
    offsets[0] = 0;
    args->compute_args.config = spgemm_set_config(m, a->offsets[m], a_conj, b_conj);
    args->compute_args.m = m;
    args->compute_args.n = n;
    args->compute_args.alpha = alpha;
    args->compute_args.beta = beta;
    args->compute_args.a_row_off = a->offsets;
    args->compute_args.a_col_idx = a->indices;
    args->compute_args.a_values = VALUES(a, DATA_T);
    args->compute_args.b_row_off = b->offsets;
    args->compute_args.b_col_idx = b->indices;
    args->compute_args.b_values = VALUES(b, DATA_T);
    args->compute_args.d_row_off = d->offsets;
    args->compute_args.d_col_idx = d->indices;
    args->compute_args.d_values = VALUES(d, DATA_T);
    args->compute_args.d_row_off = d->offsets;
    args->compute_args.d_col_idx = d->indices;
    args->compute_args.d_values = VALUES(d, DATA_T);
    args->compute_args.c_row_off = offsets;
#ifdef SPGEMM_PARTITION_ANNZ
    args->compute_args.a_nnz = a->offsets[m];
#endif

    auto ret = gemm_hash_omp(args);
    IF_ERR(ret != SWSPARSE_SUCCESS) {
        return clean_return(ret, args, offsets);
    }

    c->offsets = offsets;
    c->indices = args->postprocess_args.c_col_idx;
    c->values = args->postprocess_args.c_values;

    swSparse_free(args);
#ifdef PROFILE_SPGEMM_MULTICG
    swSparse_profile.compute_ncg = args->compute_args.config & CONFIG_MASK_COMPUTE_NCG;
    swSparse_profile.preprocess_ncg = (args->compute_args.config & CONFIG_MASK_PREPROCESS_NCG) >> CONFIG_SHIFT_PREPROCESS_NCG;
    swSparse_profile.n = m;
    swSparse_profile.annz = a->offsets[m];
    swSparse_profile.cnnz = c->offsets[m];
    //swSparse_gemm_print_profile();//DQADD
#else//DQADD
    //很奇怪，后续需要理解一下GEMM的计算过程
    swSparse_profile.compute_ncg = args->compute_args.config & CONFIG_MASK_COMPUTE_NCG;
    swSparse_profile.preprocess_ncg = (args->compute_args.config & CONFIG_MASK_PREPROCESS_NCG) >> CONFIG_SHIFT_PREPROCESS_NCG;
    swSparse_profile.n = m;
    swSparse_profile.annz = a->offsets[m];
    swSparse_profile.cnnz = c->offsets[m];
    //swSparse_gemm_print_profile();//DQADD
#endif
    
    return SWSPARSE_SUCCESS;
}

} // namespace impl

template<typename DATA_T>
INLINE ErrorStatus gemm_hash( \
    DATA_T alpha, DATA_T beta, Int m, Int n, Int k, \
    MatrixCSRC *a, MatrixCSRC *b, MatrixCSRC *d, MatrixCSRC *c, Bool a_conj, Bool b_conj) {

    ErrorStatus ret = I::gemm_hash_multicg<DATA_T>(alpha, beta, m, n, k, a, b, d, c, a_conj, b_conj);

    /* 
     * ensure order of output
     */
    if(ret == SWSPARSE_SUCCESS) {
        if(c->ordered) {
            ret = sort_elements(m, c->offsets, c->indices, VALUES(c, DATA_T));
            IF_ERR(ret != SWSPARSE_SUCCESS) {
                free_all(c->offsets, c->indices, c->values);
            } 
        }
    } 
    return ret;
}

template<typename DATA_T>
ErrorStatus gemm_csr( \
    DATA_T alpha, DATA_T beta, Int m, Int n, Int k, \
    MatrixCSRC *a, MatrixCSRC *b, MatrixCSRC *d, MatrixCSRC *c, Bool a_conj, Bool b_conj) {
    return gemm_hash<DATA_T>(alpha, beta, m, n, k, a, b, d, c, a_conj, b_conj);
}


template ErrorStatus gemm_csr<float>( \
    float alpha, float beta, Int m, Int n, Int k, \
    MatrixCSRC *a, MatrixCSRC *b, MatrixCSRC *d, MatrixCSRC *c, Bool a_conj, Bool b_conj);
template ErrorStatus gemm_csr<double>( \
    double alpha, double beta, Int m, Int n, Int k, \
    MatrixCSRC *a, MatrixCSRC *b, MatrixCSRC *d, MatrixCSRC *c, Bool a_conj, Bool b_conj);
template ErrorStatus gemm_csr<SComplex>( \
    SComplex alpha, SComplex beta, Int m, Int n, Int k, \
    MatrixCSRC *a, MatrixCSRC *b, MatrixCSRC *d, MatrixCSRC *c, Bool a_conj, Bool b_conj);
template ErrorStatus gemm_csr<DComplex>( \
    DComplex alpha, DComplex beta, Int m, Int n, Int k, \
    MatrixCSRC *a, MatrixCSRC *b, MatrixCSRC *d, MatrixCSRC *c, Bool a_conj, Bool b_conj);
}
