#include <algorithm>
#include "swSparse_trf.h"
#include "internal/templates.h"
#include "internal/memory.h"
#include "internal/rename.h"
#include "internal/reorder.h"
#include "internal/utils.h"
#include "internal/debug.h"
#include "internal/sptrf_common.h"
#include "internal/sptrf_param.h"
#include "internal/algorithm_heap.h"

#ifdef LU_PRINT_STATS
#define RECORD_STATS(a_, b_, c_, d_, e_, f_) swSparse_set_lu_stats(a_, b_, c_, d_, e_, f_)
#else
#define RECORD_STATS(a_, b_, c_, d_, e_, f_)
#endif

namespace swSparse {

ATHREAD_SPAWN_CONCRETE_ARGTYPE(sort_subtrees_kernel, sort_subtrees_arg_t)

static void athread_join_sort_subtrees(const sort_subtrees_arg_t& args) {
    if(UNLIKELY(args.temp != nullptr)) {
        swSparse_free(args.temp);
        athread_join();
    }
}

static void sort_subtree_host(const Int* offset, trf_subtree_t* subtrees) {
    for(Int tid = 0; tid < 64; ++ tid) {
        std::sort(subtrees + offset[tid], subtrees + offset[tid+1]);
    }
}

using weight_t = float;

struct weight_heap_t {
    weight_t weight;
    Int id;
};

struct get_weight_t {
    weight_t operator()(const weight_heap_t& h) const { return h.weight; }
};

inline constexpr get_weight_t get_weight;
inline constexpr Int etree_empty = -1;

class queue_scheduler {
    const Int* next_sibling;
    Int* snode_status;
    trf_task_t *result_queue;
public:
    queue_scheduler(const Int* next, Int* status, trf_task_t *queue) :
        next_sibling(next), snode_status(status), result_queue(queue) {}

    Int enqueue(Int parent_queue_id, Int first_child, Int queue_tail) {
        Int current_right = queue_tail, left_id, right_id;
        for(Int isup = first_child; isup != etree_empty; isup = next_sibling[isup]) {
            Int status = snode_status[isup];
            if(status == 0) {
                result_queue[queue_tail].parent = parent_queue_id;
                result_queue[queue_tail--].sup_id = isup;
            }
        }
        for(left_id = queue_tail + 1, right_id = current_right; left_id < right_id; ++left_id, --right_id) {
            Int left_i = result_queue[left_id].sup_id, right_i = result_queue[right_id].sup_id;
            Int left_p = result_queue[left_id].parent, right_p = result_queue[right_id].parent;
            snode_status[right_i] = left_id;
            snode_status[left_i] = right_id;
            result_queue[left_id].sup_id = right_i;
            result_queue[right_id].sup_id = left_i;
            result_queue[left_id].parent = right_p;
            result_queue[right_id].parent = left_p;
        }
        if(left_id == right_id) {
            snode_status[result_queue[left_id].sup_id] = left_id;
        }
        return queue_tail;
    }

    void set_level_info(Int q_head, Int q_tail) const {
        for(Int queue_id = q_head; queue_id > q_tail; --queue_id) {
            result_queue[queue_id].level_id = q_head - queue_id;
        }
    }
};

static void static_estimate(Int nsuper, weight_t *weight, const LUSup* lu, void* workspace, Int* marker) {
    const weight_t alpha = 14.56789f, beta = 123.456789f;
    const Int *sup2col = lu->sup2col, *col2sup = lu->col2sup;
    const Int *l_v_offsets = lu->l_v_offsets,  *l_i_offsets = lu->l_i_offsets;
    const Int *u_col_offsets = lu->u_col_offsets, *u_seg_indices = lu->u_seg_indices;
    typedef struct { weight_t kw, jw; } pair_t;
    pair_t* l_weight = (pair_t*) workspace;
    for(Int isup = 0; isup < nsuper; ++isup) {
        Int sc = sup2col[isup + 1] - sup2col[isup];
        Int sv = l_v_offsets[isup + 1] - l_v_offsets[isup];
        Int si = l_i_offsets[isup + 1] - l_i_offsets[isup];
        l_weight[isup].jw = sv + beta * (sc + si);  // sup-sup update: dense flops and sparse updates
        l_weight[isup].kw = sv * alpha;             // sup-sup update: dense mem
        weight_t w = sv * (sc + alpha);             // inner factorization
        for(Int p = u_col_offsets[sup2col[isup]], p_end = u_col_offsets[sup2col[isup + 1]]; p < p_end; ++p) {
            Int ksup = col2sup[u_seg_indices[p]];
            w += l_weight[ksup].jw;
            if(marker[ksup] != isup) {
                marker[ksup] = isup;
                w += l_weight[ksup].kw;
            }
        }
        weight[isup] = w;
        marker[isup] = 0;
    }
    weight[nsuper] = 0;
}

ErrorStatus trf_static_schedule(LUSup* lu) {
    Int nsuper = lu->nsuper;
    const Int *snode_etree = lu->sup_etree_parent;
    Int *iwork, *first_child, *next_sibling, *snode_status;
    Int nsubtree, heap_size, ichain, nsuper_subtree, nsuper_queue, temp, min_weight_cpe, xor_diff;
    weight_t sum_weight, *subtree_weight;
    weight_heap_t *heap_1, heap_2[cpe_for_subtree];
    Int nsubtree_per_cpe[cpe_for_subtree] = {0};
    trf_subtree_t* result_subtrees;
    trf_task_t* result_queue;

    static_assert(sizeof(weight_t) <= sizeof(Int));
    iwork = (Int*)swSparse_malloc(sizeof(Int) * (nsuper * 2 + 2) + sizeof(weight_t) * (nsuper + 1));
    first_child = iwork;
    next_sibling = iwork + nsuper + 1;
    subtree_weight = reinterpret_cast<weight_t*>(next_sibling + nsuper + 1);
    IF_ERR(iwork == nullptr) {
        return MALLOC_ERROR; 
    }
    
    snode_status = (Int*)swSparse_malloc(sizeof(Int) * nsuper);
    IF_ERR(snode_status == nullptr) {
        return clean_return(MALLOC_ERROR, iwork); 
    }
    heap_1 = (weight_heap_t*)swSparse_malloc(sizeof(weight_heap_t) * nsuper);
    IF_ERR(heap_1 == nullptr) {
        return clean_return(MALLOC_ERROR, iwork, snode_status); 
    }

    static_estimate(nsuper, subtree_weight, lu, iwork, snode_status);
    for(Int isup = 0; isup < nsuper; ++isup) {
        subtree_weight[snode_etree[isup]] += subtree_weight[isup];
        first_child[isup] = next_sibling[isup] = etree_empty;
        snode_status[isup] = 0;
    }
    first_child[nsuper] = next_sibling[nsuper] = etree_empty;
    for(Int isup = nsuper - 1; isup >= 0; --isup) {            // left-right order among sibllings
        Int p = snode_etree[isup], f = first_child[p];
        next_sibling[isup] = f;
        first_child[p] = isup;
    }

    /* schedule subtrees */
    heap_size = 1;
    ichain = nsuper;
    sum_weight = subtree_weight[nsuper];
    heap_1[0].id = nsuper;
    heap_1[0].weight = sum_weight;
    while (heap_size > 0 && heap_1[0].weight * cpe_for_subtree > sum_weight) {
        Int t = heap_1[0].id, f = first_child[t];
        while (f != etree_empty && next_sibling[f] == etree_empty) {  // walk through chain
            t = f;
            f = first_child[t];
        }
        // t: branch, f: first child of t
        if (f == etree_empty) { // 暂时排除无分叉的长链
            heap_1[--ichain] = heap_1[0];
            heap_1[0] = heap_1[--heap_size];
            adjust_heap_max_down(0, heap_size, heap_1, get_weight);
        } else {
            Int ch = first_child[t];
            sum_weight -= heap_1[0].weight;
            heap_1[0].id = ch;
            heap_1[0].weight = subtree_weight[ch];
            sum_weight += heap_1[0].weight;
            adjust_heap_max_down(0, heap_size, heap_1, get_weight);
            while (next_sibling[ch] != etree_empty) {
                ch = next_sibling[ch];
                heap_1[heap_size].id = ch;
                heap_1[heap_size].weight = subtree_weight[ch];
                sum_weight += heap_1[heap_size].weight;
                adjust_heap_max_up(heap_size++, heap_1, get_weight);
            }
        }
    }
    nsubtree = heap_size + nsuper - ichain;
    for(Int i = heap_size; i < nsubtree; ++ i) {
        heap_1[i] = heap_1[ichain ++];
        adjust_heap_max_up(i, heap_1, get_weight);
    }
    heap_size = nsubtree;
    while (heap_size >= cpe_for_subtree && heap_1[0].weight * cpe_for_subtree > sum_weight) { // 将最长的长链缩短
        int t = heap_1[0].id;
        sum_weight -= subtree_weight[t];
        t = first_child[t];
        if (t == etree_empty) {
            heap_1[0] = heap_1[--heap_size];
        } else {
            heap_1[0].id = t;
            heap_1[0].weight = subtree_weight[t];
            sum_weight += heap_1[0].weight;
        }
        adjust_heap_max_down(0, heap_size, heap_1, get_weight);
    }
    if(heap_size < cpe_for_subtree) {  // fall back to queue
        nsuper_subtree = nsubtree = heap_size = 0;
        result_subtrees = nullptr;
        for(Int i = 0; i <= cpe_for_subtree; ++i) {
            lu->subtree_offsets[i] = 0;
        }
    } else {
        nsubtree = heap_size;
        
        /* schedule subtrees
        * heap_1 = { weight : weight, id : root of subtree }
        * heap_2 = { weight : weight, id : CPE id }
        */
        for(Int tid = 0; tid < cpe_for_subtree; ++ tid) {
            snode_status[heap_1[0].id] = tid - 64;
            ++nsubtree_per_cpe[tid];
            heap_2[cpe_for_subtree - 1 - tid].id = tid;
            heap_2[cpe_for_subtree - 1 - tid].weight = heap_1[0].weight;
            auto tmp = heap_1[--heap_size];
            heap_1[heap_size] = heap_1[0];
            heap_1[0] = tmp;
            adjust_heap_max_down(0, heap_size, heap_1, get_weight);
        }
        // heap_2 already sorted
        // init_heap_min(cpe_for_subtree, heap_2, get_weight);
        while(heap_size > 0) {
            Int tid = heap_2[0].id;
            snode_status[heap_1[0].id] = tid - 64;
            ++nsubtree_per_cpe[tid];
            heap_2[0].weight += heap_1[0].weight;
            auto tmp = heap_1[--heap_size];
            heap_1[heap_size] = heap_1[0];
            heap_1[0] = tmp;
            adjust_heap_max_down(0, heap_size, heap_1, get_weight);
            adjust_heap_min_down(0, cpe_for_subtree, heap_2, get_weight);
        }
        // here heap_1 is sorted

        result_subtrees = (trf_subtree_t*)swSparse_malloc(sizeof(trf_subtree_t) * nsubtree);
        IF_ERR(result_subtrees == nullptr) {
            return clean_return(MALLOC_ERROR, iwork, snode_status, heap_1); 
        }
    
        // let the scheduler enter the queue part as soon as possible
        min_weight_cpe = heap_2[0].id;
        temp = nsubtree_per_cpe[min_weight_cpe];
        nsubtree_per_cpe[min_weight_cpe] = nsubtree_per_cpe[scheduler_id];
        nsubtree_per_cpe[scheduler_id] = temp;
        min_weight_cpe -= 64;
        xor_diff = min_weight_cpe ^ (scheduler_id - 64);

        // schedule subtrees
        temp = 0;
        for(Int i = 0; i < cpe_for_subtree; ++i) {
            temp += nsubtree_per_cpe[i];
            lu->subtree_offsets[i] = temp;
        }
        lu->subtree_offsets[cpe_for_subtree] = temp;
        nsuper_subtree = 0;
        for(Int i = 0; i < nsubtree; ++i) {
            Int root = heap_1[i].id;
            Int status = snode_status[root];
            if(status == scheduler_id - 64 || status == min_weight_cpe) {
                status ^= xor_diff;
            }
            Int tid = status + 64;
            Int pos = --(lu->subtree_offsets[tid]);
            Int end = root + 1;
            Int begin = root;
            result_subtrees[pos].sup_end = end;
            while(first_child[begin] != etree_empty) {
                begin = first_child[begin];
            }
            result_subtrees[pos].sup_begin = begin;
            result_subtrees[pos].parent_task = 0;
            nsuper_subtree += end - begin;
            for(Int j = begin; j < end; ++j) {
                snode_status[j] = status;
            }
        }
    }

    nsuper_queue = nsuper - nsuper_subtree;
    swSparse_free(heap_1);

    if(UNLIKELY(nsuper_queue == 0)) {  // extremely rare: matrix is balanced reducible, no need to sort subtrees
        lu->task_queue = nullptr;
        lu->task_queue_size = 0;
        lu->subtrees = result_subtrees;
        lu->snode_status = snode_status;
        RECORD_STATS(nsubtree, nsuper_subtree, sum_weight, 0, 0, 0.0f);
        return clean_return(SWSPARSE_SUCCESS, iwork);
    } else {
        Int q_head, q_tail, q_level;

        // sort subtrees by `sup_begin` so that `fb_sup_tree` works
        sort_subtrees_arg_t sort_subtree_args;
        if(LIKELY(nsubtree < cpe_for_subtree * 8)) {
            sort_subtree_args.temp = nullptr;
        } else {    // so many subtrees that need CPE to sort
            sort_subtree_args.temp = (trf_subtree_t*)swSparse_malloc_raw(sizeof(trf_subtree_t) * nsubtree);
        }
        if(LIKELY(sort_subtree_args.temp == nullptr)) {
            sort_subtree_host(lu->subtree_offsets, result_subtrees);
        } else {
            sort_subtree_args.subtrees = result_subtrees;
            sort_subtree_args.subtree_offsets = lu->subtree_offsets;
            athread_spawn_sort_subtrees_kernel(&sort_subtree_args);
        }
    

        result_queue = (trf_task_t*)swSparse_malloc(sizeof(trf_task_t) * nsuper_queue);
        IF_ERR(result_queue == nullptr) {
            athread_join_sort_subtrees(sort_subtree_args);
            return clean_return(MALLOC_ERROR, iwork, snode_status, result_subtrees); 
        }

        // enqueue supernodes in level-set order
        q_head = nsuper_queue - 1;
        q_tail = q_head;
        queue_scheduler sched(next_sibling, snode_status, result_queue);

        q_tail = sched.enqueue(nsuper, first_child[nsuper], q_tail);
        sched.set_level_info(q_head, q_tail);
        q_level = 1;
        while(q_head != q_tail) {
            Int begin = q_head, end = q_tail;
            q_head = q_tail;
            for(Int queue_id = begin; queue_id > end; --queue_id) {
                q_tail = sched.enqueue(queue_id, first_child[result_queue[queue_id].sup_id], q_tail);
            }
            sched.set_level_info(q_head, q_tail);
            q_level += 1;
        }
        ASSERT_EQUAL(q_head, -1);
        ASSERT_EQUAL(q_tail, -1);

        athread_join_sort_subtrees(sort_subtree_args);
        for(Int i = 0; i < nsubtree; ++i) {
            Int parent_snode = snode_etree[result_subtrees[i].sup_end - 1];
            if(parent_snode < nsuper) {
                result_subtrees[i].parent_task = snode_status[parent_snode];
                ASSERT(snode_status[parent_snode] >= 0);
            } else {
                result_subtrees[i].parent_task = nsuper;
            }
        }

#ifdef SWSPARSE_HAS_ASSERT  
        for(Int i = 0; i < nsuper_queue; ++ i) {
            Int p = snode_etree[result_queue[i].sup_id];
            ASSERT_EQUAL(snode_status[result_queue[i].sup_id], i);
            if(p < nsuper) {
                ASSERT_LESS(result_queue[i].parent, nsuper_queue);
                ASSERT_EQUAL(result_queue[result_queue[i].parent].sup_id, p);
            }
        }      
        for(Int id = 0; id < 64; ++id) {
            for(Int i = lu->subtree_offsets[id]; i < lu->subtree_offsets[id + 1]; ++i) {
                Int sup_begin = result_subtrees[i].sup_begin, sup_end = result_subtrees[i].sup_end, p = snode_etree[sup_end - 1];
                if(p < nsuper) {
                    ASSERT_LESS(result_subtrees[i].parent_task, nsuper_queue);
                    ASSERT_EQUAL(result_queue[result_subtrees[i].parent_task].sup_id, p);
                }
                ASSERT(std::all_of(snode_status + sup_begin, snode_status + sup_end, [=](Int s) { return s + 64 == id; }));
                ASSERT_LESS(result_subtrees[i].sup_begin, result_subtrees[i].sup_end);
                if ( i > lu->subtree_offsets[id] ) {
                    ASSERT_LESS_EQUAL(result_subtrees[i-1].sup_end, result_subtrees[i].sup_begin);
                }
            }
        }
#endif
        RECORD_STATS(nsubtree, nsuper_subtree, sum_weight, nsuper_queue, q_level, subtree_weight[nsuper] - sum_weight);
        lu->subtrees = result_subtrees;
        lu->task_queue = result_queue;
        lu->task_queue_size = nsuper_queue;
        lu->snode_status = snode_status;
        return clean_return(SWSPARSE_SUCCESS, iwork);
    }
}

}
