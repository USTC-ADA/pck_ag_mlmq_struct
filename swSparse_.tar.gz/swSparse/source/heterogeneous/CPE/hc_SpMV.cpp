#include <cmath>
#include "internal/crts.hpp"
#include "internal/kernel_args.h"
#include "internal/memory.h"
#include "internal/templates.h"
#include "internal/CPE_utils.h"
#include "internal/swSpMV.h"
#include "internal/spmv_param.h"
#include "internal/spmv_param_cpe.h"
#include "internal/CPE_communicator.h"
#include "swSparse_base.h"

__thread_local volatile athread_rply_t reply_reduce;

using namespace swSparse;

#define Count_Slave

namespace swSparse {

    //基于SWCOO格式的SW从核SpMV函数
    template<typename DATA_T>
    NOINLINE void spmv_kernel(DATA_T *_b, const DATA_T *_x, SpMV_Slave_Info *info){

        int rid = ROW(CPE_ID);
        int cid = COL(CPE_ID);
        int id = cid + rid *  8;
        spmv_params<sizeof(DATA_T)> params;
        volatile int reply = 0;
        int COUNT = 0;
        dma_mode dma_get;
        dma_mode dma_put;
        //开辟非零元,X和B向量的LDM空间
        __attribute__((aligned(32))) DATA_T b[params.BUFFER_B];
        __attribute__((aligned(32))) DATA_T b_tmp[params.BUFFER_B];
        __attribute__((aligned(32))) DATA_T x[params.BUFFER_X];
        __attribute__((aligned(32))) DATA_T value[params.BUFFER_NNZ];
        __attribute__((aligned(32))) DATA_T b_reduce[params.BUFFER_B];
        intv16  row_col16[params.BUFFER_I];
        SpMV_Slave_TASK tasks[params.BUFFER_TASK];
        //DATA_RLC *vb = (DATA_RLC*)b;
        DATA_T tmp;
        DATA_T *ratio = (DATA_T*)info->ratio;
        DATA_T alpha,beta;


        //char sout[256];

        int    *row_col = (int*)row_col16;
        int   *_row_col = info->row_idx;
        DATA_T *_value  = (DATA_T*)(info->value);
        int i, j, k, t;
        int row_offset_record = -1;
        int size_b  = info->tile_size;
        //int size_vb = info->tile_size * Size_RLC ;
        int result = 0;

        rst_rd_communicator<doublev8,params.BUFFER_B / 8> rd_spmv(id);

        DMA_DECL_DESC(READ_WRITE);

        #ifdef Count_Slave
            unsigned long dma_start,dma_end,dmab_start,dmab_end,dmat_start,dmat_end,calc_start,calc_end,reduce_start,reduce_end,total_start,total_end;
            unsigned long dma_time,dmab_time,dmat_time,calc_time,reduce_time,total_time;
            long long nnz_tot,x_tot;
            dma_time = 0;
            dmab_time = 0;
            dmat_time = 0;
            calc_time = 0;
            reduce_time = 0;
            total_time = 0;
            nnz_tot = 0;
            x_tot = 0;
            total_start = CRTS_stime_cycle();
        #endif 

        alpha = ratio[0];
        beta  = ratio[1];

        //计算从核负责的所有任务
        for(t = 0; t < info->ntasks; t += params.BUFFER_TASK){
            
            #ifdef Count_Slave
                dmat_start = CRTS_stime_cycle();
            #endif

            int task_size = min(params.BUFFER_TASK, info->ntasks - t);
            DMA_READ(info->tasks + t, tasks, task_size * sizeof(SpMV_Slave_TASK));

            #ifdef Count_Slave
                dmat_end = CRTS_stime_cycle();
                dmat_time += dmat_end - dmat_start;
            #endif


            i = 0;    
            while(i < task_size){
                if(tasks[i].nnz_length > params.BUFFER_NNZ){    
                    //如果该小块内的非零元数量大于LDM非零元数组
                    //从矩阵块信息中读取计算信息 
                    int row_offset = tasks[i].row_offset;
                    int row_length = tasks[i].row_length;
                    int col_offset = tasks[i].col_offset;
                    int col_length = tasks[i].col_length;
                    int nnz_offset = tasks[i].nnz_offset;
                    int nnz_length = tasks[i].nnz_length;
                    int reduce_root = tasks[i].reduce_root + rid * 8;
                    int reduce_ncpe = tasks[i].reduce_ncpe;
                    bool reduce_flag = tasks[i].reduce_flag;
                    bool job         = tasks[i].job;

                    //如果需要计算
                    if (job){
                        //清空结果向量
                        if(row_offset_record != row_offset){
                            row_offset_record = row_offset;
                            for(j = 0; j < size_b; j += 1) b[j] = 0;
                        }
                        
                        #ifdef Count_Slave
                            dma_start = CRTS_stime_cycle();
                        #endif

                        //读取该矩阵块对应的X向量
                        DMA_IREAD(_x + col_offset, x, col_length*sizeof(DATA_T));

                        #ifdef Count_Slave
                            dma_end = CRTS_stime_cycle();
                            dma_time += dma_end - dma_start;
                            x_tot += col_length;
                        #endif
                        //按批计算非零元
                        for(j = 0; j < nnz_length; j += params.BUFFER_NNZ){
                            int size = min(nnz_length-j, params.BUFFER_NNZ);

                            #ifdef Count_Slave
                                dma_start = CRTS_stime_cycle();
                            #endif                      
                            //读取坐标和值
                            DMA_IREAD(_row_col + nnz_offset + j, row_col, size*sizeof(int));
                            DMA_READ (_value   + nnz_offset + j, value,   size*sizeof(DATA_T));
                        
                            #ifdef Count_Slave
                                dma_end = CRTS_stime_cycle();
                                dma_time += dma_end - dma_start;
                                nnz_tot += size;
                                calc_start = CRTS_stime_cycle();
                            #endif

                            //计算Ax=B,并提前判断alpha值,看是否可少做一次乘法
                            if (is_one(alpha)){
                                for(k = 0; k < size; k ++)
                                    b[row_col[k]>>COL_IDX_DIGITS] += value[k] * x[row_col[k]&COL_IDX_MASK];
                            }
                            else{
                               for(k = 0; k < size; k ++)
                                    b[row_col[k]>>COL_IDX_DIGITS] += alpha *  value[k] * x[row_col[k]&COL_IDX_MASK]; 
                            }

                            #ifdef Count_Slave
                                calc_end = CRTS_stime_cycle();
                                calc_time += calc_end - calc_start;
                            #endif
                        }
                    }
                    else{
                        row_offset_record = row_offset;
                        for(j = 0; j < size_b; j += 1) b[j] = 0;
                    }
                    
                    if (reduce_flag){
                        //如果该矩阵带由多个从核计算,则计算reduce结果向量B

                        #ifdef Count_Slave
                            reduce_start = CRTS_stime_cycle();
                        #endif 

                        //FUNCNAME(col_sum)(rid,reduce_root,reduce_ncpe,vb,(size_vb+3)/4);    
                        //FUNCNAME(col_sum)(rid,reduce_root,reduce_ncpe,vb,(size_b+VECTOR_LEN-1)/VECTOR_LEN);

                        //调用通信库,前面的从核只向后传递,而最后一个从核负责累加,传递过程中使用了树形加速
                        if (id == reduce_root){
                            int vid;
                            int rj;
                            for (vid = id - reduce_ncpe + 1; vid < id; vid ++){
                                CRTS_ssync_peer(vid);
                                mem_fence(); 
                                CRTS_rma_get(b_reduce, size_b*sizeof(DATA_T) , vid , b , &reply_reduce);
                                mem_fence(); 
                                for (rj = 0; rj < size_b; rj++) b[rj] += b_reduce[rj];
                                mem_fence(); 
                                CRTS_ssync_peer(vid);
                            }
                        }
                        else{
                            CRTS_ssync_peer(reduce_root);
                            // CRTS_rma_put(b, size_b*sizeof(DATA_T) , reduce_root , b_reduce , &reply_reduce);
                            CRTS_rma_wait_value (&reply_reduce, 1);
                            CRTS_ssync_peer(reduce_root);  
                        }
                        //rd_spmv.reduce_sum(reduce_root,1,reduce_ncpe,reinterpret_cast<doublev8*>(b),(size_b+8-1)/8);

                        #ifdef Count_Slave
                            reduce_end = CRTS_stime_cycle();
                            reduce_time += reduce_end - reduce_start;
                            dmab_start = CRTS_stime_cycle();
                        #endif

                        //如果是最后一个从核,负责将结果写回内存,同时检查beta是否为0,不为0则再次计算
                        if (id == reduce_root){
                            if (is_zero(beta)){
                                DMA_WRITE(_b + row_offset_record, b, row_length*sizeof(DATA_T));
                            }
                            else{
                                DMA_READ(_b + row_offset_record, b_tmp, row_length*sizeof(DATA_T));
                                for (j = 0 ; j < row_length ; j++){
                                    b[j] += beta * b_tmp[j];
                                }
                                DMA_WRITE(_b + row_offset_record, b, row_length*sizeof(DATA_T)); 

                            }
                        }

                        #ifdef Count_Slave
                            dmab_end = CRTS_stime_cycle();
                            dmab_time += dmab_end - dmab_start;
                        #endif

                    }                     
                    i ++;
                }
                else
                {   

                    //全过程同上,只是该矩阵块中非零元数非常少,只需一次计算即可全部完成
                    int sub_task_size = 1;
                    int sub_nnz_length = tasks[i].nnz_length;
                    while((i+sub_task_size) < task_size && sub_nnz_length + tasks[i+sub_task_size].nnz_length < params.BUFFER_NNZ){
                        sub_nnz_length += tasks[i+sub_task_size].nnz_length;
                        sub_task_size ++;
                    }

                    #ifdef Count_Slave
                        dma_start = CRTS_stime_cycle();
                    #endif

                    if (sub_nnz_length){
                        DMA_IREAD(_row_col + tasks[i].nnz_offset, row_col, sub_nnz_length*sizeof(int));
                        DMA_READ (_value   + tasks[i].nnz_offset, value,   sub_nnz_length*sizeof(DATA_T));
                    }

                    #ifdef Count_Slave
                        dma_end = CRTS_stime_cycle();
                        dma_time += dma_end - dma_start;
                        nnz_tot += sub_nnz_length;
                    #endif

                    int target_i = i + sub_task_size;
                    int nnz_offset_record = 0;
                    for(i; i < target_i; i ++){
                        int row_offset = tasks[i].row_offset;
                        int row_length = tasks[i].row_length;
                        int col_offset = tasks[i].col_offset;
                        int col_length = tasks[i].col_length;
                        int nnz_offset = tasks[i].nnz_offset;
                        int nnz_length = tasks[i].nnz_length;
                        int reduce_root = tasks[i].reduce_root + rid * 8;
                        int reduce_ncpe = tasks[i].reduce_ncpe;
                        bool reduce_flag = tasks[i].reduce_flag;
                        bool job         = tasks[i].job;

                        if (job){  
                            if(row_offset_record != row_offset){
                                row_offset_record = row_offset;
                                for(j = 0; j < size_b; j += 1) b[j] = 0 ;
                            }

                            #ifdef Count_Slave
                                dma_start = CRTS_stime_cycle();
                            #endif

                            DMA_READ(_x + col_offset, x, col_length*sizeof(DATA_T));

                            #ifdef Count_Slave
                                dma_end = CRTS_stime_cycle();
                                dma_time += dma_end - dma_start;
                                x_tot += col_length;
                                calc_start = CRTS_stime_cycle();
                            #endif

                            if ( is_one(alpha) ){
                                for(j = nnz_offset_record; j < nnz_offset_record + nnz_length; j ++){     
                                    b[row_col[j]>>COL_IDX_DIGITS] += value[j] * x[row_col[j]&COL_IDX_MASK];
                                }
                            }
                            else{
                                for(j = nnz_offset_record; j < nnz_offset_record + nnz_length; j ++)                         
                                    b[row_col[j]>>COL_IDX_DIGITS] += alpha * value[j] * x[row_col[j]&COL_IDX_MASK];
                            }

                            

                            #ifdef Count_Slave
                                calc_end = CRTS_stime_cycle();
                                calc_time += calc_end - calc_start;
                            #endif

                            nnz_offset_record += nnz_length;
                        }
                        else{
                            row_offset_record = row_offset;
                            for(j = 0; j < size_b; j += 1) b[j] = 0;
                        }
                            
                        if (reduce_flag){

                            #ifdef Count_Slave
                                reduce_start = CRTS_stime_cycle();
                            #endif

                            //FUNCNAME(col_sum)(rid,reduce_root,reduce_ncpe,vb,(size_vb+3)/4);
                            //FUNCNAME(col_sum)(rid,reduce_root,reduce_ncpe,vb,(size_b+VECTOR_LEN-1)/VECTOR_LEN);

                            if (id == reduce_root){
                                int vid;
                                int rj;
                                for (vid = id - reduce_ncpe + 1; vid < id; vid ++){
                                    CRTS_ssync_peer(vid);
                                    mem_fence(); 
                                    CRTS_rma_get(b_reduce, size_b*sizeof(DATA_T) , vid , b , &reply_reduce);
                                    mem_fence(); 
                                    for (rj = 0; rj < size_b; rj++) b[rj] += b_reduce[rj];
                                    mem_fence(); 
                                    CRTS_ssync_peer(vid);
                                }
                            }
                            else{
                                CRTS_ssync_peer(reduce_root);
                                // CRTS_rma_put(b, size_b*sizeof(DATA_T) , reduce_root , b_reduce , &reply_reduce);
                                CRTS_rma_wait_value (&reply_reduce, 1);
                                CRTS_ssync_peer(reduce_root);  
                            }
                            //rd_spmv.reduce_sum(reduce_root,1,reduce_ncpe,reinterpret_cast<doublev8*>(b),(size_b+sizeof(DATA_T)-1)/sizeof(DATA_T));

                            #ifdef Count_Slave
                                reduce_end = CRTS_stime_cycle();
                                reduce_time += reduce_end - reduce_start;
                                dmab_start = CRTS_stime_cycle();
                            #endif

                            if (id == reduce_root){
                                if (is_zero(beta) == 0){
                                    DMA_WRITE(_b + row_offset_record, b, row_length*sizeof(DATA_T));
                                }
                                else{
                                    DMA_READ(_b + row_offset_record, b_tmp, row_length*sizeof(DATA_T));
                                    for (j = 0 ; j < row_length ; j++){
                                        b[j] += beta * b_tmp[j];
                                    }
                                    DMA_WRITE(_b + row_offset_record, b, row_length*sizeof(DATA_T)); 

                                }
                            }

                            #ifdef Count_Slave
                                dmab_end = CRTS_stime_cycle();
                                dmab_time += dmab_end - dmab_start;
                            #endif

                        }



                
                    }
                }           
            } // end of while i
        }// end of for t

        #ifdef Count_Slave
            char sout[256];
            total_end = CRTS_stime_cycle();
            total_time = total_end - total_start;
            sprintf(sout,"[%d %d] %d %d %d %d %d %d %d %d\n",rid,cid,total_time , dma_time,dmab_time,dmat_time,reduce_time, calc_time,nnz_tot,x_tot);
            printf(sout);
        #endif

        return; 
    }
    //从核入口函数,转存参数信息并调用计算函数
    template<typename DATA_T>
    NOINLINE void spmv_cpe(void *p_args){

        int rid = ROW(CPE_ID);
        int cid = COL(CPE_ID);
        int id = rid + cid * 8;
        //DATA_T *b , *x;
        spmv_kernel_arg_t<DATA_T> args;
        DMA_DECL_DESC(READ_WRITE);
        DMA_READ(p_args, &args, sizeof(spmv_kernel_arg_t<DATA_T>));

        SpMV_Slave_Info info = args.infos[rid][cid];
        DATA_T *x = (DATA_T*)(info.x);
        DATA_T *b = (DATA_T*)(info.b);
        
        spmv_kernel<DATA_T>(b, x, &info);
        return;
    }


CPE_TEMPLATE_KERNEL(spmv_cpe, CACHE_IGNORE)

}


