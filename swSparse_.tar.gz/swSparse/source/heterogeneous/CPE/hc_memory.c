#include <crts.h>
#include "internal/CPE.h"
#include "internal/kernel_args.h"
#include "internal/memory.h"
#include "internal/utils.h"

#define ACTIVE_CPE_COL 8
#define MEMCPY_CHUNK 32768
#define MEMSET_CHUNK 4096

#if ACTIVE_CPE_COL == 2
#define ACTIVE_CPE 16
#define ACTIVE_CPE_SHIFT 4
#elif ACTIVE_CPE_COL == 4
#define ACTIVE_CPE 32
#define ACTIVE_CPE_SHIFT 5
#elif ACTIVE_CPE_COL == 8
#define ACTIVE_CPE 64
#define ACTIVE_CPE_SHIFT 6
#endif

void swSparse_memcpy_kernel(void *p_args) {
    unsigned char buffer[MEMCPY_CHUNK];
    DMA_DECL_DESC(READ_WRITE);
    memcpy_arg_t args;
    DMA_READ(p_args, &args, sizeof(memcpy_arg_t));
    int i;
    // int col = COL(CPE_ID), row = ROW(CPE_ID), id = col + row * ACTIVE_CPE_COL;
    int id = CPE_ID;
    size_t size, mis_align;
    void *dst_begin;
    void *dst_end;
    const void *src_begin;
    //if(col >= ACTIVE_CPE_COL) { return; }

    //DMA_READ(p_args, &args, sizeof(memcpy_arg_t));
    
    size = args.size >> ACTIVE_CPE_SHIFT;
    /* align */
    /* assert(size >= 128); */
    dst_begin = args.dst + size * id;
    dst_end = dst_begin + size;
    mis_align = (size_t)dst_begin & 127;
    if(id != 0) {
        dst_begin -= mis_align;
        mis_align = 0;
    }
    if(id != ACTIVE_CPE - 1) {
        dst_end -= (size_t)dst_end & 127;
    } else {
        dst_end = args.dst + args.size;
    }
    src_begin = args.src + (dst_begin - args.dst);
    size = dst_end - dst_begin;

    for(i = 0; i < size; i += MEMCPY_CHUNK) {
        int len = min(MEMCPY_CHUNK, size - i);
        DMA_SREAD(src_begin + i, buffer, len);
        DMA_SWRITE(dst_begin + i, buffer, len);
    }
    DMA_WAIT_ALL;
}

void swSparse_memset_kernel(void *p_args) {
    uintv16 buffer[MEMSET_CHUNK / 64];
    DMA_DECL_DESC(READ_WRITE);
    memset_arg_t args;
    DMA_READ(p_args, &args, sizeof(memset_arg_t));
    int len, i;
    // int col = COL(CPE_ID), row = ROW(CPE_ID), id = col + row * ACTIVE_CPE_COL;
    int id = CPE_ID;
    size_t size, mis_align;
    void *dst_begin;
    void *dst_end;
    uint32_t int_value = (uint32_t)args.value & 0xffu;
    int_value |= int_value << 8;
    int_value |= int_value << 16;
    uintv16 vvalue = int_value;

    for(i = 0; i < MEMSET_CHUNK / 64; i += 4) {
        buffer[i] = buffer[i+1] = buffer[i+2] = buffer[i+3] = vvalue;
    }
    
    size = args.size >> ACTIVE_CPE_SHIFT;

    /* align */
    /* assert(size >= 128); */
    dst_begin = args.dst + size * id;
    dst_end = dst_begin + size;
    mis_align = (size_t)dst_begin & 127;
    if(id != 0) {
        dst_begin -= mis_align;
    }
    if(id != ACTIVE_CPE - 1) {
        dst_end -= (size_t)dst_end & 127;
    } else {
        dst_end = args.dst + args.size;
    }
    size = dst_end - dst_begin;

    i = 0; 
    if(id == 0) {
        len = min(MEMSET_CHUNK - mis_align, size - i);
        DMA_IWRITE(dst_begin + i, buffer, len);
        i += len;
    }
    while(i < size) {
        len = min(MEMSET_CHUNK, size - i);
        DMA_IWRITE(dst_begin + i, buffer, len);
        i += len;
    }
    DMA_WAIT_ALL;
}
