#include <cmath>
#include "internal/crts.hpp"
#include "internal/kernel_args.h"
#include "internal/memory.h"
#include "internal/templates.h"
#include "internal/CPE_utils.h"
#include "internal/swSpMV.h"
#include "internal/CPE_communicator.h"
#include "swSparse_base.h"
#include "internal/utils.h"
#include "internal/CPE.h"
#include "internal/swstructSpMV.h"
#include "internal/stspmv_param.h"

#define MIN(a,b) ((a) < (b) ? (a) : (b))
#define MAX(a,b) ((a) > (b) ? (a) : (b))
#define SWAP(a,b) (tmp=(a);(a)=(b);(b)=tmp);

using namespace swSparse;

//#define Count_Slave

__thread_local volatile athread_rply_t reply_w_l, reply_e_l, reply_n_l, reply_s_l, reply_n, reply_s, reply_e, reply_w;

//计算每个从核的基本信息
static int Cal_ID(int ids[16] , int group){
  int id = -1;
  int w = -1, e = -1, n = -1, s = -1;
  //计算行列从核号
  int row = ROW(CPE_ID);
  int col = COL(CPE_ID);
  //计算东南西北从核号
  w = col - 1;
  e = col + 1;
  n = row - 1;
  s = row + 1;
  if ( col % group == 0 ) w = -1;
  if ( col % group == group-1 ) e = -1;
  if ( row % group == 0 ) n = -1;
  if ( row % group == group-1 ) s = -1;
  ids[0] = CPE_ID;
  ids[1] = row;
  ids[2] = col;
  ids[3] = w;
  ids[4] = e;
  ids[5] = n;
  ids[6] = s;
  return 0;
}

static int Calc_Idx(int *pos, int row, int nr, int *idx){

  *pos = (*pos + row) % nr;
  idx[1] = *pos;
  idx[0] = (idx[1] - 1 + nr) % nr;
  for (int i = 2 ; i <2*row+2 ; i++) idx[i] = (idx[i-1]+1) % nr;  

}

namespace swSparse {

template<typename DATA_T>
NOINLINE void stspmv_27_kernel(DATA_T *_B, const DATA_T *_A, const DATA_T *_X, int NX, int NY, int NZ, int rnnz , int *_POS , int height){
    int id = -1, rid = -1, cid = -1;
    int w = -1, e = -1, n = -1, s = -1;
    {   
        //通过调用函数,计算从核号和邻居从核信息
        int ids[16];
        Cal_ID(ids , 8);
        id  = ids[0];
        rid = ids[1];
        cid = ids[2];
        w   = ids[3];
        e   = ids[4];
        n   = ids[5];
        s   = ids[6];
    }

    stspmv_params_27<sizeof(DATA_T)> params;

    //volatile int reply_w = 0;
    //int COUNT_w = 0;
    //开辟内存对齐的数组,分别存储矩阵A,结果向量B,和乘向量X,其数组个数由空间大小决定,每个空间大小下为固定值
    __attribute((aligned(64))) DATA_T A[params.len+2][rnnz];
    __attribute((aligned(64))) DATA_T B[params.len+height * 2];
    __attribute((aligned(64))) DATA_T X[3][3][params.len+ height * 2];

    int ii, i, j, k;
    int jj;
    int il,ir,rl,rr;
    int iter;
    int  pos[27*3];
    int len,len4;
    int p;
    int now;
    int v;
    //volatile int reply = 0;
    int reply_count, reply_count_e, reply_count_w, reply_count_n, reply_count_s;
    //int COUNT_A = 0;
    char sout[256];
    int pp;


    int dma_size,len_size;

    int DZ = NZ;
    while(DZ > params.len) DZ = (DZ+1)/2;

    

    DMA_DECL_DESC(READ_WRITE);

    //DMA(dma_get, _POS, &pos[0], rnnz * 3 *sizeof(int) , &reply, COUNT);  
    DMA_READ(_POS, &pos[0], rnnz * 3 *sizeof(int));
    //reply = 0;

    //大分块循环,即NCOLS*NROWS的从核为一组,一起计算。
    //即组内的从核相通过核间通信共享X数据,此处默认值为8*8
    //因为组内从核越多,需额外读取的halo区总数就越小
    for(i = cid; i < NX; i += NCOLS){
        for(j = rid; j < NY; j += NROWS){  
        
        //垂向分块,len的大小为每次计算的行数,亦为每次DMA访存的粒度
        for(k = 0; k < NZ; k += DZ){
            len = min(DZ, NZ-k);
               
            //len4 = (len+height * 2) * params.len_RLC;

            //通信应答字预处理
            reply_n = reply_s = reply_e = reply_w = 0;
            reply_n_l = reply_s_l = reply_e_l = reply_w_l = 0;
            reply_count_e = reply_count_w = reply_count_n = reply_count_s = 0;

            DMA_IREAD(_A+rnnz*(i*NZ*NY+j*NZ+k), &A[0][0], rnnz*len*sizeof(DATA_T));
            
            //垂直层高度范围预处理
            il = k - height;
            ir = k + len + height -1;
            rl = max(0,il);
            rr = min(NZ - 1 , ir);

            //X向量数组预处理,因默认空间外的halo区全为0
            for (ii = 0 ; ii < 3 ; ii++)
              for (jj = 0 ; jj< 3 ; jj++){
                  for (p = 0 ; p < params.len+height * 2 ; p++) X[ii][jj][p] =  0;
              }
            
            //根据计算范围,求DMA访存大小
            dma_size = (rr - rl + 1) * sizeof(DATA_T);
            len_size = (ir - il + 1) * sizeof(DATA_T);

            //读取自己从核对应空间柱的X
            DMA_IREAD(_X+(i+0)*NZ*NY+(j+0)*NZ+rl, &X[1][1][abs( MIN(0,il) )], dma_size);
            
            //如果从核处于西边界,且西边界外不是空间外,则读取对应halo数据的X数据
            if ( w == -1 )
            {
            if (i){
                DMA_IREAD(_X+(i-1)*NZ*NY+(j+0)*NZ+rl, &X[0][1][abs( MIN(0,il) )],dma_size);
            } 
            }

            //如果从核处于东边界,且东边界外不是空间外,则读取对应halo数据的X数据
            if ( e == -1 || i == NX-1 )
            {
            if (i != (NX - 1)){
                //DMA_IREAD( _X+(i+1)*NZ*NY+(j+0)*NZ+rl, &X[2][1][abs( MIN(0,il) )], dma_size);
                DMA_IREAD(_X+(i+1)*NZ*NY+(j+0)*NZ+rl, &X[2][1][abs( MIN(0,il) )], dma_size);
            }
            }

            //如果处于北边界
            if ( n == -1 )
            {
              //外部空间为空,则全部初始化为0
              if (j == 0){
                  for (ii= 0 ; ii < params.len+height * 2 ; ii++) X[0][0][ii] = X[1][0][ii] = X[2][0][ii] =  0;
              }  
              else{

                  //如果不在空间的角上,则读取北部3柱X数据,在角上则读取2柱
                  if (i==0) for (ii= 0 ; ii < params.len+height * 2 ; ii++) X[0][0][ii] =  0;
                  else DMA_IREAD( _X+(i-1)*NZ*NY+(j-1)*NZ+rl, &X[0][0][abs( MIN(0,il) )], dma_size);
                  
                  DMA_IREAD( _X+(i+0)*NZ*NY+(j-1)*NZ+rl, &X[1][0][abs( MIN(0,il) )], dma_size);
                  
                  if (i == NX - 1) for (ii= 0 ; ii < params.len+height * 2 ; ii++) X[2][0][ii] =  0;
                  else DMA_IREAD( _X+(i+1)*NZ*NY+(j-1)*NZ+rl, &X[2][0][abs( MIN(0,il) )], dma_size);

              }
            }     

            //如果处于南边界,整体情况和北边界相同
            if ( s == -1 || j == NY-1)
            { 
              //外部空间为空,则全部初始化为0
              if (j == NY - 1){
                  for (ii= 0 ; ii < params.len+height * 2 ; ii++) X[0][2][ii] = X[1][2][ii] = X[2][2][ii] =  0;
              }
              else{
                  //如果不在空间的角上,则读取南部3柱X数据,在角上则读取2柱
                  if (i==0) for (ii= 0 ; ii < params.len+height * 2 ; ii++) X[0][2][ii] =  0;
                  else DMA_IREAD( _X+(i-1)*NZ*NY+(j+1)*NZ+rl, &X[0][2][abs( MIN(0,il) )], dma_size);
                  
                  DMA_IREAD( _X+(i+0)*NZ*NY+(j+1)*NZ+rl, &X[1][2][abs( MIN(0,il) )], dma_size);
                  
                  if (i == NX - 1) for (ii= 0 ; ii < params.len+height * 2 ; ii++) X[2][2][ii] =  0;
                  else DMA_IREAD( _X+(i+1)*NZ*NY+(j+1)*NZ+rl, &X[2][2][abs( MIN(0,il) )], dma_size);
                  
              }
            }

            //等待所有X读取完成
            DMA_WAIT_ALL;

            //为了避免死锁,根据从核列号分奇偶处理东西向halo,区分为先发再收和先收再发
            if (cid % 2 == 0){
              
              //与东邻居交换数据
              if (e != -1 && i != NX - 1){
                  v = id + 1;
                  CRTS_ssync_peer(v);
                  mem_fence(); CRTS_rma_put(X[1][1], len_size , v , X[0][1] , &reply_w);
                  CRTS_rma_wait_value (&reply_e, 1);
              }
              //与西邻居交换数据
              if (w != -1){
                  v = id - 1;
                  CRTS_ssync_peer(v);
                  mem_fence(); CRTS_rma_put(X[1][1], len_size , v , X[2][1] , &reply_e);
                  CRTS_rma_wait_value (&reply_w, 1);
              }  
            }
            else{
              if (w != 1){
                  v = id - 1;
                  CRTS_ssync_peer(v);
                  CRTS_rma_wait_value (&reply_w, 1);  
                  mem_fence(); CRTS_rma_put(X[1][1], len_size , v , X[2][1] , &reply_e);
              }
              if (e != -1 && i != NX - 1){
                  v = id + 1;
                  CRTS_ssync_peer(v);
                  CRTS_rma_wait_value (&reply_e, 1);
                  mem_fence(); CRTS_rma_put(X[1][1], len_size , v , X[0][1], &reply_w);
              }
            }      

            DMA_WAIT_ALL;

            //为了避免死锁,根据从核行号分奇偶处理南北向halo,区分为先发再收和先收再发,原理同东西向halo
            if (rid % 2 == 0){
              //和南邻居交换数据
              if (s != -1 && j != NY-1){
                  v = id + 8; 
                  CRTS_ssync_peer(v);
                  mem_fence(); CRTS_rma_put(X[1][1], len_size , v , X[1][0], &reply_n);
                  mem_fence(); CRTS_rma_put(X[0][1], len_size , v , X[0][0], &reply_n);
                  mem_fence(); CRTS_rma_put(X[2][1], len_size , v , X[2][0], &reply_n);
                  CRTS_rma_wait_value (&reply_s, 3);
              }
              //和北邻居交换数据
              if (n != -1){ 
                  v = id - 8;
                  CRTS_ssync_peer(v);
                  mem_fence(); CRTS_rma_put(X[1][1], len_size , v , X[1][2], &reply_s);
                  mem_fence(); CRTS_rma_put(X[0][1], len_size , v , X[0][2], &reply_s);
                  mem_fence(); CRTS_rma_put(X[2][1], len_size , v , X[2][2], &reply_s);
                  CRTS_rma_wait_value (&reply_n, 3);
              }  
            }
            else{
              if (n != 1){
                  v = id - 8;
                  CRTS_ssync_peer(v);
                  CRTS_rma_wait_value (&reply_n, 3);
                  mem_fence(); CRTS_rma_put(X[1][1], len_size , v , X[1][2], &reply_s);
                  mem_fence(); CRTS_rma_put(X[0][1], len_size , v , X[0][2], &reply_s);
                  mem_fence(); CRTS_rma_put(X[2][1], len_size , v , X[2][2], &reply_s);
              }

              if (s != -1 && j != NY - 1){
                  v = id + 8;
                  CRTS_ssync_peer(v);
                  CRTS_rma_wait_value (&reply_s, 3);
                  mem_fence(); CRTS_rma_put(X[1][1], len_size , v , X[1][0], &reply_n);
                  mem_fence(); CRTS_rma_put(X[0][1], len_size , v , X[0][0], &reply_n);
                  mem_fence(); CRTS_rma_put(X[2][1], len_size , v , X[2][0], &reply_n);
              }
            } 

            //所有需要的X数据都收齐后开始计算,计算流程十分简单
            //根据每个非零元依赖的数据偏移,从X向量中取出对应的值,与矩阵A中对应值相乘,并累加成结果向量B          
            for ( ii = 0; ii < len; ii ++ ) 
            {
            
                DATA_T  result = 0;
                int p_;

                for (p_ = 0 ; p_ < rnnz ; p_++){
                    result += A[ii][p_] * X[1 + pos[p_*3] ][1 + pos[p_*3+1]][ii + height + pos[p_*3 + 2] ];
                }
                
                B[ii] = result;
            }

            //写回该柱的结果向量B,结束该空间块计算
            DMA_WRITE(_B+i*NZ*NY+j*NZ+k, B, len*sizeof(DATA_T));
        }
        }
        SYNC_COL;
    }
    return;
}

//计算流程与3d27完全相同,只是读取时外halo的空间判断增加到2圈,halo通信时也从收发一圈halo变两圈halo,除此之外无其他变化
template<typename DATA_T>
NOINLINE void stspmv_125_kernel(DATA_T *_B, const DATA_T *_A, const DATA_T *_X, int NX, int NY, int NZ, int rnnz , int *_POS , int height){
  int id = -1, rid = -1, cid = -1;
  int w = -1, e = -1, n = -1, s = -1;
  {
    int ids[16];
    Cal_ID(ids,8);
    id  = ids[0];
    rid = ids[1];
    cid = ids[2];
    w   = ids[3];
    e   = ids[4];
    n   = ids[5];
    s   = ids[6];
  }
  
    stspmv_params_125<sizeof(DATA_T)> params;
  

  //int rid = ROW(CPE_ID);
  //int cid = COL(CPE_ID);
  height = 2;

  __attribute((aligned(64))) DATA_T A[params.len+2][rnnz];
  __attribute((aligned(64))) DATA_T B[params.len+ height * 2];
  __attribute((aligned(64))) DATA_T X[5][5][params.len+ height * 2 ];

  //DATA_RCL* X_v4[5][5];

  int ii, i, j, k;
  int jj;
  int il,ir,rl,rr;
  int  pos[125*3];
  int p;
  int v;
  int dma_size,len_size;
  int reply_count, reply_count_e, reply_count_w, reply_count_n, reply_count_s;
  int height_now;

  int DZ = NZ;
  while(DZ > params.len) DZ = (DZ+1)/2;

  DMA_DECL_DESC(READ_WRITE);

  //DMA(dma_get, _POS, &pos[0], rnnz * 3 *sizeof(int) , &reply, COUNT)
  DMA_READ( _POS, &pos[0], rnnz * 3 *sizeof(int));

  reply_n = reply_s = reply_e = reply_w = 0;
  reply_n_l = reply_s_l = reply_e_l = reply_w_l = 0;
  reply_count_e = reply_count_w = reply_count_n = reply_count_s = 0;
  CRTS_ssync_array();
  
  for(i = cid; i < NX; i += NCOLS){
    for(j = rid; j < NY; j += NROWS){

      for(k = 0; k < NZ; k += DZ){

        int len = min(DZ, NZ-k);
                  
        dma_size = rnnz*len*sizeof(DATA_T); 
        DMA_IREAD(_A+rnnz*(i*NZ*NY+j*NZ+k), &A[0][0], rnnz*len*sizeof(DATA_T));
              
        il = k - height;
        ir = k + len + height -1;
        rl = max(0,il);
        rr = min(NZ - 1 , ir);

        for (ii = 0 ; ii < 5 ; ii++)
          for (jj = 0 ; jj< 5 ; jj++){
              for (p = 0 ; p < params.len+height * 2 ; p++) X[ii][jj][p] =  0;
          }
        
        dma_size = (rr - rl + 1) * sizeof(DATA_T);
        //len_size = (ir - il + 1) * sizeof(DATA_T);
        len_size = (len+height * 2) * sizeof(DATA_T);
        //int len4 = (len+height * 2) * params.len_RLC;

        if (k == 0) height_now = height;
        else height_now = 0;

        DMA_IREAD( _X+(i+0)*NZ*NY+(j+0)*NZ+rl, &X[2][2][height_now],dma_size);

        if ( w == -1 )
        {
          if (i == 0){
            for (ii= 0 ; ii < params.len+height * 2 ; ii++) X[0][2][ii] = X[1][2][ii] = 0;
          } 
          else{
            DMA_IREAD( _X+(i-1)*NZ*NY+(j+0)*NZ+rl, &X[1][2][height_now], dma_size);
            DMA_IREAD( _X+(i-2)*NZ*NY+(j+0)*NZ+rl, &X[0][2][height_now], dma_size);
          } 
        }

        if ( e == -1 || i == NX-1 )
        {
          if (i == NX - 1){
            for (ii= 0 ; ii < params.len+height * 2 ; ii++) X[3][2][ii]  = X[4][2][ii] = 0;
          }
          else if (i == NX - 2){
            for (ii= 0 ; ii < params.len+height * 2 ; ii++) X[4][2][ii] = 0;
            DMA_IREAD( _X+(i+1)*NZ*NY+(j+0)*NZ+rl, &X[3][2][height_now], dma_size);
          }
          else{
            DMA_IREAD( _X+(i+1)*NZ*NY+(j+0)*NZ+rl, &X[3][2][height_now], dma_size);
            DMA_IREAD( _X+(i+2)*NZ*NY+(j+0)*NZ+rl, &X[4][2][height_now], dma_size);
          }
        }

        if ( n == -1 )
        {

          if (j == 0){
            for (ii= 0 ; ii < params.len+height * 2 ; ii++) X[2][1][ii] = X[2][0][ii] =  0;
          }  
          else{
            DMA_IREAD( _X+(i+0)*NZ*NY+(j-1)*NZ+rl, &X[2][1][height_now], dma_size);
            DMA_IREAD( _X+(i+0)*NZ*NY+(j-2)*NZ+rl, &X[2][0][height_now], dma_size);
          }
          
          if (w == -1){
            
            if (j == 0){
              for (ii= 0 ; ii < params.len+height * 2 ; ii++) X[1][1][ii] = X[1][0][ii] = X[0][1][ii] = X[0][0][ii] = 0;
            }
            else if (i == 0){
              for (ii= 0 ; ii < params.len+height * 2 ; ii++) X[1][1][ii] = X[1][0][ii] = X[0][1][ii] = X[0][0][ii] = 0;
            }
            else{
              DMA_IREAD( _X+(i-1)*NZ*NY+(j-1)*NZ+rl, &X[1][1][height_now], dma_size);
              DMA_IREAD( _X+(i-1)*NZ*NY+(j-2)*NZ+rl, &X[1][0][height_now], dma_size);
              DMA_IREAD( _X+(i-2)*NZ*NY+(j-1)*NZ+rl, &X[0][1][height_now], dma_size);
              DMA_IREAD( _X+(i-2)*NZ*NY+(j-2)*NZ+rl, &X[0][0][height_now], dma_size);
            }

          }

          if (e == -1){

            if (j == 0){
              for (ii= 0 ; ii < params.len+height * 2 ; ii++) X[3][1][ii] = X[3][0][ii] = X[4][1][ii] = X[4][0][ii] = 0;  
            } 
            else if (i == NX - 1){
              for (ii= 0 ; ii < params.len+height * 2 ; ii++) X[3][1][ii] = X[3][0][ii] = X[4][1][ii] = X[4][0][ii] = 0;
            }
            else if (i == NX - 2){
              for (ii= 0 ; ii < params.len+height * 2 ; ii++) X[4][1][ii] = X[4][0][ii] = 0;
              DMA_IREAD( _X+(i+1)*NZ*NY+(j-1)*NZ+rl, &X[3][1][height_now], dma_size);
              DMA_IREAD( _X+(i+1)*NZ*NY+(j-2)*NZ+rl, &X[3][0][height_now], dma_size);
            }
            else{
              DMA_IREAD( _X+(i+1)*NZ*NY+(j-1)*NZ+rl, &X[3][1][height_now], dma_size);
              DMA_IREAD( _X+(i+1)*NZ*NY+(j-2)*NZ+rl, &X[3][0][height_now], dma_size);
              DMA_IREAD( _X+(i+2)*NZ*NY+(j-1)*NZ+rl, &X[4][1][height_now], dma_size);
              DMA_IREAD( _X+(i+2)*NZ*NY+(j-2)*NZ+rl, &X[4][0][height_now], dma_size);
            }  

          }
        }


        
      
        if ( s == -1 || j == NY-1)
        { 
          if (j == NY - 1){
            for (ii= 0 ; ii < params.len+height * 2 ; ii++) X[2][3][ii] = X[2][4][ii] =  0;
          }
          else if (j == NY -2){
            for (ii= 0 ; ii < params.len+height * 2 ; ii++) X[2][4][ii] =  0;
            DMA_IREAD( _X+(i+0)*NZ*NY+(j+1)*NZ+rl, &X[2][3][height_now], dma_size);
          }
          else{
            DMA_IREAD( _X+(i+0)*NZ*NY+(j+1)*NZ+rl, &X[2][3][height_now], dma_size);
            DMA_IREAD( _X+(i+0)*NZ*NY+(j+2)*NZ+rl, &X[2][4][height_now], dma_size);
          }

          if (w == -1){
            if (j == NY -1){
              for (ii= 0 ; ii < params.len+height * 2 ; ii++) X[1][3][ii] = X[0][3][ii] = X[1][4][ii] = X[0][4][ii] = 0;
            }
            else if(j == NY -2){
              if (i == 0 ){
                for (ii= 0 ; ii < params.len+height * 2 ; ii++) X[1][3][ii] = X[0][3][ii] = X[1][4][ii] = X[0][4][ii] = 0;
              }
              else{
                for (ii= 0 ; ii < params.len+height * 2 ; ii++) X[1][4][ii] = X[0][4][ii] = 0;
                DMA_IREAD( _X+(i-1)*NZ*NY+(j+1)*NZ+rl, &X[1][3][height_now], dma_size);
                DMA_IREAD( _X+(i-2)*NZ*NY+(j+1)*NZ+rl, &X[0][3][height_now], dma_size);
              }
            }
            else{
              if (i==0){
                for (ii= 0 ; ii < params.len+height * 2 ; ii++) X[1][3][ii] = X[0][3][ii] = X[1][4][ii] = X[0][4][ii] = 0;
              }
              else{
                DMA_IREAD( _X+(i-1)*NZ*NY+(j+1)*NZ+rl, &X[1][3][height_now], dma_size);
                DMA_IREAD( _X+(i-2)*NZ*NY+(j+1)*NZ+rl, &X[0][3][height_now], dma_size);
                DMA_IREAD( _X+(i-1)*NZ*NY+(j+2)*NZ+rl, &X[1][4][height_now], dma_size);
                DMA_IREAD( _X+(i-2)*NZ*NY+(j+2)*NZ+rl, &X[0][4][height_now], dma_size);
              }
            }   
          }

          if (e == -1){
            if (j == NY - 1){
              for (ii= 0 ; ii < params.len+height * 2 ; ii++) X[3][3][ii] = X[4][3][ii] = X[3][4][ii] = X[4][4][ii] = 0;
            }  
            else if( j == NY - 2){

              if (i == NX - 1){
                for (ii= 0 ; ii < params.len+height * 2 ; ii++) X[3][3][ii] = X[4][3][ii] = X[3][4][ii] = X[4][4][ii] = 0;
              }
              else if (i == NX - 2){
                for (ii= 0 ; ii < params.len+height * 2 ; ii++) X[4][3][ii] = X[3][4][ii] = X[4][4][ii] = 0;
                DMA_IREAD( _X+(i+1)*NZ*NY+(j+1)*NZ+rl, &X[3][3][height_now], dma_size);
              }
              else{
                for (ii= 0 ; ii < params.len+height * 2 ; ii++) X[3][4][ii] = X[4][4][ii] = 0;
                DMA_IREAD( _X+(i+1)*NZ*NY+(j+1)*NZ+rl, &X[3][3][height_now], dma_size);
                DMA_IREAD( _X+(i+2)*NZ*NY+(j+1)*NZ+rl, &X[4][3][height_now], dma_size);
              }
            }
            else{

              if (i == NX - 1){
                for (ii= 0 ; ii < params.len+height * 2 ; ii++) X[3][3][ii] = X[4][3][ii] = X[3][4][ii] = X[4][4][ii] = 0;
              }
              else if (i == NX - 2){
                for (ii= 0 ; ii < params.len+height * 2 ; ii++) X[4][3][ii] = X[4][4][ii] = 0;
                DMA_IREAD( _X+(i+1)*NZ*NY+(j+1)*NZ+rl, &X[3][3][height_now], dma_size);
                DMA_IREAD( _X+(i+1)*NZ*NY+(j+2)*NZ+rl, &X[3][4][height_now], dma_size);
              }
              else{
                DMA_IREAD( _X+(i+1)*NZ*NY+(j+1)*NZ+rl, &X[3][3][height_now], dma_size);
                DMA_IREAD( _X+(i+1)*NZ*NY+(j+2)*NZ+rl, &X[3][4][height_now], dma_size);
                DMA_IREAD( _X+(i+2)*NZ*NY+(j+1)*NZ+rl, &X[4][3][height_now], dma_size);
                DMA_IREAD( _X+(i+2)*NZ*NY+(j+2)*NZ+rl, &X[4][4][height_now], dma_size);
              }  
            }
          }
        }
      

        DMA_WAIT_ALL;

        for (ii = 0 ; ii < 5 ; ii++)
          for (jj = 0 ; jj< 5 ; jj++){
            for (p = 0 ; p < abs(min(0,il)) ; p ++) X[ii][jj][p] =  0;
            for (p = abs( min(0,il)) + (rr - rl + 1) ; p < params.len+height * 2 ; p++) X[ii][jj][p] =  0;
          }

      

        if (n == -1){
          
          if (! (w == -1 && i == NX-1) ){
          //首行左向右
            if (w == -1){
              v = id + 1;
              CRTS_ssync_peer(v);
              mem_fence(); CRTS_rma_put(X[1][0], len_size , v , X[0][0] , &reply_w);
              mem_fence(); CRTS_rma_put(X[2][0], len_size , v , X[1][0] , &reply_w);
              mem_fence(); CRTS_rma_put(X[1][1], len_size , v , X[0][1] , &reply_w);
              mem_fence(); CRTS_rma_put(X[2][1], len_size , v , X[1][1] , &reply_w);        
            }
            else if (e == -1 || i == NX - 1){
              v = id - 1;
              CRTS_ssync_peer(v);
              reply_count_w += 4;
              CRTS_rma_wait_value (&reply_w, reply_count_w);
            }
            else{
              v = id - 1;
              CRTS_ssync_peer(v);
              reply_count_w += 4;
              CRTS_rma_wait_value (&reply_w, reply_count_w);

              v = id + 1;
              CRTS_ssync_peer(v);
              mem_fence(); CRTS_rma_put(X[1][0], len_size , v , X[0][0] , &reply_w);
              mem_fence(); CRTS_rma_put(X[2][0], len_size , v , X[1][0] , &reply_w);
              mem_fence(); CRTS_rma_put(X[1][1], len_size , v , X[0][1] , &reply_w);
              mem_fence(); CRTS_rma_put(X[2][1], len_size , v , X[1][1] , &reply_w);
            }

            //首行右向左
            if (e == -1 || i == NX - 1){

              v = id - 1;
              CRTS_ssync_peer(v);
              mem_fence(); CRTS_rma_put(X[2][0], len_size , v , X[3][0] , &reply_e);
              mem_fence(); CRTS_rma_put(X[3][0], len_size , v , X[4][0] , &reply_e);
              mem_fence(); CRTS_rma_put(X[2][1], len_size , v , X[3][1] , &reply_e);
              mem_fence(); CRTS_rma_put(X[3][1], len_size , v , X[4][1] , &reply_e);
            }
            else if (w == -1){

              v = id + 1;
              reply_count_e += 4;
              CRTS_ssync_peer(v);
              CRTS_rma_wait_value (&reply_e, reply_count_e);  
            }
            else{

              v = id + 1;
              reply_count_e += 4;
              CRTS_ssync_peer(v);
              CRTS_rma_wait_value (&reply_e, reply_count_e);

              v = id - 1;
              CRTS_ssync_peer(v);
              mem_fence(); CRTS_rma_put(X[2][0], len_size , v , X[3][0] , &reply_e);
              mem_fence(); CRTS_rma_put(X[3][0], len_size , v , X[4][0] , &reply_e);
              mem_fence(); CRTS_rma_put(X[2][1], len_size , v , X[3][1] , &reply_e);
              mem_fence(); CRTS_rma_put(X[3][1], len_size , v , X[4][1] , &reply_e);
            }
          }
        }

        if (s == -1 || j == NY - 1){

          if ( ! (w == -1 && (i == NX-1)) ){
            
            //末行左向右
            if (w == -1){

              v = id + 1;
              CRTS_ssync_peer(v);
              mem_fence(); CRTS_rma_put(X[1][3], len_size , v , X[0][3] , &reply_w);
              mem_fence(); CRTS_rma_put(X[2][3], len_size , v , X[1][3] , &reply_w);
              mem_fence(); CRTS_rma_put(X[1][4], len_size , v , X[0][4] , &reply_w);
              mem_fence(); CRTS_rma_put(X[2][4], len_size , v , X[1][4] , &reply_w);        
            }
            else if (e == -1 || i == NX - 1){

              v = id - 1;
              reply_count_w += 4;
              CRTS_ssync_peer(v);
              CRTS_rma_wait_value (&reply_w, reply_count_w);
            }
            else{

              v = id - 1;
              reply_count_w += 4;
              CRTS_ssync_peer(v);
              CRTS_rma_wait_value (&reply_w, reply_count_w);

              v = id + 1;
              CRTS_ssync_peer(v);
              mem_fence(); CRTS_rma_put(X[1][3], len_size , v , X[0][3] , &reply_w);
              mem_fence(); CRTS_rma_put(X[2][3], len_size , v , X[1][3] , &reply_w);
              mem_fence(); CRTS_rma_put(X[1][4], len_size , v , X[0][4] , &reply_w);
              mem_fence(); CRTS_rma_put(X[2][4], len_size , v , X[1][4] , &reply_w);
            }  

            //末行右向左
            if (e == -1 || i == NX - 1){

              v = id - 1;
              CRTS_ssync_peer(v);
              mem_fence(); CRTS_rma_put(X[2][3], len_size , v , X[3][3] , &reply_e);
              mem_fence(); CRTS_rma_put(X[3][3], len_size , v , X[4][3] , &reply_e);
              mem_fence(); CRTS_rma_put(X[2][4], len_size , v , X[3][4] , &reply_e);
              mem_fence(); CRTS_rma_put(X[3][4], len_size , v , X[4][4] , &reply_e);
            }
            else if (w == -1){

              v = id + 1;
              reply_count_e += 4;
              CRTS_ssync_peer(v);
              CRTS_rma_wait_value (&reply_e, reply_count_e); 
          }
            else{

              v = id + 1;
              reply_count_e += 4;
              CRTS_ssync_peer(v);
              CRTS_rma_wait_value (&reply_e, reply_count_e);

              v = id - 1;
              CRTS_ssync_peer(v);
              mem_fence(); CRTS_rma_put(X[2][3], len_size , v , X[3][3] , &reply_e);
              mem_fence(); CRTS_rma_put(X[3][3], len_size , v , X[4][3] , &reply_e);
              mem_fence(); CRTS_rma_put(X[2][4], len_size , v , X[3][4] , &reply_e);
              mem_fence(); CRTS_rma_put(X[3][4], len_size , v , X[4][4] , &reply_e);
            }
          }
        }      
   
        if (! (w == -1 && i == NX-1) ){  
          //左向右
          if (w == -1){

            v = id + 1;
            CRTS_ssync_peer(v);
            mem_fence(); CRTS_rma_put(X[1][2], len_size , v , X[0][2] , &reply_w);
            mem_fence(); CRTS_rma_put(X[2][2], len_size , v , X[1][2] , &reply_w);
          }
          else if (e == -1 || i == NX - 1){

            v = id - 1;
            reply_count_w += 2;
            CRTS_ssync_peer(v);
            CRTS_rma_wait_value (&reply_w, reply_count_w);
          }
          else{
          
            v = id - 1;
            reply_count_w += 2;
            CRTS_ssync_peer(v);
            CRTS_rma_wait_value (&reply_w, reply_count_w);

            v = id + 1;
            CRTS_ssync_peer(v);
            mem_fence(); CRTS_rma_put(X[1][2], len_size , v , X[0][2] , &reply_w);
            mem_fence(); CRTS_rma_put(X[2][2], len_size , v , X[1][2] , &reply_w);
          }

          //右向左
          if (e == -1 || i == NX - 1 ){

            v = id - 1;
            CRTS_ssync_peer(v);
            mem_fence(); CRTS_rma_put(X[2][2], len_size , v , X[3][2] , &reply_e);
            mem_fence(); CRTS_rma_put(X[3][2], len_size , v , X[4][2] , &reply_e);
          }
          else if (w == -1){

            v = id + 1;
            reply_count_e += 2;
            CRTS_ssync_peer(v);
            CRTS_rma_wait_value (&reply_e, reply_count_e);         
          }
          else{

            v = id + 1;
            reply_count_e += 2;
            CRTS_ssync_peer(v);
            CRTS_rma_wait_value (&reply_e, reply_count_e);

            v = id - 1;
            CRTS_ssync_peer(v);
            mem_fence(); CRTS_rma_put(X[2][2], len_size , v , X[3][2] , &reply_e);
            mem_fence(); CRTS_rma_put(X[3][2], len_size , v , X[4][2] , &reply_e);
          }
        }
      

      

      
        if (! (n == -1 && ( j == NY - 1) ) ){
          //前向后
          if (n == -1){

            v = id + 8;
            CRTS_ssync_peer(v);

            //athread_syn(COL_SCOPE , (1 << rid) | (1 << s));
            for (jj = 0 ; jj<5 ; jj++){
              mem_fence(); CRTS_rma_put(X[jj][1], len_size , v , X[jj][0], &reply_n);
              mem_fence(); CRTS_rma_put(X[jj][2], len_size , v , X[jj][1], &reply_n);
            }
          }
          else if (s == -1 || j == NY - 1){
            v = id - 8;
            reply_count_n += 10;
            CRTS_ssync_peer(v);
            CRTS_rma_wait_value (&reply_n, reply_count_n);
          }
          else{

            v = id - 8;
            reply_count_n += 10;
            CRTS_ssync_peer(v);
            CRTS_rma_wait_value (&reply_n, reply_count_n);

            v = id + 8;
            CRTS_ssync_peer(v);
            
            //athread_syn(COL_SCOPE , (1 << rid) | (1 << s));
            for (jj = 0 ; jj<5 ; jj++){
              mem_fence(); CRTS_rma_put(X[jj][1], len_size , v , X[jj][0], &reply_n);
              mem_fence(); CRTS_rma_put(X[jj][2], len_size , v , X[jj][1], &reply_n);
            }
          }

          //后向前
          if (s == -1 || j == NY - 1){

            v = id - 8;
            CRTS_ssync_peer(v);
            for (jj = 0 ; jj<5 ; jj++){
              mem_fence(); CRTS_rma_put(X[jj][2], len_size , v , X[jj][3], &reply_s);
              mem_fence(); CRTS_rma_put(X[jj][3], len_size , v , X[jj][4], &reply_s);
            }
          }
          else if (n == -1){

            v = id + 8;
            reply_count_s += 10;
            CRTS_ssync_peer(v);
            CRTS_rma_wait_value (&reply_s, reply_count_s);
          }
          else{

            v = id + 8;
            reply_count_s += 10;
            CRTS_ssync_peer(v);
            CRTS_rma_wait_value (&reply_s, reply_count_s);
            v = id - 8;
            CRTS_ssync_peer(v);
            //athread_syn(COL_SCOPE , (1 << rid) | (1 << n));
            for (jj = 0 ; jj<5 ; jj++){
              mem_fence(); CRTS_rma_put(X[jj][2], len_size , v , X[jj][3], &reply_s);
              mem_fence(); CRTS_rma_put(X[jj][3], len_size , v , X[jj][4], &reply_s);
            }

          }
        }          

        for ( ii = 0; ii < len; ii ++ ){
          
          DATA_T  result = 0;
          int p_;

          for (p_ = 0 ; p_ < rnnz ; p_++){
           

            result += A[ii][p_] * X[2 + pos[p_*3] ][2 + pos[p_*3+1]][ii + height + pos[p_*3 + 2] ];
          }
          
          B[ii] = result;
        }
        DMA_WRITE(_B+i*NZ*NY+j*NZ+k, B, len*sizeof(DATA_T));

      }
    }
    SYNC_COL;
  }
  return;
}

//计算流程与3d27完全相同,只是读取时外halo的空间判断增加到3圈,halo通信时也从收发一圈halo变三圈halo,除此之外无其他变化
template<typename DATA_T>
NOINLINE void stspmv_343_kernel(DATA_T *_B, const DATA_T *_A, const DATA_T *_X, int NX, int NY, int NZ, int rnnz , int *_POS , int height){
  int id = -1, rid = -1, cid = -1;
  int w = -1, e = -1, n = -1, s = -1;
  {
    int ids[16];
    Cal_ID(ids,8);
    id  = ids[0];
    rid = ids[1];
    cid = ids[2];
    w   = ids[3];
    e   = ids[4];
    n   = ids[5];
    s   = ids[6];
  }

    stspmv_params_343<sizeof(DATA_T)> params;


  //int rid = ROW(CPE_ID);
  //int cid = COL(CPE_ID);
  height = 3;
  __attribute((aligned(64))) DATA_T A[params.len+2][rnnz];
  __attribute((aligned(64))) DATA_T B[params.len+ height * 2];
  __attribute((aligned(64))) DATA_T X[7][7][params.len+ height * 2];

  //DATA_RCL* X_v4[7][7];

  int ii, i, j, k;
  int jj;
  int il,ir,rl,rr;
  int  pos[343*3];
  int p;
  int v;

  int dma_size,len_size;
  int reply_count, reply_count_e, reply_count_w, reply_count_n, reply_count_s;
  int height_now;




  int DZ = NZ;
  while(DZ > params.len) DZ = (DZ+1)/2;
  DMA_DECL_DESC(READ_WRITE);
   
  //DMA(dma_get, _POS, &pos[0], rnnz * 3 *sizeof(int) , &reply, COUNT); 
  DMA_READ(_POS, &pos[0], rnnz * 3 *sizeof(int)); 

  reply_n = reply_s = reply_e = reply_w = 0;
  reply_n_l = reply_s_l = reply_e_l = reply_w_l = 0;
  reply_count_e = reply_count_w = reply_count_n = reply_count_s = 0;
  CRTS_ssync_array();

  for(i = cid; i < NX; i += NCOLS){
    for(j = rid; j < NY; j += NROWS){
      for(k = 0; k < NZ; k += DZ)
      {
        int len = min(DZ, NZ-k);
        //int len4 = (len+height * 2) * params.len_RLC;
        dma_size = rnnz*len*sizeof(DATA_T);
        
        //读自己A 

        //DMA(dma_get, _A+rnnz*(i*NZ*NY+j*NZ+k), &A[0][0], rnnz*len*sizeof(DATA_T) , &reply, COUNT); 
        DMA_READ(_A+rnnz*(i*NZ*NY+j*NZ+k), &A[0][0], rnnz*len*sizeof(DATA_T));

        il = k - height;
        ir = k + len + height -1;
        rl = max(0,il);
        rr = min(NZ - 1 , ir);

        if (k == 0) height_now = height;
        else height_now = 0;

        for (ii = 0 ; ii < 7 ; ii++)
          for (jj = 0 ; jj< 7 ; jj++){
              for (p = 0 ; p < params.len+height * 2 ; p++) X[ii][jj][p] =  0;
          }
        
        //读自己X 

        dma_size = (rr - rl + 1) * sizeof(DATA_T);
        len_size = (len+height * 2) * sizeof(DATA_T);

        DMA_IREAD( _X+(i+0)*NZ*NY+(j+0)*NZ+rl, &X[3][3][abs( MIN(0,il) )], dma_size);



        if ( w == -1 )
        {
          if (i == 0){
            for (ii= 0 ; ii < params.len+height * 2 ; ii++) X[0][3][ii] = X[1][3][ii] = X[2][3][ii] =  0;
          } 
          else{
            DMA_IREAD( _X+(i-1)*NZ*NY+(j+0)*NZ+rl, &X[2][3][height_now], dma_size);
            DMA_IREAD( _X+(i-2)*NZ*NY+(j+0)*NZ+rl, &X[1][3][height_now], dma_size);
            DMA_IREAD( _X+(i-3)*NZ*NY+(j+0)*NZ+rl, &X[0][3][height_now], dma_size);
          } 
        }

        if ( e == -1 || i == NX-1 )
        {
          if (i == NX - 1){
            for (ii= 0 ; ii < params.len+height * 2 ; ii++) X[4][3][ii]  = X[5][3][ii] = X[6][3][ii] =  0;
          }
          else if (i == NX - 2){
            for (ii= 0 ; ii < params.len+height * 2 ; ii++) X[5][3][ii] = X[6][3][ii] = 0;
            DMA_IREAD( _X+(i+1)*NZ*NY+(j+0)*NZ+rl, &X[4][3][height_now], dma_size);
          }
          else if (i == NX - 3){
            for (ii= 0 ; ii < params.len+height * 2 ; ii++) X[6][3][ii] = 0;
            DMA_IREAD( _X+(i+1)*NZ*NY+(j+0)*NZ+rl, &X[4][3][height_now], dma_size);
            DMA_IREAD( _X+(i+2)*NZ*NY+(j+0)*NZ+rl, &X[5][3][height_now], dma_size);
          }
          else{
            DMA_IREAD( _X+(i+1)*NZ*NY+(j+0)*NZ+rl, &X[4][3][height_now], dma_size);
            DMA_IREAD( _X+(i+2)*NZ*NY+(j+0)*NZ+rl, &X[5][3][height_now], dma_size);
            DMA_IREAD( _X+(i+3)*NZ*NY+(j+0)*NZ+rl, &X[6][3][height_now], dma_size);
          }
        }

        if ( n == -1 )
        {

          if (j == 0){
            for (ii= 0 ; ii < params.len+height * 2 ; ii++) X[3][0][ii] = X[3][1][ii] = X[3][2][ii] = 0;
          }  
          else{
            DMA_IREAD( _X+(i+0)*NZ*NY+(j-1)*NZ+rl, &X[3][2][height_now], dma_size);
            DMA_IREAD( _X+(i+0)*NZ*NY+(j-2)*NZ+rl, &X[3][1][height_now], dma_size);
            DMA_IREAD( _X+(i+0)*NZ*NY+(j-3)*NZ+rl, &X[3][0][height_now], dma_size);
          }
          
          if (w == -1){
            
            if (j == 0){
              for (ii = 0 ; ii < 3 ; ii++)
                for (jj = 0 ; jj < 3 ; jj++)
                  for (p = 0 ; p < params.len+height * 2 ; p++) X[ii][jj][p] = 0;
            }
            else if (i == 0){
              for (ii = 0 ; ii < 3 ; ii++)
                for (jj = 0 ; jj < 3 ; jj++)
                  for (p = 0 ; p < params.len+height * 2 ; p++) X[ii][jj][p] = 0;
            }
            else{
              for (ii = 1 ; ii <= 3 ; ii++)
                for (jj = 1 ; jj <= 3 ; jj++)
                  DMA_IREAD( _X+(i-ii)*NZ*NY+(j-jj)*NZ+rl, &X[3-ii][3-jj][height_now], dma_size);
            }

          }

          if (e == -1){

            if (j == 0){
              for (ii = 1 ; ii<=3 ; ii++)
                for (jj = 1 ; jj<=3 ; jj++)
                  for (p= 0 ; p < params.len+height * 2 ; p++) X[3 + ii][3 - jj][p] = 0;  
            } 
            else if (i == NX - 1){
              for (ii = 1 ; ii<=3 ; ii++)
                for (jj = 1 ; jj<=3 ; jj++)
                  for (p= 0 ; p < params.len+height * 2 ; p++) X[3 + ii][3 - jj][p] = 0;
            }
            else if (i == NX - 2){
              for (ii = 2 ; ii<=3 ; ii++)
                for (jj = 1 ; jj<=3 ; jj++)
                  for (p= 0 ; p < params.len+height * 2 ; p++) X[3 + ii][3 - jj][p] = 0;
              
              for (ii = 1 ; ii<=1 ; ii++)
                for (jj = 1 ; jj<=3 ; jj++)
                  DMA_IREAD( _X+(i+ii)*NZ*NY+(j-jj)*NZ+rl, &X[3 + ii][3 - jj][height_now], dma_size);
            }
            else if (i == NX - 3){
              for (ii = 3 ; ii<=3 ; ii++)
                for (jj = 1 ; jj<=3 ; jj++)
                  for (p= 0 ; p < params.len+height * 2 ; p++) X[3 + ii][3 - jj][p] = 0;
              
              for (ii = 1 ; ii<=2 ; ii++)
                for (jj = 1 ; jj<=3 ; jj++)
                  DMA_IREAD( _X+(i+ii)*NZ*NY+(j-jj)*NZ+rl, &X[3 + ii][3 - jj][height_now], dma_size);
            }
            else{
              for (ii = 1 ; ii<=3 ; ii++)
                for (jj = 1 ; jj<=3 ; jj++)
                  DMA_IREAD( _X+(i+ii)*NZ*NY+(j-jj)*NZ+rl, &X[3 + ii][3 - jj][height_now], dma_size);
            }  

          }
        }   
       
        if ( s == -1 || j == NY-1)
        { 
          if (j == NY - 1){
            for (ii= 0 ; ii < params.len+height * 2 ; ii++) X[3][4][ii] = X[3][5][ii] = X[3][6][ii] = 0;
          }
          else if (j == NY -2){
            for (ii= 0 ; ii < params.len+height * 2 ; ii++) X[3][5][ii] = X[3][6][ii] = 0;
            DMA_IREAD( _X+(i+0)*NZ*NY+(j+1)*NZ+rl, &X[3][4][height_now], dma_size);
          }
          else if (j == NY - 3){
            for (ii= 0 ; ii < params.len+height * 2 ; ii++) X[3][6][ii] = 0;
            DMA_IREAD( _X+(i+0)*NZ*NY+(j+1)*NZ+rl, &X[3][4][height_now], dma_size);
            DMA_IREAD( _X+(i+0)*NZ*NY+(j+2)*NZ+rl, &X[3][5][height_now], dma_size);
          }
          else{
            DMA_IREAD( _X+(i+0)*NZ*NY+(j+1)*NZ+rl, &X[3][4][height_now], dma_size);
            DMA_IREAD( _X+(i+0)*NZ*NY+(j+2)*NZ+rl, &X[3][5][height_now], dma_size);
            DMA_IREAD( _X+(i+0)*NZ*NY+(j+3)*NZ+rl, &X[3][6][height_now], dma_size);
          }

          if (w == -1){
            if (j == NY -1){
              for (ii = 1 ; ii <= 3 ;ii++)
                for (jj = 1 ; jj <= 3 ; jj++)
                  for (p= 0 ; p < params.len+height * 2 ; p++) X[3-ii][3+jj][p] = 0;
            }
            else if(j == NY -2){
              if (i == 0 ){
                for (ii = 1 ; ii <= 3 ;ii++)
                  for (jj = 1 ; jj <= 3 ; jj++)
                    for (p= 0 ; p < params.len+height * 2 ; p++) X[3-ii][3+jj][p] = 0;
              }
              else{
                for (ii = 1 ; ii <= 3 ;ii++)
                  for (jj = 2 ; jj <= 3 ; jj++)
                    for (p= 0 ; p < params.len+height * 2 ; p++) X[3-ii][3+jj][p] = 0;
                
                for (ii = 1 ; ii <= 3 ;ii++)
                  for (jj = 1 ; jj <= 1 ; jj++)
                    DMA_IREAD( _X+(i-ii)*NZ*NY+(j+jj)*NZ+rl, &X[ 3 - ii][3 + jj][height_now], dma_size);
              }
            }
            else if (j == NY - 3){
              if (i==0){
                for (ii = 1 ; ii <= 3 ;ii++)
                  for (jj = 1 ; jj <= 3 ; jj++)
                    for (p= 0 ; p < params.len+height * 2 ; p++) X[3-ii][3+jj][p] = 0;
              }
              else{
                for (ii = 1 ; ii <= 3 ;ii++)
                  for (jj = 3 ; jj <= 3 ; jj++)
                    for (p= 0 ; p < params.len+height * 2 ; p++) X[3-ii][3+jj][p] = 0;
                
                for (ii = 1 ; ii <= 3 ;ii++)
                  for (jj = 1 ; jj <= 2 ; jj++)
                    DMA_IREAD( _X+(i-ii)*NZ*NY+(j+jj)*NZ+rl, &X[3 - ii][3 + jj][height_now], dma_size);
              }
            }
            else{
              if (i==0){
                for (ii = 1 ; ii <= 3 ;ii++)
                  for (jj = 1 ; jj <= 3 ; jj++)
                    for (p= 0 ; p < params.len+height * 2 ; p++) X[3-ii][3+jj][p] = 0;
              }
              else{
                for (ii = 1 ; ii <= 3 ;ii++)
                  for (jj = 1 ; jj <= 3 ; jj++)
                    DMA_IREAD( _X+(i-ii)*NZ*NY+(j+jj)*NZ+rl, &X[3 - ii][3 + jj][height_now], dma_size);
              }
            }   
          }

          if (e == -1){

            for (ii = 1 ; ii <= 3 ; ii++)
              for (jj = 1 ; jj <=3 ; jj++)
                if ( (i + ii <= NX - 1) && (j +jj <= NY - 1) )
                  DMA_IREAD( _X+(i+ii)*NZ*NY+(j+jj)*NZ+rl, &X[3+ii][3+jj][height_now], dma_size);    
          }
        }

        DMA_WAIT_ALL;

        

        for (ii = 0 ; ii < 7 ; ii++)
          for (jj = 0 ; jj< 7 ; jj++){
             for (p = 0 ; p < abs(min(0,il)) ; p ++) X[ii][jj][p] =  0;
             for (p = abs( min(0,il)) + (rr - rl + 1) ; p < params.len+height * 2 ; p++) X[ii][jj][p] =  0;
          }
        
        if (n == -1){
          
          if (! (w == -1 && i == NX - 1)){

            //首行左向右
            if (w == -1){
              v = id + 1;
              CRTS_ssync_peer(v);
              for (ii=1;ii<=3;ii++)
                for (jj=0;jj<=2;jj++){
                  mem_fence();CRTS_rma_put(X[ii][jj], len_size , v , X[ii-1][jj] , &reply_w);
                }    
            }
            else if (e == -1 || i == NX - 1){
              v = id - 1;
              reply_count_w += 9;
              CRTS_ssync_peer(v);              
              CRTS_rma_wait_value (&reply_w, reply_count_w);
            }
            else{

              v = id - 1;
              reply_count_w += 9;
              CRTS_ssync_peer(v);
              CRTS_rma_wait_value (&reply_w, reply_count_w);
              v = id + 1;
              CRTS_ssync_peer(v);

              for (ii=1;ii<=3;ii++)
                for (jj=0;jj<=2;jj++){
                  mem_fence();CRTS_rma_put(X[ii][jj], len_size , v , X[ii-1][jj] , &reply_w);
                }
            }

            //首行右向左
            if (e == -1 || i == NX - 1){
              v = id - 1;
              CRTS_ssync_peer(v);
              for (ii=3;ii<=5;ii++)
                for (jj=0;jj<=2;jj++){
                  mem_fence();CRTS_rma_put(X[ii][jj], len_size , v , X[ii+1][jj] , &reply_e);
                }
            }
            else if (w == -1){
              v = id + 1;
              reply_count_e += 9;
              CRTS_ssync_peer(v);
              CRTS_rma_wait_value (&reply_e, reply_count_e); 
            }
            else{

              v = id + 1;
              reply_count_e += 9;
              CRTS_ssync_peer(v);
              CRTS_rma_wait_value (&reply_e, reply_count_e);

              v = id - 1;
              CRTS_ssync_peer(v);

              for (ii=3;ii<=5;ii++)
                for (jj=0;jj<=2;jj++){
                  mem_fence();CRTS_rma_put(X[ii][jj], len_size , v , X[ii+1][jj] , &reply_e);
                }
            }  
          }
        }


        if (s == -1 || j == NY - 1){
          
          if (! (w == -1 && i == NX - 1)){
            //末行左向右
            if (w == -1){

              v = id + 1;
              CRTS_ssync_peer(v);

              for (ii=1;ii<=3;ii++)
                for (jj=4;jj<=6;jj++){
                  mem_fence();CRTS_rma_put(X[ii][jj], len_size , v , X[ii-1][jj] , &reply_w);
                }         
            }
            else if (e == -1 || i == NX - 1){

              v = id - 1;
              reply_count_w += 9;
              CRTS_ssync_peer(v);
              CRTS_rma_wait_value (&reply_w, reply_count_w);
            }
            else{

              v = id - 1;
              reply_count_w += 9;
              CRTS_ssync_peer(v);
              CRTS_rma_wait_value (&reply_w, reply_count_w);

              v = id + 1;
              CRTS_ssync_peer(v);
              for (ii=1;ii<=3;ii++)
                for (jj=4;jj<=6;jj++){
                  mem_fence();CRTS_rma_put(X[ii][jj], len_size , v , X[ii-1][jj] , &reply_w);
                }
            }  

            //末行右向左
            if (e == -1 || i == NX - 1){
              v = id - 1;
              CRTS_ssync_peer(v);

              for (ii=3;ii<=5;ii++)
                for (jj=4;jj<=6;jj++){
                  mem_fence();CRTS_rma_put(X[ii][jj], len_size , v , X[ii+1][jj] , &reply_e);
                }
            }
            else if (w == -1){

              v = id + 1;
              reply_count_e += 9;
              CRTS_ssync_peer(v);
              CRTS_rma_wait_value (&reply_e, reply_count_e);  
            }
            else{

              v = id + 1;
              reply_count_e += 9;
              CRTS_ssync_peer(v);
              CRTS_rma_wait_value (&reply_e, reply_count_e);   

              v = id - 1;
              CRTS_ssync_peer(v);
              for (ii=3;ii<=5;ii++)
                for (jj=4;jj<=6;jj++){
                  mem_fence();CRTS_rma_put(X[ii][jj], len_size , v , X[ii+1][jj] , &reply_e);
                }
            }
          }  
        }

        if (! (w == -1 && i == NX - 1)){
          //左向右  
          if (w == -1){

            v = id + 1;
            CRTS_ssync_peer(v);
            mem_fence();CRTS_rma_put(X[1][3], len_size , v , X[0][3] , &reply_w);
            mem_fence();CRTS_rma_put(X[2][3], len_size , v , X[1][3] , &reply_w);
            mem_fence();CRTS_rma_put(X[3][3], len_size , v , X[2][3] , &reply_w);
          }
          else if (e == -1 || i == NX - 1){
            v = id - 1;
            reply_count_w += 3;
            CRTS_ssync_peer(v);
            CRTS_rma_wait_value (&reply_w, reply_count_w);
          }
          else{

            v = id - 1;
            reply_count_w += 3;
            CRTS_ssync_peer(v);
            CRTS_rma_wait_value (&reply_w, reply_count_w);

            v = id + 1;
            CRTS_ssync_peer(v);
            mem_fence();CRTS_rma_put(X[1][3], len_size , v , X[0][3] , &reply_w);
            mem_fence();CRTS_rma_put(X[2][3], len_size , v , X[1][3] , &reply_w);
            mem_fence();CRTS_rma_put(X[3][3], len_size , v , X[2][3] , &reply_w);
          }

          //右向左
          if (e == -1 || i == NX - 1 ){
            v = id - 1;
            CRTS_ssync_peer(v);
            mem_fence();CRTS_rma_put(X[3][3], len_size , v , X[4][3] , &reply_e);
            mem_fence();CRTS_rma_put(X[4][3], len_size , v , X[5][3] , &reply_e);
            mem_fence();CRTS_rma_put(X[5][3], len_size , v , X[6][3] , &reply_e);

          }
          else if (w == -1){

            v = id + 1;
            reply_count_e += 3;
            CRTS_ssync_peer(v);
            CRTS_rma_wait_value (&reply_e, reply_count_e);
        
          }
          else{

            v = id + 1;
            reply_count_e += 3;
            CRTS_ssync_peer(v);
            CRTS_rma_wait_value (&reply_e, reply_count_e);

            v = id - 1;
            CRTS_ssync_peer(v);
            mem_fence();CRTS_rma_put(X[3][3], len_size , v , X[4][3] , &reply_e);
            mem_fence();CRTS_rma_put(X[4][3], len_size , v , X[5][3] , &reply_e);
            mem_fence();CRTS_rma_put(X[5][3], len_size , v , X[6][3] , &reply_e);

          }
        }

        if (! (n == -1 && j == NY - 1) ){
          //前向后
          if (n == -1){

            v = id + 8;
            CRTS_ssync_peer(v);

            for (jj = 0 ; jj<7 ; jj++){
              mem_fence();CRTS_rma_put(X[jj][1], len_size , v , X[jj][0], &reply_n);
              mem_fence();CRTS_rma_put(X[jj][2], len_size , v , X[jj][1], &reply_n);
              mem_fence();CRTS_rma_put(X[jj][3], len_size , v , X[jj][2], &reply_n);
            }
          }
          else if (s == -1 || j == NY - 1){
            v = id - 8;
            reply_count_n += 21;
            CRTS_ssync_peer(v);
            CRTS_rma_wait_value (&reply_n, reply_count_n);
          }
          else{

            v = id - 8;
            reply_count_n += 21;
            CRTS_ssync_peer(v);
            CRTS_rma_wait_value (&reply_n, reply_count_n);

            v = id + 8;
            CRTS_ssync_peer(v);

            for (jj = 0 ; jj<7 ; jj++){
              mem_fence();CRTS_rma_put(X[jj][1], len_size , v , X[jj][0], &reply_n);
              mem_fence();CRTS_rma_put(X[jj][2], len_size , v , X[jj][1], &reply_n);
              mem_fence();CRTS_rma_put(X[jj][3], len_size , v , X[jj][2], &reply_n);
            }
          }

          //后向前
          if (s == -1 || j == NY - 1){

            v = id - 8;
            CRTS_ssync_peer(v);
            
            for (jj = 0 ; jj<7 ; jj++){
              mem_fence();CRTS_rma_put(X[jj][3], len_size , v , X[jj][4], &reply_s);
              mem_fence();CRTS_rma_put(X[jj][4], len_size , v , X[jj][5], &reply_s);
              mem_fence();CRTS_rma_put(X[jj][5], len_size , v , X[jj][6], &reply_s);
            }
          }
          else if (n == -1){

            v = id + 8;
            reply_count_s += 21;
            CRTS_ssync_peer(v);
            CRTS_rma_wait_value (&reply_s, reply_count_s);
          }
          else{

            v = id + 8;
            reply_count_s += 21;
            CRTS_ssync_peer(v);
            CRTS_rma_wait_value (&reply_s, reply_count_s);
            v = id - 8;
            CRTS_ssync_peer(v);

            for (jj = 0 ; jj<7 ; jj++){
              mem_fence();CRTS_rma_put(X[jj][3], len_size , v , X[jj][4], &reply_s);
              mem_fence();CRTS_rma_put(X[jj][4], len_size , v , X[jj][5], &reply_s);
              mem_fence();CRTS_rma_put(X[jj][5], len_size , v , X[jj][6], &reply_s);
            }
          }
        }


        
        for ( ii = 0; ii < len; ii ++ ) 
        {
          
          DATA_T result1 = 0, result0 = 0, result = 0;
          int p_;

          for (p_ = 0 ; p_ < rnnz ; p_++){            
            result += A[ii][p_] * X[3 + pos[p_*3] ][3 + pos[p_*3+1]][ii + height + pos[p_*3 + 2] ];
          }
          
          B[ii] = result;
        }

		    //DMA(dma_put, _B+i*NZ*NY+j*NZ+k, B, len*sizeof(DATA_T) , &reply, COUNT);
        DMA_WRITE(_B+i*NZ*NY+j*NZ+k, B, len*sizeof(DATA_T));

      }
    }
    SYNC_COL;
  }
  return;
}


    //不同空间大小的从核入口函数,负责将参赛结构体读入LDM,并传给从核计算函数
    template<typename DATA_T>
    NOINLINE void call_27_kernel(void *p_args){
        stspmv_kernel_arg_t<DATA_T> data;
        DMA_DECL_DESC(READ_WRITE);
        DMA_READ(p_args, &data, sizeof(stspmv_kernel_arg_t<DATA_T>));
        stspmv_27_kernel<DATA_T>((DATA_T*)data.b, (const DATA_T*)data.a, (const DATA_T*)data.x, data.lm, data.ln, data.ll,data.rnnz,data.pos,data.height);
        return;
    }

    template<typename DATA_T>
    NOINLINE void call_125_kernel(void *p_args){
        stspmv_kernel_arg_t<DATA_T> data;
        DMA_DECL_DESC(READ_WRITE);
        DMA_READ(p_args, &data, sizeof(stspmv_kernel_arg_t<DATA_T>));
        stspmv_125_kernel<DATA_T>((DATA_T*)data.b, (const DATA_T*)data.a, (const DATA_T*)data.x, data.lm, data.ln, data.ll,data.rnnz,data.pos,data.height);
        return;
    }

    template<typename DATA_T>
    NOINLINE void call_343_kernel(void *p_args){
        stspmv_kernel_arg_t<DATA_T> data;
        DMA_DECL_DESC(READ_WRITE);
        DMA_READ(p_args, &data, sizeof(stspmv_kernel_arg_t<DATA_T>));
        stspmv_343_kernel<DATA_T>((DATA_T*)data.b, (const DATA_T*)data.a, (const DATA_T*)data.x, data.lm, data.ln, data.ll,data.rnnz,data.pos,data.height);
        return;
    }



CPE_TEMPLATE_KERNEL(call_27_kernel, CACHE_IGNORE)
CPE_TEMPLATE_KERNEL(call_125_kernel, CACHE_IGNORE)
CPE_TEMPLATE_KERNEL(call_343_kernel, CACHE_IGNORE)

}