#include "swSparse_trf.h"
#include "internal/rename.h"
#include "internal/debug.h"
#include "internal/CPE.h"
#include "internal/templates.h"
#include "internal/sptrf_common.h"
#include "internal/utils.h"
#include "internal/sptrf_param.h"
#include "internal/sptrf_supfact.h"
#include "internal/sptrf_cpe.h"

namespace swSparse {
namespace supfact {

template <typename DATA_T>
template <typename PERTURB>
Int B<DATA_T>::supfact_seq(DATA_T *ldm, DATA_T *mem, Int *ipiv, Int jpanel_begin, Int jpanel_end, Int sup_size, Int sup_ld) const {
    const Int w = this->panel_size, fact_br = this->fact_block_row, trsm_br = this->trsm_block_row;
    const Int left_ld = this->left_ld_, right_ld = this->right_ld_;
    const Bool vsplit = (left_ld == right_ld);
    const Int left_brf = vsplit ? fact_br : left_ld, left_brs = vsplit ? trsm_br : left_ld, left_w = vsplit ? (w >> 1) : w;
    PERTURB perturb (this->perturb_thres, this->rcp_thres);
    DATA_T *left_buff = ldm;
    DATA_T *right_buff = ldm + left_w * left_ld;
    DATA_T *right_down = right_buff + w;
#ifdef LU_CPE_PROFILE
    unsigned long tcomm = 0, tcontmem = 0, tcomp = 0;
    DECLARE_TIMER
#endif
    for (Int jfact = jpanel_begin; jfact < jpanel_end; jfact += w) {
        Int fact_ncol = min(jpanel_end - jfact, w);
        DATA_T *temp_mem, *temp_left, *temp_right;
        DATA_T *panel_val = mem + jfact * sup_ld;
        Int *panel_ipiv = ipiv + jfact;

        // diagnal part
        const Int fact_nrow  = min(sup_ld, fact_br);
        const Int lower_nrow = fact_nrow - left_brf;

        // copy the block
        TIMER_SET(timer1)
        cached_read_mtx(right_buff, panel_val, fact_nrow, fact_ncol, right_ld, sup_ld);
        TIMER_SET(timer2)
        TIMER_GET(tcontmem, timer1, timer2)

        for (Int kfact = 0; kfact < jfact; kfact += w) {
            const Bool hsplit = (lower_nrow > 0) && (kfact < left_brf);
            const Int upper_rows = (hsplit ? left_brf : fact_nrow) - kfact;
            size_t read_len = sizeof(DATA_T) * (upper_rows - 1);
            temp_mem = mem + kfact * sup_ld + kfact + 1;
            temp_left = left_buff + 1;

            pivot_permute_dense(right_buff, ipiv + kfact, kfact, w, fact_ncol, right_ld);
                
            TIMER_SET(timer1)
            for (Int kk = 0; kk < left_w; ++kk, temp_mem += (sup_ld + 1), temp_left += (left_ld + 1), read_len -= sizeof(DATA_T)) {
                cached_read(temp_left, temp_mem, read_len);
            }
            TIMER_SET(timer2)
            temp_right = right_buff + kfact;
            this->l_trsm_update_fact(left_w, fact_ncol, left_buff, temp_right);
            this->mm_update_fact(left_w, fact_ncol, upper_rows - left_w, left_buff + left_w, temp_right, temp_right + left_w);
            TIMER_SET(timer3)
            TIMER_GET(tcontmem, timer1, timer2)
            TIMER_GET(tcomp, timer2, timer3)
            if(hsplit) {
                TIMER_SET(timer1)
                cached_read_mtx(left_buff, mem + kfact * sup_ld + left_brf, lower_nrow, left_w, left_ld, sup_ld);
                TIMER_SET(timer2)
                this->mm_update_fact(left_w, fact_ncol, lower_nrow, left_buff, temp_right, right_buff + left_brf);
                TIMER_SET(timer3)
            } else if (vsplit) {
                Int kfact_ = kfact + left_w, upper_rows_ = upper_rows - left_w;
                read_len = sizeof(DATA_T) * (upper_rows_ - 1);
                TIMER_SET(timer1)
                temp_mem = mem + kfact_ * sup_ld + kfact_ + 1;
                temp_left = left_buff + 1;
                for (Int kk = 0; kk < left_w; ++kk, temp_mem += (sup_ld + 1), temp_left += (left_ld + 1), read_len -= sizeof(DATA_T)) {
                    cached_read(temp_left, temp_mem, read_len);
                }
                TIMER_SET(timer2)
                temp_right = right_buff + kfact_;
                this->l_trsm_update_fact(left_w, fact_ncol, left_buff, temp_right);
                this->mm_update_fact(left_w, fact_ncol, upper_rows_ - left_w, left_buff + left_w, temp_right, temp_right + left_w);
                TIMER_SET(timer3)
            }
            TIMER_GET(tcontmem, timer1, timer2)
            TIMER_GET(tcomp, timer2, timer3)
        }

        // diagnal part
        // factorize diagnal block
        {
            temp_right = right_buff;
            for(Int jvec = 0; jvec < fact_ncol; jvec += simd_width<DATA_T>) {
                const Int jj_end = min(jvec + simd_width<DATA_T>, fact_ncol);
                const Int ii_end = min(jfact + jvec + simd_width<DATA_T>, fact_nrow);
                DATA_T *next = right_buff + jfact + jvec + jvec * right_ld;
                DATA_T *next_left = next + simd_width<DATA_T>;
                DATA_T *next_right = next + simd_width<DATA_T> * right_ld;
                Int rr = fact_nrow - ii_end, cc = fact_ncol - jj_end;
                for(Int jj = jvec; jj < jj_end; ++jj, temp_right += right_ld) {
                    const Int diag = jfact + jj;
                    Int ipivot = diag;
                    real_t<DATA_T> mag = fabs(temp_right[ipivot]);
                    for(Int k = ipivot + 1; k < sup_size; ++k) {
                        real_t<DATA_T> tmp = fabs(temp_right[k]);
                        if(mag < tmp) {
                            mag = tmp;
                            ipivot = k;
                        }
                    }
                    panel_ipiv[jj] = ipivot;
                    if(ipivot != diag) {
                        DATA_T *col = right_buff;
                        for(Int k = 0; k < fact_ncol; ++k, col += right_ld) {  // pivot permute all columns in the panel
                            DATA_T tmp = col[ipivot];
                            col[ipivot] = col[diag];
                            col[diag] = tmp;
                        }
                    }
                    // perturbation & scale
                    DATA_T piv = perturb.rcp_pivot(temp_right[diag], mag);
                    temp_right[diag] = piv;
                    for(Int k = diag + 1; k < ii_end; ++k) {
                        temp_right[k] *= piv;
                    }
                    if(rr > 0) {
                        this->template scale<not_conjugate<DATA_T>>(temp_right + ii_end, rr, piv);
                    }
                    DATA_T *col = temp_right + right_ld;
                    for(Int l = jj + 1; l < jj_end; ++l, col += right_ld) {
                        for(Int k = diag + 1; k < ii_end; ++k) {
                            col[k] -= col[diag] * temp_right[k];
                        }
                        if(rr > 0) {
                            this->minus_scale(col + ii_end, temp_right + ii_end, rr, col[diag]);
                        }
                    }
                }
                if(rr > 0 && cc > 0) { // TODO: rr > 0 always
                    TIMER_SET(timer1)
                    this->l_trsm_8x8(cc, next, next_right);
                    this->rank8_update(cc, rr, next_left, next_right, next_right + simd_width<DATA_T>);
                    TIMER_SET(timer2)
                    TIMER_GET(tcomp, timer1, timer2)
                }
            } 
        }
        TIMER_SET(timer1)
        cached_write_mtx(panel_val, right_buff, fact_nrow, fact_ncol, sup_ld, right_ld);
        TIMER_SET(timer2)
        TIMER_GET(tcontmem, timer1, timer2)
        
        for (Int ifact = fact_br; ifact < sup_ld; ifact += trsm_br) { // lower part
            const Int fact_nrow_ = min(sup_ld - ifact, trsm_br);
            const Int upper_nrow_ = min(sup_ld - ifact, left_brs);
            const Int lower_nrow_ = fact_nrow_ - left_brs;

            // copy the block
            TIMER_SET(timer1)
            cached_read_mtx(right_down, panel_val + ifact, fact_nrow_, fact_ncol, right_ld, sup_ld);
            TIMER_SET(timer2)
            TIMER_GET(tcontmem, timer1, timer2)

            for (Int kfact = 0; kfact < jfact; kfact += w) {
                TIMER_SET(timer1)
                cached_read_mtx(right_buff, mem + jfact * sup_ld + kfact, w, fact_ncol, right_ld, sup_ld);
                cached_read_mtx(left_buff,  mem + kfact * sup_ld + ifact, upper_nrow_, left_w, left_ld, sup_ld);
                TIMER_SET(timer2)
                this->mm_update_fact(left_w, fact_ncol, upper_nrow_, left_buff, right_buff, right_down);
                TIMER_SET(timer3)
                TIMER_GET(tcontmem, timer1, timer2)
                TIMER_GET(tcomp, timer2, timer3)

                TIMER_SET(timer1)
                if(lower_nrow_ > 0) {
                    cached_read_mtx(left_buff,  mem + kfact * sup_ld + ifact + left_brs, lower_nrow_, w, left_ld, sup_ld);
                    TIMER_SET(timer2)
                    this->mm_update_fact(w, fact_ncol, lower_nrow_, left_buff, right_buff, right_down + left_brs);
                } else if (vsplit) {
                    Int kfact_ = kfact + left_w;
                    cached_read_mtx(left_buff,  mem + kfact_ * sup_ld + ifact, upper_nrow_, left_w, left_ld, sup_ld);
                    TIMER_SET(timer2)
                    this->mm_update_fact(left_w, fact_ncol, upper_nrow_, left_buff, right_buff + left_w, right_down);
                }
                TIMER_SET(timer3)
                TIMER_GET(tcontmem, timer1, timer2)
                TIMER_GET(tcomp, timer2, timer3)
            }
            
            // copy the triangular part
            temp_mem = panel_val + jfact;
            temp_right = right_buff;
            TIMER_SET(timer1)
            for (Int jj = 0; jj < fact_ncol; ++jj, temp_mem += sup_ld, temp_right += right_ld) {
                cached_read(temp_right, temp_mem, sizeof(DATA_T) * (jj + 1));
            }
            TIMER_SET(timer2)
            this->ud_trsm(fact_ncol, fact_nrow_, right_buff, right_down);
            TIMER_SET(timer3)
            cached_write_mtx(panel_val + ifact, right_down, fact_nrow_, fact_ncol, sup_ld, right_ld);
            TIMER_SET(timer4)
            TIMER_GET(tcontmem, timer1, timer2)
            TIMER_GET(tcomp, timer2, timer3)
            TIMER_GET(tcontmem, timer3, timer4)
        }
    }
#ifdef LU_CPE_PROFILE
    this->tcomm += tcomm;
    this->tcontmem += tcontmem;
    this->tcomp += tcomp;
#endif
    return perturb.count();
}

template <typename DATA_T>
void B<DATA_T>::pivot_permute_L_seq(DATA_T *l_sup_val, Int *sup_ipiv, Int sup_size, Int sup_ld) const {
    for(Int w = this->panel_size, i_block_begin = w; i_block_begin < sup_size; i_block_begin += w) {
        Int i_block_end = min(i_block_begin + w, sup_size);
        for(Int j_block_begin = 0; j_block_begin < i_block_begin; j_block_begin += w) {
            auto block_val = l_sup_val + j_block_begin * sup_ld;

            for(Int i = i_block_begin; i < i_block_end; ++ i) {
                Int idx = sup_ipiv[i];
                if(idx != i) {
                    auto mem0 = block_val;
                    for(Int j = 0; j < w; j += 8, mem0 += sup_ld * 8) {
                        auto mem1 = mem0 + sup_ld;
                        auto mem2 = mem0 + sup_ld * 2;
                        auto mem3 = mem0 + sup_ld * 3;
                        auto mem4 = mem0 + sup_ld * 4;
                        auto mem5 = mem0 + sup_ld * 5;
                        auto mem6 = mem0 + sup_ld * 6;
                        auto mem7 = mem0 + sup_ld * 7;
                        DATA_T tt0a = mem0[i], tt0b = mem0[idx];
                        DATA_T tt1a = mem1[i], tt1b = mem1[idx];
                        DATA_T tt2a = mem2[i], tt2b = mem2[idx];
                        mem0[idx] = tt0a; mem0[i] = tt0b;
                        DATA_T tt3a = mem3[i], tt3b = mem3[idx];
                        mem1[idx] = tt1a; mem1[i] = tt1b;
                        DATA_T tt4a = mem4[i], tt4b = mem4[idx];
                        mem2[idx] = tt2a; mem2[i] = tt2b;
                        DATA_T tt5a = mem5[i], tt5b = mem5[idx];
                        mem3[idx] = tt3a; mem3[i] = tt3b;
                        DATA_T tt6a = mem6[i], tt6b = mem6[idx];
                        mem4[idx] = tt4a; mem4[i] = tt4b;
                        DATA_T tt7a = mem7[i], tt7b = mem7[idx];
                        mem5[idx] = tt5a; mem5[i] = tt5b; 
                        mem6[idx] = tt6a; mem6[i] = tt6b; 
                        mem7[idx] = tt7a; mem7[i] = tt7b;
                    }
                }
            }
        }
    }
}


template <typename DATA_T, typename PERTURB>
NOINLINE Int supfact_seq(DATA_T *ldm, DATA_T *mem, Int *ipiv, \
        Int jpanel_begin, Int jpanel_end, Int sup_size, Int sup_ld, const dense_fact_base<DATA_T>* this_) {
    return this_->template supfact_seq<PERTURB>(ldm, mem, ipiv, jpanel_begin, jpanel_end, sup_size, sup_ld);
}

template <typename DATA_T>
F<DATA_T>::F(real_t<DATA_T> thres, real_t<DATA_T> rthres, Int perturb_op) : B<DATA_T>(thres, rthres) {
    if(perturb_op == options_perturb_tiny) {
        this->fact = supfact_seq<DATA_T, perturb_tiny<DATA_T>>;
    } else if(perturb_op == options_perturb_zero) {
        this->fact = supfact_seq<DATA_T, perturb_zero<DATA_T>>;
    } else {
        this->fact = supfact_seq<DATA_T, no_perturbation>;
    }
}

#define INSTANTIATE(type) \
template F<type>::F(real_t<type> thres, real_t<type> rthres, Int perturb_op); \
template void B<type>::pivot_permute_L_seq(type *l_sup_val, Int *sup_ipiv, Int sup_size, Int sup_ld) const; 

INSTANTIATE(float)
INSTANTIATE(double)
INSTANTIATE(SComplex)
INSTANTIATE(DComplex)

} // namespace supfact
} // namespace swSparse