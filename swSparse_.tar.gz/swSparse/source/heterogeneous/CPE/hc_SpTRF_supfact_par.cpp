#include "swSparse_trf.h"
#include "internal/rename.h"
#include "internal/debug.h"
#include "internal/CPE.h"
#include "internal/templates.h"
#include "internal/sptrf_common.h"
#include "internal/utils.h"
#include "internal/sptrf_cpe.h"
#include "internal/sptrf_param.h"
#include "internal/sptrf_supfact.h"

namespace swSparse {
//void set_verbose1(bool);
//__thread_local bool verbose0 = false;
//void set_verbose0(bool x) { verbose0 = x; }

namespace rma {

struct S {  // RMA status
    rply_counter_t counter;
    crts_rply_t reply;
    S() : reply(0), counter(0) {}
    void issue(rply_counter_t inc) {
        counter += inc;
    }
    void wait() const {
        CRTS_rma_wait_value(&reply, counter);
    }
};

class C {  // contiguous array
    void* data;
    size_t data_size;
public:
    template<typename DATA_T>
    C(DATA_T *p, Int s) : data(p), data_size(s * sizeof(DATA_T)) {}
    Int num_msg() const { return 1; }
    void isend(Int target, S& status) const {
        CRTS_rma_iput(data, &status.reply, data_size, target, data, &status.reply);
    }
};

class C2 {  // 2 contiguous arrays
    C data1, data2;
public:
    template<typename DATA_1, typename DATA_2>
    C2(DATA_1 *p1, Int s1, DATA_2 *p2, Int s2) : data1(p1, s1), data2(p2, s2) {}
    Int num_msg() const { return 2; }
    void isend(Int target, S& status) const {
        data1.isend(target, status);
        data2.isend(target, status);
    }
};

class M {  // matrix
    uint8_t* data;
    size_t row_size, data_ld;
    Int col_size;
public:
    template<typename DATA_T>
    M(DATA_T *p, Int row, Int col, Int ld) 
    : data(reinterpret_cast<uint8_t*>(p)), row_size(row * sizeof(DATA_T)), col_size(col), data_ld(ld * sizeof(DATA_T)) {}
    Int num_msg() const { return col_size; }
    void isend(Int target, S& status) const {
        uint8_t* end = data + data_ld * col_size;
        for(uint8_t* temp = data; temp != end; temp += data_ld) {
            CRTS_rma_iput(temp, &status.reply, row_size, target, temp, &status.reply);
        }
    }
};

class T {  // triangular matrix, excluding diagnal
    uint8_t* data;
    Int *ipiv;
    size_t initial_send_size, ld_real, esize;
    Int col_size, col_msg;
public:
    template<typename DATA_T>
    T(DATA_T *p, Int row, Int col, Int ld, Int *ip) 
        : data(reinterpret_cast<uint8_t*>(p+1)), ipiv(ip), 
            initial_send_size((row-1) * sizeof(DATA_T)), ld_real((ld+1) * sizeof(DATA_T)), esize(sizeof(DATA_T)),
            col_size(col), col_msg(min(col, row - 1)) {} // lower triangular, the last columns are empty
    Int num_msg() const { return col_msg + 1; }
    void isend(Int target, S& status) const {
        size_t send_size = initial_send_size;
        uint8_t* end = data + ld_real * col_msg;
        for(uint8_t* temp = data; temp != end; temp += ld_real, send_size -= esize) {
            CRTS_rma_iput(temp, &status.reply, send_size, target, temp, &status.reply);
        }
        CRTS_rma_iput(ipiv, &status.reply, col_size * sizeof(Int), target, ipiv, &status.reply);
    }
};

template<typename Table>
INLINE Int rank2id(Int partner_rank, Int root_rank, Int group_size, Table partners) {
    auto pr1 = root_rank + partner_rank;
    auto pr2 = pr1 - ((pr1 >= group_size) ? group_size : 0);
    return partners[pr2];
}

// block receive, non-block send, broadcast to following `n` partners
template<typename Data>
NOINLINE void bc(Int root_rank, Int n, Int group_size, const group_communicator& comm, S& status, const Data& data) {
    if(n <= 1) return;
    const Int rank_ = comm.group_rank - root_rank, rank = rank_ + ((rank_ < 0) ? group_size : 0);
    Int high_bit, low_bit, bit, partner_rank, partner_id;
    if(rank != 0) {
        high_bit = lowest_bit(rank);
        low_bit = 0;
        partner_rank = rank ^ high_bit;
        partner_id = rank2id(partner_rank, root_rank, group_size, comm.partners);
        CRTS_ssync_peer(partner_id); // notify partner that my buffer is ready
        status.issue(data.num_msg());
        status.wait();
    } else {
        high_bit = ceil_pow_2(n);
        low_bit = 1;
        partner_id = rank2id(1, root_rank, group_size, comm.partners);  // 1 is on the critical path
        CRTS_ssync_peer(partner_id);
        status.issue(data.num_msg());
        data.isend(partner_id, status);
    }
        
    for(bit = high_bit >> 1, partner_rank = rank ^ bit; bit != low_bit; bit = bit >> 1, partner_rank = rank ^ bit) {
        if(partner_rank < n) {
            partner_id = rank2id(partner_rank, root_rank, group_size, comm.partners);
            CRTS_ssync_peer(partner_id); // ensure partner's buffer is ready
            status.issue(data.num_msg());
            data.isend(partner_id, status);
        }
    }
}

// block receive, non-block send
template<typename Data>
NOINLINE void bs(Int n, const group_communicator& comm, S& status, const Data& data) {
    const Int high_bit = ceil_pow_2(n);
    Int bit, partner_id = comm.partners[0];
    CRTS_ssync_peer(partner_id); // ensure partner's buffer is ready
    status.issue(data.num_msg());
    data.isend(partner_id, status);
    for(bit = high_bit >> 1; bit > 0; bit = bit >> 1) {
        if(bit < n) {
            partner_id = comm.partners[bit];
            CRTS_ssync_peer(partner_id); // ensure partner's buffer is ready
            status.issue(data.num_msg());
            data.isend(partner_id, status);
        }
    }
}

// block receive, non-block send
template<typename Data>
NOINLINE void br(Int root_rank, Int n, const group_communicator& comm, S& status, const Data& data) {
    const Int rank = comm.group_rank, high_bit = lowest_bit(rank);
    Int bit, partner_id, partner_rank = rank ^ high_bit;
    partner_rank = (partner_rank == 0) ? root_rank : partner_rank;
    partner_id = comm.partners[partner_rank];
    CRTS_ssync_peer(partner_id); // notify partner that my buffer is ready
    status.issue(data.num_msg());
    status.wait();
    
    if(rank != 0) {
        for(bit = high_bit >> 1, partner_rank = rank ^ bit; bit != 0; bit = bit >> 1, partner_rank = rank ^ bit) {
            if(partner_rank < n) {
                partner_id = comm.partners[partner_rank];
                CRTS_ssync_peer(partner_id); // ensure partner's buffer is ready
                status.issue(data.num_msg());
                data.isend(partner_id, status);
            }
        }
    }
}

} // namespace rma

// export
using RMA_status = rma::S;
using Contiguous = rma::C;
using Contiguous2 = rma::C2;
using Matrix = rma::M;
using Triangular = rma::T;

template<typename DATA_T>
INLINE void rma_broadcast_mat_cont(DATA_T *data, Int data_rows, Int data_cols, Int ld, \
        Int root, Int n, const group_communicator& comm, RMA_status& status) {
    if(ld - data_rows < 32 / sizeof(DATA_T)) {
        rma::bc(root, n, comm.group_size, comm, status, Contiguous(data, data_cols * ld));
    } else {
        rma::bc(root, n, comm.group_size, comm, status, Matrix(data, data_rows, data_cols, ld));
    }
}

template<typename DATA_T>
INLINE void rma_broadcast_mat_recv(DATA_T *data, Int data_rows, Int data_cols, Int ld, \
        Int root, Int n, const group_communicator& comm, RMA_status& status) {
    if(root < n) {
        if(ld - data_rows < 32 / sizeof(DATA_T)) {
            rma::bc(root, n, n, comm, status, Contiguous(data, data_cols * ld));
        } else {
            rma::bc(root, n, n, comm, status, Matrix(data, data_rows, data_cols, ld));
        }
    } else {
        if(ld - data_rows < 32 / sizeof(DATA_T)) {
            rma::br(root, n, comm, status, Contiguous(data, data_cols * ld));
        } else {
            rma::br(root, n, comm, status, Matrix(data, data_rows, data_cols, ld));
        }
    }
}

template<typename DATA_T>
INLINE void rma_broadcast_mat_send(DATA_T *data, Int data_rows, Int data_cols, Int ld, \
        Int n, const group_communicator& comm, RMA_status& status) {
    if(ld - data_rows < 32 / sizeof(DATA_T)) {
        rma::bs(n, comm, status, Contiguous(data, data_cols * ld));
    } else {
        rma::bs(n, comm, status, Matrix(data, data_rows, data_cols, ld));
    }
}

template<typename DATA_T>
INLINE void rma_broadcast_tri_cont(DATA_T *data, Int rows, Int cols, Int ld, Int *ipiv, \
        Int root, Int n, const group_communicator& comm, RMA_status& status) {
    if(ld - rows < 16 / sizeof(DATA_T)) {
        rma::bc(root, n, comm.group_size, comm, status, Contiguous2(data, ld * cols, ipiv, cols));
    } else {
        rma::bc(root, n, comm.group_size, comm, status, Triangular(data, rows, cols, ld, ipiv));
    }
}

template<typename DATA_T>
INLINE void rma_broadcast_tri_recv(DATA_T *data, Int rows, Int cols, Int ld, Int *ipiv, \
        Int root, Int n, const group_communicator& comm, RMA_status& status) {
    if(root < n) {
        if(ld - rows < 16 / sizeof(DATA_T)) {
            rma::bc(root, n, n, comm, status, Contiguous2(data, ld * cols, ipiv, cols));
        } else {
            rma::bc(root, n, n, comm, status, Triangular(data, rows, cols, ld, ipiv));
        }
    } else {
        if(ld - rows < 16 / sizeof(DATA_T)) {
            rma::br(root, n, comm, status, Contiguous2(data, ld * cols, ipiv, cols));
        } else {
            rma::br(root, n, comm, status, Triangular(data, rows, cols, ld, ipiv));
        }
    }
}

template<typename DATA_T>
INLINE void rma_broadcast_tri_send(DATA_T *data, Int rows, Int cols, Int ld, Int *ipiv, \
        Int n, const group_communicator& comm, RMA_status& status) {
    if(ld - rows < 16 / sizeof(DATA_T)) {
        rma::bs(n, comm, status, Contiguous2(data, ld * cols, ipiv, cols));
    } else {
        rma::bs(n, comm, status, Triangular(data, rows, cols, ld, ipiv));
    }
}

INLINE Int get_ncores(Int col, Int first_quit_begin, Int group_size) {
    Int t = col - first_quit_begin;
    return group_size - (((t > 0) ? t : 0) >> block_cycle_shift);
}

INLINE Int next_rank(Int src_rank, Int group_size) {
    Int temp = src_rank + 1;
    return (temp == group_size) ? 0 : temp;
}

namespace supfact {

template <typename DATA_T>
template<typename PERTURB>
Int P<DATA_T>::supfact_par(DATA_T *ldm, DATA_T *mem, Int *ipiv_ldm, Int *ipiv, \
        Int jgroup_begin, Int jgroup_end, Int sup_size, Int sup_ld) const {
    const Int npanel_max = this->panel_size >> block_cycle_shift, fact_br = this->fact_block_row, trsm_br = this->trsm_block_row;
    const Int left_ld = this->left_ld_, right_ld = this->right_ld_;
    const Bool vsplit = (left_ld == right_ld);
    const Int left_brf = vsplit ? fact_br : left_ld, left_brs = vsplit ? trsm_br : left_ld;
    const Int group_cycle_size = (comm.group_size << block_cycle_shift);
    const Int group_panel_size = group_cycle_size * npanel_max;
    RMA_status rma_status;
    PERTURB perturb (this->perturb_thres, this->rcp_thres);
    DATA_T *left_buff = ldm;
    DATA_T *right_buff = ldm + (left_ld << block_cycle_shift);
    DATA_T *right_down = right_buff + block_cycle_size;

    const Int gsize = comm.group_size;
    const Int fact_nrow  = min(sup_ld, fact_br);
    const Int lower_nrow = fact_nrow - left_brf;
    const Int offset = (comm.group_rank << block_cycle_shift);
#ifdef LU_CPE_PROFILE
    unsigned long tcomm = 0, tcontmem = 0, tcomp = 0;
    DECLARE_TIMER
#endif

    for (Int jgroup = jgroup_begin; jgroup < jgroup_end; jgroup += group_panel_size) {
        const Int jfact = jgroup + offset;

        const Int group_size_a = min(gsize, ceiling_sra(jgroup_end - jgroup, block_cycle_shift)); 
        const Int last_quit_end = min(jgroup + group_panel_size, ((jgroup_end - 1) & (~block_cycle_mask)) + block_cycle_size);
        const Int first_quit_begin = last_quit_end - group_cycle_size;
        const Int ncycles = min(npanel_max, ceiling_div(jgroup_end - jgroup, group_cycle_size));
        const Int ncycles_not_last = ncycles - 1;
        const Int last_panel_jfact = jfact + ncycles_not_last * group_cycle_size;
        const Int ncol_last = max(0, min(block_cycle_size, jgroup_end - last_panel_jfact));
        const Int ncol = ncycles_not_last * block_cycle_size + ncol_last;
        const Int npanel = (last_panel_jfact >= last_quit_end) ? ncycles_not_last : ncycles;

        DATA_T *panel_val = mem + jfact * sup_ld;
        Int *panel_ipiv_mem = ipiv + jfact;

        // diagnal part

        // copy the block
        TIMER_SET(timer1)
        cached_read_mtx_bc(right_buff, panel_val, fact_nrow, ncycles_not_last, group_cycle_size, ncol_last, right_ld, sup_ld);
        TIMER_SET(timer2)
        TIMER_GET(tcontmem, timer1, timer2)

        Int src_rank = 0; // use src_rank to update this rank
        if(ncol > 0) {  // update from left
            for (Int kfact = 0; kfact < jgroup; 
                    kfact += block_cycle_size, src_rank = next_rank(src_rank, gsize)) { // TRSM

                // fact_nrow <= left_brf: fact_nrow
                // fact_nrow >  left_brf:
                //     kfact <  left_brf: left_brf
                //     kfact >= left_brf: fact_nrow
                const bool split = (lower_nrow > 0) && (kfact < left_brf);
                const Int upper_rows = (split ? left_brf : fact_nrow) - kfact;
                DATA_T *right_up = right_buff + kfact;

                if(comm.group_rank == src_rank) {
                    TIMER_SET(timer1)
                    size_t read_size = sizeof(DATA_T) * (upper_rows - 1);
                    DATA_T *temp_mem = mem + kfact * sup_ld + kfact + 1;
                    DATA_T *temp_left = left_buff + 1;
                    for (Int kk = 0; kk < block_cycle_size; ++kk, temp_mem += (sup_ld + 1), \
                        temp_left += (left_ld + 1), read_size -= sizeof(DATA_T)) {
                        cached_read(temp_left, temp_mem, read_size);
                    }
                    cached_read(ipiv_ldm, ipiv + kfact, sizeof(Int) * block_cycle_size);
                    TIMER_SET(timer2)
                    TIMER_GET(tcontmem, timer1, timer2)
                }
                
                TIMER_SET(timer1)
                rma_broadcast_tri_recv(left_buff, upper_rows, block_cycle_size, left_ld, ipiv_ldm, \
                    src_rank, group_size_a, comm, rma_status);
                TIMER_SET(timer2)
                pivot_permute_dense(right_buff, ipiv_ldm, kfact, block_cycle_size, ncol, right_ld);
                TIMER_SET(timer3)
                this->l_trsm_update_fact(block_cycle_size, ncol, left_buff, right_up);
                this->mm_update_fact(block_cycle_size, ncol, upper_rows - block_cycle_size, \
                    left_buff + block_cycle_size, right_up, right_up + block_cycle_size);
                TIMER_SET(timer4)
                TIMER_GET(tcomm, timer1, timer2)
                TIMER_GET(tcomp, timer3, timer4)
                rma_status.wait();
                if(split) {
                    TIMER_SET(timer1)
                    if(comm.group_rank == src_rank) {
                        cached_read_mtx(left_buff, mem + kfact * sup_ld + left_brf, lower_nrow, block_cycle_size, left_ld, sup_ld);
                    }
                    TIMER_SET(timer2)
                    rma_broadcast_mat_recv(left_buff, lower_nrow, block_cycle_size, left_ld, src_rank, group_size_a, comm, rma_status);
                    TIMER_SET(timer3)
                    this->mm_update_fact(block_cycle_size, ncol, lower_nrow, left_buff, right_up, right_buff + left_brf);
                    TIMER_SET(timer4)
                    TIMER_GET(tcontmem, timer1, timer2)
                    TIMER_GET(tcomm, timer2, timer3)
                    TIMER_GET(tcomp, timer3, timer4)
                    rma_status.wait();
                }
            }
            ASSERT_EQUAL(src_rank, 0);
        } else {  // communication only
            for (Int kfact = offset; kfact < jgroup; kfact += group_cycle_size) {
                const bool split = (lower_nrow > 0) && (kfact < left_brf);
                const Int upper_rows = (split ? left_brf : fact_nrow) - kfact;

                TIMER_SET(timer1)
                size_t read_size = sizeof(DATA_T) * (upper_rows - 1);
                DATA_T *temp_mem = mem + kfact * sup_ld + kfact + 1;
                DATA_T *temp_left = left_buff + 1;
                for (Int kk = 0; kk < block_cycle_size; ++kk, temp_mem += (sup_ld + 1), \
                    temp_left += (left_ld + 1), read_size -= sizeof(DATA_T)) {
                    cached_read(temp_left, temp_mem, read_size);
                }
                cached_read(ipiv_ldm, ipiv + kfact, sizeof(Int) * block_cycle_size);
                
                TIMER_SET(timer2)
                rma_broadcast_tri_send(left_buff, upper_rows, block_cycle_size, left_ld, ipiv_ldm, group_size_a, comm, rma_status);
                TIMER_SET(timer3)
                TIMER_GET(tcontmem, timer1, timer2)
                TIMER_GET(tcomm, timer2, timer3)
                
                rma_status.wait();
                
                if(split) {
                    TIMER_SET(timer1)
                    cached_read_mtx(left_buff, mem + kfact * sup_ld + left_brf, lower_nrow, block_cycle_size, left_ld, sup_ld);
                    TIMER_SET(timer2)
                    rma_broadcast_mat_send(left_buff, lower_nrow, block_cycle_size, left_ld, group_size_a, comm, rma_status);
                    TIMER_SET(timer3)
                    TIMER_GET(tcontmem, timer1, timer2)
                    TIMER_GET(tcomm, timer2, timer3)
                    rma_status.wait();
                }
            }
        }
        
        Int k_begin = jgroup, k_end = jfact, fact_ncol = ncol;
        for(Int panel = 0; panel < npanel; ++ panel) {
            Int panel_begin = panel << block_cycle_shift;   // local index
            Int panel_mem_begin = panel * group_cycle_size;   // local index
            DATA_T* right_active = right_buff + panel_begin * right_ld;
            for (Int kfact = k_begin; kfact < k_end; 
                    kfact += block_cycle_size, src_rank = next_rank(src_rank, gsize)) { // TRSM

                // fact_nrow <= left_brf: fact_nrow
                // fact_nrow >  left_brf:
                //     kfact <  left_brf: left_brf
                //     kfact >= left_brf: fact_nrow
                const bool split = (lower_nrow > 0) && (kfact < left_brf);
                const Int upper_rows = (split ? left_brf : fact_nrow) - kfact;
                const Int ncores = get_ncores(kfact, first_quit_begin, gsize);
                DATA_T *right_up_active = right_active + kfact;

                TIMER_SET(timer1)
                if(comm.group_rank == src_rank) {
                    size_t read_size = sizeof(DATA_T) * (upper_rows - 1);
                    DATA_T *temp_mem = mem + kfact * sup_ld + kfact + 1;
                    DATA_T *temp_left = left_buff + 1;
                    for (Int kk = 0; kk < block_cycle_size; ++kk, temp_mem += (sup_ld + 1), \
                        temp_left += (left_ld + 1), read_size -= sizeof(DATA_T)) {
                        cached_read(temp_left, temp_mem, read_size);
                    }
                    cached_read(ipiv_ldm, ipiv + kfact, sizeof(Int) * block_cycle_size);
                }
                TIMER_SET(timer2)
                rma_broadcast_tri_cont(left_buff, upper_rows, block_cycle_size, left_ld, ipiv_ldm, \
                    src_rank, ncores, comm, rma_status);
                TIMER_SET(timer3)
                TIMER_GET(tcontmem, timer1, timer2)
                TIMER_GET(tcomm, timer2, timer3)

                pivot_permute_dense(right_active, ipiv_ldm, kfact, block_cycle_size, fact_ncol, right_ld);             
                
                TIMER_SET(timer1)
                this->l_trsm_update_fact(block_cycle_size, fact_ncol, left_buff, right_up_active);
                this->mm_update_fact(block_cycle_size, fact_ncol, upper_rows - block_cycle_size, \
                    left_buff + block_cycle_size, right_up_active, right_up_active + block_cycle_size);
                TIMER_SET(timer2)
                TIMER_GET(tcomp, timer1, timer2)
                rma_status.wait();
                if(split) {
                    TIMER_SET(timer1)
                    if(comm.group_rank == src_rank) {
                        cached_read_mtx(left_buff, mem + kfact * sup_ld + left_brf, lower_nrow, block_cycle_size, left_ld, sup_ld);
                    }
                    TIMER_SET(timer2)
                    rma_broadcast_mat_cont(left_buff, lower_nrow, block_cycle_size, left_ld, \
                        src_rank, ncores, comm, rma_status);
                    TIMER_SET(timer3)
                    this->mm_update_fact(block_cycle_size, fact_ncol, lower_nrow, left_buff, right_up_active, right_active + left_brf);
                    TIMER_SET(timer4)
                    TIMER_GET(tcontmem, timer1, timer2)
                    TIMER_GET(tcomm, timer2, timer3)
                    TIMER_GET(tcomp, timer3, timer4)
                    rma_status.wait();
                }
            }
            
            Int panel_end = min(panel_begin + block_cycle_size, ncol), panel_ncol = panel_end - panel_begin;
            Int diag_begin = jfact + panel * group_cycle_size;
            Int diag_end = min(diag_begin + block_cycle_size, fact_nrow);
            Int rr = fact_nrow - diag_end, cc = ncol - panel_end;
            DATA_T *current = right_buff + diag_begin + panel_begin * right_ld;
            DATA_T *next_left = current + simd_width<DATA_T>;
            DATA_T *next_right = current + simd_width<DATA_T> * right_ld;
            DATA_T* temp_right = right_active;  // already includes `panel_begin`

            for(Int jrel = 0; jrel < panel_ncol; ++jrel, temp_right += right_ld) {   // 8x8 LU
                const Int diag = diag_begin + jrel;
                Int ipivot = diag;
                real_t<DATA_T> mag = fabs(temp_right[ipivot]);
                for(Int k = ipivot + 1; k < sup_size; ++k) {
                    real_t<DATA_T> tmp = fabs(temp_right[k]);
                    if(mag < tmp) {
                        mag = tmp;
                        ipivot = k;
                    }
                } 
                panel_ipiv_mem[jrel + panel_mem_begin] = ipiv_ldm[jrel] = ipivot;
                if(ipivot != diag) {
                    DATA_T *col = right_active;
                    for(Int k = 0; k < fact_ncol; ++k, col += right_ld) {  // pivot permute all columns in the panel
                        DATA_T tmp = col[ipivot];
                        col[ipivot] = col[diag];
                        col[diag] = tmp;
                    }
                }
                // perturbation & scale
                DATA_T piv = perturb.rcp_pivot(temp_right[diag], mag);
                temp_right[diag] = piv;
                for(Int k = diag + 1; k < diag_end; ++k) {
                    temp_right[k] *= piv;
                }
                if(rr > 0) {
                    this->template scale<not_conjugate<DATA_T>>(temp_right + diag_end, rr, piv);
                }
                DATA_T *col = temp_right + right_ld;
                for(Int l = jrel + 1; l < panel_ncol; ++l, col += right_ld) {
                    for(Int k = diag + 1; k < diag_end; ++k) {
                        col[k] -= col[diag] * temp_right[k];
                    }
                    if(rr > 0) {
                        this->minus_scale(col + diag_end, temp_right + diag_end, rr, col[diag]);
                    }
                }
            }
            // broadcast this panel to partners
            const Int ncores = get_ncores(k_end, first_quit_begin, gsize);
            if(ncores > 1) {
                TIMER_SET(timer1)
                if(jfact == 0) {
                    // rank 1 waits for all partners to be assigned.
                    // in the first broadcast, every partner receives from rank 1, thus synchronized.
                    while(comm.partners[gsize - 1] < static_cast<int8_t>(0));
                }
                TIMER_SET(timer2)
                DATA_T* temp_left = left_buff + 1;
                temp_right = right_active + diag_begin + 1;
                
                const bool split = (diag_begin < left_brf) && (fact_nrow > left_brf);
                Int copy_nrow = (split ? left_brf : fact_nrow) - diag_begin;
                size_t read_size = sizeof(DATA_T) * (copy_nrow - 1);
                for (Int kk = 0; kk < block_cycle_size; ++kk, temp_right += (right_ld + 1), \
                    temp_left += (left_ld + 1), read_size -= sizeof(DATA_T)) {
                    memcpy(temp_left, temp_right, read_size);
                }
                TIMER_SET(timer3)
                rma_broadcast_tri_cont(left_buff, copy_nrow, block_cycle_size, left_ld, ipiv_ldm, \
                    src_rank, ncores, comm, rma_status);
                TIMER_SET(timer4)
                TIMER_GET(tcomm, timer1, timer2)
                TIMER_GET(tcontmem, timer2, timer3)
                TIMER_GET(tcomm, timer3, timer4)
                if(split) {
                    rma_status.wait();

                    TIMER_SET(timer1)
                    temp_left = left_buff;
                    temp_right = right_active + left_brf;
                    copy_nrow = fact_nrow - left_brf;
                    for (Int kk = 0; kk < block_cycle_size; ++kk, temp_right += right_ld, temp_left += left_ld) {
                        memcpy(temp_left, temp_right, sizeof(DATA_T) * copy_nrow);
                    }
                    TIMER_SET(timer2)
                    rma_broadcast_mat_cont(left_buff, copy_nrow, block_cycle_size, left_ld, \
                        src_rank, ncores, comm, rma_status);
                    TIMER_SET(timer3)
                    TIMER_GET(tcontmem, timer1, timer2)
                    TIMER_GET(tcomm, timer2, timer3)
                }
                //  overlap with RMA
                if(rr > 0 && cc > 0) { // TODO: rr > 0 always
                    TIMER_SET(timer1)
                    this->l_trsm_8x8(cc, current, next_right);
                    this->rank8_update(cc, rr, next_left, next_right, next_right + simd_width<DATA_T>);
                    TIMER_SET(timer2)
                    TIMER_GET(tcomp, timer1, timer2)
                }
                rma_status.wait();
            }
            ASSERT_EQUAL(src_rank, comm.group_rank);
            src_rank = next_rank(src_rank, gsize);
            fact_ncol -= block_cycle_size;
            k_begin = k_end + block_cycle_size;
            k_end = k_end + group_cycle_size;
        }

        TIMER_SET(timer1)
        cached_write_mtx_bc(panel_val, right_buff, fact_nrow, ncycles_not_last, group_cycle_size, ncol_last, sup_ld, right_ld);
        TIMER_SET(timer2)
        TIMER_GET(tcontmem, timer1, timer2)

        for (Int ifact = fact_br; ifact < sup_ld; ifact += trsm_br) { // lower part U-TRSM
            const Int fact_nrow_ = min(sup_ld - ifact, trsm_br);
            const Int lower_nrow_ = fact_nrow_ - left_brs, upper_nrow = min(left_brs, fact_nrow_);
            
            // copy the block
            TIMER_SET(timer1)
            cached_read_mtx_bc(right_down, panel_val + ifact, fact_nrow_, ncycles_not_last, group_cycle_size, ncol_last, right_ld, sup_ld);
            TIMER_SET(timer2)
            TIMER_GET(tcontmem, timer1, timer2)

            src_rank = 0; // use src_rank to update this rank
            
            if(ncol > 0) {
                for (Int kfact = 0; kfact < jgroup; 
                        kfact += block_cycle_size, src_rank = next_rank(src_rank, gsize)) {
                    TIMER_SET(timer1)
                    cached_read_mtx_bc(right_buff, panel_val + kfact, block_cycle_size, ncycles_not_last, \
                            group_cycle_size, ncol_last, right_ld, sup_ld);
                        
                    if(src_rank == comm.group_rank) {// read left part
                        cached_read_mtx(left_buff, mem + kfact * sup_ld + ifact, upper_nrow, block_cycle_size, left_ld, sup_ld);
                    }
                    TIMER_SET(timer2)
                    rma_broadcast_mat_recv(left_buff, upper_nrow, block_cycle_size, left_ld, src_rank, group_size_a, comm, rma_status);
                    TIMER_SET(timer3)
                    this->mm_update_fact(block_cycle_size, ncol, upper_nrow, left_buff, right_buff, right_down);
                    TIMER_SET(timer4)
                    TIMER_GET(tcontmem, timer1, timer2)
                    TIMER_GET(tcomm, timer2, timer3)
                    TIMER_GET(tcomp, timer3, timer4)
                    rma_status.wait();

                    if(lower_nrow_ > 0) {
                        TIMER_SET(timer1)
                        if(src_rank == comm.group_rank) {
                            cached_read_mtx(left_buff, mem + kfact * sup_ld + ifact + left_brs, lower_nrow_, \
                                block_cycle_size, left_ld, sup_ld);
                        }
                        TIMER_SET(timer2)
                        rma_broadcast_mat_recv(left_buff, lower_nrow_, block_cycle_size, left_ld, \
                            src_rank, group_size_a, comm, rma_status);
                        TIMER_SET(timer3)
                        this->mm_update_fact(block_cycle_size, ncol, lower_nrow_, left_buff, right_buff, \
                            right_down + left_brs);
                        TIMER_SET(timer4)
                        TIMER_GET(tcontmem, timer1, timer2)
                        TIMER_GET(tcomm, timer2, timer3)
                        TIMER_GET(tcomp, timer3, timer4)
                        rma_status.wait();
                    }
                }
                ASSERT_EQUAL(src_rank, 0);
            } else {  // communication only
                for (Int kfact = offset; kfact < jgroup; kfact += group_cycle_size) {
                    TIMER_SET(timer1)
                    cached_read_mtx(left_buff, mem + kfact * sup_ld + ifact, upper_nrow, block_cycle_size, left_ld, sup_ld);
                    TIMER_SET(timer2)
                    rma_broadcast_mat_send(left_buff, upper_nrow, block_cycle_size, left_ld, group_size_a, comm, rma_status);
                    TIMER_SET(timer3)
                    TIMER_GET(tcontmem, timer1, timer2)
                    TIMER_GET(tcomm, timer2, timer3)
                    rma_status.wait();
                    if(lower_nrow_ > 0) {
                        TIMER_SET(timer1)
                        cached_read_mtx(left_buff, mem + kfact * sup_ld + ifact + left_brs, lower_nrow_, \
                                block_cycle_size, left_ld, sup_ld);
                        TIMER_SET(timer2)
                        rma_broadcast_mat_send(left_buff, lower_nrow_, block_cycle_size, left_ld, group_size_a, comm, rma_status);
                        TIMER_SET(timer3)
                        TIMER_GET(tcontmem, timer1, timer2)
                        TIMER_GET(tcomm, timer2, timer3)
                        rma_status.wait();
                    }
                }
            }

            k_begin = jgroup, k_end = jfact, fact_ncol = ncol;
            for(Int panel = 0; panel < npanel; ++ panel) {
                const Int trailing_ncol = fact_ncol - block_cycle_size;
                const Int panel_ncol = min(fact_ncol, block_cycle_size);
                Int panel_begin = panel << block_cycle_shift;   // local index
                DATA_T* mem_active = panel_val + panel * group_cycle_size * sup_ld;
                DATA_T* right_buff_active = right_buff + panel_begin * right_ld;
                DATA_T* right_down_active = right_down + panel_begin * right_ld;
                DATA_T* right_buff_next = right_buff_active + block_cycle_size * right_ld;
                DATA_T* right_down_next = right_down_active + block_cycle_size * right_ld;

                for (Int kfact = k_begin; kfact < k_end; 
                        kfact += block_cycle_size, src_rank = next_rank(src_rank, gsize)) {
                    const Int ncores = get_ncores(kfact, first_quit_begin, gsize);
                    TIMER_SET(timer1)
                    cached_read_mtx_bc(right_buff_active, mem_active + kfact, block_cycle_size, ncycles_not_last - panel, \
                            group_cycle_size, ncol_last, right_ld, sup_ld);
                    TIMER_SET(timer2)
                    rma_broadcast_mat_cont(left_buff, upper_nrow, block_cycle_size, left_ld, src_rank, ncores, comm, rma_status);
                    TIMER_SET(timer3)
                    this->mm_update_fact(block_cycle_size, fact_ncol, upper_nrow, left_buff, right_buff_active, right_down_active);
                    TIMER_SET(timer4)
                    TIMER_GET(tcontmem, timer1, timer2)
                    TIMER_GET(tcomm, timer2, timer3)
                    TIMER_GET(tcomp, timer3, timer4)
                    rma_status.wait();

                    if(lower_nrow_ > 0) {
                        TIMER_SET(timer1)
                        rma_broadcast_mat_cont(left_buff, lower_nrow_, block_cycle_size, left_ld, src_rank, ncores, comm, rma_status);
                        TIMER_SET(timer2)
                        this->mm_update_fact(block_cycle_size, fact_ncol, lower_nrow_, left_buff, right_buff_active, \
                            right_down_active + left_brs);
                        TIMER_SET(timer3)
                        TIMER_GET(tcomm, timer1, timer2)
                        TIMER_GET(tcomp, timer2, timer3)
                        rma_status.wait();
                    }
                }
                const Int ncores = get_ncores(k_end, first_quit_begin, gsize);
                TIMER_SET(timer1)
                cached_read_mtx_bc(right_buff_active, mem_active + k_end, block_cycle_size, ncycles_not_last - panel, \
                    group_cycle_size, ncol_last, right_ld, sup_ld);
                TIMER_SET(timer2)
                this->ud_trsm(panel_ncol, fact_nrow_, right_buff_active, right_down_active);
                TIMER_SET(timer3)
                TIMER_GET(tcontmem, timer1, timer2)
                TIMER_GET(tcomp, timer2, timer3)
                
                TIMER_SET(timer1)
                DATA_T* temp_left = left_buff;
                DATA_T* temp_right = right_down_active;
                for (Int kk = 0; kk < panel_ncol; ++kk, temp_right += right_ld, temp_left += left_ld) {
                    memcpy(temp_left, temp_right, sizeof(DATA_T) * upper_nrow);
                }
                TIMER_SET(timer2)
                rma_broadcast_mat_cont(left_buff, upper_nrow, block_cycle_size, left_ld, src_rank, ncores, comm, rma_status);
                TIMER_SET(timer3)
                if (trailing_ncol > 0) {
                    this->mm_update_fact(block_cycle_size, trailing_ncol, upper_nrow, left_buff, right_buff_next, right_down_next);
                }
                TIMER_SET(timer4)
                TIMER_GET(tcontmem, timer1, timer2)
                TIMER_GET(tcomm, timer2, timer3)
                TIMER_GET(tcomp, timer3, timer4)
                rma_status.wait();
                if(lower_nrow_ > 0) {
                    TIMER_SET(timer1)
                    temp_left = left_buff;
                    temp_right = right_down_active + left_brs;
                    for (Int kk = 0; kk < panel_ncol; ++kk, temp_right += right_ld, temp_left += left_ld) {
                        memcpy(temp_left, temp_right, sizeof(DATA_T) * lower_nrow_);
                    }
                    TIMER_SET(timer2)
                    rma_broadcast_mat_cont(left_buff, lower_nrow_, block_cycle_size, left_ld, src_rank, ncores, comm, rma_status);
                    TIMER_SET(timer3)
                    if (trailing_ncol > 0) {
                        this->mm_update_fact(block_cycle_size, trailing_ncol, lower_nrow_, left_buff, \
                            right_buff_next, right_down_next + left_brs);
                    }
                    TIMER_SET(timer4)
                    TIMER_GET(tcontmem, timer1, timer2)
                    TIMER_GET(tcomm, timer2, timer3)
                    TIMER_GET(tcomp, timer3, timer4)
                    rma_status.wait();
                }
                                
                ASSERT_EQUAL(src_rank, comm.group_rank);
                src_rank = next_rank(src_rank, gsize);
                fact_ncol -= block_cycle_size;
                k_begin = k_end + block_cycle_size;
                k_end = k_end + group_cycle_size;
            }
            
            TIMER_SET(timer1)
            cached_write_mtx_bc(panel_val + ifact, right_down, fact_nrow_, ncycles_not_last, group_cycle_size, ncol_last, sup_ld, right_ld);
            TIMER_SET(timer2)
            TIMER_GET(tcontmem, timer1, timer2)
        }
    }
#ifdef LU_CPE_PROFILE
    this->tcomm += tcomm;
    this->tcontmem += tcontmem;
    this->tcomp += tcomp;
#endif
    
    return perturb.count();
}

template <typename DATA_T>
void P<DATA_T>::pivot_permute_L_par(DATA_T *l_sup_val, Int *ipiv_ldm, Int *ipiv_mem, Int sup_size, Int sup_ld) const {
    const Int offset = comm.group_rank << block_cycle_shift, group_cycle_size = comm.group_size << block_cycle_shift;
    const Int ncycles_not_last = (sup_size - 1) / group_cycle_size, ncycles = ncycles_not_last + 1;
    const Int ncol_last = max(0, min(block_cycle_size, sup_size - ncycles_not_last * group_cycle_size - offset));
    const Int ncol = ncycles_not_last * block_cycle_size + ncol_last;
    const Int ipiv_local_size = ncycles * block_cycle_size, ipiv_local_pos = comm.group_rank * ipiv_local_size;
    const Int ipiv_global_size = comm.group_size * ipiv_local_size, pos_step = ipiv_global_size - block_cycle_size;
    const rply_counter_t rma_count = comm.group_size - 1;
    crts_rply_t rma_reply[2] = {0, 0};

    Int* dst = ipiv_ldm + ipiv_local_pos;
    Int* src = ipiv_mem + offset;
    for(Int i = 0; i < ncycles_not_last; ++i, dst += block_cycle_size, src += group_cycle_size) {
        cached_read(dst, src, sizeof(Int) * block_cycle_size);
    }
    cached_read(dst, src, sizeof(Int) * ncol_last);
    for(Int i = 0; i < comm.group_size; ++i) { // naive all-to-all
        if(i != comm.group_rank) {
            Int partner = comm.partners[i];
            CRTS_ssync_peer(partner);  // ensure partner's buffer is ready
            CRTS_rma_iput(ipiv_ldm + ipiv_local_pos, &rma_reply[0], sizeof(Int) * ncol, 
                partner, ipiv_ldm + ipiv_local_pos, &rma_reply[1]);
        }
    }
    CRTS_rma_wait_value(&rma_reply[1], rma_count);
    for(Int ipanel = 0, pos = 0; ipanel < sup_size; ipanel += block_cycle_size) {
        Int ipanel_size = min(sup_size - ipanel, block_cycle_size);
        for(Int jpanel = offset; jpanel < ipanel; jpanel += group_cycle_size) {
            for(Int ii = 0; ii < ipanel_size; ++ii) {
                Int idx = ipiv_ldm[pos + ii], i = ipanel + ii;
                if(idx != i) {
                    auto mem0 = l_sup_val + sup_ld * jpanel;
                    auto mem1 = mem0 + sup_ld;
                    auto mem2 = mem0 + sup_ld * 2;
                    auto mem3 = mem0 + sup_ld * 3;
                    auto mem4 = mem0 + sup_ld * 4;
                    auto mem5 = mem0 + sup_ld * 5;
                    auto mem6 = mem0 + sup_ld * 6;
                    auto mem7 = mem0 + sup_ld * 7;
                    DATA_T tt0a = mem0[i], tt0b = mem0[idx];
                    DATA_T tt1a = mem1[i], tt1b = mem1[idx];
                    DATA_T tt2a = mem2[i], tt2b = mem2[idx];
                    mem0[idx] = tt0a; mem0[i] = tt0b;
                    DATA_T tt3a = mem3[i], tt3b = mem3[idx];
                    mem1[idx] = tt1a; mem1[i] = tt1b;
                    DATA_T tt4a = mem4[i], tt4b = mem4[idx];
                    mem2[idx] = tt2a; mem2[i] = tt2b;
                    DATA_T tt5a = mem5[i], tt5b = mem5[idx];
                    mem3[idx] = tt3a; mem3[i] = tt3b;
                    DATA_T tt6a = mem6[i], tt6b = mem6[idx];
                    mem4[idx] = tt4a; mem4[i] = tt4b;
                    DATA_T tt7a = mem7[i], tt7b = mem7[idx];
                    mem5[idx] = tt5a; mem5[i] = tt5b; 
                    mem6[idx] = tt6a; mem6[i] = tt6b; 
                    mem7[idx] = tt7a; mem7[i] = tt7b;
                }
            }
        }
        pos += ipiv_local_size;
        if(pos >= ipiv_global_size) {
            pos -= (ipiv_global_size - block_cycle_size);
        }
    }        
    CRTS_rma_wait_value(&rma_reply[0], rma_count);
}


template <typename DATA_T, typename PERTURB>
static Int FS(DATA_T *ldm, DATA_T *mem, Int *ipiv_ldm, Int *ipiv, \
        Int jpanel_begin, Int jpanel_end, Int sup_size, Int sup_ld, const dense_par_fact<DATA_T>* this_) {
    return supfact_seq<DATA_T, PERTURB>(ldm, mem, ipiv, jpanel_begin, jpanel_end, sup_size, sup_ld, this_);
}

template <typename DATA_T, typename PERTURB>
static Int FP(DATA_T *ldm, DATA_T *mem, Int *ipiv_ldm, Int *ipiv, \
        Int jpanel_begin, Int jpanel_end, Int sup_size, Int sup_ld, const dense_par_fact<DATA_T>* this_) {
    return this_->template supfact_par<PERTURB>(ldm, mem, ipiv_ldm, ipiv, jpanel_begin, jpanel_end, sup_size, sup_ld);
}

template <typename DATA_T>
static void PS(DATA_T *l_sup_val, Int *ipiv_ldm, Int *ipiv_mem, Int sup_size, Int sup_ld, const dense_par_fact<DATA_T>* this_) {
    this_->pivot_permute_L_seq(l_sup_val, ipiv_mem, sup_size, sup_ld);
}

template <typename DATA_T>
static void PP(DATA_T *l_sup_val, Int *ipiv_ldm, Int *ipiv_mem, Int sup_size, Int sup_ld, const dense_par_fact<DATA_T>* this_) {
    this_->pivot_permute_L_par(l_sup_val, ipiv_ldm, ipiv_mem, sup_size, sup_ld);
}

template <typename DATA_T>
P<DATA_T>::P(real_t<DATA_T> thres, real_t<DATA_T> rthres, Int perturb_op) : B<DATA_T>(thres, rthres) {
    if(perturb_op == options_perturb_tiny) {
        this->fact_seq = FS<DATA_T, perturb_tiny<DATA_T>>;
        this->fact_par = FP<DATA_T, perturb_tiny<DATA_T>>;
    } else if(perturb_op == options_perturb_zero) {
        this->fact_seq = FS<DATA_T, perturb_zero<DATA_T>>;
        this->fact_par = FP<DATA_T, perturb_zero<DATA_T>>;
    } else {
        this->fact_seq = FS<DATA_T, no_perturbation>;
        this->fact_par = FP<DATA_T, no_perturbation>;
    }
    this->permute_seq = PS<DATA_T>;
    this->permute_par = PP<DATA_T>;
}

#define INSTANTIATE(type) \
template P<type>::P(real_t<type> thres, real_t<type> rthres, Int perturb_op);

INSTANTIATE(float)
INSTANTIATE(double)
INSTANTIATE(SComplex)
INSTANTIATE(DComplex)

} // namespace supfact
} // namespace swSparse