#include <limits>
#include "swSparse_trf.h"
#include "internal/rename.h"
#include "internal/debug.h"
#include "internal/debug_array.h"
#include "internal/CPE.h"
#include "internal/templates.h"
#include "internal/utils.h"
#include "internal/sptrf_cpe.h"

// not used
//#define TRACK_ANCESTOR 1

namespace swSparse {

using status_t = int8_t;
constexpr Int strip_shift = 11;
constexpr Int strip_size = 1 << strip_shift, nstrip = 2;
constexpr Int window_size = strip_size * nstrip, window_mask = window_size - 1, strip_mask = strip_size - 1, round_mask = nstrip - 1;
constexpr status_t unassigned = -1, done = -2;

struct TG {
    Int size, tid[63];
};

struct CH {
    Int nb;
};

struct TI {
    Int assigned_task;
    INLINE void update_fb_rank(Int rank, Int tid, scheduler_communicator& comm) const {
        comm.update_fb_rank_queue(rank, tid);
    }
    INLINE Int reset_fb_child(Int rank, const CH& child) const {
        return rank;
    }
};

struct CH2 {
    Int nb, fb;
};

struct TI2 {
    Int assigned_task, fb_child;
    INLINE void update_fb_rank(Int rank, Int tid, scheduler_communicator& comm) {
        if(rank > fb_child) {
            fb_child = rank;
            comm.update_fb_rank_queue(rank, tid);
        }
    }
    INLINE Int reset_fb_child(Int rank, const CH2& child) {
        fb_child = max(rank, child.fb);
        return fb_child;
    }
};

#ifdef TRACK_ANCESTOR
using thread_info_t = TI2;
using child_t = CH2;
#else
using thread_info_t = TI;
using child_t = CH;
#endif

using thread_group_t = TG;

class LevelScheduler {
    Int q, r, shift;
    Bool new_level;
public:
    LevelScheduler() : new_level(true) {}
    Int schedule(Int current_level_id, Int cores_in_subtree, Int sup_size) {
        if(new_level) {
            Int size = current_level_id + 1;
            Int nworker = 63 - cores_in_subtree;
            q = nworker / size;
            r = nworker % size;
            shift = block_cycle_shift + ((size == 1) ? 0 : 1);
        }
        new_level = (current_level_id == 0);
        Int req = ceiling_sra(sup_size, shift);
        if(req <= q) {
            return req;
        } else if(r > 0) {
            --r;
            return q + 1;
        } else if(q <= 0) {
            return 1;
        } else {
            return q;
        }
    }
};

class QS {
    // group_id  --(thread_groups)--> thread_id
    // thread_id --(thread_info)--> task_id
    // task_id   -----(status)----->  group_id
    SIMD_ALIGN child_t child[window_size];
    SIMD_ALIGN status_t status[window_size];
    trf_task_t tasks[window_size];
    thread_info_t thread_info[64];
    thread_group_t thread_groups[64];
    Int strip_undone[nstrip];
    Int wbegin, wend, front, back;
    scheduler_communicator comm;
    struct BT {
        Int thread_id, last_busy_tree;
    };
    BT busy_tree[63];
    Int subtree_offsets[65];
    Int first_window;
    Int subtree_not_finish;
public:
    QS(scheduler_communicator&& c) : comm(c), subtree_not_finish(0), wbegin(0), front(0), back(0) {}

    inline void init_subtree_parent(const trf_subtree_t* subtrees);
    void update_subtree_parent(const trf_subtree_t* subtrees);
    inline void ensure_subtree_complete(const trf_subtree_t* subtrees) {
        while(subtree_not_finish != 0) {
            this->update_subtree_parent(subtrees);
        }
    }

    template<typename LOCAL>
    inline void update_parent(Int parent, const LOCAL& loc);
    inline void on_completion(Int comp_rank);
    void schedule(const trf_task_t* queue, Int queue_size, const Int* g_subtoff, const trf_subtree_t* subtrees, const Int* sup2col);
};

void QS::init_subtree_parent(const trf_subtree_t* subtrees) {
    for(Int id = 0; id < 64; ++id) {
        if(id == scheduler_id) continue;
        Int bt, fb_tree = comm.get_fb_sup_subtree(id), tree_end = subtree_offsets[id+1];
        for(bt = subtree_offsets[id]; (bt < tree_end) && (fb_tree >= subtrees[bt].sup_end); ++bt); 
        // find the first busy subtree which satisfies (fb_tree < subtrees[bt].sup_end)
        
        if(bt < tree_end) {
            for(Int t = bt; t < tree_end; ++t) {
                Int p = subtrees[t].parent_task;
                if(p < first_window) {
                    ++ child[p].nb;
                }
            }
            busy_tree[subtree_not_finish].thread_id = id;
            busy_tree[subtree_not_finish++].last_busy_tree = bt;
        }
    }
}

void QS::update_subtree_parent(const trf_subtree_t* subtrees) {
    for(Int i = subtree_not_finish - 1; i >= 0; --i) {
        Int id = busy_tree[i].thread_id, bt = busy_tree[i].last_busy_tree, tree_end = subtree_offsets[id+1];
        Int fb_tree = comm.get_fb_sup_subtree(id);
        if(bt < tree_end) {  // not complete yet
            for(; (bt < tree_end) && (fb_tree >= subtrees[bt].sup_end); ++bt) {
                update_parent(subtrees[bt].parent_task, [](Int x) { return x; });
            }
            if(bt >= tree_end) {
                busy_tree[i] = busy_tree[--subtree_not_finish];
            } else {
                busy_tree[i].last_busy_tree = bt;
            }
        }
    }
}

template<typename LOCAL>
void QS::update_parent(Int parent, const LOCAL& local) {
    if(parent < wend) {
        Int local_pos = local(parent);
        child[local_pos].nb -= 1;
        if(child[local_pos].nb == 0) { /* notify parent */
            Int group_idx = status[local_pos];
            if(group_idx >= 0) {  /* if parent is assigned */
                for(Int part = 0, size = thread_groups[group_idx].size; part < size; ++ part) {
                    comm.update_nbchild(thread_groups[group_idx].tid[part]);
                }
            }
#ifdef TRACK_ANCESTOR
            Int fb = parent;
            parent = tasks[local_pos].parent;
            local_pos = local(parent); 
            ASSERT_LESS_EQUAL(back, fb);
            while(parent < wend && child[local_pos].nb == 1) {
                group_idx = status[local_pos];
                if(group_idx > 0) {
                    for(Int part = 0, size = thread_groups[group_idx].size; part < size; ++ part) {
                        Int tid = thread_groups[group_idx].tid[part];
                        thread_info[tid].update_fb_rank(fb, tid, comm);
                    }
                }
                child[local_pos].fb = fb;
                parent = tasks[local_pos].parent;
                local_pos = local(parent); 
            }
#endif
        }
    }
}

void QS::on_completion(Int comp_rank) {
    Int local_rank_ = comp_rank & window_mask;  // local index of the last complete task
    Int tg_id = status[local_rank_];

    // At this point, some CPE has finished, meaning that nbchild is 0.
    // No more notification is required, then the partner list is no more used
    Int left_active = --thread_groups[tg_id].size;
    ASSERT_EQUAL(child[local_rank_].nb, 0);
    ASSERT_LESS_EQUAL(0, left_active);
    ASSERT_LESS(left_active, 63);
    if(left_active == 0) {
        status[local_rank_] = done;             // set status
        update_parent(tasks[local_rank_].parent, [](Int x) { return x & window_mask; });
        -- strip_undone[(local_rank_ >> strip_shift) & round_mask];
        if(comp_rank == back) {
            for(; (back < front) && (status[back & window_mask] == done) ; ++back);
            /* notify all */
            for(Int i = 0; i < scheduler_id; ++i) {
                thread_info[i].update_fb_rank(back, i, comm);
            }
            for(Int i = scheduler_id + 1; i < 64; ++i) {
                thread_info[i].update_fb_rank(back, i, comm);
            }
        }
    }
}

void QS::schedule(const trf_task_t* queue, Int queue_size, const Int* g_subtoff, const trf_subtree_t* subtrees, const Int* sup2col) {
    trf_communicator::worker_message msg_to_send;
    LevelScheduler lvl_sched;
    Int ntask_in_window = min(queue_size, window_size);
    Int ncores = 0, next_partner = 0, wait_for_partner = 0, worker_not_finish = 63;
    Int task_rank, local_pos, group_id = 0;
    DMA_DECL_DESC(READ_WRITE);
    DMA_IREAD(g_subtoff, subtree_offsets, sizeof(subtree_offsets));
    if(queue_size != 0) {
        DMA_IREAD(queue, tasks, ntask_in_window * sizeof(trf_task_t));
    }
    for(Int i = 0, j = 0; i < min(queue_size, window_size); i += strip_size, ++j) {
        strip_undone[j] = min(queue_size - i, strip_size);
    }
    memset(&status[0], unassigned, sizeof(status_t) * ntask_in_window);
    memset(&child[0], 0, sizeof(child_t) * ntask_in_window);
    for(Int i = 0; i < 64; ++i) {
        thread_groups[i].size = 0;
        thread_info[i].assigned_task = trf_communicator::empty;
    }
    first_window = ntask_in_window;
    wend = ntask_in_window;
    DMA_WAIT_ALL;
    init_subtree_parent(subtrees);
    if(queue_size == 0) {
        goto END_QUEUE1;
    }
    for(Int i = 0; i < ntask_in_window; ++i) {
        Int p = tasks[i].parent;
        if(p < ntask_in_window) {
            child[p].nb += 1;
        }
    }
    while(true) {
        for(Int worker_id = 0; worker_id < 63; ++worker_id) {
            Int thread_id = comm.scheduler_signal(worker_id);
            if(thread_id >= 0) {
                Int complete_rank = thread_info[thread_id].assigned_task;
                comm.scheduler_signal(worker_id) = trf_communicator::empty;
                if(wait_for_partner > 0) {
                    // the status may have changed since allocating last partner
                    thread_groups[group_id].tid[next_partner] = thread_id;
                    thread_groups[group_id].size += 1;
                    thread_info[thread_id].assigned_task = front - 1;
                    msg_to_send.task.t.fb_rank_queue = thread_info[thread_id].reset_fb_child(back, child[local_pos]);
                    msg_to_send.task.t.nb_child = child[local_pos].nb;
                    msg_to_send.task.t.group_rank = next_partner;
                    msg_to_send.partners.v[next_partner] = thread_id;
                    ++ next_partner;
                } else {
                    task_rank = front ++, local_pos = task_rank & window_mask;
                    const auto& task = tasks[local_pos];
                    Int isup = task.sup_id;
                    ncores = lvl_sched.schedule(task.level_id, subtree_not_finish, sup2col[isup + 1] - sup2col[isup]);
                    ASSERT_LESS(0, ncores);
                    ASSERT_LESS(ncores, 64);
                    for(group_id = (group_id + 1) & 63; thread_groups[group_id].size != 0; group_id = (group_id + 1) & 63);
                    status[local_pos] = group_id;
                    thread_groups[group_id].size = 1;
                    thread_groups[group_id].tid[0] = thread_id;
                    thread_info[thread_id].assigned_task = task_rank;
                    msg_to_send.task.t.fb_rank_queue = thread_info[thread_id].reset_fb_child(back, child[local_pos]);
                    msg_to_send.task.t.nb_child = child[local_pos].nb;
                    msg_to_send.task.t.group_rank = 0;
                    msg_to_send.task.t.group_size = ncores;
                    msg_to_send.task.t.sup_id = isup;
                    msg_to_send.partners.packed = -1;
                    msg_to_send.partners.v[0] = thread_id;
                    next_partner = 1;
                }
                wait_for_partner = ncores - next_partner;

                comm.schedule_response(msg_to_send, thread_id);

                if(complete_rank >= 0) {  // the last partner, complete a supernode
                    on_completion(complete_rank);
                }
                if(wait_for_partner == 0) {
                    if(front >= queue_size) {
                        goto END_QUEUE;
                    }
                    if(front >= wend) {                // init a new strip
                        // wait for the last to complete
                        Int old_strip = (wbegin >> strip_shift) & round_mask;
                        while(strip_undone[old_strip] > 0) {
                            for(Int wid = 0; wid < 63; ++wid) {
                                Int tid = comm.scheduler_signal(wid);
                                if(tid >= 0) {   // only process the completion, do not assign new task 
                                    complete_rank = thread_info[tid].assigned_task;
                                    if(complete_rank >= 0) {
                                        on_completion(complete_rank);
                                        thread_info[tid].assigned_task = trf_communicator::empty;
                                    }
                                }
                            }
                            
                            // in order to let parents of subtrees to complete
                            update_subtree_parent(subtrees);
                        }

                        Int ntask_in_strip = min(queue_size - wend, strip_size);
                        Int offset = wend & window_mask;

                        ensure_subtree_complete(subtrees);
                        DMA_IREAD(queue + wend, tasks + offset, ntask_in_strip * sizeof(trf_task_t));

                        Int new_wbegin = wbegin + strip_size;
                        Int new_wend   = wend   + ntask_in_strip;
                        Int new_strip = (wend >> strip_shift) & round_mask;
                        strip_undone[new_strip] = ntask_in_strip;
                        memset(&status[offset], unassigned, sizeof(status_t) * ntask_in_strip);
                        memset(&child[offset], 0, sizeof(child_t) * ntask_in_strip);
                        DMA_WAIT_ALL;
                        
                        for(Int i = back; i < new_wend; ++i) {
                            Int idx = i & window_mask;
                            Int p = tasks[idx].parent;
                            if ((status[idx] != done) && (p < new_wend) && (p >= wend)) { // count all undone children
                                child[p & window_mask].nb += 1;
                            }
                        }
                        wbegin = new_wbegin;
                        wend = new_wend;
                    }
                }
            }
        }
        update_subtree_parent(subtrees);
    }
    END_QUEUE:
    ensure_subtree_complete(subtrees);
    END_QUEUE1:
    while(worker_not_finish > 0) {
        for(Int wid = 0; wid < 63; ++wid) {
            Int tid = comm.scheduler_signal(wid);
            if(tid >= 0) {   // only process the completion, do not assign new task 
                Int complete_rank = thread_info[tid].assigned_task;
                comm.scheduler_signal(wid) = trf_communicator::empty;
                msg_to_send.task.t.sup_id = trf_communicator::end;
                comm.schedule_response(msg_to_send, tid);
                worker_not_finish--;
                if(complete_rank >= 0) {  // the last partner, complete a supernode
                    on_completion(complete_rank);
                }
            }
        }
    }
}

void queue_scheduler(const trf_task_t* queue, Int queue_size, const Int* subtree_offsets, const trf_subtree_t* subtrees, 
            const Int* sup2col, scheduler_communicator&& comm) {
    QS qs(std::forward<scheduler_communicator>(comm));
    qs.schedule(queue, queue_size, subtree_offsets, subtrees, sup2col);
}


}