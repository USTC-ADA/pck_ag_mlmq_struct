#include "internal/memory.h"
#include "internal/rename.h"
#include "internal/templates.h"
#include "internal/utils.h"
#include "internal/CPE_blas_kernels.h"

// automatic unroll with compiler option -funroll-all-loops

namespace swSparse {
template <typename DATA_T>
void ESC<DATA_T>::ewise_scale(DATA_T *y, const real_t<DATA_T> *RSTR x, Int n) const {
    simd_t<DATA_T> *yv = reinterpret_cast<simd_t<DATA_T> *>(y);
    const simd_real_t<DATA_T> *xv = reinterpret_cast<const simd_real_t<DATA_T> *>(x);
    Int nv = ceiling_div(n, simd_width<DATA_T>);
    for (Int i = 0; i < nv; ++i) {
        auto y0 = this->complex_to_simd(yv[i]);
        auto z0 = y0 * xv[i];
        yv[i] = this->simd_to_complex(z0);
    }
}

template <typename REAL_T>
void scale_real(REAL_T *RSTR x, Int n, REAL_T alpha) {
    simd_t<REAL_T> alpha_v = simd_broadcast(alpha);
    simd_t<REAL_T> *xv = reinterpret_cast<simd_t<REAL_T> *>(x);
    int nv = ceiling_div(n, simd_width<REAL_T>);
    for (Int i = 0; i < nv; ++ i) {
        simd_t<REAL_T> x0 = xv[i];
        simd_t<REAL_T> y0 = x0 * alpha_v;
        xv[i] = y0;
    }
}

template <typename REAL_T>
template <typename Conj>
void SC<complex<REAL_T>>::scale_cplx(complex<REAL_T> *RSTR x, Int n, REAL_T real, REAL_T imag) const {
    simd_t<REAL_T> real_v = real, imag_v = imag;
    complex<simd_t<REAL_T>> alpha_v{real_v, imag_v};
    complex<simd_t<REAL_T>> *xv = reinterpret_cast<complex<simd_t<REAL_T>> *>(x);
    Int nv = ceiling_div(n, simd_width<complex<REAL_T>>);
    for (Int i = 0; i < nv; ++i) {
        auto x0 = this->complex_to_simd(xv[i]);
        auto y0 = Conj::value(x0) * alpha_v;
        xv[i] = this->simd_to_complex(y0);
    }
}

template <typename REAL_T>
void minus_scale_real(REAL_T *RSTR y, const REAL_T *RSTR x, Int n, REAL_T alpha) {
    simd_t<REAL_T> alpha_v = simd_broadcast(alpha);
    const simd_t<REAL_T> *xv = reinterpret_cast<const simd_t<REAL_T> *>(x);
    simd_t<REAL_T> *yv = reinterpret_cast<simd_t<REAL_T> *>(y);
    Int nv = ceiling_div(n, simd_width<REAL_T>);
    for (Int i = 0; i < nv; ++i) {
        simd_t<REAL_T> x0 = xv[i];
        simd_t<REAL_T> y0 = yv[i];
        simd_t<REAL_T> z0 = simd_nma(x0, alpha_v, y0);
        yv[i] = z0;
    }
}

template <typename REAL_T>
void SC<complex<REAL_T>>::minus_scale_cplx(complex<REAL_T> *RSTR y, const complex<REAL_T> *RSTR x, Int n, REAL_T real, REAL_T imag) const {
    simd_t<REAL_T> real_v = real, imag_v = imag;
    complex<simd_t<REAL_T>> alpha_v{real_v, imag_v};
    const complex<simd_t<REAL_T>> *xv = reinterpret_cast<const complex<simd_t<REAL_T>> *>(x);
    complex<simd_t<REAL_T>> *yv = reinterpret_cast<complex<simd_t<REAL_T>> *>(y);
    Int nv = ceiling_div(n, simd_width<complex<REAL_T>>);
    for (Int i = 0; i < nv; ++i) {
        auto x0 = this->complex_to_simd(xv[i]);
        auto y0 = this->complex_to_simd(yv[i]);
        auto z0 = simd_nma(x0, alpha_v, y0);
        yv[i] = this->simd_to_complex(z0);
    }
}

template<typename REAL_T>
void fill_real(REAL_T* RSTR x, Int size, REAL_T value) {
    simd_t<REAL_T> value_v = value;
    simd_t<REAL_T>* xv = reinterpret_cast<simd_t<REAL_T>*>(x);
    Int nv = ceiling_div(size, simd_width<REAL_T>);
    for(Int i = 0; i < nv; ++i) {
        xv[i] = value_v;
    }
}

template<typename REAL_T>
void fill_cplx(complex<REAL_T>* RSTR x, Int size, REAL_T real, REAL_T imag) {
    simd_t<REAL_T> real_v = real, imag_v = imag;
    complex<simd_t<REAL_T>> value_v {real_v, imag_v};
    simd_t<complex<REAL_T>>* xv = reinterpret_cast<simd_t<complex<REAL_T>>*>(x);
    Int nv = ceiling_div(size, simd_width<complex<REAL_T>>);
    for(Int i = 0; i < nv; ++i) {
        xv[i] = value_v;
    }
}

template<typename REAL_T>
void shift(REAL_T* RSTR x, Int n, REAL_T delta) {
    simd_t<REAL_T> delta_v = delta;
    simd_t<REAL_T>* xv = reinterpret_cast<simd_t<REAL_T>*>(x);
    Int nv = ceiling_div(n, simd_width<REAL_T>);
    for(Int i = 0; i < nv; ++i) {
        xv[i] = xv[i] + delta_v;
    }
}

#define INSTANTIATE_REAL(type)                                                      \
    template void ESC<type>::ewise_scale(type *, const type *RSTR, Int) const;      \
    template void scale_real<type>(type * RSTR, Int, type);                         \
    template void minus_scale_real<type>(type * RSTR, const type *RSTR, Int, type); \
    template void fill_real<type>(type * RSTR, Int, type);

#define INSTANTIATE_CPLX(real)                                                                                                \
    template void ESC<complex<real>>::ewise_scale(complex<real> *, const real *RSTR, Int n) const;                            \
    template void SC<complex<real>>::scale_cplx<not_conjugate<complex<real>>>(complex<real> * RSTR, Int, real, real) const;   \
    template void SC<complex<real>>::scale_cplx<conjugate<complex<real>>>(complex<real> * RSTR, Int, real, real) const;       \
    template void SC<complex<real>>::minus_scale_cplx(complex<real> *RSTR, const complex<real> *RSTR, Int, real, real) const; \
    template void fill_cplx<real>(complex<real> * RSTR, Int, real, real);

INSTANTIATE_REAL(float)
INSTANTIATE_REAL(double)
INSTANTIATE_CPLX(float)
INSTANTIATE_CPLX(double)

template void fill_real<Int>(Int* RSTR, Int, Int);
template void shift<Int>(Int* RSTR x, Int n, Int delta);

} // namespace swSparse