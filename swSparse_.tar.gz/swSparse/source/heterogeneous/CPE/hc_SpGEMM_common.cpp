#include "swSparse_blas.h"
#include "internal/rename.h"
#include "internal/spblas_common.h"
#include "internal/CPE.h"
#include "internal/CPE_communicator.h"
#include "internal/CPE_simd_utils.h"
#include "internal/templates.h"
#include "internal/spgemm_param.h"

namespace swSparse {
inline constexpr const int r_tile = 8192;
inline constexpr const int r_tile_1 = r_tile - 2;

NOINLINE static void count_flops_partition_annz(Int rbegin, Int rend, Int annz, const Int* RSTR a_row_off, \
        const Int* RSTR a_col_idx, const Int* RSTR b_row_off, const Int* RSTR d_row_off, Int* RSTR f_off, \
        Int* RSTR dist, Int* RSTR row_max, int64_t n, Int ncpe) {
    SIMD_ALIGN Int local_d_offsets[r_tile], local_a_offsets[r_tile];
    Int tgt_rank, rmax = 0, p, ideal_nnz = max(1, annz / ncpe);  // `ideal_nnz` is the integer part of  `annz / ncpe`
    DMA_DECL_DESC(READ_WRITE);
    for(Int i = rbegin; i < rend; i += r_tile_1) {
        Int len = min(r_tile_1, rend - i);
        DMA_IREAD(a_row_off + i, local_a_offsets, (len + 1) * sizeof(Int));
        if(d_row_off != nullptr) {
            DMA_IREAD(d_row_off + i, local_d_offsets, (len + 1) * sizeof(Int));
            local_d_offsets[len+1] = 0;
        } else {
            fill(local_d_offsets, len + 2, 0);  // overlap with DMA
        }
        DMA_WAIT_ALL;
        local_a_offsets[len+1] = 0;  // afster SWRITE complete
        if(UNLIKELY(i == rbegin)) {
            tgt_rank = ceiling_divl(local_a_offsets[0], ideal_nnz);
            p = tgt_rank * ideal_nnz;
        }
        for(Int j = 0; j <= len; ++j) {
            Int begin = local_a_offsets[j], end = local_a_offsets[j+1], flop = local_d_offsets[j+1] - local_d_offsets[j];
            for(Int loc = begin; loc < end; ++loc) {
                Int k = a_col_idx[loc];                     // gld
                flop += (b_row_off[k+1] - b_row_off[k]);    // gld
            }
            if(begin > p) {   // this means (begin >= (double)total / ncpe)
                Int dist_ = i + j, rmax_ = static_cast<Int>(minl(rmax, n));
                do {
                    if(UNLIKELY(tgt_rank > ncpe)) {  // if tgt_rank == ncpe, we still have to compute row_max
                        row_max[ncpe - 1] = max(row_max[ncpe - 1], rmax_);
                        break;
                    }
                    if(LIKELY(tgt_rank < ncpe)) {
                        dist[tgt_rank] = dist_; // a_offsets[dist_] > id * ideal_nnz
                    }
                    if(LIKELY(tgt_rank > 0)) {
                        row_max[tgt_rank - 1] = rmax_;
                    }
                    rmax_ = 0;
                    p += ideal_nnz;
                    ++tgt_rank;
                } while(begin > p);
                rmax = 0;
            }
            rmax = maxl(rmax, flop);
            local_a_offsets[j] = flop;
        }
        DMA_SWRITE(f_off + i, local_a_offsets, len * sizeof(Int));
    }
    Int rmax_ = static_cast<Int>(minl(rmax, n));
    if(tgt_rank > ncpe) {
        row_max[ncpe - 1] = max(row_max[ncpe - 1], rmax_);
    } else if(tgt_rank > 0) {
        row_max[tgt_rank - 1] = rmax_;
    }
    DMA_WAIT_ALL;
}

NOINLINE static int64_t count_flops(Int rbegin, Int rend, const Int* RSTR a_row_off, const Int* RSTR a_col_idx, const Int* RSTR b_row_off, const Int* RSTR d_row_off, Int* RSTR f_off) {
    SIMD_ALIGN Int local_d_offsets[r_tile], local_a_offsets[r_tile];
    int64_t total = 0;
    DMA_DECL_DESC(READ_WRITE);

    for(Int i = rbegin; i < rend; i += r_tile_1) {
        Int len = min(r_tile_1, rend - i);
        DMA_IREAD(a_row_off + i, local_a_offsets, (len + 1) * sizeof(Int));
        if(d_row_off != nullptr) {
            DMA_IREAD(d_row_off + i, local_d_offsets, (len + 1) * sizeof(Int));
        } else {
            fill(local_d_offsets, len + 1, 0);  // overlap with DMA
        }
        DMA_WAIT_ALL;
        for(Int j = 0; j < len; ++j) {
            Int begin = local_a_offsets[j], end = local_a_offsets[j+1], flop = local_d_offsets[j+1] - local_d_offsets[j];
            for(Int p = begin; p < end; ++p) {
                Int k = a_col_idx[p];                       // gld
                flop += (b_row_off[k+1] - b_row_off[k]);    // gld
            }
            local_a_offsets[j] = flop;
            total += flop;
        }
        DMA_SWRITE(f_off + i, local_a_offsets, len * sizeof(Int));
    }
    DMA_WAIT_ALL;
    return total;
}

NOINLINE static void spgemm_scan_partition(Int roffset, Int size, int64_t total, int64_t base, const Int *nflops, 
        Int* RSTR dist, Int* RSTR row_max, int64_t n, Int ncpe) {
    Int local_nflops[r_tile + 1];
    Int i, j, len, rend = size + roffset;
    int64_t tgt_rank, rmax = 0, p, ideal_nnz = maxl(1, total / ncpe);  // `ideal_nnz` is the integer part of  `total / ncpe`
    DMA_DECL_DESC(READ);

    tgt_rank = ceiling_divl(base, ideal_nnz);
    
    p = tgt_rank * ideal_nnz;
    
    for(i = roffset; i < rend; i += r_tile) {
        len = min(r_tile, rend - i);
        DMA_IREAD(nflops + i, local_nflops, len * sizeof(Int));
        local_nflops[len] = 0;
        DMA_WAIT_ALL;
        for(j = 0; j <= len; ++j) {
            if(base > p) {   // this means (base >= (double)total / ncpe)
                Int dist_ = i + j, rmax_ = static_cast<Int>(minl(rmax, n));
                do {
                    if(UNLIKELY(tgt_rank > ncpe)) {  // if tgt_rank == ncpe, we still have to compute row_max
                        row_max[ncpe - 1] = max(row_max[ncpe - 1], rmax_);
                        return;
                    }
                    if(LIKELY(tgt_rank < ncpe)) {
                        dist[tgt_rank] = dist_; // base = sum(nflops[0:dist_]) > id * ideal_nnz
                    }
                    if(LIKELY(tgt_rank > 0)) {
                        row_max[tgt_rank - 1] = rmax_;
                    }
                    rmax_ = 0;
                    p += ideal_nnz;
                    ++tgt_rank;

                } while(base > p);
                rmax = 0;
            }
            /* scan */
            base += local_nflops[j];
            rmax = maxl(rmax, local_nflops[j]);
        }
    }
    Int rmax_ = static_cast<Int>(minl(rmax, n));
    if(tgt_rank > ncpe) {
        row_max[ncpe - 1] = max(row_max[ncpe - 1], rmax_);
    } else if(tgt_rank > 0) {
        row_max[tgt_rank - 1] = rmax_;
    }
}

Int partition_spgemm_flops_multicg(
        Int m, Int n, Int pncpe, Int cncpe, Int cgid, const Int *a_row_off, const Int *a_col_idx, const Int* b_row_off, 
        const Int* d_row_off, Int *c_nf, spgemm::ex_buffer_t* buffer, spgemm::cpe_state_t& s REQUIRE_ANNZ(a_nnz)) {
    SIMD_ALIGN Int temp_dist[64 * 6], temp_nnz_max[64 * 6];
    int64_t temp_nf[65], status;
    auto mem_temp = &buffer[cgid];
    Int tid = CPE_ID, gid = tid + cgid * 64;
    DMA_DECL_DESC(READ_WRITE)
    if(gid < pncpe) {
        put_rd_communicator<simd_t<Int>, 384 / simd_width<Int>> comm(tid);
        Int q = m / pncpe, r = m % pncpe;
        Int roffset = gid * q + ((gid < r) ? gid : r);
        Int size    =       q + ((gid < r) ? 1   : 0);
        Int rend    = roffset + size;

        fill(temp_dist, cncpe, 0);
        fill(temp_nnz_max, cncpe, 0);
#ifdef SPGEMM_PARTITION_ANNZ
        count_flops_partition_annz(roffset, rend, a_nnz, a_row_off, a_col_idx, b_row_off, d_row_off, c_nf, \
                temp_dist, temp_nnz_max, n, cncpe);
#else
        int64_t prev, curr = count_flops(roffset, rend, a_row_off, a_col_idx, b_row_off, d_row_off, c_nf);

        CRTS_ssync_array();  // SYNC X
        if(tid == 27) {
            temp_nf[tid] = curr;
            CRTS_ssync_array();
            DMA_WRITE(mem_temp->i64, temp_nf, sizeof(int64_t) * 64);
            mem_fence();
            status = SYNC_SIGNAL_ENFLOPS;
            mem_temp->sync_signal = status;
            while(status == SYNC_SIGNAL_ENFLOPS) {
                status = mem_temp->sync_signal;
            }
            DMA_IREAD(mem_temp->i64, temp_nf, sizeof(int64_t) * 64);
            temp_nf[64] = status;
            DMA_WAIT_ALL;
            CRTS_ssync_array();
            prev = temp_nf[tid];
        } else {
            *remote_ldm_addr(&temp_nf[tid], 27) = curr;  // after SYNC X: temp_nf is ready
            CRTS_ssync_array();
            CRTS_ssync_array();
            prev = *remote_ldm_addr(&temp_nf[tid], 27);
            status = *remote_ldm_addr(&temp_nf[64], 27);
        }

        if(status == SYNC_SIGNAL_EXCEPT) {
            return status;
        }

        spgemm_scan_partition(roffset, size, buffer[0].i64[65], prev, c_nf, temp_dist, temp_nnz_max, n, cncpe);
#endif
        comm.template reduce<reduce_bitor_t>(27, 8, 8, reinterpret_cast<simd_t<Int>*>(&temp_dist[0]), cncpe / simd_width<Int>);
        comm.template reduce<reduce_imax_t>(27, 8, 8, reinterpret_cast<simd_t<Int>*>(&temp_nnz_max[0]), cncpe / simd_width<Int>);
        
        if(tid == 27) {
            DMA_IWRITE(mem_temp->dist, temp_dist, sizeof(Int) * cncpe);
            DMA_WRITE(mem_temp->i32, temp_nnz_max, sizeof(Int) * cncpe);
            mem_fence();
        }
    }
    if(tid == 27) {
        mem_temp->sync_signal = SYNC_SIGNAL_EDIST;
    }
    if(gid < cncpe) {
        if(tid == 27) {
            status = mem_temp->sync_signal;
            while(status != SYNC_SIGNAL_BCOMP && status != SYNC_SIGNAL_EXCEPT) {
                status = mem_temp->sync_signal;
            }
            temp_nf[64] = status;
            CRTS_ssync_array();
        } else {
            CRTS_ssync_array();
            status = *remote_ldm_addr(&temp_nf[64], 27);
        }
        if(status == SYNC_SIGNAL_EXCEPT) {
            return status;
        }

        DMA_READ(&buffer[0].dist[gid], temp_dist, sizeof(Int) * 2);

        s.current_row = temp_dist[0];
        s.end_row = (gid == cncpe - 1) ? m : temp_dist[1];
        s.max_nnz = buffer[0].i32[gid];
    }
    return 0;
}

template<size_t element_size>
NOINLINE static void pack(Int nfull, Int last, Int *global_idx, void *global_val_v, void **buffers) {
    typedef uint8_t (*val_ptr_t)[element_size];
    DMA_DECL_DESC(READ_WRITE);

    void *pointers[ptr_tile];
    alignas(8) uint8_t val_buffer[copy_tile_i<element_size>][element_size];
    Int idx_buffer[copy_tile_i<element_size>];

    Int i, j, k, na = nfull + 1;

    val_ptr_t global_val = reinterpret_cast<val_ptr_t>(global_val_v);
    val_ptr_t chunk_val;
    Int *chunk_idx;

    for(j = 0; j < na; j += ptr_tile) {
        Int len_1 = min(ptr_tile, nfull - j);
        Int len_2 = min(ptr_tile, na - j);
        DMA_READ(buffers + j, pointers, len_2 * sizeof(void*));
        for(k = 0; k < len_1; ++k) {
            chunk_val = reinterpret_cast<val_ptr_t>(pointers[k]);
            chunk_idx = reinterpret_cast<Int*>(chunk_val + chunk_size_i<element_size>);
            for(i = 0; i < chunk_size_i<element_size>; i += copy_tile_i<element_size>) {
                DMA_IREAD(chunk_val + i, val_buffer, copy_tile_i<element_size> * element_size);
                DMA_SREAD(chunk_idx + i, idx_buffer, copy_tile_i<element_size> * sizeof(Int));
                DMA_IWRITE(global_val + i, val_buffer, copy_tile_i<element_size> * element_size);
                DMA_SWRITE(global_idx + i, idx_buffer, copy_tile_i<element_size> * sizeof(Int));
            }
            global_val += chunk_size_i<element_size>;
            global_idx += chunk_size_i<element_size>;
        }
        if(len_1 < len_2) {
            chunk_val = reinterpret_cast<val_ptr_t>(pointers[len_1]);
            chunk_idx = reinterpret_cast<Int*>(chunk_val + chunk_size_i<element_size>);
            for(i = 0; i < last; i += copy_tile_i<element_size>) {
                const Int len = min(copy_tile_i<element_size>, last - i);
                DMA_IREAD(chunk_val + i, val_buffer, len * element_size);
                DMA_SREAD(chunk_idx + i, idx_buffer, len * sizeof(Int));
                DMA_IWRITE(global_val + i, val_buffer, len * element_size);
                DMA_SWRITE(global_idx + i, idx_buffer, len * sizeof(Int));
            }
        }
    }
    DMA_WAIT_ALL;
}

NOINLINE static void build_offsets(Int r_begin, Int r_end, Int base, Int *c_row_off) {
    Int local_c_off[r_tile];
    Int i, j;

    DMA_DECL_DESC(READ_WRITE);
    
    for(i = r_begin; i < r_end; i += r_tile) {
        Int len = min(r_tile, r_end - i);
        DMA_READ(c_row_off + i, local_c_off, len * sizeof(Int));
        for(j = 0; j < len; ++j) {
            base += local_c_off[j];
            local_c_off[j] = base;
        }
        DMA_SWRITE(c_row_off + i, local_c_off, len * sizeof(Int));
    }
    DMA_WAIT_ALL;
}

template<typename DATA_T>
void spgemm_postprocess_multicg(spgemm::postprocess_t<DATA_T>& args, spgemm::result_t& result, Int* c_offset, Int b_row, Int e_row) {
    pack<sizeof(DATA_T)>(result.nfull, result.last, args.c_col_idx + result.tgt_offset, \
        args.c_values + result.tgt_offset, result.buffers);
    build_offsets(b_row, e_row, result.tgt_offset, c_offset + 1);
}

template void spgemm_postprocess_multicg<float>(spgemm::postprocess_t<float>&, spgemm::result_t&, Int*, Int, Int);
template void spgemm_postprocess_multicg<double>(spgemm::postprocess_t<double>&, spgemm::result_t&, Int*, Int, Int);
template void spgemm_postprocess_multicg<SComplex>(spgemm::postprocess_t<SComplex>&, spgemm::result_t&, Int*, Int, Int);
template void spgemm_postprocess_multicg<DComplex>(spgemm::postprocess_t<DComplex>&, spgemm::result_t&, Int*, Int, Int);

} // namespace swSparse
