#include "internal/multicompile.h"

#ifdef DATA_TYPE_S
#define MLEN 400
#endif
#ifdef DATA_TYPE_D
#define MLEN 200
#endif
#ifdef DATA_TYPE_C
#define MLEN 200
#endif
#ifdef DATA_TYPE_Z
#define MLEN 100
#endif

#ifndef CAL_ID_343
#define CAL_ID_343

static int Cal_ID_343(int ids[16]) //Need Row Synchronous
{
	int id = -1;
	int gr = -1, gc = -1, pr = -1, pc = -1;
	int ps = -1, gs = -1;
	int row = ROW(CPE_ID);
	int col = COL(CPE_ID);
	gr = (col+COLS-1)%COLS;
	gc = (row+ROWS-1)%ROWS;
	pr = (col+1)%COLS;
	pc = (row+1)%ROWS;
	if(col == 0)
	{
		gs = gr;
		gr = -1;
	}
	if(col == 7)
	{
		ps = pr;
		pr = -1;
	}
	if (row == 7) pc = -1;
	row = (row-3*col+ROWS*ROWS)%ROWS;
	id = col*8+row;
	//printf("%d(R:%d C:%d)(pr:%d gr:%d pc:%d gc:%d)(%d %d)\n", id, row, col, pr, gr, pc, gc, ps, gs);
	ids[0] = id;
	ids[1] = row;
	ids[2] = col;
	ids[3] = pr;
	ids[4] = gr;
	ids[5] = pc;
	ids[6] = gc;
	ids[7] = ps;
	ids[8] = gs;
	return 0;
}

#endif

void FUNCNAME(ilu0_343_kernel)(const DATA_T *a, DATA_T *l, DATA_T *u, int M, int N, int L, int lnz, int nnz, DATA_T *_ptr, int* m_pos, int HALO)
{
    int id = -1, rid = -1, cid = -1;
	int gr = -1, gc = -1, pr = -1, pc = -1;
	int ps = -1, gs = -1;
	//Init id information
	{
		int ids[16];
		Cal_ID_343(ids);
		id  = ids[0];
		rid = ids[1];
		cid = ids[2];
		pr  = ids[3];
		gr  = ids[4];
		pc  = ids[5];
		gc  = ids[6];
		ps  = ids[7];
		gs  = ids[8];
	}
    #define MATRIX_BUFFER 1024
	int pos_dj[25] = {-3, -2, -1, 0, 1, 2, 3, -3, -2, -1, 0, 1, 2, 3, \
	-3, -2, -1, 0, 1, 2, 3, -3, -2, -1, 0};
	int pos_di[25] = {-3, -3, -3, -3, -3, -3, -3, -2, -2, -2, -2, -2, -2, -2, \
	-1, -1, -1, -1, -1, -1, -1, 0, 0, 0, 0};
	int should_reg[25] = {0, 2, 2, 2, 0, 0, 0, 1, 4, 4, 4, 0, 0, 0, \
	1, 4, 4, 4, 0, 0, 0, 1, 4, 4, 4};
	int should_dma[25];
	int not_from_reg[25];
	//Begin Cal
    {
		char testout[128];
		int rnz = nnz - lnz;
		int col_id[rnz];
		int z_offset[rnz];
		DATA_T *ptr = _ptr;
		// volatile int reply = 0;
		// volatile int COUNT = 0;
		int i = 0,j = 0,k = 0,K = 0;
		int ii, jj, kk;
		int oi, oj, ok;
		int ti, tj, tk;
		int bi = 0, bj = 0, bk = 0, bii = 0, bjj = 0;
		int count = 0, zcount = 0;
		DATA_T *abuf , *ubuf;
		int *pos;
		unsigned long time1, time2, time3, time4;
		unsigned long DMA_time = 0, REG_time = 0, T_time = 0;
		// dma_desc dma_get;
		// dma_desc dma_put;
		// WXL_DMA_SET_NOSIZE(&dma_get, DMA_GET, &reply);
		// WXL_DMA_SET_NOSIZE(&dma_put, DMA_PUT, &reply);
		DMA_DECL_DESC(READ_WRITE);
		//Init LX pointer
		int halo = HALO / 2;
		int LEN = gridmin(L, (MAX_GRID_SIZE*8-sizeof(int)*nnz*3-sizeof(DATA_T)*rnz)/sizeof(DATA_T)/nnz-halo);
		int SIZE = LEN;

        abuf = _ptr;
		ptr += (LEN + halo) * nnz;
		ubuf = ptr;
		ptr += rnz;
		pos = (int*)ptr;
		DMA_READ(m_pos, pos, 3*sizeof(int)*nnz);
        // WXL_DMA_NEW(dma_get, , COUNT);
        // dma_wait(&reply, COUNT);
        
		int v[7][7][7];
		for (i = 0; i < 7; i++)
		for (j = 0; j < 7; j++)
		for (k = 0; k < 7; k++)
		{
			v[i][j][k] = -1;
		}
		for (i = 0; i < nnz; i++)
		{
			oi = pos[3 * i] + 3;
			oj = pos[3 * i + 1] + 3;
			ok = pos[3 * i + 2] + 3;
			v[oi][oj][ok] = i;
		}
		
		// if (id == 0)
		// {
		// 	printf("LEN:%d\n", LEN);
		// 	printf("-3-3-3 %d\n", v[0][0][0]);
		// }
		int is = (M + COLS - 1) / COLS;
		int js;
		for (i = cid; i < cid + is * COLS; i+=COLS)
		{
			int width = gridmin(M - (i - cid), COLS);
			int right_off;
			if (width <= 3)
			{
				right_off = 8 - (width - 1) * 3;
				js = (N - right_off + ROWS - 1) / ROWS + 1;
			}
			else if (width <= 6)
			{
				right_off = 7 - (width - 4) * 3;
				js = (N - right_off + ROWS - 1) / ROWS + 2;
			}
			else
			{
				right_off = 6 - (width - 7) * 3;
				js = (N - right_off + ROWS - 1) / ROWS + 3;
			}
			for (j = ROW(CPE_ID) - 3 * cid; j < ROW(CPE_ID) - 3 * cid + js * ROWS; j+=ROWS)
			{
				count = bi = bj = bii = bjj = halo;
				for (ii = 0; ii < halo; ii++)
					for (jj = 0; jj < nnz; jj++)
						abuf[ii*nnz+jj] = 0;
				if (j >= 0 && j <= N + 2 && i < M)
				{
					//asm volatile ("rcsr %0, 4\n":"=r"(time3));
					for (ii = 0; ii <= 24; ii++)
					{
						oi = i + pos_di[ii];
						oj = j + pos_dj[ii];
						if (oi >= 0 && oi < M && oj >= 0 && oj < N) should_dma[ii] = 1; else should_dma[ii] = 0;
					}
					int g_off = i*N*L + j*L;
					if (j < N)
					{
						for (K = 0; K < L; K += SIZE)
						{
							T_time = DMA_time = REG_time = 0;
							LEN = gridmin(L - K, SIZE);
							//asm volatile ("rcsr %0, 4\n":"=r"(time1));
							// WXL_DMA_NEW(dma_get, , COUNT);
							// dma_wait(&reply, COUNT);
							DMA_READ(a+nnz*(g_off+K), abuf + halo*nnz, sizeof(DATA_T)*nnz*LEN);
							//asm volatile ("rcsr %0, 4\n":"=r"(time2));
							//DMA_time += time2 - time1;
							for (k = 0; k < LEN; k++)
							{
								int iter;
								for (iter = 0; iter <= 24; iter++)
								{
									int from_row = 0;
									oi = iter / 7 - 3;
									oj = iter % 7 - 3;
									if (oi < 0 && oj >= 0) from_row = 1;
									for (ok = -halo; ok <= halo; ok++)
									{
										int k_pos = K+k+ok;
										if (iter == 24)
										{
											if (ok >= 0 || k_pos < 0) continue;
											for (ii = 0; ii < rnz; ii++)
											{
												ubuf[ii] = abuf[nnz*(halo+k+ok)+lnz+ii];
											}
										}
										else if (ok < 0 || K + k >= L - halo)
										{
											if (should_dma[iter] && k_pos >= 0 && k_pos < L)
											{
												//asm volatile ("rcsr %0, 4\n":"=r"(time1));
												DMA_READ(u+rnz*(g_off+oi*N*L+oj*L+k_pos), ubuf, sizeof(DATA_T)*rnz);
												// WXL_DMA_NEW(dma_get, , COUNT);
												// dma_wait(&reply, COUNT);
												//asm volatile ("rcsr %0, 4\n":"=r"(time2));
												//DMA_time += time2 - time1;
											}
											else
											{
												for (ii = 0; ii < rnz; ii++)
													ubuf[ii] = 0;
											}
										}
										else if (from_row)
										{
											if (cid == 0)
											{
												if (should_dma[iter] && k_pos >= 0 && k_pos < L)
												{
													//asm volatile ("rcsr %0, 4\n":"=r"(time1));
													DMA_READ(u+rnz*(g_off+oi*N*L+oj*L+k_pos), ubuf, sizeof(DATA_T)*rnz);
													// WXL_DMA_NEW(dma_get, , COUNT);
													// dma_wait(&reply, COUNT);
													//asm volatile ("rcsr %0, 4\n":"=r"(time2));
													//DMA_time += time2 - time1;
												}
												else
												{
													for (ii = 0; ii < rnz; ii++)
														ubuf[ii] = 0;
												}
											}
											else
											{
												//asm volatile ("rcsr %0, 4\n":"=r"(time1));
												for (ii = 0; ii < rnz; ii++)
												{
													GGETR(ubuf[ii]);
												}
												//asm volatile ("rcsr %0, 4\n":"=r"(time2));
												//REG_time += time2 - time1;
												// if (i == 1 && j == 1)
												// {
												// 	sprintf(testout, "%d %d got row %d on %d %d\n", i, j, iter, K+k, k_pos);
												// 	printf(testout);
												// }
											}
										}
										else
										{
											if (ROW(CPE_ID) == 0||j == 0)
											{
												if (should_dma[iter] && k_pos >= 0 && k_pos < L)
												{
													//asm volatile ("rcsr %0, 4\n":"=r"(time1));
													DMA_READ(u+rnz*(g_off+oi*N*L+oj*L+k_pos), ubuf, sizeof(DATA_T)*rnz);
													// WXL_DMA_NEW(dma_get, , COUNT);
													// dma_wait(&reply, COUNT);
													//asm volatile ("rcsr %0, 4\n":"=r"(time2));
													//DMA_time += time2 - time1;
												}
												else
												{
													for (ii = 0; ii < rnz; ii++)
														ubuf[ii] = 0;
												}
											}
											else
											{
												//asm volatile ("rcsr %0, 4\n":"=r"(time1));
												for (ii = 0; ii < rnz; ii++)
												{
													GGETC(ubuf[ii]);
												}
												//asm volatile ("rcsr %0, 4\n":"=r"(time2));
												//REG_time += time2 - time1;
												// if (i == 1 && j == 1)
												// {
												// 	sprintf(testout, "%d %d got col %d on %d %d\n", i, j, iter, K+k, k_pos);
												// 	printf(testout);
												// }
											}
										}
										if (should_dma[iter] && k_pos >= 0 && k_pos < L && v[oi+3][oj+3][ok+3] != -1)
										{
											abuf[(k+halo)*nnz+v[oi+3][oj+3][ok+3]] /= ubuf[0];
											DATA_T aik = abuf[(k+halo)*nnz+v[oi+3][oj+3][ok+3]];
											for (ii = 1; ii < rnz; ii++)
											{
												int temp = lnz + ii;
												ti = oi + pos[temp*3] + 3;
												tj = oj + pos[temp*3+1] + 3;
												tk = ok + pos[temp*3+2] + 3;
												if (ti >= 0 && ti < 7 && tj >= 0 && tj < 7 && tk >= 0 && tk < 7 && v[ti][tj][tk] != -1)
												{
													abuf[(k+halo)*nnz+v[ti][tj][tk]] -= ubuf[ii] * aik;
												}
											}
										}
										if (K + k >= halo)
										{
											if (ok <= 0 && (should_reg[iter] == 4 || should_reg[iter] == 1))
											{
												if (pr >= 0 && j > 2 && i < M-1)
												{
													//asm volatile ("rcsr %0, 4\n":"=r"(time1));
													for (ii = 0; ii < rnz; ii++)
													{
														GPUTR(ubuf[ii], pr);
													}
													//asm volatile ("rcsr %0, 4\n":"=r"(time2));
													//REG_time += time2 - time1;
												}
											}
											if (ok <= 0 && (should_reg[iter] == 4 || should_reg[iter] == 2))
											{
												if (pc >= 0)
												{
													// if (i == 1 & j == 1)
													// {
													// 	sprintf(testout, "%d %d putting col %d on %d %d\n", i, j, iter, K+k, k_pos);
													// 	printf(testout);
													// }
													//asm volatile ("rcsr %0, 4\n":"=r"(time1));
													for (ii = 0; ii < rnz; ii++)
													{
														GPUTC(ubuf[ii], pc);
													}
													//asm volatile ("rcsr %0, 4\n":"=r"(time2));
													//REG_time += time2 - time1;
													// if (i == 1 & j == 1)
													// {
													// 	sprintf(testout, "%d %d done putting col %d\n", i, j, iter);
													// 	printf(testout);
													// }
												}
											}
										}
									}
								}
								//asm volatile ("rcsr %0, 4\n":"=r"(time1));
								DMA_WRITE(u+(g_off+K+k)*rnz, abuf+(halo+k)*nnz+lnz, sizeof(DATA_T)*rnz);
								// WXL_DMA_NEW(dma_put, , COUNT);
								// dma_wait(&reply, COUNT);
								//asm volatile ("rcsr %0, 4\n":"=r"(time2));
								//DMA_time += time2 - time1;
								if (pr >= 0 && j > 2 && i < M-1 && K + k >= halo)
								{
									//asm volatile ("rcsr %0, 4\n":"=r"(time1));
									for (ii = 0; ii < rnz; ii++)
									{
										GPUTR(abuf[(k+halo)*nnz+lnz+ii], pr);
									}
									//asm volatile ("rcsr %0, 4\n":"=r"(time2));
									//REG_time += time2 - time1;
								}
								if (pc >= 0 && K + k >= halo)
								{
									//asm volatile ("rcsr %0, 4\n":"=r"(time1));
									for (ii = 0; ii < rnz; ii++)
									{
										GPUTC(abuf[(k+halo)*nnz+lnz+ii], pc);
									}
									//asm volatile ("rcsr %0, 4\n":"=r"(time2));
									//REG_time += time2 - time1;
								}
								//asm volatile ("rcsr %0, 4\n":"=r"(time1));
								DMA_WRITE(l+(g_off+K+k)*lnz, abuf+(halo+k)*nnz, sizeof(DATA_T)*lnz);
								// WXL_DMA_NEW(dma_put, , COUNT);
								// dma_wait(&reply, COUNT);
								//asm volatile ("rcsr %0, 4\n":"=r"(time2));
								//DMA_time += time2 - time1;
							}
							for (ii = 0; ii < halo*nnz; ii++)
							{
								abuf[ii] = abuf[LEN*nnz+ii];
							}
						}
					}
					else
					{
						// sprintf(testout, "%d %d begin\n", i, j);
						// printf(testout);
						for (K = 0; K < L; K += SIZE)
						{
							LEN = gridmin(L - K, SIZE);
							for (k = 0; k < LEN; k++)
							{
								int iter;
								for (iter = 0; iter <= 24; iter++)
								{
									int from_row = 0;
									oi = iter / 7 - 3;
									oj = iter % 7 - 3;
									if (oi < 0 && oj >= 0) from_row = 1;
									for (ok = -halo; ok <= halo; ok++)
									{
										int k_pos = K+k+ok;
										if (iter == 24)
										{
											if (ok >= 0 || k_pos < 0) continue;
											for (ii = 0; ii < rnz; ii++)
											{
												ubuf[ii] = 0;
											}
										}
										else if (ok < 0 || K + k >= L - halo)
										{
											if (should_dma[iter] && k_pos >= 0 && k_pos < L)
											{
												DMA_READ(u+rnz*(g_off+oi*N*L+oj*L+k_pos), ubuf, sizeof(DATA_T)*rnz);
												// WXL_DMA_NEW(dma_get, , COUNT);
												// dma_wait(&reply, COUNT);
											}
											else
											{
												for (ii = 0; ii < rnz; ii++)
													ubuf[ii] = 0;
											}
										}
										else if (from_row)
										{
											// // if (i == 0 && j == 1) printf("haha\n");
											// if (cid == 0)
											// {
											// 	if (should_dma[iter] && k_pos >= 0 && k_pos < L)
											// 	{
											// 		WXL_DMA_NEW(dma_get, u+rnz*(g_off+oi*N*L+oj*L+k_pos), ubuf, sizeof(DATA_T)*rnz, COUNT);
											// 		dma_wait(&reply, COUNT);
											// 	}
											// 	else
											// 	{
													for (ii = 0; ii < rnz; ii++)
														ubuf[ii] = 0;
											// 	}
											// }
											// else
											// {
											// 	for (ii = 0; ii < rnz; ii++)
											// 	{
											// 		GGETR(ubuf[ii]);
											// 	}
											// }
										}
										else
										{
											// if (i == 0 && j == 1) printf("hahaduile\n");
											if (ROW(CPE_ID) == 0||j == 0)
											{
												if (should_dma[iter] && k_pos >= 0 && k_pos < L)
												{
													DMA_READ(u+rnz*(g_off+oi*N*L+oj*L+k_pos), ubuf, sizeof(DATA_T)*rnz);
													// WXL_DMA_NEW(dma_get, , COUNT);
													// dma_wait(&reply, COUNT);
												}
												else
												{
													for (ii = 0; ii < rnz; ii++)
														ubuf[ii] = 0;
												}
											}
											else
											{
												// sprintf(testout, "%d %d getting col %d on %d %d\n", i, j, iter, K+k, k_pos);
												// printf(testout);
												for (ii = 0; ii < rnz; ii++)
												{
													GGETC(ubuf[ii]);
												}
												// sprintf(testout, "%d %d done getting col %d\n", i, j, iter);
												// printf(testout);
											}
										}
										if (K + k >= halo)
										{
											if (ok <= 0 && (should_reg[iter] == 4 || should_reg[iter] == 1))
											{
												if (pr >= 0 && j > 2 && i < M-1)
												{
													for (ii = 0; ii < rnz; ii++)
													{
														GPUTR(ubuf[ii], pr);
													}
												}
											}
											if (ok <= 0 && (should_reg[iter] == 4 || should_reg[iter] == 2))
											{
												if (pc >= 0 && j <= N+1)
												{
													// sprintf(testout, "%d %d putting col %d on k %d %d\n", i, j, iter, K + k, k_pos);
													// printf(testout);
													for (ii = 0; ii < rnz; ii++)
													{
														GPUTC(ubuf[ii], pc);
													}
													// sprintf(testout, "%d %d done putting col %d\n", i, j, iter);
													// printf(testout);
												}
											}
										}
									}
								}
								if (pr >= 0 && j > 2 && i < M-1 && K + k >= halo)
								{
									for (ii = 0; ii < rnz; ii++)
									{
										GPUTR(ubuf[0], pr);
									}
								}
								if (pc >= 0 && j <= N+1 && K + k >= halo)
								{
									for (ii = 0; ii < rnz; ii++)
									{
										GPUTC(ubuf[0], pc);
									}
								}
							}
						}
					}
					// sprintf(testout, "%d %d done\n", i, j);
					// printf(testout);
					// asm volatile ("rcsr %0, 4\n":"=r"(time4));
					// T_time += time4 - time3;
					// sprintf(testout, "DMA: %d id %.4f %.2f\n", id, 1.0 * DMA_time / T_time, 1.0 * DMA_time / 1e3);
					// if (id == 11) printf(testout);
					// sprintf(testout, "REG: %d id %.4f %.2f\n", id, 1.0 * REG_time / T_time, 1.0 * REG_time / 1e3);
					// if (id == 11) printf(testout);
				}
				SYNC_ALL;
			}
		}
	}
}

void SLAVE_FUNCNAME(ilu0_343_slave)(void *_ptr)
{
        DATA_T data[MAX_GRID_SIZE*8/sizeof(DATA_T)];
        // volatile int reply = 0;
        // volatile int COUNT = 0;
        Info info;
        // dma_desc dma_get;
        // WXL_DMA_SET_NOSIZE(&dma_get, DMA_GET, &reply);
        // WXL_DMA_NEW(dma_get, , COUNT);
        // dma_wait(&reply, COUNT);
		DMA_DECL_DESC(READ);
		DMA_READ(_ptr, &info, sizeof(Info));
        #ifdef DATA_TYPE_S
        swSparse_s_ilu0_343_kernel(info.A, info.l, info.u, info.M, info.N, info.L, info.lnz, info.nnz, (DATA_T*)data, info.pos, info.HALO);
        #endif
        #ifdef DATA_TYPE_D
        swSparse_d_ilu0_343_kernel(info.A, info.l, info.u, info.M, info.N, info.L, info.lnz, info.nnz, (DATA_T*)data, info.pos, info.HALO);
        #endif
        #ifdef DATA_TYPE_C
        swSparse_c_ilu0_343_kernel(info.A, info.l, info.u, info.M, info.N, info.L, info.lnz, info.nnz, (DATA_T*)data, info.pos, info.HALO);
        #endif
        #ifdef DATA_TYPE_Z
        swSparse_z_ilu0_343_kernel(info.A, info.l, info.u, info.M, info.N, info.L, info.lnz, info.nnz, (DATA_T*)data, info.pos, info.HALO);
        #endif
        return;
}

#undef MLEN
