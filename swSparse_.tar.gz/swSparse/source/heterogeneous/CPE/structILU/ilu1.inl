#include "internal/multicompile.h"

#ifdef DATA_TYPE_S
#define MLEN 400
#endif
#ifdef DATA_TYPE_D
#define MLEN 300
#endif
#ifdef DATA_TYPE_C
#define MLEN 300
#endif
#ifdef DATA_TYPE_Z
#define MLEN 150
#endif

#ifndef CAL_ID_125
#define CAL_ID_125

static int Cal_ID_125(int ids[16]) //Need Row Synchronous
{
	int id = -1;
	int gr = -1, gc = -1, pr = -1, pc = -1;
	int ps = -1, gs = -1;
	int row = ROW(CPE_ID);
	int col = COL(CPE_ID);
	gr = (col+COLS-1)%COLS;
	gc = (row+ROWS-1)%ROWS;
	pr = (col+1)%COLS;
	pc = (row+1)%ROWS;
	if(col == 0)
	{
		gs = gr;
		gr = -1;
	}
	if(col == 7)
	{
		ps = pr;
		pr = -1;
	}
	if (row == 7) pc = -1;
        if (row == 0) gc = -1;
	row = (row-2*col+ROWS*ROWS)%ROWS;
	id = col*8+row;
	ids[0] = id;
	ids[1] = row;
	ids[2] = col;
	ids[3] = pr;
	ids[4] = gr;
	ids[5] = pc;
	ids[6] = gc;
	ids[7] = ps;
	ids[8] = gs;
	return 0;
}

#endif

void FUNCNAME(ilu1_27_kernel)(const DATA_T *a, DATA_T *l, DATA_T *u, int M, int N, int L, int lnz, int nnz, DATA_T *_ptr, int* m_pos, int onnz, int *a_pos, int HALO)
{
        char testout[128];
        int id = -1, rid = -1, cid = -1;
        int gr = -1, gc = -1, pr = -1, pc = -1;
        int ps = -1, gs = -1;
        //Init id information
        {
                int ids[16];
                Cal_ID_125(ids);
                id  = ids[0];
                rid = ids[1];
                cid = ids[2];
                pr  = ids[3];
                gr  = ids[4];
                pc  = ids[5];
                gc  = ids[6];
                ps  = ids[7];
                gs  = ids[8];
        }
	int pos_dj[12] = {-2, -1, 0, 1, 2, -2, -1, 0, 1, 2, -2, -1};
	int pos_di[12] = {-2, -2, -2, -2, -2, -1, -1, -1, -1, -1, 0, 0};
	int should_dma[12];
	int not_from_reg[12];

        int rnz = nnz - lnz;
        int LEN = gridmin(L, MAX_GRID_SIZE*0.8*8/sizeof(DATA_T)/(13*rnz + lnz)-HALO);
        int SIZE = LEN;
        int halo = HALO / 2;
        int ALEN = (MAX_GRID_SIZE*8/sizeof(DATA_T)-13*(LEN+HALO)*rnz-LEN*lnz)/onnz;
        DATA_T *ptr = _ptr;
        // volatile int reply = 0;
        // volatile int COUNT = 0;

        // if (id == 0)
        // {
        //         printf("%d %d %d %d %d\n", nnz, lnz, rnz, onnz, LEN);
        // }
        DATA_T *LUB[13], *LLB, *LAA, *LA_begin, *LA_end;
        DATA_T *LA;
        DATA_T rbuf[nnz];

        int i = 0, j = 0, k = 0, K = 0;
        int bi = 0, bj = 0, bk = 0, bii = 0, bjj = 0;
        int count = 0, zcount = 0;

        // dma_desc dma_get;
        // dma_desc dma_put;
        // WXL_DMA_SET_NOSIZE(&dma_get, DMA_GET, &reply);
        // WXL_DMA_SET_NOSIZE(&dma_put, DMA_PUT, &reply);
        DMA_DECL_DESC(READ_WRITE);
        int pos[3 * nnz];
        // WXL_DMA_NEW(dma_get, , COUNT);
        DMA_IREAD(m_pos, pos, 3*sizeof(int)*nnz);
        int apos[onnz];
        // WXL_DMA_NEW(dma_get, , COUNT);
        DMA_IREAD(a_pos, apos, sizeof(int)*onnz);
        DMA_WAIT_ALL;

        int v[7][7][7];
        int oi, oj, ok;
	for (i = 0; i < 7; i++)
	for (j = 0; j < 7; j++)
	for (k = 0; k < 7; k++)
	{
		v[i][j][k] = -1;
	}
        for (i = 0; i < nnz; i++)
	{
		oi = pos[3 * i] + 3;
		oj = pos[3 * i + 1] + 3;
		ok = pos[3 * i + 2] + 3;
		v[oi][oj][ok] = i;
	}

        int ii, jj, kk;
        for (ii = 0; ii < 13; ii++)
        {
                LUB[ii] = (DATA_T*)ptr;
                for (jj = 0; jj < (LEN + HALO) * rnz; jj++)
                        LUB[ii][jj] = 0;
                ptr += (SIZE + HALO) * rnz;
        }
        LLB = (DATA_T*)ptr;
        ptr += SIZE * lnz;
        LA_begin = ptr; ptr += onnz * ALEN; LA_end = ptr;
        // for (i = 0; i < nnz; i++)
        // {
        //         if (id == 0)printf("%d %d %d\n", pos[i * 3], pos[i * 3+1],pos[i * 3+2]);
        // }
        int is = (M + COLS - 1) / COLS;
        int js;
        for (i = cid; i < cid + is * COLS; i+=COLS)
        {
                int width = gridmin(M - (i - cid), COLS);
                int right_off;
                if (width <= 4)
                {
                        right_off = 8 - (width - 1) * 2;
                        if (N <= right_off)
                                js = 1;
                        else
                                js = (N - right_off + ROWS - 1) / ROWS + 1;
                }
                else
                {
                        right_off = 8 - (width - 4) * 2;
                        if (N <= right_off)
                                js = 2;
                        else
                                js = (N - right_off + ROWS - 1) / ROWS + 2;
                }     
                for (j = ROW(CPE_ID) - 2 * cid; j < ROW(CPE_ID) - 2 * cid + js * ROWS; j+=ROWS)
                {
                        count = bi = bj = bii = bjj = halo;
                        for (ii = 0; ii <= 12; ii++)
                                for (jj = 0; jj < halo * rnz; jj++)
                                {
                                        LUB[ii][jj] = 0;
                                }
                        if (j >= 0 && j <= N + 1 && i < M)
                        {
                                for (ii = 0; ii < 12; ii++)
                                {
                                        oi = i + pos_di[ii];
                                        oj = j + pos_dj[ii];
                                        if (oi >= 0 && oi < M && oj >= 0 && oj < N) should_dma[ii] = 1; else should_dma[ii] = 0;
                                }
                                if (COL(CPE_ID) == 0||j >= N) bi += L;
                                if (ROW(CPE_ID) == 0||j == 0) bj += L;
                                if (j < N)
                                {
                                        int alen = onnz * (ALEN < L ? ALEN : L);
                                        DMA_IREAD(a+onnz*((i*N+j)*L), LA_begin,sizeof(DATA_T)*alen);
                                        // WXL_DMA_NEW(dma_get, , COUNT);
                                        LA = LA_begin;
                                        for (K = 0; K < L; K+= SIZE)
                                        {
                                                int off_up;
                                                if (K + SIZE > L - 1)
                                                        off_up = 0;
                                                else
                                                        off_up = gridmin(L - K - SIZE, halo);
                                                LEN = gridmin(L - K, SIZE);
                                                if (cid == 0)
                                                {
                                                        for (ii = 0; ii < 3; ii++)
                                                        {
                                                                int t_coid = ii + 2;
                                                                if (should_dma[t_coid])
                                                                {
                                                                        DMA_IREAD(u+(i*N*L+j*L+pos_di[t_coid]*N*L+pos_dj[t_coid]*L+K)*rnz, LUB[t_coid]+halo*rnz, sizeof(DATA_T)*(LEN+off_up)*rnz);
                                                                        //WXL_DMA_NEW(dma_get, , COUNT);
                                                                }
                                                                else
                                                                        for (jj = 0; jj < LEN + halo; jj++)
                                                                                for (kk = 0; kk < rnz; kk++)
                                                                                        LUB[t_coid][(jj+halo)*rnz+kk] = 0;
                                                                t_coid = ii + 7;
                                                                if (should_dma[t_coid])
                                                                {
                                                                        DMA_IREAD(u+(i*N*L+j*L+pos_di[t_coid]*N*L+pos_dj[t_coid]*L+K)*rnz, LUB[t_coid]+halo*rnz, sizeof(DATA_T)*(LEN+off_up)*rnz);
                                                                        // WXL_DMA_NEW(dma_get, , COUNT);
                                                                }
                                                                else
                                                                        for (jj = 0; jj < LEN + halo; jj++)
                                                                                for (kk = 0; kk < rnz; kk++)
                                                                                        LUB[t_coid][(jj+halo)*rnz+kk] = 0;
                                                        }
                                                }
                                                if (ROW(CPE_ID) == 0||j == 0)
                                                {
                                                        for (ii = 0; ii < 3; ii++)
                                                        {
                                                                for (jj = 0; jj < 2; jj++)
                                                                {
                                                                        int t_coid = ii*5 + jj;
                                                                        if (should_dma[t_coid])
                                                                        {
                                                                                DMA_IREAD(u+(i*N*L+j*L+pos_di[t_coid]*N*L+pos_dj[t_coid]*L+K)*rnz, LUB[t_coid]+halo*rnz, sizeof(DATA_T)*(LEN+off_up)*rnz);
                                                                                // WXL_DMA_NEW(dma_get, , COUNT);
                                                                        }
                                                                        else
                                                                                for (kk = 0; kk < (LEN + halo) * rnz; kk++)
                                                                                        LUB[t_coid][halo*rnz+kk] = 0;
                                                                }
                                                        }
                                                }
                                                // dma_wait(&reply, COUNT);
                                                DMA_WAIT_ALL;
                                                for (k = 0; k < LEN; k++)
                                                {
                                                        if(LA == LA_end)
                                                        {
                                                                LA = LA_begin;
                                                                alen = onnz * (ALEN < (L-K-k) ? ALEN : (L-K-k));
                                                                DMA_READ(a+onnz*((i*N+j)*L+K+k), LA_begin, sizeof(DATA_T)*alen);
                                                                // WXL_DMA_NEW(dma_get, , COUNT);
                                                                // dma_wait(&reply, COUNT);
                                                        }
                                                        int overlap = LEN;
                                                        // if (K + SIZE < L) overlap -= halo;
                                                        // overlap = gridmax(overlap, K + LEN + HALO - count);
                                                        while (count>=(bi-halo)&&bi!=L+halo||count>=(bj-halo)&&bj!=L+halo)
                                                        {
                                                                if (gr >= 0 && bi <= (count+halo) && !EMPTY_GETR())
                                                                {
                                                                        for (ii = 0; ii < rnz; ii++)
                                                                        {
                                                                                GGETR2(LUB[2][bii*rnz+ii], LUB[3][bii*rnz+ii]);
                                                                                GGETR2(LUB[4][bii*rnz+ii], LUB[7][bii*rnz+ii]);
                                                                                GGETR2(LUB[8][bii*rnz+ii], LUB[9][bii*rnz+ii]);
                                                                        }
                                                                        bii++;
                                                                        if (bii >= HALO+SIZE) bii -= SIZE;
                                                                        bi++;
                                                                }
                                                                if (gc >= 0 && bj <= (count+halo) && !EMPTY_GETC())
                                                                {
                                                                        for (ii = 0; ii < rnz; ii++)
                                                                        {
                                                                                GGETC2(LUB[0][bjj*rnz+ii], LUB[1][bjj*rnz+ii]);
                                                                                GGETC2(LUB[5][bjj*rnz+ii], LUB[6][bjj*rnz+ii]);
                                                                                GGETC2(LUB[10][bjj*rnz+ii], LUB[11][bjj*rnz+ii]);
                                                                        }
                                                                        bjj++;
                                                                        if (bjj >= HALO+SIZE) bjj -= SIZE;
                                                                        bj++;
                                                                }
                                                        }
                                                        //Compute
                                                        for (ii = 0; ii < nnz; ii++)
                                                                rbuf[ii] = 0;
                                                        for (ii = 0; ii < onnz; ii++)
                                                        {
                                                                rbuf[apos[ii]] = LA[ii];
                                                        }
                                                        for (ii = 0; ii < lnz; ii++)
                                                        {
                                                                int ti, tj, tk;
                                                                oi = pos[3 * ii];
                                                                oj = pos[3 * ii + 1];
                                                                ok = pos[3 * ii + 2];
                                                                ti = i + oi;
                                                                tj = j + oj;
                                                                tk = K + k + ok;
                                                                if (ti >= 0 && ti < M && tj >= 0 && tj < N && tk >= 0 && tk < L)
                                                                {
                                                                        // if (i == 0 && j == 0 && k == 2)
                                                                        // {
                                                                        //         printf("%d %d %d\n", oi, oj, ok);
                                                                        //         printf("pos\n");
                                                                        //         for (jj = 0; jj < nnz; jj++)
                                                                        //         {
                                                                        //                 printf("%d %d %d\n", pos[3*jj], pos[3*jj+1], pos[3*jj+2]);
                                                                        //         }
                                                                        //         printf("end\n");
                                                                        //         printf("%.4f\n", rbuf[8]);
                                                                        // }
                                                                        int col_pos = (oi + 2) * 5 + oj + 2;
                                                                        int k_pos = (k + ok + halo) * rnz;
                                                                        rbuf[ii] /= LUB[col_pos][k_pos];
                                                                        for (jj = 1; jj < rnz; jj++)
                                                                        {
                                                                                int temp = lnz + jj;
                                                                                ti = oi + 3 + pos[3 * temp];
                                                                                tj = oj + 3 + pos[3 * temp + 1];
                                                                                tk = ok + 3 + pos[3 * temp + 2];
                                                                                if (ti >= 0 && ti < 7 && tj >= 0 && tj < 7 && tk >= 0 && tk < 7 && v[ti][tj][tk] != -1)
                                                                                {
                                                                                        rbuf[v[ti][tj][tk]] -= rbuf[ii] * LUB[col_pos][k_pos+jj];
                                                                                        // if (i == 0 && j == 0 && K == 0 && k == 2)
                                                                                        // {
                                                                                        //         printf("%d %d %d\n", ti, tj, tk);
                                                                                        // }
                                                                                } 					
                                                                        }
                                                                }
                                                        }
                                                        for (ii = 0; ii < lnz; ii++)
                                                                LLB[k*lnz+ii] = rbuf[ii];
                                                        for (ii = 0; ii < rnz; ii++)
                                                                LUB[12][(k+halo)*rnz+ii] = rbuf[ii+lnz];
                                                        LA += onnz;
                                                        count++;
                                                        if (pr >= 0 && j > 1 && i < M - 1)
                                                        {
                                                                for (ii = 0; ii < rnz; ii++)
                                                                {
                                                                        GPUTR2(LUB[5][(k+halo)*rnz+ii], LUB[6][(k+halo)*rnz+ii], pr);
                                                                        GPUTR2(LUB[7][(k+halo)*rnz+ii], LUB[10][(k+halo)*rnz+ii], pr);
                                                                        GPUTR2(LUB[11][(k+halo)*rnz+ii], LUB[12][(k+halo)*rnz+ii], pr);
                                                                }
                                                        }
                                                        if (pc >= 0)
                                                        {
                                                                for (ii = 0; ii < rnz; ii++)
                                                                {
                                                                        GPUTC2(LUB[1][(k+halo)*rnz+ii], LUB[2][(k+halo)*rnz+ii], pc);
                                                                        GPUTC2(LUB[6][(k+halo)*rnz+ii], LUB[7][(k+halo)*rnz+ii], pc);
                                                                        GPUTC2(LUB[11][(k+halo)*rnz+ii], LUB[12][(k+halo)*rnz+ii], pc);
                                                                }
                                                        }
                                                }
                                                DMA_IWRITE(l+((i*N+j)*L+K)*lnz, LLB, sizeof(DATA_T)*(LEN)*lnz);
                                                DMA_IWRITE(u+((i*N+j)*L+K)*rnz, LUB[12]+halo*rnz, sizeof(DATA_T)*(LEN)*rnz);
                                                DMA_WAIT_ALL;
                                                // WXL_DMA_NEW(dma_put, , COUNT);
                                                // WXL_DMA_NEW(dma_put, , COUNT);
                                                // dma_wait(&reply, COUNT);
                                                if (K + SIZE < L)
                                                {
                                                        int LENtoBe = gridmin(L - K - SIZE, SIZE);
                                                        for (ii = 0; ii <= 12; ii++)
                                                        {
                                                                for (jj = 0; jj < HALO; jj++)
                                                                        for (kk = 0; kk < rnz; kk++)
                                                                                LUB[ii][jj*rnz+kk] = LUB[ii][(jj+LEN)*rnz+kk];
                                                                for (jj = 0; jj < halo; jj++)
                                                                        for (kk = 0; kk < rnz; kk++)
                                                                                LUB[ii][(LENtoBe+halo+jj)*rnz+kk] = 0;
                                                        }
                                                }
                                        }
                                }
                                else
                                {
                                        LUB[12][0] = 0;
                                        for (K = 0; K < L; K+=SIZE)
                                        {
                                                LEN = gridmin(L - K, SIZE);
                                                int buf_off = SIZE - LEN + halo;
                                                int off_up;
                                                if (K + SIZE > L - 1)
                                                        off_up = 0;
                                                else
                                                        off_up = gridmin(L - K - SIZE, halo);
                                                if (true)
                                                {
                                                        for (ii =0; ii < 3; ii++)
                                                        {
                                                                for (kk = halo*rnz; kk < (LEN + HALO)*rnz; kk++) LUB[2+ii][kk] = 0;
                                                                for (kk = halo*rnz; kk < (LEN + HALO)*rnz; kk++) LUB[7+ii][kk] = 0;
                                                        }
                                                }
                                                if (ROW(CPE_ID) == 0)
                                                {
                                                        for (ii = 0; ii < 3; ii++)
                                                        {
                                                                for (jj = 0; jj < 2; jj++)
                                                                {
                                                                        int t_coid = 5 * ii + jj;
                                                                        if (should_dma[t_coid])
                                                                        {
                                                                                DMA_IREAD(u+(i*N*L+j*L+pos_di[t_coid]*N*L+pos_dj[t_coid]*L+K)*rnz, LUB[t_coid]+halo*rnz, sizeof(DATA_T)*(LEN+off_up)*rnz);
                                                                                //WXL_DMA_NEW(dma_get, , COUNT);
                                                                        }
                                                                        else
                                                                                for (kk = halo*rnz; kk < (LEN + HALO)*rnz; kk++) LUB[t_coid][kk] = 0;
                                                                }
                                                        }
                                                }
                                                DMA_WAIT_ALL;
                                                //dma_wait(&reply, COUNT);
                                                for (k = 0; k < LEN; k++)
                                                {
                                                        int overlap = LEN;
                                                        while (count>=(bi-halo)&&bi!=L+halo||count>=(bj-halo)&&bj!=L+halo)
                                                        {
                                                                if (gr >= 0 && bi <= (count+halo) && !EMPTY_GETR())
                                                                {
                                                                        for (ii = 0; ii < rnz; ii++)
                                                                        {
                                                                                GGETR2(LUB[2][bii*rnz+ii], LUB[3][bii*rnz+ii]);
                                                                                GGETR2(LUB[4][bii*rnz+ii], LUB[7][bii*rnz+ii]);
                                                                                GGETR2(LUB[8][bii*rnz+ii], LUB[9][bii*rnz+ii]);
                                                                        }
                                                                        bii++;
                                                                        if (bii >= halo+SIZE) bii -= SIZE;
                                                                        bi++;
                                                                }
                                                                if (gc >= 0 && bj <= (count+halo) && !EMPTY_GETC())
                                                                {
                                                                        for (ii = 0; ii < rnz; ii++)
                                                                        {
                                                                                GGETC2(LUB[0][bjj*rnz+ii], LUB[1][bjj*rnz+ii]);
                                                                                GGETC2(LUB[5][bjj*rnz+ii], LUB[6][bjj*rnz+ii]);
                                                                                GGETC2(LUB[10][bjj*rnz+ii], LUB[11][bjj*rnz+ii]);
                                                                        }
                                                                        bjj++;
                                                                        if (bjj >= halo+SIZE) bjj -= SIZE;
                                                                        bj++;
                                                                }
                                                        }
                                                        count++;
                                                        if (pr >= 0 && j > 1 && i < M - 1)
                                                        {
                                                                for (ii = 0; ii < rnz; ii++)
                                                                {
                                                                        GPUTR2(LUB[5][(k+halo)*rnz+ii], LUB[6][(k+halo)*rnz+ii], pr);
                                                                        GPUTR2(LUB[7][(k+halo)*rnz+ii], LUB[10][(k+halo)*rnz+ii], pr);
                                                                        GPUTR2(LUB[11][(k+halo)*rnz+ii], LUB[12][0], pr);
                                                                }
                                                        }
                                                        if (pc >= 0 && j <= N)
                                                        {
                                                                for (ii = 0; ii < rnz; ii++)
                                                                {
                                                                        GPUTC2(LUB[1][(k+halo)*rnz+ii], LUB[2][(k+halo)*rnz+ii], pc);
                                                                        GPUTC2(LUB[6][(k+halo)*rnz+ii], LUB[7][(k+halo)*rnz+ii], pc);
                                                                        GPUTC2(LUB[11][(k+halo)*rnz+ii], LUB[12][0], pc);
                                                                }
                                                        }
                                                }
                                        }
                                }
                                
                        }
                        SYNC_ALL;
                }
        }
}

void SLAVE_FUNCNAME(ilu1_27_slave)(void *_ptr)
{
        DATA_T data[MAX_GRID_SIZE*8/sizeof(DATA_T)];
        // volatile int reply = 0;
        // volatile int COUNT = 0;
        Info info;
        // dma_desc dma_get;
        // WXL_DMA_SET_NOSIZE(&dma_get, DMA_GET, &reply);
        // WXL_DMA_NEW(dma_get, _ptr, &info, sizeof(Info), COUNT);
        // dma_wait(&reply, COUNT);
        DMA_DECL_DESC(READ);
        DMA_READ(_ptr, &info, sizeof(Info));
        #ifdef DATA_TYPE_S
        swSparse_s_ilu1_27_kernel(info.A, info.l, info.u, info.M, info.N, info.L, info.lnz, info.nnz, (DATA_T*)data, info.pos, info.onnz, info.apos, info.HALO);
        #endif
        #ifdef DATA_TYPE_D
        swSparse_d_ilu1_27_kernel(info.A, info.l, info.u, info.M, info.N, info.L, info.lnz, info.nnz, (DATA_T*)data, info.pos, info.onnz, info.apos, info.HALO);
        #endif
        #ifdef DATA_TYPE_C
        swSparse_c_ilu1_27_kernel(info.A, info.l, info.u, info.M, info.N, info.L, info.lnz, info.nnz, (DATA_T*)data, info.pos, info.onnz, info.apos, info.HALO);
        #endif
        #ifdef DATA_TYPE_Z
        swSparse_z_ilu1_27_kernel(info.A, info.l, info.u, info.M, info.N, info.L, info.lnz, info.nnz, (DATA_T*)data, info.pos, info.onnz, info.apos, info.HALO);
        #endif
        return;
}

#undef MLEN
