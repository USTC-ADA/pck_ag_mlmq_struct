#include "swSparse_blas.h"
#include "internal/rename.h"
#include "internal/spblas_common.h"
#include "internal/CPE.h"
#include "internal/utils.h"
#include "internal/CPE_utils.h"
#include "internal/CPE_communicator.h"
#include "internal/CPE_simd_utils.h"
#include "internal/templates.h"

// for SpTRF_queue_scheduler: put 27 at the end
// perm[rank] = cpe_id
// iperm[cpe_id] = rank
const Int swSparse_space_filling_8x8_perm[64] = {
    19,18,17,25,24,16,8, 0, 1, 9, 10,2, 3, 11,12,4, 5, 13,14,6, 7, 15,23,31,30,22,21,20,28,29,37,36,\
    44,45,46,38,39,47,55,63,62,54,53,61,60,52,51,59,58,50,49,57,56,48,40,32,33,41,42,43,35,34,26,27
}; 
const Int swSparse_space_filling_8x8_iperm[64] = {
     7, 8,11,12,15,16,19,20, \
     6, 9,10,13,14,17,18,21, \
     5, 2, 1, 0,27,26,25,22, \
     4, 3,62,63,28,29,24,23, \
    55,56,61,60,31,30,35,36, \
    54,57,58,59,32,33,34,37, \
    53,50,49,46,45,42,41,38, \
    52,51,48,47,44,43,40,39
};

namespace swSparse {

RING::RING(int tid_this, int tid_first_row_first_col, int rows, int cols) {
    constexpr int row_displacement = TID(1, 0), col_displacement = TID(0, 1);
    int rank_, prev_, next_;
    int tid = tid_this - tid_first_row_first_col;  // relative tid
    int rid = ROW(tid), cid = COL(tid);
    if((cid & 1) == 0) {
        rank_ = cid * rows + rid;
        if(rid == 0) {
            prev_ = TID(rid, (cid - 1) & (cols - 1));
        } else {
            prev_ = tid - row_displacement; // rid - 1
        }
        if(rid == (rows - 1)) {
            next_ = tid + col_displacement; // cid + 1
        } else {
            next_ = tid + row_displacement; // rid + 1
        }
    } else {
        rank_ = (cid + 1) * rows - rid - 1;
        if(rid == 0) {
            next_ = TID(rid, (cid + 1) & (cols - 1));
        } else {
            next_ = tid - row_displacement; // rid - 1
        }
        if(rid == (rows - 1)) {
            prev_ = tid - col_displacement; // cid - 1
        } else {
            prev_ = tid + row_displacement; // rid + 1
        }
    }
    this->rank = rank_;
    this->prev = tid_first_row_first_col + prev_;
    this->next = tid_first_row_first_col + next_;
} 

INLINE intv16 wait_vec(volatile intv16 *ptr) {
    intv16 tmp = *ptr;
    while(simd_vextw7(tmp) == 0) {
        tmp = *ptr;
    }
    return tmp;
}

int write_all_sum_int2(int i0, int i1, int *mem) {
    intv16 msg[6];
    int id = CPE_ID;
    intv16 vec = simd_vinsw0(i0, simd_vinsw1(i1, simd_vcpyw(1)));
    memset(msg, 0, sizeof(msg));
    mem_fence();
    CRTS_ssync_array();
    for(int shift = 0; shift < 6; ++shift) {
        int partner = id ^ (1 << shift);
        *remote_ldm_addr(&msg[shift], partner) = vec;
        mem_fence();
        vec += wait_vec(&msg[shift]);
    }
    i0 = simd_vextw0(vec);
    if(id == 0) {
        mem[0] = i0;
        mem[1] = simd_vextw1(vec);
    }
    return i0;
}

template<typename REAL_T>
void write_max_real(REAL_T value, REAL_T *mem) {
    REAL_T msg[6];
    int id = CPE_ID, mask = id | 64, shift, bit;
    memset(msg, 0, sizeof(msg));
    mem_fence();
    CRTS_ssync_array();
    for(shift = 0, bit = 1; (bit & mask) == 0; ++shift, bit = bit << 1) {
        int partner = id ^ bit;
        CRTS_ssync_peer(partner);
        double m = msg[shift];
        value = (value > m) ? value : m;
    }
    if(id != 0) {
        int partner = id ^ bit;
        *remote_ldm_addr(&msg[shift], partner) = value;
        mem_fence();
        CRTS_ssync_peer(partner);
    } else {
        *mem = value;
    }
}

template void write_max_real<float>(float value, float *mem);
template void write_max_real<double>(double value, double *mem);

// no extra LDM 
NOINLINE static void find_partition(Int roffset, Int size, Int total, const Int *offsets, Int *dist, Int* local_offsets, Int ldm_size) {
    Int i, j, tgt_rank, p, len, ideal_nnz = max(1, total >> 6), tile = ldm_size - 1;
    DMA_DECL_DESC(READ);

    i = 0;
    len = min(tile, size - i);
    DMA_READ(offsets + roffset + i, local_offsets, (len + 1) * sizeof(Int));

    tgt_rank = ceiling_div(local_offsets[0], ideal_nnz);
    p = tgt_rank * ideal_nnz;

    if(tgt_rank >= 64) {
        return;
    }

    // TODO: use std::upper_bound for binary search
    for(j = 0; j <= len; ++j) {
        if(local_offsets[j] > p) {
            dist[tgt_rank] = i + j + roffset;
            p += ideal_nnz;
            ++tgt_rank;
            if(tgt_rank >= 64) {
                return;
            }
        }
    }
    
    for(i = tile; i < size; i += tile) {
        len = min(tile, size - i);
        DMA_READ(offsets + roffset + i, local_offsets, (len + 1) * sizeof(Int));
        for(j = 0; j <= len; ++j) {
            if(local_offsets[j] > p) {
                dist[tgt_rank] = i + j + roffset;
                p += ideal_nnz;
                ++tgt_rank;
                if(tgt_rank >= 64) {
                    return;
                }
            }
        }
    }
}

}

void swSparse_collect_partition(Int *dist) {
    swSparse::put_rd_communicator<simd_t<Int>, 64 / simd_width<Int>> comm(CPE_ID);
    comm.allreduce<swSparse::reduce_bitor_t>(8, 8, reinterpret_cast<simd_t<Int>*>(dist), 64 / simd_width<Int>);
    
    dist[0] = 0;
    for(Int i = 1; i < 64; ++i) {
        if(dist[i] == 0) {
            dist[i] = dist[i-1];
        }
    }
}

void swSparse_partition_nnz(Int m, Int a_nnz, const Int *a_row_off, Int *dist, Int *ldm_buffer, Int ldm_size) {
    Int id = CPE_ID;
    Int q = m >> 6, r = m & 63;
    Int roffset = id * q + ((id < r) ? id : r);
    Int size    =      q + ((id < r) ? 1  : 0);
    swSparse::find_partition(roffset, size, a_nnz, a_row_off, dist, ldm_buffer, ldm_size);
    swSparse_collect_partition(dist);
}
