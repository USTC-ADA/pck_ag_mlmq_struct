#include "swSparse_trf.h"
#include "internal/rename.h"
#include "internal/debug.h"
#include "internal/debug_array.h"
#include "internal/CPE.h"
#include "internal/templates.h"
#include "internal/utils.h"
#include "internal/CPE_blas_kernels.h"
#include "internal/sptrf_param.h"
#include "internal/sptrf_cpe.h"
#include "internal/sptrf_supfact.h"

namespace swSparse {

namespace cache {
inline constexpr Int cache_size = 120 * 1024; // a little smaller
inline constexpr Int cache_line_size = 256;
inline constexpr Int queue_size = 32;
inline constexpr Int queue_size_mask = queue_size - 1;

template<size_t FROM, size_t TO>
INLINE Int equivalent_nelem(Int nidx) {
    if constexpr (TO > FROM) {
        constexpr Int ratio = TO / FROM;
        return (nidx + (ratio - 1)) / ratio;
    } else {
        constexpr Int ratio = FROM / TO;
        return nidx * ratio;
    }
}

// not used
template<size_t element_size>
class cache_aligned {
    Int misalign;
public:
    inline cache_aligned(void* ptr) {
        constexpr uintptr_t mask = cache_line_size - 1;
        misalign = (reinterpret_cast<uintptr_t>(ptr) & mask) / element_size;
    }
    inline Int end_index(Int idx) const {
        constexpr Int size = cache_size / element_size, mask = size - 1;
        return ((misalign + idx + mask) & (~mask)) - misalign;
    }
};


struct Item {
    Int isup, size, v_begin, v_end, col_begin, col_end;
    void dummy_node() {
        this->isup = -1;
        this->size = 0;
        this->v_begin = 0;
        this->v_end = 0;
        this->col_begin = 0;
        this->col_end = 0;
    }
};

template<size_t element_size>
class simulator {
    typedef uint8_t (*val_ptr_t)[element_size];
    typedef Int *idx_ptr_t;
    Item queue[queue_size];
    val_ptr_t val;
    idx_ptr_t ipiv;
    Int total_size, head, tail;

    Int evict(Int pos) {
        total_size -= queue[pos].size;
        evict_cache(val + queue[pos].v_begin, val + queue[pos].v_end);
        evict_cache(ipiv + queue[pos].col_begin, ipiv + queue[pos].col_end);
        return (pos + 1) & queue_size_mask;
    }
public:
    simulator(void *l_val, Int *l_ipiv) : total_size(0), head(0), tail(0), \
                val(reinterpret_cast<val_ptr_t>(l_val)), ipiv(l_ipiv) {
        queue[0].dummy_node();
    }
    void flush_and_destroy() {  // flush all dirty data in cache
        flush_slave_cache();
        mem_fence();
    }
    // begin and end should be multiplied with element size
    Int new_super(Int isup, Int col_begin, Int col_end, Int l_i_begin, Int l_i_end, Int l_v_begin, Int l_v_end) {
        Int pos = head;
        //col_end = ipiv_a.end_index(col_end);
        //l_v_end =  val_a.end_index(l_v_end);
        Int l_i_size = equivalent_nelem<sizeof(Int), element_size>(l_i_end - l_i_begin + col_end - col_begin);

        Int next_tail = (tail + 1) & queue_size_mask;
        if(pos == next_tail) {  // full
            pos = evict(pos);
        }
        tail = next_tail;
        head = pos;

        total_size += l_i_size;
        queue[tail].isup = isup;
        queue[tail].size = l_i_size;  // at this time, only indices and pivots
        queue[tail].col_begin = col_begin;
        queue[tail].col_end = col_end;
        queue[tail].v_begin = l_v_begin;
        queue[tail].v_end = l_v_end;
        mem_fence();
        return queue[pos].isup;
    }
    Int new_panel(Int l_v_size, Int u_idx_size, Int u_val_size, Int request) { // operate on `queue[tail]`
        constexpr Int cache_nelem = cache_size / element_size;
        Int u_size = u_val_size + equivalent_nelem<sizeof(Int) * 2/* seg offsets, seg indices */, element_size>(u_idx_size); 
        Int pos = head;
        queue[tail].size += l_v_size;
        total_size += l_v_size;
        
        while(pos != tail && total_size - queue[pos].size > cache_nelem - u_size) {
            pos = evict(pos);
        }
        while(pos != tail && queue[pos].isup <= request) {
            pos = evict(pos);
        }
        head = pos;
        mem_fence();
        return queue[pos].isup;
    }
};

}  // namespace cache

template<typename DATA_T>
NOINLINE Int subtree_impl(const sptrf_arg_t<DATA_T>& args, subtree_communicator comm, const trf_subtree_t* subtrees, Int nsubtree) {
    constexpr DATA_T zero = 0;
    constexpr Int simd_mask = simd_width<DATA_T> - 1, off_buffer_size = 192;

    Int perturb_count = 0;
    Array<trf_subtree_t, 32> tree_buffer;
    Array<Int, off_buffer_size> u_col_off_buffer, a_col_off_buffer;
    AArray<Int, trf_idx_size<DATA_T>> idx_buffer;
    AArray<DATA_T, trf_val_size<DATA_T>> val_buffer;

    const Int *a_col_off = args.a_col_off, *u_col_off = args.u_col_off, *sup2col = args.sup2col;
    const Int *col2sup = args.col2sup, *l_idx = args.l_row_idx, *l_v_off = args.l_v_off, *l_i_off = args.l_i_off;
    const Int *a_row_idx = args.a_row_idx, *u_seg_off = args.u_seg_off, *u_seg_idx = args.u_seg_idx;
    Int *ipiv = args.ipiv;
    DATA_T *l_val = args.l_val, *u_val = args.u_val;
    const DATA_T *a_val = args.a_val;
    sign_t<DATA_T> sign = get_imaginary_sign<DATA_T>((args.options & options_conj) == options_conj);
    cache::simulator<sizeof(DATA_T)> cache_sim(l_val, ipiv);
    dense_fact<DATA_T> kernel(args.perturb_threshold, args.rcp_thres, args.options & options_perturb_tiny);

    DMA_DECL_DESC(READ_WRITE);
#ifdef LU_CPE_PROFILE
    unsigned long tblascomp = 0, tcontmem = 0, twait = 0, tsparse = 0;
    DECLARE_TIMER
#endif

    for(Int t = 0; t < nsubtree; t += 32) {  // for each subtree
        Int tlen = min(32, nsubtree - t);
        DMA_READ(subtrees + t, tree_buffer, sizeof(trf_subtree_t) * tlen);
        for(Int tp = 0; tp < tlen; ++tp) {
            Int col_cur = sup2col[tree_buffer[tp].sup_begin], col_end = sup2col[tree_buffer[tp].sup_end];
            Int read_ncol = min(off_buffer_size, col_end - col_cur + 1);
            DMA_IREAD(args.u_col_off + col_cur, u_col_off_buffer, sizeof(Int) * read_ncol);
            DMA_READ( args.a_col_off + col_cur, a_col_off_buffer, sizeof(Int) * read_ncol);

            // for each supernode in the subtree
            for(Int jsup = tree_buffer[tp].sup_begin, tree_end = tree_buffer[tp].sup_end; jsup < tree_end; ++ jsup) { 
                Int update_block_row, update_block_col, left_ld, right_ld;
                Int jcol_begin = sup2col[jsup], jcol_end = sup2col[jsup + 1], sup_size = jcol_end - jcol_begin;
                Int v_begin = l_v_off[jsup], v_end = l_v_off[jsup + 1];  // L offsets of previous supernodes will be accessed
                Int i_begin = l_i_off[jsup], i_end = l_i_off[jsup + 1];
                Int sup_ld = sup_size + i_end - i_begin;
                Int *sup_ipiv = ipiv + jcol_begin;
                const Int* l_sup_idx = l_idx + i_begin;
                DATA_T *l_sup_val = l_val + v_begin;
                Int fic = cache_sim.new_super(jsup, jcol_begin, jcol_end, i_begin, i_end, v_begin , v_end);  // first in cache
                comm.update_fb_sup_subtree(fic);
                kernel.new_super(sup_size);
                
                // for each panel
                for(Int jpanel = jcol_begin; jpanel < jcol_end; jpanel += update_panel_size) {
                    next_seg_t next_seg[update_panel_size];
                    current_seg_t current_seg[update_panel_size];
                    Int ncol = min(update_panel_size, jcol_end - jpanel);
                    Int jpanel_end = jpanel + ncol;
                    Int jprel = jpanel - jcol_begin, jprel_end = jprel + ncol;
                    DATA_T *l_panel_val = l_sup_val + jprel * sup_ld;
                    if(jpanel_end - col_cur >= off_buffer_size) {  // update collumn offsets
                        Int off = jpanel - col_cur, move_size = off_buffer_size - off, read_off = jpanel + move_size;
                        for(Int x = 0; x < move_size; ++x) {
                            u_col_off_buffer[x] = u_col_off_buffer[x + off];
                            a_col_off_buffer[x] = a_col_off_buffer[x + off];
                        }
                        col_cur = jpanel;
                        read_ncol = min(off_buffer_size - move_size, col_end - read_off + 1);
                        DMA_IREAD(args.u_col_off + read_off, u_col_off_buffer + move_size, sizeof(Int) * read_ncol);
                        DMA_READ( args.a_col_off + read_off, a_col_off_buffer + move_size, sizeof(Int) * read_ncol);
                        
                        //for(int j = 0; j < read_ncol + move_size; ++j) {
                        //    ASSERT_EQUAL(u_col_off_buffer[j], args.u_col_off[j + col_cur]);
                        //}
                    }
                    {
                        Int u_col_begin = u_col_off_buffer[jpanel - col_cur];
                        Int u_col_end = u_col_off_buffer[jpanel_end - col_cur];
                        fic = cache_sim.new_panel(ncol * sup_ld, u_col_end - u_col_begin, 
                                                u_seg_off[u_col_end] - u_seg_off[u_col_begin],
                                                comm.check_req_sup_subtree());  // first in cache
                        comm.update_fb_sup_subtree(fic);
                    }

                    // initialize with A values
                    for(Int jcol_rel = 0; jcol_rel < ncol; ++jcol_rel) {
                        Int jcol = jcol_rel + jpanel, jcol_in_buff = jcol - col_cur;
                        Int u_begin = u_col_off_buffer[jcol_in_buff], u_end = u_col_off_buffer[jcol_in_buff + 1];
                        Int a_begin = a_col_off_buffer[jcol_in_buff], a_end = a_col_off_buffer[jcol_in_buff + 1];
                        Int seg_begin = u_seg_off[u_begin];
                        DATA_T *l_col_val = l_panel_val + jcol_rel * sup_ld;
                        Int pos, upos, lpos, row_idx;
                        TIMER_SET(timer1)
                        memset(u_val + seg_begin, 0, sizeof(DATA_T) * (u_seg_off[u_end] - seg_begin));
                        memset(l_col_val, 0, sizeof(DATA_T) * sup_ld);
                            
                        next_seg[jcol_rel].position = u_begin;
                        next_seg[jcol_rel].index = (u_begin < u_end) ? u_seg_idx[u_begin] : jcol_begin;
                        TIMER_SET(timer2)
                        upos = u_begin;
                        for(pos = a_begin; pos < a_end && (row_idx = a_row_idx[pos]) < jcol_begin; ++ pos) {
                            Int off_in_seg = row_idx - u_seg_idx[upos];
                            while(off_in_seg >= u_seg_off[upos + 1] - u_seg_off[upos]) {
                                off_in_seg = row_idx - u_seg_idx[++upos];
                            }
                            u_val[u_seg_off[upos] + off_in_seg] = conjugate_value(a_val[pos], sign);
                        }

                        for(; pos < a_end && (row_idx = a_row_idx[pos]) < jcol_end; ++ pos) {
                            l_col_val[row_idx - jcol_begin] = conjugate_value(a_val[pos], sign);
                        }
                        for(lpos = 0; pos < a_end; ++ pos) {
                            row_idx = a_row_idx[pos];
                            while(l_sup_idx[lpos] < row_idx) {
                                ++lpos;
                            }
                            l_col_val[sup_size + lpos] = conjugate_value(a_val[pos], sign);
                        }
                        TIMER_SET(timer3)
                        TIMER_GET(tcontmem, timer1, timer2)
                        TIMER_GET(tsparse, timer2, timer3)
                    }

                    // update from previous supernodes
                    for (;;) {
                        DATA_T *l_ksup_val;
                        const Int *l_ksup_idx;
                        Int kcol, ksup, ksup_size, ksup_nrow, ioff, poff;
                        Int ksup_i_off, ksup_ld, nuseg;
                        
                        kcol = jcol_begin;
                        for(Int jj = 0; jj < ncol; ++ jj) {
                            kcol = min(kcol, next_seg[jj].index);
                        }
                        if(kcol == jcol_begin) {
                            break;
                        }
                        ksup = col2sup[kcol];
                        ksup_size = sup2col[ksup + 1] - sup2col[ksup];
                        ksup_i_off = l_i_off[ksup];
                        l_ksup_val = l_val + l_v_off[ksup];              // previous supernode
                        ksup_nrow = l_i_off[ksup + 1] - ksup_i_off;
                        ksup_ld = ksup_nrow + ksup_size;

                        ASSERT_EQUAL(args.snode_status[ksup] + 64, CPE_ID);

                        // find the kcol segment
                        nuseg = 0;
                        for(Int jj = 0; jj < ncol; ++ jj) {
                            if(next_seg[jj].index == kcol) {  // non-zero segment
                                Int k = next_seg[jj].position, k_next = k + 1;
                                Int jcol = jpanel + jj;
                                Int u_col_end = u_col_off_buffer[jcol - col_cur + 1];
                                
                                current_seg[nuseg].val_off = u_seg_off[k];
                                current_seg[nuseg].dense_pos = jj * sup_ld;
                                current_seg[nuseg++].seg_pos = k;

                                next_seg[jj].position = k_next;
                                next_seg[jj].index = (k_next < u_col_end) ? u_seg_idx[k_next] : jcol_begin;
                            }
                        }

                        // pivot permute
                        if(ksup < fic) {  // not in cache, use DMA
                            for(Int koff = 0; koff < ksup_size; koff += trf_idx_size<DATA_T>) {
                                Int ipiv_block = min(trf_idx_size<DATA_T>, ksup_size - koff);
                                DMA_READ(ipiv + kcol + koff, idx_buffer, sizeof(Int) * ipiv_block);
                                pivot_permute_U_seg(u_val, idx_buffer, koff, ipiv_block, nuseg, current_seg);
                            }
                        } else {
                            pivot_permute_U_seg(u_val, ipiv + kcol, 0, ksup_size, nuseg, current_seg);
                        }

                        for(Int jseg = 0; jseg < nuseg; jseg += segment_block_size) {  // for each 32 segments
                            const Int bnseg = min(segment_block_size, nuseg - jseg), jseg_end = jseg + bnseg;
                            sptrf_params<sizeof(DATA_T)>::select_update_block_size(ksup_size, bnseg, 
                                update_block_col, update_block_row, left_ld, right_ld);
                            DATA_T *left_buffer = val_buffer;
                            DATA_T *right_buffer = val_buffer + update_block_col * left_ld;
                            DATA_T *right_down = right_buffer + update_block_col;
                            DATA_T *temp_right, *temp_left, *temp_ksup;
                            Int l_pos = 0;
                            kernel.set_update_layout(left_ld, right_ld);

                            if(ksup_size <= update_block_col) {  // no more than 64 columns in ksup. 1-D blocking
                                const Int right_rows = min(left_ld, ksup_ld);
                                const Int trsm_rows = min(right_rows, ((ksup_size - 1) & (~simd_mask)) + simd_width<DATA_T>);
                                const Int mm_rows = right_rows - trsm_rows;
                                const Int idx_len = right_rows - ksup_size;
                                l_ksup_idx = l_idx + ksup_i_off;              // previous supernode

                                TIMER_SET(timer1)
                                // load U
                                temp_right = right_buffer;
                                for(Int jj = jseg; jj < jseg_end; ++ jj, temp_right += right_ld) {
                                    cached_read(temp_right, u_val + current_seg[jj].val_off, sizeof(DATA_T) * ksup_size);
                                    memset(temp_right + ksup_size, 0, sizeof(DATA_T) * (trsm_rows - ksup_size));
                                }

                                // load Supernode diagnal block
                                temp_ksup = l_ksup_val + 1;
                                temp_left = left_buffer + 1;
                                size_t read_size = (right_rows - 1) * sizeof(DATA_T);
                                if(ksup < fic) {
                                    for(Int kk = 0; kk < ksup_size && read_size > 0; ++kk, read_size -= sizeof(DATA_T)) {
                                        DMA_IREAD(temp_ksup, temp_left, read_size);
                                        temp_ksup += (ksup_ld + 1);
                                        temp_left += (left_ld + 1);
                                    }
                                    if(idx_len > 0) {
                                        DMA_IREAD(l_ksup_idx, idx_buffer, sizeof(Int) * idx_len);
                                    }
                                    DMA_WAIT_ALL;
                                } else {
                                    for(Int kk = 0; kk < ksup_size && read_size > 0; ++kk, read_size -= sizeof(DATA_T)) {
                                        cached_read(temp_left, temp_ksup, read_size);
                                        temp_ksup += (ksup_ld + 1);
                                        temp_left += (left_ld + 1);
                                    }
                                    cached_read(idx_buffer, l_ksup_idx, sizeof(Int) * idx_len);
                                }
                                l_ksup_idx += idx_len;
                                TIMER_SET(timer2)
                                kernel.l_trsm_update(ksup_size, bnseg, trsm_rows, left_buffer, right_buffer);
                                if(mm_rows > 0) {
                                    kernel.mm_negative(ksup_size, bnseg, mm_rows, left_buffer + trsm_rows, \
                                        right_buffer, right_buffer + trsm_rows);
                                }
                                TIMER_SET(timer3)
                                    
                                temp_right = right_buffer;
                                for(Int jj = jseg; jj < jseg_end; ++ jj, temp_right += right_ld) {
                                    cached_write(u_val + current_seg[jj].val_off, temp_right, sizeof(DATA_T) * ksup_size);  // copy back U segment
                                }
                                TIMER_SET(timer4)
                                TIMER_GET(tcontmem, timer1, timer2)
                                TIMER_GET(tblascomp, timer2, timer3)
                                TIMER_GET(tcontmem, timer3, timer4)
                                
                                if (idx_len > 0) {
                                    Int pos = 0;
                                    TIMER_SET(timer1)
                                    temp_right = right_buffer;
                                    for(Int jj = jseg; jj < jseg_end; ++ jj, temp_right += right_ld) {
                                        pos = sparse_update_U(idx_len, idx_buffer, temp_right + ksup_size, jcol_begin, \
                                            u_seg_off, u_seg_idx, u_val, &current_seg[jj]);
                                    }
                                    l_pos = sparse_update_L(idx_len - pos, idx_buffer + pos, right_buffer + ksup_size + pos, right_ld, \
                                            jcol_begin, jcol_end, sup_size, l_pos, l_sup_idx, l_panel_val, \
                                            &current_seg[jseg], bnseg);
                                    TIMER_SET(timer2)
                                    TIMER_GET(tsparse, timer1, timer2)
                                }

                                // load Supernode off-diagnal blocks
                                for(ioff = left_ld; ioff < ksup_ld; ioff += update_block_row) {
                                    Int mm_row_size = min(update_block_row, ksup_ld - ioff);
                                    TIMER_SET(timer1)
                                    temp_left = left_buffer;
                                    temp_ksup = l_ksup_val + ioff;
                                    size_t mm_row_val_size = sizeof(DATA_T) * mm_row_size;
                                    if(ksup < fic) {
                                        for(Int kk = 0; kk < ksup_size; ++kk, temp_ksup += ksup_ld, temp_left += left_ld) {
                                            DMA_IREAD(temp_ksup, temp_left, mm_row_val_size);
                                        }
                                        DMA_READ(l_ksup_idx, idx_buffer, sizeof(Int) * mm_row_size);
                                    } else {
                                        for(Int kk = 0; kk < ksup_size; ++kk, temp_ksup += ksup_ld, temp_left += left_ld) {
                                            cached_read(temp_left, temp_ksup, mm_row_val_size);
                                        }
                                        cached_read(idx_buffer, l_ksup_idx, sizeof(Int) * mm_row_size);
                                    }
                                    l_ksup_idx += mm_row_size;

                                    TIMER_SET(timer2)
                                    kernel.mm_negative(ksup_size, bnseg, mm_row_size, left_buffer, \
                                        right_buffer, right_down);
                                    TIMER_SET(timer3)
                                    
                                    Int pos = 0;
                                    temp_right = right_down;
                                    for(Int jj = jseg; jj < jseg_end; ++ jj, temp_right += right_ld) {
                                        pos = sparse_update_U(mm_row_size, idx_buffer, temp_right, jcol_begin, \
                                            u_seg_off, u_seg_idx, u_val, &current_seg[jj]);
                                    }
                                    l_pos = sparse_update_L(mm_row_size - pos, idx_buffer + pos, right_down + pos, right_ld, \
                                            jcol_begin, jcol_end, sup_size, l_pos, l_sup_idx, l_panel_val, \
                                            &current_seg[jseg], bnseg);
                                    TIMER_SET(timer4)
                                    TIMER_GET(tcontmem, timer1, timer2)
                                    TIMER_GET(tblascomp, timer2, timer3)
                                    TIMER_GET(tsparse, timer3, timer4)
                                }
                            } else {             // more than 64 columns in ksup, 2-D blocking
                                l_ksup_idx = l_idx + ksup_i_off;              // previous supernode

                                // TRSM part
                                for(ioff = 0; ioff < ksup_size; ioff += update_block_row) {  // ioff : relative to supernode begin
                                    const Int useg_rows = min(update_block_row, ksup_size - ioff);
                                    const Int right_rows  = min(update_block_row, ksup_ld - ioff);
                                    const Int col_block_end = ioff + useg_rows, col_cached = ioff - update_block_col;
                                    const Int idx_len = right_rows - useg_rows;

                                    TIMER_SET(timer1)
                                    // load U to right_down
                                    temp_right = right_down;
                                    for(Int jj = jseg; jj < jseg_end; ++ jj, temp_right += right_ld) {
                                        cached_read(temp_right, u_val + current_seg[jj].val_off + ioff, sizeof(DATA_T) * useg_rows);
                                        memset(temp_right + useg_rows, 0, sizeof(DATA_T) * (right_rows - useg_rows));
                                        // different from the case columns < 64, here we use mm_update only, which requires initializtion
                                        // not use mm_negative
                                    }
                                    
                                    if(idx_len > 0) {
                                        if(ksup < fic) {
                                            DMA_READ(l_ksup_idx, idx_buffer, sizeof(Int) * idx_len);
                                        } else {
                                            cached_read(idx_buffer, l_ksup_idx, sizeof(Int) * idx_len);
                                        }
                                        l_ksup_idx += idx_len;
                                    }


                                    const size_t right_val_size = sizeof(DATA_T) * right_rows;
                                    // use the last result for GEMM
                                    if(ioff != 0) {
                                        temp_left = left_buffer;
                                        temp_ksup = l_ksup_val + ioff + col_cached * ksup_ld;
                                        // full block
                                        if(ksup < fic) {
                                            for(Int kk = col_cached; kk < ioff; ++kk, temp_ksup += ksup_ld, temp_left += left_ld) {
                                                DMA_IREAD(temp_ksup, temp_left, right_val_size);
                                            }
                                            DMA_WAIT_ALL;
                                        } else {
                                            for(Int kk = col_cached; kk < ioff; ++kk, temp_ksup += ksup_ld, temp_left += left_ld) {
                                                cached_read(temp_left, temp_ksup, right_val_size);
                                            }
                                        }

                                        TIMER_SET(timer2)
                                        kernel.mm_update(update_block_col, bnseg, right_rows, left_buffer, right_buffer, right_down);
                                        TIMER_SET(timer3)
                                        TIMER_GET(tcontmem, timer1, timer2)
                                        TIMER_GET(tblascomp, timer2, timer3)
                                    } else {
                                        TIMER_SET(timer2)
                                        TIMER_GET(tcontmem, timer1, timer2)
                                    }
                                    

                                    // full-block GEMM
                                    for(poff = 0; poff < col_cached; poff += update_block_col) {
                                        Int pend = poff + update_block_col;
                                        temp_left = left_buffer;
                                        temp_ksup = l_ksup_val + ioff + poff * ksup_ld;
                                        TIMER_SET(timer1)
                                        
                                        temp_right = right_buffer;
                                        for(Int jj = jseg; jj < jseg_end; ++ jj, temp_right += right_ld) {
                                            cached_read(temp_right, u_val + current_seg[jj].val_off + poff, sizeof(DATA_T) * update_block_col);
                                        }

                                        // full block
                                        if(ksup < fic) {
                                            for(Int kk = poff; kk < pend; ++kk, temp_ksup += ksup_ld, temp_left += left_ld) {
                                                DMA_IREAD(temp_ksup, temp_left, right_val_size);
                                            }
                                            DMA_WAIT_ALL;
                                        } else {
                                            for(Int kk = poff; kk < pend; ++kk, temp_ksup += ksup_ld, temp_left += left_ld) {
                                                cached_read(temp_left, temp_ksup, right_val_size);
                                            }
                                        }
                                        TIMER_SET(timer2)

                                        kernel.mm_update(update_block_col, bnseg, right_rows, left_buffer, right_buffer, right_down);
                                        TIMER_SET(timer3)
                                        TIMER_GET(tcontmem, timer1, timer2)
                                        TIMER_GET(tblascomp, timer2, timer3)
                                    }
                                    // TRSM
                                    temp_right = right_down;
                                    for(poff = ioff; poff < col_block_end; poff += update_block_col, temp_right += update_block_col) {
                                        Int psize = min(update_block_col, col_block_end - poff), pend = poff + psize;
                                        Int lower_part = right_rows - (poff - ioff);
                                        Int trsm_part = min(lower_part, ((psize - 1) & (~simd_mask)) + simd_width<DATA_T>);
                                        Int mm_part = lower_part - trsm_part;
                                        Int left_col = pend - poff;
                                        temp_ksup = l_ksup_val + poff + poff * ksup_ld + 1;
                                        temp_left = left_buffer + 1;
                                        TIMER_SET(timer1)
                                        if(ksup < fic) {
                                            for(Int kk = poff, read_len = lower_part - 1; kk < pend && read_len > 0; ++kk, --read_len) {
                                                DMA_IREAD(temp_ksup, temp_left, sizeof(DATA_T) * read_len);
                                                temp_ksup += (ksup_ld + 1);
                                                temp_left += (left_ld + 1);
                                            }
                                            DMA_WAIT_ALL;
                                        } else {
                                            for(Int kk = poff, read_len = lower_part - 1; kk < pend; ++kk, --read_len) {
                                                cached_read(temp_left, temp_ksup, sizeof(DATA_T) * read_len);
                                                temp_ksup += (ksup_ld + 1);
                                                temp_left += (left_ld + 1);
                                            }
                                        }
                                        TIMER_SET(timer2)
                                        kernel.l_trsm_update(left_col, bnseg, trsm_part, left_buffer, temp_right);
                                        if(mm_part > 0) {
                                            kernel.mm_update(left_col, bnseg, mm_part, left_buffer + trsm_part, \
                                                temp_right, temp_right + trsm_part);
                                        }
                                        TIMER_SET(timer3)
                                        TIMER_GET(tcontmem, timer1, timer2)
                                        TIMER_GET(tblascomp, timer2, timer3)
                                    }
                                    TIMER_SET(timer1)
                                    temp_right = right_down;
                                    for(Int jj = jseg; jj < jseg_end; ++ jj, temp_right += right_ld) {
                                        // store U
                                        cached_write(u_val + current_seg[jj].val_off + ioff, temp_right, sizeof(DATA_T) * useg_rows);
                                        // move the result for the next GEMM
                                        memcpy(temp_right - update_block_col, temp_right + update_block_row - update_block_col, \
                                                sizeof(DATA_T) * update_block_col);
                                    }
                                    TIMER_SET(timer2)
                                    if(idx_len > 0) {
                                        Int pos;
                                        DATA_T *val = right_down + useg_rows;
                                        temp_right = val;
                                        for(Int jj = jseg; jj < jseg_end; ++ jj, temp_right += right_ld) {
                                            pos = sparse_update_U(idx_len, idx_buffer, temp_right, jcol_begin, \
                                                u_seg_off, u_seg_idx, u_val, &current_seg[jj]);
                                        }
                                        l_pos = sparse_update_L(idx_len - pos, idx_buffer + pos, val + pos, right_ld, \
                                                jcol_begin, jcol_end, sup_size, l_pos, l_sup_idx, l_panel_val, \
                                                &current_seg[jseg], bnseg);
                                    }
                                    TIMER_SET(timer3)
                                    TIMER_GET(tcontmem, timer1, timer2)
                                    TIMER_GET(tsparse, timer2, timer3)
                                }
                                // GEMM part
                                for(; ioff < ksup_ld; ioff += update_block_row) {
                                    // ksup_size > update_block_col, mm_col_size == update_block_col
                                    Int mm_row_size = min(update_block_row, ksup_ld - ioff);
                                    size_t mm_row_val_size = sizeof(DATA_T) * mm_row_size, mm_row_idx_size = sizeof(Int) * mm_row_size;
                                    TIMER_SET(timer1)
                                    temp_left = left_buffer;
                                    temp_ksup = l_ksup_val + ioff;
                                    if(ksup < fic) {
                                        for(Int kk = 0; kk < update_block_col; ++kk, temp_ksup += ksup_ld, temp_left += left_ld) {
                                            DMA_IREAD(temp_ksup, temp_left, mm_row_val_size);
                                        }
                                        DMA_READ(l_ksup_idx, idx_buffer, mm_row_idx_size);
                                    } else {
                                        for(Int kk = 0; kk < update_block_col; ++kk, temp_ksup += ksup_ld, temp_left += left_ld) {
                                            cached_read(temp_left, temp_ksup, mm_row_val_size);
                                        }
                                        cached_read(idx_buffer, l_ksup_idx, mm_row_idx_size);
                                    }
                                    l_ksup_idx += mm_row_size;
                                    temp_right = right_buffer;
                                    for(Int jj = jseg; jj < jseg_end; ++ jj, temp_right += right_ld) {
                                        cached_read(temp_right, u_val + current_seg[jj].val_off, sizeof(DATA_T) * update_block_col);
                                    }
                                    TIMER_SET(timer2)
                                    kernel.mm_negative(update_block_col, bnseg, mm_row_size, left_buffer, right_buffer, right_down);
                                    TIMER_SET(timer3)
                                    TIMER_GET(tcontmem, timer1, timer2)
                                    TIMER_GET(tblascomp, timer2, timer3)

                                    for(poff = update_block_col; poff < ksup_size; poff += update_block_col) {
                                        Int mm_col_size = min(update_block_col, ksup_size - poff);
                                        TIMER_SET(timer1)
                                        temp_left = left_buffer;
                                        temp_ksup = l_ksup_val + ioff + poff * ksup_ld;
                                        if(ksup < fic) {
                                            for(Int kk = 0; kk < mm_col_size; ++kk, temp_ksup += ksup_ld, temp_left += left_ld) {
                                                DMA_IREAD(temp_ksup, temp_left, mm_row_val_size);
                                            }
                                            DMA_WAIT_ALL;
                                        } else {
                                            for(Int kk = 0; kk < mm_col_size; ++kk, temp_ksup += ksup_ld, temp_left += left_ld) {
                                                cached_read(temp_left, temp_ksup, mm_row_val_size);
                                            }
                                        }
                                        temp_right = right_buffer;
                                        for(Int jj = jseg; jj < jseg_end; ++ jj, temp_right += right_ld) {
                                            cached_read(temp_right, u_val + current_seg[jj].val_off + poff, sizeof(DATA_T) * mm_col_size);
                                        }
                                        TIMER_SET(timer2)
                                        kernel.mm_update(mm_col_size, bnseg, mm_row_size, left_buffer, right_buffer, right_down);
                                        TIMER_SET(timer3)
                                        TIMER_GET(tcontmem, timer1, timer2)
                                        TIMER_GET(tblascomp, timer2, timer3)
                                    }

                                    TIMER_SET(timer2)
                                    Int pos = 0;
                                    temp_right = right_down;
                                    for(Int jj = jseg; jj < jseg_end; ++ jj, temp_right += right_ld) {
                                        pos = sparse_update_U(mm_row_size, idx_buffer, temp_right, jcol_begin, \
                                            u_seg_off, u_seg_idx, u_val, &current_seg[jj]);
                                    }
                                    l_pos = sparse_update_L(mm_row_size - pos, idx_buffer + pos, right_down + pos, right_ld, \
                                            jcol_begin, jcol_end, sup_size, l_pos, l_sup_idx, l_panel_val, \
                                            &current_seg[jseg], bnseg);
                                    TIMER_SET(timer2)
                                    TIMER_GET(tsparse, timer1, timer2)
                                }
                            }
                        }
                    }
                    perturb_count += kernel.factorize_super_seq(val_buffer, l_sup_val, sup_ipiv, jprel, jprel_end, sup_size, sup_ld);
                }
                // pivot permute off-diagnals of L
                kernel.pivot_permute_L_seq(l_sup_val, sup_ipiv, sup_size, sup_ld);
            }
        }
    }
    cache_sim.flush_and_destroy();
    comm.update_fb_sup_subtree(args.nsuper);
    
#ifdef LU_CPE_PROFILE
    comm.record_update_timing(tblascomp, tcontmem, twait, tsparse);
    comm.record_fact_timing(kernel.tcomp, kernel.tcontmem, kernel.tcomm);
#endif
    return perturb_count;
}

template<typename DATA_T>
Int subtree_part(const sptrf_arg_t<DATA_T>& args, subtree_communicator comm) {
    const Int id = CPE_ID, subt_off = args.subtree_offsets[id], nsubtree = args.subtree_offsets[id + 1] - subt_off;
    const trf_subtree_t* subtrees = args.subtrees + subt_off;
    CRTS_ssync_array();  // ensure everyone has contructed the communicator
    return subtree_impl(args, comm, subtrees, nsubtree);
}

template Int subtree_part<float>(const sptrf_arg_t<float>& args, subtree_communicator comm);
template Int subtree_part<double>(const sptrf_arg_t<double>& args, subtree_communicator comm);
template Int subtree_part<SComplex>(const sptrf_arg_t<SComplex>& args, subtree_communicator comm);
template Int subtree_part<DComplex>(const sptrf_arg_t<DComplex>& args, subtree_communicator comm);
}