#include "swSparse_trf.h"
#include "internal/rename.h"
#include "internal/debug.h"
#include "internal/debug_array.h"
#include "internal/CPE.h"
#include "internal/templates.h"
#include "internal/utils.h"
#include "internal/CPE_blas_kernels.h"
#include "internal/sptrf_param.h"
#include "internal/sptrf_cpe.h"
#include "internal/sptrf_supfact.h"

namespace swSparse {
//void set_verbose0(bool);

INLINE Int space_filling_curve(Int rid, Int cid) {
    switch (rid) {
    case 0:
        return 4 + cid;
    case 16:
        return (((cid < 8) ? 0 : 32) - cid) & 60;
    case 32:
        return ((cid < 8) ? 52 : 20) + cid;
    case 48:
        return 48 - cid;
    }
    UNREACHABLE;
}

INLINE Int get_worker_id(Int tid) {
    return space_filling_curve(tid & 48, (tid << 1) & 12) | (tid & 1) | ((tid >> 2) & 2);
}

class CompletionPredicator {
    // fb_aux[worker_id]:    cached fb_subtree value
    // fb_aux[scheduler_id]: frozen fb_subtree value
    AArray<Int, 64> fb_freeze, fb_aux;
public:
    CompletionPredicator() {
        fb_aux.fill(-1);
    }

    void init(Int this_id, Int nsuper) {
        fb_freeze.fill(-1);
        fb_freeze[this_id] = fb_freeze[scheduler_id] = nsuper;  // their subtrees are guaranteed to be finished
        fb_aux[scheduler_id] = -1;
    }

    bool any_waiting() const { return fb_aux[scheduler_id] >= 0; }

    bool is_ready(Int ksup, const Int* sup_status, worker_communicator& comm) {
        if(!any_waiting() && comm.get_worker_message().task.t.nb_child == 0) {
            return true;
        }
        Int fb_queue, kstatus = sup_status[ksup];
        Bool ready;

        if(kstatus < 0) {
            Int target_id = kstatus + 64, fb_subtree = fb_freeze[target_id];
            if(fb_subtree >= 0) {
                return fb_subtree > ksup;
            }
            ASSERT_NOT_EQUAL(target_id, CPE_ID);
            ASSERT_NOT_EQUAL(target_id, scheduler_id);
            fb_subtree = fb_aux[target_id];  // get_fb_sup_subtree requires RLD, cache it.
            if(fb_subtree > ksup) {
                return true;
            }
            fb_queue = comm.get_fb_rank_queue();
            fb_subtree = comm.get_fb_sup_subtree(target_id);
            fb_aux[target_id] = fb_subtree;

            ready = fb_subtree > ksup;
            if(!ready) {
                fb_freeze[target_id] = fb_subtree;

                // bugfix 2023.3.5: freeze fb_queue when any subtree is not finished
                Int old = fb_aux[scheduler_id];
                fb_aux[scheduler_id] = (old >= 0) ? old : fb_queue;
            }
            return ready;
        } else {
            fb_queue = fb_aux[scheduler_id];
            if(fb_queue >= 0) {
                return fb_queue > kstatus;
            }
            // not frozen
            fb_queue = comm.get_fb_rank_queue();
            ready = fb_queue > kstatus;
            fb_aux[scheduler_id] = ready ? (-1) : fb_queue;
            return ready;
        }
    }
    bool is_already_done(Int ksup, Int kstatus) const {
        if(kstatus < 0) {
            Int fb_subtree = fb_freeze[kstatus + 64];
            return fb_subtree < 0 || fb_subtree > ksup;
        } else {
            return fb_aux[scheduler_id] > kstatus;
        }
    }
    void wait(Int ksup, Int kstatus, worker_communicator& comm) {
        auto& nbchild_source = comm.get_worker_message().task.t.nb_child;
        Int nbchild = nbchild_source;
        if(kstatus < 0) {
            Int target_id = kstatus + 64, fb_subtree = fb_aux[target_id];
            ASSERT_NOT_EQUAL(target_id, CPE_ID);
            ASSERT_NOT_EQUAL(target_id, scheduler_id);
            if(UNLIKELY(fb_subtree <= ksup) && (nbchild > 0)) {
                fb_subtree = comm.request_fbsup_subtree(ksup, target_id);
                while((fb_subtree <= ksup) && (nbchild > 0)) {   // busy waiting
                    fb_subtree = comm.get_fb_sup_subtree(target_id);
                    nbchild = nbchild_source;
                }
                fb_aux[target_id] = fb_subtree;
            }
        } else {
            Int fb_queue = comm.get_fb_rank_queue();
            while((fb_queue <= kstatus) && (nbchild > 0)) {  // busy waiting
                fb_queue = comm.get_fb_rank_queue();
                nbchild = nbchild_source;
            }
        }
    }
};

#ifdef SWSPARSE_LU_USE_SPA
#define IF_USE_SPA if(UNLIKELY(use_spa))
#define SELECT_SPA(spa__, common__) UNLIKELY(use_spa) ? (spa__) : (common__)
#else
#define IF_USE_SPA if constexpr(false)
#define SELECT_SPA(spa__, common__) common__
#endif

template<typename DATA_T>
Int queue_worker(const sptrf_arg_t<DATA_T>& args, worker_communicator comm) {
    constexpr DATA_T zero = 0;
    constexpr Int simd_mask = simd_width<DATA_T> - 1;

    AArray<Int, trf_idx_size<DATA_T>> idx_buffer;
    AArray<DATA_T, trf_val_size<DATA_T>> val_buffer;
    CompletionPredicator completion;

    const Int *a_col_off = args.a_col_off, *u_col_off = args.u_col_off;
    const Int *col2sup = args.col2sup,  *sup2col = args.sup2col, *l_idx = args.l_row_idx, *l_v_off = args.l_v_off, *l_i_off = args.l_i_off;
    const Int *a_row_idx = args.a_row_idx, *u_seg_off = args.u_seg_off, *u_seg_idx = args.u_seg_idx;
    const Int *sup_status = args.snode_status;
    Int *ipiv = args.ipiv;
    DATA_T *l_val = args.l_val, *u_val = args.u_val, *spa;
    const DATA_T *a_val = args.a_val;
    Int spa_col, n, spa_init, perturb_count = 0, thread_id = CPE_ID, worker_id = get_worker_id(thread_id);
    sign_t<DATA_T> sign = get_imaginary_sign<DATA_T>((args.options & options_conj) == options_conj);
    dense_par_fact<DATA_T> kernel(args.perturb_threshold, args.rcp_thres, args.options & options_perturb_tiny);
    ASSERT_LESS(worker_id, 63);
#ifdef SWSPARSE_LU_USE_SPA
    spa_col = args.spa_cols;
    n = args.n;
    spa_init = -1;
    spa = args.spa + n * spa_col * thread_id;
#endif
#ifdef LU_CPE_PROFILE
    unsigned long tblascomp = 0, tcontmem = 0, twait = 0, tsparse = 0;
    DECLARE_TIMER
#endif

    DMA_DECL_DESC(READ_WRITE);
    for(;;) {
        Int jsup = comm.request_new_task(thread_id, worker_id);
        if(jsup < 0) { break; }
        auto& msg = comm.get_worker_message();
        comm.update_partners();
        Int group_size = msg.task.t.group_size, group_rank = msg.task.t.group_rank;
        Int group_panel_size = group_size << update_panel_shift, group_cycle_size = group_size << block_cycle_shift;
        Int group_offset = group_rank << block_cycle_shift;
        Int update_block_row, update_block_col, left_ld, right_ld;
        Int jcol_begin = sup2col[jsup], jcol_end = sup2col[jsup + 1], sup_size = jcol_end - jcol_begin;
        Int v_begin = l_v_off[jsup], v_end = l_v_off[jsup + 1];  // L offsets of previous supernodes will be accessed
        Int i_begin = l_i_off[jsup], i_end = l_i_off[jsup + 1];
        Int sup_ld = sup_size + i_end - i_begin;
        Int *sup_ipiv = ipiv + jcol_begin;
        const Int* l_sup_idx = l_idx + i_begin;
        DATA_T *l_sup_val = l_val + v_begin;
        kernel.new_super(sup_size, msg.partners.v, group_size, group_rank);   // select block size

        // for each panel
        for(Int jgroup = jcol_begin; jgroup < jcol_end; jgroup += group_panel_size) {
            Int jpanel = jgroup + group_offset;
            Array<next_seg_t, update_panel_size> next_seg, first_waiting;
            Array<current_seg_t, update_panel_size> current_seg;
            
            if(jpanel < jcol_end) {
                const Int nbc = min(update_panel_ncycles, ceiling_div(jcol_end - jgroup, group_cycle_size));
                const Int ncol_last = max(0, min(block_cycle_size, (jcol_end - jpanel) - (nbc - 1) * group_cycle_size));
                const Int ncol = (nbc - 1) * block_cycle_size + ncol_last;

                const Bool use_spa = (sup_size > 512 && ncol <= spa_col);
                Int jprel = jpanel - jcol_begin;
                DATA_T *l_panel_val = l_sup_val + jprel * sup_ld;

                completion.init(thread_id, args.nsuper);
                first_waiting[0].index = -1;

                // initialize with A values
                for(Int jj = 0; jj < ncol; ++jj) {
                    Int jcol_rel = block_cyclic_local_to_global(jj, group_size);
                    Int jcol = jpanel + jcol_rel;
                    Int u_begin = u_col_off[jcol], u_end = u_col_off[jcol + 1];
                    Int a_begin = a_col_off[jcol], a_end = a_col_off[jcol + 1];

                    next_seg[jj].position = u_begin;   /* seg::postion and upos are in the range of u_col_off[] */
                    next_seg[jj].index = (u_begin < u_end) ? u_seg_idx[u_begin] : jcol_begin;

                    IF_USE_SPA {
                        DATA_T *s = spa + n * jj;
                        if(spa_init < jj) {
                            memset(s, 0, sizeof(DATA_T) * n);
                            spa_init = jj;
                        }
                        for(Int pos = a_begin; pos < a_end; ++ pos) {
                            s[a_row_idx[pos]] = conjugate_value(a_val[pos], sign);
                        }
                    } else {
                        DATA_T *l_col_val = l_panel_val + jcol_rel * sup_ld;
                        Int seg_begin = u_seg_off[u_begin];
                        Int pos, upos, lpos, row_idx;

                        TIMER_SET(timer1);
                        memset(u_val + seg_begin, 0, sizeof(DATA_T) * (u_seg_off[u_end] - seg_begin));
                        memset(l_col_val, 0, sizeof(DATA_T) * sup_ld);
                                    
                        TIMER_SET(timer2);
                        upos = u_begin;
                        for(pos = a_begin; pos < a_end && (row_idx = a_row_idx[pos]) < jcol_begin; ++ pos) {
                            Int off_in_seg = row_idx - u_seg_idx[upos];
                            while(off_in_seg >= u_seg_off[upos + 1] - u_seg_off[upos]) {
                                off_in_seg = row_idx - u_seg_idx[++upos];
                            }
                            u_val[u_seg_off[upos] + off_in_seg] = conjugate_value(a_val[pos], sign);
                        }

                        for(; pos < a_end && (row_idx = a_row_idx[pos]) < jcol_end; ++ pos) {
                            l_col_val[row_idx - jcol_begin] = conjugate_value(a_val[pos], sign);
                        }
                        for(lpos = 0; pos < a_end; ++ pos) {
                            row_idx = a_row_idx[pos];
                            while(l_sup_idx[lpos] < row_idx) {
                                ++lpos;
                            }
                            l_col_val[sup_size + lpos] = conjugate_value(a_val[pos], sign);
                        }
                        TIMER_SET(timer3);
                        TIMER_GET(tcontmem, timer1, timer2)
                        TIMER_GET(tsparse, timer2, timer3)
                    }
                }

                // phase 1: update from previous ready supernodes
                for (;;) {
                    DATA_T *l_ksup_val;
                    const Int *l_ksup_idx;
                    Int kcol, ksup, ksup_size, ksup_nrow, ioff, poff;
                    Int ksup_i_off, ksup_ld, nuseg;
                    Bool ready;
                            
                    kcol = jcol_begin;
                    for(Int jj = 0; jj < ncol; ++ jj) {
                        kcol = min(kcol, next_seg[jj].index);
                    }
                    if(kcol == jcol_begin) {
                        break;
                    }

                    ksup = col2sup[kcol];
                    ready = completion.is_ready(ksup, sup_status, comm);

                    if(!ready) { // non-zero segment are not ready, skip. will be done in phase 2
                        if(first_waiting[0].index < 0) {
                            first_waiting.copy_from(next_seg, ncol);
                        }
                        for(Int jj = 0; jj < ncol; ++ jj) {
                            if(next_seg[jj].index == kcol) {
                                Int k = next_seg[jj].position, k_next = k + 1;
                                Int jcol_rel = block_cyclic_local_to_global(jj, group_size), jcol = jpanel + jcol_rel;
                                next_seg[jj].position = k_next;
                                next_seg[jj].index = (k_next < u_col_off[jcol + 1]) ? u_seg_idx[k_next] : jcol_begin;
                            }
                        }
                        continue;
                    }

                    ksup_size = sup2col[ksup + 1] - sup2col[ksup];
                    ksup_i_off = l_i_off[ksup];
                    l_ksup_val = l_val + l_v_off[ksup];              // previous supernode
                    ksup_nrow = l_i_off[ksup + 1] - ksup_i_off;
                    ksup_ld = ksup_nrow + ksup_size;

                    // find the kcol segment
                    nuseg = 0;
                    for(Int jj = 0; jj < ncol; ++ jj) {
                        if(next_seg[jj].index == kcol) {  // non-zero segment
                            Int k = next_seg[jj].position, k_next = k + 1;
                            Int jcol_rel = block_cyclic_local_to_global(jj, group_size), jcol = jpanel + jcol_rel;
                                    
                            current_seg[nuseg].val_off = u_seg_off[k];
                            current_seg[nuseg].dense_pos = SELECT_SPA(jj * n, jcol_rel * sup_ld);
                            current_seg[nuseg++].seg_pos = k;

                            next_seg[jj].position = k_next;
                            next_seg[jj].index = (k_next < u_col_off[jcol + 1]) ? u_seg_idx[k_next] : jcol_begin;
                        }
                    }

                    // pivot permute
                    for(Int koff = 0; koff < ksup_size; koff += trf_idx_size<DATA_T>) {
                        Int ipiv_block = min(trf_idx_size<DATA_T>, ksup_size - koff);
                        DMA_READ(ipiv + kcol + koff, idx_buffer, sizeof(Int) * ipiv_block);
                        IF_USE_SPA {
                            pivot_permute_U_spa(spa + kcol, idx_buffer, koff, ipiv_block, nuseg, current_seg);
                        } else {
                            pivot_permute_U_seg(u_val, idx_buffer, koff, ipiv_block, nuseg, current_seg);
                        }
                    }

                    for(Int jseg = 0; jseg < nuseg; jseg += segment_block_size) {  // for each 32 segments
                        const Int bnseg = min(segment_block_size, nuseg - jseg), jseg_end = jseg + bnseg;
                        sptrf_params<sizeof(DATA_T)>::select_update_block_size(ksup_size, bnseg, 
                            update_block_col, update_block_row, left_ld, right_ld);
                        DATA_T *left_buffer = val_buffer;
                        DATA_T *right_buffer = val_buffer + update_block_col * left_ld;
                        DATA_T *right_down = right_buffer + update_block_col;
                        DATA_T *temp_right, *temp_left, *temp_ksup;
                        Int l_pos = 0;
                        kernel.set_update_layout(left_ld, right_ld);

                        if(ksup_size <= update_block_col) {  // no more than 64 columns in ksup. 1-D blocking
                            const Int right_rows = min(left_ld, ksup_ld);
                            const Int trsm_rows = min(right_rows, ((ksup_size - 1) & (~simd_mask)) + simd_width<DATA_T>);
                            const Int mm_rows = right_rows - trsm_rows;
                            const Int idx_len = right_rows - ksup_size;

                            l_ksup_idx = l_idx + ksup_i_off;              // previous supernode

                            TIMER_SET(timer1)
                            // load U
                            temp_right = right_buffer;
                            IF_USE_SPA {
                                for(Int jj = jseg; jj < jseg_end; ++ jj, temp_right += right_ld) {
                                    DATA_T* s = spa + current_seg[jj].dense_pos + kcol;
                                    cached_read(temp_right, s, sizeof(DATA_T) * ksup_size);
                                    memset(s, 0, sizeof(DATA_T) * ksup_size);
                                    memset(temp_right + ksup_size, 0, sizeof(DATA_T) * (trsm_rows - ksup_size));
                                }
                            } else {
                                for(Int jj = jseg; jj < jseg_end; ++ jj, temp_right += right_ld) {
                                    cached_read(temp_right, u_val + current_seg[jj].val_off, sizeof(DATA_T) * ksup_size);
                                    memset(temp_right + ksup_size, 0, sizeof(DATA_T) * (trsm_rows - ksup_size));
                                }
                            }

                            // load Supernode diagnal block
                            temp_ksup = l_ksup_val + 1;
                            temp_left = left_buffer + 1;
                            
                            for(Int kk = 0, read_len = right_rows - 1; kk < ksup_size && read_len > 0; ++kk, --read_len) {
                                DMA_IREAD(temp_ksup, temp_left, sizeof(DATA_T) * read_len);
                                temp_ksup += (ksup_ld + 1);
                                temp_left += (left_ld + 1);
                            }
                            DMA_WAIT_ALL;
                            if(idx_len > 0) {
                                DMA_IREAD(l_ksup_idx, idx_buffer, sizeof(Int) * idx_len);
                            }
                            l_ksup_idx += idx_len;
                            TIMER_SET(timer2)
                            kernel.l_trsm_update(ksup_size, bnseg, trsm_rows, left_buffer, right_buffer);
                            if(mm_rows > 0) {
                                kernel.mm_negative(ksup_size, bnseg, mm_rows, left_buffer + trsm_rows, \
                                    right_buffer, right_buffer + trsm_rows);
                            }
                            TIMER_SET(timer3)
                            DMA_WAIT_ALL;
                            TIMER_SET(timer4)
                            TIMER_GET(tcontmem, timer1, timer2)
                            TIMER_GET(tblascomp, timer2, timer3)
                            TIMER_GET(tcontmem, timer3, timer4)
                                            
                            temp_right = right_buffer;
                            IF_USE_SPA {
                                for(Int jj = jseg; jj < jseg_end; ++ jj, temp_right += right_ld) {
                                    DMA_IWRITE(u_val + current_seg[jj].val_off, temp_right, sizeof(DATA_T) * ksup_size);  // copy back U segment
                                }
                                if (idx_len > 0) {
                                    temp_right = right_buffer + ksup_size;
                                    sparse_update_spa(spa, idx_buffer, temp_right, idx_len, right_ld, &current_seg[jseg], bnseg);
                                }
                                DMA_WAIT_ALL;
                            } else {
                                TIMER_SET(timer1)
                                for(Int jj = jseg; jj < jseg_end; ++ jj, temp_right += right_ld) {
                                    cached_write(u_val + current_seg[jj].val_off, temp_right, sizeof(DATA_T) * ksup_size);  // copy back U segment
                                }
                                TIMER_SET(timer2)
                                if (idx_len > 0) {
                                    Int pos = 0;
                                    temp_right = right_buffer + ksup_size;
                                    for(Int jj = jseg; jj < jseg_end; ++ jj, temp_right += right_ld) {
                                        pos = sparse_update_U(idx_len, idx_buffer, temp_right, jcol_begin, \
                                            u_seg_off, u_seg_idx, u_val, &current_seg[jj]);
                                    }
                                    l_pos = sparse_update_L(idx_len - pos, idx_buffer + pos, right_buffer + ksup_size + pos, right_ld, \
                                            jcol_begin, jcol_end, sup_size, l_pos, l_sup_idx, l_panel_val, \
                                                &current_seg[jseg], bnseg);
                                }
                                TIMER_SET(timer3)
                                TIMER_GET(tcontmem, timer1, timer2)
                                TIMER_GET(tsparse, timer2, timer3)
                            }
                                        

                            // load Supernode off-diagnal blocks
                            for(ioff = left_ld; ioff < ksup_ld; ioff += update_block_row) {
                                Int mm_row_size = min(update_block_row, ksup_ld - ioff);
                                temp_left = left_buffer;
                                temp_ksup = l_ksup_val + ioff;
                                TIMER_SET(timer1)
                                for(Int kk = 0; kk < ksup_size; ++kk, temp_ksup += ksup_ld, temp_left += left_ld) {
                                    DMA_IREAD(temp_ksup, temp_left, sizeof(DATA_T) * mm_row_size);
                                }
                                DMA_READ(l_ksup_idx, idx_buffer, sizeof(Int) * mm_row_size);
                                TIMER_SET(timer2)
                                l_ksup_idx += mm_row_size;
                                
                                kernel.mm_negative(ksup_size, bnseg, mm_row_size, left_buffer, right_buffer, right_down);
                                TIMER_SET(timer3)
                                            
                                temp_right = right_down;
                                IF_USE_SPA {
                                    sparse_update_spa(spa, idx_buffer, temp_right, mm_row_size, right_ld, &current_seg[jseg], bnseg);
                                } else {
                                    Int pos = 0;
                                    for(Int jj = jseg; jj < jseg_end; ++ jj, temp_right += right_ld) {
                                        pos = sparse_update_U(mm_row_size, idx_buffer, temp_right, jcol_begin, \
                                                u_seg_off, u_seg_idx, u_val, &current_seg[jj]);
                                    }
                                    l_pos = sparse_update_L(mm_row_size - pos, idx_buffer + pos, right_down + pos, right_ld, \
                                            jcol_begin, jcol_end, sup_size, l_pos, l_sup_idx, l_panel_val, \
                                            &current_seg[jseg], bnseg);
                                }
                                TIMER_SET(timer4)
                                TIMER_GET(tcontmem, timer1, timer2)
                                TIMER_GET(tblascomp, timer2, timer3)
                                TIMER_GET(tsparse, timer3, timer4)
                            }
                        } else {             // more than 64 columns in ksup, 2-D blocking
                            l_ksup_idx = l_idx + ksup_i_off;              // previous supernode

                            // TRSM part
                            for(ioff = 0; ioff < ksup_size; ioff += update_block_row) {  // ioff : relative to supernode begin
                                const Int useg_rows = min(update_block_row, ksup_size - ioff);
                                const Int right_rows = min(update_block_row, ksup_ld - ioff);
                                const Int col_block_end = ioff + useg_rows, col_cached = ioff - update_block_col;
                                const Int idx_len = right_rows - useg_rows;

                                TIMER_SET(timer1)
                                // load U to right_down
                                temp_right = right_down;
                                IF_USE_SPA {
                                    for(Int jj = jseg; jj < jseg_end; ++ jj, temp_right += right_ld) {
                                        DATA_T* s = spa + current_seg[jj].dense_pos + kcol;
                                        cached_read(temp_right, s + ioff, sizeof(DATA_T) * useg_rows);
                                        memset(s + ioff, 0, sizeof(DATA_T) * useg_rows);
                                        memset(temp_right + useg_rows, 0, sizeof(DATA_T) * (right_rows - useg_rows));
                                    }
                                } else {
                                    for(Int jj = jseg; jj < jseg_end; ++ jj, temp_right += right_ld) {
                                        cached_read(temp_right, u_val + current_seg[jj].val_off + ioff, sizeof(DATA_T) * useg_rows);
                                        memset(temp_right + useg_rows, 0, sizeof(DATA_T) * (right_rows - useg_rows));
                                        // different from the case columns < 64, here we use mm_update only, which requires initializtion
                                        // not use mm_negative
                                    }
                                }
                                            
                                if(idx_len > 0) {  // only happens in the last loop
                                    DMA_READ(l_ksup_idx, idx_buffer, sizeof(Int) * idx_len);
                                    l_ksup_idx += idx_len;
                                }

                                // use the last result for GEMM
                                if(ioff != 0) {
                                    temp_left = left_buffer;
                                    temp_ksup = l_ksup_val + ioff + col_cached * ksup_ld;
                                    // full block
                                    for(Int kk = col_cached; kk < ioff; ++kk, temp_ksup += ksup_ld, temp_left += left_ld) {
                                        DMA_IREAD(temp_ksup, temp_left, sizeof(DATA_T) * right_rows);
                                    }
                                    DMA_WAIT_ALL;

                                    TIMER_SET(timer2)
                                    kernel.mm_update(update_block_col, bnseg, right_rows, left_buffer, right_buffer, right_down);
                                    TIMER_SET(timer3)
                                    TIMER_GET(tcontmem, timer1, timer2)
                                    TIMER_GET(tblascomp, timer2, timer3)
                                } else {
                                    TIMER_SET(timer2)
                                    TIMER_GET(tcontmem, timer1, timer2)
                                }
                                            

                                // full-block GEMM
                                for(poff = 0; poff < col_cached; poff += update_block_col) {
                                    Int pend = poff + update_block_col;
                                    temp_left = left_buffer;
                                    temp_ksup = l_ksup_val + ioff + poff * ksup_ld;
                                    
                                    TIMER_SET(timer1)
                                    temp_right = right_buffer;
                                    IF_USE_SPA {
                                        for(Int jj = jseg; jj < jseg_end; ++ jj, temp_right += right_ld) {
                                            DMA_IREAD(u_val + current_seg[jj].val_off + poff, temp_right, sizeof(DATA_T) * update_block_col);
                                        }
                                    } else {
                                        for(Int jj = jseg; jj < jseg_end; ++ jj, temp_right += right_ld) {
                                            cached_read(temp_right, u_val + current_seg[jj].val_off + poff, sizeof(DATA_T) * update_block_col);
                                        }
                                    }

                                    // full block
                                    for(Int kk = poff; kk < pend; ++kk, temp_ksup += ksup_ld, temp_left += left_ld) {
                                        DMA_IREAD(temp_ksup, temp_left, sizeof(DATA_T) * right_rows);
                                    }
                                    DMA_WAIT_ALL;
                                    
                                    TIMER_SET(timer2)
                                    kernel.mm_update(update_block_col, bnseg, right_rows, left_buffer, right_buffer, right_down);
                                    TIMER_SET(timer3)
                                    TIMER_GET(tcontmem, timer1, timer2)
                                    TIMER_GET(tblascomp, timer2, timer3)
                                }
                                // TRSM
                                temp_right = right_down;
                                for(poff = ioff; poff < col_block_end; poff += update_block_col, temp_right += update_block_col) {
                                    Int psize = min(update_block_col, col_block_end - poff), pend = poff + psize;
                                    Int lower_part = right_rows - (poff - ioff);
                                    Int trsm_part = min(lower_part, ((psize - 1) & (~simd_mask)) + simd_width<DATA_T>);
                                    Int mm_part = lower_part - trsm_part;
                                    Int left_col = pend - poff;
                                    temp_ksup = l_ksup_val + poff + poff * ksup_ld + 1;
                                    temp_left = left_buffer + 1;

                                    TIMER_SET(timer1)
                                    for(Int kk = poff, read_len = lower_part - 1; kk < pend && read_len > 0; ++kk, --read_len) {
                                        DMA_IREAD(temp_ksup, temp_left, sizeof(DATA_T) * read_len);
                                        temp_ksup += (ksup_ld + 1);
                                        temp_left += (left_ld + 1);
                                    }
                                    DMA_WAIT_ALL;
                                    
                                    TIMER_SET(timer2)
                                    kernel.l_trsm_update(left_col, bnseg, trsm_part, left_buffer, temp_right);
                                    if(mm_part > 0) {
                                        kernel.mm_update(left_col, bnseg, mm_part, left_buffer + trsm_part, \
                                                temp_right, temp_right + trsm_part);
                                    }
                                    TIMER_SET(timer3)
                                    TIMER_GET(tcontmem, timer1, timer2)
                                    TIMER_GET(tblascomp, timer2, timer3)
                                }
                                temp_right = right_down;
                                IF_USE_SPA {
                                    for(Int jj = jseg; jj < jseg_end; ++ jj, temp_right += right_ld) {
                                        DMA_IWRITE(u_val + current_seg[jj].val_off + ioff, temp_right, sizeof(DATA_T) * useg_rows);
                                    }
                                    if(idx_len > 0) {
                                        DATA_T *val = right_down + useg_rows;
                                        sparse_update_spa(spa, idx_buffer, val, idx_len, right_ld, &current_seg[jseg], bnseg);
                                    }
                                    DMA_WAIT_ALL;
                                } else {
                                    TIMER_SET(timer1)
                                    for(Int jj = jseg; jj < jseg_end; ++ jj, temp_right += right_ld) {
                                        // store U
                                        cached_write(u_val + current_seg[jj].val_off + ioff, temp_right, sizeof(DATA_T) * useg_rows);
                                    }
                                    TIMER_SET(timer2)
                                    if(idx_len > 0) {
                                        Int pos;
                                        DATA_T *val = right_down + useg_rows;
                                        temp_right = val;
                                        for(Int jj = jseg; jj < jseg_end; ++ jj, temp_right += right_ld) {
                                            pos = sparse_update_U(idx_len, idx_buffer, temp_right, jcol_begin, \
                                                    u_seg_off, u_seg_idx, u_val, &current_seg[jj]);
                                        }
                                        l_pos = sparse_update_L(idx_len - pos, idx_buffer + pos, val + pos, right_ld, \
                                                jcol_begin, jcol_end, sup_size, l_pos, l_sup_idx, l_panel_val, \
                                                    &current_seg[jseg], bnseg);
                                    }
                                    TIMER_SET(timer3)
                                    TIMER_GET(tcontmem, timer1, timer2)
                                    TIMER_GET(tsparse, timer2, timer3)
                                }
                                TIMER_SET(timer1)
                                temp_right = right_down; // move the result for the next GEMM
                                for(Int jj = jseg; jj < jseg_end; ++ jj, temp_right += right_ld) {
                                    memcpy(temp_right - update_block_col, temp_right + update_block_row - update_block_col, \
                                                sizeof(DATA_T) * update_block_col);
                                }
                                TIMER_SET(timer2)
                                TIMER_GET(tcontmem, timer1, timer2)
                            }
                            // GEMM part
                            for(; ioff < ksup_ld; ioff += update_block_row) {
                                // ksup_size > update_block_col, mm_col_size == update_block_col
                                Int mm_row_size = min(update_block_row, ksup_ld - ioff);

                                TIMER_SET(timer1)
                                temp_left = left_buffer;
                                temp_ksup = l_ksup_val + ioff;
                                for(Int kk = 0; kk < update_block_col; ++kk, temp_ksup += ksup_ld, temp_left += left_ld) {
                                    DMA_IREAD(temp_ksup, temp_left, sizeof(DATA_T) * mm_row_size);
                                }
                                temp_right = right_buffer;
                                
                                IF_USE_SPA {
                                    for(Int jj = jseg; jj < jseg_end; ++ jj, temp_right += right_ld) {
                                        DMA_IREAD(u_val + current_seg[jj].val_off, temp_right, sizeof(DATA_T) * update_block_col);
                                    }
                                } else {
                                    for(Int jj = jseg; jj < jseg_end; ++ jj, temp_right += right_ld) {
                                        cached_read(temp_right, u_val + current_seg[jj].val_off, sizeof(DATA_T) * update_block_col);
                                    }
                                }
                                DMA_WAIT_ALL;
                                DMA_IREAD(l_ksup_idx, idx_buffer, sizeof(Int) * mm_row_size);
                                l_ksup_idx += mm_row_size;

                                TIMER_SET(timer2)
                                kernel.mm_negative(update_block_col, bnseg, mm_row_size, left_buffer, right_buffer, right_down);
                                TIMER_SET(timer3)
                                TIMER_GET(tcontmem, timer1, timer2)
                                TIMER_GET(tblascomp, timer2, timer3)

                                for(poff = update_block_col; poff < ksup_size; poff += update_block_col) {
                                    Int mm_col_size = min(update_block_col, ksup_size - poff);
                                    TIMER_SET(timer1)
                                    temp_left = left_buffer;
                                    temp_ksup = l_ksup_val + ioff + poff * ksup_ld;
                                    for(Int kk = 0; kk < mm_col_size; ++kk, temp_ksup += ksup_ld, temp_left += left_ld) {
                                        DMA_IREAD(temp_ksup, temp_left, sizeof(DATA_T) * mm_row_size);
                                    }
                                    temp_right = right_buffer;
                                    IF_USE_SPA {
                                        for(Int jj = jseg; jj < jseg_end; ++ jj, temp_right += right_ld) {
                                            DMA_IREAD(u_val + current_seg[jj].val_off + poff, temp_right, sizeof(DATA_T) * mm_col_size);
                                        }
                                    } else {
                                        for(Int jj = jseg; jj < jseg_end; ++ jj, temp_right += right_ld) {
                                            cached_read(temp_right, u_val + current_seg[jj].val_off + poff, sizeof(DATA_T) * mm_col_size);
                                        }
                                    }
                                    DMA_WAIT_ALL;
                                    TIMER_SET(timer2)
                                    kernel.mm_update(mm_col_size, bnseg, mm_row_size, left_buffer, right_buffer, right_down);
                                    TIMER_SET(timer3)
                                    TIMER_GET(tcontmem, timer1, timer2)
                                    TIMER_GET(tblascomp, timer2, timer3)
                                }
                                TIMER_SET(timer1)
                                DMA_WAIT_ALL;

                                TIMER_SET(timer2)
                                temp_right = right_down;
                                IF_USE_SPA {
                                    sparse_update_spa(spa, idx_buffer, temp_right, mm_row_size, right_ld, &current_seg[jseg], bnseg);
                                } else {
                                    Int pos = 0;
                                    for(Int jj = jseg; jj < jseg_end; ++ jj, temp_right += right_ld) {
                                        pos = sparse_update_U(mm_row_size, idx_buffer, temp_right, jcol_begin, \
                                            u_seg_off, u_seg_idx, u_val, &current_seg[jj]);
                                    }
                                    l_pos = sparse_update_L(mm_row_size - pos, idx_buffer + pos, right_down + pos, right_ld, \
                                            jcol_begin, jcol_end, sup_size, l_pos, l_sup_idx, l_panel_val, \
                                            &current_seg[jseg], bnseg);
                                }
                                TIMER_SET(timer3)
                                TIMER_GET(tcontmem, timer1, timer2)
                                TIMER_GET(tsparse, timer2, timer3)
                            }
                        }
                    }
                }

                if(completion.any_waiting()) {  // false if nbchild == 0
                    auto& next_seg_ = first_waiting;
                    // phase 2: wait and update from previous remaining supernodes
                    for (;;) {
                        DATA_T *l_ksup_val;
                        const Int *l_ksup_idx;
                        Int kcol, ksup, ksup_size, ksup_nrow, ioff, poff, target_id;
                        Int ksup_i_off, ksup_ld, nuseg, kstatus;
                        Bool already_done;
                                
                        kcol = jcol_begin;
                        for(Int jj = 0; jj < ncol; ++ jj) {
                            kcol = min(kcol, next_seg_[jj].index);
                        }
                        if(kcol >= jcol_begin) {
                            break;
                        }

                        ksup = col2sup[kcol];
                        
                        kstatus = sup_status[ksup];
                        already_done = completion.is_already_done(ksup, kstatus);

                        if(already_done) { // already done in phase 1, skip
                            for(Int jj = 0; jj < ncol; ++ jj) {
                                if(next_seg_[jj].index == kcol) {
                                    Int k = next_seg_[jj].position, k_next = k + 1;
                                    Int jcol_rel = block_cyclic_local_to_global(jj, group_size), jcol = jpanel + jcol_rel;
                                    next_seg_[jj].position = k_next;
                                    next_seg_[jj].index = (k_next < u_col_off[jcol + 1]) ? u_seg_idx[k_next] : jcol_begin;
                                }
                            }
                            continue;
                        }

                        TIMER_SET(timer1)
                        completion.wait(ksup, kstatus, comm);
                        TIMER_SET(timer2)
                        TIMER_GET(twait, timer1, timer2)

                        ksup_size = sup2col[ksup + 1] - sup2col[ksup];
                        ksup_i_off = l_i_off[ksup];
                        l_ksup_val = l_val + l_v_off[ksup];              // previous supernode
                        ksup_nrow = l_i_off[ksup + 1] - ksup_i_off;
                        ksup_ld = ksup_nrow + ksup_size;

                        // find the kcol segment
                        nuseg = 0;
                        for(Int jj = 0; jj < ncol; ++ jj) {
                            if(next_seg_[jj].index == kcol) {  // non-zero segment
                                Int k = next_seg_[jj].position, k_next = k + 1;
                                Int jcol_rel = block_cyclic_local_to_global(jj, group_size), jcol = jpanel + jcol_rel;
                                        
                                current_seg[nuseg].val_off = u_seg_off[k];
                                current_seg[nuseg].dense_pos = SELECT_SPA(jj * n, jcol_rel * sup_ld);
                                current_seg[nuseg++].seg_pos = k;

                                next_seg_[jj].position = k_next;
                                next_seg_[jj].index = (k_next < u_col_off[jcol + 1]) ? u_seg_idx[k_next] : jcol_begin;
                            }
                        }

                        // pivot permute
                        for(Int koff = 0; koff < ksup_size; koff += trf_idx_size<DATA_T>) {
                            Int ipiv_block = min(trf_idx_size<DATA_T>, ksup_size - koff);
                            DMA_READ(ipiv + kcol + koff, idx_buffer, sizeof(Int) * ipiv_block);
                            IF_USE_SPA {
                                pivot_permute_U_spa(spa + kcol, idx_buffer, koff, ipiv_block, nuseg, current_seg);
                            } else {
                                pivot_permute_U_seg(u_val, idx_buffer, koff, ipiv_block, nuseg, current_seg);
                            }
                        }

                        for(Int jseg = 0; jseg < nuseg; jseg += segment_block_size) {  // for each 32 segments
                            const Int bnseg = min(segment_block_size, nuseg - jseg), jseg_end = jseg + bnseg;
                            sptrf_params<sizeof(DATA_T)>::select_update_block_size(ksup_size, bnseg, 
                                update_block_col, update_block_row, left_ld, right_ld);
                            DATA_T *left_buffer = val_buffer;
                            DATA_T *right_buffer = val_buffer + update_block_col * left_ld;
                            DATA_T *right_down = right_buffer + update_block_col;
                            DATA_T *temp_right, *temp_left, *temp_ksup;
                            Int l_pos = 0;
                            kernel.set_update_layout(left_ld, right_ld);

                            if(ksup_size <= update_block_col) {  // no more than 64 columns in ksup. 1-D blocking
                                const Int right_rows = min(left_ld, ksup_ld);
                                const Int trsm_rows = min(right_rows, ((ksup_size - 1) & (~simd_mask)) + simd_width<DATA_T>);
                                const Int mm_rows = right_rows - trsm_rows;
                                const Int idx_len = right_rows - ksup_size;

                                l_ksup_idx = l_idx + ksup_i_off;              // previous supernode

                                TIMER_SET(timer1)
                                // load U
                                temp_right = right_buffer;
                                IF_USE_SPA {
                                    for(Int jj = jseg; jj < jseg_end; ++ jj, temp_right += right_ld) {
                                        DATA_T* s = spa + current_seg[jj].dense_pos + kcol;
                                        cached_read(temp_right, s, sizeof(DATA_T) * ksup_size);
                                        memset(s, 0, sizeof(DATA_T) * ksup_size);
                                        memset(temp_right + ksup_size, 0, sizeof(DATA_T) * (trsm_rows - ksup_size));
                                    }
                                } else {
                                    for(Int jj = jseg; jj < jseg_end; ++ jj, temp_right += right_ld) {
                                        cached_read(temp_right, u_val + current_seg[jj].val_off, sizeof(DATA_T) * ksup_size);
                                        memset(temp_right + ksup_size, 0, sizeof(DATA_T) * (trsm_rows - ksup_size));
                                    }
                                }

                                // load Supernode diagnal block
                                temp_ksup = l_ksup_val + 1;
                                temp_left = left_buffer + 1;
                                
                                for(Int kk = 0, read_len = right_rows - 1; kk < ksup_size && read_len > 0; ++kk, --read_len) {
                                    DMA_IREAD(temp_ksup, temp_left, sizeof(DATA_T) * read_len);
                                    temp_ksup += (ksup_ld + 1);
                                    temp_left += (left_ld + 1);
                                }
                                DMA_WAIT_ALL;
                                if(idx_len > 0) {
                                    DMA_IREAD(l_ksup_idx, idx_buffer, sizeof(Int) * idx_len);
                                }
                                TIMER_SET(timer2)
                                l_ksup_idx += idx_len;
                                kernel.l_trsm_update(ksup_size, bnseg, trsm_rows, left_buffer, right_buffer);
                                if(mm_rows > 0) {
                                    kernel.mm_negative(ksup_size, bnseg, mm_rows, left_buffer + trsm_rows, \
                                        right_buffer, right_buffer + trsm_rows);
                                }
                                TIMER_SET(timer3)
                                DMA_WAIT_ALL;
                                TIMER_SET(timer4)
                                TIMER_GET(tcontmem, timer1, timer2)
                                TIMER_GET(tblascomp, timer2, timer3)
                                TIMER_GET(tcontmem, timer3, timer4)
                                            
                                temp_right = right_buffer;
                                IF_USE_SPA {
                                    for(Int jj = jseg; jj < jseg_end; ++ jj, temp_right += right_ld) {
                                        DMA_IWRITE(u_val + current_seg[jj].val_off, temp_right, sizeof(DATA_T) * ksup_size);  // copy back U segment
                                    }
                                    if (idx_len > 0) {
                                        temp_right = right_buffer + ksup_size;
                                        sparse_update_spa(spa, idx_buffer, temp_right, idx_len, right_ld, &current_seg[jseg], bnseg);
                                    }
                                    DMA_WAIT_ALL;
                                } else {
                                    TIMER_SET(timer1)
                                    for(Int jj = jseg; jj < jseg_end; ++ jj, temp_right += right_ld) {
                                        cached_write(u_val + current_seg[jj].val_off, temp_right, sizeof(DATA_T) * ksup_size);  // copy back U segment
                                    }
                                    TIMER_SET(timer2)
                                    if (idx_len > 0) {
                                        Int pos = 0;
                                        temp_right = right_buffer + ksup_size;
                                        for(Int jj = jseg; jj < jseg_end; ++ jj, temp_right += right_ld) {
                                            pos = sparse_update_U(idx_len, idx_buffer, temp_right, jcol_begin, \
                                                u_seg_off, u_seg_idx, u_val, &current_seg[jj]);
                                        }
                                        l_pos = sparse_update_L(idx_len - pos, idx_buffer + pos, right_buffer + ksup_size + pos, right_ld, \
                                                jcol_begin, jcol_end, sup_size, l_pos, l_sup_idx, l_panel_val, \
                                                &current_seg[jseg], bnseg);
                                    }
                                    TIMER_SET(timer3)
                                    TIMER_GET(tcontmem, timer1, timer2)
                                    TIMER_GET(tsparse, timer2, timer3)
                                }
                                        

                                // load Supernode off-diagnal blocks
                                for(ioff = left_ld; ioff < ksup_ld; ioff += update_block_row) {
                                    Int mm_row_size = min(update_block_row, ksup_ld - ioff);
                                    TIMER_SET(timer1)
                                    temp_left = left_buffer;
                                    temp_ksup = l_ksup_val + ioff;
                                    for(Int kk = 0; kk < ksup_size; ++kk, temp_ksup += ksup_ld, temp_left += left_ld) {
                                        DMA_IREAD(temp_ksup, temp_left, sizeof(DATA_T) * mm_row_size);
                                    }
                                    DMA_READ(l_ksup_idx, idx_buffer, sizeof(Int) * mm_row_size);
                                    l_ksup_idx += mm_row_size;

                                    TIMER_SET(timer2)
                                    kernel.mm_negative(ksup_size, bnseg, mm_row_size, left_buffer, right_buffer, right_down);
                                    TIMER_SET(timer3)

                                    temp_right = right_down;
                                    IF_USE_SPA {
                                        sparse_update_spa(spa, idx_buffer, temp_right, mm_row_size, right_ld, &current_seg[jseg], bnseg);
                                    } else {
                                        Int pos = 0;
                                        for(Int jj = jseg; jj < jseg_end; ++ jj, temp_right += right_ld) {
                                            pos = sparse_update_U(mm_row_size, idx_buffer, temp_right, jcol_begin, \
                                                u_seg_off, u_seg_idx, u_val, &current_seg[jj]);
                                        }
                                        l_pos = sparse_update_L(mm_row_size - pos, idx_buffer + pos, right_down + pos, right_ld, \
                                                jcol_begin, jcol_end, sup_size, l_pos, l_sup_idx, l_panel_val, \
                                                &current_seg[jseg], bnseg);
                                    }
                                    TIMER_SET(timer4)
                                    TIMER_GET(tcontmem, timer1, timer2)
                                    TIMER_GET(tblascomp, timer2, timer3)
                                    TIMER_GET(tsparse, timer3, timer4)
                                }
                            } else {             // more than 64 columns in ksup, 2-D blocking
                                l_ksup_idx = l_idx + ksup_i_off;              // previous supernode

                                // TRSM part
                                for(ioff = 0; ioff < ksup_size; ioff += update_block_row) {  // ioff : relative to supernode begin
                                    const Int useg_rows = min(update_block_row, ksup_size - ioff);
                                    const Int right_rows = min(update_block_row, ksup_ld - ioff);
                                    const Int col_block_end = ioff + useg_rows, col_cached = ioff - update_block_col;
                                    const Int idx_len = right_rows - useg_rows;

                                    TIMER_SET(timer1)
                                    // load U to right_down
                                    temp_right = right_down;
                                    IF_USE_SPA {
                                        for(Int jj = jseg; jj < jseg_end; ++ jj, temp_right += right_ld) {
                                            DATA_T* s = spa + current_seg[jj].dense_pos + kcol;
                                            cached_read(temp_right, s + ioff, sizeof(DATA_T) * useg_rows);
                                            memset(s + ioff, 0, sizeof(DATA_T) * useg_rows);
                                            memset(temp_right + useg_rows, 0, sizeof(DATA_T) * (right_rows - useg_rows));
                                        }
                                    } else {
                                        for(Int jj = jseg; jj < jseg_end; ++ jj, temp_right += right_ld) {
                                            cached_read(temp_right, u_val + current_seg[jj].val_off + ioff, sizeof(DATA_T) * useg_rows);
                                            memset(temp_right + useg_rows, 0, sizeof(DATA_T) * (right_rows - useg_rows));
                                            // different from the case columns < 64, here we use mm_update only, which requires initializtion
                                            // not use mm_negative
                                        }
                                    }
                                            
                                    if(idx_len > 0) {  // only happens in the last loop
                                        DMA_READ(l_ksup_idx, idx_buffer, sizeof(Int) * idx_len);
                                        l_ksup_idx += idx_len;
                                    }


                                    // use the last result for GEMM
                                    if(ioff != 0) {
                                        temp_left = left_buffer;
                                        temp_ksup = l_ksup_val + ioff + col_cached * ksup_ld;
                                        // full block
                                        for(Int kk = col_cached; kk < ioff; ++kk, temp_ksup += ksup_ld, temp_left += left_ld) {
                                            DMA_IREAD(temp_ksup, temp_left, sizeof(DATA_T) * right_rows);
                                        }
                                        DMA_WAIT_ALL;

                                        TIMER_SET(timer2)
                                        kernel.mm_update(update_block_col, bnseg, right_rows, left_buffer, right_buffer, right_down);
                                        TIMER_SET(timer3)
                                        TIMER_GET(tcontmem, timer1, timer2)
                                        TIMER_GET(tblascomp, timer2, timer3)
                                    } else {
                                        TIMER_SET(timer2)
                                        TIMER_GET(tcontmem, timer1, timer2)
                                    }
                                            

                                    // full-block GEMM
                                    for(poff = 0; poff < col_cached; poff += update_block_col) {
                                        Int pend = poff + update_block_col;
                                        temp_left = left_buffer;
                                        temp_ksup = l_ksup_val + ioff + poff * ksup_ld;
                                                
                                        TIMER_SET(timer1)
                                        temp_right = right_buffer;
                                        IF_USE_SPA {
                                            for(Int jj = jseg; jj < jseg_end; ++ jj, temp_right += right_ld) {
                                                DMA_IREAD(u_val + current_seg[jj].val_off + poff, temp_right, sizeof(DATA_T) * update_block_col);
                                            }
                                        } else {
                                            for(Int jj = jseg; jj < jseg_end; ++ jj, temp_right += right_ld) {
                                                cached_read(temp_right, u_val + current_seg[jj].val_off + poff, sizeof(DATA_T) * update_block_col);
                                            }
                                        }

                                        // full block
                                        for(Int kk = poff; kk < pend; ++kk, temp_ksup += ksup_ld, temp_left += left_ld) {
                                            DMA_IREAD(temp_ksup, temp_left, sizeof(DATA_T) * right_rows);
                                        }
                                        DMA_WAIT_ALL;
                                        TIMER_SET(timer2)
                                        kernel.mm_update(update_block_col, bnseg, right_rows, left_buffer, right_buffer, right_down);
                                        TIMER_SET(timer3)
                                        TIMER_GET(tcontmem, timer1, timer2)
                                        TIMER_GET(tblascomp, timer2, timer3)
                                    }
                                    // TRSM
                                    temp_right = right_down;
                                    for(poff = ioff; poff < col_block_end; poff += update_block_col, temp_right += update_block_col) {
                                        Int psize = min(update_block_col, col_block_end - poff), pend = poff + psize;
                                        Int lower_part = right_rows - (poff - ioff);
                                        Int trsm_part = min(lower_part, ((psize - 1) & (~simd_mask)) + simd_width<DATA_T>);
                                        Int mm_part = lower_part - trsm_part;
                                        Int left_col = pend - poff;
                                        temp_ksup = l_ksup_val + poff + poff * ksup_ld + 1;
                                        temp_left = left_buffer + 1;
                                        
                                        TIMER_SET(timer1)
                                        for(Int kk = poff, read_len = lower_part - 1; kk < pend && read_len > 0; ++kk, --read_len) {
                                            DMA_IREAD(temp_ksup, temp_left, sizeof(DATA_T) * read_len);
                                            temp_ksup += (ksup_ld + 1);
                                            temp_left += (left_ld + 1);
                                        }
                                        DMA_WAIT_ALL;
                                        TIMER_SET(timer2)
                                        
                                        kernel.l_trsm_update(left_col, bnseg, trsm_part, left_buffer, temp_right);
                                        if(mm_part > 0) {
                                            kernel.mm_update(left_col, bnseg, mm_part, left_buffer + trsm_part, \
                                                temp_right, temp_right + trsm_part);
                                        }
                                        TIMER_SET(timer3)
                                        TIMER_GET(tcontmem, timer1, timer2)
                                        TIMER_GET(tblascomp, timer2, timer3)
                                    }
                                    temp_right = right_down;
                                    IF_USE_SPA {
                                        for(Int jj = jseg; jj < jseg_end; ++ jj, temp_right += right_ld) {
                                            DMA_IWRITE(u_val + current_seg[jj].val_off + ioff, temp_right, sizeof(DATA_T) * useg_rows);
                                        }
                                        if(idx_len > 0) {
                                            DATA_T *val = right_down + useg_rows;
                                            sparse_update_spa(spa, idx_buffer, val, idx_len, right_ld, &current_seg[jseg], bnseg);
                                        }
                                        DMA_WAIT_ALL;
                                    } else {
                                        TIMER_SET(timer1)
                                        for(Int jj = jseg; jj < jseg_end; ++ jj, temp_right += right_ld) {
                                            // store U
                                            cached_write(u_val + current_seg[jj].val_off + ioff, temp_right, sizeof(DATA_T) * useg_rows);
                                        }
                                        TIMER_SET(timer2)
                                        if(idx_len > 0) {
                                            Int pos;
                                            DATA_T *val = right_down + useg_rows;
                                            temp_right = val;
                                            for(Int jj = jseg; jj < jseg_end; ++ jj, temp_right += right_ld) {
                                                pos = sparse_update_U(idx_len, idx_buffer, temp_right, jcol_begin, \
                                                    u_seg_off, u_seg_idx, u_val, &current_seg[jj]);
                                            }
                                            l_pos = sparse_update_L(idx_len - pos, idx_buffer + pos, val + pos, right_ld, \
                                                jcol_begin, jcol_end, sup_size, l_pos, l_sup_idx, l_panel_val, \
                                                    &current_seg[jseg], bnseg);
                                        }
                                        TIMER_SET(timer3)
                                        TIMER_GET(tcontmem, timer1, timer2)
                                        TIMER_GET(tsparse, timer2, timer3)
                                    }
                                    TIMER_SET(timer1)
                                    temp_right = right_down; // move the result for the next GEMM
                                    for(Int jj = jseg; jj < jseg_end; ++ jj, temp_right += right_ld) {
                                        memcpy(temp_right - update_block_col, temp_right + update_block_row - update_block_col, \
                                                sizeof(DATA_T) * update_block_col);
                                    }
                                    TIMER_SET(timer2)
                                    TIMER_GET(tcontmem, timer1, timer2)
                                }
                                // GEMM part
                                for(; ioff < ksup_ld; ioff += update_block_row) {
                                    // ksup_size > update_block_col, mm_col_size == update_block_col
                                    Int mm_row_size = min(update_block_row, ksup_ld - ioff);
                                    TIMER_SET(timer1)
                                    temp_left = left_buffer;
                                    temp_ksup = l_ksup_val + ioff;
                                    for(Int kk = 0; kk < update_block_col; ++kk, temp_ksup += ksup_ld, temp_left += left_ld) {
                                        DMA_IREAD(temp_ksup, temp_left, sizeof(DATA_T) * mm_row_size);
                                    }
                                    temp_right = right_buffer;
                                    
                                    IF_USE_SPA {
                                        for(Int jj = jseg; jj < jseg_end; ++ jj, temp_right += right_ld) {
                                            DMA_IREAD(u_val + current_seg[jj].val_off, temp_right, sizeof(DATA_T) * update_block_col);
                                        }
                                    } else {
                                        for(Int jj = jseg; jj < jseg_end; ++ jj, temp_right += right_ld) {
                                            cached_read(temp_right, u_val + current_seg[jj].val_off, sizeof(DATA_T) * update_block_col);
                                        }
                                    }
                                    DMA_WAIT_ALL;
                                    DMA_IREAD(l_ksup_idx, idx_buffer, sizeof(Int) * mm_row_size);
                                    l_ksup_idx += mm_row_size;

                                    TIMER_SET(timer2)
                                    kernel.mm_negative(update_block_col, bnseg, mm_row_size, left_buffer, right_buffer, right_down);
                                    TIMER_SET(timer3)
                                    TIMER_GET(tcontmem, timer1, timer2)
                                    TIMER_GET(tblascomp, timer2, timer3)

                                    for(poff = update_block_col; poff < ksup_size; poff += update_block_col) {
                                        Int mm_col_size = min(update_block_col, ksup_size - poff);
                                        TIMER_SET(timer1)
                                        temp_left = left_buffer;
                                        temp_ksup = l_ksup_val + ioff + poff * ksup_ld;
                                        for(Int kk = 0; kk < mm_col_size; ++kk, temp_ksup += ksup_ld, temp_left += left_ld) {
                                            DMA_IREAD(temp_ksup, temp_left, sizeof(DATA_T) * mm_row_size);
                                        }
                                        temp_right = right_buffer;
                                        IF_USE_SPA {
                                            for(Int jj = jseg; jj < jseg_end; ++ jj, temp_right += right_ld) {
                                                DMA_IREAD(u_val + current_seg[jj].val_off + poff, temp_right, sizeof(DATA_T) * mm_col_size);
                                            }
                                        } else {
                                            for(Int jj = jseg; jj < jseg_end; ++ jj, temp_right += right_ld) {
                                                cached_read(temp_right, u_val + current_seg[jj].val_off + poff, sizeof(DATA_T) * mm_col_size);
                                            }
                                        }
                                        DMA_WAIT_ALL;
                                        TIMER_SET(timer2)
                                        kernel.mm_update(mm_col_size, bnseg, mm_row_size, left_buffer, right_buffer, right_down);
                                        TIMER_SET(timer3)
                                        TIMER_GET(tcontmem, timer1, timer2)
                                        TIMER_GET(tblascomp, timer2, timer3)
                                    }
                                    TIMER_SET(timer1)
                                    DMA_WAIT_ALL;
                                    TIMER_SET(timer2)

                                    temp_right = right_down;
                                    IF_USE_SPA {
                                        sparse_update_spa(spa, idx_buffer, temp_right, mm_row_size, right_ld, &current_seg[jseg], bnseg);
                                    } else {
                                        Int pos = 0;
                                        for(Int jj = jseg; jj < jseg_end; ++ jj, temp_right += right_ld) {
                                            pos = sparse_update_U(mm_row_size, idx_buffer, temp_right, jcol_begin, \
                                                u_seg_off, u_seg_idx, u_val, &current_seg[jj]);
                                        }
                                        l_pos = sparse_update_L(mm_row_size - pos, idx_buffer + pos, right_down + pos, right_ld, \
                                                jcol_begin, jcol_end, sup_size, l_pos, l_sup_idx, l_panel_val, \
                                                &current_seg[jseg], bnseg);
                                    }
                                    TIMER_SET(timer3)
                                    TIMER_GET(tcontmem, timer1, timer2)
                                    TIMER_GET(tsparse, timer2, timer3)
                                }
                            }
                        }
                    }
                }
                IF_USE_SPA {
                    auto idx = l_sup_idx - sup_size;
                    DATA_T* s = spa + jcol_begin;
                    for(Int jj = 0; jj < ncol; ++ jj, s += n) {
                        auto l = l_panel_val + sup_ld * block_cyclic_local_to_global(jj, group_size);
                        memcpy(l, s, sizeof(DATA_T) * sup_size);
                        memset(s, 0, sizeof(DATA_T) * sup_size);
                    }
                    for(Int ii = sup_size; ii < sup_ld; ii += trf_idx_size<DATA_T>) {
                        auto val = l_panel_val + ii;
                        Int idx_len = min(trf_idx_size<DATA_T>, sup_ld - ii);
                        DMA_READ(idx + ii, idx_buffer, sizeof(Int) * idx_len);
                        s = spa;
                        for(Int jj = 0; jj < ncol; ++ jj, s += n) {
                            auto l = val + sup_ld * block_cyclic_local_to_global(jj, group_size);
                            for(Int i = 0; i < idx_len; ++i) {
                                Int index = idx_buffer[i];
                                l[i] = s[index];
                                s[index] = DATA_T(0);
                            }
                        }
                    }
                }
            }
            perturb_count += kernel.factorize_super_par(val_buffer, l_sup_val, idx_buffer, sup_ipiv, \
                jgroup - jcol_begin, min(jgroup + group_panel_size, jcol_end) - jcol_begin, sup_size, sup_ld);
        }
        /* pivot permute off-diagnal L */
        kernel.pivot_permute_L_parallel(l_sup_val, reinterpret_cast<Int*>(&val_buffer[0]), sup_ipiv, sup_size, sup_ld);
        evict_cache(l_sup_val, l_sup_val + sup_size * sup_ld);
        evict_cache(sup_ipiv, sup_ipiv + sup_size);
        mem_fence();
        /*
            | A |   | C |
            | A | B | C |
            | A | B | C |
            etree: A -> B -> C
        In this matrix, B may complete early than A, because B actually does not depend on A.
        However at this time, C still needs to wait until A completes. 
         */
        while(msg.task.t.nb_child != 0); /* cannot complete while children not complete */
    }
    
#ifdef LU_CPE_PROFILE
    comm.record_update_timing(tblascomp, tcontmem, twait, tsparse);
    comm.record_fact_timing(kernel.tcomp, kernel.tcontmem, kernel.tcomm);
#endif
    return perturb_count;
}

template Int queue_worker<float>(const sptrf_arg_t<float>& args, worker_communicator comm);
template Int queue_worker<double>(const sptrf_arg_t<double>& args, worker_communicator comm);
template Int queue_worker<SComplex>(const sptrf_arg_t<SComplex>& args, worker_communicator comm);
template Int queue_worker<DComplex>(const sptrf_arg_t<DComplex>& args, worker_communicator comm);
}