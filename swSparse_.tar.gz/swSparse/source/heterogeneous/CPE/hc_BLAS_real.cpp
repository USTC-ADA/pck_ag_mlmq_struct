#include "swSparse_trf.h"
#include "internal/rename.h"
#include "internal/debug.h"
#include "internal/templates.h"
#include "internal/utils.h"
#include "internal/CPE_blas_kernels.h"
#include "internal/sptrf_param.h"

namespace swSparse {
//__thread_local bool verbose1 = false;
//void set_verbose1(bool x) { verbose1 = x; }

template<typename REAL_T>
struct INIT_ZERO {
    using SIMD_T = simd_t<REAL_T>;
    template <Int i, Int j>
    INLINE static SIMD_T init(REAL_T *c, Int right_ld) {
        SIMD_T x = 0;
        return x;
    }
};

#define SIMD_LOAD(v, p) v = *reinterpret_cast<typename std::template add_pointer<decltype(v)>::type>(p)
#define SIMD_STORE(v, p) *reinterpret_cast<typename std::template add_pointer<decltype(v)>::type>(p) = v

// internal compiler error
// #define SIMD_LOAD(v, p) simd_load(v, p)
// #define SIMD_STORE(v, p) simd_store(v, p)

template<typename REAL_T>
struct INIT_REAL {
    using SIMD_T = simd_t<REAL_T>;
    template <Int i, Int j>
    INLINE static SIMD_T init(REAL_T *c, Int right_ld) {
        SIMD_T x;
        REAL_T* ptr = c + i * simd_width<REAL_T> + right_ld * j;
        SIMD_LOAD(x, ptr);
        return x;
    }
};

template <typename INIT, typename REAL_T, Int ROWS, Int COLUMNS>
struct UNFOLD {  // helper for loop unrooling
    using SIMD_T = simd_t<REAL_T>;
    template <Int i, Int j>
    INLINE static void init(SIMD_T& reg, REAL_T *c, Int ld) {
        if constexpr ((i < ROWS) && (j < COLUMNS)) {
            reg = INIT::template init<i, j>(c, ld);
        }
    }
    template <Int i, Int j>
    INLINE static void load(SIMD_T& reg, REAL_T *c, Int ld) {
        if constexpr ((i < ROWS) && (j < COLUMNS)) {
            SIMD_LOAD(reg, c + i * simd_width<REAL_T> + ld * j);
        }
    }
    template <Int i, Int j>
    INLINE static void load_copy(SIMD_T& reg, REAL_T *c, Int ld) {
        if constexpr ((i < ROWS) && (j < COLUMNS)) {
            reg = c[i + ld * j];
        }
    }
    template <Int i, Int j>
    INLINE static void store(SIMD_T reg, REAL_T *c, Int ld) {
        if constexpr ((i < ROWS) && (j < COLUMNS)) {
            SIMD_STORE(reg, c + i * simd_width<REAL_T> + ld * j);
        }
    }
    template <Int i, Int j, typename BTYPE>
    INLINE static void update(SIMD_T& reg, SIMD_T x, BTYPE y) {
        if constexpr ((i < ROWS) && (j < COLUMNS)) {
            reg = simd_nma(x, y, reg);
        }
    }
    template <Int i, Int j, typename BTYPE>
    INLINE static void scale(SIMD_T& reg, BTYPE y) {
        if constexpr ((i < ROWS) && (j < COLUMNS)) {
            reg *= y;
        }
    }
};
    
template <Int ROWS, Int COLUMNS, typename INIT, typename REAL_T>
INLINE void mm_kernel_small(Int left_col, REAL_T *aa, REAL_T *bb, REAL_T *c, Int left_ld, Int right_ld) {
    static_assert(ROWS <= 2 && COLUMNS <= 2);
    using UNFOLD_C = UNFOLD<INIT, REAL_T, ROWS, COLUMNS>;
    using UNFOLD_A = UNFOLD<INIT, REAL_T, ROWS, 2>;
    using UNFOLD_B = UNFOLD<INIT, REAL_T, 2, COLUMNS>;
    using SIMD_T = simd_t<REAL_T>;
    SIMD_T c00, c01, c10, c11, cc00, cc01, cc10, cc11;
    SIMD_T a0, a1, aa0, aa1, b0, b1, bb0, bb1;
    
    UNFOLD_C::template init<0, 0>(c00, c, right_ld);
    UNFOLD_C::template init<0, 1>(c01, c, right_ld);
    UNFOLD_C::template init<1, 0>(c10, c, right_ld);
    UNFOLD_C::template init<1, 1>(c11, c, right_ld);
    cc00 = 0;
    cc01 = 0;
    cc10 = 0;
    cc11 = 0;

    REAL_T *a = aa;
    REAL_T *b = bb, *b_end = b + left_col, *b_end_2 = b + (left_col & (~1));
    for (; b < b_end_2; a += left_ld * 2, b += 2) { // break register dependency
        UNFOLD_A::template load     <0, 0>(a0, a, left_ld);
        UNFOLD_A::template load     <1, 0>(a1, a, left_ld);
        UNFOLD_A::template load     <0, 1>(aa0, a, left_ld);
        UNFOLD_A::template load     <1, 1>(aa1, a, left_ld);
        UNFOLD_B::template load_copy<0, 0>(b0, b, right_ld);
        UNFOLD_B::template load_copy<1, 0>(bb0, b, right_ld);
        UNFOLD_C::template update   <0, 0>(c00, a0, b0);
        UNFOLD_C::template update   <1, 0>(c10, a1, b0);
        UNFOLD_C::template update   <0, 0>(cc00, aa0, bb0);
        UNFOLD_C::template update   <1, 0>(cc10, aa1, bb0);
        UNFOLD_B::template load_copy<0, 1>(b1, b, right_ld);
        UNFOLD_B::template load_copy<1, 1>(bb1, b, right_ld);
        UNFOLD_C::template update   <0, 1>(c01, a0, b1);
        UNFOLD_C::template update   <1, 1>(c11, a1, b1);
        UNFOLD_C::template update   <0, 1>(cc01, aa0, bb1);
        UNFOLD_C::template update   <1, 1>(cc11, aa1, bb1);
    }
    if (b < b_end) {
        UNFOLD_A::template load<0, 0>(a0, a, left_ld);
        UNFOLD_A::template load<1, 0>(a1, a, left_ld);
        UNFOLD_B::template load_copy<0, 0>(b0, b, right_ld);
        UNFOLD_C::template update<0, 0>(c00, a0, b0);
        UNFOLD_C::template update<1, 0>(c10, a1, b0);
        UNFOLD_B::template load_copy<0, 1>(b1, b, right_ld);
        UNFOLD_C::template update<0, 1>(c01, a0, b1);
        UNFOLD_C::template update<1, 1>(c11, a1, b1);
    }
    
    c00 += cc00;
    c10 += cc10;
    c01 += cc01;
    c11 += cc11;
    UNFOLD_C::template store<0, 0>(c00, c, right_ld);
    UNFOLD_C::template store<0, 1>(c01, c, right_ld);
    UNFOLD_C::template store<1, 0>(c10, c, right_ld);
    UNFOLD_C::template store<1, 1>(c11, c, right_ld);
}

template <Int ROWS, Int COLUMNS, typename INIT, typename REAL_T>
INLINE void mm_kernel(Int left_col, REAL_T *aa, REAL_T *bb, REAL_T *c, Int left_ld, Int right_ld) {
    static_assert(ROWS <= 2 && COLUMNS <= 8);
    using UNFOLD_T = UNFOLD<INIT, REAL_T, ROWS, COLUMNS>;
    using SIMD_T = simd_t<REAL_T>;
    SIMD_T c00, c01, c02, c03, c04, c05, c06, c07, c10, c11, c12, c13, c14, c15, c16, c17;
    SIMD_T a0, a1, b0, b1, b2, b3, b4, b5, b6, b7;
    
    UNFOLD_T::template init<0, 0>(c00, c, right_ld);
    UNFOLD_T::template init<0, 1>(c01, c, right_ld);
    UNFOLD_T::template init<0, 2>(c02, c, right_ld);
    UNFOLD_T::template init<0, 3>(c03, c, right_ld);
    UNFOLD_T::template init<0, 4>(c04, c, right_ld);
    UNFOLD_T::template init<0, 5>(c05, c, right_ld);
    UNFOLD_T::template init<0, 6>(c06, c, right_ld);
    UNFOLD_T::template init<0, 7>(c07, c, right_ld);
    UNFOLD_T::template init<1, 0>(c10, c, right_ld);
    UNFOLD_T::template init<1, 1>(c11, c, right_ld);
    UNFOLD_T::template init<1, 2>(c12, c, right_ld);
    UNFOLD_T::template init<1, 3>(c13, c, right_ld);
    UNFOLD_T::template init<1, 4>(c14, c, right_ld);
    UNFOLD_T::template init<1, 5>(c15, c, right_ld);
    UNFOLD_T::template init<1, 6>(c16, c, right_ld);
    UNFOLD_T::template init<1, 7>(c17, c, right_ld);

    REAL_T *a = aa;
    REAL_T *b = bb, *b_end = bb + left_col;
    for (; b < b_end; a += left_ld, b += 1) {
        UNFOLD_T::template load     <0, 0>(a0, a, left_ld);
        UNFOLD_T::template load     <1, 0>(a1, a, left_ld);
        UNFOLD_T::template load_copy<0, 0>(b0, b, right_ld);
        UNFOLD_T::template update   <0, 0>(c00, a0, b0);
        UNFOLD_T::template update   <1, 0>(c10, a1, b0);
        UNFOLD_T::template load_copy<0, 1>(b1, b, right_ld);
        UNFOLD_T::template update   <0, 1>(c01, a0, b1);
        UNFOLD_T::template update   <1, 1>(c11, a1, b1);
        UNFOLD_T::template load_copy<0, 2>(b2, b, right_ld);
        UNFOLD_T::template update   <0, 2>(c02, a0, b2);
        UNFOLD_T::template update   <1, 2>(c12, a1, b2);
        UNFOLD_T::template load_copy<0, 3>(b3, b, right_ld);
        UNFOLD_T::template update   <0, 3>(c03, a0, b3);
        UNFOLD_T::template update   <1, 3>(c13, a1, b3);
        UNFOLD_T::template load_copy<0, 4>(b4, b, right_ld);
        UNFOLD_T::template update   <0, 4>(c04, a0, b4);
        UNFOLD_T::template update   <1, 4>(c14, a1, b4);
        UNFOLD_T::template load_copy<0, 5>(b5, b, right_ld);
        UNFOLD_T::template update   <0, 5>(c05, a0, b5);
        UNFOLD_T::template update   <1, 5>(c15, a1, b5);
        UNFOLD_T::template load_copy<0, 6>(b6, b, right_ld);
        UNFOLD_T::template update   <0, 6>(c06, a0, b6);
        UNFOLD_T::template update   <1, 6>(c16, a1, b6);
        UNFOLD_T::template load_copy<0, 7>(b7, b, right_ld);
        UNFOLD_T::template update   <0, 7>(c07, a0, b7);
        UNFOLD_T::template update   <1, 7>(c17, a1, b7);
    }
    
    UNFOLD_T::template store<0, 0>(c00, c, right_ld);
    UNFOLD_T::template store<0, 1>(c01, c, right_ld);
    UNFOLD_T::template store<0, 2>(c02, c, right_ld);
    UNFOLD_T::template store<0, 3>(c03, c, right_ld);
    UNFOLD_T::template store<0, 4>(c04, c, right_ld);
    UNFOLD_T::template store<0, 5>(c05, c, right_ld);
    UNFOLD_T::template store<0, 6>(c06, c, right_ld);
    UNFOLD_T::template store<0, 7>(c07, c, right_ld);
    UNFOLD_T::template store<1, 0>(c10, c, right_ld);
    UNFOLD_T::template store<1, 1>(c11, c, right_ld);
    UNFOLD_T::template store<1, 2>(c12, c, right_ld);
    UNFOLD_T::template store<1, 3>(c13, c, right_ld);
    UNFOLD_T::template store<1, 4>(c14, c, right_ld);
    UNFOLD_T::template store<1, 5>(c15, c, right_ld);
    UNFOLD_T::template store<1, 6>(c16, c, right_ld);
    UNFOLD_T::template store<1, 7>(c17, c, right_ld);
}

template <typename INIT, typename REAL_T>
static void mm_real(Int left_col, Int right_col, Int nrow, REAL_T *left, REAL_T *right_up, REAL_T *right_down, Int left_ld, Int right_ld) { // ldc == lda
    using SIMD_T = simd_t<REAL_T>;
    const Int i_end = nrow - 8;
    REAL_T *c, *c_end, *aa, *bb = right_up, *cc = right_down;
    REAL_T *bb_end_3 = right_up + right_ld * (right_col & (~3));
    REAL_T *bb_end_1 = right_up + right_ld * (right_col & (~1));
    REAL_T *bb_end   = right_up + right_ld * right_col;
    for (; bb < bb_end_3; cc += right_ld * 4, bb += right_ld * 4) {
        c = cc;
        c_end = cc + i_end;
        aa = left;
        for (; c < c_end; c += 16, aa += 16) { // 16x4, may out of range, but doesn't exceed left_ld
            mm_kernel<2, 4, INIT, REAL_T>(left_col, aa, bb, c, left_ld, right_ld);
        }
    }
    if (bb < bb_end_1) {
        c = cc;
        c_end = cc + i_end;
        aa = left;
        for (; c < c_end; c += 16, aa += 16) { // 16x2, may out of range, but doesn't exceed left_ld
            mm_kernel<2, 2, INIT, REAL_T>(left_col, aa, bb, c, left_ld, right_ld);
        }
        cc += right_ld * 2;
        bb += right_ld * 2;
    }
    if (bb < bb_end) {
        c = cc;
        c_end = cc + i_end;
        aa = left;
        for (; c < c_end; c += 16, aa += 16) { // 16x1, may out of range, but doesn't exceed left_ld
            mm_kernel_small<2, 1, INIT, REAL_T>(left_col, aa, bb, c, left_ld, right_ld);
        }
    }
    if(((nrow - 1) & 8) == 0) {   // 0 < (nrow % 16) <= 8
        REAL_T *bb_end_7 = right_up + right_ld * (right_col & (~7));
        bb = right_up;
        c = right_down + (nrow & (~15));
        for (; bb < bb_end_7; c += right_ld * 8, bb += right_ld * 8) {
            mm_kernel<1, 8, INIT, REAL_T>(left_col, aa, bb, c, left_ld, right_ld);
        }
        if(bb < bb_end_3) {
            mm_kernel<1, 4, INIT, REAL_T>(left_col, aa, bb, c, left_ld, right_ld);
            c += right_ld * 4;
            bb += right_ld * 4;
        }
        if (bb < bb_end_1) {
            mm_kernel_small<1, 2, INIT, REAL_T>(left_col, aa, bb, c, left_ld, right_ld);
            c += right_ld * 2;
            bb += right_ld * 2;
        }
        if (bb < bb_end) {
            mm_kernel_small<1, 1, INIT, REAL_T>(left_col, aa, bb, c, left_ld, right_ld);
        }
    }
}

// solve 2~8 columns
template <typename REAL_T>
template <Int COLUMNS>
void BLAS<REAL_T>::l_trsm_kernel(Int left_col, Int nrow, Int i_end, REAL_T *left, REAL_T *right, Int left_ld, Int right_ld) const {
    using UNFOLD_T = UNFOLD<INIT_REAL<REAL_T>, REAL_T, 1, COLUMNS>;
    using SIMD_T = simd_t<REAL_T>;
    Int xrow = nrow - i_end, xcol = left_col - i_end;
    REAL_T *a, *b, *c = right, *c_end = right + i_end, *c_nrow = right + nrow;
    SIMD_T c0, c1, c2, c3, c4, c5, c6, c7, ar;
    for (; c < c_end; c += 8, left += 8) {  // full 8x8xc
        UNFOLD_T::template load<0, 0>(c0, c, right_ld);
        UNFOLD_T::template load<0, 1>(c1, c, right_ld);
        UNFOLD_T::template load<0, 2>(c2, c, right_ld);
        UNFOLD_T::template load<0, 3>(c3, c, right_ld);
        UNFOLD_T::template load<0, 4>(c4, c, right_ld);
        UNFOLD_T::template load<0, 5>(c5, c, right_ld);
        UNFOLD_T::template load<0, 6>(c6, c, right_ld);
        UNFOLD_T::template load<0, 7>(c7, c, right_ld);
        
        // substitute solved
        a = left;
        b = right;
        for (; b < c; a += left_ld, b += 1) {
            SIMD_LOAD(ar, a);
            UNFOLD_T::template update<0, 0>(c0, ar, b[0]);
            UNFOLD_T::template update<0, 1>(c1, ar, b[right_ld]);
            UNFOLD_T::template update<0, 2>(c2, ar, b[right_ld*2]);
            UNFOLD_T::template update<0, 3>(c3, ar, b[right_ld*3]);
            UNFOLD_T::template update<0, 4>(c4, ar, b[right_ld*4]);
            UNFOLD_T::template update<0, 5>(c5, ar, b[right_ld*5]);
            UNFOLD_T::template update<0, 6>(c6, ar, b[right_ld*6]);
            UNFOLD_T::template update<0, 7>(c7, ar, b[right_ld*7]);
        }

        if constexpr (COLUMNS > 4) {
            this->transposer.transpose_8x8(c0, c1, c2, c3, c4, c5, c6, c7);
        } else {
            if constexpr (COLUMNS > 2) { 
                this->transposer.transpose_8x4(c0, c1, c2, c3, c4, c5, c6, c7);
            } else {
                this->transposer.transpose_8x2(c0, c1, c2, c3, c4, c5, c6, c7);
            }
        }

        c1 = simd_nma(c0, a[1], c1);
        c2 = simd_nma(c0, a[2], c2);
        c3 = simd_nma(c0, a[3], c3);
        c4 = simd_nma(c0, a[4], c4);
        c5 = simd_nma(c0, a[5], c5);
        c6 = simd_nma(c0, a[6], c6);
        c7 = simd_nma(c0, a[7], c7);
        a += left_ld;
        c2 = simd_nma(c1, a[2], c2);
        c3 = simd_nma(c1, a[3], c3);
        c4 = simd_nma(c1, a[4], c4);
        c5 = simd_nma(c1, a[5], c5);
        c6 = simd_nma(c1, a[6], c6);
        c7 = simd_nma(c1, a[7], c7);
        a += left_ld;
        c3 = simd_nma(c2, a[3], c3);
        c4 = simd_nma(c2, a[4], c4);
        c5 = simd_nma(c2, a[5], c5);
        c6 = simd_nma(c2, a[6], c6);
        c7 = simd_nma(c2, a[7], c7);
        a += left_ld;
        c4 = simd_nma(c3, a[4], c4);
        c5 = simd_nma(c3, a[5], c5);
        c6 = simd_nma(c3, a[6], c6);
        c7 = simd_nma(c3, a[7], c7);
        a += left_ld;
        c5 = simd_nma(c4, a[5], c5);
        c6 = simd_nma(c4, a[6], c6);
        c7 = simd_nma(c4, a[7], c7);
        a += left_ld;
        c6 = simd_nma(c5, a[6], c6);
        c7 = simd_nma(c5, a[7], c7);
        a += left_ld;
        c7 = simd_nma(c6, a[7], c7);
        if constexpr (COLUMNS > 4) {
            this->transposer.transpose_8x8(c0, c1, c2, c3, c4, c5, c6, c7);
        } else {
            if constexpr (COLUMNS > 2) { 
                this->transposer.transpose_4x8(c0, c1, c2, c3, c4, c5, c6, c7);
            } else {
                this->transposer.transpose_2x8(c0, c1, c2, c3, c4, c5, c6, c7);
            }
        }
        UNFOLD_T::template store<0, 0>(c0, c, right_ld);
        UNFOLD_T::template store<0, 1>(c1, c, right_ld);
        UNFOLD_T::template store<0, 2>(c2, c, right_ld);
        UNFOLD_T::template store<0, 3>(c3, c, right_ld);
        UNFOLD_T::template store<0, 4>(c4, c, right_ld);
        UNFOLD_T::template store<0, 5>(c5, c, right_ld);
        UNFOLD_T::template store<0, 6>(c6, c, right_ld);
        UNFOLD_T::template store<0, 7>(c7, c, right_ld);
    }
    if(c < c_nrow) {    // mxnxc
        UNFOLD_T::template load<0, 0>(c0, c, right_ld);
        UNFOLD_T::template load<0, 1>(c1, c, right_ld);
        UNFOLD_T::template load<0, 2>(c2, c, right_ld);
        UNFOLD_T::template load<0, 3>(c3, c, right_ld);
        UNFOLD_T::template load<0, 4>(c4, c, right_ld);
        UNFOLD_T::template load<0, 5>(c5, c, right_ld);
        UNFOLD_T::template load<0, 6>(c6, c, right_ld);
        UNFOLD_T::template load<0, 7>(c7, c, right_ld);
        
        // substitute solved
        a = left;
        b = right;
        for (; b < c; a += left_ld, b += 1) {
            SIMD_LOAD(ar, a);
            UNFOLD_T::template update<0, 0>(c0, ar, b[0]);
            UNFOLD_T::template update<0, 1>(c1, ar, b[right_ld]);
            UNFOLD_T::template update<0, 2>(c2, ar, b[right_ld*2]);
            UNFOLD_T::template update<0, 3>(c3, ar, b[right_ld*3]);
            UNFOLD_T::template update<0, 4>(c4, ar, b[right_ld*4]);
            UNFOLD_T::template update<0, 5>(c5, ar, b[right_ld*5]);
            UNFOLD_T::template update<0, 6>(c6, ar, b[right_ld*6]);
            UNFOLD_T::template update<0, 7>(c7, ar, b[right_ld*7]);
        }

        if (xrow > 4) {  // may exceed nrow, but not exceed left_ld
            if constexpr (COLUMNS > 4) {
                this->transposer.transpose_8x8(c0, c1, c2, c3, c4, c5, c6, c7);
            } else {
                if constexpr (COLUMNS > 2) { 
                    this->transposer.transpose_8x4(c0, c1, c2, c3, c4, c5, c6, c7);
                } else {
                    this->transposer.transpose_8x2(c0, c1, c2, c3, c4, c5, c6, c7);
                }
            }

            c1 = simd_nma(c0, a[1], c1);
            c2 = simd_nma(c0, a[2], c2);
            c3 = simd_nma(c0, a[3], c3);
            c4 = simd_nma(c0, a[4], c4);
            c5 = simd_nma(c0, a[5], c5);
            c6 = simd_nma(c0, a[6], c6);
            c7 = simd_nma(c0, a[7], c7);
            if (xcol > 1) {
                a += left_ld;
                c2 = simd_nma(c1, a[2], c2);
                c3 = simd_nma(c1, a[3], c3);
                c4 = simd_nma(c1, a[4], c4);
                c5 = simd_nma(c1, a[5], c5);
                c6 = simd_nma(c1, a[6], c6);
                c7 = simd_nma(c1, a[7], c7);
                if (xcol > 2) {
                    a += left_ld;
                    c3 = simd_nma(c2, a[3], c3);
                    c4 = simd_nma(c2, a[4], c4);
                    c5 = simd_nma(c2, a[5], c5);
                    c6 = simd_nma(c2, a[6], c6);
                    c7 = simd_nma(c2, a[7], c7);
                    if (xcol > 3) {
                        a += left_ld;
                        c4 = simd_nma(c3, a[4], c4);
                        c5 = simd_nma(c3, a[5], c5);
                        c6 = simd_nma(c3, a[6], c6);
                        c7 = simd_nma(c3, a[7], c7);
                        if (xcol > 4) {
                            a += left_ld;
                            c5 = simd_nma(c4, a[5], c5);
                            c6 = simd_nma(c4, a[6], c6);
                            c7 = simd_nma(c4, a[7], c7);
                            if (xcol > 5) {
                                a += left_ld;
                                c6 = simd_nma(c5, a[6], c6);
                                c7 = simd_nma(c5, a[7], c7);
                                if (xcol > 6) {
                                    a += left_ld;
                                    c7 = simd_nma(c6, a[7], c7);
                                }
                            }
                        }
                    }
                }
            }

            if constexpr (COLUMNS > 4) {
                this->transposer.transpose_8x8(c0, c1, c2, c3, c4, c5, c6, c7);
            } else {
                if constexpr (COLUMNS > 2) { 
                    this->transposer.transpose_4x8(c0, c1, c2, c3, c4, c5, c6, c7);
                } else {
                    this->transposer.transpose_2x8(c0, c1, c2, c3, c4, c5, c6, c7);
                }
            }
        } else if (xrow > 2) {
            if constexpr (COLUMNS > 4) {
                this->transposer.transpose_4x8(c0, c1, c2, c3, c4, c5, c6, c7);
            } else {
                if constexpr (COLUMNS > 2) { 
                    this->transposer.transpose_4x4(c0, c1, c2, c3);
                } else {
                    this->transposer.transpose_4x2(c0, c1, c2, c3);
                }
            }

            c1 = simd_nma(c0, a[1], c1);
            c2 = simd_nma(c0, a[2], c2);
            c3 = simd_nma(c0, a[3], c3);
            if (xcol > 1) {
                a += left_ld;
                c2 = simd_nma(c1, a[2], c2);
                c3 = simd_nma(c1, a[3], c3);
                if (xcol > 2) {
                    a += left_ld;
                    c3 = simd_nma(c2, a[3], c3);
                }
            }

            if constexpr (COLUMNS > 4) {
                this->transposer.transpose_8x4(c0, c1, c2, c3, c4, c5, c6, c7);
            } else {
                if constexpr (COLUMNS > 2) { 
                    this->transposer.transpose_4x4(c0, c1, c2, c3);
                } else {
                    this->transposer.transpose_2x4(c0, c1, c2, c3);
                }
            }
        } else {
            if constexpr (COLUMNS > 4) {
                this->transposer.transpose_2x8(c0, c1, c2, c3, c4, c5, c6, c7);
            } else {
                if constexpr (COLUMNS > 2) { 
                    this->transposer.transpose_2x4(c0, c1, c2, c3);
                } else {
                    this->transposer.transpose_2x2(c0, c1);
                }
            }
            c1 = simd_nma(c0, a[1], c1);
            if constexpr (COLUMNS > 4) {
                this->transposer.transpose_8x2(c0, c1, c2, c3, c4, c5, c6, c7);
            } else {
                if constexpr (COLUMNS > 2) { 
                    this->transposer.transpose_4x2(c0, c1, c2, c3);
                } else {
                    this->transposer.transpose_2x2(c0, c1);
                }
            }
        }

        UNFOLD_T::template store<0, 0>(c0, c, right_ld);
        UNFOLD_T::template store<0, 1>(c1, c, right_ld);
        UNFOLD_T::template store<0, 2>(c2, c, right_ld);
        UNFOLD_T::template store<0, 3>(c3, c, right_ld);
        UNFOLD_T::template store<0, 4>(c4, c, right_ld);
        UNFOLD_T::template store<0, 5>(c5, c, right_ld);
        UNFOLD_T::template store<0, 6>(c6, c, right_ld);
        UNFOLD_T::template store<0, 7>(c7, c, right_ld);
    }
}

template <typename REAL_T>
INLINE void l_trsv_kernel(Int left_col, Int nrow, Int i_end, REAL_T *left, REAL_T *right, Int left_ld) {
    using SIMD_T = simd_t<REAL_T>;
    Int i;
    REAL_T *a, *b, *b_end, *b_end_1, *c = right;
    SIMD_T ct, cr, at, ar;
    // `i` is necessary to unroll the inner loop
    for (i = 0; i < i_end; i += 8, c += 8, left += 8) {  // full 8x8x1
        SIMD_LOAD(cr, c);
        ct = 0;  // break register dependency
        
        // substitute solved
        a = left;
        b = right;
        b_end_1 = right + (i & (~1));
        b_end   = right + i;
        for (; b < b_end_1; a += left_ld * 2, b += 2) {
            SIMD_LOAD(ar, a);
            SIMD_LOAD(at, a + left_ld);
            cr = simd_nma(ar, b[0], cr);
            ct = simd_nma(at, b[1], ct);
        }
        if (b < b_end) {
            SIMD_LOAD(ar, a);
            cr = simd_nma(ar, b[0], cr);
            a += left_ld;
        }
        cr += ct;
        REAL_T c0 = simd_extract0(cr);
        REAL_T c1 = simd_extract1(cr);
        REAL_T c2 = simd_extract2(cr);
        REAL_T c3 = simd_extract3(cr);
        REAL_T c4 = simd_extract4(cr);
        REAL_T c5 = simd_extract5(cr);
        REAL_T c6 = simd_extract6(cr);
        REAL_T c7 = simd_extract7(cr);
        c1 -= c0 * a[1];
        c2 -= c0 * a[2];
        c3 -= c0 * a[3];
        c4 -= c0 * a[4];
        c5 -= c0 * a[5];
        c6 -= c0 * a[6];
        c7 -= c0 * a[7];
        a += left_ld;
        c2 -= c1 * a[2];
        c3 -= c1 * a[3];
        c4 -= c1 * a[4];
        c5 -= c1 * a[5];
        c6 -= c1 * a[6];
        c7 -= c1 * a[7];
        a += left_ld;
        c3 -= c2 * a[3];
        c4 -= c2 * a[4];
        c5 -= c2 * a[5];
        c6 -= c2 * a[6];
        c7 -= c2 * a[7];
        a += left_ld;
        c4 -= c3 * a[4];
        c5 -= c3 * a[5];
        c6 -= c3 * a[6];
        c7 -= c3 * a[7];
        a += left_ld;
        c5 -= c4 * a[5];
        c6 -= c4 * a[6];
        c7 -= c4 * a[7];
        a += left_ld;
        c6 -= c5 * a[6];
        c7 -= c5 * a[7];
        a += left_ld;
        c7 -= c6 * a[7];
        c[0] = c0;
        c[1] = c1;
        c[2] = c2;
        c[3] = c3;
        c[4] = c4;
        c[5] = c5;
        c[6] = c6;
        c[7] = c7;
    }
    if(i < nrow) {    // mxnx1
        SIMD_LOAD(cr, c);
        ct = 0;
        
        // substitute solved
        a = left;
        b = right;
        b_end_1 = right + (i & (~1));
        b_end   = right + i;
        for (; b < b_end_1; a += left_ld * 2, b += 2) {
            SIMD_LOAD(ar, a);
            SIMD_LOAD(at, a + left_ld);
            cr = simd_nma(ar, b[0], cr);
            ct = simd_nma(at, b[1], ct);
        }
        if (b < b_end) {
            SIMD_LOAD(ar, a);
            cr = simd_nma(ar, b[0], cr);
            a += left_ld, b += 1;
        }
        cr += ct;
        if (nrow - i > 4) {
            REAL_T c0 = simd_extract0(cr);
            REAL_T c1 = simd_extract1(cr);
            REAL_T c2 = simd_extract2(cr);
            REAL_T c3 = simd_extract3(cr);
            REAL_T c4 = simd_extract4(cr);
            REAL_T c5 = simd_extract5(cr);
            REAL_T c6 = simd_extract6(cr);
            REAL_T c7 = simd_extract7(cr);
            c1 -= c0 * a[1];
            c2 -= c0 * a[2];
            c3 -= c0 * a[3];
            c4 -= c0 * a[4];
            c5 -= c0 * a[5];
            c6 -= c0 * a[6];
            c7 -= c0 * a[7];
            if (left_col - i > 1) {
                a += left_ld;
                c2 -= c1 * a[2];
                c3 -= c1 * a[3];
                c4 -= c1 * a[4];
                c5 -= c1 * a[5];
                c6 -= c1 * a[6];
                c7 -= c1 * a[7];
                if (left_col - i > 2) {
                    a += left_ld;
                    c3 -= c2 * a[3];
                    c4 -= c2 * a[4];
                    c5 -= c2 * a[5];
                    c6 -= c2 * a[6];
                    c7 -= c2 * a[7];
                    if (left_col - i > 3) {
                        a += left_ld;
                        c4 -= c3 * a[4];
                        c5 -= c3 * a[5];
                        c6 -= c3 * a[6];
                        c7 -= c3 * a[7];
                        if (left_col - i > 4) {
                            a += left_ld;
                            c5 -= c4 * a[5];
                            c6 -= c4 * a[6];
                            c7 -= c4 * a[7];
                            if (left_col - i > 5) {
                                a += left_ld;
                                c6 -= c5 * a[6];
                                c7 -= c5 * a[7];
                                if (left_col - i > 6) {
                                    a += left_ld;
                                    c7 -= c6 * a[7];
                                }
                            }
                        }
                    }
                }
            }
            c[0] = c0;
            c[1] = c1;
            c[2] = c2;
            c[3] = c3;
            c[4] = c4;
            c[5] = c5;
            c[6] = c6;
            c[7] = c7;
 
        } else if (nrow - i > 2) {
            REAL_T c0 = simd_extract0(cr);
            REAL_T c1 = simd_extract1(cr);
            REAL_T c2 = simd_extract2(cr);
            REAL_T c3 = simd_extract3(cr);
 
            c1 -= c0 * a[1];
            c2 -= c0 * a[2];
            c3 -= c0 * a[3];
            if (left_col - i > 1) {
                a += left_ld;
                c2 -= c1 * a[2];
                c3 -= c1 * a[3];
                if (left_col - i > 2) {
                    a += left_ld;
                    c3 -= c2 * a[3];
                }
            }
            c[0] = c0;
            c[1] = c1;
            c[2] = c2;
            c[3] = c3;
        } else {
            REAL_T c0 = simd_extract0(cr);
            REAL_T c1 = simd_extract1(cr);
            c1 -= c0 * a[1];
            c[0] = c0;
            c[1] = c1;
        }
    }
}

template <typename REAL_T>
void BLAS<REAL_T>::l_trsm_update_real(Int left_col, Int right_col, Int nrow, REAL_T *left, REAL_T *right, Int left_ld, Int right_ld) const {
    const Int j_end_7 = right_col & (~7), i_end = left_col & (~7);  
    // i_end is not nrow & (~7): left_col <= nrow
    // i_end shows the end of full blocks
    // even the last block has full rows, it doesn't necessarily has full columns
    Int j;
    REAL_T *bb = right;
    for (j = 0; j < j_end_7; j += 8, bb += right_ld * 8) {
        this->template l_trsm_kernel<8>(left_col, nrow, i_end, left, bb, left_ld, right_ld);
    }
    switch (right_col - j) {
    case 1:
        l_trsv_kernel(left_col, nrow, i_end, left, bb, left_ld);
        break;
    case 2:
        this->template l_trsm_kernel<2>(left_col, nrow, i_end, left, bb, left_ld, right_ld);
        break;
    case 3:
        this->template l_trsm_kernel<3>(left_col, nrow, i_end, left, bb, left_ld, right_ld);
        break;
    case 4:
        this->template l_trsm_kernel<4>(left_col, nrow, i_end, left, bb, left_ld, right_ld);
        break;
    case 5:
        this->template l_trsm_kernel<5>(left_col, nrow, i_end, left, bb, left_ld, right_ld);
        break;
    case 6:
        this->template l_trsm_kernel<6>(left_col, nrow, i_end, left, bb, left_ld, right_ld);
        break;
    case 7:
        this->template l_trsm_kernel<7>(left_col, nrow, i_end, left, bb, left_ld, right_ld);
        break;
    default:
        break;
    }
}

template<typename REAL_T>
INLINE void ud_trsm_kernel_11(REAL_T* aa, REAL_T* bb, REAL_T* c, Int right_ld) {
    using SIMD_T = simd_t<REAL_T>;
    SIMD_T c00, b0, a0, ct, at, bt;
    REAL_T *a, *b, *c1 = c - right_ld;

    SIMD_LOAD(c00, c);
    ct = 0;

    a = aa;
    b = bb;
    // substitude previous solution
    for(; b < c1; a += 2, b += right_ld * 2) {
        SIMD_LOAD(b0, b);
        SIMD_LOAD(bt, b + right_ld);
        c00 = simd_nma(b0, a[0], c00);
        ct  = simd_nma(bt, a[1], ct);
    }
    if(b < c) {
        SIMD_LOAD(b0, b);
        c00 = simd_nma(b0, a[0], c00);
        a += 1;
    }
    // solve
    c00 = (c00 + ct) * a[0];
    SIMD_STORE(c00, c);
}

// no more than 2x4
template<Int ROWS, Int COLUMNS, typename REAL_T>
INLINE void ud_trsm_kernel(REAL_T* aa, REAL_T* bb, REAL_T* c, Int right_ld) {
    using UNFOLD_T = UNFOLD<INIT_REAL<REAL_T>, REAL_T, ROWS, COLUMNS>;
    using SIMD_T = simd_t<REAL_T>;
    SIMD_T c00, c01, c02, c03, c10, c11, c12, c13, b0, b1, a0, a1, a2, a3;
    REAL_T *a, *b;

    UNFOLD_T::template load<0, 0>(c00, c, right_ld);
    UNFOLD_T::template load<0, 1>(c01, c, right_ld);
    UNFOLD_T::template load<0, 2>(c02, c, right_ld);
    UNFOLD_T::template load<0, 3>(c03, c, right_ld);
    UNFOLD_T::template load<1, 0>(c10, c, right_ld);
    UNFOLD_T::template load<1, 1>(c11, c, right_ld);
    UNFOLD_T::template load<1, 2>(c12, c, right_ld);
    UNFOLD_T::template load<1, 3>(c13, c, right_ld);

    a = aa;
    b = bb;
    // substitude previous solution
    for(; b < c; a += 1, b += right_ld) {
        UNFOLD_T::template load     <0, 0>(b0, b, right_ld);
        UNFOLD_T::template load     <1, 0>(b1, b, right_ld);
        UNFOLD_T::template load_copy<0, 0>(a0, a, right_ld);
        UNFOLD_T::template update   <0, 0>(c00, b0, a0);
        UNFOLD_T::template update   <1, 0>(c10, b1, a0);
        UNFOLD_T::template load_copy<0, 1>(a1, a, right_ld);
        UNFOLD_T::template update   <0, 1>(c01, b0, a1);
        UNFOLD_T::template update   <1, 1>(c11, b1, a1);
        UNFOLD_T::template load_copy<0, 2>(a2, a, right_ld);
        UNFOLD_T::template update   <0, 2>(c02, b0, a2);
        UNFOLD_T::template update   <1, 2>(c12, b1, a2);
        UNFOLD_T::template load_copy<0, 3>(a3, a, right_ld);
        UNFOLD_T::template update   <0, 3>(c03, b0, a3);
        UNFOLD_T::template update   <1, 3>(c13, b1, a3);
    }
    // solve
    a0 = a[0];
    UNFOLD_T::template scale<0, 0>(c00, a0);
    UNFOLD_T::template scale<1, 0>(c10, a0);
    if constexpr (COLUMNS >= 2) {
        a += right_ld;
        a0 = a[0];
        UNFOLD_T::template update<0, 1>(c01, a0, c00);
        UNFOLD_T::template update<1, 1>(c11, a0, c10);
        a1 = a[1];
        UNFOLD_T::template scale<0, 1>(c01, a1);
        UNFOLD_T::template scale<1, 1>(c11, a1);
        if constexpr (COLUMNS >= 3) {
            a += right_ld;
            a0 = a[0];
            UNFOLD_T::template update<0, 2>(c02, a0, c00);
            UNFOLD_T::template update<1, 2>(c12, a0, c10);
            a1 = a[1];
            UNFOLD_T::template update<0, 2>(c02, a1, c01);
            UNFOLD_T::template update<1, 2>(c12, a1, c11);
            a2 = a[2];
            UNFOLD_T::template scale<0, 2>(c02, a2);
            UNFOLD_T::template scale<1, 2>(c12, a2);
            if constexpr (COLUMNS >= 4) {
                a += right_ld;
                a0 = a[0];
                UNFOLD_T::template update<0, 3>(c03, a0, c00);
                UNFOLD_T::template update<1, 3>(c13, a0, c10);
                a1 = a[1];
                UNFOLD_T::template update<0, 3>(c03, a1, c01);
                UNFOLD_T::template update<1, 3>(c13, a1, c11);
                a2 = a[2];
                UNFOLD_T::template update<0, 3>(c03, a2, c02);
                UNFOLD_T::template update<1, 3>(c13, a2, c12);
                a3 = a[3];
                UNFOLD_T::template scale<0, 3>(c03, a3);
                UNFOLD_T::template scale<1, 3>(c13, a3);
            }
        }
    }
    
    UNFOLD_T::template store<0, 0>(c00, c, right_ld);
    UNFOLD_T::template store<0, 1>(c01, c, right_ld);
    UNFOLD_T::template store<0, 2>(c02, c, right_ld);
    UNFOLD_T::template store<0, 3>(c03, c, right_ld);
    UNFOLD_T::template store<1, 0>(c10, c, right_ld);
    UNFOLD_T::template store<1, 1>(c11, c, right_ld);
    UNFOLD_T::template store<1, 2>(c12, c, right_ld);
    UNFOLD_T::template store<1, 3>(c13, c, right_ld);
}

template<typename REAL_T>
static void ud_trsm_real(Int ncol, Int nrow, REAL_T* right_up, REAL_T* right_down, Int right_ld) {
    using SIMD_T = simd_t<REAL_T>;
    REAL_T *c, *aa, *bb = right_down, *bb_end = bb + (nrow - 8);
    REAL_T *aa_end_3 = right_up + right_ld * (ncol & (~3));
    REAL_T *aa_end_1 = right_up + right_ld * (ncol & (~1));
    REAL_T *aa_end   = right_up + right_ld * ncol;
    for(; bb < bb_end; bb += 16) {
        c = bb;
        aa = right_up;
        for(; aa < aa_end_3; c += right_ld * 4, aa += right_ld * 4) {  // 4 x 4 x 16
            ud_trsm_kernel<2, 4>(aa, bb, c, right_ld);
        }
        if(aa < aa_end_1) {  // 2 x 2 x 16
            ud_trsm_kernel<2, 2>(aa, bb, c, right_ld);
            c += right_ld * 2;
            aa += right_ld * 2;
        }
        if(aa < aa_end) {
            ud_trsm_kernel<2, 1>(aa, bb, c, right_ld);
        }
    }
    if(((nrow - 1) & 8) == 0) {   // 0 < (nrow % 16) <= 8
        c = bb;
        aa = right_up;
        for(; aa < aa_end_3; c += right_ld * 4, aa += right_ld * 4) {  // 4 x 4 x 8
            ud_trsm_kernel<1, 4>(aa, bb, c, right_ld);
        }
        if(aa < aa_end_1) {     // 2 x 2 x 8
            ud_trsm_kernel<1, 2>(aa, bb, c, right_ld);
            c += right_ld * 2;
            aa += right_ld * 2;
        }
        if(aa < aa_end) {
            ud_trsm_kernel_11(aa, bb, c, right_ld);
        }
    }
}

template <typename REAL_T>
void BLAS<REAL_T>::l_trsm_8x8_real(Int right_col, REAL_T* left, REAL_T* right, Int right_ld) const {
    using SIMD_T = simd_t<REAL_T>;
    const Int left_ld = right_ld;
    Int q = right_col & (~7), r = right_col & 7;
    Int right_col_8 = (r > 4) ? (q + 8) : q;
    REAL_T *a, *u;
    REAL_T *u_end_8 = right + right_col_8 * right_ld;
    for(u = right; u < u_end_8; u += 8 * right_ld) {
        SIMD_T u0, u1, u2, u3, u4, u5, u6, u7;
        SIMD_LOAD(u0, u);
        SIMD_LOAD(u1, u + right_ld);
        SIMD_LOAD(u2, u + right_ld * 2);
        SIMD_LOAD(u3, u + right_ld * 3);
        SIMD_LOAD(u4, u + right_ld * 4);
        SIMD_LOAD(u5, u + right_ld * 5);
        SIMD_LOAD(u6, u + right_ld * 6);
        SIMD_LOAD(u7, u + right_ld * 7);
        a = left;
        this->transposer.transpose_8x8(u0, u1, u2, u3, u4, u5, u6, u7);
        u1 = simd_nma(u0, a[1], u1);
        u2 = simd_nma(u0, a[2], u2);
        u3 = simd_nma(u0, a[3], u3);
        u4 = simd_nma(u0, a[4], u4);
        u5 = simd_nma(u0, a[5], u5);
        u6 = simd_nma(u0, a[6], u6);
        u7 = simd_nma(u0, a[7], u7);
        a += left_ld;
        u2 = simd_nma(u1, a[2], u2);
        u3 = simd_nma(u1, a[3], u3);
        u4 = simd_nma(u1, a[4], u4);
        u5 = simd_nma(u1, a[5], u5);
        u6 = simd_nma(u1, a[6], u6);
        u7 = simd_nma(u1, a[7], u7);
        a += left_ld;
        u3 = simd_nma(u2, a[3], u3);
        u4 = simd_nma(u2, a[4], u4);
        u5 = simd_nma(u2, a[5], u5);
        u6 = simd_nma(u2, a[6], u6);
        u7 = simd_nma(u2, a[7], u7);
        a += left_ld;
        u4 = simd_nma(u3, a[4], u4);
        u5 = simd_nma(u3, a[5], u5);
        u6 = simd_nma(u3, a[6], u6);
        u7 = simd_nma(u3, a[7], u7);
        a += left_ld;
        u5 = simd_nma(u4, a[5], u5);
        u6 = simd_nma(u4, a[6], u6);
        u7 = simd_nma(u4, a[7], u7);
        a += left_ld;
        u6 = simd_nma(u5, a[6], u6);
        u7 = simd_nma(u5, a[7], u7);
        a += left_ld;
        u7 = simd_nma(u6, a[7], u7);
        this->transposer.transpose_8x8(u0, u1, u2, u3, u4, u5, u6, u7);
        SIMD_STORE(u0, u);
        SIMD_STORE(u1, u + right_ld);
        SIMD_STORE(u2, u + right_ld * 2);
        SIMD_STORE(u3, u + right_ld * 3);
        SIMD_STORE(u4, u + right_ld * 4);
        SIMD_STORE(u5, u + right_ld * 5);
        SIMD_STORE(u6, u + right_ld * 6);
        SIMD_STORE(u7, u + right_ld * 7);
    }
    switch (r) {
        case 1: {
            REAL_T c0 = u[0], c1 = u[1], c2 = u[2], c3 = u[3];
            REAL_T c4 = u[4], c5 = u[5], c6 = u[6], c7 = u[7];
            a = left;
            c1 -= c0 * a[1];
            c2 -= c0 * a[2];
            c3 -= c0 * a[3];
            c4 -= c0 * a[4];
            c5 -= c0 * a[5];
            c6 -= c0 * a[6];
            c7 -= c0 * a[7];
            a += left_ld;
            c2 -= c1 * a[2];
            c3 -= c1 * a[3];
            c4 -= c1 * a[4];
            c5 -= c1 * a[5];
            c6 -= c1 * a[6];
            c7 -= c1 * a[7];
            a += left_ld;
            c3 -= c2 * a[3];
            c4 -= c2 * a[4];
            c5 -= c2 * a[5];
            c6 -= c2 * a[6];
            c7 -= c2 * a[7];
            a += left_ld;
            c4 -= c3 * a[4];
            c5 -= c3 * a[5];
            c6 -= c3 * a[6];
            c7 -= c3 * a[7];
            a += left_ld;
            c5 -= c4 * a[5];
            c6 -= c4 * a[6];
            c7 -= c4 * a[7];
            a += left_ld;
            c6 -= c5 * a[6];
            c7 -= c5 * a[7];
            a += left_ld;
            c7 -= c6 * a[7];
            u[0] = c0;
            u[1] = c1;
            u[2] = c2;
            u[3] = c3;
            u[4] = c4;
            u[5] = c5;
            u[6] = c6;
            u[7] = c7;
            break;
        }
        case 2: {
            SIMD_T u0, u1, u2, u3, u4, u5, u6, u7;
            SIMD_LOAD(u0, u);
            SIMD_LOAD(u1, u + right_ld);
            a = left;
            this->transposer.transpose_8x2(u0, u1, u2, u3, u4, u5, u6, u7);
            u1 = simd_nma(u0, a[1], u1);
            u2 = simd_nma(u0, a[2], u2);
            u3 = simd_nma(u0, a[3], u3);
            u4 = simd_nma(u0, a[4], u4);
            u5 = simd_nma(u0, a[5], u5);
            u6 = simd_nma(u0, a[6], u6);
            u7 = simd_nma(u0, a[7], u7);
            a += left_ld;
            u2 = simd_nma(u1, a[2], u2);
            u3 = simd_nma(u1, a[3], u3);
            u4 = simd_nma(u1, a[4], u4);
            u5 = simd_nma(u1, a[5], u5);
            u6 = simd_nma(u1, a[6], u6);
            u7 = simd_nma(u1, a[7], u7);
            a += left_ld;
            u3 = simd_nma(u2, a[3], u3);
            u4 = simd_nma(u2, a[4], u4);
            u5 = simd_nma(u2, a[5], u5);
            u6 = simd_nma(u2, a[6], u6);
            u7 = simd_nma(u2, a[7], u7);
            a += left_ld;
            u4 = simd_nma(u3, a[4], u4);
            u5 = simd_nma(u3, a[5], u5);
            u6 = simd_nma(u3, a[6], u6);
            u7 = simd_nma(u3, a[7], u7);
            a += left_ld;
            u5 = simd_nma(u4, a[5], u5);
            u6 = simd_nma(u4, a[6], u6);
            u7 = simd_nma(u4, a[7], u7);
            a += left_ld;
            u6 = simd_nma(u5, a[6], u6);
            u7 = simd_nma(u5, a[7], u7);
            a += left_ld;
            u7 = simd_nma(u6, a[7], u7);
            this->transposer.transpose_2x8(u0, u1, u2, u3, u4, u5, u6, u7);
            SIMD_STORE(u0, u);
            SIMD_STORE(u1, u + right_ld);
            break;
        }
        case 3:
        case 4: {
            SIMD_T u0, u1, u2, u3, u4, u5, u6, u7;
            SIMD_LOAD(u0, u);
            SIMD_LOAD(u1, u + right_ld);
            SIMD_LOAD(u2, u + right_ld * 2);
            SIMD_LOAD(u3, u + right_ld * 3);
            a = left;
            this->transposer.transpose_8x4(u0, u1, u2, u3, u4, u5, u6, u7);
            u1 = simd_nma(u0, a[1], u1);
            u2 = simd_nma(u0, a[2], u2);
            u3 = simd_nma(u0, a[3], u3);
            u4 = simd_nma(u0, a[4], u4);
            u5 = simd_nma(u0, a[5], u5);
            u6 = simd_nma(u0, a[6], u6);
            u7 = simd_nma(u0, a[7], u7);
            a += left_ld;
            u2 = simd_nma(u1, a[2], u2);
            u3 = simd_nma(u1, a[3], u3);
            u4 = simd_nma(u1, a[4], u4);
            u5 = simd_nma(u1, a[5], u5);
            u6 = simd_nma(u1, a[6], u6);
            u7 = simd_nma(u1, a[7], u7);
            a += left_ld;
            u3 = simd_nma(u2, a[3], u3);
            u4 = simd_nma(u2, a[4], u4);
            u5 = simd_nma(u2, a[5], u5);
            u6 = simd_nma(u2, a[6], u6);
            u7 = simd_nma(u2, a[7], u7);
            a += left_ld;
            u4 = simd_nma(u3, a[4], u4);
            u5 = simd_nma(u3, a[5], u5);
            u6 = simd_nma(u3, a[6], u6);
            u7 = simd_nma(u3, a[7], u7);
            a += left_ld;
            u5 = simd_nma(u4, a[5], u5);
            u6 = simd_nma(u4, a[6], u6);
            u7 = simd_nma(u4, a[7], u7);
            a += left_ld;
            u6 = simd_nma(u5, a[6], u6);
            u7 = simd_nma(u5, a[7], u7);
            a += left_ld;
            u7 = simd_nma(u6, a[7], u7);
            this->transposer.transpose_4x8(u0, u1, u2, u3, u4, u5, u6, u7);
            SIMD_STORE(u0, u);
            SIMD_STORE(u1, u + right_ld);
            SIMD_STORE(u2, u + right_ld * 2);
            SIMD_STORE(u3, u + right_ld * 3);
            break;
        } 
    }
}

template<typename REAL_T>
static void rank8_update_real(Int ncol, Int nrow, REAL_T* left, REAL_T* right_up, REAL_T* right_down, Int right_ld) {
    using SIMD_T = simd_t<REAL_T>;
    const Int left_ld = right_ld;
    REAL_T *s, *u, *l = left, *l_end = left + nrow;
    REAL_T *uu = right_up, *ss = right_down;
    REAL_T *u_end_3 = uu + (ncol & (~3)) * right_ld, *u_end_1 = uu + (ncol & (~1)) * right_ld, *u_end = uu + ncol * right_ld;
    for(; l < l_end; ss += 8, l += 8) {
        SIMD_T l0, l1, l2, l3, l4, l5, l6, l7;
        SIMD_LOAD(l0, l);
        SIMD_LOAD(l1, l + left_ld);
        SIMD_LOAD(l2, l + left_ld * 2);
        SIMD_LOAD(l3, l + left_ld * 3);
        SIMD_LOAD(l4, l + left_ld * 4);
        SIMD_LOAD(l5, l + left_ld * 5);
        SIMD_LOAD(l6, l + left_ld * 6);
        SIMD_LOAD(l7, l + left_ld * 7);

        s = ss;
        u = uu;
        for(; u < u_end_3; s += right_ld * 4, u += right_ld * 4) {
            REAL_T *u1 = u + right_ld, *u2 = u + right_ld * 2, *u3 = u + right_ld * 3;
            SIMD_T s0, s1, s2, s3;
            SIMD_LOAD(s0, s);
            SIMD_LOAD(s1, s + right_ld);
            SIMD_LOAD(s2, s + right_ld * 2);
            SIMD_LOAD(s3, s + right_ld * 3);

            s0 = simd_nma(l0, u [0], s0);
            s1 = simd_nma(l0, u1[0], s1);
            s2 = simd_nma(l0, u2[0], s2);
            s3 = simd_nma(l0, u3[0], s3);
            s0 = simd_nma(l1, u [1], s0);
            s1 = simd_nma(l1, u1[1], s1);
            s2 = simd_nma(l1, u2[1], s2);
            s3 = simd_nma(l1, u3[1], s3);
            s0 = simd_nma(l2, u [2], s0);
            s1 = simd_nma(l2, u1[2], s1);
            s2 = simd_nma(l2, u2[2], s2);
            s3 = simd_nma(l2, u3[2], s3);
            s0 = simd_nma(l3, u [3], s0);
            s1 = simd_nma(l3, u1[3], s1);
            s2 = simd_nma(l3, u2[3], s2);
            s3 = simd_nma(l3, u3[3], s3);
            s0 = simd_nma(l4, u [4], s0);
            s1 = simd_nma(l4, u1[4], s1);
            s2 = simd_nma(l4, u2[4], s2);
            s3 = simd_nma(l4, u3[4], s3);
            s0 = simd_nma(l5, u [5], s0);
            s1 = simd_nma(l5, u1[5], s1);
            s2 = simd_nma(l5, u2[5], s2);
            s3 = simd_nma(l5, u3[5], s3);
            s0 = simd_nma(l6, u [6], s0);
            s1 = simd_nma(l6, u1[6], s1);
            s2 = simd_nma(l6, u2[6], s2);
            s3 = simd_nma(l6, u3[6], s3);
            s0 = simd_nma(l7, u [7], s0);
            s1 = simd_nma(l7, u1[7], s1);
            s2 = simd_nma(l7, u2[7], s2);
            s3 = simd_nma(l7, u3[7], s3);

            SIMD_STORE(s0, s);
            SIMD_STORE(s1, s + right_ld);
            SIMD_STORE(s2, s + right_ld * 2);
            SIMD_STORE(s3, s + right_ld * 3);
        }
        if(u < u_end_1) {
            REAL_T *u1 = u + right_ld;
            SIMD_T s0, s1;
            SIMD_LOAD(s0, s);
            SIMD_LOAD(s1, s + right_ld);

            s0 = simd_nma(l0, u [0], s0);
            s1 = simd_nma(l0, u1[0], s1);
            s0 = simd_nma(l1, u [1], s0);
            s1 = simd_nma(l1, u1[1], s1);
            s0 = simd_nma(l2, u [2], s0);
            s1 = simd_nma(l2, u1[2], s1);
            s0 = simd_nma(l3, u [3], s0);
            s1 = simd_nma(l3, u1[3], s1);
            s0 = simd_nma(l4, u [4], s0);
            s1 = simd_nma(l4, u1[4], s1);
            s0 = simd_nma(l5, u [5], s0);
            s1 = simd_nma(l5, u1[5], s1);
            s0 = simd_nma(l6, u [6], s0);
            s1 = simd_nma(l6, u1[6], s1);
            s0 = simd_nma(l7, u [7], s0);
            s1 = simd_nma(l7, u1[7], s1);

            SIMD_STORE(s0, s);
            SIMD_STORE(s1, s + right_ld);
            s += right_ld * 2, u += right_ld * 2;
        }
        if(u < u_end) {
            SIMD_T s0, st = 0;   // break register dependency
            SIMD_LOAD(s0, s);

            s0 = simd_nma(l0, u [0], s0);
            st = simd_nma(l1, u [1], st);
            s0 = simd_nma(l2, u [2], s0);
            st = simd_nma(l3, u [3], st);
            s0 = simd_nma(l4, u [4], s0);
            st = simd_nma(l5, u [5], st);
            s0 = simd_nma(l6, u [6], s0);
            st = simd_nma(l7, u [7], st);
            s0 += st;
            SIMD_STORE(s0, s);
        }
    }
}

template <typename REAL_T>
void BLAS<REAL_T>::mm_update(Int left_col, Int right_col, Int nrow, REAL_T* left, REAL_T* right_up, REAL_T* right_down) const {
    mm_real<INIT_REAL<REAL_T>>(left_col, right_col, nrow, left, right_up, right_down, update_left_ld, update_right_ld);
}
template <typename REAL_T>
void BLAS<REAL_T>::mm_update_fact(Int left_col, Int right_col, Int nrow, REAL_T* left, REAL_T* right_up, REAL_T* right_down) const {
    mm_real<INIT_REAL<REAL_T>>(left_col, right_col, nrow, left, right_up, right_down, fact_left_ld, fact_right_ld);
}
template <typename REAL_T>
void BLAS<REAL_T>::mm_negative(Int left_col, Int right_col, Int nrow, REAL_T* left, REAL_T* right_up, REAL_T* right_down) const {
    mm_real<INIT_ZERO<REAL_T>>(left_col, right_col, nrow, left, right_up, right_down, update_left_ld, update_right_ld);
}
template <typename REAL_T>
void BLAS<REAL_T>::l_trsm_update(Int left_col, Int right_col, Int nrow, REAL_T* left, REAL_T* right) const {
    this->l_trsm_update_real(left_col, right_col, nrow, left, right, update_left_ld, update_right_ld);
}
template <typename REAL_T>
void BLAS<REAL_T>::l_trsm_update_fact(Int left_col, Int right_col, REAL_T* left, REAL_T* right) const {
    this->l_trsm_update_real(left_col, right_col, left_col, left, right, fact_left_ld, fact_right_ld);
}
template <typename REAL_T>
void BLAS<REAL_T>::l_trsm_8x8(Int right_col, REAL_T* left, REAL_T* right) const {
    this->l_trsm_8x8_real(right_col, left, right, fact_right_ld);
}
template <typename REAL_T>
void BLAS<REAL_T>::ud_trsm(Int ncol, Int nrow, REAL_T* right_up, REAL_T* right_down) const {
    ud_trsm_real(ncol, nrow, right_up, right_down, fact_right_ld);
}
template <typename REAL_T>
void BLAS<REAL_T>::rank8_update(Int right_col, Int nrow, REAL_T* left, REAL_T* right_up, REAL_T* right_down) const {
    rank8_update_real(right_col, nrow, left, right_up, right_down, fact_right_ld);
}

#define INSTANTIATE_TEMPLATE(type) \
template void BLAS<type>::mm_update(Int, Int, Int, type*, type*, type*) const; \
template void BLAS<type>::mm_negative(Int, Int, Int, type*, type*, type*) const; \
template void BLAS<type>::l_trsm_update(Int, Int, Int, type*, type*) const; \
template void BLAS<type>::l_trsm_update_fact(Int, Int, type*, type*) const; \
template void BLAS<type>::l_trsm_8x8(Int, type*, type*) const; \
template void BLAS<type>::ud_trsm(Int, Int, type*, type*) const; \
template void BLAS<type>::mm_update_fact(Int, Int, Int, type*, type*, type*) const; \
template void BLAS<type>::rank8_update(Int, Int, type*, type*, type*) const;

INSTANTIATE_TEMPLATE(float)
INSTANTIATE_TEMPLATE(double)

} // namespace swSparse