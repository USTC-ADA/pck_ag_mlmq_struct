#include <limits>
#include <crts.h>
#include "swSparse_blas.h"
#include "internal/rename.h"
#include "internal/spblas_common.h"
#include "internal/CPE.h"
#include "internal/CPE_blas_kernels.h"
#include "internal/spgemm_param.h"
#include "internal/spgemm_sort.h"
#include "internal/algorithm.h"

//#define PROFILE_SPGEMM_MULTICG
#define L1_HASH_UNROLL 2

namespace swSparse {
    
template<typename DATA_T>
inline constexpr const int L1_hash_max_2 = static_cast<int>(L1_hash_size<DATA_T> * 0.8);
template<typename DATA_T>
inline constexpr const int L1_hash_max_3 = static_cast<int>(L1_hash_size<DATA_T> * 0.85);
template<typename DATA_T>
inline constexpr const int L1_hash_max_4 = static_cast<int>(L1_hash_size<DATA_T> * 0.9);

using namespace spgemm;

struct Z : cpe_state_t {
    int64_t total_flops;
#ifdef PROFILE_SPGEMM_MULTICG
    int64_t L1hashconf = 0, L2hashconf = 0;
#define HASHCONF_(x_) , l_state.L1hashconf += x_
#define HASHCONF(x_) l_state.L1hashconf += x_
#else
#define HASHCONF_(x_)
#define HASHCONF(x_)
#endif
    Z() : total_flops(0) {
        this->L1_nnz = this->L2_nnz = this->L2_end = this->total_nnz = this->chunk_offset = 0;
    }
    void finish_row(Int f, Int nnz) {
        this->total_flops += f;
        this->total_nnz += nnz;
    }
    template<typename DATA_T>
    Int L1_max(Int row_flops) const {
        if(UNLIKELY(this->total_flops == 0)) {
            return L1_hash_max_3<DATA_T>;  // optimistic at the first time
        }
        Int estimate = (int64_t)row_flops * this->total_nnz / this->total_flops;
        if(estimate < L1_hash_size<DATA_T>) {
            return L1_hash_max_4<DATA_T>;
        } else if(estimate < L1_hash_size<DATA_T> * 2) {
            return L1_hash_max_2<DATA_T>;
        } else {
            return L1_hash_max_1<DATA_T>;
        }
    }
    bool is_finished() const {
        return ((this->end_row ^ this->current_row) | this->L2_nnz | this->L1_nnz ) == 0;
    }
    void not_finish(Int row, Int L1nnz, Int L2nnz, Int L2b, Int L2e) {
        this->L1_nnz   = L1nnz;
        this->L2_nnz   = L2nnz;
        this->L2_begin = L2b;
        this->L2_end   = L2e;
        this->current_row = row;
    }
    void finish() {
        this->current_row = this->end_row;
        this->L1_nnz = this->L2_nnz = 0;
    }
};
using CPEState = Z;

Int partition_spgemm_flops_multicg(Int m, Int n, Int pncpe, Int cncpe, Int cgid, const Int *a_row_off, const Int *a_col_idx, \
    const Int* b_row_off, const Int* d_row_off, Int *c_nf, ex_buffer_t* buffer, cpe_state_t& s REQUIRE_ANNZ(annz));
template<typename DATA_T>
void spgemm_postprocess_multicg(postprocess_t<DATA_T>& args, result_t& result, Int* c_offset, Int b_row, Int e_row);
template<typename ConjA, typename ConjB, bool HasD, typename DATA_T>
static void spgemm_hash_iter(const compute_t<DATA_T>& args, const hash_buffer_t<DATA_T>& buffer, CPEState& l_state);

template<typename DATA_T, typename ... ANY>
INLINE void spgemm_hash_iter_call(const compute_t<DATA_T>& args, \
    const hash_buffer_t<DATA_T>& buffer, CPEState& l_state, ANY && ...) {
    using noconj = not_conjugate<DATA_T>;
    if(args.d_row_off == nullptr) {
        spgemm_hash_iter<noconj, noconj, false>(args, buffer, l_state);
    } else {
        spgemm_hash_iter<noconj, noconj, true>(args, buffer, l_state);
    }
}

template<typename DATA_T>
INLINE void spgemm_hash_iter_call(const compute_t<complex<DATA_T>>& args, \
    const hash_buffer_t<complex<DATA_T>>& buffer, CPEState& l_state, Bool a_conj, Bool b_conj) {
    using conj = conjugate<DATA_T>;
    using noconj = not_conjugate<DATA_T>;
    if(a_conj) {
        if(b_conj) {
            if(args.d_row_off == nullptr) {
                spgemm_hash_iter<conj, conj, false>(args, buffer, l_state);
            } else {
                spgemm_hash_iter<conj, conj, true>(args, buffer, l_state);
            }
        } else {
            if(args.d_row_off == nullptr) {
                spgemm_hash_iter<conj, noconj, false>(args, buffer, l_state);
            } else {
                spgemm_hash_iter<conj, noconj, true>(args, buffer, l_state);
            }
        }
    } else {
        if(b_conj) {
            if(args.d_row_off == nullptr) {
                spgemm_hash_iter<noconj, conj, false>(args, buffer, l_state);
            } else {
                spgemm_hash_iter<noconj, conj, true>(args, buffer, l_state);
            }
        } else {
            if(args.d_row_off == nullptr) {
                spgemm_hash_iter<noconj, noconj, false>(args, buffer, l_state);
            } else {
                spgemm_hash_iter<noconj, noconj, true>(args, buffer, l_state);
            }
        }
    }
}

template<typename DATA_T>
NOINLINE static void spgemm_hash_copy_remain(const hash_buffer_t<DATA_T>& buffer, CPEState& state) {
    /* unpack arguments */
    Int L1_nnz = state.L1_nnz,     L2_nnz = state.L2_nnz;
    Int L2_begin = state.L2_begin, L2_end = state.L2_end;
    Int *L1_dump_idx = buffer.L1_dump_idx;
    DATA_T *L1_dump_val = buffer.L1_dump_val;
    Int *RSTR L2_idx = buffer.L2_idx;
    DATA_T *RSTR L2_val = buffer.L2_val;
    Int *chunk_idx = buffer.chunk_idx;
    DATA_T *chunk_val = buffer.chunk_val;
    
    Int output_idx_buffer[copy_tile<DATA_T>];
    DATA_T output_val_buffer[copy_tile<DATA_T>];
    Int i, j, k, len = 0, n_remain = L1_nnz + L2_nnz, n_copy = min(chunk_size<DATA_T>, n_remain);
    DMA_DECL_DESC(READ_WRITE);

    for(i = 0; i < L1_nnz; i += len) {
        len = min(copy_tile<DATA_T>, L1_nnz - i);
        DMA_IREAD(L1_dump_idx + i, output_idx_buffer, len * sizeof(Int));
        DMA_SREAD(L1_dump_val + i, output_val_buffer, len * sizeof(DATA_T));
        DMA_IWRITE(chunk_idx + i, output_idx_buffer, len * sizeof(Int));
        DMA_SWRITE(chunk_val + i, output_val_buffer, len * sizeof(DATA_T));
    }
    DMA_WAIT_ALL;

    k = 0;
    len = min(copy_tile<DATA_T>, chunk_size<DATA_T> - i); // len > k
    for(j = L2_begin; j < L2_end; ++j) {
        Int load_idx = L2_idx[j];
        if(load_idx >= 0) {
            output_idx_buffer[k] = load_idx;
            output_val_buffer[k] = L2_val[j];
            L2_idx[j] = empty;
            if(UNLIKELY((++k) == len)) {
                DMA_IWRITE(chunk_idx + i, output_idx_buffer, len * sizeof(Int));
                DMA_WRITE(chunk_val + i, output_val_buffer, len * sizeof(DATA_T));
                k = 0;
                i += len;
                len = min(copy_tile<DATA_T>, chunk_size<DATA_T> - i);
                if(len == 0) { // chunk full
                    break;
                }
            }
        }
    }
    if(k > 0) {
        DMA_IWRITE(chunk_idx + i, output_idx_buffer, k * sizeof(Int));
        DMA_WRITE(chunk_val + i, output_val_buffer, k * sizeof(DATA_T));
    }
    ASSERT_EQUAL(i + k, n_copy);
    state.L2_begin = j;
    state.L1_nnz = 0;
    state.L2_nnz = n_remain - n_copy;
    state.chunk_offset = n_copy;
}


NOINLINE static void init_L2(Int* L2, Int size) {
    if(size > 0) {
        SIMD_ALIGN Int buffer[1024];
        DMA_DECL_DESC(READ_WRITE)
        fill(buffer, min(size, 1024), empty);
        for(Int i = 0; i < size; i += 1024) {
            Int len = min(size - i, 1024);
            DMA_IWRITE(L2 + i, buffer, sizeof(Int) * len);
        }
        DMA_WAIT_ALL;
    }
}

INLINE int64_t compute_wait_for_MPE(volatile int64_t *share, int cgid, ex_buffer_t* buffer) {
    int64_t sync_signal;
    CRTS_ssync_array();
    if(CPE_ID == 28) {
        sync_signal = SYNC_SIGNAL_MCOMP;
        mem_fence();
        buffer->sync_signal = sync_signal;
        while(sync_signal == SYNC_SIGNAL_MCOMP) {
            sync_signal = buffer->sync_signal;
        }
        *share = sync_signal;
        CRTS_ssync_array();
    } else {
        CRTS_ssync_array();
        sync_signal = *remote_ldm_addr(share, 28);
    }
    return sync_signal;
}

template<typename DATA_T>
NOINLINE static void spgemm_hash_multicg_kernel(void *p_args) {
    DMA_DECL_DESC(READ_WRITE);
    volatile int64_t share;
    compute_t<DATA_T> compute_args;
    postprocess_t<DATA_T> postprocess_args;
    perthread_t<DATA_T>  per_thread;
    CPEState l_state;
    set_ptr_uncached(&p_args);
    auto uncached_args = reinterpret_cast<arg_t<DATA_T>*>(p_args);
    DMA_READ_NODESC(&uncached_args->compute_args, &compute_args, sizeof(compute_t<DATA_T>));
    const Int first_cg = (compute_args.config & CONFIG_MASK_FIRST_CG) >> CONFIG_SHIFT_FIRST_CG;
    const Int preprocess_ncg = (compute_args.config & CONFIG_MASK_PREPROCESS_NCG) >> CONFIG_SHIFT_PREPROCESS_NCG;
    const Int compute_ncg = (compute_args.config & CONFIG_MASK_COMPUTE_NCG);
    const Int cgid = _CGN - first_cg, id = CPE_ID + cgid * 64;
    const Bool aconj = (compute_args.config & CONFIG_MASK_A_CONJUGATE) != 0;
    const Bool bconj = (compute_args.config & CONFIG_MASK_B_CONJUGATE) != 0;
    auto ret = partition_spgemm_flops_multicg(compute_args.m, compute_args.n,
            preprocess_ncg * 64, compute_ncg * 64, cgid,
            compute_args.a_row_off, compute_args.a_col_idx, compute_args.b_row_off, compute_args.d_row_off, 
            compute_args.c_row_off + 1, uncached_args->exchange_buffer, l_state GET_ANNZ(compute_args));
    if(ret != 0) {
        return;
    }

    if(cgid < compute_ncg) {
        // per_thread.buffer
        DMA_READ(&uncached_args->per_thread[id].buffer, &per_thread.buffer, sizeof(hash_buffer_t<DATA_T>));
        Int begin_row = l_state.current_row, max_nnz = l_state.max_nnz;
        init_L2(per_thread.buffer.L2_idx, L2_max_size<DATA_T>(max_nnz));
        spgemm_hash_iter_call(compute_args, per_thread.buffer, l_state, aconj, bconj);
        // per_thread.state
        per_thread.state.complete = l_state.is_finished();
        per_thread.state.total_nnz = l_state.total_nnz;
        DMA_WRITE(&uncached_args->per_thread[id].state, &per_thread.state, sizeof(global_state_t));
        auto status = compute_wait_for_MPE(&share, cgid, &uncached_args->exchange_buffer[cgid]);
        while(status == SYNC_SIGNAL_BCOMP) {
            // per_thread.buffer
            DMA_READ(&uncached_args->per_thread[id].buffer, &per_thread.buffer, sizeof(hash_buffer_t<DATA_T>));
            if(per_thread.buffer.chunk_val != nullptr) {
                spgemm_hash_copy_remain(per_thread.buffer, l_state);
                if(l_state.chunk_offset < chunk_size<DATA_T>) {
                    spgemm_hash_iter_call(compute_args, per_thread.buffer, l_state, aconj, bconj);
                } 
                // per_thread.state
                per_thread.state.complete = l_state.is_finished();
                per_thread.state.total_nnz = l_state.total_nnz;
                DMA_WRITE(&uncached_args->per_thread[id].state, &per_thread.state, sizeof(global_state_t));
            }
            status = compute_wait_for_MPE(&share, cgid, &uncached_args->exchange_buffer[cgid]);
        }
        if(status == SYNC_SIGNAL_EXCEPT) {
            return;
        }

#ifdef PROFILE_SPGEMM_MULTICG
        printf("%2d,%lld,%lld\n", id, l_state.L1hashconf, l_state.L2hashconf);
#endif
        // per_thread.result
        DMA_IREAD(&uncached_args->postprocess_args, &postprocess_args, sizeof(postprocess_t<DATA_T>));
        DMA_READ(&uncached_args->per_thread[id].result, &per_thread.result, sizeof(result_t));
        spgemm_postprocess_multicg(postprocess_args, per_thread.result, compute_args.c_row_off, begin_row, l_state.end_row);
    }
}


template<typename DATA_T>
struct L2_hash_manager {
    DATA_T* L2_hash_val;
    Int* L2_hash_idx;
    Int nzub, size, mask, nnz, remain_flop;
#ifdef SWSPARSE_HAS_ASSERT
    Int max_size;
#endif
#ifdef PROFILE_SPGEMM_MULTICG
    int64_t hashconf = 0;
#endif

    L2_hash_manager(Int n, DATA_T* val, Int* idx) : L2_hash_val(val), L2_hash_idx(idx) {
#ifdef SWSPARSE_HAS_ASSERT
        max_size = 0;
#endif
    }
    void prepare(Int flop, Int nzub_) {
        remain_flop = flop;
        nzub = nzub_;
    }

    void new_row() {
        size = mask = nnz = 0;
    }
    void record_flops(Int flop) { remain_flop -= flop; }

    void insert(DATA_T val, Int idx, Int hh, Int r, Int boff) {
        if(UNLIKELY(size == 0)) {
            Int rest_nz_ub = min(remain_flop - (r - boff), nzub);
            size = ceil_pow_2(rest_nz_ub);
            mask = size - 1;
#ifdef SWSPARSE_HAS_ASSERT
            max_size = (max_size > size) ? max_size : size;
#endif
        }
        
        for(Int h = hh & mask; ; h = (h + 1) & mask) {
            Int hidx = L2_hash_idx[h];
            if(hidx < 0) {
                L2_hash_idx[h] = idx;
                L2_hash_val[h] = val;
                ++ nnz;
                break;
            } else if(LIKELY(hidx == idx)) {
                L2_hash_val[h] += val;
                break;
            } 
#ifdef PROFILE_SPGEMM_MULTICG
            ++hashconf;
#endif
        }
    }
};


template<size_t element_size, size_t capacity0, size_t capacity1>
struct copy_manager {
    using valp_t = uint8_t (*)[element_size];
    Int *indices0, *indices1, *indices2;
    valp_t values0, values1, values2;
    Int offsets0, offsets1, offsets2;

    copy_manager(Int* ci, void *cv, Int* L1di, void* L1dv, Int* L2i, void* L2v) {
        indices0 = ci;
        values0 = reinterpret_cast<valp_t>(cv);
        indices1 = L1di;
        values1 = reinterpret_cast<valp_t>(L1dv);
        indices2 = L2i;
        values2 = reinterpret_cast<valp_t>(L2v);
    }
    void setup(Int off) {
        offsets0 = off;
        offsets1 = offsets2 = 0;
    }
    void operator()(Int len, Int* ldm_idx, void* val) {
        DMA_DECL_DESC(READ_WRITE);
        valp_t ldm_val = reinterpret_cast<valp_t>(val);
        Int o_size;

        if(LIKELY(offsets0 + len <= capacity0)) {
            DMA_IWRITE(indices0 + offsets0, ldm_idx, len * sizeof(Int));
            DMA_IWRITE( values0 + offsets0, ldm_val, len * element_size);
            offsets0 += len;
        } else {
            o_size = capacity0 - offsets0;
            if(o_size > 0) {
                DMA_IWRITE(indices0 + offsets0, ldm_idx, o_size * sizeof(Int));
                DMA_IWRITE( values0 + offsets0, ldm_val, o_size * element_size);
                offsets0 += o_size;
                len -= o_size;
                ldm_idx += o_size;
                ldm_val += o_size;
            }
            if(LIKELY(offsets1 + len <= capacity1)) {
                DMA_IWRITE(indices1 + offsets1, ldm_idx, len * sizeof(Int));
                DMA_IWRITE( values1 + offsets1, ldm_val, len * element_size);
                offsets1 += len;
            } else {
                o_size = capacity1 - offsets1;
                if(o_size > 0) {
                    DMA_IWRITE(indices1 + offsets1, ldm_idx, o_size * sizeof(Int));
                    DMA_IWRITE( values1 + offsets1, ldm_val, o_size * element_size);
                    offsets1 += o_size;
                    len -= o_size;
                    ldm_idx += o_size;
                    ldm_val += o_size;
                }
                cached_write(indices2 + offsets2, ldm_idx, len * sizeof(Int));  // cached
                cached_write( values2 + offsets2, ldm_val, len * element_size); // cached
                offsets2 += len;
            }
        }
        DMA_WAIT_ALL;
    }
};


template<typename ConjA, typename ConjB, bool HasD, typename DATA_T>
NOINLINE static void spgemm_hash_iter(const compute_t<DATA_T>& args, const hash_buffer_t<DATA_T>& buffer, CPEState& l_state) {
    constexpr const int i_special = p_tile<DATA_T>;
    using intp_t = Int* RSTR;
    using intcp_t = const Int* RSTR;
    using valuep_t = DATA_T* RSTR;
    using valuecp_t = const DATA_T* RSTR;

    scale_kernel_t<DATA_T> scale_kernel;
    //sort_combiner<DATA_T> sort_combine;

    /* unpack arguments */
    const DATA_T beta = args.beta, alpha = args.alpha;
    const Int n = args.n;
    intcp_t a_row_off = args.a_row_off, b_row_off = args.b_row_off, d_row_off = args.d_row_off;
    intcp_t a_col_idx = args.a_col_idx, b_col_idx = args.b_col_idx, d_col_idx = args.d_col_idx;
    valuecp_t a_values = args.a_values, b_values  = args.b_values,  d_values  = args.d_values;
    intp_t   c_row_off = args.c_row_off, c_row_nz = c_row_off + 1;
    intp_t   L1_dump_idx = buffer.L1_dump_idx, L2_idx = buffer.L2_idx, chunk_idx = buffer.chunk_idx;
    valuep_t L1_dump_val = buffer.L1_dump_val, L2_val = buffer.L2_val, chunk_val = buffer.chunk_val;
    Int chunk_offset = l_state.chunk_offset;
    const Int r_begin = l_state.current_row, r_end = l_state.end_row;

    Int local_a_off[m_tile + 1], local_c_rnz[m_tile + 1], local_d_off[m_tile + 1];
    Int local_a_idx[p_tile<DATA_T>];
    SIMD_ALIGN Int local_rowcnt[sort_max_n_row];
    SIMD_ALIGN DATA_T local_a_val[p_tile<DATA_T>];
    SIMD_ALIGN Int L1_hash_idx[L1_hash_size<DATA_T>];
    SIMD_ALIGN DATA_T L1_hash_val[L1_hash_size<DATA_T>];
    DMA_DECL_DESC(READ_WRITE);
    DMA_DECL_DESC_2(READ);
    L2_hash_manager L2(n, L2_val, L2_idx);
    copy_manager<sizeof(DATA_T),chunk_size<DATA_T>,L1_hash_size<DATA_T>> \
        direct_copy(chunk_idx, chunk_val, L1_dump_idx, L1_dump_val, L2_idx, L2_val);
    #ifdef SWSPARSE_HAS_ASSERT
        const Int verify_initial_offset = l_state.total_nnz & chunk_size_mask<DATA_T>;
        ASSERT_EQUAL(verify_initial_offset, chunk_offset);
    #endif
    
    for(Int i = r_begin; i < r_end; i += m_tile) {
        Int j, len = min(m_tile, r_end - i);
        if constexpr(HasD) {  // beta != 0
            DMA_IREAD(d_row_off + i, local_d_off, (len + 1) * sizeof(Int));
        }
        DMA_IREAD(a_row_off + i, local_a_off, (len + 1) * sizeof(Int));
        DMA_READ( c_row_nz  + i, local_c_rnz, len * sizeof(Int));
        //local_c_rnz[len] = L1_hash_size<DATA_T>;

        for(j = 0; j < len; ++j) {
            const Int p_begin = local_a_off[j], p_end = local_a_off[j+1];
            Int flop = local_c_rnz[j], c_rnz, nz_ub, L1_size;
            #ifdef SWSPARSE_HAS_ASSERT
                const Int verify_offset = chunk_offset;
            #endif
            
            if constexpr(HasD) {  // beta != 0
                if(UNLIKELY(p_end == p_begin)) {  // special case, A row is empty, scale D row only
                    Int temp_out_offset = 0;
                    Int t_begin = local_d_off[j];
                    Int t_end = local_d_off[j+1];
                    direct_copy.setup(chunk_offset);
                    for(Int p = t_begin; p < t_end; p += L1_hash_size<DATA_T>) {
                        Int read_len = min(L1_hash_size<DATA_T>, t_end - p);
                        cached_read(L1_hash_idx, d_col_idx + p, sizeof(Int) * read_len);
                        cached_read(L1_hash_val, d_values + p, sizeof(DATA_T) * read_len);
                        scale_kernel.template scale<not_conjugate<DATA_T>>(L1_hash_val, read_len, beta);
                        direct_copy(read_len, L1_hash_idx, L1_hash_val);
                    }
                    c_rnz = t_end - t_begin;
                    local_c_rnz[j] = c_rnz;
                    l_state.finish_row(c_rnz, c_rnz);
                    chunk_offset = direct_copy.offsets0;
                    if(chunk_offset == chunk_size<DATA_T>) {
                        DMA_IWRITE(c_row_nz + i, local_c_rnz, (j + 1) * sizeof(Int));
                        l_state.not_finish(i + j + 1, direct_copy.offsets1, direct_copy.offsets2, 0, direct_copy.offsets2);
                        ASSERT_EQUAL(verify_offset + c_rnz, chunk_size<DATA_T> + direct_copy.offsets1 + direct_copy.offsets2);
                        goto FUNCTION_RETURN;
                    } else {
                        ASSERT_EQUAL(verify_offset + c_rnz, chunk_offset);
                        continue;
                    }
                } 
            } else if(UNLIKELY(p_end - p_begin == 1)) {  // special case, A row is only 1 element and beta == 0, scale B row only
                DATA_T a_val = alpha * ConjA::value(a_values[p_begin]);
                Int a_col_index = a_col_idx[p_begin];
                Int b_begin = b_row_off[a_col_index], b_end = b_row_off[a_col_index + 1];
                direct_copy.setup(chunk_offset);
                for(Int p = b_begin; p < b_end; p += L1_hash_size<DATA_T>) {
                    Int read_len = min(L1_hash_size<DATA_T>, b_end - p);
                    cached_read(L1_hash_idx, b_col_idx + p, sizeof(Int) * read_len);
                    cached_read(L1_hash_val, b_values + p, sizeof(DATA_T) * read_len);
                    scale_kernel.template scale<ConjB>(L1_hash_val, read_len, a_val);
                    direct_copy(read_len, L1_hash_idx, L1_hash_val);
                }
                c_rnz = b_end - b_begin;
                local_c_rnz[j] = c_rnz;
                l_state.finish_row(c_rnz, c_rnz);
                chunk_offset = direct_copy.offsets0;
                if(UNLIKELY(chunk_offset == chunk_size<DATA_T>)) {
                    DMA_IWRITE(c_row_nz + i, local_c_rnz, (j + 1) * sizeof(Int));
                        l_state.not_finish(i + j + 1, direct_copy.offsets1, direct_copy.offsets2, 0, direct_copy.offsets2);
                        ASSERT_EQUAL(verify_offset + c_rnz, chunk_size<DATA_T> + direct_copy.offsets1 + direct_copy.offsets2);
                    goto FUNCTION_RETURN;
                } else {
                    ASSERT_EQUAL(verify_offset + c_rnz, chunk_offset);
                    continue;
                }
            } 
            
            L2.new_row();
            nz_ub = min(flop, n);

            if(nz_ub < L1_hash_size<DATA_T>) { // not use L2
                Int L1_size_mask;
                L1_size = ceil_pow_2(nz_ub);
                L1_size_mask = L1_size - 1;
                ASSERT_LESS_EQUAL(L1_size, L1_hash_size<DATA_T>);
                fill(L1_hash_idx, L1_size, empty);
                //fill(L1_hash_val, L1_size, DATA_T(0));
                if constexpr(HasD) {  // beta != 0
                    for(Int r = local_d_off[j], re = local_d_off[j+1]; r < re; ++r) {
                        Int idx = d_col_idx[r];
                        DATA_T val = d_values[r];
                        for(Int h = hash(idx) & L1_size_mask; ; h = (h + 1) & L1_size_mask) {
                            if(L1_hash_idx[h] < 0) { // first run, no combine
                                L1_hash_val[h] = beta * val;
                                L1_hash_idx[h] = idx;
                                break;
                            }
                        }
                    }
                }
                for(Int p = p_begin; p < p_end; p += p_tile<DATA_T>) {
                    Int rlen = min(p_tile<DATA_T>, p_end - p);
                    DMA_IREAD_2(a_values + p, local_a_val, rlen * sizeof(DATA_T));
                    DMA_IREAD(  a_col_idx + p, local_a_idx, rlen * sizeof(Int));
                    DMA_WAIT_ALL_2;
                    scale_kernel.template scale<ConjA>(local_a_val, rlen, alpha);  // overlap with DMA
                    DMA_WAIT_ALL;

                    for(Int q = 0; q < rlen; ++q) {
                        Int k = local_a_idx[q], b_row_begin = b_row_off[k], b_row_end = b_row_off[k+1];
                        DATA_T a_val = local_a_val[q];
#if !defined(L1_HASH_UNROLL) || L1_HASH_UNROLL == 1
                        for(Int r = b_row_begin; r < b_row_end; ++r) {
                            Int idx = b_col_idx[r];
                            DATA_T b_val = b_values[r];
                            for(Int h = hash(idx) & L1_size_mask; ; h = (h + 1) & L1_size_mask) {
                                Int hidx = L1_hash_idx[h];
                                if(hidx < 0) {
                                    L1_hash_idx[h] = idx;
                                    L1_hash_val[h] = a_val * ConjB::value(b_val);
                                    break;
                                } else if(LIKELY(hidx == idx)) {
                                    L1_hash_val[h] += a_val * ConjB::value(b_val);
                                    break;
                                } 
                            }
                        }
#elif L1_HASH_UNROLL == 2
                        Int r, b_row_end_unroll = b_row_end - 1;
                        for(r = b_row_begin; r < b_row_end_unroll; r += 2) {
                            DATA_T b_val0 = b_values[r], b_val1 = b_values[r+1];
                            Int idx0 = b_col_idx[r], idx1 = b_col_idx[r+1];  // idx0 != idx1
                            Int h0 = hash(idx0) & L1_size_mask, h1 = hash(idx1) & L1_size_mask;

                            if(LIKELY(h0 != h1)) {
                                for(; ; h0 = (h0 + 1) & L1_size_mask, h1 = (h1 + 1) & L1_size_mask HASHCONF_(1)) {
                                    Int hidx0 = L1_hash_idx[h0], hidx1 = L1_hash_idx[h1];
                                    if(hidx0 < 0) {
                                        L1_hash_idx[h0] = idx0;
                                        L1_hash_val[h0] = a_val * ConjB::value(b_val0);
                                    PROCESS_ELEMENT_1_A:
                                        if(hidx1 < 0) {
                                            L1_hash_idx[h1] = idx1;
                                            L1_hash_val[h1] = a_val * ConjB::value(b_val1);
                                            goto OUTER_LOOP_CONTINUE_A;
                                        } else if (LIKELY(hidx1 == idx1)) {
                                            L1_hash_val[h1] += a_val * ConjB::value(b_val1);
                                            goto OUTER_LOOP_CONTINUE_A;
                                        } else {
                                            h0 = h1; // for element 1
                                            idx0 = idx1;
                                            b_val0 = b_val1;
                                            HASHCONF(1);
                                            break;
                                        }
                                    } else if(LIKELY(hidx0 == idx0)) {
                                        L1_hash_val[h0] += a_val * ConjB::value(b_val0);
                                        goto PROCESS_ELEMENT_1_A;
                                    }
                                    HASHCONF(1);
                                    if(hidx1 < 0) {
                                        L1_hash_idx[h1] = idx1;
                                        L1_hash_val[h1] = a_val * ConjB::value(b_val1);
                                        break;
                                    } else if(LIKELY(hidx1 == idx1)) {
                                        L1_hash_val[h1] += a_val * ConjB::value(b_val1);
                                        break;
                                    } 
                                }
                            } else {
                                for(; ; h0 = (h0 + 1) & L1_size_mask HASHCONF_(1)) {
                                    Int hidx = L1_hash_idx[h0];
                                    if(hidx < 0) {
                                        L1_hash_idx[h0] = idx1;
                                        L1_hash_val[h0] = a_val * ConjB::value(b_val1);
                                        break;
                                    } else if(hidx == idx1) {
                                        L1_hash_val[h0] += a_val * ConjB::value(b_val1);
                                        break;
                                    } else if(LIKELY(hidx == idx0)) {
                                        L1_hash_val[h0] += a_val * ConjB::value(b_val0);
                                        idx0 = idx1;
                                        b_val0 = b_val1;
                                        HASHCONF(1);
                                        break;
                                    } 
                                }
                            }
                            for(h0 = (h0 + 1) & L1_size_mask; ; h0 = (h0 + 1) & L1_size_mask HASHCONF_(1)) {
                                Int hidx = L1_hash_idx[h0];
                                if(hidx < 0) {
                                    L1_hash_idx[h0] = idx0;
                                    L1_hash_val[h0] = a_val * ConjB::value(b_val0);
                                    break;
                                } else if(LIKELY(hidx == idx0)) {
                                    L1_hash_val[h0] += a_val * ConjB::value(b_val0);
                                    break;
                                } 
                            }
                        OUTER_LOOP_CONTINUE_A:;
                        }
                        if(r < b_row_end) {
                            Int idx = b_col_idx[r];
                            DATA_T b_val = b_values[r];
                            for(Int h = hash(idx) & L1_size_mask; ; h = (h + 1) & L1_size_mask HASHCONF_(1)) {
                                Int hidx = L1_hash_idx[h];
                                if(hidx < 0) {
                                    L1_hash_idx[h] = idx;
                                    L1_hash_val[h] = a_val * ConjB::value(b_val);
                                    break;
                                } else if(LIKELY(hidx == idx)) {
                                    L1_hash_val[h] += a_val * ConjB::value(b_val);
                                    break;
                                } 
                            }
                        }
#endif
                    }
                }
            } else { // maybe use L2
                Int L1_max = l_state.template L1_max<DATA_T>(flop);
                L2.prepare(flop, n - L1_max);
                L1_size = L1_hash_size<DATA_T>;
                c_rnz = 0;  // L1 nnz
                fill(L1_hash_idx, L1_size, empty);
                if constexpr(HasD) {  // beta != 0
                    for(Int r = local_d_off[j]; r < local_d_off[j+1]; ++r) {
                        Int idx = d_col_idx[r];
                        DATA_T val = d_values[r];
                        for(Int hh = hash(idx), h = hh & L1_hash_size_mask<DATA_T>; ; h = (h + 1) & L1_hash_size_mask<DATA_T>) {
                            if(L1_hash_idx[h] < 0) {  // first run, no combine
                                if(c_rnz < L1_max) {  // insert into L1
                                    L1_hash_idx[h] = idx;
                                    L1_hash_val[h] = beta * val;
                                    ++ c_rnz;
                                } else { // use L2
                                    L2.insert(beta * val, idx, hh, r, local_d_off[j]);
                                }
                                break;
                            }
                        }
                    }
                    L2.record_flops(local_d_off[j+1] - local_d_off[j]);
                }
                Int p, q, r, rlen, b_row_begin, b_row_end;
                for(p = p_begin; p < p_end; p += p_tile<DATA_T>) {
                    rlen = min(p_tile<DATA_T>, p_end - p);
                    DMA_IREAD_2(a_values + p, local_a_val, rlen * sizeof(DATA_T));
                    DMA_IREAD(  a_col_idx + p, local_a_idx, rlen * sizeof(Int));
                    DMA_WAIT_ALL_2;
                    scale_kernel.template scale<ConjA>(local_a_val, rlen, alpha);  // overlap with DMA
                    DMA_WAIT_ALL;

                    for(q = 0; q < rlen; ++q) {
                        Int k = local_a_idx[q];
                        DATA_T a_val = local_a_val[q];
                        b_row_begin = b_row_off[k], b_row_end = b_row_off[k+1];
                        r = b_row_begin;
#if !defined(L1_HASH_UNROLL) || L1_HASH_UNROLL == 1
                        for(; r < b_row_end && c_rnz < L1_max; ++r) {
                            Int idx = b_col_idx[r];
                            DATA_T b_val = b_values[r];
                            for(Int h = hash(idx) & L1_hash_size_mask<DATA_T>; ; h = (h + 1) & L1_hash_size_mask<DATA_T>) {
                                Int hidx = L1_hash_idx[h];
                                if(hidx < 0) {
                                    L1_hash_idx[h] = idx;
                                    L1_hash_val[h] = a_val * ConjB::value(b_val);
                                    ++ c_rnz;
                                    break;
                                } else if(LIKELY(hidx == idx)) {
                                    L1_hash_val[h] += a_val * ConjB::value(b_val);
                                    break;
                                } 
                            }
                        }
#else
                        
                        for(Int tmp_end = b_row_end - 1; r < tmp_end && c_rnz < L1_max; r += 2) {
                            DATA_T b_val0 = b_values[r], b_val1 = b_values[r+1];
                            Int idx0 = b_col_idx[r], idx1 = b_col_idx[r+1];  // idx0 != idx1
                            Int h0 = hash(idx0) & L1_hash_size_mask<DATA_T>, h1 = hash(idx1) & L1_hash_size_mask<DATA_T>;

                            if(LIKELY(h0 != h1)) {
                                for(; ; h0 = (h0 + 1) & L1_hash_size_mask<DATA_T>, h1 = (h1 + 1) & L1_hash_size_mask<DATA_T> HASHCONF_(1)) {
                                    Int hidx0 = L1_hash_idx[h0], hidx1 = L1_hash_idx[h1];
                                    if(hidx0 < 0) {
                                        L1_hash_idx[h0] = idx0;
                                        L1_hash_val[h0] = a_val * ConjB::value(b_val0);
                                        ++ c_rnz;
                                    PROCESS_ELEMENT_1_B:
                                        if(hidx1 < 0) {
                                            L1_hash_idx[h1] = idx1;
                                            L1_hash_val[h1] = a_val * ConjB::value(b_val1);
                                            ++ c_rnz;
                                            goto OUTER_LOOP_CONTINUE_B;
                                        } else if (LIKELY(hidx1 == idx1)) {
                                            L1_hash_val[h1] += a_val * ConjB::value(b_val1);
                                            goto OUTER_LOOP_CONTINUE_B;
                                        } else {
                                            h0 = h1; // for element 1
                                            idx0 = idx1;
                                            b_val0 = b_val1;
                                            HASHCONF(1);
                                            break;
                                        }
                                    } else if(LIKELY(hidx0 == idx0)) {
                                        L1_hash_val[h0] += a_val * ConjB::value(b_val0);
                                        goto PROCESS_ELEMENT_1_B;
                                    }
                                    HASHCONF(1);
                                    if(hidx1 < 0) {
                                        L1_hash_idx[h1] = idx1;
                                        L1_hash_val[h1] = a_val * ConjB::value(b_val1);
                                        ++ c_rnz;
                                        break;
                                    } else if(LIKELY(hidx1 == idx1)) {
                                        L1_hash_val[h1] += a_val * ConjB::value(b_val1);
                                        break;
                                    } 
                                }
                            } else {
                                for(; ; h0 = (h0 + 1) & L1_hash_size_mask<DATA_T> HASHCONF_(1)) {
                                    Int hidx = L1_hash_idx[h0];
                                    if(hidx < 0) {
                                        L1_hash_idx[h0] = idx1;
                                        L1_hash_val[h0] = a_val * ConjB::value(b_val1);
                                        ++ c_rnz;
                                        break;
                                    } else if(hidx == idx1) {
                                        L1_hash_val[h0] += a_val * ConjB::value(b_val1);
                                        break;
                                    } else if(LIKELY(hidx == idx0)) {
                                        L1_hash_val[h0] += a_val * ConjB::value(b_val0);
                                        idx0 = idx1;
                                        b_val0 = b_val1;
                                        HASHCONF(1);
                                        break;
                                    } 
                                }
                            }
                            for(h0 = (h0 + 1) & L1_hash_size_mask<DATA_T>; ; h0 = (h0 + 1) & L1_hash_size_mask<DATA_T> HASHCONF_(1)) {
                                Int hidx = L1_hash_idx[h0];
                                if(hidx < 0) {
                                    L1_hash_idx[h0] = idx0;
                                    L1_hash_val[h0] = a_val * ConjB::value(b_val0);
                                    ++ c_rnz;
                                    break;
                                } else if(LIKELY(hidx == idx0)) {
                                    L1_hash_val[h0] += a_val * ConjB::value(b_val0);
                                    break;
                                } 
                            }
                        OUTER_LOOP_CONTINUE_B:;
                        }
                        if(r < b_row_end && c_rnz < L1_max) {
                            Int idx = b_col_idx[r];
                            DATA_T b_val = b_values[r];
                            for(Int h = hash(idx) & L1_hash_size_mask<DATA_T>; ; h = (h + 1) & L1_hash_size_mask<DATA_T> HASHCONF_(1)) {
                                Int hidx = L1_hash_idx[h];
                                if(hidx < 0) {
                                    L1_hash_idx[h] = idx;
                                    L1_hash_val[h] = a_val * ConjB::value(b_val);
                                    ++ c_rnz;
                                    break;
                                } else if(LIKELY(hidx == idx)) {
                                    L1_hash_val[h] += a_val * ConjB::value(b_val);
                                    break;
                                } 
                            }
                            goto END_IN_L1;
                        }
#endif
                        for(; r < b_row_end; ++r) {
                            Int idx = b_col_idx[r];
                            DATA_T b_val = b_values[r];
                            for(Int hh = hash(idx), h = hh & L1_hash_size_mask<DATA_T>; ; h = (h + 1) & L1_hash_size_mask<DATA_T> HASHCONF_(1)) {
                                Int hidx = L1_hash_idx[h];
                                if(hidx < 0) {
                                    L2.insert(a_val * ConjB::value(b_val), idx, hh, r, b_row_begin);
                                    break;
                                } else if(LIKELY(hidx == idx)) {
                                    L1_hash_val[h] += a_val * ConjB::value(b_val);
                                    break;
                                } 
                            }
                        }
                        END_IN_L1:
                        L2.record_flops(b_row_end - b_row_begin);
                    }
                }
            }
        
            // write content of hash table into the output
            Int k = 0;
            for(Int p = 0; p < L1_size; ++p) {
                if(L1_hash_idx[p] >= 0) {
                    L1_hash_idx[k] = L1_hash_idx[p];
                    L1_hash_val[k] = L1_hash_val[p];
                    ++k;
                }
            }

            c_rnz = k + L2.nnz;

            local_c_rnz[j] = c_rnz;
            l_state.finish_row(flop, c_rnz);

            Int chunk_rest = chunk_size<DATA_T> - chunk_offset;
            #ifdef SWSPARSE_HAS_ASSERT
                const Int verify_crnz = c_rnz;
            #endif
            if(LIKELY(k <= chunk_rest)) {
                Int tlen = min(L1_hash_size<DATA_T>, chunk_rest), p = 0, load_idx;
                if(UNLIKELY(k == chunk_rest)) {
                    goto CHUNK_FULL;
                }
                for(; p < L2.size; ++p) {
                    load_idx = L2_idx[p];
                    if(load_idx >= 0) {
                        L1_hash_idx[k] = load_idx;
                        L1_hash_val[k] = L2_val[p];
                        L2_idx[p] = empty;
                        if(UNLIKELY((++k) == tlen)) {
                            CHUNK_FULL:
                            DMA_IWRITE(chunk_idx + chunk_offset, L1_hash_idx, tlen * sizeof(Int));
                            DMA_IWRITE(chunk_val + chunk_offset, L1_hash_val, tlen * sizeof(DATA_T));
                            c_rnz -= tlen;
                            k = 0;
                            chunk_offset += tlen;
                            tlen = min(L1_hash_size<DATA_T>, chunk_size<DATA_T> - chunk_offset);
                            if(tlen == 0) { // chunk full
                                DMA_IWRITE(c_row_nz + i, local_c_rnz, (j + 1) * sizeof(Int));
                                l_state.not_finish(i + j + 1, 0, c_rnz, p, L2.size);
                                ASSERT_EQUAL(verify_offset + verify_crnz, chunk_size<DATA_T> + l_state.L1_nnz + l_state.L2_nnz);
                                goto FUNCTION_RETURN;
                            }
                            DMA_WAIT_ALL;
                        }
                    }
                }
                if(k > 0) {
                    DMA_IWRITE(chunk_idx + chunk_offset, L1_hash_idx, k * sizeof(Int));
                    DMA_WRITE(chunk_val + chunk_offset, L1_hash_val, k * sizeof(DATA_T));
                    chunk_offset += k;
                }
                ASSERT_EQUAL(verify_offset + verify_crnz, chunk_offset);
            } else {
                Int L1_rest = k - chunk_rest;
                DMA_IWRITE(chunk_idx + chunk_offset, L1_hash_idx, chunk_rest * sizeof(Int));
                DMA_IWRITE(chunk_val + chunk_offset, L1_hash_val, chunk_rest * sizeof(DATA_T));
                DMA_IWRITE(L1_dump_idx, L1_hash_idx + chunk_rest, L1_rest * sizeof(Int));
                DMA_IWRITE(L1_dump_val, L1_hash_val + chunk_rest, L1_rest * sizeof(DATA_T));
                DMA_IWRITE(c_row_nz + i, local_c_rnz, (j + 1) * sizeof(Int));
                l_state.not_finish(i + j + 1, L1_rest, c_rnz - k, 0, L2.size);
                ASSERT_EQUAL(verify_offset + verify_crnz, chunk_size<DATA_T> + l_state.L1_nnz + l_state.L2_nnz);
                goto FUNCTION_RETURN;
            }
        }
        DMA_SWRITE(c_row_nz + i, local_c_rnz, len * sizeof(Int));
    }
    // COMMENT 20221118: 
    //    Here, all the computations are finished. The next stage is postprocessing.
    //    See hm_SpGEMM.cpp: first free(L2_hash) and then matrix_c = malloc(), 
    //    so `L2_hash` and `matrix_c` may be aliasing.
    //    however, `L2_hash` is access via cache and `matrix_c` via DMA, so `L2_hash` must be flushed out of cache
    flush_slave_cache();
    l_state.finish();
FUNCTION_RETURN:
    #ifdef SWSPARSE_HAS_ASSERT
    const Int verify_nnz_remainder = l_state.total_nnz & chunk_size_mask<DATA_T>;
    const Int verify_remain = l_state.L1_nnz + l_state.L2_nnz;
    const Int verify_offset = ((verify_remain > 0) ? verify_remain : chunk_offset) & chunk_size_mask<DATA_T>;
    const Int verify_L2 = L2_max_size<DATA_T>(l_state.max_nnz);
    ASSERT_EQUAL(verify_nnz_remainder, verify_offset);
    ASSERT_LESS_EQUAL(L2.max_size, verify_L2);
    #endif
    #ifdef PROFILE_SPGEMM_MULTICG
    l_state.L2hashconf += L2.hashconf;
    #endif
    DMA_WAIT_ALL;
}

CPE_TEMPLATE_KERNEL(spgemm_hash_multicg_kernel, CACHE_128KB)

} // namespace swSparse

// code back-up
#ifdef LESS_BRANCH_CODE_IN_L1_HASH
#ifndef L1_HASH_UNROLL
                        for(Int r = b_row_begin; r < b_row_end; ++r) {
                            Int idx = b_col_idx[r];
                            DATA_T b_val = b_values[r];
                            for(Int h = hash(idx) & L1_size_mask; ; h = (h + 1) & L1_size_mask) {
                                Int hidx = L1_hash_idx[h];
                                Bool f = hidx < 0, g = hidx == idx;
                                if(LIKELY(f | g)) {
                                    L1_hash_idx[h] = idx;
                                    L1_hash_val[h] += a_val * ConjB::value(b_val);
                                    break;
                                }
                            }
                        }
#else
                        Int r, b_row_end_unroll = b_row_end - 1;
                        for(r = b_row_begin; r < b_row_end_unroll; r += 2) {
                            DATA_T b_val0 = b_values[r], b_val1 = b_values[r+1];
                            Int idx0 = b_col_idx[r], idx1 = b_col_idx[r+1];  // idx0 != idx1
                            Int h0 = hash(idx0) & L1_size_mask, h1 = hash(idx1) & L1_size_mask;

                            if(LIKELY(h0 != h1)) {
                                for(; ; h0 = (h0 + 1) & L1_size_mask, h1 = (h1 + 1) & L1_size_mask) {
                                    Int hidx0 = L1_hash_idx[h0], hidx1 = L1_hash_idx[h1];
                                    Bool f0 = hidx0 < 0, g0 = hidx0 == idx0;
                                    Bool f1 = hidx1 < 0, g1 = hidx1 == idx1;
                                    if(LIKELY(f0 | g0)) {
                                        L1_hash_idx[h0] = idx0;
                                        L1_hash_val[h0] += a_val * ConjB::value(b_val0);
                                        if(LIKELY(f1 | g1)) {
                                            L1_hash_idx[h1] = idx1;
                                            L1_hash_val[h1] += a_val * ConjB::value(b_val1);
                                            goto OUTER_LOOP_CONTINUE;
                                        } else {
                                            h0 = (h1 + 1) & L1_size_mask; // for element 1
                                            idx0 = idx1;
                                            b_val0 = b_val1;
                                            break;
                                        }
                                    }
                                    if(LIKELY(f1 | g1)) {
                                        L1_hash_idx[h1] = idx1;
                                        L1_hash_val[h1] += a_val * ConjB::value(b_val1);
                                        h0 = (h0 + 1) & L1_size_mask; // for element 0
                                        break;
                                    } 
                                }
                            } else {
                                for(; ; h0 = (h0 + 1) & L1_size_mask) {
                                    Int hidx = L1_hash_idx[h0];
#ifdef BRANCHY3
                                    if(hidx < 0) {
                                        L1_hash_idx[h0] = idx1;
                                        L1_hash_val[h0] = a_val * ConjB::value(b_val1);
                                        break;
                                    } else if(hidx == idx1) {
                                        L1_hash_val[h0] += a_val * ConjB::value(b_val1);
                                        break;
                                    } else if(hidx == idx0) {
                                        L1_hash_val[h0] += a_val * ConjB::value(b_val0);
                                        idx0 = idx1;
                                        b_val0 = b_val1;
                                        break;
                                    } 
#else
                                    Bool f = hidx < 0, g0 = hidx == idx0, g1 = hidx == idx1;
                                    if(LIKELY(f | g0 | g1)) {
                                        L1_hash_idx[h0] = g0 ? idx0 : idx1;
                                        L1_hash_val[h0] += a_val * ConjB::value(g0 ? b_val0 : b_val1);
                                        idx0 = g0 ? idx1 : idx0;
                                        b_val0 = g0 ? b_val1 : b_val0;
                                        break;
                                    } 
#endif
                                }
                                h0 = (h0 + 1) & L1_size_mask;
                            }
                            
                            
                            for(; ; h0 = (h0 + 1) & L1_size_mask) {
                                Int hidx = L1_hash_idx[h0];
                                Bool f = hidx < 0, g = hidx == idx0;
                                if(LIKELY(f | g)) {
                                    L1_hash_idx[h0] = idx0;
                                    L1_hash_val[h0] += a_val * ConjB::value(b_val0);
                                    break;
                                }
                            }
                        OUTER_LOOP_CONTINUE:;
                            
                        }
                        if(r < b_row_end) {
                            Int idx = b_col_idx[r];
                            DATA_T b_val = b_values[r];
                            for(Int h = hash(idx) & L1_size_mask; ; h = (h + 1) & L1_size_mask) {
                                Int hidx = L1_hash_idx[h];
                                Bool f = hidx < 0, g = hidx == idx;
                                if(LIKELY(f | g)) {
                                    L1_hash_idx[h] = idx;
                                    L1_hash_val[h] += a_val * ConjB::value(b_val);
                                    break;
                                }
                            }
                        }
#endif

#endif

#ifdef L1_HASH_UNROLL_3_CODE
                        Int r, b_row_end_unroll = b_row_end - 2;
                        for(r = b_row_begin; r < b_row_end_unroll; r += 3) {
                            DATA_T b_val0 = b_values[r], b_val1 = b_values[r+1], b_val2 = b_values[r+2];
                            Int idx0 = b_col_idx[r], idx1 = b_col_idx[r+1], idx2 = b_col_idx[r+2];  // idx0 != idx1
                            Int h0 = hash(idx0) & L1_size_mask, h1 = hash(idx1) & L1_size_mask, h2 = hash(idx2) & L1_size_mask;

                            if(LIKELY(h0 != h1)) {
                                if(LIKELY(h1 != h2 && h0 != h2)) {  // all not equal
                                    for(; ; h0 = (h0 + 1) & L1_size_mask, h1 = (h1 + 1) & L1_size_mask, h2 = (h2 + 1) & L1_size_mask) {
                                        Int hidx0 = L1_hash_idx[h0], hidx1 = L1_hash_idx[h1], hidx2 = L1_hash_idx[h2];
                                        Int s0 = 0, s1 = 0, s2 = 0;
                                        if(hidx0 < 0) {
                                            L1_hash_idx[h0] = idx0;
                                            L1_hash_val[h0] = a_val * ConjB::value(b_val0);
                                            s0 = 1;
                                        } else if(LIKELY(hidx0 == idx0)) {
                                            L1_hash_val[h0] += a_val * ConjB::value(b_val0);
                                            s0 = 1;
                                        }
                                        if(hidx1 < 0) {
                                            L1_hash_idx[h1] = idx1;
                                            L1_hash_val[h1] = a_val * ConjB::value(b_val1);
                                            s1 = 1;
                                        } else if(LIKELY(hidx1 == idx1)) {
                                            L1_hash_val[h1] += a_val * ConjB::value(b_val1);
                                            s1 = 1;
                                        }
                                        if(hidx2 < 0) {
                                            L1_hash_idx[h2] = idx2;
                                            L1_hash_val[h2] = a_val * ConjB::value(b_val2);
                                            s2 = 1;
                                        } else if(LIKELY(hidx2 == idx2)) {
                                            L1_hash_val[h2] += a_val * ConjB::value(b_val2);
                                            s2 = 1;
                                        }
                                        switch (s0 + s1 + s2) {
                                        case 3:
                                            goto OUTER_LOOP_CONTINUE_A;
                                        case 2:
                                            if(s1 == 0) {  // 1 0 1
                                                h0 = h1; idx0 = idx1; b_val0 = b_val1;
                                            } else if(s2 == 0) {   // 1 1 0
                                                h0 = h2; idx0 = idx2; b_val0 = b_val2;
                                            }
                                            goto PROCESS_1_A;
                                        case 1:
                                            if(s0 == 1) {  // 1 0 0
                                                h0 = h2; idx0 = idx2; b_val0 = b_val2;
                                            } else if(s1 == 1) {   // 0 1 0
                                                h1 = h2; idx1 = idx2; b_val1 = b_val2;
                                            }
                                            goto PROCESS_2_A;
                                        }
                                    }
                                } else {  // h2 == h0 or h2 == h1
                                    for(; ; h0 = (h0 + 1) & L1_size_mask, h1 = (h1 + 1) & L1_size_mask, h2 = (h2 + 1) & L1_size_mask) {
                                        Int hidx0 = L1_hash_idx[h0], hidx1 = L1_hash_idx[h1], hidx2 = L1_hash_idx[h2];
                                        Int s0 = 0, s1 = 0, s2 = 0;
                                        if(hidx0 < 0) {
                                            L1_hash_idx[h0] = idx0;
                                            L1_hash_val[h0] = a_val * ConjB::value(b_val0);
                                            s0 = 1;
                                        } else if(LIKELY(hidx0 == idx0)) {
                                            L1_hash_val[h0] += a_val * ConjB::value(b_val0);
                                            s0 = 1;
                                        }
                                        if(hidx1 < 0) {
                                            L1_hash_idx[h1] = idx1;
                                            L1_hash_val[h1] = a_val * ConjB::value(b_val1);
                                            s1 = 1;
                                        } else if(LIKELY(hidx1 == idx1)) {
                                            L1_hash_val[h1] += a_val * ConjB::value(b_val1);
                                            s1 = 1;
                                        }
                                        if(LIKELY(hidx2 == idx2)) {
                                            L1_hash_val[h2] += a_val * ConjB::value(b_val2);
                                            s2 = 1;
                                        }
                                        switch (s0 + s1 + s2) {
                                        case 3:
                                            goto OUTER_LOOP_CONTINUE_A;
                                        case 2:
                                            if(s1 == 0) {
                                                h0 = h1; idx0 = idx1; b_val0 = b_val1;
                                            } else if(s2 == 0) {
                                                h0 = h2; idx0 = idx2; b_val0 = b_val2;
                                            }
                                            goto PROCESS_1_A;
                                        case 1:
                                            if(s0 == 1) {
                                                h0 = h2; idx0 = idx2; b_val0 = b_val2;
                                            } else if(s1 == 1) {
                                                h1 = h2; idx1 = idx2; b_val1 = b_val2;
                                            }
                                            goto PROCESS_2_A;
                                        }
                                    }
                                }
                            } else {
                                if(LIKELY(h2 != h1)) {  // h0 == h1
                                    for(; ; h0 = (h0 + 1) & L1_size_mask, h2 = (h2 + 1) & L1_size_mask) {
                                        Int hidx0 = L1_hash_idx[h0], hidx2 = L1_hash_idx[h2];
                                        Int s0 = 0, s1 = 0, s2 = 0;
                                        if(hidx0 < 0) {
                                            L1_hash_idx[h0] = idx0;
                                            L1_hash_val[h0] = a_val * ConjB::value(b_val0);
                                            s0 = 1;
                                        } else if(LIKELY(hidx0 == idx0)) {
                                            L1_hash_val[h0] += a_val * ConjB::value(b_val0);
                                            s0 = 1;
                                        }
                                        if(LIKELY(hidx0 == idx1)) {
                                            L1_hash_val[h0] += a_val * ConjB::value(b_val1);
                                            s1 = 1;
                                        }
                                        if(hidx2 < 0) {
                                            L1_hash_idx[h2] = idx2;
                                            L1_hash_val[h2] = a_val * ConjB::value(b_val2);
                                            s2 = 1;
                                        } else if(LIKELY(hidx2 == idx2)) {
                                            L1_hash_val[h2] += a_val * ConjB::value(b_val2);
                                            s2 = 1;
                                        }
                                        switch (s0 + s1 + s2) {
                                        case 3:
                                            goto OUTER_LOOP_CONTINUE_A;
                                        case 2:
                                            if(s1 == 0) {
                                                idx0 = idx1; b_val0 = b_val1;
                                            } else if(s2 == 0) {
                                                h0 = h2; idx0 = idx2; b_val0 = b_val2;
                                            }
                                            goto PROCESS_1_A;
                                        case 1:
                                            if(s0 == 1) {
                                                h0 = h2; idx0 = idx2; b_val0 = b_val2;
                                            } else if(s1 == 1) {
                                                h1 = h2; idx1 = idx2; b_val1 = b_val2;
                                            }
                                            goto PROCESS_2_A;
                                        }
                                    }
                                } else {  // h0 == h1 == h2
                                    for(; ; h0 = (h0 + 1) & L1_size_mask) {
                                        Int hidx0 = L1_hash_idx[h0];
                                        Int s0 = 0, s1 = 0, s2 = 0;
                                        if(hidx0 < 0) {
                                            L1_hash_idx[h0] = idx0;
                                            L1_hash_val[h0] = a_val * ConjB::value(b_val0);
                                            s0 = 1;
                                        } else if(LIKELY(hidx0 == idx0)) {
                                            L1_hash_val[h0] += a_val * ConjB::value(b_val0);
                                            s0 = 1;
                                        }
                                        if(LIKELY(hidx0 == idx1)) {
                                            L1_hash_val[h0] += a_val * ConjB::value(b_val1);
                                            s1 = 1;
                                        }
                                        if(LIKELY(hidx0 == idx2)) {
                                            L1_hash_val[h0] += a_val * ConjB::value(b_val2);
                                            s2 = 1;
                                        }
                                        switch (s0 + s1 + s2) {
                                        case 3:
                                            goto OUTER_LOOP_CONTINUE_A;
                                        case 2:
                                            if(s1 == 0) {
                                                idx0 = idx1; b_val0 = b_val1;
                                            } else if(s2 == 0) {
                                                idx0 = idx2; b_val0 = b_val2;
                                            }
                                            goto PROCESS_1_A;
                                        case 1:
                                            if(s0 == 1) {
                                                idx0 = idx2; b_val0 = b_val2;
                                            } else if(s1 == 1) {
                                                h1 = h0; idx1 = idx2; b_val1 = b_val2;
                                            }
                                            goto PROCESS_2_A;
                                        }
                                    }
                                }
                            }

                            PROCESS_2_A:
                            if(LIKELY(h0 != h1)) {
                                for(h0 = (h0 + 1) & L1_size_mask, h1 = (h1 + 1) & L1_size_mask; ; \
                                    h0 = (h0 + 1) & L1_size_mask, h1 = (h1 + 1) & L1_size_mask) {
                                    Int hidx0 = L1_hash_idx[h0], hidx1 = L1_hash_idx[h1];
                                    Bool s0 = false, s1 = false;
                                    if(hidx0 < 0) {
                                        L1_hash_idx[h0] = idx0;
                                        L1_hash_val[h0] = a_val * ConjB::value(b_val0);
                                        s0 = true;
                                    } else if(LIKELY(hidx0 == idx0)) {
                                        L1_hash_val[h0] += a_val * ConjB::value(b_val0);
                                        s0 = true;
                                    }
                                    if(hidx1 < 0) {
                                        L1_hash_idx[h1] = idx1;
                                        L1_hash_val[h1] = a_val * ConjB::value(b_val1);
                                        s1 = true;
                                    } else if(LIKELY(hidx1 == idx1)) {
                                        L1_hash_val[h1] += a_val * ConjB::value(b_val1);
                                        s1 = true;
                                    }
                                    switch (s0 + s1) {
                                    case 2:
                                        goto OUTER_LOOP_CONTINUE_A;
                                    case 1:
                                        if(s0 == 1) {
                                            h0 = h1; idx0 = idx1; b_val0 = b_val1;
                                        } 
                                        goto PROCESS_1_A;
                                    }
                                }
                            } else {
                                for(h0 = (h0 + 1) & L1_size_mask; ; h0 = (h0 + 1) & L1_size_mask) {
                                    Int hidx0 = L1_hash_idx[h0];
                                    Bool s0 = false, s1 = false;
                                    if(hidx0 < 0) {
                                        L1_hash_idx[h0] = idx0;
                                        L1_hash_val[h0] = a_val * ConjB::value(b_val0);
                                        s0 = true;
                                    } else if(LIKELY(hidx0 == idx0)) {
                                        L1_hash_val[h0] += a_val * ConjB::value(b_val0);
                                        s0 = true;
                                    }
                                    if(LIKELY(hidx0 == idx1)) {
                                        L1_hash_val[h0] += a_val * ConjB::value(b_val1);
                                        s1 = true;
                                    }
                                    switch (s0 + s1) {
                                    case 2:
                                        goto OUTER_LOOP_CONTINUE_A;
                                    case 1:
                                        if(s0 == 1) {
                                            idx0 = idx1; b_val0 = b_val1;
                                        } 
                                        goto PROCESS_1_A;
                                    }
                                }

                            }
                            PROCESS_1_A:
                            for(h0 = (h0 + 1) & L1_size_mask; ; h0 = (h0 + 1) & L1_size_mask) {
                                Int hidx = L1_hash_idx[h0];
                                if(hidx < 0) {
                                    L1_hash_idx[h0] = idx0;
                                    L1_hash_val[h0] = a_val * ConjB::value(b_val0);
                                    break;
                                } else if(LIKELY(hidx == idx0)) {
                                    L1_hash_val[h0] += a_val * ConjB::value(b_val0);
                                    break;
                                } 
                            }
                            OUTER_LOOP_CONTINUE_A:;
                        }
                        for(; r < b_row_end; ++r) {
                            Int idx = b_col_idx[r];
                            DATA_T b_val = b_values[r];
                            for(Int h = hash(idx) & L1_size_mask; ; h = (h + 1) & L1_size_mask) {
                                Int hidx = L1_hash_idx[h];
                                if(hidx < 0) {
                                    L1_hash_idx[h] = idx;
                                    L1_hash_val[h] = a_val * ConjB::value(b_val);
                                    break;
                                } else if(LIKELY(hidx == idx)) {
                                    L1_hash_val[h] += a_val * ConjB::value(b_val);
                                    break;
                                } 
                            }
                        }
#endif