#include "swSparse_trf.h"
#include "internal/rename.h"
#include "internal/debug.h"
#include "internal/utils.h"
#include "internal/templates.h"
#include "internal/CPE.h"
#include "internal/CPE_communicator.h"
#include "internal/sptrf_common.h"
#include "internal/sptrf_param.h"
#include "internal/sptrf_cpe.h"


namespace swSparse {

template<typename DATA_T>
void pivot_permute_dense(DATA_T* val, const Int* ipiv, Int left_off, Int left_ncol, Int right_ncol, Int ld) NOTHROW {    
    for(Int krel = 0, k = left_off; krel < left_ncol; ++ krel, ++ k) {
        Int jj, kpiv = ipiv[krel];
        if(kpiv != k) {
            DATA_T* temp_val0 = val;
            for(jj = 1; jj < right_ncol; jj += 2, temp_val0 += 2 * ld) {
                DATA_T* temp_val1 = temp_val0 + ld;
                DATA_T temp0a = temp_val0[k], temp0b = temp_val0[kpiv];
                DATA_T temp1a = temp_val1[k], temp1b = temp_val1[kpiv];
                temp_val0[k] = temp0b;  temp_val0[kpiv] = temp0a; 
                temp_val1[k] = temp1b;  temp_val1[kpiv] = temp1a;
            }
            if(jj == right_ncol) {
                DATA_T temp0a = temp_val0[k], temp0b = temp_val0[kpiv];
                temp_val0[k] = temp0b; temp_val0[kpiv] = temp0a;
            }
        }
    }
}

template<typename DATA_T, typename GET_OFF>
inline void pivot_permute_U(DATA_T* u_val, const Int* ipiv, Int ipiv_off, Int ipiv_cols, Int nuseg, \
        current_seg_t* current_seg, GET_OFF&& val_off) NOTHROW {
    for(Int krel = 0, k = ipiv_off; krel < ipiv_cols; ++ krel, ++k) {
        Int jj, kpiv = ipiv[krel];
        ASSERT_LESS_EQUAL(0, kpiv);
        if(kpiv != k) {
            for(jj = 1; jj < nuseg; jj += 2) {
                DATA_T *u0 = u_val + val_off(current_seg[jj - 1]), *u1 = u_val + val_off(current_seg[jj]);
                DATA_T temp0a = u0[k], temp0b = u0[kpiv];
                DATA_T temp1a = u1[k], temp1b = u1[kpiv];
                u0[k] = temp0b; u1[k] = temp1b; u0[kpiv] = temp0a; u1[kpiv] = temp1a;
            }
            if(jj == nuseg) {
                DATA_T *u = u_val + val_off(current_seg[jj - 1]);
                DATA_T temp = u[k];
                u[k] = u[kpiv];
                u[kpiv] = temp;
            }
        }
    }
}

template<typename DATA_T>
void pivot_permute_U_seg(DATA_T* u_val, const Int* ipiv, Int ipiv_off, Int ipiv_cols, Int nuseg, current_seg_t* current_seg) NOTHROW {
    pivot_permute_U(u_val, ipiv, ipiv_off, ipiv_cols, nuseg, current_seg, [](const current_seg_t& s) { return s.val_off; });
}

template<typename DATA_T>
void pivot_permute_U_spa(DATA_T* spa, const Int* ipiv, Int ipiv_off, Int ipiv_cols, Int nuseg, current_seg_t* current_seg) NOTHROW {
    pivot_permute_U(spa, ipiv, ipiv_off, ipiv_cols, nuseg, current_seg, [](const current_seg_t& s) { return s.dense_pos; });
}


template<typename DATA_T>
NOINLINE void gather_by_indices_(Int n, const DATA_T* table, DATA_T* dst, const Int* indices);

template<typename DATA_T>
NOINLINE static void trf_numeric_kernel(void *p_args) {
#ifdef LU_CPE_PROFILE
    auto t1 = CRTS_stime_cycle();
#endif
    Int perturb_count, swap_count, id = CPE_ID;
    sptrf_arg_t<DATA_T> args, *arg_ptr = (sptrf_arg_t<DATA_T>*)p_args;
    trf_communicator comm(id);
    DMA_READ_NODESC(p_args, &args, sizeof(sptrf_arg_t<DATA_T>));
    perturb_count = subtree_part(args, comm.subtree_interface());
    if(id == scheduler_id) {
        queue_scheduler(args.task_queue, args.task_queue_size, args.subtree_offsets, \
            args.subtrees, args.sup2col, comm.scheduler_interface());
    } else {
        perturb_count += queue_worker(args, comm.worker_interface());
    }
    // `ipiv2iperm` calls `allreduce` which is internally synchronized
    // but will go wrong without this `CRTS_ssync_array`, why?
    CRTS_ssync_array();
    swap_count = ipiv2iperm(args.n, args.nsuper, args.sup2col, args.ipiv);  // internally synchronized
    swap_count = write_all_sum_int2(swap_count, perturb_count, arg_ptr->numstats);  // internally synchronized
    if(swap_count > 0) {
        Int nidx = args.l_i_off[args.nsuper];    
        flush_slave_cache();  // ipiv has become riperm, written by DMA, refresh the cache
        gather_by_indices_(nidx, args.ipiv, args.l_row_idx, args.l_row_idx);
    } 
#ifdef LU_CPE_PROFILE
    auto t2 = CRTS_stime_cycle();
    comm.print_profile(id, t2 - t1);
#endif
}

CPE_TEMPLATE_KERNEL(trf_numeric_kernel, CACHE_128KB)

#define INSTANTIATE(type) \
template void pivot_permute_dense<type>(type* , const Int* , Int , Int , Int , Int ) NOTHROW;\
template void pivot_permute_U_seg<type>(type* , const Int* , Int , Int , Int , current_seg_t* ) NOTHROW;\
template void pivot_permute_U_spa<type>(type* , const Int* , Int , Int , Int , current_seg_t* ) NOTHROW;

INSTANTIATE(float)
INSTANTIATE(double)
INSTANTIATE(SComplex)
INSTANTIATE(DComplex)
}