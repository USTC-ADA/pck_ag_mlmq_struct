#include "swSparse_trf.h"
#include "internal/memory.h"
#include "internal/rename.h"
#include "internal/templates.h"
#include "internal/utils.h"
#include "internal/CPE_blas_kernels.h"

namespace swSparse {
template <typename REAL_T>
void BLAS<complex<REAL_T>>::mm_update(Int left_col, Int right_col, Int nrow, CPLX_T* left, CPLX_T* right_up, CPLX_T* right_down) const {

}
template <typename REAL_T>
void BLAS<complex<REAL_T>>::mm_negative(Int left_col, Int right_col, Int nrow, CPLX_T* left, CPLX_T* right_up, CPLX_T* right_down) const {

}
template <typename REAL_T>
void BLAS<complex<REAL_T>>::l_trsm_update(Int left_col, Int right_col, Int nrow, CPLX_T* left, CPLX_T* right) const {
    
}
template <typename REAL_T>
void BLAS<complex<REAL_T>>::l_trsm_update_fact(Int left_col, Int right_col, CPLX_T* left, CPLX_T* right) const {
    
}
template <typename REAL_T>
void BLAS<complex<REAL_T>>::l_trsm_8x8(Int right_col, CPLX_T* left, CPLX_T* right) const {
    
}
template <typename REAL_T>
void BLAS<complex<REAL_T>>::ud_trsm(Int ncol, Int nrow, CPLX_T* right_up, CPLX_T* right_down) const {
    
}
template <typename REAL_T>
void BLAS<complex<REAL_T>>::mm_update_fact(Int left_col, Int right_col, Int nrow, CPLX_T* left, CPLX_T* right_up, CPLX_T* right_down) const {

}
template <typename REAL_T>
void BLAS<complex<REAL_T>>::rank8_update(Int right_col, Int nrow, CPLX_T* left, CPLX_T* right_up, CPLX_T* right_down) const {
    
}

#define INSTANTIATE_TEMPLATE(type) \
template void BLAS<type>::mm_update(Int, Int, Int, type*, type*, type*) const; \
template void BLAS<type>::mm_negative(Int, Int, Int, type*, type*, type*) const; \
template void BLAS<type>::l_trsm_update(Int, Int, Int, type*, type*) const; \
template void BLAS<type>::l_trsm_update_fact(Int, Int, type*, type*) const; \
template void BLAS<type>::l_trsm_8x8(Int, type*, type*) const; \
template void BLAS<type>::ud_trsm(Int, Int, type*, type*) const; \
template void BLAS<type>::mm_update_fact(Int, Int, Int, type*, type*, type*) const; \
template void BLAS<type>::rank8_update(Int, Int, type*, type*, type*) const;


} // namespace swSparse