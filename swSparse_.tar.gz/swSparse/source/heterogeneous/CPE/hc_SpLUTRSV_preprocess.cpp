#include <crts.h>
#include "internal/templates.h"
#include "internal/memory.h"
#include "internal/rename.h"
#include "internal/reorder.h"
#include "internal/utils.h"
#include "internal/debug.h"
#include "internal/splutrsv_param.h"
#include "swSparse_splutrsv.h"

namespace swSparse {

/* 
 *  estimate cost for each supernode
 */
void lutrsv_static_estimate_kernel(void* p_args) {
    lutrsv_static_estimate_arg_t args;
    DMA_READ_NODESC(p_args, &args, sizeof(lutrsv_static_estimate_arg_t));
    Int nsuper = args.nsuper;
    lutrsv_weight_t *lweight = args.lweight;
    lutrsv_weight_t *uweight = args.uweight;
    const swSparseLUSupernodes* lu = args.lu;
    // alpha: dense mem, beta: sparse mem
    const lutrsv_weight_t flop = args.flop, alpha = args.alpha, beta = args.beta;
    const Int *sup2col = lu->sup2col, *col2sup = lu->col2sup;
    const Int *l_v_offsets = lu->l_v_offsets,  *l_i_offsets = lu->l_i_offsets;
    const Int *u_col_offsets = lu->u_col_offsets, *u_seg_offsets = lu->u_seg_offsets;
    
    Int part_size = nsuper / CPE_FOR_LUTRSV;
    Int start = CRTS_tid * part_size;
    Int end = start + part_size;
    if(CRTS_tid == CPE_FOR_LUTRSV - 1) { 
        end = nsuper;
    }

    for(Int isup = start; isup < end; ++isup) {
        Int isup_begin = sup2col[isup], isup_end = sup2col[isup + 1];
        Int isup_useg_begin = u_col_offsets[isup_begin], isup_useg_end = u_col_offsets[isup_end];
        Int sc = isup_end - isup_begin;
        Int si = l_i_offsets[isup + 1] - l_i_offsets[isup];
        Int ss = isup_useg_end - isup_useg_begin;
        Int sv = u_seg_offsets[isup_useg_end] - u_seg_offsets[isup_useg_begin];
        // flops + dense mem + sparse mem
        // base: 4 * alpha
        // L: (sv + sc * sc / 2) * flop + (sv * 2 + sc * sc - ss) * alpha + ss * beta
        lweight[isup] = 4 * alpha + float(sv + sc * sc / 2) * (flop + 2 * alpha) + float(ss) * (beta - alpha);
        // U: (sv + sc * sc / 2) * flop + (sv * 2 + sc * sc - si) * alpha + si * beta
        uweight[isup] = 4 * alpha + float(si * sc + sc * sc / 2) * (flop + 2 * alpha) + float(si) * (beta - alpha);
    }

    if(CRTS_tid == CPE_FOR_LUTRSV - 1) {
        lweight[nsuper] = uweight[nsuper] = 0;
    }
}

CPE_CONCRETE_KERNEL(lutrsv_static_estimate_kernel, CACHE_IGNORE)

/*
 * 并行 iperm，在 hm_reorder.cpp 中只有串行版本
 */
template<typename DATA_T>
void lutrsv_iperm_kernel(void* p_args) {
    lutrsv_iperm_arg_t<DATA_T> args;
    DMA_READ_NODESC(p_args, &args, sizeof(lutrsv_iperm_arg_t<DATA_T>));
    Int n = args.n;
    const DATA_T* src = args.src;
    DATA_T* dst = args.dst;
    const Int* iperm = args.iperm;

    Int size = n / CPE_FOR_LUTRSV;
    Int begin = size * CRTS_tid;
    Int end = (CRTS_tid == 63) ? n : (begin + size);

    for(Int i = begin; i < end; ++i) {
        dst[iperm[i]] = src[i];
    }
}

CPE_TEMPLATE_KERNEL(lutrsv_iperm_kernel, CACHE_IGNORE)

}