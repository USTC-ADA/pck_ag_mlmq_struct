#include "swSparse_base.h"
#include "internal/rename.h"
#include "internal/CPE.h"
#include "internal/utils.h"
#include "internal/CPE_utils.h"
#include "internal/transform.h"

#define READ_BLOCK_SIZE 256
#define BUFFER_SIZE 256
#define CORE_NUM 64

extern "C" void swSparse_off2idx_kernel(void* ptr){
    off2idx_arg_t info;
    Int m;
    Int id = memory_channel_mapping(CPE_ID);
    Int offset[READ_BLOCK_SIZE];
    Int idx[BUFFER_SIZE];
    Int count = 0;
    Int i, j, k = 0;

    DMA_DECL_DESC(READ_WRITE);
    DMA_READ(ptr, &info, sizeof(off2idx_arg_t));
    m = info.m;

    for(i = id*(READ_BLOCK_SIZE-1); i < m; i += CORE_NUM*(READ_BLOCK_SIZE-1))
    {
        Int element_num = min(READ_BLOCK_SIZE, m+1-i);
        DMA_READ(info.offset+i, offset, element_num*sizeof(Int));
        for(j = 0; j < element_num-1; j++)
        {
            for(k = offset[j]; k < offset[j+1]; k++)
            {
                idx[count++] = i+j;
                if(count == BUFFER_SIZE)
                {
                    DMA_WRITE(info.idx+k+1-BUFFER_SIZE, idx, BUFFER_SIZE*sizeof(Int));
                    count = 0;
                }
            }
        }
        
        if(count > 0)
        {
            DMA_WRITE(info.idx+k-count, idx, count*sizeof(Int));
            count = 0;
        }
    }    
    
}

extern "C" void swSparse_idx2off_kernel(void* ptr) {
    idx2off_arg_t info;
    Int id = memory_channel_mapping(CPE_ID);
    Int idx[READ_BLOCK_SIZE+2];
    Int offset[BUFFER_SIZE];
    Int count = 0, i, j, k = 0;

    DMA_DECL_DESC(READ_WRITE);
    DMA_READ(ptr, &info, sizeof(idx2off_arg_t));
    Int m = info.m;
    Int nnz = info.nnz;
    Int t = max(ceiling_sra(nnz, 6), 64), begin = t * id, end = min(nnz, begin + t + 1);

    idx[0] = -1;
    for(i = begin; (i < end) || (i == 0); i += (READ_BLOCK_SIZE-1)) {
        Int element_num = min(READ_BLOCK_SIZE, end - i);
        if(element_num > 0) {
            DMA_READ(info.idx + i, idx + 1, element_num*sizeof(Int));
        }
        if(element_num + i == nnz) {
            idx[++element_num] = m;
        }
        for(j = ((i == 0) ? 0 : 1); j < element_num; j++) {
            for(k = idx[j] + 1; k <= idx[j + 1]; k++) {
                offset[count++] = i + j;
                if(count == BUFFER_SIZE) {
                    DMA_WRITE(info.offset + k + 1 - BUFFER_SIZE, offset, BUFFER_SIZE*sizeof(Int));
                    count = 0;
                }
            }
        }
    }
    if(count > 0) {
        DMA_WRITE(info.offset + k - count, offset, count*sizeof(Int));
    }    
}

