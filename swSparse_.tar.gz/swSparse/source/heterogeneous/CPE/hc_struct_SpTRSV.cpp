#include <stdio.h>
#include <slave.h>
#include <simd.h>
#include "internal/comm.h"
#include "internal/CPE.h"
#include <crts.h>
#include "internal/utils.h"
#include "internal/Grid.h"
#include "internal/stsSpTRSV.h"
#include "math.h"

//#define PERF
//#define PERF_COND
#define CONDITION (j < 8)


template<typename DATA_T>
NOINLINE void struct_sptrsv_cross_f(const DATA_T *a, DATA_T *x, const DATA_T *b, int M, int N, int L, \
int nnz, int halo, int cols, int *p, int *col_m, int *off_m)
{
    #ifdef PERF
    unsigned long time1, time2, time3, time4, time5, time6;
    double dmatime = 0, caltime = 0, waittime = 0, rmatime = 0, rmatruetime = 0;
    double totaltime = 0;
    double total_tmp, cal_tmp, wait_tmp, rma_tmp;
    #endif
    strTRSV_params<sizeof(DATA_T)> params;
    const int GRA = params.GRA;
    //const int LM = params.LM;

    int K = params.LM;     //vertical block size
    int gra = GRA / sizeof(DATA_T);    //granuity of communication, should be a factor of K ***
    int vec = GRA / sizeof(DATA_T);
    int nnz2 = nnz * 2, nnz3 = nnz * 3, nnz4 = nnz * 4, \
    nnz5 = nnz * 5, nnz6 = nnz * 6, nnz7 = nnz * 7;

    K = L + (8 - L % 8);

    int oneLEN = 0;
    if (K >= L) oneLEN = 1;

    int overlap = gridmin(K, L);

    //cross partition
    int id, row, col;
    id = CRTS_smng_get_tid();
    row = (CRTS_smng_get_rid()) % ROW_P;
    col = (CRTS_smng_get_cid()) % COL_P;

    //debug
    int pflag = 0;
    if (id == 0) pflag = 1;

    int halo2 = 2 * halo;
    int row_num = 8, col_num = 8;

    //DMA reply
    crts_rply_t rply = 0;
    int dmas = 0;
    
    //buffer
    __attribute((aligned(256))) DATA_T x_buf[cols + 1][K + halo2 + 8];
    __attribute((aligned(256))) DATA_T res_buf[3][K + halo2 + 8];
    __attribute((aligned(256))) DATA_T a_buf[2][K * nnz];

    //column id and vertical offset
    int col_t[nnz];
    int offset_t[nnz];
    int pos[2*cols];

    //buffer communication
    volatile int done_k[cols]; //neighbour_done_signal
    volatile int recv_k[cols]; //neighbour_receive_signal
    int local_done_k[cols]; //to avoid sychronization problem
    int local_recv_k[cols]; //to avoid sychronization problem

    int done_offset[cols];
    int recv_offset[cols];

    //dma communication
    volatile int dma_done[cols];
    int dma_id[cols];
    int dma_check[cols];
    int dma_dii[cols], dma_djj[cols];

    //whether communication is needed
    int fneed[cols];
    int bneed[cols];

    //communication id
    int bid[cols], fid[cols];
    int *baddr[cols], *faddr[cols];

    int res_id = 0;
    int a_id = 0;

    CRTS_DMA_IGET(pos, p, 2 * cols * sizeof(int), &rply);
    CRTS_DMA_IGET(col_t, col_m, nnz * sizeof(int), &rply);
    CRTS_DMA_IGET(offset_t, off_m, nnz * sizeof(int), &rply);
    dmas += 3;
    CRTS_dma_wait_value(&rply, dmas);

    //double cache
    int lasti = -1, lastj = -1;
    int lastk = (L - 1) / K * K;
    int lastlen = L - lastk;

    int i, j, k;
    int u, v;

    int no_cols_nnz = 0;
    u = 0;
    while (u < nnz && col_t[u] != cols) u++;
    no_cols_nnz = u;

    int count = -1;
    for (u = 0; u < cols; u++)
    {
        recv_k[u] = done_k[u] = -1;
        dma_done[u] = -1;
        local_recv_k[u] = 0;
        local_done_k[u] = 0;
    }

    // calculate id
    for (u = 0; u < cols; u++)
    {
        int di = pos[u*2], dj = pos[u*2+1];
        int ti = row + di, tj = col + dj;
        if (oneLEN && ti < 0)
        {
            dma_check[u] = 1;
        }
        else
            dma_check[u] = 0;
        done_offset[u] = 0;

        fid[u] = CAL_ID(ti, tj);
        if (!oneLEN && fid[u] == -1)
        {
            dma_check[u] = 1;
        }
        if (dma_check[u])
        {
            if (ti < 0) dma_dii[u] = -1; else dma_dii[u] = 0;
            if (tj < 0) dma_djj[u] = -1; else dma_djj[u] = 0;
        }

        ti = row - di, tj = col - dj;
        if (fid[u] != -1) faddr[u] = remote_ldm_addr(&done_k[u], fid[u]);
        if (oneLEN && ti >= row_num)
        {
            dma_id[u] = CAL_ID(ti - row_num, (tj + col_num) % col_num);
        }
        else
            dma_id[u] = -1;
        recv_offset[u] = 0;
        bid[u] = CAL_ID(ti, tj);
        if (!oneLEN && bid[u] == -1) dma_id[u] = CAL_ID((ti + row_num) % row_num, (tj + col_num) % col_num);
        if (bid[u] != -1) baddr[u] = remote_ldm_addr(&recv_k[u], bid[u]);
    }

    for (u = 0; u < cols; u++)
    {
        if (fid[u] == -1)
        {
            local_recv_k[u] = M * N * L;
            local_done_k[u] = M * N * L;
        }
    }

#ifndef __sw_slave__
    _ldm_base[id] = (volatile void*)&done_k[0];
#endif
    CRTS_ssync_array();

    #ifdef PERF
        time3 = CRTS_stime_cycle();
    #endif

    //M/N_iter iterations have to be done anyway
    int M_iter, N_iter, L_iter;
    M_iter = (M + row_num - 1) / row_num;
    N_iter = (N + col_num - 1) / col_num;
    L_iter = (L + K - 1) / K;

    //first column
    if (VALID(row, col, 0, M, N, 1))
    {
        int nextlen = gridmin(L, K);
        dmas += 2;
        CRTS_DMA_IGET(a_buf[a_id], a + INDEX3(row, col, 0, N, L) * nnz, nextlen * nnz * sizeof(DATA_T), &rply);
        CRTS_DMA_IGET(res_buf[res_id] + halo, b + INDEX3(row, col, 0, N, L), nextlen * sizeof(DATA_T), &rply);
    }

    //main loop
    for (int ii = 0; ii < M_iter; ii++)
    {
    for (int jj = 0; jj < N_iter; jj++)
    {
        i = ii * row_num + row;
        j = jj * col_num + col;

        CRTS_ssync_array();

        for (u = 0; u < cols; u++)
        for (v = 0; v < halo; v++)
            x_buf[u][v] = 0;

        for (v = 0; v < halo; v++)
        {
            res_buf[res_id][v] = 0;
        }

    if (VALID(i, j, 0, M, N, 1))
    {
        //*****************main part*****************//

        //fneed = need to recv from, bneed = need to send to
        for (u = 0; u < cols; u++)
        {
            int di = pos[u*2], dj = pos[u*2+1];
            int ti = i + di, tj = j + dj;
            if (VALID(ti, tj, 0, M, N, 1)) fneed[u] = 1; else fneed[u] = 0;
            if (fid[u] == -1 || !fneed[u]) local_recv_k[u] += L;

            ti = i - di, tj = j - dj;
            if (VALID(ti, tj, 0, M, N, 1)) bneed[u] = 1; else bneed[u] = 0;
            if (bid[u] != -1 && !bneed[u]) recv_offset[u] -= L;
        }

        int count_max = count + L;

        //vertical block size K
        for (k = 0; k < L; k+=K)
        {
            int len = gridmin(L - k, K);

            #ifdef PERF
                time1 = CRTS_stime_cycle();
            #endif

            //DMA other columns
            int len_halo = gridmin(len + halo, L - k);
            for (u = 0; u < cols; u++)
            {
                if (fid[u] == -1 && fneed[u] == 1)
                {
                    if (dma_check[u])
                    {
                        int halo_block_id = (ii + dma_dii[u]) * N_iter * L_iter + (jj + dma_djj[u]) * L_iter + k/K;
                        while (dma_done[u] < halo_block_id);
                        // if (id == 0) {
                        //     printf("i %d j %d u %d dma_done %d\n", i, j, u, dma_done[u]);
                        // }
                    }

                    int di = pos[u*2], dj = pos[u*2+1];
                    int ti = i + di, tj = j + dj;
                    CRTS_DMA_IGET(x_buf[u] + halo, x + INDEX3(ti, tj, k, N, L), len_halo * sizeof(DATA_T), &rply);
                    dmas++;
                }
                else if (fneed[u] == 0)
                {
                    for (v = 0; v < K + halo; v++)
                        x_buf[u][v + halo] = 0;
                }
            }

            //DMA A & b
            CRTS_dma_wait_value(&rply, dmas);

            if (k + len >= L)
            {
                //ti, tj indicate next column position
                int ti = i, tj = j + col_num;
                if (tj >= N)
                {
                    ti = ti + row_num;
                    tj = col;
                }
                if (VALID(ti, tj, 0, M, N, 1))
                {
                    int nextlen = gridmin(K, L);
                    dmas += 2;
                    CRTS_DMA_IGET(a_buf[(a_id+1)%2], a + INDEX3(ti, tj, 0, N, L) * nnz, nextlen * nnz * sizeof(DATA_T), &rply);
                    CRTS_DMA_IGET(res_buf[(res_id+1)%3] + halo, b + INDEX3(ti, tj, 0, N, L), nextlen * sizeof(DATA_T), &rply);
                }
            }
            else
            {
                int nextlen = gridmin(L - k - len, K);
                dmas += 2;
                CRTS_DMA_IGET(a_buf[(a_id+1)%2], a + INDEX3(i, j, k + len, N, L) * nnz, nextlen * nnz * sizeof(DATA_T), &rply);
                CRTS_DMA_IGET(res_buf[(res_id+1)%3] + halo, b + INDEX3(i, j, k + len, N, L), nextlen * sizeof(DATA_T), &rply);
            }

            #ifdef PERF
                time2 = CRTS_stime_cycle();
            #ifdef PERF_COND
                if (CONDITION)
            #endif
                dmatime += time2 - time1;
            #endif

            int c;

            //calculation loop, vectorized
            int commu_index = halo;
            for (c = 0; c < len; c+=vec)
            {
                #ifdef PERF
                    time1 = CRTS_stime_cycle();
                #endif

                count += vec;
                if (c + vec > len) count -= c + vec - len;

                //wait until data is ready
                int flag = 1;

                while(flag)
                {
                    flag = 0;
                    for (u = 0; u < cols; u++)
                    {
                        if (recv_k[u] + local_recv_k[u] < gridmin(count + halo, count_max))
                            flag = 1;
                    }
                }

                // little problem of upper halo
                if (c + vec > len - 1 - halo)
                {
                    if (k + K < L)
                    {
                        for (u = 0; u < cols; u++)
                            for (v = 0; v < halo; v++)
                                x_buf[u][v + K + halo] = x_buf[u][v + halo];
                    }
                    else
                    {
                        for (u = 0; u < cols; u++)
                            for (v = 0; v < halo; v++)
                                x_buf[u][v + len + halo] = 0;
                    }
                }

                simd_t<DATA_T> res, atmp, xtmp;
                vec_loadu(res, res_buf[res_id] + c + halo);
                for (u = 0; u < no_cols_nnz; u++)
                {
                    //atmp = simd_set_a_nnz(a_buf[a_id] + c * nnz + u);
                    atmp = params.simd_set_nnz(a_buf[a_id] + c * nnz + u ,  nnz, nnz2, nnz3, nnz4, nnz5, nnz6, nnz7);
                    vec_loadu(xtmp, x_buf[col_t[u]] + c + offset_t[u] + halo);
                    res = res - atmp * xtmp;
                }
                vec_storeu(res, res_buf[res_id] + c + halo);

                if (no_cols_nnz < nnz)
                {
                    for (v = 0; v < vec; v++)
                    {
                        for (u = no_cols_nnz; u < nnz; u++)
                        {
                            res_buf[res_id][c + v + halo] -= a_buf[a_id][(c + v)* nnz + u]* res_buf[res_id][c + offset_t[u] + v + halo];
                        }
                    }
                }

                //inform forward slave
                for (u = 0; u < cols; u++)
                {
                    if (fid[u] != -1)
                    {

                        *(faddr[u]) = count + done_offset[u];

                    }
                }

                // u == 0;
                for (u = cols - 1; u >= 0; u--)
                {

                    if (bid[u] != -1 && bneed[u])
                    {
                        while ((count - (done_k[u] + local_done_k[u])) \
                        >= overlap - halo - vec);

                        rstore8(res_buf[res_id] + commu_index, x_buf[u] + commu_index, bid[u]);

                        mem_fence();
                        *(baddr[u]) = count + recv_offset[u];
                    }
                }
                commu_index += gra;

            }

            dmas++;
            CRTS_dma_iput(x + INDEX3(i, j, k, N, L), res_buf[res_id] + halo, len * sizeof(DATA_T), &rply);
            CRTS_dma_wait_value(&rply, dmas);
            //inform halo dma threads
            for (u = 0; u < cols; u++)
            {
                if (dma_id[u] != -1)
                {
                    int *remote_id = remote_ldm_addr(&dma_done[u], dma_id[u]);
                    (*remote_id) = ii * N_iter * L_iter + jj * L_iter + k/K;
                }
            }

            //post
            if (!oneLEN)
            {
                for (u = 0; u < cols; u++)
                {
                    for (v = 0; v < halo; v++)
                    {
                        x_buf[u][v] = x_buf[u][v + K];
                    }
                }
                for (v = 0; v < halo; v++)
                    res_buf[(res_id+1)%3][v] = res_buf[res_id][v + K];
            }

            a_id = (a_id + 1) % 2;
            res_id = (res_id + 1) % 3;
        }

        lasti = i;
        lastj = j;

    }
    else
    {
        count += L;
        for (u = 0; u < cols; u++)
        {
            local_recv_k[u] += L;
            local_done_k[u] += L;
            recv_offset[u] -= L;
            if (fid[u] != -1)
            {

                *(faddr[u]) = count + done_offset[u];

            }
        }
    }

    }
    }

    CRTS_ssync_array();

    #ifdef PERF
        time4 = CRTS_stime_cycle();
    #ifdef PERF_COND
        if (CONDITION)
    #endif
        totaltime += time4 - time3;
    #endif

    #ifdef PERF
        int totalcols = M_iter * N_iter * L;
    #ifdef PERF_COND
        totalcols = L;
    #endif
        double dma = dmatime / totalcols, wait = waittime / totalcols, \
        cal = caltime / totalcols, rma = rmatime / totalcols, \
        rmatrue = rmatruetime;
        double mytime = totaltime / totalcols;
        if (id == 0)
        {
            printf("id: %d dma  average cycles: %.4f\n", id, dma);
            printf("id: %d wait average cycles: %.4f\n", id, wait);
            printf("id: %d cal  average cycles: %.4f\n", id, cal);
            printf("id: %d rma  average cycles: %.4f\n", id, rma);
            //printf("id: %d rma true average cycles: %.4f\n", id, rmatrue);
            printf("id: %d total average cycles: %.4f\n", id, mytime);
            printf("id: %d total time: %.10f\n", id, totaltime / 2.25 / 1000 / 1000 / 1000);
        }
        if (id == 0)
        {
            double Gflops = 1.0 * M * N * L * 2 * nnz / 1024 / 1024 / 1024;
            double Gmems  = 1.0 * M * N * L * (nnz + 2) * sizeof(DATA_T) / 1024 / 1024 / 1024;
            double total_time = totaltime / 2.25 / 1000 / 1000 / 1000;
            printf("id: %d total time:       %.6f\n", id, total_time);
            printf("id: %d Gflops:           %.6f\n", id, Gflops / total_time);
            printf("id: %d Memory bandwidth: %.6f\n", id, Gmems / total_time);
        }
    #endif
}

template<typename DATA_T>
NOINLINE void struct_sptrsv_cross_entry(void *_info)
{
    struct_info<DATA_T> info;

	CRTS_dma_get(&info, _info, sizeof(info));
    struct_sptrsv_cross_f(info.a, info.x, info.b, info.M, info.N, info.L, info.nnz, info.halo, info.cols, info.p, info.col_id, info.z_off);
}

#undef PERF

template<typename DATA_T>
NOINLINE void struct_back_sptrsv_cross_f(const DATA_T *a, DATA_T *x, const DATA_T *b, int M, int N, int L, \
int nnz, int halo, int cols, int *p, int *col_m, int *off_m)
{
    #ifdef PERF
    unsigned long time1, time2, time3, time4, time5, time6;
    double dmatime = 0, caltime = 0, waittime = 0, rmatime = 0, rmatruetime = 0;
    double totaltime = 0;
    double total_tmp, cal_tmp, wait_tmp, rma_tmp;
    #endif

    strTRSV_params<sizeof(DATA_T)> params;
    const int GRA = params.GRA;

    int K = params.LM;     //vertical block size
    int gra = GRA / sizeof(DATA_T);    //granuity of communication, should be a factor of K ***
    int vec = GRA / sizeof(DATA_T);
    int nnz2 = nnz * 2, nnz3 = nnz * 3, nnz4 = nnz * 4, \
    nnz5 = nnz * 5, nnz6 = nnz * 6, nnz7 = nnz * 7;

    int oneLEN = 0;
    K = L + (8 - L % 8);
	if (K >= L) oneLEN = 1;
     
    int overlap = gridmin(K, L);

    //cross partition
    int id, row, col;
    id = CRTS_smng_get_tid();
    row = (CRTS_smng_get_rid()) % ROW_P;
    col = (CRTS_smng_get_cid()) % COL_P;

    //debug
    int pflag = 0;
    if (id == 0) pflag = 1;

    int halo2 = 2 * halo;
    int row_num = 8, col_num = 8;

    //DMA reply
    crts_rply_t rply = 0;
    int dmas = 0;
    
    //buffer
    __attribute((aligned(256))) DATA_T x_buf[cols + 1][K + halo2 + 8];
    __attribute((aligned(256))) DATA_T res_buf[3][K + halo2 + 8];
    __attribute((aligned(256))) DATA_T a_buf[2][K * nnz];

    //column id and vertical offset
    int col_t[nnz];
    int offset_t[nnz];
    int pos[2*cols];

    //buffer communication
    volatile int done_k[cols]; //neighbour_done_signal
    volatile int recv_k[cols]; //neighbour_receive_signal
    int local_done_k[cols]; //to avoid sychronization problem
    int local_recv_k[cols]; //to avoid sychronization problem

    int done_offset[cols];
    int recv_offset[cols];

    //dma communication
    volatile int dma_done[cols];
    int dma_id[cols];
    int dma_check[cols];
    int dma_dii[cols], dma_djj[cols];
    
    //whether communication is needed
    int fneed[cols];
    int bneed[cols];

    //communication id
    int bid[cols], fid[cols];
    int *baddr[cols], *faddr[cols];

    int res_id = 0;
    int a_id = 0;

    CRTS_DMA_IGET(pos, p, 2 * cols * sizeof(int), &rply);
    CRTS_DMA_IGET(col_t, col_m, nnz * sizeof(int), &rply);
    CRTS_DMA_IGET(offset_t, off_m, nnz * sizeof(int), &rply);
    dmas += 3;
    CRTS_dma_wait_value(&rply, dmas);

    //double cache
    int lasti = -1, lastj = -1;
    int lastk = (L - 1) / K * K;
    int lastlen = L - lastk;

    int i, j, k;
    int u, v;
	
	
	int count=-1;
    int no_cols_nnz = 0;
    u = nnz-1;
    while (u >= 0 && col_t[u] != cols) {
		u--;
	}
    no_cols_nnz = nnz - 1 - u;

    for (u = 0; u < cols; u++)
    {
        recv_k[u] = done_k[u] = -1;
        dma_done[u] = -1;
        local_recv_k[u] = 0;
        if(L<32)
			local_recv_k[u] = 0;
        local_done_k[u] = 0;
    }

    // calculate id
    for (u = 0; u < cols; u++)
    {
        int di = pos[u*2], dj = pos[u*2+1];
        int ti = row + di, tj = col + dj;
        if (oneLEN && ti < 0)
        {
            dma_check[u] = 1;
        }
        else
            dma_check[u] = 0;
        done_offset[u] = 0;

        fid[u] = CAL_ID(ti, tj);
        if (!oneLEN && fid[u] == -1)
        {
            dma_check[u] = 1;
        }
        if (dma_check[u])
        {
            if (ti < 0) dma_dii[u] = -1; else dma_dii[u] = 0;
            if (tj < 0) dma_djj[u] = -1; else dma_djj[u] = 0;
        }

        ti = row - di, tj = col - dj;
        if (fid[u] != -1) faddr[u] = remote_ldm_addr(&done_k[u], fid[u]);
        if (oneLEN && ti >= row_num)
        {
            dma_id[u] = CAL_ID(ti - row_num, (tj + col_num) % col_num);
        }
        else
            dma_id[u] = -1;
        recv_offset[u] = 0;
        bid[u] = CAL_ID(ti, tj);
        if (!oneLEN && bid[u] == -1) dma_id[u] = CAL_ID((ti + row_num) % row_num, (tj + col_num) % col_num);
    if (bid[u] != -1) baddr[u] = remote_ldm_addr(&recv_k[u], bid[u]);
    }

    for (u = 0; u < cols; u++)
    {
        if (fid[u] == -1)
        {
            local_recv_k[u] = M * N * L;
            local_done_k[u] = M * N * L;
        }
    }
    
#ifndef __sw_slave__
    _ldm_base[id] = (volatile void*)&done_k[0];
#endif
    CRTS_ssync_array();

    #ifdef PERF
        time3 = CRTS_stime_cycle();
    #endif
    
    //M/N_iter iterations have to be done anyway
    int M_iter, N_iter, L_iter;
    M_iter = (M + row_num - 1) / row_num;
    N_iter = (N + col_num - 1) / col_num;
    L_iter = (L + K - 1) / K;

    int nextlen = gridmin(L, K);
    int buf_off=K-nextlen+halo;
    //first column
    if (VALID(row, col, 0, M, N, 1))
    {
        dmas += 2;
        CRTS_DMA_IGET(a_buf[a_id], a + (M*N*L-INDEX3(row, col, 0, N, L)) * nnz - nextlen*nnz, nextlen * nnz * sizeof(DATA_T), &rply);
        CRTS_DMA_IGET(res_buf[res_id] + buf_off, b + M*N*L-INDEX3(row, col, 0, N, L)-nextlen, nextlen * sizeof(DATA_T), &rply);
    }

    //main loop
    for (int ii = 0; ii < M_iter; ii++)
    {
    for (int jj = 0; jj < N_iter; jj++)
    {
        i = ii * row_num + row;
        j = jj * col_num + col;

        CRTS_ssync_array();

        for (u = 0; u < cols; u++)
        for (v = 0; v < buf_off; v++)
            x_buf[u][v] = 0;

        for (v = 0; v < buf_off; v++)
        {
            res_buf[res_id][v] = 0;
        }

    if (VALID(i, j, 0, M, N, 1))
    {
        //*****************main part*****************//
	//	printf("i=%d,j=%d????\n",i,j);
        //fneed = need to recv from, bneed = need to send to
        for (u = 0; u < cols; u++)
        {
            int di = pos[u*2], dj = pos[u*2+1];
            int ti = i + di, tj = j + dj;
            if (VALID(ti, tj, 0, M, N, 1)) fneed[u] = 1; else fneed[u] = 0;
            if (fid[u] == -1 || !fneed[u]) local_recv_k[u] += L;

            ti = i - di, tj = j - dj;
            if (VALID(ti, tj, 0, M, N, 1)) bneed[u] = 1; else bneed[u] = 0;
            if (bid[u] != -1 && !bneed[u]) recv_offset[u] -= L;
        }

        int count_max = count + L;

        //vertical block size K
        for (k = 0; k < L; k+=K)
        {
		//	count=L;
            int len = gridmin(L - k, K);

            #ifdef PERF
                time1 = CRTS_stime_cycle();
            #endif

            //DMA other columns
            int len_halo = gridmin(len + halo, L - k);
			int off_up;
			if(k+K>L-1)
				off_up=0;
			else
				off_up=gridmin(L-k-K,halo);
			buf_off=K-len+halo;
            for (u = 0; u < cols; u++)
            {
                if (fid[u] == -1 && fneed[u] == 1)
                {
                    if (dma_check[u])
                    {
                        int halo_block_id = (ii + dma_dii[u]) * N_iter * L_iter + (jj + dma_djj[u]) * L_iter + k/K;
                        while (dma_done[u] < halo_block_id);
                        // if (id == 0) {
                        //     printf("i %d j %d u %d dma_done %d\n", i, j, u, dma_done[u]);
                        // }
                    }

                    int di = pos[u*2], dj = pos[u*2+1];
                    int ti = i + di, tj = j + dj;
                    CRTS_DMA_IGET(x_buf[u] + buf_off, x + M*N*L- INDEX3(ti, tj, k, N, L)-len, len * sizeof(DATA_T), &rply);
                    dmas++;
                }
                else if (fneed[u] == 0)
                {
                    for (v = 0; v < K + halo; v++)
                        x_buf[u][v + halo] = 0;
                }
            }

            //DMA A & b
            CRTS_dma_wait_value(&rply, dmas);

            if (k + len >= L)
            {
                //ti, tj indicate next column position
                int ti = i, tj = j + col_num;
                if (tj >= N)
                {
                    ti = ti + row_num;
                    tj = col;
                }
                if (VALID(ti, tj, 0, M, N, 1))
                {
                    nextlen = gridmin(K, L);
                    dmas += 2;
                    CRTS_DMA_IGET(a_buf[(a_id+1)%2], a +(M*N*L- INDEX3(ti, tj, 0, N, L)) * nnz-nextlen*nnz, nextlen * nnz * sizeof(DATA_T), &rply);
                    CRTS_DMA_IGET(res_buf[(res_id+1)%3] + buf_off, b + M*N*L-INDEX3(ti, tj, 0, N, L)-nextlen, nextlen * sizeof(DATA_T), &rply);
                }
            }
            else
            {
                nextlen = gridmin(L - k - len, K);
                dmas += 2;
                CRTS_DMA_IGET(a_buf[(a_id+1)%2], a + (M*N*L-INDEX3(i, j, k + len, N, L)) * nnz-nextlen*nnz, nextlen * nnz * sizeof(DATA_T), &rply);
                CRTS_DMA_IGET(res_buf[(res_id+1)%3] + buf_off, b + M*N*L-INDEX3(i, j, k + len, N, L)-nextlen, nextlen * sizeof(DATA_T), &rply);
            }

            #ifdef PERF
                time2 = CRTS_stime_cycle();
            #ifdef PERF_COND
                if (CONDITION)
            #endif
                dmatime += time2 - time1;
            #endif

            int c;

            //calculation loop, vectorized
            int commu_index = len-gra;//halo;
            for (c = len-vec; c > -vec; c-=vec)
            {
			    //buf_off=K-len+halo;
                #ifdef PERF
                    time1 = CRTS_stime_cycle();
                #endif

                count +=  vec;
                //if (c < 0) count -= c;
                if (len-vec-c + vec > len) count -= len-vec-c + vec - len;

                //wait until data is ready
                int flag = 1;

                while(flag)
                {
                    flag = 0;
                    for (u = 0; u < cols; u++)
					{
                        if (recv_k[u] + local_recv_k[u] < gridmin(count + halo, count_max))
                            flag = 1;
                    }
                }

                // little problem of upper halo
                if (len-vec-c + vec > len - 1 - halo)
                {
                    if (k + K < L)
                    {
                        for (u = 0; u < cols; u++)
                            for (v = 0; v < halo; v++)
                                x_buf[u][v + K + halo] = x_buf[u][v + halo];
                    }
                    else
                    {
                        for (u = 0; u < cols; u++)
                            for (v = 0; v < halo; v++)
                                x_buf[u][v + len + buf_off] = 0;
                    }
                }

                simd_t<DATA_T> res, atmp, xtmp;
                vec_loadu(res, res_buf[res_id] + c + buf_off);
                for (u = nnz-1;u > nnz-1-no_cols_nnz; u--)
                {
                    //atmp = simd_set_a_nnz(a_buf[a_id] + c * nnz + u);
                    atmp = params.simd_set_nnz(a_buf[a_id] + c * nnz + u ,  nnz, nnz2, nnz3, nnz4, nnz5, nnz6, nnz7);
                    vec_loadu(xtmp, x_buf[col_t[u]] + c + offset_t[u] + buf_off);
                    res = res - atmp * xtmp;
                }
                vec_storeu(res, res_buf[res_id] + c + buf_off);
				DATA_T para=1.0;//a_buf[c*nnz];//1.0;
                if (no_cols_nnz < nnz)
                {
				//	printf("进啦！\n");
					for(v=vec-1;v>=0;v--)
                    {	
						if(c+v<0) break;
						//DATA_T tmp=0.0;
                        for (u = nnz-1-no_cols_nnz; u >=0; u--)
                        {
							
						    if(offset_t[u]==0){
								para=a_buf[a_id][(c+v)*nnz+u];
				      //          res_buf[res_id][c+v+buf_off]/=para;
							}
							else{
                              res_buf[res_id][c + v + buf_off] -= a_buf[a_id][(c + v)* nnz + u]* res_buf[res_id][c + offset_t[u] + v + buf_off];
                             }
					     }
                    }
                }

                //inform forward slave
                for (u = 0; u < cols; u++)
                {
                    if (fid[u] != -1)
                    {

                        *(faddr[u]) = count + done_offset[u];

                    }
                }
                // u == 0;
                for (u = cols - 1; u >= 0; u--)
                {

                    if (bid[u] != -1 && bneed[u])
                    {
					//	local_done_k[u]+=L;
                        while ((count - (done_k[u] + local_done_k[u])) \
                        >= overlap - halo - vec){
						}

                        rstore8(res_buf[res_id] +buf_off+ commu_index, x_buf[u] + buf_off+commu_index, bid[u]);

                        mem_fence();
                        *(baddr[u]) = count + recv_offset[u];
                    }
                }
                commu_index -= gra;

            }

            dmas++;
            CRTS_dma_iput(x + M*N*L-INDEX3(i, j, k, N, L)-len, res_buf[res_id] + buf_off, len * sizeof(DATA_T), &rply);
            CRTS_dma_wait_value(&rply, dmas);
            //inform halo dma threads
            for (u = 0; u < cols; u++)
            {
                if (dma_id[u] != -1)
                {
                    int *remote_id = remote_ldm_addr(&dma_done[u], dma_id[u]);
                    (*remote_id) = ii * N_iter * L_iter + jj * L_iter + k/K;
                }
            }

            //post
            if (!oneLEN)
            {
                for (u = 0; u < cols; u++)
                {
                    for (v = 0; v < halo; v++)
                    {
                        x_buf[u][v] = x_buf[u][v + K];
                    }
                }
                for (v = 0; v < halo; v++)
                    res_buf[(res_id+1)%3][v] = res_buf[res_id][v + K];
            }

            a_id = (a_id + 1) % 2;
            res_id = (res_id + 1) % 3;
        }

        lasti = i;
        lastj = j;

    }
    else
    {
        count += L;
        for (u = 0; u < cols; u++)
        {
            local_recv_k[u] += L;
            local_done_k[u] += L;
            recv_offset[u] -= L;
            if (fid[u] != -1)
            {

                *(faddr[u]) = count + done_offset[u];

            }
        }
    }

    }
    }

    CRTS_ssync_array();

    #ifdef PERF
        time4 = CRTS_stime_cycle();
    #ifdef PERF_COND
        if (CONDITION)
    #endif
        totaltime += time4 - time3;
    #endif

    #ifdef PERF
        int totalcols = M_iter * N_iter * L;
    #ifdef PERF_COND
        totalcols = L;
    #endif
        double dma = dmatime / totalcols, wait = waittime / totalcols, \
        cal = caltime / totalcols, rma = rmatime / totalcols, \
        rmatrue = rmatruetime;
        double mytime = totaltime / totalcols;
        if (id == 0)
        {
            printf("id: %d dma  average cycles: %.4f\n", id, dma);
            printf("id: %d wait average cycles: %.4f\n", id, wait);
            printf("id: %d cal  average cycles: %.4f\n", id, cal);
            printf("id: %d rma  average cycles: %.4f\n", id, rma);
            //printf("id: %d rma true average cycles: %.4f\n", id, rmatrue);
            printf("id: %d total average cycles: %.4f\n", id, mytime);
            printf("id: %d total time: %.10f\n", id, totaltime / 2.25 / 1000 / 1000 / 1000);
        }
        if (id == 0)
        {
            double Gflops = 1.0 * M * N * L * 2 * nnz / 1024 / 1024 / 1024;
            double Gmems  = 1.0 * M * N * L * (nnz + 2) * sizeof(DATA_T) / 1024 / 1024 / 1024;
            double total_time = totaltime / 2.25 / 1000 / 1000 / 1000;
            printf("id: %d total time:       %.6f\n", id, total_time);
            printf("id: %d Gflops:           %.6f\n", id, Gflops / total_time);
            printf("id: %d Memory bandwidth: %.6f\n", id, Gmems / total_time);
        }
    #endif
}

template<typename DATA_T>
NOINLINE void struct_back_sptrsv_cross_entry(void *_info)
{
    struct_info<DATA_T> info; 
    CRTS_dma_get(&info, _info, sizeof(info));
    struct_back_sptrsv_cross_f(info.a, info.x, info.b, info.M, info.N, info.L, info.nnz, info.halo, info.cols, info.p, info.col_id, info.z_off);
}

template<typename DATA_T>
NOINLINE void struct_back_sptrsv_f(const DATA_T *a, DATA_T *x, const DATA_T *b, int M, int N, int L, \
int nnz, int halo, int cols, int skew, int *p, int *col_m, int *off_m)
{
    strTRSV_params<sizeof(DATA_T)> params;
    const int GRA = params.GRA;

    int K = params.LM;
	int gra = GRA / sizeof(DATA_T);    //granuity of communication, should be a factor of K ***
    int oneLEN = 0;
    if (K >= L) oneLEN = 1;
    //if(L<64&&L>32) K=64; 
	K=L+(8-L%8);


    int id, row, col;
    id = CRTS_smng_get_tid();
    row = (CRTS_smng_get_rid()) % ROW_P;
    col = (CRTS_smng_get_cid()) % COL_P;

    //debug
    int pflag = 0;
    if (id == 0) pflag = 1;

    int halo2 = 2 * halo;
    int row_num = 8, col_num = 8;

    //DMA reply
    crts_rply_t rply = 0;
    int dmas = 0;
    
    //buffer
    DATA_T x_buf[cols+1][K + halo2];
    DATA_T a_buf[K * nnz];

    //column id and vertical offset
    int col_t[nnz];
    int offset_t[nnz];
    int pos[2*cols];
    CRTS_DMA_IGET(pos, p, 2 * cols * sizeof(int), &rply);
    CRTS_DMA_IGET(col_t, col_m, nnz * sizeof(int), &rply);
    CRTS_DMA_IGET(offset_t, off_m, nnz * sizeof(int), &rply);
    dmas += 3;
    CRTS_dma_wait_value(&rply, dmas);

    //buffer communication
    volatile int done_k[cols]; //neighbour_done_signal
    volatile int recv_k[cols]; //neighbour_receive_signal
    //whether communication is needed
    int fneed[cols];
    int bneed[cols];

    //communication id
    int bid[cols], fid[cols];

    //M/N_iter iterations have to be done anyway
    int M_iter, N_iter;
    M_iter = (M + row_num - 1) / row_num;
    N_iter = (N + col_num - 1) / col_num;

    int i, j, k;
    int u, v;
    int count;
    // calculate id
    for (u = 0; u < cols; u++)
    {
        int di = pos[u*2], dj = pos[u*2+1];
        int ti = row + di, tj = col + dj + skew * di;
        fid[u] = CAL_ID(ti, tj);
        ti = row - di, tj = col - dj - skew * di;
        bid[u] = CAL_ID(ti, tj);
    }

    //main loop
    for (int ii = 0; ii < M_iter; ii++){
            int width = gridmin(M - ii * row_num, row_num);
            int right_off;
            right_off = 8 - (width - 1);
            N_iter = (N - right_off + col_num - 1) / col_num + 1;
            for (int jj = 0; jj < N_iter ; jj++)
            {
                i = ii * row_num + row;
                j = jj * col_num + col - skew * row;
#ifndef __sw_slave__
    _ldm_base[id] = (volatile void*)&done_k[0];
#endif
    CRTS_ssync_array();
                for (u = 0; u <= cols; u++)
                for (v = 0; v < K + halo2; v++)
                    x_buf[u][v] = 0;
                for (u = 0; u < cols; u++)
                    recv_k[u] = done_k[u] = -1;
                CRTS_ssync_array();
            if (VALID(i, j, 0, M, N, 1))
            {
                //*****************main part*****************
                
                //fneed = need to recv from, bneed = need to send to
                for (u = 0; u < cols; u++)
                {
                    int di = pos[u*2], dj = pos[u*2+1];
                    int ti = i + di, tj = j + dj;
                    if (VALID(ti, tj, 0, M, N, 1)) fneed[u] = 1; else fneed[u] = 0;
                    ti = i - di, tj = j - dj;
                    if (VALID(ti, tj, 0, M, N, 1)) bneed[u] = 1; else bneed[u] = 0;
                }

                //vertical block size K
                for (k = 0; k < L; k+=K)
                {
                    int len = gridmin(L - k, K);
                    int  c;

			int off_up;
			if(k+K>L-1)
				off_up=0;
			else
				off_up=gridmin(L-k-K,halo);
			int buf_off=K-len+halo;
			//int buf_off=halo;
                    //DMA A & b
                    dmas += 2;
            CRTS_DMA_IGET(a_buf, a + (M*N*L -(i*N+j)*L-k) * nnz-len*nnz, len * nnz * sizeof(DATA_T), &rply);
                    int len_halo = gridmin(len + halo, L - k);
			CRTS_DMA_IGET(x_buf[cols] + buf_off, b + M*N*L-(i*N+j)*L-k-len, len * sizeof(DATA_T), &rply);
                    for (u = 0; u < cols; u++)
                    {
                        if (fid[u] == -1)
                        {
                            if (fneed[u] == 1)
                            {
                                int di = pos[u*2], dj = pos[u*2+1];
                                int ti = i + di, tj = j + dj;
                        		CRTS_DMA_IGET(x_buf[u] + buf_off-off_up, x + M*N*L-(ti*N*L+tj*L+k)-len, (len) * sizeof(DATA_T), &rply);
                                dmas++;
                            }
                            recv_k[u] = L;
                        }
                    }
                    CRTS_dma_wait_value(&rply, dmas);

                    //calculation loop
					int graa=gridmin(gra-1,L-1);
            		int commu_index =len-gra;
                    //int commu_index = halo;
                    for (c = len-1; c >= 0; c--)
                    {

                        count = c + k;

                        //wait until data is ready
                        int flag = 1;
                    
                        while (flag)
                        {
                            flag = 0;
                            for (u = 0; u < cols; u++)
                            {
                                if (recv_k[u] < gridmin(len-1-count + halo, L - 1)) flag = 1;
                            }
                        }
						//printf("i=%d,j=%d,cols=%d\n",i,j,cols);

                        DATA_T tmp = x_buf[cols][c + buf_off];
						DATA_T para=1.0;//a_buf[c*nnz];//1.0;
                        for (u = 0; u < nnz; u++)
                        {

						if(col_t[u]==cols&&offset_t[u]==0)
						{
							para=a_buf[c*nnz+u];
						}
						else
						{    
							DATA_T ttmp=a_buf[c * nnz + u] * x_buf[col_t[u]][c + offset_t[u] + buf_off];
							tmp-=ttmp;
                       	}
					    }
                        //x_buf[cols][c + buf_off] = tmp/para;
                        x_buf[cols][c + buf_off] = tmp;
                        
                	if (len-1-c==len-1||((len-1-c + 1) % gra == 0 ))
                        {
                            //inform forward slave
                            for (u = 0; u < cols; u++)
                            {
                                if (fid[u] != -1 && fneed[u])
                                {
                                    int* remote_r = remote_ldm_addr(&done_k[u], fid[u]);
                                    (*remote_r) = len-1-count;
                                }
                            }
						
                            //data backward
                            for (u = 0; u < cols; u++)
                            {
                                if (bid[u] != -1 && bneed[u])
                                {
                                    while ((len-1-count - done_k[u]) >= K);

                            		  rstore8(x_buf[cols] +buf_off+ commu_index, x_buf[u] + buf_off+commu_index, bid[u]);
            
                                    int* remote_r = remote_ldm_addr(&recv_k[u], bid[u]);
                                    mem_fence();
                                    (*remote_r) = len-1-count;
                                }
                            }
                            commu_index -= gra;
                        }
                    }

                    //dma wb
                    dmas++;
            	    CRTS_dma_iput(x + M*N*L-(i*N+j)*L-k-len, x_buf[cols] + buf_off, len * sizeof(DATA_T), &rply);
                    CRTS_dma_wait_value(&rply, dmas);

                }

            }else{
				for (u = 0; u < cols; u++)
				{
					if (bid[u] != -1)
					{
						int *remote_r = remote_ldm_addr(&recv_k[u], bid[u]);
						(*remote_r) = L;
					}
				}
			}
            }
    }

}








//**************backward
template<typename DATA_T>
NOINLINE void struct_back_sptrsv_entry(void *_info)
{
    struct_info<DATA_T> info; 
    CRTS_dma_get(&info, _info, sizeof(info));
    struct_back_sptrsv_f(info.a, info.x, info.b, info.M, info.N, info.L, info.nnz, info.halo, info.cols, info.skew, info.p, info.col_id, info.z_off);

}

//#define PERF

template<typename DATA_T>
NOINLINE void struct_sptrsv_f(const DATA_T *a, DATA_T *x, const DATA_T *b, int M, int N, int L, \
int nnz, int halo, int cols, int skew, int *p, int *col_m, int *off_m)
{

    #ifdef PERF
        unsigned long time1, time2;
    #endif

    strTRSV_params<sizeof(DATA_T)> params;
    const int GRA = params.GRA;

    int K = params.LM;     //vertical block size
    int gra = GRA / sizeof(DATA_T);    //granuity of communication, should be a factor of K ***
    int vec = GRA / sizeof(DATA_T);
    int nnz2 = nnz * 2, nnz3 = nnz * 3, nnz4 = nnz * 4, \
    nnz5 = nnz * 5, nnz6 = nnz * 6, nnz7 = nnz * 7;

    int oneLEN = 0;
    if (K >= L) oneLEN = 1;
    K = L + (8 - L % 8);

    int overlap = gridmin(K, L);

    //cross partition
    int id, row, col;
    id = CRTS_smng_get_tid();
    row = (CRTS_smng_get_rid()) % ROW_P;
    col = (CRTS_smng_get_cid()) % COL_P;

    //debug
    int pflag = 0;
    if (id == 0) pflag = 1;
    
    int halo2 = 2 * halo;
    int row_num = 8, col_num = 8;

    //DMA reply
    crts_rply_t rply = 0;
    int dmas = 0;

    //buffer
    __attribute((aligned(256))) DATA_T x_buf[cols + 1][K + halo2 + 8];
    __attribute((aligned(256))) DATA_T res_buf[2][K + halo2 + 8];
    __attribute((aligned(256))) DATA_T a_buf[2][K * nnz];

    int res_id = 0;
    int a_id = 0;

    //column id and vertical offset
    int col_t[nnz];
    int offset_t[nnz];
    int pos[2*cols];
    CRTS_DMA_IGET(pos, p, 2 * cols * sizeof(int), &rply);
    CRTS_DMA_IGET(col_t, col_m, nnz * sizeof(int), &rply);
    CRTS_DMA_IGET(offset_t, off_m, nnz * sizeof(int), &rply);
    dmas += 3;
    CRTS_dma_wait_value(&rply, dmas);

    //buffer communication
    volatile int done_k[cols]; //neighbour_done_signal
    volatile int recv_k[cols]; //neighbour_receive_signal
    int local_recv_k[cols]; //to avoid sychronization problem
    int local_done_k[cols]; //to avoid sychronization problem

    int done_offset[cols];
    int recv_offset[cols];

    //dma communication
    volatile int dma_done[cols];
    int dma_id[cols];
    int dma_check[cols];
    int dma_dii[cols], dma_djj[cols];

    //whether communication is needed
    int fneed[cols];
    int bneed[cols];

    //communication id
    int bid[cols], fid[cols];

    int i, j, k;
    int u, v;

    int no_cols_nnz = 0;
    u = 0;
    while (u < nnz && col_t[u] != cols) u++;
    no_cols_nnz = u;

    int count = -1;
    for (u = 0; u < cols; u++)
    {
        recv_k[u] = done_k[u] = -1;
        dma_done[u] = -1;
        local_recv_k[u] = 0;
        local_done_k[u] = 0;
    }

    // calculate id
    for (u = 0; u < cols; u++)
    {
        int di = pos[u*2], dj = pos[u*2+1];
        int ti = row + di, tj = col + dj + skew * di;
        if (oneLEN && ti < 0)
        {
            dma_check[u] = 1;
        }
        else
            dma_check[u] = 0;
        done_offset[u] = 0;
        fid[u] = CAL_ID(ti, tj);
        if (!oneLEN && fid[u] == -1) dma_check[u] = 1;
        if (dma_check[u])
        {
            if (ti < 0) dma_dii[u] = -1; else dma_dii[u] = 0;
            if (tj < 0) dma_djj[u] = -1; else dma_djj[u] = 0;
        }

        ti = row - di, tj = col - dj - skew * di;
        if (oneLEN && ti >= row_num)
        {
            dma_id[u] = CAL_ID(ti - row_num, (tj + col_num) % col_num);
        }
        else
            dma_id[u] = -1;
        recv_offset[u] = 0;
        bid[u] = CAL_ID(ti, tj);
        if (!oneLEN && bid[u] == -1) dma_id[u] = CAL_ID((ti + row_num) % row_num, (tj + col_num) % col_num);

    }

    for (u = 0; u < cols; u++)
    {
        if (fid[u] == -1)
        {
            local_recv_k[u] = M * N * L;
            local_done_k[u] = M * N * L;
        }
    }
    
#ifndef __sw_slave__
    _ldm_base[id] = (volatile void*)&done_k[0];
    fprintf(stderr, "REG: id=%d base=%p\n", (int)id, (volatile void*)&done_k[0]);
#endif
    CRTS_ssync_array();

    #ifdef PERF
        time1 = CRTS_stime_cycle();
    #endif

    //M/N_iter iterations have to be done anyway
    int M_iter, N_iter, L_iter;
    M_iter = (M + row_num - 1) / row_num;
    L_iter = (L + K - 1) / K;

    //first column
    int new_col_j = col - skew * row;
    while (new_col_j < 0) new_col_j += col_num;
    //if (id == 8) printf("new_col_j %d\n", new_col_j);
    if (VALID(row, new_col_j, 0, M, N, 1))
    {
        int nextlen = gridmin(L, K);
        int buf_off_first = K - nextlen + halo;
        int src_idx = INDEX3(row, new_col_j, 0, N, L);
        dmas += 2;
        CRTS_DMA_IGET(a_buf[a_id], a + src_idx * nnz, nextlen * nnz * sizeof(DATA_T), &rply);
        CRTS_DMA_IGET(res_buf[res_id] + buf_off_first, b + src_idx, nextlen * sizeof(DATA_T), &rply);
    }

    //main loop
    for (int ii = 0; ii < M_iter; ii++)
    {
        int width = gridmin(M - ii * row_num, row_num);
        int right_off;
        right_off = 8 - (width - 1);
        N_iter = (N - right_off + col_num - 1) / col_num + 1;
    for (int jj = 0; jj < N_iter; jj++)
    {
        i = ii * row_num + row;
        j = jj * col_num + col - skew * row;

        CRTS_ssync_array();

        for (u = 0; u < cols; u++)
        for (v = 0; v < halo; v++)
            x_buf[u][v] = 0;

        for (v = 0; v < halo; v++)
        {
            res_buf[res_id][v] = 0;
        }
        
    if (VALID(i, j, 0, M, N, 1))
    {
        //*****************main part*****************//
        
        //fneed = need to recv from, bneed = need to send to
        for (u = 0; u < cols; u++)
        {
            int di = pos[u*2], dj = pos[u*2+1];
            int ti = i + di, tj = j + dj;
            if (VALID(ti, tj, 0, M, N, 1)) fneed[u] = 1; else fneed[u] = 0;
            if (fid[u] == -1 || !fneed[u]) local_recv_k[u] += L;

            ti = i - di, tj = j - dj;
            if (VALID(ti, tj, 0, M, N, 1)) bneed[u] = 1; else bneed[u] = 0;
            if (bid[u] != -1 && !bneed[u]) recv_offset[u] -= L;
        }

        int count_max = count + L;

        //vertical block size K
        for (k = 0; k < L; k+=K)
        {
            int len = gridmin(L - k, K);
            int buf_off = K - len + halo;

            //DMA other columns
            int len_halo = gridmin(len + halo, L - k);

            for (u = 0; u < cols; u++)
            {
                if (fid[u] == -1 && fneed[u] == 1)
                {
                    int di = pos[u*2], dj = pos[u*2+1];
                    int ti = i + di, tj = j + dj;
                    if (dma_check[u])
                    {
                        int halo_block_id = ti * N * L + tj * L + k/K;
                        while (dma_done[u] < halo_block_id);
                    }
                    CRTS_DMA_IGET(x_buf[u] + buf_off, x + INDEX3(ti, tj, k, N, L), len_halo * sizeof(DATA_T), &rply);
                    dmas++;
                }
                else if (fneed[u] == 0)
                {
                    for (v = 0; v < K + halo; v++)
                        x_buf[u][v + buf_off] = 0;
                }
            }
            CRTS_dma_wait_value(&rply, dmas);

            if (k + len >= L)
            {
                //ti, tj indicate next column position
                int ti = i, tj = j + col_num;
                if (tj >= N)
                {
                    ti = ti + row_num;
                    tj = new_col_j;
                }
                if (VALID(ti, tj, 0, M, N, 1))
                {
                    int nextlen = gridmin(K, L);
                    int buf_off_next = K - nextlen + halo;
                    dmas += 2;
                    CRTS_DMA_IGET(a_buf[(a_id+1)%2], a + INDEX3(ti, tj, 0, N, L) * nnz, nextlen * nnz * sizeof(DATA_T), &rply);
                    CRTS_DMA_IGET(res_buf[(res_id+1)%2] + buf_off_next, b + INDEX3(ti, tj, 0, N, L), nextlen * sizeof(DATA_T), &rply);
                }
            }
            else
            {
                int nextlen = gridmin(L - k - len, K);
                int buf_off_next = K - nextlen + halo;
                dmas += 2;
                CRTS_DMA_IGET(a_buf[(a_id+1)%2], a + INDEX3(i, j, k + len, N, L) * nnz, nextlen * nnz * sizeof(DATA_T), &rply);
                CRTS_DMA_IGET(res_buf[(res_id+1)%2] + buf_off_next, b + INDEX3(i, j, k + len, N, L), nextlen * sizeof(DATA_T), &rply);
            }

            int c;

            //calculation loop, vectorized
            int commu_index = buf_off;

            for (c = 0; c < len; c+=vec)
            {
                count += vec;
                if (c + vec > len) count -= c + vec - len;

                //wait until data is ready
                int flag = 1;


                while(flag)
                {
                    flag = 0;
                    for (u = 0; u < cols; u++)
                    {
                        if (recv_k[u] + local_recv_k[u] < gridmin(count + halo, count_max))
                            flag = 1;
                    }
                }

                
                simd_t<DATA_T> res, atmp, xtmp;
                vec_loadu(res, res_buf[res_id] + c + buf_off);
                for (u = 0; u < no_cols_nnz; u++)
                {
                    //atmp = simd_set_a_nnz(a_buf[a_id] + c * nnz + u);
                    atmp = params.simd_set_nnz(a_buf[a_id] + c * nnz + u ,  nnz, nnz2, nnz3, nnz4, nnz5, nnz6, nnz7);
                    vec_loadu(xtmp, x_buf[col_t[u]] + c + offset_t[u] + buf_off);
                    res = res - atmp * xtmp;
                }
                vec_storeu(res, res_buf[res_id] + c + buf_off);

                if (no_cols_nnz < nnz)
                {
                    for (v = 0; v < vec; v++)
                    {
                        for (u = no_cols_nnz; u < nnz; u++)
                        {
                            if (offset_t[u] == 0) continue;
                            res_buf[res_id][c + v + buf_off] -= a_buf[a_id][(c + v)* nnz + u] * res_buf[res_id][c + offset_t[u] + v + buf_off];
                        }
                    }
                }

                for (u = 0; u < cols; u++)
                {
                    if (fid[u] != -1)
                    {
                        int* remote_r = remote_ldm_addr(&done_k[u], fid[u]);
                        (*remote_r) = count + done_offset[u];
                    }
                }

                for (u = cols - 1; u >= 0; u--)
                {
                    if (bid[u] != -1 && bneed[u])
                    {
                        if (!oneLEN) while ((count - (done_k[u] + local_done_k[u])) \
                        >= overlap - halo);

                        rstore8(res_buf[res_id] + commu_index, x_buf[u] + commu_index, bid[u]);


                        int* remote_r = remote_ldm_addr(&recv_k[u], bid[u]);
                        mem_fence();
                        (*remote_r) = count + recv_offset[u];
                    }
                }
                commu_index += gra;


            }

            //dma wb
            dmas++;
            CRTS_dma_iput(x + INDEX3(i, j, k, N, L), res_buf[res_id] + buf_off, len * sizeof(DATA_T), &rply);

            for (u = 0; u < cols; u++)
            {
                if (dma_id[u] != -1)
                {
                    int *remote_id = remote_ldm_addr(&dma_done[u], dma_id[u]);
                    (*remote_id) = i * N * L + j * L + k;
                }
            }

            //post
            for (u = 0; u < cols; u++)
            {
                for (v = 0; v < halo; v++)
                {
                    x_buf[u][v] = x_buf[u][v + K];
                }
            }

            for (v = 0; v < halo; v++)
                res_buf[(res_id+1)%2][v] = res_buf[res_id][v + K];

            a_id = (a_id + 1) % 2;
            res_id = (res_id + 1) % 2;
        }
        CRTS_dma_wait_value(&rply, dmas);
    }
    else
    {
        //if (id == 8) printf("id %d i %d j %d\n", id, i, j);
        count += L;
        for (u = 0; u < cols; u++)
        {
            local_recv_k[u] += L;
            local_done_k[u] += L;
            recv_offset[u] -= L;
            //done_offset[u] -= L;
            if (fid[u] != -1)
            {
                int* remote_r = remote_ldm_addr(&done_k[u], fid[u]);
                (*remote_r) = count + done_offset[u];
            }
        }
    }

    //printf("%d done i %d j %d\n", id, i, j);

    }
    }

    CRTS_ssync_array();

    #ifdef PERF
        time2 = CRTS_stime_cycle();
        if (id == 0)
        {
            double Gflops = 1.0 * M * N * L * 2 * nnz / 1024 / 1024 / 1024;
            double Gmems  = 1.0 * M * N * L * (nnz + 2) * sizeof(DATA_T) / 1024 / 1024 / 1024;
            double total_time = (time2 - time1) / 2.25 / 1000 / 1000 / 1000;
            printf("id: %d total time:       %.6f\n", id, total_time);
            printf("id: %d Gflops:           %.6f\n", id, Gflops / total_time);
            printf("id: %d Memory bandwidth: %.6f\n", id, Gmems / total_time);
        }
    #endif

}

template<typename DATA_T>
NOINLINE void struct_sptrsv_entry(void *_info)
{
    struct_info<DATA_T> info; 
	CRTS_dma_get(&info, _info, sizeof(info));
    
    struct_sptrsv_f(info.a, info.x, info.b, info.M, info.N, info.L, info.nnz, info.halo, info.cols, info.skew, info.p, info.col_id, info.z_off);

}



WITH_CACHE_IGNORE(swSparse_s_struct_sptrsv_cross_entry, struct_sptrsv_cross_entry<float>)
WITH_CACHE_IGNORE(swSparse_d_struct_sptrsv_cross_entry, struct_sptrsv_cross_entry<double>)
WITH_CACHE_IGNORE(swSparse_s_struct_sptrsv_entry, struct_sptrsv_entry<float>)
WITH_CACHE_IGNORE(swSparse_d_struct_sptrsv_entry, struct_sptrsv_entry<double>)
WITH_CACHE_IGNORE(swSparse_s_struct_back_sptrsv_cross_entry, struct_back_sptrsv_cross_entry<float>)
WITH_CACHE_IGNORE(swSparse_d_struct_back_sptrsv_cross_entry, struct_back_sptrsv_cross_entry<double>)
WITH_CACHE_IGNORE(swSparse_s_struct_back_sptrsv_entry, struct_back_sptrsv_entry<float>)
WITH_CACHE_IGNORE(swSparse_d_struct_back_sptrsv_entry, struct_back_sptrsv_entry<double>)





