#include<crts.h>
#include"internal/CPE_utils.h"
#include"internal/CPE_simd_utils.h"

// export
const intv16 swSparse_intv16_iota = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15};
const int swSparse_shuffle_indices[23][3] = {
    // swSparse_shuffle_indices[0 : 12] : for optimal 16
    // {0, 2, 6, 8, 10, 12, 14, 26, 1, 3, 7, 9, 11, 13, 15, 27}
    {0x98a41840, 0xb49c61d3, 0xdbda}, 
    // {30, 4, 24, 16, 20, 18, 22, 28, 31, 5, 25, 17, 21, 19, 23, 29}
    {0xa548609e, 0x58e4bfe5, 0xede7},
    // {0, 1, 17, 2, 4, 5, 6, 22, 8, 9, 25, 10, 12, 13, 14, 30}
    {0x8a414420, 0xc56528b1, 0xf39a},
    // {16, 3, 19, 20, 21, 18, 7, 23, 24, 11, 27, 28, 29, 26, 15, 31}
    {0xe55a4c70, 0xde6d78b9, 0xfbf5},
    // {0, 1, 2, 3, 5, 6, 19, 7, 8, 9, 10, 11, 13, 14, 27, 15}
    {0xcc518820, 0xd5a9283c, 0x7edc},
    // {16, 23, 17, 4, 18, 20, 21, 22, 24, 31, 25, 12, 26, 28, 29, 30}
    {0x692246f0, 0xa667f8b5, 0xf779},
    // {0, 1, 2, 3, 19, 5, 21, 18, 8, 9, 10, 11, 27, 13, 29, 26}
    {0x4b318820, 0xb5a92895, 0xd75b},
    // {16, 17, 23, 4, 20, 6, 22, 7, 24, 25, 31, 12, 28, 14, 30, 15}
    {0x8d425e30, 0xc67f383d, 0x7f9d},
    // {0, 1, 2, 3, 4, 5, 6, 23, 8, 9, 10, 11, 12, 13, 14, 31}
    {0x8a418820, 0xc5a928b9, 0xfb9a},
    // {16, 17, 18, 7, 19, 20, 21, 22, 24, 25, 26, 15, 27, 28, 29, 30}
    {0x6933ca30, 0xb7eb38b5, 0xf779},
    // {0, 1, 2, 3, 19, 4, 20, 5, 21, 6, 22, 7, 23, 18, 17, 16}
    {0x9318820,  0x73d8d52d, 0x8465},
    // {8, 9, 10, 11, 27, 12, 28, 13, 29, 14, 30, 15, 31, 26, 25, 24}
    {0x19b5a928, 0xf7f9dd6f, 0xc675},

    // swSparse_shuffle_indices[12 : 14] : for transpose-bitonic
    // {0, 8, 16, 24, 1, 9, 17, 25, 2, 10, 18, 26, 3, 11, 19, 27}
    {0x521c4100, 0x3d4942cc, 0xdcd6}, 
    // {31, 23, 15, 7, 30, 22, 14, 6, 29, 21, 13, 5, 28, 20, 12, 4}
    {0xade3beff, 0xc2b6bd33, 0x2329},

    // swSparse_shuffle_indices[14 : 18] : shuffle and unshuffle 4 bytes
    // {0, 16, 1, 17, 2, 18, 3, 19, 4, 20, 5, 21, 6, 22, 7, 23}
    {0xe4288600, 0x6a968498, 0xb9ec},
    // {8, 24, 9, 25, 10, 26, 11, 27, 12, 28, 13, 29, 14, 30, 15, 31}
    {0xf4aca708, 0xeeb78cda, 0xfbfc},
    // {0, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30}
    {0x14831040, 0x8b525073, 0xf735}, 
    // {1, 3, 5, 7, 9, 11, 13, 15, 17, 19, 21, 23, 25, 27, 29, 31}
    {0x56939461, 0x9bd6717b, 0xff77},

    // swSparse_shuffle_indices[18 : 22] : shuffle and unshuffle 8 bytes
    // {0, 1, 16, 17, 2, 3, 18, 19, 4, 5, 20, 21, 6, 7, 22, 23}
    {0x8628c020, 0x6ad0a49c, 0xbd8e}, 
    // {8, 9, 24, 25, 10, 11, 26, 27, 12, 13, 28, 29, 14, 15, 30, 31}
    {0x96ace128, 0xeef1acde, 0xff9e},
    // {0, 1, 4, 5, 8, 9, 12, 13, 16, 17, 20, 21, 24, 25, 28, 29}
    {0x12829020, 0x8ad2306b, 0xef33}, 
    // {2, 3, 6, 7, 10, 11, 14, 15, 18, 19, 22, 23, 26, 27, 30, 31}
    {0x96a39862, 0xabda727b, 0xffb7}
};

void swSparse_load_shuffle_indices(void *index, int offset, int size) {
    int *iptr = (int*) index;
    crts_rply_t reply = 0;
    CRTS_DMA_IGET(iptr, swSparse_shuffle_indices[offset], sizeof(int) * 3 * size, &reply);
    memset(iptr + size * 3, 0, sizeof(int) * 13 * size);
    CRTS_dma_wait_value(&reply, 1);
    for(int i = size; i > 0; --i) {
        iptr[i * 16]     = iptr[i * 3];
        iptr[i * 16 + 1] = iptr[i * 3 + 1];
        iptr[i * 16 + 2] = iptr[i * 3 + 2];
        iptr[i * 3]     = 0;
        iptr[i * 3 + 1] = 0;
        iptr[i * 3 + 2] = 0;
    }
}

void swSparse_colmaj2simd_shuffle(const void * RSTR x, void * RSTR y, int n_bytes, int ld_bytes, const intv16 shuffle_idx[]) {
    const intv16* RSTR xi = (const intv16*)x;
    intv16* RSTR yi = (intv16*)y;
    const intv16 shflo = shuffle_idx[0];
    const intv16 shfhi = shuffle_idx[1];
    const int ld_vec = ld_bytes >> 6;
    for(int i = 0; i < n_bytes; i += 64) {
        const int idx = i >> 6;
        intv16 y0, y1, y2, y3, y4, y5, y6;
        intv16 x0 = xi[idx];
        intv16 x1 = xi[idx + ld_vec];
        intv16 x2 = xi[idx + ld_vec * 2];
        intv16 x3 = xi[idx + ld_vec * 3];
        intv16 x4 = xi[idx + ld_vec * 4];
        intv16 x5 = xi[idx + ld_vec * 5];
        intv16 x6 = xi[idx + ld_vec * 6];
        intv16 x7 = xi[idx + ld_vec * 7];
        y0 = simd_vshfw(x0, x4, shflo);
        x4 = simd_vshfw(x0, x4, shfhi);
        y1 = simd_vshfw(x1, x5, shflo);
        x5 = simd_vshfw(x1, x5, shfhi);
        y2 = simd_vshfw(x2, x6, shflo);
        x6 = simd_vshfw(x2, x6, shfhi);
        y3 = simd_vshfw(x3, x7, shflo);
        x7 = simd_vshfw(x3, x7, shfhi);
        x0 = y0; x1 = y1; x2 = y2; x3 = y3;
        y0 = simd_vshfw(x0, x2, shflo);
        x2 = simd_vshfw(x0, x2, shfhi);
        y1 = simd_vshfw(x1, x3, shflo);
        x3 = simd_vshfw(x1, x3, shfhi);
        y4 = simd_vshfw(x4, x6, shflo);
        x6 = simd_vshfw(x4, x6, shfhi);
        y5 = simd_vshfw(x5, x7, shflo);
        x7 = simd_vshfw(x5, x7, shfhi);
        x0 = y0; x1 = y1; x4 = y4; x5 = y5;
        y0 = simd_vshfw(x0, x1, shflo);
        x1 = simd_vshfw(x0, x1, shfhi);
        y2 = simd_vshfw(x2, x3, shflo);
        x3 = simd_vshfw(x2, x3, shfhi);
        y4 = simd_vshfw(x4, x5, shflo);
        x5 = simd_vshfw(x4, x5, shfhi);
        y6 = simd_vshfw(x6, x7, shflo);
        x7 = simd_vshfw(x6, x7, shfhi);
        x0 = y0; x2 = y2; x4 = y4; x6 = y6;
        yi[idx * 8]     = x0;
        yi[idx * 8 + 1] = x1;
        yi[idx * 8 + 2] = x2;
        yi[idx * 8 + 3] = x3;
        yi[idx * 8 + 4] = x4;
        yi[idx * 8 + 5] = x5;
        yi[idx * 8 + 6] = x6;
        yi[idx * 8 + 7] = x7;
    }
}

void swSparse_simd2colmaj_shuffle(const void * RSTR x, void * RSTR y, int n_bytes, int ld_bytes, const intv16 shuffle_idx[]) {
    const intv16* RSTR xi = (const intv16*)x;
    intv16* RSTR yi = (intv16*)y;
    const intv16 ushflo = shuffle_idx[0];
    const intv16 ushfhi = shuffle_idx[1];
    const int ld_vec = ld_bytes >> 6;
    for(int i = 0; i < n_bytes; i += 64) {
        const int idx = i >> 6;
        intv16 y0, y1, y2, y3, y4, y5, y6;
        intv16 x0 = xi[idx * 8];
        intv16 x1 = xi[idx * 8 + 1];
        intv16 x2 = xi[idx * 8 + 2];
        intv16 x3 = xi[idx * 8 + 3];
        intv16 x4 = xi[idx * 8 + 4];
        intv16 x5 = xi[idx * 8 + 5];
        intv16 x6 = xi[idx * 8 + 6];
        intv16 x7 = xi[idx * 8 + 7];
        y0 = simd_vshfw(x0, x1, ushflo);
        x1 = simd_vshfw(x0, x1, ushfhi);
        y2 = simd_vshfw(x2, x3, ushflo);
        x3 = simd_vshfw(x2, x3, ushfhi);
        y4 = simd_vshfw(x4, x5, ushflo);
        x5 = simd_vshfw(x4, x5, ushfhi);
        y6 = simd_vshfw(x6, x7, ushflo);
        x7 = simd_vshfw(x6, x7, ushfhi);
        x0 = y0; x2 = y2; x4 = y4; x6 = y6;
        y0 = simd_vshfw(x0, x2, ushflo);
        x2 = simd_vshfw(x0, x2, ushfhi);
        y1 = simd_vshfw(x1, x3, ushflo);
        x3 = simd_vshfw(x1, x3, ushfhi);
        y4 = simd_vshfw(x4, x6, ushflo);
        x6 = simd_vshfw(x4, x6, ushfhi);
        y5 = simd_vshfw(x5, x7, ushflo);
        x7 = simd_vshfw(x5, x7, ushfhi);
        x0 = y0; x1 = y1; x4 = y4; x5 = y5;
        y0 = simd_vshfw(x0, x4, ushflo);
        x4 = simd_vshfw(x0, x4, ushfhi);
        y1 = simd_vshfw(x1, x5, ushflo);
        x5 = simd_vshfw(x1, x5, ushfhi);
        y2 = simd_vshfw(x2, x6, ushflo);
        x6 = simd_vshfw(x2, x6, ushfhi);
        y3 = simd_vshfw(x3, x7, ushflo);
        x7 = simd_vshfw(x3, x7, ushfhi);
        x0 = y0; x1 = y1; x2 = y2; x3 = y3;
        yi[idx]              = x0;
        yi[idx + ld_vec]     = x1;
        yi[idx + ld_vec * 2] = x2;
        yi[idx + ld_vec * 3] = x3;
        yi[idx + ld_vec * 4] = x4;
        yi[idx + ld_vec * 5] = x5;
        yi[idx + ld_vec * 6] = x6;
        yi[idx + ld_vec * 7] = x7;
    }
}

void swSparse_cplx_simd_shuffle(void * RSTR x, int n_bytes, const intv16 shuffle_idx[]) {
    intv16* RSTR xi = (intv16* RSTR)x;
    const intv16 idxa = shuffle_idx[0];
    const intv16 idxb = shuffle_idx[1];
    int i, iend = n_bytes - 256;
    for(i = 0; i < iend; i += 384) {
        const int idx = i >> 6;
        intv16 xa, xb, xc, xd, xe, xf;
        intv16 ya, yb, yc, yd, ye, yf;
        xa = xi[idx];
        xb = xi[idx+1];
        xc = xi[idx+2];
        xd = xi[idx+3];
        xe = xi[idx+4];
        xf = xi[idx+5];
        ya = simd_vshfw(xa, xb, idxa);
        yb = simd_vshfw(xa, xb, idxb);
        yc = simd_vshfw(xc, xd, idxa);
        yd = simd_vshfw(xc, xd, idxb);
        ye = simd_vshfw(xe, xf, idxa);
        yf = simd_vshfw(xe, xf, idxb);
        xi[idx]   = ya;
        xi[idx+1] = yb;
        xi[idx+2] = yc;
        xi[idx+3] = yd;
        xi[idx+4] = ye;
        xi[idx+5] = yf;
    }
    const int idx = i >> 6;
    intv16 xa, xb, xc, xd;
    intv16 ya, yb, yc, yd;
    switch (n_bytes - i)
    {
    case 256:
        xc = xi[idx+2];
        xd = xi[idx+3];
        yc = simd_vshfw(xc, xd, idxa);
        yd = simd_vshfw(xc, xd, idxb);
        xi[idx+2] = yc;
        xi[idx+3] = yd;
    case 128:
        xa = xi[idx];
        xb = xi[idx+1];
        ya = simd_vshfw(xa, xb, idxa);
        yb = simd_vshfw(xa, xb, idxb);
        xi[idx]   = ya;
        xi[idx+1] = yb;
    default:
        break;
    }
}
