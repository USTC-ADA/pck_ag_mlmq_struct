#include<float.h>
#include "internal/CPE_simd_math.h"
/********* abs, exp and log *********/

#ifndef SWSPARSE_USE_LIBM_SLAVE
/*
 * Warning: These functions are not equivalent to standard math library
 *
 *          The error is not guarenteed to be under EPSILON. Sometimes it exceeds.
 *
 *          They do not handle NaN or denormalized numbers, the result is undefined.
 *          `exp` does not handle big numbers and Infinity. It may overflow and return Infinity.
 *          `exp` does not handle big negative numbers and -Infinity. It may underflow and return 0.

 *          `log_abs` does not handle Infinity and treats it as a big number. `log_abs(Infinity)` returns `log(DOUBLE_MAX)`;
 *          `log_abs` handles zero. `log_abs(0)` returns `-DOUBLE_MAX` or `-FLOAT_MAX` (not -Infinity)
 * 
 *          If the macro `SWSPARSE_COMPLEX_SAFE_NUMERICS` <= 1:
 *              `abs` of complex numbers calculate squares internally, so the valid range is square-rooted.
 *              Even if the expected answer is in `[DOUBLE_MIN, DOUBLE_MAX]`,
 *                  it still may overflow if it is not in`[sqrt(DOUBLE_MIN), sqrt(DOUBLE_MAX)]`
 *
 *          If the macro `SWSPARSE_COMPLEX_SAFE_NUMERICS` > 1, then we avoid calculating squares. It may be a little slower.
 *
 * They are used in preconditioning of LU factorization.
 */

// evaluate polynomial in tree (modified from `yyzlib/math_lib_vect`)
//      Linear evaluation of polynomials has strong dependency.
//      As FMA has a latency of 7 cycles, linear evaluation requires loop unrolling of 7 to fill the pipeline.
//      However, the number of registers is not enough for such unrolling
#define SPOLY2(x, c0, c1)                     simd_vmas(x, c1, c0)
#define SPOLY3(x, c0, c1, c2)                 simd_vmas(x, simd_vmas(x, c2, c1), c0)
#define SPOLY5(x, x2, c0, c1, c2, c3, c4)     SPOLY3(x2, SPOLY2(x, c0, c1), SPOLY2(x, c2, c3), c4)
#define SPOLY6(x, x2, c0, c1, c2, c3, c4, c5) SPOLY3(x2, SPOLY2(x, c0, c1), SPOLY2(x, c2, c3), SPOLY2(x, c4, c5))

#define DPOLY2(x, c0, c1)                     simd_vmad(x, c1, c0)
#define DPOLY3(x, c0, c1, c2)                 simd_vmad(x, simd_vmad(x, c2, c1), c0)
#define DPOLY4L(x, c0, c1, c2, c3)            DPOLY2(x, c0, DPOLY3(x, c1, c2, c3))             // linear form, need loop-unroll
#define DPOLY4T(x, x2, c0, c1, c2, c3)        DPOLY2(x2, DPOLY2(x, c0, c1), DPOLY2(x, c2, c3)) // tree form, use more registers

#define DPOLY10(x, x2, x4, c0, c1, c2, c3, c4, c5, c6, c7, c8, c9) \
    DPOLY3(x4, DPOLY4L(x, c0, c1, c2, c3), DPOLY4L(x, c4, c5, c6, c7), DPOLY2(x, c8, c9))
#define DPOLY11(x, x2, x4, c0, c1, c2, c3, c4, c5, c6, c7, c8, c9, c10) \
    DPOLY3(x4, DPOLY4L(x, c0, c1, c2, c3), DPOLY4L(x, c4, c5, c6, c7), DPOLY3(x, c8, c9, c10))

#define DPOLY10_(x, x2, x4, c0, c1, c2, c3, c4, c5, c6, c7, c8, c9) \
    DPOLY3(x4, DPOLY4T(x, x2, c0, c1, c2, c3), DPOLY4T(x, x2, c4, c5, c6, c7), DPOLY2(x, c8, c9))
#define DPOLY11_(x, x2, x4, c0, c1, c2, c3, c4, c5, c6, c7, c8, c9, c10) \
    DPOLY3(x4, DPOLY4T(x, x2, c0, c1, c2, c3), DPOLY4T(x, x2, c4, c5, c6, c7), DPOLY3(x, c8, c9, c10))

// export
// [1/(2!), 1/(3!), 1/(4!), 1/(5!), 1/log(2), log(2), 1, -max, 2, 2/3, 2/5, 2/7, 2/9]
const float swSparse_s_math_constant[S_CONTANT_SIZE] = { \
    0x1p-1f, 0x1.555556p-3f, 0x1.555556p-5f, 0x1.111112p-7f, \
    0x1.715476p+0f, 0x1.62e430p-1f, 1.0f, -0x1.fffffep+127f, \
    2.0f, 0x1.555556p-1f, 0x1.99999ap-2f, 0x1.24924ap-2, 0x1.c71c72p-3f
};

// export
// [1/(2!), 1/(3!), 1/(4!), 1/(5!), 1/(6!), 1/(7!), 1/(8!), 1/(9!), \
//      1/log(2), log(2), 1, -max, 2, 2/3, 2/5, 2/7, 2/9, 2/11, 2/13, 2/15, 2/17, 2/19, 2/21]
const double swSparse_d_math_constant[D_CONTANT_SIZE] = {
    0x1p-1, 0x1.5555555555555p-3, 0x1.5555555555555p-5, 0x1.1111111111111p-7, \
    0x1.6c16c16c16c17p-10, 0x1.a01a01a01a01ap-13, 0x1.a01a01a01a01ap-16, 0x1.71de3a556c734p-19, \
    0x1.71547652b82fep+0, 0x1.62e42fefa39efp-1, 1.0, -0x1.ffffffffffffp+1023, \
    2.0, 0x1.5555555555555p-1, 0x1.999999999999ap-2, 0x1.2492492492492p-2, 0x1.c71c71c71c71cp-3, \
    0x1.745d1745d1746p-3, 0x1.3b13b13b13b14p-3, 0x1.1111111111111p-3, 0x1.e1e1e1e1e1e1ep-4, \
    0x1.af286bca1af28p-4, 0x1.8618618618618p-4
};

INLINE int512 value_convert_d2l(doublev8 x) {
    int512 a = (int512)x; // round to nearest, nice !!
    return a;
}

INLINE doublev8 value_convert_l2d(int512 x) {
    doublev8 a = (doublev8)x;
    return a;
}

INLINE int512 value_convert_f2l(floatv8 x) {
    return value_convert_d2l((doublev8)x);
}

INLINE floatv8 value_convert_l2f(int512 x) {
    floatv8 a = (floatv8)x;
    return a;
}

// `v_scaled` must be positive
INLINE int512 get_exponent(doublev8 v_scaled, int512 base, int512 mask) {
    int512 vbits = simd_vcastdl(v_scaled);
    return ((vbits & mask) >> 52) - base;
}

// `base` must be positive
// returns undefined value if overflow
INLINE doublev8 scale_up_pow2(doublev8 base, int512 l, int512 mask) {
    int512 bits = simd_vcastdl(base);
    int512 result = (bits + ((l << 52) & mask));  // may overflow [0, 2048)
    return simd_vcastld(result);
}

// `base` must be positive
// returns undefined value if overflow
INLINE doublev8 scale_down_pow2(doublev8 base, int512 l, int512 mask) {
    int512 bits = simd_vcastdl(base);
    int512 result = (bits - ((l << 52) & mask));  // may overflow [0, 2048)
    return simd_vcastld(result);
}

void swSparse_s_vec_exp(float* data, int len, const float* table) {
    const floatv8 half = table[0], c3 = table[1], c4 = table[2], c5 = table[3];
    const floatv8 rcp_log_2 = table[4], log_2 = table[5], one = table[6];
    const int512 expbits = simd_vcastdl((doublev8)one), mask = expbits | (expbits << 2);
    floatv8* xv = (floatv8*)data;
    int nv = (len + 7) >> 3, nv1 = nv - 1;
    for(int i = 0; i < nv1; i += 2) {
        floatv8 x0 = xv[i], x1 = xv[i+1];
        int512 i0 = value_convert_f2l(x0 * rcp_log_2);
        int512 i1 = value_convert_f2l(x1 * rcp_log_2);
        floatv8 f0 = simd_vnmas(value_convert_l2f(i0), log_2, x0);
        floatv8 f1 = simd_vnmas(value_convert_l2f(i1), log_2, x1);
        
        // x      = f + i * log(2)
        // exp(x) = exp(f) * 2^i
        f0 *= half;
        f1 *= half;
        floatv8 f02 = f0 * f0, f12 = f1 * f1;
        floatv8 e0 = SPOLY6(f0, f02, one, one, half, c3, c4, c5);
        floatv8 e1 = SPOLY6(f1, f12, one, one, half, c3, c4, c5);
        e0 *= e0;
        e1 *= e1;
        xv[i] = (floatv8)scale_up_pow2((doublev8)e0, i0, mask);  // using double precision to prevent overflow
        xv[i+1] = (floatv8)scale_up_pow2((doublev8)e1, i1, mask);
    }
    if((nv & 1) != 0) {
        floatv8 x0 = xv[nv-1];
        floatv8 y0 = x0 * rcp_log_2;
        int512 i0 = value_convert_f2l(y0);
        floatv8 f0 = simd_vnmas(value_convert_l2f(i0), log_2, x0);
        f0 *= half;
        floatv8 f02 = f0 * f0;
        floatv8 e0 = SPOLY6(f0, f02, one, one, half, c3, c4, c5);
        e0 *= e0;
        xv[nv-1] = (floatv8)scale_up_pow2((doublev8)e0, i0, mask);
    }
}

void swSparse_d_vec_exp(double* data, int len, const double* table) {
    const doublev8 half = table[0], c3 = table[1], c4 = table[2], c5 = table[3];
    const doublev8 c6 = table[4], c7 = table[5], c8 = table[6], c9 = table[7];
    const doublev8 rcp_log_2 = table[8], log_2 = table[9],  one = table[10];
    const doublev8 quarter = half * half;
    const int512 expbits = simd_vcastdl(one), mask = expbits | (expbits << 2);
    doublev8* xv = (doublev8*)data;
    int nv = (len + 7) >> 3, nv1 = nv - 1;
    for(int i = 0; i < nv1; i += 2) {
        doublev8 x0 = xv[i], x1 = xv[i+1];
        int512 i0 = value_convert_d2l(x0 * rcp_log_2);
        int512 i1 = value_convert_d2l(x1 * rcp_log_2);
        doublev8 f0 = simd_vnmad(value_convert_l2d(i0), log_2, x0);
        doublev8 f1 = simd_vnmad(value_convert_l2d(i1), log_2, x1);

        // don't scale e0 directly, may overflow
        doublev8 p0 = scale_up_pow2(one, i0, mask), p1 = scale_up_pow2(one, i1, mask);
        
        // x      = f + i * log(2)
        // exp(x) = exp(f) * 2^i = exp(f) * p
        f0 *= quarter;
        f1 *= quarter;
        doublev8 f02 = f0 * f0, f12 = f1 * f1, f04 = f02 * f02, f14 = f12 * f12;
        doublev8 e0 = DPOLY10(f0, f02, f04, one, one, half, c3, c4, c5, c6, c7, c8, c9);
        doublev8 e1 = DPOLY10(f1, f12, f14, one, one, half, c3, c4, c5, c6, c7, c8, c9);
        e0 *= e0;
        e1 *= e1;
        xv[i] = p0 * e0 * e0;
        xv[i+1] = p1 * e1 * e1;
    }
    if((nv & 1) != 0) {
        doublev8 x0 = xv[nv-1];
        doublev8 y0 = x0 * rcp_log_2;
        int512 i0 = value_convert_d2l(y0);
        doublev8 f0 = simd_vnmad(value_convert_l2d(i0), log_2, x0);
        doublev8 p0 = scale_up_pow2(one, i0, mask);
        f0 *= quarter;
        doublev8 f02 = f0 * f0, f04 = f02 * f02;
        doublev8 e0 = DPOLY10_(f0, f02, f04, one, one, half, c3, c4, c5, c6, c7, c8, c9);
        e0 *= e0;
        xv[nv-1] = p0 * e0 * e0;
    }
}

void swSparse_s_vec_log_abs(const float* data, float* abs_data, float* log_data, int len, const float* table) {
    // neg_inf is actually -FLOAT_MAX
    const floatv8 log_2 = table[0], one = table[1], zero = 0.0f, neg_inf = table[2];
    const floatv8 c0 = table[3], c1 = table[4], c2 = table[5], c3 = table[6], c4 = table[7];
    const floatv8 scale = c0 * c1;  // (4 / 3)
    const int512 expbits = simd_vcastdl((doublev8)one), base = expbits >> 52, mask = expbits | (expbits << 2);

    const floatv8* xv = (const floatv8*)data;
    floatv8* yv = (floatv8*)log_data;
    floatv8* zv = (floatv8*)abs_data;
    int nv = (len + 7) >> 3, nv1 = nv - 1;
    for(int i = 0; i < nv1; i += 2) {
        floatv8 q0 = xv[i], q1 = xv[i+1];
        floatv8 x0 = simd_vcpyss(scale, q0);
        floatv8 x1 = simd_vcpyss(scale, q1);
        int512 i0 = get_exponent((doublev8)(x0 * scale), base, mask);
        int512 i1 = get_exponent((doublev8)(x1 * scale), base, mask);
        floatv8 y0 = (floatv8)scale_down_pow2((doublev8)x0, i0, mask);  // never overflow
        floatv8 y1 = (floatv8)scale_down_pow2((doublev8)x1, i1, mask);
        floatv8 p0 = value_convert_l2f(i0) * log_2;
        floatv8 p1 = value_convert_l2f(i1) * log_2;
        // x      = y * 2^p
        // log(x) = log(y) + p * log_2
        floatv8 z0 = (y0 - one) * simd_vfrecps(y0 + one), z1 = (y1 - one) * simd_vfrecps(y1 + one);
        floatv8 t0 = z0 * z0, t1 = z1 * z1, t02 = t0 * t0, t12 = t1 * t1;
        floatv8 l0 = SPOLY5(t0, t02, c0, c1, c2, c3, c4);
        floatv8 l1 = SPOLY5(t1, t12, c0, c1, c2, c3, c4);
        floatv8 r0 = simd_vmas(l0, z0, p0);
        floatv8 r1 = simd_vmas(l1, z1, p1);
        zv[i]   = x0;
        zv[i+1] = x1;
        yv[i]   = simd_vfseleqs(x0, neg_inf, r0);
        yv[i+1] = simd_vfseleqs(x1, neg_inf, r1);
    }
    if((nv & 1) != 0) {
        floatv8 q0 = xv[nv-1];
        floatv8 x0 = simd_vcpyss(scale, q0);
        int512 i0 = get_exponent((doublev8)(x0 * scale), base, mask);
        floatv8 y0 = (floatv8)scale_down_pow2((doublev8)x0, i0, mask);
        floatv8 p0 = value_convert_l2f(i0) * log_2;
        floatv8 z0 = (y0 - one) * simd_vfrecps(y0 + one);
        floatv8 t0 = z0 * z0, t02 = t0 * t0;
        floatv8 l0 = SPOLY5(t0, t02, c0, c1, c2, c3, c4);
        floatv8 r0 = simd_vmas(l0, z0, p0);
        zv[nv-1] = x0;
        yv[nv-1] = simd_vfseleqs(x0, neg_inf, r0);
    }
}

void swSparse_d_vec_log_abs(const double* data, double* abs_data, double* log_data, int len, const double* table) {
    // neg_inf is actually -DOUBLE_MAX
    const doublev8 log_2 = table[0], one = table[1], zero = 0.0, neg_inf = table[2];
    const doublev8 c0 = table[3], c1 = table[4], c2 = table[5], c3 = table[6], c4 = table[7];
    const doublev8 c5 = table[8], c6 = table[9], c7 = table[10], c8 = table[11], c9 = table[12];
    const doublev8 c10 = table[13], scale = c0 * c1;  // (4 / 3)
    const int512 expbits = simd_vcastdl(one), base = expbits >> 52, mask = expbits | (expbits << 2);
    const doublev8* xv = (const doublev8*)data;
    doublev8* yv = (doublev8*)log_data;
    doublev8* zv = (doublev8*)abs_data;
    int nv = (len + 7) >> 3, nv1 = nv - 1;
    for(int i = 0; i < nv1; i += 2) {
        doublev8 q0 = xv[i], q1 = xv[i+1];
        doublev8 x0 = simd_vcpysd(scale, q0);
        doublev8 x1 = simd_vcpysd(scale, q1);
        int512 i0 = get_exponent(x0 * scale, base, mask);
        int512 i1 = get_exponent(x1 * scale, base, mask);
        doublev8 y0 = scale_down_pow2(x0, i0, mask);
        doublev8 y1 = scale_down_pow2(x1, i1, mask);
        doublev8 p0 = value_convert_l2d(i0) * log_2;
        doublev8 p1 = value_convert_l2d(i1) * log_2;
        // x      = y * 2^p
        // log(x) = log(y) + p * log_2
        doublev8 z0 = (y0 - one) * simd_vfrecpd(y0 + one), z1 = (y1 - one) * simd_vfrecpd(y1 + one);
        doublev8 t0 = z0 * z0, t1 = z1 * z1, t02 = t0 * t0, t12 = t1 * t1;
        doublev8 t04 = t02 * t02, t14 = t12 * t12;
        doublev8 l0 = DPOLY11(t0, t02, t04, c0, c1, c2, c3, c4, c5, c6, c7, c8, c9, c10);
        doublev8 l1 = DPOLY11(t1, t12, t14, c0, c1, c2, c3, c4, c5, c6, c7, c8, c9, c10);
        doublev8 r0 = simd_vmad(l0, z0, p0);
        doublev8 r1 = simd_vmad(l1, z1, p1);
        zv[i]   = x0;
        zv[i+1] = x1;
        yv[i]   = simd_vfseleqd(x0, neg_inf, r0);
        yv[i+1] = simd_vfseleqd(x1, neg_inf, r1);
    }
    if((nv & 1) != 0) {
        doublev8 q0 = xv[nv-1];
        doublev8 x0 = simd_vcpysd(scale, q0);
        int512 i0 = get_exponent(x0 * scale, base, mask);
        doublev8 y0 = scale_down_pow2(x0, i0, mask);
        doublev8 p0 = value_convert_l2d(i0) * log_2;
        doublev8 z0 = (y0 - one) * simd_vfrecpd(y0 + one);
        doublev8 t0 = z0 * z0, t02 = t0 * t0, t04 = t02 * t02;
        doublev8 l0 = DPOLY11_(t0, t02, t04, c0, c1, c2, c3, c4, c5, c6, c7, c8, c9, c10);
        doublev8 r0 = simd_vmad(l0, z0, p0);
        zv[nv-1] = x0;
        yv[nv-1] = simd_vfseleqd(x0, neg_inf, r0);
    }
}

#if SWSPARSE_COMPLEX_SAFE_NUMERICS > 1
// prevent overflow
INLINE doublev8 dcomplex_magnitude(doublev8 r, doublev8 i, intv16 il, intv16 ih, doublev8 one) {
    doublev8 rr = simd_vshfd(r, i, il);
    doublev8 ri = simd_vshfd(r, i, ih);
    doublev8 abs_r = simd_vcpysd(one, rr), abs_i = simd_vcpysd(one, ri);
    doublev8 diff = abs_r - abs_i;
    doublev8 small = simd_vfselltd(diff, abs_r, abs_i);
    doublev8 large = simd_vfselltd(diff, abs_i, abs_r);
    doublev8 ratio = small * simd_vfrecpd(large);
    return large * simd_vsqrtd(one + ratio * ratio);
}
INLINE floatv8 scomplex_magnitude(floatv8 r, floatv8 i, intv16 il, intv16 ih, floatv8 one) {
    floatv8 rr = simd_vshfs(r, i, il);
    floatv8 ri = simd_vshfs(r, i, ih);
    floatv8 abs_r = simd_vcpyss(one, rr), abs_i = simd_vcpyss(one, ri);
    floatv8 diff = abs_r - abs_i;
    floatv8 small = simd_vfsellts(diff, abs_r, abs_i);
    floatv8 large = simd_vfsellts(diff, abs_i, abs_r);
    floatv8 ratio = small  * simd_vfrecps(large);
    return large * simd_vsqrts(one + ratio * ratio);
}
#define SMAG(r, i, il, ih, one) scomplex_magnitude(r, i, il, ih, one)
#define DMAG(r, i, il, ih, one) dcomplex_magnitude(r, i, il, ih, one)
#else

INLINE doublev8 dcomplex_magnitude(doublev8 r, doublev8 i, intv16 il, intv16 ih) {
    doublev8 rr = simd_vshfd(r, i, il);
    doublev8 ri = simd_vshfd(r, i, ih);
    return simd_vsqrtd(rr * rr + ri * ri);
}
INLINE floatv8 scomplex_magnitude(floatv8 r, floatv8 i, intv16 il, intv16 ih) {
    floatv8 rr = simd_vshfs(r, i, il);
    floatv8 ri = simd_vshfs(r, i, ih);
    return simd_vsqrts(rr * rr + ri * ri);
}
#define SMAG(r, i, il, ih, _) scomplex_magnitude(r, i, il, ih)
#define DMAG(r, i, il, ih, _) dcomplex_magnitude(r, i, il, ih)
#endif

void swSparse_c_vec_log_abs(const void* data, float* abs_data, float* log_data, int len, const clogabs_table_t* table) {
    const intv16 il = table->shfl_idx[0], ih = table->shfl_idx[1];
    const floatv8 log_2 = table->math_const[0], one = table->math_const[1], zero = 0.0f, neg_inf = table->math_const[2];
    const floatv8 c0 = table->math_const[3], c1 = table->math_const[4], c2 = table->math_const[5], c3 = table->math_const[6];
    const floatv8 c4 = table->math_const[7], scale = c0 * c1;  // (4 / 3)
    const int512 expbits = simd_vcastdl((doublev8)one), base = expbits >> 52, mask = expbits | (expbits << 2);
    
    const floatv8* xv = (const floatv8*)data;
    floatv8* yv = (floatv8*)log_data;
    floatv8* zv = (floatv8*)abs_data;
    int nv = (len + 7) >> 3, nv1 = nv - 1;
    for(int i = 0; i < nv1; i += 2) {
        int j = i << 1;
        floatv8 q0r = xv[j], q0i = xv[j+1], q1r = xv[j+2], q1i = xv[j+3];
        floatv8 x0 = SMAG(q0r, q0i, il, ih, one);
        floatv8 x1 = SMAG(q1r, q1i, il, ih, one);
        int512 i0 = get_exponent((doublev8)(x0 * scale), base, mask);
        int512 i1 = get_exponent((doublev8)(x1 * scale), base, mask);
        floatv8 y0 = (floatv8)scale_down_pow2((doublev8)x0, i0, mask);  // never overflow
        floatv8 y1 = (floatv8)scale_down_pow2((doublev8)x1, i1, mask);
        floatv8 p0 = value_convert_l2f(i0) * log_2;
        floatv8 p1 = value_convert_l2f(i1) * log_2;
        // x      = y * 2^p
        // log(x) = log(y) + p * log_2
        floatv8 z0 = (y0 - one) * simd_vfrecps(y0 + one), z1 = (y1 - one) * simd_vfrecps(y1 + one);
        floatv8 t0 = z0 * z0, t1 = z1 * z1, t02 = t0 * t0, t12 = t1 * t1;
        floatv8 l0 = SPOLY5(t0, t02, c0, c1, c2, c3, c4);
        floatv8 l1 = SPOLY5(t1, t12, c0, c1, c2, c3, c4);
        floatv8 r0 = simd_vmas(l0, z0, p0);
        floatv8 r1 = simd_vmas(l1, z1, p1);
        zv[i]   = x0;
        zv[i+1] = x1;
        yv[i]   = simd_vfseleqs(x0, neg_inf, r0);
        yv[i+1] = simd_vfseleqs(x1, neg_inf, r1);
    }
    if((nv & 1) != 0) {
        int j = nv << 1;
        floatv8 q0r = xv[j-2], q0i = xv[j-1];
        floatv8 x0 = SMAG(q0r, q0i, il, ih, one);
        int512 i0 = get_exponent((doublev8)(x0 * scale), base, mask);
        floatv8 y0 = (floatv8)scale_down_pow2((doublev8)x0, i0, mask);
        floatv8 p0 = value_convert_l2f(i0) * log_2;
        floatv8 z0 = (y0 - one) * simd_vfrecps(y0 + one);
        floatv8 t0 = z0 * z0, t02 = t0 * t0;
        floatv8 l0 = SPOLY5(t0, t02, c0, c1, c2, c3, c4);
        floatv8 r0 = simd_vmas(l0, z0, p0);
        zv[nv-1] = x0;
        yv[nv-1] = simd_vfseleqs(x0, neg_inf, r0);
    }
}

void swSparse_z_vec_log_abs(const void* data, double* abs_data, double* log_data, int len, const zlogabs_table_t* table) {
    const intv16 il = table->shfl_idx[0], ih = table->shfl_idx[1];
    const doublev8 log_2 = table->math_const[0], one = table->math_const[1], zero = 0.0, neg_inf = table->math_const[2];
    const doublev8 c0 = table->math_const[3], c1 = table->math_const[4], c2 = table->math_const[5];
    const doublev8 c3 = table->math_const[6], c4 = table->math_const[7], c5 = table->math_const[8];
    const doublev8 c6 = table->math_const[9], c7 = table->math_const[10], c8 = table->math_const[11];
    const doublev8 c9 = table->math_const[12], c10 = table->math_const[13], scale = c0 * c1;  // (4 / 3)
    const int512 expbits = simd_vcastdl(one), base = expbits >> 52, mask = expbits | (expbits << 2);
    const doublev8* xv = (const doublev8*)data;
    doublev8* yv = (doublev8*)log_data;
    doublev8* zv = (doublev8*)abs_data;
    int nv = (len + 7) >> 3, nv1 = nv - 1;
    for(int i = 0; i < nv1; i += 2) {
        int j = i << 1;
        doublev8 q0r = xv[j], q0i = xv[j+1], q1r = xv[j+2], q1i = xv[j+3];
        doublev8 x0 = DMAG(q0r, q0i, il, ih, one);
        doublev8 x1 = DMAG(q1r, q1i, il, ih, one);
        int512 i0 = get_exponent(x0 * scale, base, mask);
        int512 i1 = get_exponent(x1 * scale, base, mask);
        doublev8 y0 = scale_down_pow2(x0, i0, mask);
        doublev8 y1 = scale_down_pow2(x1, i1, mask);
        doublev8 p0 = value_convert_l2d(i0) * log_2;
        doublev8 p1 = value_convert_l2d(i1) * log_2;
        // x      = y * 2^p
        // log(x) = log(y) + p * log_2
        doublev8 z0 = (y0 - one) * simd_vfrecpd(y0 + one), z1 = (y1 - one) * simd_vfrecpd(y1 + one);
        doublev8 t0 = z0 * z0, t1 = z1 * z1, t02 = t0 * t0, t12 = t1 * t1;
        doublev8 t04 = t02 * t02, t14 = t12 * t12;
        doublev8 l0 = DPOLY11(t0, t02, t04, c0, c1, c2, c3, c4, c5, c6, c7, c8, c9, c10);
        doublev8 l1 = DPOLY11(t1, t12, t14, c0, c1, c2, c3, c4, c5, c6, c7, c8, c9, c10);
        doublev8 r0 = simd_vmad(l0, z0, p0);
        doublev8 r1 = simd_vmad(l1, z1, p1);
        zv[i]   = x0;
        zv[i+1] = x1;
        yv[i]   = simd_vfseleqd(x0, neg_inf, r0);
        yv[i+1] = simd_vfseleqd(x1, neg_inf, r1);
    }
    if((nv & 1) != 0) {
        int j = nv << 1;
        doublev8 q0r = xv[j-2], q0i = xv[j-1];
        doublev8 x0 = DMAG(q0r, q0i, il, ih, one);
        int512 i0 = get_exponent(x0 * scale, base, mask);
        doublev8 y0 = scale_down_pow2(x0, i0, mask);
        doublev8 p0 = value_convert_l2d(i0) * log_2;
        doublev8 z0 = (y0 - one) * simd_vfrecpd(y0 + one);
        doublev8 t0 = z0 * z0, t02 = t0 * t0, t04 = t02 * t02;
        doublev8 l0 = DPOLY11_(t0, t02, t04, c0, c1, c2, c3, c4, c5, c6, c7, c8, c9, c10);
        doublev8 r0 = simd_vmad(l0, z0, p0);
        zv[nv-1] = x0;
        yv[nv-1] = simd_vfseleqd(x0, neg_inf, r0);
    }
}

#else // use libm_slave for accurate result
#include<math.h>
#include<complex.h>

void swSparse_s_vec_exp(float* data, int len, const float* table) {
    for(int i = 0; i < len; ++i) {
        data[i] = expf(data[i]);
    }
}

void swSparse_d_vec_exp(double* data, int len, const double* table) {
    for(int i = 0; i < len; ++i) {
        data[i] = exp(data[i]);
    }
}

void swSparse_s_vec_log_abs(const float* data, float* abs_data, float* log_data, int len, const float* table) {
    for(int i = 0; i < len; ++i) {
        abs_data[i] = fabsf(data[i]);
        log_data[i] = logf(abs_data[i]);
    }
}

void swSparse_d_vec_log_abs(const double* data, double* abs_data, double* log_data, int len, const double* table) {
    for(int i = 0; i < len; ++i) {
        abs_data[i] = fabs(data[i]);
        log_data[i] = log(abs_data[i]);
    }
}

void swSparse_c_vec_log_abs(const void* data, float* abs_data, float* log_data, int len, const clogabs_table_t* table) {
    const float complex* x = (const float complex*)data;
    for(int i = 0; i < len; ++i) {
        abs_data[i] = cabsf(x[i]);
        log_data[i] = logf(abs_data[i]);
    }
}

void swSparse_z_vec_log_abs(const void* data, double* abs_data, double* log_data, int len, const zlogabs_table_t* table) {
    const double complex* x = (const double complex*)data;
    for(int i = 0; i < len; ++i) {
        abs_data[i] = cabs(x[i]);
        log_data[i] = log(abs_data[i]);
    }
}

#endif