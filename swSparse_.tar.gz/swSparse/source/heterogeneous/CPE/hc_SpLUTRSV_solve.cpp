#include <crts.h>
#include <stdio.h>
#include <cstring>
#include <cassert>
#include "swperf.h"
#include "internal/rename.h"
#include "internal/utils.h"
#include "internal/CPE.h"
#include "internal/CPE_communicator.h"
#include "internal/sptrf_common.h"
#include "internal/splutrsv_param.h"
#include "swSparse_splutrsv.h"

#define MAX_MESSAGE_SIZE 16
inline constexpr Int etree_empty = -1;

namespace swSparse {

// comm
template <typename DATA_T>
class lutrsv_comm {
private:
    inline void send_issue() {
        send_counter += 1;
    }
    inline void recv_issue() {
        recv_counter += 1;
    }
    void isend(Int target, Int data_size) {
        CRTS_rma_iput(data, &send_reply, data_size, target, data, &recv_reply);
    }
    void wait() {
        CRTS_rma_wait_value(&recv_reply, recv_counter);
    }
public:
    // subtree_sup_id
    Int finished_sup[64];
    crts_rply_t finished_sup_reply;

    // task_sup_id
    Int finished_queue_id[64];
    crts_rply_t finished_queue_id_reply;

    // counter
    rply_counter_t send_counter, recv_counter;
    // reply
    crts_rply_t send_reply, recv_reply;
    // data
    DATA_T data[MAX_MESSAGE_SIZE];

    lutrsv_comm() : send_reply(0), recv_reply(0), send_counter(0), recv_counter(0) {
        memset(finished_sup, 0, sizeof(Int) * 64);
        memset(finished_queue_id, 0, sizeof(Int) * 64);
        memset(data, 0, sizeof(DATA_T) * MAX_MESSAGE_SIZE);
        send_counter = 0;
        recv_counter = 0;
        send_reply = 0;
        recv_reply = 0;
    }
    inline Int rank2id(Int partner_rank, Int root_rank, Int group_size, int8_t* partners) {
        auto pr1 = root_rank + partner_rank;
        auto pr2 = pr1 - ((pr1 >= group_size) ? group_size : 0);
        return partners[pr2];
    }
    void sync_and_recv_data(Int partner_id) {
        CRTS_ssync_peer(partner_id);
        recv_issue();
        wait();
    }
    void sync_and_send_data(Int partner_id, Int data_size) {
        CRTS_ssync_peer(partner_id);
        send_issue();
        isend(partner_id, sizeof(DATA_T) * data_size);
    }
    void flush() {
        flush_slave_cache();
        mem_fence();
    }
    void broadcast_finished_sup(Int sup) {
        finished_sup[CRTS_tid] = sup;
        // broadcast finished_sup
        CRTS_rma_ibcast(&finished_sup[CRTS_tid], &finished_sup[CRTS_tid], &finished_sup_reply, sizeof(Int), &finished_sup_reply);
    }
    void broadcast_finished_queue_id(Int queue_id) {
        finished_queue_id[CRTS_tid] = queue_id;
        // broadcast finished_queue_id
        CRTS_rma_ibcast(&finished_queue_id[CRTS_tid], &finished_queue_id[CRTS_tid], &finished_queue_id_reply, sizeof(Int), &finished_queue_id_reply);
    }
    // todo: tree broadcast
    void broadcast(Int root_rank, Int n, Int group_size, Int group_rank, int8_t* partner, Int data_size) {
        if(n <= 1) return;
    }
};

// 求解 Ly = b
template<typename DATA_T>
void lutrsv_lsolve_kernel(void *p_args)
{
    // args
    splutrsv_arg_t<DATA_T> args;
    DMA_READ_NODESC(p_args, &args, sizeof(splutrsv_arg_t<DATA_T>));
    Int n = args.n;
    DATA_T* x = args.x;
    Int nsup = args.lusup->nsuper;
    swSparseLUSupernodes *lusup = args.lusup;
    
    Int *sup2col = args.lusup->sup2col;
    Int *col2sup = args.lusup->col2sup;

    Int *l_v_offsets = args.lusup->l_v_offsets;
    Int *l_i_offsets = args.lusup->l_i_offsets;
    Int *l_indices = args.lusup->l_indices;
    DATA_T *l_values = (DATA_T*)args.lusup->l_values;

    Int *u_col_offsets = args.lusup->u_col_offsets;
    Int *u_seg_offsets = args.lusup->u_seg_offsets;
    Int *u_seg_indices = args.lusup->u_seg_indices;
    DATA_T *u_values = (DATA_T*)args.lusup->u_values;

    Int* parent = args.lusup->sup_etree_parent;
    Int* first_child = args.first_child;
    Int* next_sibling = args.next_sibling;
    Int* snode_status = args.snode_status;

    trf_subtree_t* subtrees = (swSparse::trf_subtree_t*)args.subtrees;
    Int* subtree_offsets = args.subtree_offsets;
    lutrsv_task_t* tasks = (lutrsv_task_t*)args.tasks;
    Int* task_offsets = args.task_offsets;
    lutrsv_task_t* task_queue = (lutrsv_task_t*)args.task_queue;

    // 阵列同步
    lutrsv_comm<DATA_T> comm;
    CRTS_ssync_array();

    // subtree part
    // for each subtree
    for(Int offset = subtree_offsets[CRTS_tid]; offset < subtree_offsets[CRTS_tid + 1]; ++offset) {
        //for each sup
        Int sup_begin = subtrees[offset].sup_begin, sup_end = subtrees[offset].sup_end;
        for(Int jsup = sup_begin; jsup < sup_end; ++jsup) {
            Int p, k, j_sup_begin = sup2col[jsup], j_sup_end = sup2col[jsup + 1], supsize = j_sup_end - j_sup_begin;
            Int v_off = l_v_offsets[jsup];
            Int ld = l_i_offsets[jsup + 1] - l_i_offsets[jsup] + supsize;
            const DATA_T *l_sup_val = &l_values[v_off];
            for(Int j = j_sup_begin; j < j_sup_end; ++j) {  
                // off-diagnal block
                for(k = u_col_offsets[j]; k < u_col_offsets[j + 1]; ++k) {
                    Int segoff = u_seg_offsets[k], segsize = u_seg_offsets[k + 1] - segoff;
                    Int segrep = u_seg_indices[k];
                    for(p = 0; p < segsize; ++p) {
                        x[j] -= u_values[segoff + p] * x[segrep + p];
                    }
                }
                Int jrel = j - j_sup_begin;
                const DATA_T *l_row_val = &l_sup_val[jrel * ld];
                // diagnal block
                for(p = 0; p < jrel; ++p) {                    
                    x[j] -= l_row_val[p] * x[j_sup_begin + p];
                }
                // reciprocal diagnal
                x[j] = x[j] * l_row_val[jrel];                
            }
        }
        Int row_begin = sup2col[sup_begin], row_end = sup2col[sup_end];
       
        // evict_cache(&x[row_begin], &x[row_end]);
        comm.flush();
        comm.broadcast_finished_sup(sup_end);
    }
    
    // task_part
    // for each task
    for(Int offset = task_offsets[CRTS_tid]; offset < task_offsets[CRTS_tid + 1]; ++offset) {
        // 可能由多个核心处理，根据 stride 大小对行分块
        // 一个核心可能处理多个 stride
        Int jsup = tasks[offset].sup_id, stride = tasks[offset].stride;
        Int group_size = tasks[offset].group.size, group_id = tasks[offset].group.id;
        Int group_npart = tasks[offset].group.npart;
        Int queue_id = tasks[offset].queue_id;
        int8_t* partner = tasks[offset].group.partner;
        
        Int j_sup_begin = sup2col[jsup], j_sup_end = sup2col[jsup + 1], supsize = j_sup_end - j_sup_begin;
        Int v_off = l_v_offsets[jsup];
        Int ld = l_i_offsets[jsup + 1] - l_i_offsets[jsup] + supsize;
        const DATA_T *l_sup_val = &l_values[v_off];

        // 等待子节点完成
        volatile Int child = first_child[jsup];
        while(child != etree_empty) {
            if(snode_status[child] < 0) {
                volatile Int tid = snode_status[child] + 64;
                while(child >= comm.finished_sup[tid]);
            } else {
                // 只考虑 part_id 为 0 的核心
                Int child_group_npart = task_queue[snode_status[child]].group.npart;
                int8_t* child_group_partner = task_queue[snode_status[child]].group.partner;
                for(Int rank = 0; rank < child_group_npart; ++rank) {
                    volatile Int tid = child_group_partner[rank];
                    while(snode_status[child] >= comm.finished_queue_id[tid]);
                }
            }
            child = next_sibling[child];
        }
         
        // 计算非对角块, part_num: 第几个分区, part_id: 分区内的 id
        Int part_num = group_id % group_npart, part_id = group_id / group_npart;
        Int part_size = group_size / group_npart;

        for(Int j = j_sup_begin + stride * part_num; j < j_sup_end; j += stride * group_npart) {
            Int j_end = std::min(j_sup_end, j + stride);
            Int data_size = j_end - j;
            memset(comm.data, 0, sizeof(DATA_T) * data_size);
            
            for(Int j_real = j; j_real < j_end; ++j_real) {
                Int seg_off_start = u_col_offsets[j_real], seg_off_end = u_col_offsets[j_real + 1];
                Int seg_off_size = seg_off_end - seg_off_start;
                
                Int part_seg_off_size = seg_off_size / part_size;
                Int part_seg_off_start = seg_off_start + part_seg_off_size * part_id;
                Int part_seg_off_end = part_seg_off_start + part_seg_off_size;
                if(part_id == part_size - 1) part_seg_off_end = seg_off_end;

                for(Int k = part_seg_off_start; k < part_seg_off_end; ++k) {
                    Int segoff = u_seg_offsets[k], segsize = u_seg_offsets[k + 1] - segoff;
                    Int segrep = u_seg_indices[k];
                    for(Int p = 0; p < segsize; ++p) {
                        comm.data[j_real - j] += u_values[segoff + p] * x[segrep + p];
                    }
                }
            }

            Int root_id = 0;
            if(part_id == root_id) {
                // 先计算本地的累积
                for(Int j_real = j; j_real < j_end; ++j_real) {
                    x[j_real] -= comm.data[j_real - j];
                }

                for(Int partner_rank = 1; partner_rank < part_size; ++partner_rank) {
                    Int partner_id = partner[partner_rank * group_npart + part_num];
                    comm.sync_and_recv_data(partner_id);

                    for(Int j_real = j; j_real < j_end; ++j_real) {
                        x[j_real] -= comm.data[j_real - j];
                    }
                }
            } else {
                Int partner_id = partner[root_id * group_npart + part_num];
                comm.sync_and_send_data(partner_id, data_size);
            }
        }

        // 计算对角块
        if(part_id != 0) {
            // 可能由于 cacheline 机制读取到还未计算出的 x, 必须刷缓存保证后续可以获取最新数据
            // part_id != 0 的核心没有修改 x，刷缓存不会影响正确性
            comm.flush();
        } else {
            // 只有 part_id == 0 的核心参与对角块计算
            for(Int j = j_sup_begin; j < j_sup_end; j += stride) {
                Int root_id = (j - j_sup_begin) / stride;
                root_id %= group_npart;
                Int j_end = std::min(j_sup_end, j + stride);
                Int data_size = j_end - j;
                if(group_id == root_id) {
                    for(Int t = j; t < j_end; ++t) {
                        Int jrel = t - j_sup_begin;
                        const DATA_T *l_row_val = &l_sup_val[jrel * ld];
                        for(Int p = j; p < t; ++p) {
                            x[t] -= l_row_val[p - j_sup_begin] * x[p];
                        }
                        x[t] = x[t] * l_row_val[jrel];                // reciprocal diagnal
                    }

                    memcpy(comm.data, &x[j], sizeof(DATA_T) * data_size);
                    for(Int partner_rank = 1; partner_rank < group_npart; ++partner_rank) {
                        Int partner_id = comm.rank2id(partner_rank, root_id, group_npart, partner);
                        comm.sync_and_send_data(partner_id, data_size);
                    }

                    Int t = j + group_npart * stride;
                    for(; t < j_sup_end; t += stride * group_npart) {
                        Int t_end = std::min(j_sup_end, t + stride);
                        for(Int t_real = t; t_real < t_end; ++t_real) {
                            Int jrel = t_real - j_sup_begin;
                            const DATA_T *l_row_val = &l_sup_val[jrel * ld];
                            for(Int p = 0; p < data_size; ++p) {
                                x[t_real] -= l_row_val[p + j - j_sup_begin] * comm.data[p];
                            }
                        }
                    }

                } else {
                    Int partner_rank = 0;
                    Int partner_id = comm.rank2id(0, root_id, group_npart, partner);
                    comm.sync_and_recv_data(partner_id);

                    Int t = j + ((group_id - root_id + group_npart) % group_npart) * stride;
                    for(; t < j_sup_end; t += stride * group_npart) {
                        Int t_end = std::min(j_sup_end, t + stride);
                        for(Int t_real = t; t_real < t_end; ++t_real) {
                            Int jrel = t_real - j_sup_begin;
                            const DATA_T *l_row_val = &l_sup_val[jrel * ld];
                            for(Int p = 0; p < data_size; ++p) {
                                x[t_real] -= l_row_val[p + j - j_sup_begin] * comm.data[p];
                            }
                        }
                    }
                }
            }

            // evict_cache(&x[j_sup_begin], &x[j_sup_end]);
            comm.flush();
            comm.broadcast_finished_queue_id(queue_id + 1);
        }
    }
}

// 求解 Ux = y
template<typename DATA_T>
void lutrsv_usolve_kernel(void *p_args)
{
    // args
    splutrsv_arg_t<DATA_T> args;
    DMA_READ_NODESC(p_args, &args, sizeof(splutrsv_arg_t<DATA_T>));
    Int n = args.n;
    DATA_T* x = args.x;
    Int nsup = args.lusup->nsuper;
    swSparseLUSupernodes *lusup = args.lusup;
    
    Int *sup2col = args.lusup->sup2col;
    Int *col2sup = args.lusup->col2sup;

    Int *l_v_offsets = args.lusup->l_v_offsets;
    Int *l_i_offsets = args.lusup->l_i_offsets;
    Int *l_indices = args.lusup->l_indices;
    DATA_T *l_values = (DATA_T*)args.lusup->l_values;

    Int* snode_parent = args.lusup->sup_etree_parent;
    Int* first_child = args.first_child;
    Int* next_sibling = args.next_sibling;
    Int* snode_status = args.snode_status;

    swSparse::trf_subtree_t* subtrees = (swSparse::trf_subtree_t*)args.subtrees;
    Int* subtree_offsets = args.subtree_offsets;
    lutrsv_task_t* tasks = (lutrsv_task_t*)args.tasks;
    Int* task_offsets = args.task_offsets;
    lutrsv_task_t* task_queue = (lutrsv_task_t*)args.task_queue;

    lutrsv_comm<DATA_T> comm;
    for(Int i = 0; i < 64; ++i) {
        comm.finished_queue_id[i] = nsup;
    }
    // 阵列同步
    CRTS_ssync_array();

    // 与 L 部分不同，U 部分从树顶向树底调度，因此先计算任务队列
    // task_part
    // for each task
    for(Int offset = task_offsets[CRTS_tid + 1] - 1; offset >= task_offsets[CRTS_tid]; --offset) {
        // 可能由多个核心处理，根据 stride 大小对行分块
        // 一个核心可能处理多个 stride
        Int jsup = tasks[offset].sup_id, stride = tasks[offset].stride;
        // stride belongs to {8, 16}
        assert(stride <= MAX_MESSAGE_SIZE);
        Int group_size = tasks[offset].group.size, group_id = tasks[offset].group.id;
        Int queue_id = tasks[offset].queue_id;
        Int group_npart = tasks[offset].group.npart;
        int8_t* partner = tasks[offset].group.partner;
        
        Int j_sup_begin = sup2col[jsup], j_sup_end = sup2col[jsup + 1], supsize = j_sup_end - j_sup_begin;
        Int v_off = l_v_offsets[jsup], i_off = l_i_offsets[jsup] - supsize;;
        Int ld = l_i_offsets[jsup + 1] - l_i_offsets[jsup] + supsize;
        const DATA_T *l_sup_val = &l_values[v_off];
        const Int *l_sup_idx = &l_indices[i_off];

        // 等待父节点完成
        volatile Int parent = snode_parent[jsup];
        if(LIKELY(parent != nsup)) {
            assert(parent >= 0);
            assert(snode_status[parent] >= 0);
            // 只等待 part_id 为 0 的核心
            Int parent_group_npart = task_queue[snode_status[parent]].group.npart;
            int8_t* parent_group_partner = task_queue[snode_status[parent]].group.partner;
            for(Int rank = 0; rank < parent_group_npart; ++rank) {
                volatile Int tid = parent_group_partner[rank];
                while(snode_status[parent] <= comm.finished_queue_id[tid]);
            }
        }

        // 计算非对角块
        Int part_num = group_id % group_npart, part_id = group_id / group_npart;
        Int part_size = group_size / group_npart;

        Int part_indice_size = (ld - supsize) / part_size;
        Int part_indice_start = supsize + part_indice_size * part_id;
        Int part_indice_end = part_indice_start + part_indice_size;
        if(part_id == part_size - 1) part_indice_end = ld;

        for(Int j = j_sup_end - 1 - stride * part_num; j > j_sup_begin - 1; j -= stride * group_npart) {
            Int j_end = std::max(j_sup_begin - 1, j - stride);
            Int data_size = j - j_end;
            memset(comm.data, 0, sizeof(DATA_T) * data_size);
            
            for(Int p = part_indice_start; p < part_indice_end; ++p) {
                Int l_col_id = l_sup_idx[p];
                for(Int j_real = j; j_real > j_end; --j_real) {
                    Int jrel = j_real - j_sup_begin;
                    const DATA_T *l_row_val = &l_sup_val[jrel * ld];
                    comm.data[j - j_real] += l_row_val[p] * x[l_col_id];
                }
            }

            Int root_id = 0;
            if(part_id == root_id) {
                // 先计算本地的累积
                for(Int j_real = j; j_real > j_end; --j_real) {
                    x[j_real] -= comm.data[j - j_real];
                }

                for(Int partner_rank = 1; partner_rank < part_size; ++partner_rank) {
                    Int partner_id = partner[partner_rank * group_npart + part_num];
                    comm.sync_and_recv_data(partner_id);

                    for(Int j_real = j; j_real > j_end; --j_real) {
                        x[j_real] -= comm.data[j - j_real];
                    }
                }
            } else {
                Int partner_id = partner[root_id * group_npart + part_num];
                comm.sync_and_send_data(partner_id, data_size);
            }
        }

        // 计算对角块
        if(part_id != 0) {
            // 可能由于 cacheline 机制读取到还未计算出的 x, 必须刷缓存保证后续可以获取最新数据
            // part_id != 0 的核心没有修改 x，刷缓存不会影响正确性
            comm.flush();
        } else {
            // 只有 part_id == 0 的核心参与对角块计算
            for(Int j = j_sup_end - 1; j > j_sup_begin - 1; j -= stride) {
                Int root_id = (j_sup_end - 1 - j) / stride;
                root_id %= group_npart;
                Int j_end = std::max(j_sup_begin - 1, j - stride);
                Int data_size = j - j_end;
                if(group_id == root_id) {

                    for(Int t = j; t > j_end; --t) {
                        Int jrel = t - j_sup_begin;
                        const DATA_T *l_row_val = &l_sup_val[jrel * ld];
                        for(Int p = t + 1; p <= j; ++p) {
                            x[t] -= l_row_val[p - j_sup_begin] * x[p];
                        }
                    }

                    memcpy(comm.data, &x[j_end + 1], sizeof(DATA_T) * data_size);
                    for(Int partner_rank = 1; partner_rank < group_npart; ++partner_rank) {
                        Int partner_id = comm.rank2id(partner_rank, root_id, group_npart, partner);
                        comm.sync_and_send_data(partner_id, data_size);
                    }

                    Int t = j - group_npart * stride;
                    for(; t > j_sup_begin - 1; t -= stride * group_npart) {
                        Int t_end = std::max(j_sup_begin - 1, t - stride);
                        for(Int t_real = t; t_real > t_end; --t_real) {
                            Int jrel = t_real - j_sup_begin;
                            const DATA_T *l_row_val = &l_sup_val[jrel * ld];
                            for(Int p = 0; p < data_size; ++p) {
                                x[t_real] -= l_row_val[p + j_end + 1 - j_sup_begin] * comm.data[p];
                            }
                        }
                    }

                } else {
                    Int partner_rank = 0;
                    Int partner_id = comm.rank2id(0, root_id, group_npart, partner);
                    comm.sync_and_recv_data(partner_id);

                    Int t = j - ((group_id - root_id + group_npart) % group_npart) * stride;
                    for(; t > j_sup_begin - 1; t -= stride * group_npart) {
                        Int t_end = std::max(j_sup_begin - 1, t - stride);
                        for(Int t_real = t; t_real > t_end; --t_real) {
                            Int jrel = t_real - j_sup_begin;
                            const DATA_T *l_row_val = &l_sup_val[jrel * ld];
                            for(Int p = 0; p < data_size; ++p) {
                                x[t_real] -= l_row_val[p + j_end + 1 - j_sup_begin] * comm.data[p];
                            }
                        }
                    }
                }
            }

            // evict_cache(&x[j_sup_begin], &x[j_sup_end]);
            comm.flush();
            comm.broadcast_finished_queue_id(queue_id - 1);
        }
    }

    // subtree part
    // for each subtree
    for(Int offset = subtree_offsets[CRTS_tid]; offset < subtree_offsets[CRTS_tid + 1]; ++offset) {
        //for each sup
        Int sup_begin = subtrees[offset].sup_begin, sup_end = subtrees[offset].sup_end;
        
        // 等待父节点完成，只等待 part_id 为 0 的核心
        volatile Int parent = snode_parent[sup_end - 1];
        if(LIKELY(parent != nsup)) {
            assert(parent >= 0);
            assert(snode_status[parent] >= 0);
            Int parent_group_npart = task_queue[snode_status[parent]].group.npart;
            int8_t* parent_group_partner = task_queue[snode_status[parent]].group.partner;
            for(Int rank = 0; rank < parent_group_npart; ++rank) {
                volatile Int tid = parent_group_partner[rank];
                while(snode_status[parent] <= comm.finished_queue_id[tid]);
            }
        }

        for(Int jsup = sup_end - 1; jsup >= sup_begin; --jsup) {
            Int p, k, j_sup_begin = sup2col[jsup], j_sup_end = sup2col[jsup + 1], supsize = j_sup_end - j_sup_begin;
            Int v_off = l_v_offsets[jsup], i_off = l_i_offsets[jsup] - supsize;
            Int ld = l_i_offsets[jsup + 1] - l_i_offsets[jsup] + supsize;
            const DATA_T *l_sup_val = &l_values[v_off];
            const Int *l_sup_idx = &l_indices[i_off];
            
            // off-diagnal block
            for(p = supsize; p < ld; ++p) {
                Int l_col_id = l_sup_idx[p];
                for(Int j = j_sup_end - 1; j >= j_sup_begin; --j) {
                    Int jrel = j - j_sup_begin;
                    const DATA_T *l_row_val = &l_sup_val[jrel * ld];
                    x[j] -= l_row_val[p] * x[l_col_id];
                }
            }

            // diagnal block
            for(Int j = j_sup_end - 1; j >= j_sup_begin; --j) {
                Int jrel = j - j_sup_begin;
                const DATA_T *l_row_val = &l_sup_val[jrel * ld];
                for(p = jrel + 1; p < supsize; ++p) {
                    x[j] -= l_row_val[p] * x[j_sup_begin + p];
                }
            }
        }
        Int row_begin = sup2col[sup_begin], row_end = sup2col[sup_end];
     
        // 可能由于 cache line 机制读到还未计算出的 x，影响本核心后续其他子树的计算
        // 因此必须刷新缓存（或者在任务队列处进行同步，保证读取到的 x 已计算完成）
        comm.flush();
    }
}

CPE_TEMPLATE_KERNEL(lutrsv_lsolve_kernel, CACHE_128KB)
CPE_TEMPLATE_KERNEL(lutrsv_usolve_kernel, CACHE_128KB)

};