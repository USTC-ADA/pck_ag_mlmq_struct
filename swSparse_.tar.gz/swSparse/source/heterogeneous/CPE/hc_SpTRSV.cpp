#include "swSparse_blas.h"
#include "internal/rename.h"
#include "internal/spblas_common.h"
#include "internal/memory.h"
#include "internal/debug.h"
#include "internal/utils.h"
#include "internal/reorder.h"
#include "internal/dependency.h"
#include "internal/CPE_communicator.h"
#include "internal/SpTRSV.h"

using namespace swSparse;

//#define TRSV_PRO_DEBUG
//#define TRSV_CON_DEBUG
//#define TRSV_TIMING
//#define RMA_IPUT

#if defined(TRSV_PRO_DEBUG) || defined(TRSV_CON_DEBUG)
#include <stdarg.h>
#include <string.h>
#include <stdio.h>
void trsv_debug(const char* format, ...) {
    va_list args;
    va_start(args, format);
    vfprintf(stderr, format, args);
    va_end(args);
}
#endif

#ifdef TRSV_PRO_DEBUG
#define TRSV_PRINTF(...) if(id == 0) { trsv_debug(__VA_ARGS__); }
#else
#define TRSV_PRINTF(...) ;
#endif

#ifdef TRSV_TIMING
//	#define rpcc(var) __asm__ volatile ("rcsr %0, 4\n":"=r"(var));
	#define rpcc(var) var=CRTS_stime_cycle();
	#define comp_cyc(cyc,ed,st) cyc+=ed-st;
#else
	#define rpcc(var)
	#define comp_cyc(cyc,ed,st)
#endif

template<typename DATA_T>
struct trsv_msg_t {
	DATA_T	value;
	Int		index;
};

template<typename Communicator, typename DATA_T>
static void producer_kernel(Communicator &comm, trsv_tune_t *tune, DATA_T alpha, DATA_T *x, const DATA_T *b, \
			DATA_T *_aa, Int *_ai, Int *_aj, DATA_T value_cache[2][CACHE_X], Int *_idx, Int *_level, \
			crts_rply_t *signal, Int levels, Int n, Int n_org, swSparseMatrixStatus status, unsigned long* cycles) {
#ifdef TRSV_TIMING
	unsigned long st, ed, all_st, all_ed, pro_cycles;
	unsigned long comm_cycles = 0;
	unsigned long rsv_cycles = 0;
	unsigned long ex_cycles = 0;
	rpcc(all_st)
#endif

	Int id				= comm.get_id();
	Int vector_log2		= tune->vector_log2; 
	Int cache_x_log2	= tune->cache_x_log2;
	Int producers_log2	= tune->couples_log2;
	Int big_block_log2	= cache_x_log2 + producers_log2;
	Int vector			= 1 << vector_log2;
	Int cache_x			= 1 << cache_x_log2;
	Int producers		= 1 << producers_log2;
	Int big_block		= 1 << big_block_log2;
	Int vector_2num		= vector - 1;
	Int cache_x_2num	= cache_x - 1;
	Int producers_2num	= producers - 1;
	Int big_block_2num	= big_block - 1;

	Int part_width,	 part_width_log2,  part_width_2num;
	Int core_cols,	 core_cols_log2,   core_cols_2num;
	Int comm_part,   comm_part_log2,   comm_part_2num;

	comm_part_log2	 = producers  > 4 ? tune->comm_part_log2 			  : 0;
	comm_part_log2	 = producers == 1 ? 0 								  : comm_part_log2;
	part_width_log2  = producers  > 4 ? (CORE_COLS_LOG2 - comm_part_log2) : producers_log2-comm_part_log2;
	core_cols_log2   = producers  > 4 ?  CORE_COLS_LOG2  				  : producers_log2;
	comm_part		 = 1 << comm_part_log2; 
	part_width 		 = 1 << part_width_log2;
	core_cols		 = 1 << core_cols_log2;
	comm_part_2num   = comm_part    - 1;
	part_width_2num  = part_width   - 1;
	core_cols_2num	 = core_cols    - 1;
	
	Int diag_block_part = comm_part+1;

	Int comm_id = CRTS_cid >> part_width_log2;

	crts_rply_t pro_reply = 0;

	Int nxt_partner_id = ((CRTS_tid>>core_cols_log2)<<core_cols_log2)
						+((CRTS_tid+part_width)&core_cols_2num);
	Int pre_partner_id = ((CRTS_tid>>core_cols_log2)<<core_cols_log2)
						+((CRTS_tid-part_width+core_cols)&core_cols_2num);

#ifdef RMA_IPUT
	crts_rply_t ex_rply[MAX_COMM_PART];
//	crts_rply_t *remote_ex =  remote_ldm_addr(ex_rply, nxt_partner_id);
#endif

	Int sp_id = (n + producers_2num) & producers_2num;
	Int add_n = (n << vector_log2) - n_org;

	DATA_T *x_org = x;
	
	DMA_DECL_DESC(READ_WRITE);
	
	typename Communicator::producer_status comm_status;

//	DATA_T value_cache[CACHE_X];//cache for x
	DATA_T 	  x_buffer[PRODUCER_BUFFER];//Buffer for mass memory access

	//Matrix A 
	DATA_T	aa[PRODUCER_BUFFER_A]; 
	Int		aj[PRODUCER_BUFFER_A]; 

	//level & idx
	Int		level[PRODUCER_CACHE_LEVEL];
	Int		idx  [PRODUCER_CACHE_IDX * (MAX_COMM_PART+1)]; 

	Int idx_begin	= _idx[0];// the idx of first nz belonging to the producer
	Int idx_end		= _idx[levels * diag_block_part];// the idx of last nz 
	Int all_nnz		= idx_end - idx_begin;			 // nnz of the producer

	Int	buf_idx		= 0;//index for x_buffer
	Int   a_idx		= 0;//index for buffer matrix A (aa and aj)
	_aa			   += idx_begin;
	_aj			   += idx_begin;
	Int	len			= min(PRODUCER_BUFFER_A, all_nnz);//len of matrix data for DMA
	Int begin_global= 0; //begin indices of every block

	if(len > 0) {
		DMA_IREAD(_aa, aa, len*sizeof(DATA_T));
		DMA_IREAD(_aj, aj, len*sizeof(Int));
		_aa		+= len; 
		_aj 	+= len;
		all_nnz -= len;
	}
	
	Int pre_idx = idx_begin; //the pre idx
	Int level_len;
	for(Int i = 0, i_idx = 0, i_level = 0; i < levels; i++, \
		i_idx=(i_idx+1)&PRODUCER_CACHE_IDX_2NUM, i_level=(i_level+1)&PRODUCER_CACHE_LEVEL_2NUM) {
	
		
		if(i_idx == 0) {
			Int idx_len = min(PRODUCER_CACHE_IDX, levels-i);
			DMA_IREAD(_idx + diag_block_part*i + 1, idx, idx_len*diag_block_part*sizeof(Int));
			DMA_WAIT_ALL;
		}
		if(i_level == 0) {
			level_len = min(PRODUCER_CACHE_LEVEL, levels-i);
			DMA_IREAD(_level+i, level, level_len*sizeof(Int));
			DMA_WAIT_ALL;
		}

#ifdef RMA_IPUT
		ex_rply[0] = 1;
		for(Int r = 1; r < MAX_COMM_PART; r++)
			ex_rply[r] = 0;
#endif

		Int n_block = level[i_level]; //n_vec of the block in diagnal block
		if( n_block <= 0 ) { /* non_diagnal block */
			n_block = -n_block;
			len = cache_x;//TODO
			Int base = begin_global << vector_log2;
			DMA_IREAD(x_org+(n_block<<cache_x_log2), value_cache[0], len*sizeof(DATA_T));
			DMA_WAIT_ALL;
			pre_idx = idx[i_idx*diag_block_part];
			
#ifdef RMA_IPUT
			if(comm_id & 1) {
				CRTS_ssync_peer(pre_partner_id);
				CRTS_ssync_peer(nxt_partner_id);
			} else {
				CRTS_ssync_peer(nxt_partner_id);
				CRTS_ssync_peer(pre_partner_id);
			}

			Int which = 1;
#else
			Int which = 0;
#endif
			for(Int k = 0; k < comm_part; k++) {
				/* exchange x between producers */
				//rma put x
#ifdef RMA_IPUT
				CRTS_rma_wait_value(ex_rply+k, 1);
				which ^= 1;
				if(k < comm_part-1) {
					rpcc(st)
					CRTS_rma_iput(value_cache[which], &pro_reply, cache_x*sizeof(DATA_T), nxt_partner_id, value_cache[which^1], ex_rply+k+1);
					rpcc(ed)
					comp_cyc(ex_cycles,ed,st);
				}
#else
				if(k > 0) {
					if(comm_id & 1) {
						CRTS_ssync_peer(pre_partner_id);
						CRTS_ssync_peer(nxt_partner_id);
					} else {
						CRTS_ssync_peer(nxt_partner_id);
						CRTS_ssync_peer(pre_partner_id);
					}
					CRTS_rma_put(value_cache[which], cache_x*sizeof(DATA_T), nxt_partner_id, value_cache[which^1], &pro_reply);
					which ^= 1;
					CRTS_rma_wait_value(&pro_reply, 1);
					pro_reply = 0;
				}
#endif
				/* compute mid = aa * x */
				Int nd_nnz  = idx[i_idx*diag_block_part+k+1] - pre_idx;
				while(nd_nnz > 0) {
					DMA_WAIT_ALL;
					Int dlen = min(nd_nnz, PRODUCER_BUFFER_A - a_idx);
					for(Int j = 0; j < dlen; j++) {
						Int aai 	= (aj[a_idx+j] >> big_block_log2)&cache_x_2num;
						Int aaj 	=  aj[a_idx+j]  & big_block_2num;
						Int row_ind =  aaj + base;//real row_indices
						Int dst_id 	= (row_ind>>vector_log2)&producers_2num;//dst cpe id
						trsv_msg_t<DATA_T> msg;
						msg.index = row_ind;//real row_indices
						msg.value = value_cache[which][aai] * aa[a_idx+j];
						rpcc(st)
						comm.send(msg, dst_id, comm_status);
						rpcc(ed)
						comp_cyc(comm_cycles,ed,st);
					}
					a_idx  += dlen;
					nd_nnz -= dlen;
					if(a_idx == PRODUCER_BUFFER_A && all_nnz > 0) {
						a_idx = 0;
						Int dan = min(PRODUCER_BUFFER_A, all_nnz);
						DMA_IREAD(_aa, aa, dan*sizeof(DATA_T));
						DMA_IREAD(_aj, aj, dan*sizeof(Int));
						_aa	    += dan;
						_aj     += dan;
						all_nnz -= dan;
					}
				}
				pre_idx = idx[i_idx*diag_block_part+k+1];
			}
			if(((i_level+1) <  level_len &&  level[i_level+1] > 0) //|| (i_level+1) >= level_len) { 
			 || (i_level+1) >= level_len && _level[i      +1] > 0) { 
				//next block is diagnal block TODO:don't know next block info ----gld???
				rpcc(st)
				for(Int j = 0; j < producers; j++) {
					comm.flush(j, comm_status);
				}
				rpcc(ed)
				comp_cyc(comm_cycles, ed , st);
			}

		} else { /* diagnal block */
			/* top triangle part of the diagnal block */
			Int base = (begin_global+n_block)<<vector_log2;//depart top and bottom
			Int tmp_id = (id+producers-(begin_global&producers_2num))&producers_2num;//the new_id of the producer at this block
			len = (n_block>>producers_log2) + (tmp_id < (n_block&producers_2num) ? 1 : 0);//the column_vec number of the producer in this blcok
			len = len << vector_log2; // the real column number
			if(len > 0) {
				/* for the first block, DMA_read b form MEM */
				if(i == 0) {
					DMA_IREAD(b, value_cache[0], len*sizeof(DATA_T));
					DMA_WAIT_ALL;
					for(Int j = 0; j < len; j++)
						value_cache[0][j] *= alpha;
				} else { /* recieve b from consumer */
					//
					*signal = 1;//set signal = 1;
					rpcc(st)
					while(*signal != 0);
					rpcc(ed)
					comp_cyc(rsv_cycles, ed, st);
				}
				/* compute x */
				Int nnz_dblock = idx[i_idx*diag_block_part]-pre_idx;//nnz of the producer in this diagnal block top part 
				while(nnz_dblock > 0) {
					DMA_WAIT_ALL;
					Int dlen = min(nnz_dblock, PRODUCER_BUFFER_A - a_idx);
					if(status & SWSPARSE_RECP_DIAG) {
						for(Int j = 0; j < dlen; j++) {
							Int aai = aj[a_idx+j] >> big_block_log2;//in this block, the producer-column-indices of the nonzero
							Int aaj = aj[a_idx+j]  & big_block_2num;//in this block, the producer-row-indices of the nonzero
							value_cache[0][aaj] = (aai == aaj ? (value_cache[0][aaj] * aa[a_idx+j]) : \
										  (value_cache[0][aaj] - value_cache[0][aai] * aa[a_idx+j]));
						}
					} else {
						for(Int j = 0; j < dlen; j++) {
							Int aai = aj[a_idx+j] >> big_block_log2;//in this block, the producer-column-indices of the nonzero
							Int aaj = aj[a_idx+j]  & big_block_2num;//in this block, the producer-row-indices of the nonzero
							value_cache[0][aaj] = (aai == aaj ? (value_cache[0][aaj] / aa[a_idx+j]) : \
										  (value_cache[0][aaj] - value_cache[0][aai] * aa[a_idx+j]));
						}
					}
					a_idx += dlen;
					nnz_dblock -= dlen;
					if(a_idx == PRODUCER_BUFFER_A && all_nnz > 0) {
						a_idx = 0;
						Int dan = min(PRODUCER_BUFFER_A, all_nnz);
						DMA_IREAD(_aa, aa, dan*sizeof(DATA_T));
						DMA_IREAD(_aj, aj, dan*sizeof(Int));
						_aa		+= dan;
						_aj		+= dan;
						all_nnz -= dan;
					}
				}
				pre_idx = idx[i_idx*diag_block_part];
				/* write data to main memory TODO: compute bottom part first? */
				if((PRODUCER_BUFFER - buf_idx) >= len) { /* remain space of buffer is big enough */ 
					for(Int j = 0; j < len; j++) {
						x_buffer[buf_idx+j] = value_cache[0][j];
					}
					buf_idx += len;
					/* If next block is non-diagonal block, then put data. */
					/* If this block is finished, then put data. TODO:??? */ 
					if((i_level+1) == level_len || level[i_level+1] <= 0) {
						if(id == sp_id && i == levels - 1) {/* last time, sp_id put data of real_size*/
							DMA_IWRITE(x, x_buffer, (buf_idx-add_n)*sizeof(DATA_T));
							x += buf_idx-add_n;
						} else {
							DMA_IWRITE(x, x_buffer, buf_idx*sizeof(DATA_T));
							x += buf_idx;
						}
						buf_idx = 0;
						DMA_WAIT_ALL; 
					}
				} else { /* remain space is not big enough*/
					if(buf_idx > 0) {
						DMA_IWRITE(x, x_buffer, buf_idx*sizeof(DATA_T));
						x += buf_idx;
						buf_idx = 0;
					}
					if(id == sp_id && i == levels-1) {
						DMA_IWRITE(x, value_cache[0], (len-add_n)*sizeof(DATA_T));
						x += len-add_n;
					} else {
						DMA_IWRITE(x, value_cache[0], len*sizeof(DATA_T));
						x += len;
					}
					DMA_WAIT_ALL;
				}
			} else { /* len = 0 for the producer this time, but next block is non-diagonal blcok, then put buffer data. */ 
				if(((i_level+1) == level_len || level[i_level+1] <= 0) && buf_idx > 0) {
					if(id == sp_id && i == levels-1) {/* last time, sp_id put data of real_size */
						DMA_IWRITE(x, x_buffer, (buf_idx-add_n)*sizeof(DATA_T));
						x += buf_idx-add_n;
					} else {
						DMA_IWRITE(x, x_buffer, buf_idx*sizeof(DATA_T));
						x += buf_idx;
					}
					buf_idx = 0;
					DMA_WAIT_ALL;
				}
			}
			/* bottom rectangle part of the diagnal block */
			if(n_block <= CACHE_X) {
				/* exchange x between producers */
				Int max_dlen = ((n_block + producers_2num) >> producers_log2) << vector_log2;
				Int cache_offset = CACHE_X>>comm_part_log2;
				for(Int k = 0; k < comm_part-1; k++)  {
					DATA_T *src_addr = &value_cache[0][ k   *cache_offset];
					DATA_T *dst_addr = &value_cache[0][(k+1)*cache_offset];
					rpcc(st)
					if(comm_id & 1) {
						CRTS_ssync_peer(pre_partner_id);
						CRTS_ssync_peer(nxt_partner_id);
					} else {
						CRTS_ssync_peer(nxt_partner_id);
						CRTS_ssync_peer(pre_partner_id);
					}
					CRTS_rma_put(src_addr, max_dlen*sizeof(DATA_T), nxt_partner_id, dst_addr, &pro_reply);
					CRTS_rma_wait_value(&pro_reply, 1);
					pro_reply = 0;
					rpcc(ed)
					comp_cyc(ex_cycles,ed,st);
				}
				Int nnz_dblock = idx[i_idx*diag_block_part+comm_part]-pre_idx;//nnz of the producer in this diagnal block bottom part 
				while(nnz_dblock > 0) {
					DMA_WAIT_ALL;
					Int dlen = min(nnz_dblock, PRODUCER_BUFFER_A-a_idx);
					for(Int j = 0; j < dlen; j++) {
						Int aai 	= (aj[a_idx+j] >> big_block_log2)&cache_x_2num;
						Int aaj 	=  aj[a_idx+j]  & big_block_2num;
						Int _parts	=  aj[a_idx+j] >>(big_block_log2+cache_x_log2); 
						Int row_ind	=  aaj + base;//real row_indices
						Int dst_id	= (row_ind>>vector_log2)&producers_2num;//dst cpe id

						trsv_msg_t<DATA_T> msg;
						msg.index = row_ind;//real row_indices
						msg.value = value_cache[0][_parts*cache_offset+aai] * aa[a_idx+j];
						rpcc(st)
						comm.send(msg, dst_id, comm_status);
						rpcc(ed)
						comp_cyc(comm_cycles, ed , st);
					}
					a_idx 		+= dlen;
					nnz_dblock 	-= dlen;
					if(a_idx == PRODUCER_BUFFER_A && all_nnz > 0) {
						a_idx = 0;
						Int dan = min(PRODUCER_BUFFER_A, all_nnz);
						DMA_IREAD(_aa, aa, dan*sizeof(DATA_T));
						DMA_IREAD(_aj, aj, dan*sizeof(Int));
						_aa		+= dan;
						_aj		+= dan;
						all_nnz -= dan;
					}
				}
				pre_idx = idx[i_idx*diag_block_part+comm_part];
			} else {
				/* exchange x between producers */
				Int max_dlen = ((n_block + producers_2num) >> producers_log2) << vector_log2;
#ifdef RMA_IPUT
				if(comm_id & 1) {
					CRTS_ssync_peer(pre_partner_id);
					CRTS_ssync_peer(nxt_partner_id);
				} else {
					CRTS_ssync_peer(nxt_partner_id);
					CRTS_ssync_peer(pre_partner_id);
				}
				Int which = 1;
#else
				Int which = 0;
#endif
				for(Int k = 0; k < comm_part; k++)  {
#ifdef RMA_IPUT
					CRTS_rma_wait_value(ex_rply+k, 1);
					which ^= 1;
					if(k < comm_part-1) {
						rpcc(st)
						CRTS_rma_iput(value_cache[which], &pro_reply, max_dlen*sizeof(DATA_T), nxt_partner_id, value_cache[which^1], ex_rply+k+1);
						rpcc(ed)
						comp_cyc(ex_cycles,ed,st);
					}
#else
					if(k > 0) {
						if(comm_id & 1) {
							CRTS_ssync_peer(pre_partner_id);
							CRTS_ssync_peer(nxt_partner_id);
						} else {
							CRTS_ssync_peer(nxt_partner_id);
							CRTS_ssync_peer(pre_partner_id);
						}
						CRTS_rma_put(value_cache[which], max_dlen*sizeof(DATA_T), nxt_partner_id, value_cache[which^1], &pro_reply);
						which ^= 1;
						CRTS_rma_wait_value(&pro_reply, 1);
						pro_reply = 0;
					}
#endif
					Int nnz_dblock = idx[i_idx*diag_block_part+k+1]-pre_idx;//nnz of the producer in this diagnal block bottom part 
					while(nnz_dblock > 0) {
						DMA_WAIT_ALL;
						Int dlen = min(nnz_dblock, PRODUCER_BUFFER_A-a_idx);
						for(Int j = 0; j < dlen; j++) {
							Int aai 	= (aj[a_idx+j] >> big_block_log2)&cache_x_2num;
							Int aaj 	=  aj[a_idx+j]  & big_block_2num;
							Int row_ind	=  aaj + base;//real row_indices
							Int dst_id	= (row_ind>>vector_log2)&producers_2num;//dst cpe id

							trsv_msg_t<DATA_T> msg;
							msg.index = row_ind;//real row_indices
							msg.value = value_cache[which][aai] * aa[a_idx+j];
							rpcc(st)
							comm.send(msg, dst_id, comm_status);
							rpcc(ed)
							comp_cyc(comm_cycles, ed , st);
						}
						a_idx 		+= dlen;
						nnz_dblock 	-= dlen;
						if(a_idx == PRODUCER_BUFFER_A && all_nnz > 0) {
							a_idx = 0;
							Int dan = min(PRODUCER_BUFFER_A, all_nnz);
							DMA_IREAD(_aa, aa, dan*sizeof(DATA_T));
							DMA_IREAD(_aj, aj, dan*sizeof(Int));
							_aa		+= dan;
							_aj		+= dan;
							all_nnz -= dan;
						}
					}
					pre_idx = idx[i_idx*diag_block_part+k+1];
				}
			}
			if(((i_level+1) <  level_len &&  level[i_level+1] > 0) //|| ((i_level+1) >= level_len)) { 
			 ||((i_level+1) >= level_len && (i+1) < levels && _level[i+1] > 0)) { 
				//next block is diagnal block TODO:don't know next block info ----gld???
				rpcc(st)
				for(Int j = 0; j < producers; j++) {
					comm.flush(j, comm_status);
				}
				rpcc(ed)
				comp_cyc(comm_cycles , ed , st);
			}
			begin_global += n_block;
		}
	}

	if(buf_idx > 0) {
		if(id == sp_id) {
            DMA_IWRITE(x, x_buffer, buf_idx*sizeof(DATA_T)-add_n*sizeof(DATA_T));
		} else {
            DMA_IWRITE(x, x_buffer, buf_idx*sizeof(DATA_T));
		}
		x += buf_idx;
	}

	DMA_WAIT_ALL;

#ifdef TRSV_TIMING
	rpcc(all_ed)
	pro_cycles = all_ed - all_st;
	double cycle_rate = ((double)comm_cycles / (double)pro_cycles)*100;
	double rsv_rate   = ((double)rsv_cycles  / (double)pro_cycles)*100;
	cycles[0] = comm_cycles;
	cycles[1] = rsv_cycles;
	cycles[2] = pro_cycles;
	cycles[3] = ex_cycles;
//	printf("producer %d: pro_cycles = %d, comm_cycles = %d, rate = %.2f%%, rsv_cycles = %d, rate = %.2f%%\n", \
			id, pro_cycles, comm_cycles, cycle_rate, rsv_cycles, rsv_rate);
#endif
 
	return;
}

#undef TRSV_PRINTF
#ifdef TRSV_CON_DEBUG
#define TRSV_PRINTF(...) if(id == 1) { trsv_debug(__VA_ARGS__); }
#else
#define TRSV_PRINTF(...) ;
#endif

template<typename Communicator, typename DATA_T>
static void consumer_kernel(Communicator &comm, trsv_tune_t *tune, DATA_T alpha, DATA_T *x, const DATA_T *b, \
							DATA_T value_cache[2][CACHE_X], Int *_level, Int *_cnt, crts_rply_t *signal, \
							crts_rply_t *reply, Int levels, Int n, Int partner_id, unsigned long* cycles) {
#ifdef TRSV_TIMING
	unsigned long st, ed, all_st, all_ed, con_cycles, comm_st, comm_ed;
	unsigned long comm_cycles = 0;
	unsigned long put_cycles = 0;
	rpcc(all_st)
#endif
	Int id				= comm.get_id();
	Int vector_log2		= tune->vector_log2; 
	Int cache_x_log2	= tune->cache_x_log2;
	Int consumers_log2	= tune->couples_log2;
	Int big_block_log2	= cache_x_log2 + consumers_log2;
	Int vector			= 1 << vector_log2;
	Int cache_x			= 1 << cache_x_log2;
	Int consumers		= 1 << consumers_log2;
	Int big_block		= 1 << big_block_log2;
	Int vector_2num		= vector - 1;
	Int cache_x_2num	= cache_x - 1;
	Int consumers_2num	= consumers - 1;
	Int big_block_2num	= big_block - 1;

	DATA_T b_buffer[CONSUMER_BUFFER];//buffer b: for mass memory access
	Int	        cnt[CONSUMER_CACHE][MAX_PRODUCERS]; //cnt:the times of update b
	Int       level[CONSUMER_CACHE]; //level:columns of every level
//	DATA_T value_cache[CACHE_X];	    //cache b:  for update b

	DMA_DECL_DESC(READ_WRITE);

	crts_rply_t *remote_sig = remote_ldm_addr(signal, partner_id);

	Int begin_global = 0;//current idx for all consumer
	Int begin_local	 = 0;//current idx for only this consumer
	Int dlen		 = 0;//
	Int buf_idx		 = CONSUMER_BUFFER;//
	//Init value
	Int n_level		 = _level[0];//n in first level
	Int n_local		 = (n_level>>consumers_log2) + (id < (n_level&consumers_2num) ? 1 : 0);//the consumer's n in current level
	Int n_local_all  = (n      >>consumers_log2) + (id < (n      &consumers_2num) ? 1 : 0);//all n of this consumer to be solved

	n_level 		<<= vector_log2;
	n_local 		<<= vector_log2;
	n_local_all		<<= vector_log2;
	
	begin_global	+= n_level;
	begin_local		+= n_local;
	n_local_all		-= n_local;
	/* first block(diagnal top part), producer read b[] from MEM,so consumer don't need to read.
	 * but consumer need to read b[] for the fist diagnal block bottom part 
	 * as to keep the idx consistent with producer, read b[] to b_cache inner idx*/
	b				+= n_local;//move b pointer
	Int begin_idx 	 = begin_local&CACHE_X_2NUM;//idx of cache start
	dlen			 = min(n_local_all, CACHE_X-begin_idx);
	if(dlen > 0) { /* read b[] to b_cache behind part */
		DMA_IREAD(b, &value_cache[0][begin_idx], dlen*sizeof(DATA_T));
		n_local_all	-= dlen;
		b			+= dlen;
		DMA_WAIT_ALL;
		for(Int i = 0; i < dlen; i++)
			value_cache[0][begin_idx+i] *= alpha;
	}
	dlen 			 = min(n_local_all, begin_idx);
	if(dlen > 0) { /*  read b[] to b_cache front part*/
		DMA_IREAD(b, &value_cache[0][0], dlen*sizeof(DATA_T));
		n_local_all	-= dlen;
		b			+= dlen;
                DMA_WAIT_ALL; // LIUKAN
		for(Int i = 0; i < dlen; i++)
			value_cache[0][i] *= alpha;
	}
	DMA_WAIT_ALL;

	if(buf_idx == CONSUMER_BUFFER && n_local_all > 0) {
		buf_idx = 0;
		dlen 	= min(n_local_all, CONSUMER_BUFFER);
		DMA_IREAD(b, b_buffer, dlen*sizeof(DATA_T));
		n_local_all -= dlen;
		b			+= dlen;
	}
	//why i < levels-1 ? because the first level don't need to send b and the last level don't need to update b
	for(Int i = 0, i_level = 0; i < levels-1; i++, i_level = (i_level+1)&CONSUMER_CACHE_2NUM) {
		if(i_level == 0) {
			/* Init level and cnt */
			Int tmp_len = min(CONSUMER_CACHE, levels-i);
			DMA_IREAD(_level+i+1, 			  level, tmp_len*sizeof(Int));
			DMA_IREAD(_cnt  +i*MAX_PRODUCERS, cnt,   tmp_len*MAX_PRODUCERS*sizeof(Int));
			DMA_WAIT_ALL;
		}
		n_level     = level[i_level];//n of next level 
		Int tmp_id 	= (id + consumers - ((begin_global>>vector_log2)&consumers_2num)) & consumers_2num;//the new_id of the consumer at this level
		n_local		= (n_level>>consumers_log2) + ((tmp_id < (n_level&consumers_2num) ? 1 : 0));
		n_level	  <<= vector_log2;
		n_local   <<= vector_log2;

		/* Get data from producer */
		/* non_diagnal blocks after diagnal block: producers send data continously */
		uint32_t mask = 0x0;
		for(Int p = 0; p < consumers; p++) {
			if(cnt[i_level][p] > 0)
				mask |= 1 << p;
		}
		rpcc(comm_st)
#ifdef TRSV_TIMING
		comm.consume_message(mask, [i_level, &value_cache, &cnt, consumers_log2, vector_2num, vector_log2, id, &st, &ed]\
							(const Int pid, const trsv_msg_t<DATA_T> msg) {
#else
		comm.consume_message(mask, [i_level, &value_cache, &cnt, consumers_log2, vector_2num, vector_log2, id]\
							(const Int pid, const trsv_msg_t<DATA_T> msg) {
#endif
			rpcc(st)
			Int row_ind = msg.index;
			Int idx_cache = (((row_ind>>(vector_log2+consumers_log2))<<vector_log2)&CACHE_X_2NUM)+(row_ind&vector_2num);
			value_cache[0][idx_cache] -= msg.value;

			cnt[i_level][pid]--;
			rpcc(ed)
			return (cnt[i_level][pid] <= 0); //is last message?
		});
		rpcc(comm_ed)
		comp_cyc(comm_cycles, (comm_ed-comm_st) , (ed-st));

		/* Put data to producer */
		dlen = min(n_local, (CACHE_X-begin_idx));//len of local_b in behind b_cache
		bool isPut = false;
		if(dlen > 0) {/* rma_put b_cache behind part */
			//wait signal
			rpcc(st)
			while(*remote_sig != 1);
			CRTS_rma_put(&value_cache[0][begin_idx], dlen*sizeof(DATA_T), partner_id, value_cache[0], reply);
			rpcc(ed)
			comp_cyc(put_cycles , ed , st);
			isPut = true;
		}

		Int remain_len = n_local-dlen;
		Int sec_dlen= max(0, remain_len);//len of local_b in front b_cache
		if(sec_dlen > 0) {/* rma_put b_cache front part TODO */ 
			rpcc(st)
			while(*remote_sig != 1);
			CRTS_rma_put(value_cache[0], sec_dlen*sizeof(DATA_T), partner_id, &value_cache[0][dlen], reply);
			rpcc(ed)
			comp_cyc(put_cycles , ed , st);
			isPut = true;
		}
		if(isPut)
			*remote_sig = 0;//set remote_sig = 0
		
		/* supply data from buffer */
		DATA_T *tmp_cache = value_cache[0] + begin_idx;
		while(dlen > 0 && buf_idx < CONSUMER_BUFFER) {
			DMA_WAIT_ALL;
			Int tmp_len = min(dlen, (CONSUMER_BUFFER - buf_idx));
			for(Int j = 0; j < tmp_len; j++) {
				*tmp_cache++ = alpha * b_buffer[buf_idx+j];
			}
			buf_idx += tmp_len;
			dlen	-= tmp_len;
			if(buf_idx == CONSUMER_BUFFER && n_local_all > 0) {
				buf_idx = 0;
				Int buf_len = min(n_local_all, CONSUMER_BUFFER);
				DMA_IREAD(b, b_buffer, buf_len*sizeof(DATA_T));
				n_local_all -= buf_len;
				b			+= buf_len;
			}
		}
		dlen = n_local - min(n_local, CACHE_X-begin_idx);
		tmp_cache = value_cache[0];
		while(dlen > 0 && buf_idx < CONSUMER_BUFFER) {
			DMA_WAIT_ALL;
			Int tmp_len = min(dlen, (CONSUMER_BUFFER - buf_idx));
			for(Int j = 0; j < tmp_len; j++) {
				*tmp_cache++ = alpha * b_buffer[buf_idx+j];
			}
			buf_idx += tmp_len;
			dlen	-= tmp_len;
			if(buf_idx == CONSUMER_BUFFER && n_local_all > 0) {
				buf_idx = 0;
				Int buf_len = min(n_local_all, CONSUMER_BUFFER);
				DMA_IREAD(b, b_buffer, buf_len*sizeof(DATA_T));
				n_local_all -= buf_len;
				b			+= buf_len;
			}
		}
		begin_global += n_level;
		begin_local	 += n_local;
		begin_idx 	  = begin_local&CACHE_X_2NUM;
	}

#ifdef TRSV_TIMING
	rpcc(all_ed)
	con_cycles = all_ed - all_st;
	double cycle_rate = ((double)comm_cycles / (double)con_cycles) * 100;
	double put_rate   = ((double)put_cycles  / (double)con_cycles) * 100;
	cycles[0] = comm_cycles;
	cycles[1] = put_cycles;
	cycles[2] = con_cycles;
//	printf("consumer %d: con_cycles = %d, comm_cycles = %d, rate = %.2f%%, put_cycles = %d, rate = %.2f%%\n", \
			id, con_cycles, comm_cycles, cycle_rate, put_cycles, put_rate);
#endif

	return;
}


template<typename DATA_T>
static void trsv_kernel(void *args) {

	unsigned long st, ed, k_st, k_ed, tmp_st;
	unsigned long kernel_cycles[4];
	rpcc(st)
	rpcc(tmp_st)
	unsigned long compute_cycle = tmp_st-ed;
	
	rpcc(ed)
	unsigned long put_comm_cycle = ed-tmp_st;
	trsv_arg_t<DATA_T>	local_arg;
	trsv_tune_t			local_tune;

	DMA_DECL_DESC(READ);
	DMA_READ(args, &local_arg, sizeof(trsv_arg_t<DATA_T>));
	DMA_READ(local_arg.trsv_tune, &local_tune, sizeof(trsv_tune_t));

	rpcc(ed)
	unsigned long dma_cycle = ed - st;

	Int couples_log2 = local_tune.couples_log2;
	Int couples		 = 1 << couples_log2;
	Int couples_2num = couples - 1;
	Int n_org		 = local_arg.N;
	Int n 			 = local_arg.n;
	Int vector_log2  = local_tune.vector_log2;
	Int vector  	 = 1 << vector_log2;
	Int add_n		 = (n << vector_log2) - n_org;
	Int sp_id		 = (n + couples_2num) & couples_2num;

	put_pc_communicator<trsv_msg_t<DATA_T>, 32, sandwich_mapper, 32> comm(CRTS_tid);
//	iput_pc_communicator<trsv_msg_t<DATA_T>, 32, sandwich_mapper, 32> comm(CRTS_tid);
//	rst_pc_communicator<trsv_msg_t<DATA_T>, 32, sandwich_mapper, 32> comm(CRTS_tid);

	Int id = comm.get_id();
	if(id >= couples)
		return;

//	DATA_T value_cache[MAX_COMM_PART][CACHE_X];
	DATA_T value_cache[2][CACHE_X];
//	DATA_T value_cache[CACHE_X];//cache for x
	Int	 cur_block_id  = 0; 
	crts_rply_t signal = 0; 
	crts_rply_t reply  = 0; 
	sandwich_mapper mapper;
	//top cores solve more colunms
	Int offset = vector*(id*(n>>couples_log2) + (id < (n&couples_2num) ? id : (n&couples_2num)));
	//if add_n > 0 ,then bottom cores change the offset
	offset = id > sp_id ? (offset - add_n) : offset;
	rpcc(tmp_st)
	unsigned long offset_cycle = tmp_st - ed;
	unsigned long pre_cycle    = tmp_st - st;

	if(comm.is_producer()) {
		Int partner_id = mapper.cid2tid(id);
		if(couples == MAX_PRODUCERS) {
			CRTS_ssync_array();
		} else {
			CRTS_ssync_peer(partner_id);
		}
		producer_kernel(comm, &local_tune, local_arg.alpha, local_arg.x+offset, local_arg.b+offset, local_arg.aa, 
			local_arg.ai, local_arg.aj, value_cache, local_arg.idx[id], local_arg.plevel, 
			&signal, local_arg.plevels, n, n_org, local_arg.status, kernel_cycles);
	} else {
		Int partner_id = mapper.pid2tid(id);
		switch(couples) {
			case 1:
				CRTS_ssync_peer(partner_id);
				break;
			case 2:
				CRTS_ssync_2spe();
				CRTS_ssync_peer(partner_id);
				break;
			case 4:
				CRTS_ssync_2spe();
				CRTS_ssync_peer(mapper.cid2tid(id^0x3));
				CRTS_ssync_peer(partner_id);
				break;
			case 8:
				CRTS_ssync_row();
				CRTS_ssync_peer(partner_id);
				break;
			case 16:
				CRTS_ssync_row();
				CRTS_ssync_1spc();
				CRTS_ssync_peer(partner_id);
				break;
			case 32:
				CRTS_ssync_array();
				break;
		}
		consumer_kernel(comm, &local_tune, local_arg.alpha, local_arg.x+offset, local_arg.b+offset, value_cache, \
			local_arg.level, local_arg.cnt[id], &signal, &reply, local_arg.levels, n, partner_id, kernel_cycles);
	}
	
#ifdef TRSV_TIMING
	rpcc(ed)
	double comm_rate = (double)kernel_cycles[0] / (double)kernel_cycles[2] * 100;
	double peer_rate = (double)kernel_cycles[1] / (double)kernel_cycles[2] * 100;
	double ex_rate   = (double)kernel_cycles[3] / (double)kernel_cycles[2] * 100;
	if(comm.is_producer() && id < couples)
		printf("producer %d: all_cyc= %d, pre_cyc= %d, pro_cyc= %d, comm_cyc= %d, comm_rate= %.2f%%, ex_rate = %.2f%% rsv_cyc= %d, rsv_rate= %.2f%%, sum_rate = %.2f%%\n", id, ed-st, pre_cycle, kernel_cycles[2], kernel_cycles[0], comm_rate, ex_rate, kernel_cycles[1], peer_rate, comm_rate+peer_rate+ex_rate);
	else if(id < couples)
		printf("consumer %d: all_cyc= %d, pre_cyc= %d, con_cyc= %d, comm_cyc= %d, comm_rate= %.2f%%, put_cyc= %d, put_rate= %.2f%%, sum_rate = %.2f%%\n", id, ed-st, pre_cycle, kernel_cycles[2], kernel_cycles[0], comm_rate, kernel_cycles[1], peer_rate, comm_rate+peer_rate);

//	if(comm.is_producer())
//		printf("producer %d: pre_cyc = %d, dma_cyc = %d, compute_cyc = %d, put_comm_cyc = %d, offset_cyc = %d\n", 
//				id, pre_cycle, dma_cycle, compute_cycle, put_comm_cycle, offset_cycle);
//	else
//		printf("consumer %d: pre_cyc = %d, dma_cyc = %d, compute_cyc = %d, put_comm_cyc = %d, offset_cyc = %d\n", 
//				id, pre_cycle, dma_cycle, compute_cycle, put_comm_cycle, offset_cycle);
#endif
	

	return;
}

CPE_TEMPLATE_KERNEL(trsv_kernel, CACHE_0KB)
