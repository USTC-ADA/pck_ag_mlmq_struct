#include <limits>
#include <algorithm>
#include <crts.h>
#include "internal/CPE.h"
#include "internal/kernel_args.h"
#include "internal/memory.h"
#include "internal/templates.h"
#include "internal/CPE_utils.h"
#include "internal/CPE_communicator.h"
#include "internal/CPE_simd_utils.h"
#include "internal/CPE_simd_math.h"
#include "internal/CPE_blas_kernels.h"
#include "internal/algorithm_sort.h"
#include "internal/algorithm_heap.h"
#include "internal/sptrf_common.h"  // equilibration routines
#include "internal/sptrf_param.h"   // sort subtrees
#include "internal/sptrf_cpe.h" // ipiv2iperm

/*
 * Liu Kan:
 *   Various row-wise / column-wise processing of CSR / CSC:
 *       1. reorder rows of CSR
 *       2. row-wise sort nonzeros with respect to column indices
 *       3. reorder rows and columns of CSR, then row-wise sort with respect to the reordered column indices
 *       4. scale each row and column with some given factor
 *       5. scale each row of CSC with some given factor, then scale each column with its maximum absolute value
 *       6. compute the logarithm of the absolute value of each nonzero, and find the max of each column of CSC
 *       7. supernode-wise pivot interchanges, generate row permutation
 *       8. sort subtrees in factorization (rarely used)
 */

namespace swSparse {

#define adjust_priority_queue_min(length, pq) adjust_heap_min_down(0, length, pq, heap_element_t::key())
#define init_priority_queue_min(length, pq)   init_heap_min(length, pq)

NOINLINE void init_heap_min(Int length, heap_element_t *heap) {
    init_heap_min(length, heap, heap_element_t::key());
}

template<typename KEY, typename VALUE, typename VALUE_BUFFER, size_t MERGE_K, size_t MERGE_BUFF, Bool HAS_VALUE>
inline void merge_impl(KEY *keyin, KEY *keyout, VALUE* valin, VALUE* valout, Int rnz, Int p, \
            KEY (*key_buffer)[MERGE_BUFF], VALUE_BUFFER val_buffer) {
    constexpr const int output_buffer_size = 512;
    constexpr const int output_buffer_mask = output_buffer_size - 1;
    constexpr const int MERGE_BUFF_MASK = MERGE_BUFF - 1;
    heap_element_t heap[MERGE_K];
    Int begins[MERGE_K], ends[MERGE_K];
    KEY output_key_buffer[output_buffer_size];
    using OUT_BUFFER_TYPE = typename std::conditional_t<HAS_VALUE, VALUE[output_buffer_size], dummy_t>;
    OUT_BUFFER_TYPE output_val_buffer;
    static_assert(HAS_VALUE || std::is_same_v<dummy_t, VALUE>);
    DMA_DECL_DESC(READ_WRITE);

    for(Int i = 0; i < rnz; i += p * MERGE_K) {
        #ifdef SWSPARSE_HAS_ASSERT
            const Int i_end = min(p * MERGE_K, rnz - i);
        #endif
        Int len, local_in, local_out;
        Int heap_size = min(MERGE_K, ceiling_div(rnz - i, p));
        Int out_ptr = i;
        for(Int j = 0; j < heap_size; ++j) {
            begins[j] = i + j * p;
            ends[j] = min(begins[j] + p, rnz);
            len = min(MERGE_BUFF, ends[j] - begins[j]);
            DMA_READ(keyin + begins[j], key_buffer[j], sizeof(KEY) * len);
            heap[j].which = j;
            heap[j].index = static_cast<Int>(key_buffer[j][0]);
            if constexpr(HAS_VALUE) {
                static_assert(MERGE_K <= output_buffer_size);
                output_key_buffer[j] = sizeof(VALUE) * len;
            }
        }
        if constexpr(HAS_VALUE) {
            for(Int j = 0; j < heap_size; ++j) {
                DMA_IREAD(valin + begins[j], val_buffer[j], output_key_buffer[j]);
            }
            init_priority_queue_min(heap_size, heap);
            DMA_WAIT_ALL;
        } else {
            init_priority_queue_min(heap_size, heap);
        }
        while(heap_size > 0) {
            Int which = heap[0].which;
            local_in = (begins[which]++) & MERGE_BUFF_MASK;
            local_out = out_ptr & output_buffer_mask;

            // output
            if constexpr(std::is_same_v<KEY, Int>) {
                output_key_buffer[local_out] = heap[0].index;
            } else {
                output_key_buffer[local_out] = key_buffer[which][local_in];
            }
            if constexpr(HAS_VALUE) {
                output_val_buffer[local_out] = val_buffer[which][local_in];
            }
            if(local_out == output_buffer_mask) {    
                if constexpr(HAS_VALUE) {
                    DMA_IWRITE(valout + out_ptr - local_out, output_val_buffer, sizeof(VALUE) * output_buffer_size);
                }
                DMA_WRITE(keyout + out_ptr - local_out, output_key_buffer, sizeof(KEY) * output_buffer_size);
            }
            ++out_ptr;

            // input
            if(begins[which] >= ends[which]) {
                heap[0] = heap[--heap_size];
            } else {
                if(local_in == MERGE_BUFF_MASK) {
                    len = min(MERGE_BUFF, ends[which] - begins[which]);
                    if constexpr(HAS_VALUE) {
                        DMA_IREAD(valin + begins[which], val_buffer[which], sizeof(VALUE) * len);
                    }
                    DMA_READ(keyin + begins[which], key_buffer[which], sizeof(KEY) * len);
                }
                local_in = (begins[which]) & MERGE_BUFF_MASK;
                heap[0].index = static_cast<Int>(key_buffer[which][local_in]);
            }
            
            adjust_priority_queue_min(heap_size, heap);
        }     
        local_out = out_ptr & output_buffer_mask;
        if(local_out > 0) {
            if constexpr(HAS_VALUE) {
                DMA_IWRITE(valout + out_ptr - local_out, output_val_buffer, sizeof(VALUE) * local_out);
            }
            DMA_WRITE(keyout + out_ptr - local_out, output_key_buffer, sizeof(KEY) * local_out);
        }
        ASSERT_EQUAL(out_ptr, i_end);
    }
}

template<typename KEY, typename VALUE, typename VALUE_BUFFER, size_t MERGE_K, size_t MERGE_BUFF, Bool HAS_VALUE>
NOINLINE void merge(KEY *keys[2], VALUE* values[2], Int which, Int rnz, Int offset, \
            KEY (*key_buffer)[MERGE_BUFF], VALUE_BUFFER val_buffer) {
    for (int64_t p = MERGE_K * MERGE_BUFF, rnz_64 = rnz; p < rnz_64; p *= MERGE_K, which = which ^ 1) {
        merge_impl<KEY,VALUE,VALUE_BUFFER,MERGE_K,MERGE_BUFF,HAS_VALUE>(\
            keys[which] + offset, keys[which ^ 1] + offset, \
            values[which] + offset, values[which ^ 1] + offset, rnz, p, key_buffer, val_buffer);
    }   
}

template<Bool has_value, typename DATA_T>
NOINLINE static void rowwise_sort(Int m, Int nnz, const Int* offsets, Int* arg_indices, DATA_T* arg_values, Int* temp_indices, DATA_T* temp_values) {
    DMA_DECL_DESC(READ_WRITE)
    Int *indices[2] = {arg_indices, temp_indices};
    DATA_T *values[2] = {arg_values, temp_values};
    SIMD_ALIGN Int dist[64] = {0};
    Int local_offsets[offset_tile + 1];
    Int idx_buffer[merge_k<DATA_T>][merge_buffer_size];
    using VAL_BUFFER = typename std::conditional_t<has_value, DATA_T[merge_k<DATA_T>][merge_buffer_size], dummy_t[1][1]>;
    VAL_BUFFER val_buffer;
    static_assert(has_value || std::is_same_v<dummy_t, DATA_T>);
    
    swSparse_partition_nnz(m, nnz, offsets, dist, idx_buffer[0], sort_tile<DATA_T>);
    Int id = CPE_ID, r_begin = dist[id], r_end = (id == 63) ? m : dist[id+1], buffer_ptr = 0, global_ptr = -1;

    for(Int i = r_begin; i < r_end; i += offset_tile) {
        const Int len = min(offset_tile, r_end - i);
        DMA_READ(offsets + i, local_offsets, (len + 1) * sizeof(Int));
        global_ptr = (global_ptr < 0) ? local_offsets[0] : global_ptr;
        for(Int j = 0; j < len; ++j) {
            const Int o = local_offsets[j], rnz = local_offsets[j+1] - o;
            if(rnz == 0) continue;
            if(buffer_ptr > 0 && buffer_ptr + rnz > sort_tile<DATA_T>) {
                if constexpr(has_value) {
                    DMA_IWRITE(arg_values + global_ptr, val_buffer[0], buffer_ptr * sizeof(DATA_T));
                }
                DMA_SWRITE(arg_indices + global_ptr, idx_buffer[0], buffer_ptr * sizeof(Int));
                global_ptr += buffer_ptr;
                buffer_ptr = 0;
            }
            if(rnz <= sort_tile<DATA_T>) {
                if constexpr(has_value) {
                    DMA_IREAD(arg_values + o, val_buffer[0] + buffer_ptr, rnz * sizeof(DATA_T));
                }
                DMA_READ(arg_indices + o, idx_buffer[0] + buffer_ptr, rnz * sizeof(Int));
                sort_index_value(idx_buffer[0] + buffer_ptr, val_buffer[0] + buffer_ptr, rnz);
                buffer_ptr += rnz;
            } else {
                Int which = init_which<DATA_T>(rnz);
                for(Int k = 0; k < rnz; k += sort_tile<DATA_T>) {
                    Int rlen = min(sort_tile<DATA_T>, rnz - k);
                    if constexpr(has_value) {
                        DMA_IREAD(arg_values + o + k, val_buffer[0], rlen * sizeof(DATA_T));
                    }
                    DMA_READ(arg_indices + o + k, idx_buffer[0], rlen * sizeof(Int));
                    sort_index_value(idx_buffer[0], val_buffer[0], rlen);
                    if constexpr(has_value) {
                        DMA_IWRITE(values[which] + global_ptr + k, val_buffer[0], rlen * sizeof(DATA_T));
                    }
                    DMA_WRITE(indices[which] + global_ptr + k, idx_buffer[0], rlen * sizeof(Int));
                }
                merge<Int,DATA_T,VAL_BUFFER,merge_k<DATA_T>,merge_buffer_size,has_value>(\
                    indices, values, which, rnz, global_ptr, idx_buffer, val_buffer);
                global_ptr += rnz;
            }
        }
    }
    if(buffer_ptr > 0) {
        if constexpr(has_value) {
            DMA_IWRITE(arg_values + global_ptr, val_buffer[0], buffer_ptr * sizeof(DATA_T));
        }
        DMA_IWRITE(arg_indices + global_ptr, idx_buffer[0], buffer_ptr * sizeof(Int));
    }
    DMA_WAIT_ALL;
}

template<typename DATA_T>
NOINLINE static void rowwise_sort_kernel(void *p_args) {
    rowwise_sort_arg_t<DATA_T> args;
    DMA_READ_NODESC(p_args, &args, sizeof(rowwise_sort_arg_t<DATA_T>));
    rowwise_sort<true>(args.m, args.nnz, args.offsets, args.indices, args.values, args.temp_indices, args.temp_values);
}

NOINLINE static void rowwise_sort_pattern_kernel(void *p_args) {
    rowwise_sort_arg_t<dummy_t> args;
    DMA_READ_NODESC(p_args, &args, sizeof(rowwise_sort_arg_t<dummy_t>));
    rowwise_sort<false, dummy_t>(args.m, args.nnz, args.offsets, args.indices, nullptr, args.temp_indices, nullptr);
}

NOINLINE static void sort_subtrees_kernel(void *p_args) {
    constexpr const Int merge_kk = 128, merge_bb = 64, sort_tt = merge_bb * merge_kk;
    sort_subtrees_arg_t args;
    DMA_READ_NODESC(p_args, &args, sizeof(sort_subtrees_arg_t));
    trf_subtree_t buffer[merge_kk][merge_bb];
    Int id = CPE_ID, begin = args.subtree_offsets[id], n = args.subtree_offsets[id+1] - begin;
    trf_subtree_t *t[2] = {args.subtrees + begin, args.temp + begin};
    dummy_t *dummy[2] = {nullptr, nullptr};
    Int which = (n <= sort_tt) ? 0 : 1;
    DMA_DECL_DESC(READ_WRITE);
    for(Int k = 0; k < n; k += sort_tt) {
        Int k_len = min(sort_tt, n - k);
        DMA_READ(t[0] + k, buffer[0], k_len * sizeof(trf_subtree_t));
        std::sort(buffer[0], buffer[0] + k_len);
        DMA_SWRITE(t[which] + k, buffer[0], k_len * sizeof(trf_subtree_t));
    }
    merge<trf_subtree_t, dummy_t, dummy_t, merge_kk, merge_bb, false>(\
        t, dummy, which, n, 0, buffer, dummy_t());
}

template<typename DATA_T>
NOINLINE void mc64_preprocess_kernel(void *p_args) {
    constexpr Int chunk_size = 110016 / (sizeof(DATA_T) + 2 * sizeof(real_t<DATA_T>));
    constexpr Int row_chunk_size = 512;
    constexpr real_t<DATA_T> neg_inf = std::numeric_limits<real_t<DATA_T>>::lowest();
    mc64_preprocess_arg_t<DATA_T> args, *args_ptr = (mc64_preprocess_arg_t<DATA_T>*)p_args;
    DMA_DECL_DESC(READ_WRITE);
    absolute_logarithmic<DATA_T> element_wise;
    DMA_READ(p_args, &args, sizeof(mc64_preprocess_arg_t<DATA_T>));

    SIMD_ALIGN Int dist[64] = {0};
    SIMD_ALIGN DATA_T local_value[chunk_size];
    SIMD_ALIGN real_t<DATA_T> local_log[chunk_size];
    SIMD_ALIGN real_t<DATA_T> local_abs[chunk_size];
    real_t<DATA_T> local_max[row_chunk_size];
    Int local_offsets[row_chunk_size + 2];
    Int id = memory_channel_mapping(CPE_ID);

    swSparse_partition_nnz(args.n, args.nnz, args.offsets, dist, local_offsets, row_chunk_size + 2);
    Int begin = dist[id], end = (id == 63) ? args.n : dist[id + 1];

    real_t<DATA_T> nrm = 0;

    for(Int i = begin; i < end; i += row_chunk_size) {
        Int rlen = min(row_chunk_size, end - i);
        DMA_IREAD(args.offsets + i, local_offsets, (rlen + 1) * sizeof(Int));
        local_offsets[rlen + 1] = std::numeric_limits<Int>::max();
        DMA_WAIT_ALL;

        Int p_begin = local_offsets[0], p_end = local_offsets[rlen], next_col = 1;
        real_t<DATA_T> s = 0, cmax = neg_inf;
        for(Int p = p_begin; p < p_end; p += chunk_size) {
            Int next_pos, len = min(chunk_size, p_end - p);
            DMA_IREAD(args.src + p, local_value, len * sizeof(DATA_T));
            next_pos = local_offsets[next_col] - p;
            DMA_WAIT_ALL;

            element_wise.log_abs(local_value, local_abs, local_log, len);
            DMA_IWRITE(args.dst + p, local_log, len * sizeof(real_t<DATA_T>));
            for(Int j = 0; j < len; ++j) {
                real_t<DATA_T> mag = local_abs[j];
                real_t<DATA_T> logmag = local_log[j];
                if(UNLIKELY(j == next_pos)) {  // j + p == local_offsets[next_col]
                    nrm = (nrm > s) ? nrm : s;
                    local_max[next_col - 1] = cmax;
                    s = mag;
                    cmax = logmag;
                    for(next_pos = j + p, ++ next_col; local_offsets[next_col] <= next_pos; ++ next_col) {  // skip zero columns
                        local_max[next_col - 1] = 0;
                    }
                    next_pos = local_offsets[next_col] - p;
                } else {
                    s += mag;
                    cmax = (cmax > logmag) ? cmax : logmag;
                }
            }
        }   
        local_max[next_col - 1] = cmax;
        DMA_IWRITE(args.col_max + i, local_max,  rlen * sizeof(real_t<DATA_T>));  // do not need to wait
        nrm = (nrm > s) ? nrm : s;
    }
    write_max_real(nrm, &args_ptr->norm_1);
    DMA_WAIT_ALL;
}

template<typename DATA_T>
NOINLINE void sparse_scale_kernel(void *p_args) {
    constexpr Int chunk_size = 110040 / (sizeof(DATA_T) + sizeof(Int));
    constexpr Int row_chunk_size = 512;
    sparse_scale_arg_t<DATA_T> args, *args_ptr = (sparse_scale_arg_t<DATA_T>*)p_args;
    DMA_DECL_DESC(READ_WRITE);
    DMA_READ(p_args, &args, sizeof(sparse_scale_arg_t<DATA_T>));

    SIMD_ALIGN Int dist[64] = {0};
    SIMD_ALIGN DATA_T local_value[chunk_size];
    Int local_index[chunk_size];
    real_t<DATA_T> local_cscale[row_chunk_size];
    Int local_offsets[row_chunk_size + 2];
    Int id = memory_channel_mapping(CPE_ID);

    swSparse_partition_nnz(args.n, args.nnz, args.offsets, dist, local_index, chunk_size);
    Int begin = dist[id], end = (id == 63) ? args.n : dist[id + 1];

    real_t<DATA_T> nrm = 0;

    for(Int i = begin; i < end; i += row_chunk_size) {
        Int rlen = min(row_chunk_size, end - i);
        DMA_IREAD(args.offsets + i, local_offsets, (rlen + 1) * sizeof(Int));
        DMA_IREAD(args.cscale + i, local_cscale,  rlen * sizeof(real_t<DATA_T>));
        local_offsets[rlen + 1] = std::numeric_limits<Int>::max();
        DMA_WAIT_ALL;

        Int p_begin = local_offsets[0], p_end = local_offsets[rlen], next_col = 1;
        real_t<DATA_T> mag, s = 0, cs = local_cscale[0];
        for(Int p = p_begin; p < p_end; p += chunk_size) {
            Int next_pos, len = min(chunk_size, p_end - p);
            DMA_IREAD(args.indices + p, local_index, len * sizeof(Int));
            DMA_IREAD(args.src + p, local_value, len * sizeof(DATA_T));
            next_pos = local_offsets[next_col] - p;
            DMA_WAIT_ALL;

            for(Int j = 0; j < len; ++j) {
                real_t<DATA_T> rs = args.rscale[local_index[j]];  // need cache
                if(UNLIKELY(j == next_pos)) {  // j + p == local_offsets[next_col]
                    for(next_pos = j + p, ++ next_col; local_offsets[next_col] <= next_pos; ++ next_col);
                    next_pos = local_offsets[next_col] - p;
                    cs = local_cscale[next_col - 1];
                    local_value[j] *= (rs * cs);
                    mag = fabs(local_value[j]);
                    nrm = (nrm > s) ? nrm : s;
                    s = mag;
                } else {
                    local_value[j] *= (rs * cs);
                    mag = fabs(local_value[j]);
                    s += mag;
                }
            }
            DMA_SWRITE(args.dst + p, local_value, len * sizeof(real_t<DATA_T>));
        }   
        nrm = (nrm > s) ? nrm : s;
    }
    write_max_real(nrm, &args_ptr->norm_1);
    DMA_WAIT_ALL;
}

template<typename DATA_T>
NOINLINE void sparse_rescale_colmax_kernel(void *p_args) {
    constexpr Int chunk_size = 110208 / (sizeof(DATA_T) + sizeof(Int));
    constexpr Int row_chunk_size = 512;
    constexpr Int n_comp = sizeof(DATA_T) / sizeof(real_t<DATA_T>);
    constexpr Int alignsize = simd_width<real_t<DATA_T>> / n_comp, alignmask = alignsize - 1;
    sparse_rescale_colmax_arg_t<DATA_T> args, *args_ptr = (sparse_rescale_colmax_arg_t<DATA_T>*)p_args;
    DMA_DECL_DESC(READ_WRITE);
    DMA_READ(p_args, &args, sizeof(sparse_rescale_colmax_arg_t<DATA_T>));

    SIMD_ALIGN Int dist[64] = {0};
    SIMD_ALIGN DATA_T local_value[chunk_size];
    Int local_index[chunk_size];
    real_t<DATA_T> local_cscale[row_chunk_size];
    Int local_offsets[row_chunk_size + 2];
    Int id = memory_channel_mapping(CPE_ID);

    swSparse_partition_nnz(args.n, args.nnz, args.offsets, dist, local_index, chunk_size);
    Int begin = dist[id], end = (id == 63) ? args.n : dist[id + 1], global_ptr = -1, buffer_ptr = 0;

    real_t<DATA_T> nrm = 0;

    for(Int i = begin; i < end; i += row_chunk_size) {
        const Int r_len = min(row_chunk_size, end - i);
        DMA_READ(args.offsets + i, local_offsets, (r_len + 1) * sizeof(Int));
        global_ptr = (global_ptr < 0) ? local_offsets[0] : global_ptr;
        for(Int j = 0; j < r_len; ++j) {
            const Int o = local_offsets[j], rnz = local_offsets[j+1] - o;
            real_t<DATA_T> s = 0, cmax = 0, ab;

            if(rnz == 0) {
                local_cscale[j] = 0;
                continue;
            }
            if(buffer_ptr > 0 && buffer_ptr + rnz > chunk_size) {
                DMA_SWRITE(args.dst + global_ptr, local_value, buffer_ptr * sizeof(DATA_T));
                global_ptr += buffer_ptr;
                buffer_ptr = 0;
            }
            if(rnz <= chunk_size) { // 2-pass in LDM
                DMA_IREAD(args.src + o, local_value + buffer_ptr, rnz * sizeof(DATA_T));
                DMA_READ(args.indices + o, local_index + buffer_ptr, rnz * sizeof(Int));
                Int buffer_end = buffer_ptr + rnz;
                for(Int k = buffer_ptr; k < buffer_end; ++k) {
                    local_value[k] *= args.rscale[local_index[k]];
                    ab = fabs(local_value[k]);
                    s += ab;
                    cmax = (cmax > ab) ? cmax : ab;
                }
                cmax = reciprocal(cmax);
                Int kalign = buffer_ptr + min(rnz, (- buffer_ptr) & alignmask), a_len = buffer_end - kalign;
                for(Int k = buffer_ptr; k < kalign; ++k) {
                    local_value[k] *= cmax;
                }
                if(a_len > 0) {   // use SIMD `scale`
                    scale_real(reinterpret_cast<real_t<DATA_T>*>(local_value + kalign), a_len * n_comp, cmax);
                }
                buffer_ptr = buffer_end;
            } else {                 // 2-pass in memory
                const Int remain = ((rnz - 1) % chunk_size) + 1, block = rnz - remain;
                Int len = remain, p = block;
                for(; p >= 0; p -= chunk_size) {
                    DMA_IREAD(args.src + o + p, local_value, len * sizeof(DATA_T));
                    DMA_READ(args.indices + o + p, local_index, len * sizeof(Int));
                    for(Int k = 0; k < len; ++k) {
                        local_value[k] *= args.rscale[local_index[k]];
                        ab = fabs(local_value[k]);
                        s += ab;
                        cmax = (cmax > ab) ? cmax : ab;
                    }
                    if(p == 0) {
                        cmax = reciprocal(cmax);
                        scale_real(reinterpret_cast<real_t<DATA_T>*>(local_value), len * n_comp, cmax);
                    }
                    DMA_SWRITE(args.dst + o + p, local_value, len * sizeof(DATA_T));
                    len = chunk_size;
                }
                for(p = chunk_size; p < rnz; p += chunk_size) {
                    len = min(chunk_size, rnz - p);
                    DMA_READ(args.dst + o + p, local_value, len * sizeof(DATA_T));  // read back from dst
                    scale_real(reinterpret_cast<real_t<DATA_T>*>(local_value), len * n_comp, cmax);
                    DMA_SWRITE(args.dst + o + p, local_value, len * sizeof(DATA_T));
                }
                
                global_ptr += rnz;
            }
            s *= cmax;
            local_cscale[j] = cmax;
            nrm = (nrm > s) ? nrm : s;
        }
        DMA_IWRITE(args.cscale + i, local_cscale, r_len * sizeof(real_t<DATA_T>));
    }
    if(buffer_ptr > 0) {
        DMA_IWRITE(args.dst + global_ptr, local_value, buffer_ptr * sizeof(DATA_T));
    }
    write_max_real(nrm, &args_ptr->norm_1);
    DMA_WAIT_ALL;
}

// ipiv: input and output
// perm: temporary buffer
INLINE Int ipiv2iperm_local(Int offset, Int ncol, Int* ipiv, Int* perm) {
    Int cnt = 0;
    for(Int i = 0; i < ncol; ++i) {
        perm[i] = i;
    }
    for(Int i = 0; i < ncol; ++i) {
        Int piv_i = ipiv[i];
        ASSERT_LESS(piv_i, ncol);
        ASSERT_LESS_EQUAL(0, piv_i);
        if(piv_i != i) {
            Int temp = perm[i];
            perm[i] = perm[piv_i];
            perm[piv_i] = temp;
            ++ cnt;
        }
    }
    for(Int i = 0; i < ncol; ++i) {
        ipiv[perm[i]] = i + offset;
    }
    return cnt;
}

Int ipiv2iperm(Int n, Int nsuper, const Int* sup2col, Int* indices) {
    constexpr Int chunk_size = 8192, max_sup_size = 2048, row_chunk_size = 1024;
    DMA_DECL_DESC(READ_WRITE)
    SIMD_ALIGN Int dist[64] = {0};
    Int id = memory_channel_mapping(CPE_ID);
    Int local_sup2col[row_chunk_size + 1], local_indices[chunk_size], perm_buffer[max_sup_size];
    swSparse_partition_nnz(nsuper, n, sup2col, dist, local_indices, chunk_size);     // internally synchronized
    Int s_begin = dist[id], s_end = (id == 63) ? nsuper : dist[id+1], buffer_ptr = 0, global_ptr = -1;
    Int changecnt = 0;

    for(Int i = s_begin; i < s_end; i += row_chunk_size) {
        const Int len = min(row_chunk_size, s_end - i);
        DMA_READ(sup2col + i, local_sup2col, (len + 1) * sizeof(Int));
        global_ptr = (global_ptr < 0) ? local_sup2col[0] : global_ptr;
        for(Int j = 0; j < len; ++j) {
            const Int off = local_sup2col[j], rnz = local_sup2col[j+1] - off;
            ASSERT_LESS_EQUAL(rnz, max_sup_size);
            if(buffer_ptr > 0 && buffer_ptr + rnz > chunk_size) {
                DMA_SWRITE(indices + global_ptr, local_indices, buffer_ptr * sizeof(Int));
                global_ptr += buffer_ptr;
                buffer_ptr = 0;
                ASSERT_EQUAL(global_ptr, off);
            }
            DMA_READ(indices + off, local_indices + buffer_ptr, rnz * sizeof(Int));
            changecnt += ipiv2iperm_local(off, rnz, local_indices + buffer_ptr, perm_buffer);
            buffer_ptr += rnz;
        }
    }
    if(buffer_ptr > 0) {
        DMA_WRITE(indices + global_ptr, local_indices, buffer_ptr * sizeof(Int));
    }
    return changecnt;
}


inline constexpr const Int chunk_1 = 8192;
inline constexpr const Int chunk_1_mask = chunk_1 - 1;

/* build offsets */
NOINLINE static void csr423_preprocess( \
    Int first_dim, Int total_nnz, const Int *begins, const Int *ends, Int *offsets, Int *dist) {

    Int local_begins[chunk_1], local_ends[chunk_1], local_offsets[chunk_1];
    cpe_ring ring(CPE_ID, 0, 8, 8);
    volatile Int base_buff;
    Int base, my_nnz, i, j, size, roffset, tgt_rank, p, ideal_nnz = max(1, total_nnz >> 6);

    DMA_DECL_DESC(READ_WRITE);

    size = first_dim >> 6;
    roffset = ring.rank * size;
    if(ring.rank == 63) { size = first_dim - roffset; }
    
    /* analyze nnz distribution */
    my_nnz = 0;
    for(i = size & (~chunk_1_mask); i >= 0; i -= chunk_1) {
        Int len = min(chunk_1, size - i);
        if(len > 0) {
            DMA_IREAD(begins + roffset + i, local_begins, len * sizeof(Int));
            DMA_READ(ends + roffset + i, local_ends, len * sizeof(Int));
            for(j = 0; j < len; ++j) {
                my_nnz += local_ends[j] - local_begins[j];
            }
        }
    }
    
    /* prefix scan */
    ring.sync_neighbor();
    base = 0;
    if(ring.rank != 0) {
        CRTS_ssync_peer(ring.prev);
        base = base_buff;
    }
    if(ring.rank != 63) {
        Int next = base + my_nnz;
        *remote_ldm_addr(&base_buff, ring.next) = next;
        mem_fence();
        CRTS_ssync_peer(ring.next);
    }

    tgt_rank = ceiling_div(base, ideal_nnz);
    p = tgt_rank * ideal_nnz;

    for(i = 0; i < size; i += chunk_1) {
        Int len = min(chunk_1, size - i);
        if(i > 0) {
            DMA_IREAD(begins + roffset + i, local_begins, len * sizeof(Int));
            DMA_READ(ends + roffset + i, local_ends, len * sizeof(Int));
        }
        for(j = 0; j < len; ++j) {
            base += local_ends[j] - local_begins[j];
            local_offsets[j] = base;

            if((local_offsets[j] > p) && (tgt_rank < 64)) {
                dist[tgt_rank] = i + j + roffset;
                p += ideal_nnz;
                ++tgt_rank;
            }
        }
        DMA_WRITE(offsets + 1 + roffset + i, local_offsets, len * sizeof(Int));
    }

    swSparse_collect_partition(dist);
}

/* copy indices and values */
template<typename DATA_T>
NOINLINE static void csr423_copy( \
    Int r_begin, Int r_end, \
    const Int *begins, const Int *offsets, const Int *indices4, const DATA_T *values4, \
    Int *indices3, DATA_T *values3) {

    Int local_begins[offset_tile], local_offsets[offset_tile+1], indices[sort_tile<DATA_T>];
    DATA_T values[sort_tile<DATA_T>];
    
    Int i, j, k, buffer_ptr = 0, global_ptr = -1;

    DMA_DECL_DESC(READ_WRITE);

    for(i = r_begin; i < r_end; i += offset_tile) {
        const Int len = min(offset_tile, r_end - i);
        DMA_IREAD(begins + i, local_begins, len * sizeof(Int));
        DMA_READ(offsets + i, local_offsets, (len + 1) * sizeof(Int));
        global_ptr = (global_ptr < 0) ? local_offsets[0] : global_ptr;
        for(j = 0; j < len; ++j) {
            const Int b = local_begins[j], o = local_offsets[j];
            const Int rnz = local_offsets[j+1] - o;
            if(rnz == 0) continue;
            if(buffer_ptr > 0 && buffer_ptr + rnz > sort_tile<DATA_T>) {
                DMA_IWRITE(values3 + global_ptr, values, buffer_ptr * sizeof(DATA_T));
                DMA_SWRITE(indices3 + global_ptr, indices, buffer_ptr * sizeof(Int));
                global_ptr += buffer_ptr;
                buffer_ptr = 0;
            }
            if(rnz <= sort_tile<DATA_T>) {
                DMA_IREAD(values4 + b, values + buffer_ptr, rnz * sizeof(DATA_T));
                DMA_SREAD(indices4 + b, indices + buffer_ptr, rnz * sizeof(Int));
                buffer_ptr += rnz;
            } else for(k = 0; k < rnz; k += sort_tile<DATA_T>) {
                Int rlen = min(sort_tile<DATA_T>, rnz - k);
                DMA_IREAD(values4 + b + k, values, rlen * sizeof(DATA_T));
                DMA_SREAD(indices4 + b + k, indices, rlen * sizeof(Int));
                DMA_IWRITE(values3 + global_ptr, values, rlen * sizeof(DATA_T));
                DMA_SWRITE(indices3 + global_ptr, indices, rlen * sizeof(Int));
                global_ptr += rlen;
            }
        }
    }
    if(buffer_ptr > 0) {
        DMA_IWRITE(values3 + global_ptr, values, buffer_ptr * sizeof(DATA_T));
        DMA_IWRITE(indices3 + global_ptr, indices, buffer_ptr * sizeof(Int));
    }
    DMA_WAIT_ALL;
}

template<Bool has_value, typename DATA_T>
NOINLINE static void csr423_perm( \
    Int r_begin, Int r_end, \
    const Int *begins, const Int *offsets, const Int *indices4, const DATA_T *values4, const Int *iperm, \
    Int *indices3, DATA_T *values3, Int *temp_indices3, DATA_T* temp_values3) {

    Int local_begins[offset_tile], local_offsets[offset_tile+1];
    Int idx_buffer[merge_k<DATA_T>][merge_buffer_size];
    using VAL_BUFFER = typename std::conditional_t<has_value, DATA_T[merge_k<DATA_T>][merge_buffer_size], dummy_t[1][1]>;
    VAL_BUFFER val_buffer;
    
    Int i, j, k, buffer_ptr = 0, global_ptr = -1;
    DATA_T* values[2] = {values3, temp_values3};
    Int* indices[2] = {indices3, temp_indices3};

    DMA_DECL_DESC(READ_WRITE);

    for(i = r_begin; i < r_end; i += offset_tile) {
        const Int len = min(offset_tile, r_end - i);
        DMA_IREAD(begins + i, local_begins, len * sizeof(Int));
        DMA_READ(offsets + i, local_offsets, (len + 1) * sizeof(Int));
        global_ptr = (global_ptr < 0) ? local_offsets[0] : global_ptr;
        for(j = 0; j < len; ++j) {
            const Int b = local_begins[j], o = local_offsets[j];
            const Int rnz = local_offsets[j+1] - o;
            if(rnz == 0) continue;
            if(buffer_ptr > 0 && buffer_ptr + rnz > sort_tile<DATA_T>) {
                if constexpr(has_value) {
                    DMA_IWRITE(values3 + global_ptr, val_buffer[0], buffer_ptr * sizeof(DATA_T));
                }
                DMA_SWRITE(indices3 + global_ptr, idx_buffer[0], buffer_ptr * sizeof(Int));
                global_ptr += buffer_ptr;
                buffer_ptr = 0;
            }
            if(rnz <= sort_tile<DATA_T>) {
                if constexpr(has_value) {
                    DMA_IREAD(values4 + b, val_buffer[0] + buffer_ptr, rnz * sizeof(DATA_T));
                }
                DMA_READ(indices4 + b, idx_buffer[0] + buffer_ptr, rnz * sizeof(Int));
                gather_local(rnz, iperm, idx_buffer[0] + buffer_ptr, idx_buffer[0] + buffer_ptr);
                sort_index_value(idx_buffer[0] + buffer_ptr, val_buffer[0] + buffer_ptr, rnz);
                buffer_ptr += rnz;
            } else {
                Int which = init_which<DATA_T>(rnz);
                for(k = 0; k < rnz; k += sort_tile<DATA_T>) {
                    Int rlen = min(sort_tile<DATA_T>, rnz - k);
                    if constexpr(has_value) {
                        DMA_IREAD(values4 + b + k, val_buffer[0], rlen * sizeof(DATA_T));
                    }
                    DMA_READ(indices4 + b + k, idx_buffer[0], rlen * sizeof(Int));
                    gather_local(rlen, iperm, idx_buffer[0], idx_buffer[0]);
                    sort_index_value(idx_buffer[0], val_buffer[0], rlen);
                    if constexpr(has_value) {
                        DMA_IWRITE(values[which] + global_ptr + k, val_buffer[0], rlen * sizeof(DATA_T));
                    }
                    DMA_WRITE(indices[which] + global_ptr + k, idx_buffer[0], rlen * sizeof(Int));
                }
                merge<Int, DATA_T, decltype(val_buffer), merge_k<DATA_T>, merge_buffer_size, has_value>(\
                    indices, values, which, rnz, global_ptr, idx_buffer, val_buffer);
                global_ptr += rnz;
            }
        }
    }
    if(buffer_ptr > 0) {        
        if constexpr(has_value) {
            DMA_IWRITE(values3 + global_ptr, val_buffer[0], buffer_ptr * sizeof(DATA_T));
        }
        DMA_IWRITE(indices3 + global_ptr, idx_buffer[0], buffer_ptr * sizeof(Int));
    }
    DMA_WAIT_ALL;
}

template<typename DATA_T>
NOINLINE void csr423_kernel(void *p_args) {
    SIMD_ALIGN Int dist[64] = {0};
    Int r_begin, r_end, id = CPE_ID;
    csr423_arg_t<DATA_T> args;
    DMA_READ_NODESC(p_args, &args, sizeof(args));
    csr423_preprocess(args.first_dim, args.nnz, args.begins, args.ends, args.offsets, dist);
    r_begin = dist[id];
    r_end = (id == 63) ? args.first_dim : dist[id + 1];
    csr423_copy(r_begin, r_end, args.begins, args.offsets, args.indices4, args.values4, \
        args.indices3, args.values3);
}

template<typename DATA_T>
NOINLINE void csr423_perm_kernel(void *p_args) {
    SIMD_ALIGN Int dist[64] = {0};
    Int r_begin, r_end, id = CPE_ID;
    csr423_perm_arg_t<DATA_T> args;
    DMA_READ_NODESC(p_args, &args, sizeof(args));
    csr423_preprocess(args.first_dim, args.nnz, args.begins, args.ends, args.offsets, dist);
    r_begin = dist[id];
    r_end = (id == 63) ? args.first_dim : dist[id + 1];
    csr423_perm<true>(r_begin, r_end, args.begins, args.offsets, args.indices4, args.values4, args.iperm, \
        args.indices3, args.values3, args.temp_indices3, args.temp_values3);
}

CPE_TEMPLATE_KERNEL(csr423_kernel, CACHE_0KB)
CPE_TEMPLATE_KERNEL(csr423_perm_kernel, CACHE_32KB)
CPE_TEMPLATE_KERNEL(rowwise_sort_kernel, CACHE_0KB)
CPE_CONCRETE_KERNEL(rowwise_sort_pattern_kernel, CACHE_0KB)
CPE_CONCRETE_KERNEL(sort_subtrees_kernel, CACHE_IGNORE)
CPE_TEMPLATE_KERNEL(mc64_preprocess_kernel, CACHE_IGNORE)
CPE_TEMPLATE_KERNEL(sparse_rescale_colmax_kernel, CACHE_128KB)
CPE_TEMPLATE_KERNEL(sparse_scale_kernel, CACHE_128KB)
}
