#include "internal/multicompile.h"

#ifdef DATA_TYPE_S
#define MLEN 2000
#endif
#ifdef DATA_TYPE_D
#define MLEN 1000
#endif
#ifdef DATA_TYPE_C
#define MLEN 1000
#endif
#ifdef DATA_TYPE_Z
#define MLEN 500
#endif

#ifndef CAL_ID_27__
#define CAL_ID_27__

static int Cal_ID_27(int ids[16]) //Need Row Synchronous
{
	int id = -1;
	int gr = -1, gc = -1, pr = -1, pc = -1;
	int ps = -1, gs = -1;
	int row = ROW(CPE_ID);
	int col = COL(CPE_ID);
	gr = (col+COLS-1)%COLS;
	gc = (row+ROWS-1)%ROWS;
	pr = (col+1)%COLS;
	pc = (row+1)%ROWS;
	if(col == 0)
	{
		gs = gr;
		gr = -1;
	}
	if(col == 7)
	{
		ps = pr;
		pr = -1;
	}
        if (row == 7) pc = -1;
	row = (row-col+ROWS)%ROWS;
	id = col*8+row;
	ids[0] = id;
	ids[1] = row;
	ids[2] = col;
	ids[3] = pr;
	ids[4] = gr;
	ids[5] = pc;
	ids[6] = gc;
	ids[7] = ps;
	ids[8] = gs;
	return 0;
}

#endif

void FUNCNAME(strsv_27_forward_kernel)(DATA_T *X, const DATA_T *A, const DATA_T *B, int M, int N, int L, int rnz, int *coid, int *zoff, DATA_T *_ptr, int HALO)
{
        int id = -1, rid = -1, cid = -1;
        int gr = -1, gc = -1, pr = -1, pc = -1;
        int ps = -1, gs = -1;
        //Init id information
        {
                int ids[16];
                Cal_ID_27(ids);
                id  = ids[0];
                rid = ids[1];
                cid = ids[2];
                pr  = ids[3];
                gr  = ids[4];
                pc  = ids[5];
                gc  = ids[6];
                ps  = ids[7];
                gs  = ids[8];
        }
        int pos_dj[4] = {-1, 0, 1, -1};
        int pos_di[4] = {-1, -1, -1, 0};
        int should_dma[4];
        int not_from_reg[4];
	//Begin Cal
        //char testout[128];
        DATA_T *LX[5], *LAA, *LA_begin, *LA_end;
        DATA_T *LA;
        //int *LAI, *LAJ;
        int col_id[rnz];
        int z_offset[rnz];
        DATA_T *ptr = _ptr;
        // volatile int reply = 0;
        // volatile int COUNT = 0;
        int i = 0, j = 0, k = 0, K = 0;
        int bi = 0, bj = 0, bk = 0, bii = 0, bjj = 0;
        int count = 0, zcount = 0;
        // dma_desc dma_get;
        // dma_desc dma_put;
        // DMA_INIT(&dma_get, DMA_GET, &reply);
        // DMA_INIT(&dma_put, DMA_PUT, &reply);
        DMA_DECL_DESC(READ_WRITE);
        //Init LX pointer
        int LEN = gridmin(L, MLEN);
        int SIZE = LEN;
        int halo = HALO / 2;

        int ALEN = (MAX_GRID_SIZE*8/sizeof(DATA_T)-5*(LEN+HALO))/rnz;
        // WXL_DMA_NEW(dma_get, coid, col_id, sizeof(int)*rnz, COUNT);
        // DMA_WAIT(&reply, COUNT);
        // WXL_DMA_NEW(dma_get, zoff, z_offset, sizeof(int)*rnz, COUNT);
        // DMA_WAIT(&reply, COUNT);
        DMA_IREAD(coid, col_id, sizeof(int)*rnz);
        DMA_IREAD(zoff, z_offset, sizeof(int)*rnz);
        DMA_WAIT_ALL;

        int ii, jj, kk;
        for (ii = 0; ii < 5; ii++)
        {
                LX[ii] = (DATA_T*)ptr;
                for (jj = 0; jj < LEN + HALO; jj++)
                        LX[ii][jj] = 0;
                ptr += (SIZE + HALO);
        }
        LA_begin = ptr; ptr += rnz * ALEN; LA_end = ptr;
        int is = (M + COLS - 1) / COLS;
        int js;
        for (i = cid; i < cid + is * COLS; i+=COLS)
        {
                int width = gridmin(M - (i - cid), COLS);
                int right_off;
                right_off = 8 - (width - 1);
                js = (N - right_off + ROWS - 1) / ROWS + 1;        
                for (j = ROW(CPE_ID) - cid; j < ROW(CPE_ID) - cid + js * ROWS; j+=ROWS)
                {
                        count = bi = bj = bii = bjj = halo;
                        for (ii = 0; ii <= 4; ii++)
                                for (jj = 0; jj < halo; jj++)
                                {
                                        LX[ii][jj] = 0;
                                }
                        if (j >= 0 && j <= N && i < M)
                        {
                                for (ii = 0; ii < 4; ii++)
                                {
                                        int oi = i + pos_di[ii];
                                        int oj = j + pos_dj[ii];
                                        if (oi >= 0 && oi < M && oj >= 0 && oj < N) should_dma[ii] = 1; else should_dma[ii] = 0;
                                }
                                if (COL(CPE_ID) == 0||j >= N) bi += L;
                                if (ROW(CPE_ID) == 0||j == 0) bj += L;
                                if (j < N)
                                {
                                        int alen = rnz * (ALEN < L ? ALEN : L);
                                        DMA_IREAD(A+rnz*((i*N+j)*L), LA_begin,sizeof(DATA_T)*alen);
                                        // WXL_DMA_NEW(dma_get, A+rnz*((i*N+j)*L), LA_begin,sizeof(DATA_T)*alen, COUNT);
                                        LA = LA_begin;
                                        for (K = 0; K < L; K+= SIZE)
                                        {
                                                int off_up;
                                                if (K + SIZE > L - 1)
                                                        off_up = 0;
                                                else
                                                        off_up = gridmin(L - K - SIZE, halo);
                                                LEN = gridmin(L - K, SIZE);
                                                DMA_IREAD(B+(i*N+j)*L+K, LX[4]+halo, sizeof(DATA_T)*(LEN));
                                                //WXL_DMA_NEW(dma_get, B+(i*N+j)*L+K, LX[4]+halo, sizeof(DATA_T)*(LEN), COUNT);
                                                if (cid == 0)
                                                {
                                                        for (ii = 1; ii <= 2; ii++)
                                                        {
                                                                int t_coid = ii;
                                                                if (should_dma[t_coid])
                                                                {
                                                                        DMA_IREAD(X+i*N*L+j*L+pos_di[t_coid]*N*L+pos_dj[t_coid]*L+K, LX[t_coid]+halo, sizeof(DATA_T)*(LEN+off_up));
                                                                        //WXL_DMA_NEW(dma_get, , COUNT);
                                                                }
                                                                else
                                                                        for (kk = 0; kk < LEN + halo; kk++) LX[t_coid][kk+halo] = 0;
                                                        }
                                                }
                                                if (ROW(CPE_ID) == 0||j == 0)
                                                {
                                                        for (ii = 0; ii < 2; ii++)
                                                        {
                                                                int t_coid = 3 * ii;
                                                                if (should_dma[t_coid])
                                                                {
                                                                        DMA_IREAD(X+i*N*L+j*L+pos_di[t_coid]*N*L+pos_dj[t_coid]*L+K, LX[t_coid]+halo, sizeof(DATA_T)*(LEN+off_up));
                                                                        // WXL_DMA_NEW(dma_get, , COUNT);
                                                                }
                                                                else
                                                                        for (kk = 0; kk < LEN + halo; kk++) LX[t_coid][kk+halo] = 0;
                                                        }
                                                }
                                                DMA_WAIT_ALL;
                                                //DMA_WAIT(&reply, COUNT);
                                                for (k = 0; k < LEN; k++)
                                                {
                                                        if(LA == LA_end)
                                                        {
                                                                LA = LA_begin;
                                                                alen = rnz * (ALEN < (L-K-k) ? ALEN : (L-K-k));
                                                                DMA_READ(A+rnz*((i*N+j)*L+K+k), LA_begin, sizeof(DATA_T)*alen)
                                                                //WXL_DMA_NEW(dma_get, ,  COUNT);
                                                                //DMA_WAIT(&reply, COUNT);
                                                        }
                                                        while (count>=(bi-halo)&&bi!=L+halo||count>=(bj-halo)&&bj!=L+halo)
                                                        {
                                                                int overlap = LEN;
                                                                if (K + SIZE < L) overlap -= halo;
                                                                if (gr >= 0 && bi < (count+overlap) && !EMPTY_GETR())
                                                                {
                                                                        GGETR2(LX[1][bii], LX[2][bii]);
                                                                        bii++;
                                                                        if (bii >= HALO+SIZE) bii -= SIZE;
                                                                        bi++;
                                                                }
                                                                if (gc >= 0 && bj < (count+overlap) && !EMPTY_GETC())
                                                                {
                                                                        GGETC2(LX[0][bjj], LX[3][bjj]);
                                                                        bjj++;
                                                                        if (bjj >= HALO+SIZE) bjj -= SIZE;
                                                                        bj++;
                                                                }
                                                        }
                                                        DATA_T result = 0;
                                                        int iter;
                                                        for (iter = 0; iter < rnz; iter++)
                                                        {
                                                                result += LA[iter] * LX[col_id[iter]][k+halo+z_offset[iter]];
                                                        }
                                                        LX[4][k+halo] = LX[4][k+halo] - result;
                                                        LA += rnz;
                                                        count++;
                                                        if (pr >= 0 && j > 0 && i < M - 1)
                                                        {
                                                                GPUTR2(LX[3][k+halo], LX[4][k+halo], pr);
                                                        }
                                                        if (pc >= 0)
                                                        {
                                                                GPUTC2(LX[1][k+halo], LX[4][k+halo], pc);
                                                        }
                                                }
                                                DMA_WRITE(X+(i*N+j)*L+K, LX[4]+halo, sizeof(DATA_T)*(LEN));
                                                //WXL_DMA_NEW(dma_put, , COUNT);
                                                //DMA_WAIT(&reply, COUNT);
                                                if (K + SIZE < L)
                                                {
                                                        int LENtoBe = gridmin(L - K - SIZE, SIZE);
                                                        for (ii = 0; ii <= 4; ii++)
                                                        {
                                                                for (jj = 0; jj < HALO; jj++)
                                                                        LX[ii][jj] = LX[ii][LEN+jj];
                                                                for (jj = 0; jj < halo; jj++)
                                                                        LX[ii][LENtoBe+halo+jj] = 0;
                                                        }
                                                }
                                        }
                                }
                                else
                                {
                                        LX[4][0] = 0;
                                        for (K = 0; K < L; K+=SIZE)
                                        {
                                                LEN = gridmin(L - K, SIZE);
                                                int off_up;
                                                if (K + SIZE > L - 1)
                                                        off_up = 0;
                                                else
                                                        off_up = gridmin(L - K - SIZE, halo);
                                                if (true)
                                                {
                                                        for (ii = 1; ii <= 2; ii++)
                                                        {
                                                                int t_coid = ii;
                                                                for (kk = 0; kk < LEN + halo; kk++) LX[t_coid][kk+halo] = 0;
                                                        }
                                                }
                                                if (ROW(CPE_ID) == 0)
                                                {
                                                        for (ii = 0; ii < 2; ii++)
                                                        {
                                                                int t_coid = 3 * ii;
                                                                if (should_dma[t_coid])
                                                                {
                                                                        DMA_IREAD(X+i*N*L+j*L+pos_di[t_coid]*N*L+pos_dj[t_coid]*L+K, LX[t_coid]+halo, sizeof(DATA_T)*(LEN+off_up));
                                                                        //WXL_DMA_NEW(dma_get, , COUNT);
                                                                }
                                                                else
                                                                        for (kk = 0; kk < LEN + halo; kk++) LX[t_coid][kk+halo] = 0;
                                                        }
                                                }
                                                DMA_WAIT_ALL;
                                                //DMA_WAIT(&reply, COUNT);
                                                for (k = 0; k < LEN; k++)
                                                {
                                                        while (count>=bi||count>=bj)
                                                        {
                                                                int overlap = LEN;
                                                                if (K + SIZE < L) overlap -= halo;
                                                                if (gr >= 0 && bi < (count+overlap) && !EMPTY_GETR())
                                                                {
                                                                        GGETR2(LX[1][bii], LX[2][bii]);
                                                                        bii++;
                                                                        if (bii >= halo+SIZE) bii -= SIZE;
                                                                        bi++;
                                                                }
                                                                if (gc >= 0 && bj < (count+overlap) && !EMPTY_GETC())
                                                                {
                                                                        GGETC2(LX[0][bjj], LX[3][bjj]);
                                                                        bjj++;
                                                                        if (bjj >= halo+SIZE) bjj -= SIZE;
                                                                        bj++;
                                                                }
                                                        }
                                                        count++;
                                                        if (pr >= 0 && j > 0 && i < M - 1)
                                                        {
                                                                GPUTR2(LX[3][k+halo], LX[4][0], pr);
                                                        }
                                                }
                                        }
                                }
                        }
                        SYNC_ALL;
                        
                }
        }
}

void FUNCNAME(strsv_27_backward_kernel)(DATA_T *X, const DATA_T *A, const DATA_T *B, int M, int N, int L, int rnz, int *coid, int *zoff, DATA_T *_ptr, int HALO)
{
        int id = -1, rid = -1, cid = -1;
        int gr = -1, gc = -1, pr = -1, pc = -1;
        int ps = -1, gs = -1;
        //Init id information
        {
                int ids[16];
                Cal_ID_27(ids);
                id  = ids[0];
                rid = ids[1];
                cid = ids[2];
                pr  = ids[3];
                gr  = ids[4];
                pc  = ids[5];
                gc  = ids[6];
                ps  = ids[7];
                gs  = ids[8];
        }
        int pos_dj[4] = {-1, 0, 1, -1};
        int pos_di[4] = {-1, -1, -1, 0};
        int should_dma[4];
        int not_from_reg[4];
	//Begin Cal
        //char testout[128];
        DATA_T *LX[5], *LAA, *LA_begin, *LA_end;
        DATA_T *LA;
        //int *LAI, *LAJ;
        int col_id[rnz];
        int z_offset[rnz];
        DATA_T *ptr = _ptr;
        // volatile int reply = 0;
        // volatile int COUNT = 0;
        int i = 0, j = 0, k = 0, K = 0;
        int bi = 0, bj = 0, bk = 0, bii = 0, bjj = 0;
        int count = 0, zcount = 0;
        // dma_desc dma_get;
        // dma_desc dma_put;
        DMA_DECL_DESC(READ_WRITE);
        // DMA_INIT(&dma_get, DMA_GET, &reply);
        // DMA_INIT(&dma_put, DMA_PUT, &reply);
        //Init LX pointer
        int LEN = gridmin(L, MLEN);
        int SIZE = LEN;
        int halo = HALO / 2;

        int ALEN = (MAX_GRID_SIZE*8/sizeof(DATA_T)-5*(LEN+HALO))/rnz;
        //WXL_DMA_NEW(dma_get, , COUNT);
        //DMA_WAIT(&reply, COUNT);
        //WXL_DMA_NEW(dma_get, , COUNT);
        //DMA_WAIT(&reply, COUNT);
        DMA_IREAD(coid, col_id, sizeof(int)*rnz);
        DMA_IREAD(zoff, z_offset, sizeof(int)*rnz);
        DMA_WAIT_ALL;

        int ii, jj, kk;
        for (ii = 0; ii < 5; ii++)
        {
                LX[ii] = (DATA_T*)ptr;
                for (jj = 0; jj < LEN + HALO; jj++)
                        LX[ii][jj] = 0;
                ptr += (SIZE + HALO);
        }
        LA_begin = ptr; ptr += rnz * ALEN; LA_end = ptr;
        int is = (M + COLS - 1) / COLS;
        int js;
        for (i = cid; i < cid + is * COLS; i+=COLS)
        {
                int width = gridmin(M - (i - cid), COLS);
                int right_off;
                right_off = 8 - (width - 1);
                js = (N - right_off + ROWS - 1) / ROWS + 1;        
                for (j = ROW(CPE_ID) - cid; j < ROW(CPE_ID) - cid + js * ROWS; j+=ROWS)
                {
                        count = bi = bj = halo;
                        bii = bjj = SIZE + halo - 1;
                        for (ii = 0; ii <= 4; ii++)
                                for (jj = 0; jj < halo; jj++)
                                {
                                        LX[ii][SIZE + halo + jj] = 0;
                                }
                        if (j >= 0 && j <= N && i < M)
                        {
                                for (ii = 0; ii < 4; ii++)
                                {
                                        int oi = i + pos_di[ii];
                                        int oj = j + pos_dj[ii];
                                        if (oi >= 0 && oi < M && oj >= 0 && oj < N) should_dma[ii] = 1; else should_dma[ii] = 0;
                                }
                                if (COL(CPE_ID) == 0||j >= N) bi += L;
                                if (ROW(CPE_ID) == 0||j == 0) bj += L;
                                if (j < N)
                                {
                                        int alen = rnz * (ALEN < L ? ALEN : L);
                                        DMA_IREAD(A+(M*N*L-(i*N+j)*L)*rnz-alen, LA_begin, sizeof(DATA_T)*alen);
                                        //WXL_DMA_NEW(dma_get, , COUNT);
                                        LA = LA_begin + alen - rnz;
                                        for (K = 0; K < L; K+= SIZE)
                                        {
                                                int off_up;
                                                if (K + SIZE > L - 1)
                                                        off_up = 0;
                                                else
                                                        off_up = gridmin(L - K - SIZE, halo);
                                                LEN = gridmin(L - K, SIZE);
                                                int buf_off = SIZE - LEN + halo;
                                                DMA_IREAD(B+M*N*L-(i*N+j)*L-K-LEN, LX[4]+buf_off, sizeof(DATA_T)*(LEN));
                                                //WXL_DMA_NEW(dma_get, , COUNT);
                                                if (cid == 0)
                                                {
                                                        for (ii = 1; ii <= 2; ii++)
                                                        {
                                                                int t_coid = ii;
                                                                if (should_dma[t_coid])
                                                                {
                                                                        DMA_IREAD(X+M*N*L-(i*N*L+j*L+pos_di[t_coid]*N*L+pos_dj[t_coid]*L+K)-LEN-off_up, LX[t_coid]+buf_off-off_up, sizeof(DATA_T)*(LEN+off_up));
                                                                        //WXL_DMA_NEW(dma_get, , COUNT);
                                                                }
                                                                else
                                                                        for (kk = 0; kk < SIZE + halo; kk++) LX[t_coid][kk] = 0;
                                                        }
                                                }
                                                if (ROW(CPE_ID) == 0||j == 0)
                                                {
                                                        for (ii = 0; ii < 2; ii++)
                                                        {
                                                                int t_coid = 3 * ii;
                                                                if (should_dma[t_coid])
                                                                {
                                                                        DMA_IREAD(X+M*N*L-(i*N*L+j*L+pos_di[t_coid]*N*L+pos_dj[t_coid]*L+K)-LEN-off_up, LX[t_coid]+buf_off-off_up, sizeof(DATA_T)*(LEN+off_up));
                                                                        //WXL_DMA_NEW(dma_get, , COUNT);
                                                                }
                                                                else
                                                                        for (kk = 0; kk < SIZE + halo; kk++) LX[t_coid][kk] = 0;
                                                        }
                                                }
                                                DMA_WAIT_ALL;
                                                //DMA_WAIT(&reply, COUNT);
                                                for (k = LEN - 1; k >= 0; k--)
                                                {
                                                        int pass = LEN - 1 - k;
                                                        if(LA == LA_begin - rnz)
                                                        {
                                                                alen = rnz * (ALEN < (L-K-pass) ? ALEN : (L-K-pass));
                                                                LA = LA_begin + alen - rnz;
                                                                DMA_READ(A+(M*N*L-(i*N+j)*L-K-pass)*rnz-alen, LA_begin, sizeof(DATA_T)*alen);
                                                                // WXL_DMA_NEW(dma_get, , COUNT);
                                                                // DMA_WAIT(&reply, COUNT);
                                                        }
                                                        while (count>=(bi-halo)&&bi!=L+halo||count>=(bj-halo)&&bj!=L+halo)
                                                        {
                                                                int overlap = LEN;
                                                                if (K + SIZE < L) overlap -= halo;
                                                                if (gr >= 0 && bi < (count+overlap) && !EMPTY_GETR())
                                                                {
                                                                        GGETR2(LX[1][bii], LX[2][bii]);
                                                                        bii--;
                                                                        if (bii < 0) bii += SIZE;
                                                                        bi++;
                                                                }
                                                                if (gc >= 0 && bj < (count+overlap) && !EMPTY_GETC())
                                                                {
                                                                        GGETC2(LX[0][bjj], LX[3][bjj]);
                                                                        bjj--;
                                                                        if (bjj < 0) bjj += SIZE;
                                                                        bj++;
                                                                }
                                                        }
                                                        DATA_T result = 0;
                                                        DATA_T para = 1.0;
                                                        int iter;
                                                        for (iter = 0; iter < rnz; iter++)
                                                        {
                                                                if (col_id[iter] == 4 && z_offset[iter] == 0)
                                                                        para = LA[iter];
                                                                else
                                                                        result += LA[iter] * LX[col_id[iter]][k+buf_off+z_offset[iter]];
                                                        }
                                                        LX[4][k+buf_off] = (LX[4][k+buf_off] - result) / para;
                                                        LA -= rnz;
                                                        count++;
                                                        if (pr >= 0 && j > 0 && i < M - 1)
                                                        {
                                                                GPUTR2(LX[3][k+buf_off], LX[4][k+buf_off], pr);
                                                        }
                                                        if (pc >= 0)
                                                        {
                                                                GPUTC2(LX[1][k+buf_off], LX[4][k+buf_off], pc);
                                                        }
                                                }
                                                DMA_WRITE(X+M*N*L-(i*N+j)*L-K-LEN, LX[4]+buf_off, sizeof(DATA_T)*(LEN));
                                                // WXL_DMA_NEW(dma_put, , COUNT);
                                                // DMA_WAIT(&reply, COUNT);
                                                if (K + SIZE < L)
                                                {
                                                        int LENtoBe = gridmin(L - K - SIZE, SIZE);
                                                        for (ii = 0; ii <= 4; ii++)
                                                        {
                                                                for (jj = 0; jj < HALO; jj++)
                                                                        LX[ii][LEN+jj] = LX[ii][jj];
                                                                for (jj = 0; jj < halo; jj++)
                                                                        LX[ii][SIZE-LENtoBe+halo-1-jj] = 0;
                                                        }
                                                }
                                        }
                                }
                                else
                                {
                                        LX[4][0] = 0;
                                        for (K = 0; K < L; K+=SIZE)
                                        {
                                                LEN = gridmin(L - K, SIZE);
                                                int buf_off = SIZE - LEN + halo;
                                                int off_up;
                                                if (K + SIZE > L - 1)
                                                        off_up = 0;
                                                else
                                                        off_up = gridmin(L - K - SIZE, halo);
                                                if (true)
                                                {
                                                        for (ii = 1; ii <= 2; ii++)
                                                        {
                                                                int t_coid = ii;
                                                                for (kk = 0; kk < SIZE + halo; kk++) LX[t_coid][kk] = 0;
                                                        }
                                                }
                                                if (ROW(CPE_ID) == 0)
                                                {
                                                        for (ii = 0; ii < 2; ii++)
                                                        {
                                                                int t_coid = 3 * ii;
                                                                if (should_dma[t_coid])
                                                                {
                                                                        DMA_IREAD(X+M*N*L-(i*N*L+j*L+pos_di[t_coid]*N*L+pos_dj[t_coid]*L+K)-LEN-off_up, LX[t_coid]+buf_off-off_up, sizeof(DATA_T)*(LEN+off_up));
                                                                        // WXL_DMA_NEW(dma_get, , COUNT);
                                                                }
                                                                else
                                                                        for (kk = 0; kk < SIZE + halo; kk++) LX[t_coid][kk] = 0;
                                                        }
                                                }
                                                DMA_WAIT_ALL;
                                                // DMA_WAIT(&reply, COUNT);
                                                for (k = LEN - 1; k >= 0; k--)
                                                {
                                                        while (count>=bi||count>=bj)
                                                        {
                                                                int overlap = LEN;
                                                                if (K + SIZE < L) overlap -= halo;
                                                                if (gr >= 0 && bi < (count+overlap) && !EMPTY_GETR())
                                                                {
                                                                        GGETR2(LX[1][bii], LX[2][bii]);
                                                                        bii--;
                                                                        if (bii < halo) bii += SIZE;
                                                                        bi++;
                                                                }
                                                                if (gc >= 0 && bj < (count+overlap) && !EMPTY_GETC())
                                                                {
                                                                        GGETC2(LX[0][bjj], LX[3][bjj]);
                                                                        bjj--;
                                                                        if (bjj < halo) bjj += SIZE;
                                                                        bj++;
                                                                }
                                                        }
                                                        count++;
                                                        if (pr >= 0 && j > 0 && i < M - 1)
                                                        {
                                                                GPUTR2(LX[3][k+buf_off], LX[4][0], pr);
                                                        }
                                                }
                                        }
                                }
                        }
                        SYNC_ALL;
                        
                }
        }
}

void SLAVE_FUNCNAME(forward_27_slave)(void *_ptr)
{
        DATA_T data[MAX_GRID_SIZE*8/sizeof(DATA_T)];
        // volatile int reply = 0;
        // volatile int COUNT = 0;
        Info info;
        // dma_desc dma_get;
        // DMA_INIT(&dma_get, DMA_GET, &reply);
        // WXL_DMA_NEW(dma_get, , COUNT);
        // DMA_WAIT(&reply, COUNT);
        DMA_DECL_DESC(READ);
        DMA_READ(_ptr, &info, sizeof(Info));
        #ifdef DATA_TYPE_S
        swSparse_s_strsv_27_forward_kernel(info.X, info.A, info.B, info.M, info.N, info.L, info.rnz, info.cid, info.zoff, (DATA_T*)data, info.HALO);
        #endif
        #ifdef DATA_TYPE_D
        swSparse_d_strsv_27_forward_kernel(info.X, info.A, info.B, info.M, info.N, info.L, info.rnz, info.cid, info.zoff, (DATA_T*)data, info.HALO);
        #endif
        #ifdef DATA_TYPE_C
        swSparse_c_strsv_27_forward_kernel(info.X, info.A, info.B, info.M, info.N, info.L, info.rnz, info.cid, info.zoff, (DATA_T*)data, info.HALO);
        #endif
        #ifdef DATA_TYPE_Z
        swSparse_z_strsv_27_forward_kernel(info.X, info.A, info.B, info.M, info.N, info.L, info.rnz, info.cid, info.zoff, (DATA_T*)data, info.HALO);
        #endif
        return;
}

void SLAVE_FUNCNAME(backward_27_slave)(void *_ptr)
{
        DATA_T data[MAX_GRID_SIZE*8/sizeof(DATA_T)];
        // volatile int reply = 0;
        // volatile int COUNT = 0;
        Info info;
        // dma_desc dma_get;
        // DMA_INIT(&dma_get, DMA_GET, &reply);
        // WXL_DMA_NEW(dma_get, _ptr, &info, sizeof(Info), COUNT);
        // DMA_WAIT(&reply, COUNT);
        DMA_DECL_DESC(READ);
        DMA_READ(_ptr, &info, sizeof(Info));
        #ifdef DATA_TYPE_S
        swSparse_s_strsv_27_backward_kernel(info.X, info.A, info.B, info.M, info.N, info.L, info.rnz, info.cid, info.zoff, (DATA_T*)data, info.HALO);
        #endif
        #ifdef DATA_TYPE_D
        swSparse_d_strsv_27_backward_kernel(info.X, info.A, info.B, info.M, info.N, info.L, info.rnz, info.cid, info.zoff, (DATA_T*)data, info.HALO);
        #endif
        #ifdef DATA_TYPE_C
        swSparse_c_strsv_27_backward_kernel(info.X, info.A, info.B, info.M, info.N, info.L, info.rnz, info.cid, info.zoff, (DATA_T*)data, info.HALO);
        #endif
        #ifdef DATA_TYPE_Z
        swSparse_z_strsv_27_backward_kernel(info.X, info.A, info.B, info.M, info.N, info.L, info.rnz, info.cid, info.zoff, (DATA_T*)data, info.HALO);
        #endif
        return;
}

#undef MLEN
