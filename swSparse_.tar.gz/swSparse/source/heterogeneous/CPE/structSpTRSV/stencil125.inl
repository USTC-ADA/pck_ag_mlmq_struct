#include "internal/multicompile.h"

#ifdef DATA_TYPE_S
#define MLEN 1000
#endif
#ifdef DATA_TYPE_D
#define MLEN 500
#endif
#ifdef DATA_TYPE_C
#define MLEN 500
#endif
#ifdef DATA_TYPE_Z
#define MLEN 250
#endif

#ifndef CAL_ID_125
#define CAL_ID_125

static int Cal_ID_125(int ids[16]) //Need Row Synchronous
{
	int id = -1;
	int gr = -1, gc = -1, pr = -1, pc = -1;
	int ps = -1, gs = -1;
	int row = ROW(CPE_ID);
	int col = COL(CPE_ID);
	gr = (col+COLS-1)%COLS;
	gc = (row+ROWS-1)%ROWS;
	pr = (col+1)%COLS;
	pc = (row+1)%ROWS;
	if(col == 0)
	{
		gs = gr;
		gr = -1;
	}
	if(col == 7)
	{
		ps = pr;
		pr = -1;
	}
	if (row == 7) pc = -1;
	row = (row-2*col+ROWS*ROWS)%ROWS;
	id = col*8+row;
	//printf("%d(R:%d C:%d)(pr:%d gr:%d pc:%d gc:%d)(%d %d)\n", id, row, col, pr, gr, pc, gc, ps, gs);
	ids[0] = id;
	ids[1] = row;
	ids[2] = col;
	ids[3] = pr;
	ids[4] = gr;
	ids[5] = pc;
	ids[6] = gc;
	ids[7] = ps;
	ids[8] = gs;
	return 0;
}

#endif

void FUNCNAME(strsv_125_forward_kernel)(DATA_T *X, const DATA_T *A, const DATA_T *B, int M, int N, int L, int rnz, int *coid, int *zoff, DATA_T *_ptr, int HALO)
{
    int id = -1, rid = -1, cid = -1;
	int gr = -1, gc = -1, pr = -1, pc = -1;
	int ps = -1, gs = -1;
	//Init id information
	{
		int ids[16];
		Cal_ID_125(ids);
		id  = ids[0];
		rid = ids[1];
		cid = ids[2];
		pr  = ids[3];
		gr  = ids[4];
		pc  = ids[5];
		gc  = ids[6];
		ps  = ids[7];
		gs  = ids[8];
	}
    #define MATRIX_BUFFER 1024
	int pos_dj[12] = {-2, -1, 0, 1, 2, -2, -1, 0, 1, 2, -2, -1};
	int pos_di[12] = {-2, -2, -2, -2, -2, -1, -1, -1, -1, -1, 0, 0};
	int should_dma[12];
	int not_from_reg[12];
	//Begin Cal
    {
		//char testout[128];
        DATA_T *LX[13], *LAA, *LA_begin, *LA_end;
		DATA_T *LA;
        //int *LAI, *LAJ;
		int col_id[rnz];
		int z_offset[rnz];
		DATA_T *ptr = _ptr;
		// volatile int reply = 0;
		// volatile int COUNT = 0;
		int i = 0,j = 0,k = 0,K = 0;
		int bi = 0, bj = 0, bk = 0, bii = 0, bjj = 0;
		int count = 0, zcount = 0;
		// dma_desc dma_get;
		// dma_desc dma_put;
		// WXL_DMA_SET_NOSIZE(&dma_get, DMA_GET, &reply);
		// WXL_DMA_SET_NOSIZE(&dma_put, DMA_PUT, &reply);
		DMA_DECL_DESC(READ_WRITE);
		//Init LX pointer
		int LEN = gridmin(L, MLEN);
		int SIZE = LEN;
		int halo = HALO / 2;
        
		int ALEN = (MAX_GRID_SIZE*8/sizeof(DATA_T)-13*(LEN+HALO))/rnz;
		// WXL_DMA_NEW(dma_get, coid, col_id, sizeof(int)*rnz, COUNT);
		// dma_wait(&reply, COUNT);
		// WXL_DMA_NEW(dma_get, zoff, z_offset, sizeof(int)*rnz, COUNT);
		// dma_wait(&reply, COUNT);
		DMA_IREAD(coid, col_id, sizeof(int)*rnz);
        DMA_IREAD(zoff, z_offset, sizeof(int)*rnz);
        DMA_WAIT_ALL;
        
		int ii, jj, kk;
		for (ii = 0; ii < 13; ii++)
		{
			LX[ii] = (DATA_T*)ptr;
			for (jj = 0; jj < LEN + HALO; jj++)
				LX[ii][jj] = 0;
			ptr += (SIZE + HALO);
		}
		LA_begin = ptr; ptr += rnz * ALEN; LA_end = ptr;
		int is = (M + COLS - 1) / COLS;
		int js;
		for (i = cid; i < cid + is * COLS; i+=COLS)
		{
			int width = gridmin(M - (i - cid), COLS);
			int right_off;
			if (width <= 4)
			{
				right_off = 8 - (width - 1) * 2;
				if (N <= right_off)
					js = 1;
				else
					js = (N - right_off + ROWS - 1) / ROWS + 1;
			}
			else
			{
				right_off = 8 - (width - 4) * 2;
				if (N <= right_off)
					js = 2;
				else
					js = (N - right_off + ROWS - 1) / ROWS + 2;
			}
			for (j = ROW(CPE_ID) - 2 * cid; j < ROW(CPE_ID) - 2 * cid + js * ROWS; j+=ROWS)
			{
				count = bi = bj = bii = bjj = halo;
				for (ii = 0; ii <= 12; ii++)
					for (jj = 0; jj < HALO/2; jj++)
					{
						LX[ii][jj] = 0;
					}
				if (j >= 0 && j <= N + 1 && i < M)
				{
					// sprintf(testout, "%d: i %d j %d\n", id, i, j);
					// printf(testout);
					for (ii = 0; ii < 12; ii++)
					{
						int oi = i + pos_di[ii];
						int oj = j + pos_dj[ii];
						if (oi >= 0 && oi < M && oj >= 0 && oj < N) should_dma[ii] = 1; else should_dma[ii] = 0;
					}
					if (COL(CPE_ID) == 0||j >= N) bi += L;
					if (ROW(CPE_ID) == 0||j == 0) bj += L;
					if (j < N)
					{
						int alen = rnz * (ALEN < L ? ALEN : L);
						//WXL_DMA_NEW(dma_get, , COUNT);
						DMA_IREAD(A+rnz*((i*N+j)*L), LA_begin,sizeof(DATA_T)*alen);
						LA = LA_begin;
						for (K = 0; K < L; K+= SIZE)
						{
							int off_up;
							if (K + SIZE > L - 1)
								off_up = 0;
							else
								off_up = gridmin(L - K - SIZE, halo);
							LEN = gridmin(L - K, SIZE);
							//WXL_DMA_NEW(dma_get, , COUNT);
							DMA_IREAD(B+(i*N+j)*L+K, LX[12]+halo, sizeof(DATA_T)*(LEN));
							if (cid == 0)
							{
								for (ii = 0; ii < 3; ii++)
								{
									if (should_dma[2+ii])
									{
										//WXL_DMA_NEW(dma_get, , COUNT);
										DMA_IREAD(X+i*N*L+j*L-2*N*L+ii*L+K, LX[2+ii]+halo, sizeof(DATA_T)*(LEN+off_up));
									}
									else
									{
										for (jj = 0; jj < LEN+halo; jj++) LX[2+ii][halo+jj] = 0;
									}
									if (should_dma[7+ii])
									{
										//WXL_DMA_NEW(dma_get, , COUNT);
										DMA_IREAD(X+i*N*L+j*L-1*N*L+ii*L+K, LX[7+ii]+halo, sizeof(DATA_T)*(LEN+off_up));
									}
									else
									{
										for (jj = 0; jj < LEN+halo; jj++) LX[7+ii][halo+jj] = 0;
									}
								}
							}
							if (ROW(CPE_ID) == 0||j == 0)
							{
								for (ii = 0; ii < 3; ii++)
								{
									for (jj = 0; jj < 2; jj++)
									{
										if (should_dma[ii*5+jj])
										{
											//WXL_DMA_NEW(dma_get, , COUNT);
											DMA_IREAD(X+i*N*L+j*L-2*N*L+ii*N*L-2*L+jj*L+K, LX[ii*5+jj]+halo, sizeof(DATA_T)*(LEN+off_up));
										}
										else
										{
											for (kk = 0; kk < LEN+halo; kk++) LX[ii*5+jj][halo+kk] = 0;
										}
										
									}
								}
							}
							DMA_WAIT_ALL;
							//dma_wait(&reply, COUNT);
							for (k = 0; k < LEN; k++)
							{
								// sprintf(testout, "%d: i %d j %d in k %d bi %d bj %d count %d!\n", id, i, j, k, bi, bj, count);
								// printf(testout);
								// if (K + k >= L - 2)
								// {
								// 	for (ii = 0; ii < 12; ii++) LX[ii][(count+2)%(HALO+SIZE)] = 0;
								// }
								if(LA == LA_end)
								{
									LA = LA_begin;
									alen = rnz * (ALEN < (L-K-k) ? ALEN : (L-K-k));
									// WXL_DMA_NEW(dma_get, ,  COUNT);
									// dma_wait(&reply, COUNT);
									DMA_READ(A+rnz*((i*N+j)*L+K+k), LA_begin, sizeof(DATA_T)*alen);
								}
								while (count>=(bi-halo)&&bi!=L+halo||count>=(bj-halo)&&bj!=L+halo)
								{
									// sprintf(testout, "%d waiting: bi %d bj %d in k!\n", id, bi, bj);
									// printf(testout);
									int overlap = LEN;
									if (K + SIZE < L) overlap -= halo;
									if (gr >= 0 && bi < (count+overlap) && !EMPTY_GETR())
									{
										GGETR2(LX[2][bii], LX[3][bii]);
										GGETR2(LX[4][bii], LX[7][bii]);
										GGETR2(LX[8][bii], LX[9][bii]);
										bii++;
										//if (bii >= HALO+SIZE) bii -= (HALO+SIZE);
										if (bii >= HALO+SIZE) bii -= SIZE;
										bi++;
									}
									if (gc >= 0 && bj < (count+overlap) && !EMPTY_GETC())
									{
										GGETC2(LX[0][bjj], LX[1][bjj]);
										GGETC2(LX[5][bjj], LX[6][bjj]);
										GGETC2(LX[10][bjj], LX[11][bjj]);
										bjj++;
										//if (bjj >= HALO+SIZE) bjj -= (HALO+SIZE);
										if (bjj >= HALO+SIZE) bjj -= SIZE;
										bj++;
									}
								}
								// if (K != 0)
								// {
								// 	sprintf(testout, "LA %.5f A %.5f Ap %.5f ALEN %d\n", LA[rnz-1], A[rnz*((i*N+j)*L+K)+rnz-1], A[rnz*((i*N+j)*L)+rnz-1], ALEN);
								// 	printf(testout);
								// }
								DATA_T result = 0;
								int iter;
								for (iter = 0; iter < rnz; iter++)
								{
									// if (col_id[iter] == 12)
									// 	result += LA[iter] * LX[12][k+2+z_offset[iter]];
									// else
									// 	result += LA[iter] * LX[col_id[iter]][(count+z_offset[iter])%(SIZE+HALO)];
									result += LA[iter] * LX[col_id[iter]][k+halo+z_offset[iter]];
									//DEBUG
									// if (i*N*L + j*L + K + k == 39)
									// {
									// 	int oi, oj, ok;
									// 	if (col_id[iter] < 5)
									// 	{
									// 		oi = -2;
									// 		oj = col_id[iter] - 2;
									// 	}
									// 	else if (col_id[iter] < 10)
									// 	{
									// 		oi = -1;
									// 		oj = col_id[iter] - 7;
									// 	}
									// 	else
									// 	{
									// 		oi = 0;
									// 		oj = col_id[iter] - 12;
									// 	}
									// 	ok = z_offset[iter];
									// 	printf("iter: %d, LX: %.5f X: %.5f\n", iter, LX[col_id[iter]][k+2+z_offset[iter]], X[(i*N+oi*N+j+oj)*L+K+k+z_offset[iter]]);
									// 	printf("LA %.5f A %.5f\n\n", LA[iter], A[rnz*((i*N+j)*L+K+k)+iter]);
									// }
								}
								// if (i*N*L + j*L + K + k == 39)
								// {
								// 	printf("bi %d bj %d count %d\n", bi, bj, count);
								// 	for (ii = 0; ii < LEN + HALO; ii++)
								// 		printf("%.4f ", LX[8][ii]);
								// 	printf("\n");
								// }
								LX[12][k+halo] = LX[12][k+halo] - result;
								LA += rnz;
								count++;
								//int other_z = (count - 1)%(HALO + SIZE);
								if (pr >= 0 && j > 1 && i < M - 1)
								{
									// GPUTR2(LX[5][other_z], LX[6][other_z], pr);
									// GPUTR2(LX[7][other_z], LX[10][other_z], pr);
									// GPUTR2(LX[11][other_z], LX[12][k+2], pr);
									GPUTR2(LX[5][k+halo], LX[6][k+halo], pr);
									GPUTR2(LX[7][k+halo], LX[10][k+halo], pr);
									GPUTR2(LX[11][k+halo], LX[12][k+halo], pr);
								}
								if (pc >= 0)
								{
									// GPUTC2(LX[1][other_z], LX[2][other_z], pc);
									// GPUTC2(LX[6][other_z], LX[7][other_z], pc);
									// GPUTC2(LX[11][other_z], LX[12][k+2], pc);
									GPUTC2(LX[1][k+halo], LX[2][k+halo], pc);
									GPUTC2(LX[6][k+halo], LX[7][k+halo], pc);
									GPUTC2(LX[11][k+halo], LX[12][k+halo], pc);
								}
							}
							DMA_IWRITE(X+(i*N+j)*L+K, LX[12]+halo, sizeof(DATA_T)*(LEN));
							DMA_WAIT_ALL;
							// WXL_DMA_NEW(dma_put, , COUNT);
							// dma_wait(&reply, COUNT);
							if (K + SIZE < L)
							{
								int LENtoBe = gridmin(L - K - SIZE, SIZE);
								for (ii = 0; ii <= 12; ii++)
								{
									for (jj = 0; jj < HALO; jj++)
										LX[ii][jj] = LX[ii][LEN+jj];
									for (jj = 0; jj < halo; jj++)
										LX[ii][LENtoBe+halo+jj] = 0;
								}
								// LX[12][0] = LX[12][LEN];
								// LX[12][1] = LX[12][LEN + 1];
							}
						}
					}
					else
					{
						// sprintf(testout, "%d: i %d j %d\n", id, i, j);
						// printf(testout);
						LX[12][0] = 0;
						for (K = 0; K < L; K+=SIZE)
						{
							LEN = gridmin(L - K, SIZE);
							int off_up;
							if (K + SIZE > L - 1)
									off_up = 0;
							else
									off_up = gridmin(L - K - SIZE, halo);
							if (true)
							{
								for (ii = 0; ii < 3; ii++)
								{
									for (jj = 0; jj < LEN+halo; jj++) LX[2+ii][halo+jj] = 0;
									for (jj = 0; jj < LEN+halo; jj++) LX[7+ii][halo+jj] = 0;
								}
							}
							if (ROW(CPE_ID) == 0)
							{
								for (ii = 0; ii < 3; ii++)
								{
									for (jj = 0; jj < 2; jj++)
									{
										if (should_dma[ii*5+jj])
										{
											// WXL_DMA_NEW(dma_get, , COUNT);
											DMA_IREAD(X+i*N*L+j*L-2*N*L+ii*N*L-2*L+jj*L+K, LX[ii*5+jj]+halo, sizeof(DATA_T)*(LEN+off_up));
										}
										else
										{
											for (kk = 0; kk < LEN+halo; kk++) LX[ii*5+jj][halo+kk] = 0;
										}
										
									}
								}
							}
							// dma_wait(&reply, COUNT);
							DMA_WAIT_ALL;
							for (k = 0; k < LEN; k++)
							{
								// sprintf(testout, "%d: i %d j %d in k %d bi %d bj %d count %d!\n", id, i, j, k, bi, bj, count);
								// printf(testout);
								while (count>=bi||count>=bj)
								{
									// sprintf(testout, "%d waiting: bi %d bj %d in k!\n", id, bi, bj);
									// printf(testout);
									int overlap = LEN;
									if (K + SIZE < L) overlap -= halo;
									if (gr >= 0 && bi < (count+overlap) && !EMPTY_GETR())
									{
										GGETR2(LX[2][bii], LX[3][bii]);
										GGETR2(LX[4][bii], LX[7][bii]);
										GGETR2(LX[8][bii], LX[9][bii]);
										bii++;
										if (bii >= halo+SIZE) bii -= SIZE;
										bi++;
									}
									if (gc >= 0 && bj < (count+overlap) && !EMPTY_GETC())
									{
										GGETC2(LX[0][bjj], LX[1][bjj]);
										GGETC2(LX[5][bjj], LX[6][bjj]);
										GGETC2(LX[10][bjj], LX[11][bjj]);
										bjj++;
										if (bjj >= halo+SIZE) bjj -= SIZE;
										bj++;
									}
								}
								count++;
								// sprintf(testout, "i %d j %d k %d putting row\n", i, j, k);
								// printf(testout);
								if (pr >= 0 && j > 1 && i < M - 1)
								{
									// GPUTR2(LX[5][other_z], LX[6][other_z], pr);
									// GPUTR2(LX[7][other_z], LX[10][other_z], pr);
									// GPUTR2(LX[11][other_z], LX[12][0], pr);
									GPUTR2(LX[5][k+halo], LX[6][k+halo], pr);
									GPUTR2(LX[7][k+halo], LX[10][k+halo], pr);
									GPUTR2(LX[11][k+halo], LX[12][0], pr);
								}
								// sprintf(testout, "i %d j %d k %d putting pc %d\n", i, j, k, pc);
								// printf(testout);
								if (pc >= 0 && j <= N)
								{
									// GPUTC2(LX[1][other_z], LX[2][other_z], pc);
									// GPUTC2(LX[6][other_z], LX[7][other_z], pc);
									// GPUTC2(LX[11][other_z], LX[12][0], pc);
									GPUTC2(LX[1][k+halo], LX[2][k+halo], pc);
									GPUTC2(LX[6][k+halo], LX[7][k+halo], pc);
									GPUTC2(LX[11][k+halo], LX[12][0], pc);
								}
								// sprintf(testout, "i %d j %d k %d finish putting\n", i, j, k);
								// printf(testout);
							}
							// if (K + SIZE < L)
							// {
							// 	int LENtoBe = gridmin(L - K - SIZE, SIZE);
							// 	for (ii = 0; ii <= 12; ii++)
							// 	{
							// 		for (jj = 0; jj < HALO/2; jj++)
							// 			LX[ii][jj] = LX[ii][LEN+jj];
							// 		for (jj = 0; jj < HALO/2; jj++)
							// 			LX[ii][LENtoBe+HALO/2+jj] = 0;
							// 	}
							// 	// LX[12][0] = LX[12][LEN];
							// 	// LX[12][1] = LX[12][LEN + 1];
							// }
						}
					}
					// sprintf(testout, "%d: i %d j %d done\n", id, i, j);
					// printf(testout);
				}
				SYNC_ALL;
				
			}
		}
	}
}

void FUNCNAME(strsv_125_backward_kernel)(DATA_T *X, const DATA_T *A, const DATA_T *B, int M, int N, int L, int rnz, int *coid, int *zoff, DATA_T *_ptr, int HALO)
{
    int id = -1, rid = -1, cid = -1;
	int gr = -1, gc = -1, pr = -1, pc = -1;
	int ps = -1, gs = -1;
	//Init id information
	{
		int ids[16];
		Cal_ID_125(ids);
		id  = ids[0];
		rid = ids[1];
		cid = ids[2];
		pr  = ids[3];
		gr  = ids[4];
		pc  = ids[5];
		gc  = ids[6];
		ps  = ids[7];
		gs  = ids[8];
	}
    #define MATRIX_BUFFER 1024
	int pos_dj[12] = {-2, -1, 0, 1, 2, -2, -1, 0, 1, 2, -2, -1};
	int pos_di[12] = {-2, -2, -2, -2, -2, -1, -1, -1, -1, -1, 0, 0};
	int should_dma[12];
	int not_from_reg[12];
	//Begin Cal
    {
		//char testout[128];
        DATA_T *LX[13], *LAA, *LA_begin, *LA_end;
		DATA_T *LA;
        //int *LAI, *LAJ;
		int col_id[rnz];
		int z_offset[rnz];
		DATA_T *ptr = _ptr;
		// volatile int reply = 0;
		// volatile int COUNT = 0;
		int i = 0,j = 0,k = 0,K = 0;
		int bi = 0, bj = 0, bk = 0, bii = 0, bjj = 0;
		int count = 0, zcount = 0;
		// dma_desc dma_get;
		// dma_desc dma_put;
		// WXL_DMA_SET_NOSIZE(&dma_get, DMA_GET, &reply);
		// WXL_DMA_SET_NOSIZE(&dma_put, DMA_PUT, &reply);
		DMA_DECL_DESC(READ_WRITE);
		//Init LX pointer
		int LEN = gridmin(L, MLEN);
		int SIZE = LEN;
		int halo = HALO / 2;
        
		int ALEN = (MAX_GRID_SIZE*8/sizeof(DATA_T)-13*(LEN+HALO))/rnz;
		// WXL_DMA_NEW(dma_get, , COUNT);
		// dma_wait(&reply, COUNT);
		// WXL_DMA_NEW(dma_get, , COUNT);
		// dma_wait(&reply, COUNT);
		DMA_IREAD(coid, col_id, sizeof(int)*rnz);
		DMA_IREAD(zoff, z_offset, sizeof(int)*rnz);
		DMA_WAIT_ALL;
        
		int ii, jj, kk;
		for (ii = 0; ii < 13; ii++)
		{
			LX[ii] = (DATA_T*)ptr;
			for (jj = 0; jj < LEN + HALO; jj++)
				LX[ii][jj] = 0;
			ptr += (SIZE + HALO);
		}
		LA_begin = ptr; ptr += rnz * ALEN; LA_end = ptr;
		int is = (M + COLS - 1) / COLS;
		int js;
		for (i = cid; i < cid + is * COLS; i+=COLS)
		{
			int width = gridmin(M - (i - cid), COLS);
			int right_off;
			if (width <= 4)
			{
				right_off = 8 - (width - 1) * 2;
				if (N <= right_off)
					js = 1;
				else
					js = (N - right_off + ROWS - 1) / ROWS + 1;
			}
			else
			{
				right_off = 8 - (width - 4) * 2;
				if (N <= right_off)
					js = 2;
				else
					js = (N - right_off + ROWS - 1) / ROWS + 2;
			}
			for (j = ROW(CPE_ID) - 2 * cid; j < ROW(CPE_ID) - 2 * cid + js * ROWS; j+=ROWS)
			{
				count = bi = bj = halo;
				bii = bjj = SIZE + halo - 1;
				for (ii = 0; ii <= 12; ii++)
					for (jj = 0; jj < halo; jj++)
					{
						LX[ii][SIZE + halo + jj] = 0;
					}
				if (j >= 0 && j <= N + 1 && i < M)
				{
					for (ii = 0; ii < 12; ii++)
					{
						int oi = i + pos_di[ii];
						int oj = j + pos_dj[ii];
						if (oi >= 0 && oi < M && oj >= 0 && oj < N) should_dma[ii] = 1; else should_dma[ii] = 0;
					}
					if (COL(CPE_ID) == 0||j >= N) bi += L;
					if (ROW(CPE_ID) == 0||j == 0) bj += L;
					if (j < N)
					{
						int alen = rnz * (ALEN < L ? ALEN : L);
						//WXL_DMA_NEW(dma_get, , COUNT);
						DMA_IREAD(A+rnz*(M*N*L-(i*N+j)*L)-alen, LA_begin,sizeof(DATA_T)*alen);
						LA = LA_begin + alen -rnz;
						for (K = 0; K < L; K+= SIZE)
						{
							int off_up;
							if (K + SIZE > L - 1)
								off_up = 0;
							else
								off_up = gridmin(L - K - SIZE, halo);
							LEN = gridmin(L - K, SIZE);
							int buf_off = SIZE - LEN + halo;
							//WXL_DMA_NEW(dma_get, , COUNT);
							DMA_IREAD(B+M*N*L-(i*N+j)*L-K-LEN, LX[12]+buf_off, sizeof(DATA_T)*(LEN));
							if (cid == 0)
							{
								for (ii = 0; ii < 3; ii++)
								{
									if (should_dma[2+ii])
									{
										//WXL_DMA_NEW(dma_get, , COUNT);
										DMA_IREAD(X+M*N*L-(i*N*L+j*L-2*N*L+ii*L+K)-LEN-off_up, LX[2+ii]+buf_off-off_up, sizeof(DATA_T)*(LEN+off_up));
									}
									else
									{
										for (jj = 0; jj < SIZE+halo; jj++) LX[2+ii][jj] = 0;
									}
									if (should_dma[7+ii])
									{
										//WXL_DMA_NEW(dma_get, , COUNT);
										DMA_IREAD(X+M*N*L-(i*N*L+j*L-1*N*L+ii*L+K)-LEN-off_up, LX[7+ii]+buf_off-off_up, sizeof(DATA_T)*(LEN+off_up));
									}
									else
									{
										for (jj = 0; jj < SIZE+halo; jj++) LX[7+ii][jj] = 0;
									}
								}
							}
							if (ROW(CPE_ID) == 0||j == 0)
							{
								for (ii = 0; ii < 3; ii++)
								{
									for (jj = 0; jj < 2; jj++)
									{
										if (should_dma[ii*5+jj])
										{
											//WXL_DMA_NEW(dma_get, , COUNT);
											DMA_IREAD(X+M*N*L-(i*N*L+j*L-2*N*L+ii*N*L-2*L+jj*L+K)-LEN-off_up, LX[ii*5+jj]+buf_off-off_up, sizeof(DATA_T)*(LEN+off_up));
										}
										else
										{
											for (kk = 0; kk < SIZE+halo; kk++) LX[ii*5+jj][kk] = 0;
										}			
									}
								}
							}
							//dma_wait(&reply, COUNT);
							DMA_WAIT_ALL;
							for (k = LEN - 1; k >= 0; k--)
							{
								int pass = LEN - 1 - k;
								if(LA == LA_begin - rnz)
								{
									alen = rnz * (ALEN < (L-K-pass) ? ALEN : (L-K-pass));
									LA = LA_begin + alen - rnz;
									DMA_READ(A+(M*N*L-(i*N+j)*L-K-pass)*rnz-alen, LA_begin, sizeof(DATA_T)*alen);
									//WXL_DMA_NEW(dma_get, ,  COUNT);
									//dma_wait(&reply, COUNT);
								}
								while (count>=(bi-halo)&&bi!=L+halo||count>=(bj-halo)&&bj!=L+halo)
								{
									int overlap = LEN;
									if (K + SIZE < L) overlap -= halo;
									if (gr >= 0 && bi < (count+overlap) && !EMPTY_GETR())
									{
										GGETR2(LX[2][bii], LX[3][bii]);
										GGETR2(LX[4][bii], LX[7][bii]);
										GGETR2(LX[8][bii], LX[9][bii]);
										bii--;
										if (bii < 0) bii += SIZE;
										bi++;
									}
									if (gc >= 0 && bj < (count+overlap) && !EMPTY_GETC())
									{
										GGETC2(LX[0][bjj], LX[1][bjj]);
										GGETC2(LX[5][bjj], LX[6][bjj]);
										GGETC2(LX[10][bjj], LX[11][bjj]);
										bjj--;
										if (bjj < 0) bjj += SIZE;
										bj++;
									}
								}
								DATA_T result = 0;
								DATA_T para = 1.0;
								int iter;
								for (iter = 0; iter < rnz; iter++)
								{
									if (col_id[iter] == 12 && z_offset[iter] == 0)
										para = LA[iter];
									else
										result += LA[iter] * LX[col_id[iter]][k+buf_off+z_offset[iter]];
								}
								LX[12][k+buf_off] = (LX[12][k+buf_off] - result) / para;
								LA -= rnz;
								count++;
								//int other_z = (count - 1)%(HALO + SIZE);
								if (pr >= 0 && j > 1 && i < M - 1)
								{
									GPUTR2(LX[5][k+buf_off], LX[6][k+buf_off], pr);
									GPUTR2(LX[7][k+buf_off], LX[10][k+buf_off], pr);
									GPUTR2(LX[11][k+buf_off], LX[12][k+buf_off], pr);
								}
								if (pc >= 0)
								{
									GPUTC2(LX[1][k+buf_off], LX[2][k+buf_off], pc);
									GPUTC2(LX[6][k+buf_off], LX[7][k+buf_off], pc);
									GPUTC2(LX[11][k+buf_off], LX[12][k+buf_off], pc);
								}
							}
							DMA_IWRITE(X+M*N*L-(i*N+j)*L-K-LEN, LX[12]+buf_off, sizeof(DATA_T)*(LEN));
							DMA_WAIT_ALL;
							//WXL_DMA_NEW(dma_put, , COUNT);
							//dma_wait(&reply, COUNT);
							if (K + SIZE < L)
							{
								int LENtoBe = gridmin(L - K - SIZE, SIZE);
								for (ii = 0; ii <= 12; ii++)
								{
									for (jj = 0; jj < HALO; jj++)
										LX[ii][LEN+jj] = LX[ii][jj];
									for (jj = 0; jj < halo; jj++)
										LX[ii][SIZE-LENtoBe+halo-1-jj] = 0;
								}
							}
						}
					}
					else
					{
						LX[12][0] = 0;
						for (K = 0; K < L; K+=SIZE)
						{
							LEN = gridmin(L - K, SIZE);
							int buf_off = SIZE - LEN + halo;
							int off_up;
							if (K + SIZE > L - 1)
									off_up = 0;
							else
									off_up = gridmin(L - K - SIZE, halo);
							if (true)
							{
								for (ii = 0; ii < 3; ii++)
								{
									for (jj = 0; jj < SIZE+halo; jj++) LX[2+ii][jj] = 0;
									for (jj = 0; jj < SIZE+halo; jj++) LX[7+ii][jj] = 0;
								}
							}
							if (ROW(CPE_ID) == 0)
							{
								for (ii = 0; ii < 3; ii++)
								{
									for (jj = 0; jj < 2; jj++)
									{
										if (should_dma[ii*5+jj])
										{
											DMA_IREAD(X+M*N*L-(i*N*L+j*L-2*N*L+ii*N*L-2*L+jj*L+K)-LEN-off_up, LX[ii*5+jj]+buf_off-off_up, sizeof(DATA_T)*(LEN+off_up));
											//WXL_DMA_NEW(dma_get, , COUNT);
										}
										else
										{
											for (kk = 0; kk < SIZE+halo; kk++) LX[ii*5+jj][kk] = 0;
										}
									}
								}
							}
							DMA_WAIT_ALL;
							//dma_wait(&reply, COUNT);
							for (k = LEN - 1; k >= 0; k--)
							{
								while (count>=bi||count>=bj)
								{
									int overlap = LEN;
									if (K + SIZE < L) overlap -= halo;
									if (gr >= 0 && bi < (count+overlap) && !EMPTY_GETR())
									{
										GGETR2(LX[2][bii], LX[3][bii]);
										GGETR2(LX[4][bii], LX[7][bii]);
										GGETR2(LX[8][bii], LX[9][bii]);
										bii--;
										if (bii < halo) bii += SIZE;
										bi++;
									}
									if (gc >= 0 && bj < (count+overlap) && !EMPTY_GETC())
									{
										GGETC2(LX[0][bjj], LX[1][bjj]);
										GGETC2(LX[5][bjj], LX[6][bjj]);
										GGETC2(LX[10][bjj], LX[11][bjj]);
										bjj--;
										if (bjj < halo) bjj += SIZE;
										bj++;
									}
								}
								count++;
								if (pr >= 0 && j > 1 && i < M - 1)
								{
									GPUTR2(LX[5][k+buf_off], LX[6][k+buf_off], pr);
									GPUTR2(LX[7][k+buf_off], LX[10][k+buf_off], pr);
									GPUTR2(LX[11][k+buf_off], LX[12][0], pr);
								}
								if (pc >= 0 && j <= N)
								{
									GPUTC2(LX[1][k+buf_off], LX[2][k+buf_off], pc);
									GPUTC2(LX[6][k+buf_off], LX[7][k+buf_off], pc);
									GPUTC2(LX[11][k+buf_off], LX[12][0], pc);
								}
							}
						}
					}
				}
				SYNC_ALL;
				
			}
		}
	}
}

void SLAVE_FUNCNAME(forward_125_slave)(void *_ptr)
{
        DATA_T data[MAX_GRID_SIZE*8/sizeof(DATA_T)];
        // volatile int reply = 0;
        // volatile int COUNT = 0;
        Info info;
        // dma_desc dma_get;
        // WXL_DMA_SET_NOSIZE(&dma_get, DMA_GET, &reply);
        // WXL_DMA_NEW(dma_get, , COUNT);
        // dma_wait(&reply, COUNT);
		DMA_DECL_DESC(READ);
		DMA_READ(_ptr, &info, sizeof(Info));
        #ifdef DATA_TYPE_S
        swSparse_s_strsv_125_forward_kernel(info.X, info.A, info.B, info.M, info.N, info.L, info.rnz, info.cid, info.zoff, (DATA_T*)data, info.HALO);
        #endif
        #ifdef DATA_TYPE_D
        swSparse_d_strsv_125_forward_kernel(info.X, info.A, info.B, info.M, info.N, info.L, info.rnz, info.cid, info.zoff, (DATA_T*)data, info.HALO);
        #endif
        #ifdef DATA_TYPE_C
        swSparse_c_strsv_125_forward_kernel(info.X, info.A, info.B, info.M, info.N, info.L, info.rnz, info.cid, info.zoff, (DATA_T*)data, info.HALO);
        #endif
        #ifdef DATA_TYPE_Z
        swSparse_z_strsv_125_forward_kernel(info.X, info.A, info.B, info.M, info.N, info.L, info.rnz, info.cid, info.zoff, (DATA_T*)data, info.HALO);
        #endif
        return;
}

void SLAVE_FUNCNAME(backward_125_slave)(void *_ptr)
{
        DATA_T data[MAX_GRID_SIZE*8/sizeof(DATA_T)];
        // volatile int reply = 0;
        // volatile int COUNT = 0;
        Info info;
        // dma_desc dma_get;
        // WXL_DMA_SET_NOSIZE(&dma_get, DMA_GET, &reply);
        // WXL_DMA_NEW(dma_get, _ptr, &info, sizeof(Info), COUNT);
        // dma_wait(&reply, COUNT);
		DMA_DECL_DESC(READ);
		DMA_READ(_ptr, &info, sizeof(Info));
        #ifdef DATA_TYPE_S
        swSparse_s_strsv_125_backward_kernel(info.X, info.A, info.B, info.M, info.N, info.L, info.rnz, info.cid, info.zoff, (DATA_T*)data, info.HALO);
        #endif
        #ifdef DATA_TYPE_D
        swSparse_d_strsv_125_backward_kernel(info.X, info.A, info.B, info.M, info.N, info.L, info.rnz, info.cid, info.zoff, (DATA_T*)data, info.HALO);
        #endif
        #ifdef DATA_TYPE_C
        swSparse_c_strsv_125_backward_kernel(info.X, info.A, info.B, info.M, info.N, info.L, info.rnz, info.cid, info.zoff, (DATA_T*)data, info.HALO);
        #endif
        #ifdef DATA_TYPE_Z
        swSparse_z_strsv_125_backward_kernel(info.X, info.A, info.B, info.M, info.N, info.L, info.rnz, info.cid, info.zoff, (DATA_T*)data, info.HALO);
        #endif
        return;
}

#undef MLEN
