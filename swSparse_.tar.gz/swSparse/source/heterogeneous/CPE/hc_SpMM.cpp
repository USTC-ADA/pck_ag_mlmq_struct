#include <cmath>
#include "internal/crts.hpp"
#include "internal/kernel_args.h"
#include "internal/memory.h"
#include "internal/templates.h"
#include "internal/CPE_utils.h"
#include "internal/swSpMV.h"
#include "internal/spmv_param.h"
#include "internal/spmv_param_cpe.h"
#include "internal/CPE_communicator.h"
#include "swSparse_base.h"

__thread_local volatile athread_rply_t reply_reduce;

using namespace swSparse;

//#define Count_Slave

namespace swSparse {

    //基于SWCOO格式的SW从核SpMM函数,基本流程同SpMV,只对不同部分做额外注释
    template<typename DATA_T>
    NOINLINE void spmm_kernel(DATA_T *_b, const DATA_T *_x, SpMV_Slave_Info *info, int ldx, int ldy, int parallel_num){

        int rid = ROW(CPE_ID);
        int cid = COL(CPE_ID);
        int id = cid + rid *  8;
        spmv_params<sizeof(DATA_T)> params;
        volatile int reply = 0;
        int COUNT = 0;
        dma_mode dma_get;
        dma_mode dma_put;
        //根据X向量的数量,开辟B和X向量的LDM空间
        __attribute__((aligned(32))) DATA_T b[parallel_num][params.BUFFER_B];
        __attribute__((aligned(32))) DATA_T b_tmp[parallel_num][params.BUFFER_B];
        __attribute__((aligned(32))) DATA_T x[parallel_num][params.BUFFER_X];
        __attribute__((aligned(32))) DATA_T value[params.BUFFER_NNZ];
        __attribute__((aligned(32))) DATA_T b_reduce[params.BUFFER_B];

        intv16  row_col16[params.BUFFER_I];
        SpMV_Slave_TASK tasks[params.BUFFER_TASK];
        //DATA_RLC *vb = (DATA_RLC*)b;
        DATA_T tmp;
        DATA_T *ratio = (DATA_T*)info->ratio;
        DATA_T alpha,beta;

        int    *row_col = (int*)row_col16;
        int   *_row_col = info->row_idx;
        DATA_T *_value  = (DATA_T*)(info->value);
        int i, j, k, t, p;
        int row_offset_record = -1;
        int size_b  = info->tile_size;
        //int size_vb = info->tile_size * Size_RLC ;
        int result = 0;


        rst_rd_communicator<doublev8,params.BUFFER_B / 8> rd_spmv(id);

        DMA_DECL_DESC(READ_WRITE);

        #ifdef Count_Slave
            unsigned long dma_start,dma_end,dmab_start,dmab_end,dmat_start,dmat_end,calc_start,calc_end,reduce_start,reduce_end,total_start,total_end;
            unsigned long dma_time,dmab_time,dmat_time,calc_time,reduce_time,total_time;
            long long nnz_tot,x_tot;
            dma_time = 0;
            dmab_time = 0;
            dmat_time = 0;
            calc_time = 0;
            reduce_time = 0;
            total_time = 0;
            nnz_tot = 0;
            x_tot = 0;
            total_start = CRTS_stime_cycle();
        #endif 

        alpha = ratio[0];
        beta  = ratio[1];

        for(t = 0; t < info->ntasks; t += params.BUFFER_TASK){
            
            #ifdef Count_Slave
                dmat_start = CRTS_stime_cycle();
            #endif

            int task_size = min(params.BUFFER_TASK, info->ntasks - t);
            DMA_READ(info->tasks + t, tasks, task_size * sizeof(SpMV_Slave_TASK));

            #ifdef Count_Slave
                dmat_end = CRTS_stime_cycle();
                dmat_time += dmat_end - dmat_start;
            #endif


            i = 0;    
            while(i < task_size){
                if(tasks[i].nnz_length > params.BUFFER_NNZ){     
                    int row_offset = tasks[i].row_offset;
                    int row_length = tasks[i].row_length;
                    int col_offset = tasks[i].col_offset;
                    int col_length = tasks[i].col_length;
                    int nnz_offset = tasks[i].nnz_offset;
                    int nnz_length = tasks[i].nnz_length;
                    int reduce_root = tasks[i].reduce_root + rid * 8;
                    int reduce_ncpe = tasks[i].reduce_ncpe;
                    bool reduce_flag = tasks[i].reduce_flag;
                    bool job         = tasks[i].job;

                    if (job){
                        if(row_offset_record != row_offset){
                            row_offset_record = row_offset;
                            for (p = 0 ; p < parallel_num; p++)
                                for(j = 0; j < size_b; j += 1) b[p][j] = 0;
                        }
                        
                        #ifdef Count_Slave
                            dma_start = CRTS_stime_cycle();
                        #endif

                        //依次读取每个X向量的值,并额外计算偏移
                        for (p = 0 ; p < parallel_num ; p++){
                            DMA_IREAD(_x + p * ldx + col_offset, x[p], col_length*sizeof(DATA_T));
                        }
                            // DMA_IREAD(_x + col_offset, x, col_length*sizeof(DATA_T));

                        #ifdef Count_Slave
                            dma_end = CRTS_stime_cycle();
                            dma_time += dma_end - dma_start;
                            x_tot += col_length;
                        #endif

                        for(j = 0; j < nnz_length; j += params.BUFFER_NNZ){
                            int size = min(nnz_length-j, params.BUFFER_NNZ);

                            #ifdef Count_Slave
                                dma_start = CRTS_stime_cycle();
                            #endif                      

                            DMA_IREAD(_row_col + nnz_offset + j, row_col, size*sizeof(int));
                            DMA_READ (_value   + nnz_offset + j, value,   size*sizeof(DATA_T));
                        
                            #ifdef Count_Slave
                                dma_end = CRTS_stime_cycle();
                                dma_time += dma_end - dma_start;
                                nnz_tot += size;
                                calc_start = CRTS_stime_cycle();
                            #endif

                            //依次计算和每个向量X的SpMV结果
                            for (p = 0 ; p < parallel_num ; p++){
                                if (is_one(alpha)){
                                    for(k = 0; k < size; k ++)
                                        b[p][row_col[k]>>COL_IDX_DIGITS] += value[k] * x[p][row_col[k]&COL_IDX_MASK];
                                }
                                else{
                                for(k = 0; k < size; k ++)
                                        b[p][row_col[k]>>COL_IDX_DIGITS] += alpha * value[k] * x[p][row_col[k]&COL_IDX_MASK]; 
                                }
                            }

                            #ifdef Count_Slave
                                calc_end = CRTS_stime_cycle();
                                calc_time += calc_end - calc_start;
                            #endif
                        }
                    }
                    else{
                        row_offset_record = row_offset;
                        for (p = 0 ; p < parallel_num; p++)
                            for(j = 0; j < size_b; j += 1) b[p][j] = 0;
                    }
                    
                    if (reduce_flag){

                        #ifdef Count_Slave
                            reduce_start = CRTS_stime_cycle();
                        #endif 

                        //FUNCNAME(col_sum)(rid,reduce_root,reduce_ncpe,vb,(size_vb+3)/4);    
                        //FUNCNAME(col_sum)(rid,reduce_root,reduce_ncpe,vb,(size_b+VECTOR_LEN-1)/VECTOR_LEN);
                        
                        for (p = 0 ; p < parallel_num; p++){
                            if (id == reduce_root){
                                int vid;
                                int rj;
                                for (vid = id - reduce_ncpe + 1; vid < id; vid ++){
                                    CRTS_ssync_peer(vid);
                                    mem_fence(); 
                                    CRTS_rma_get(b_reduce, size_b*sizeof(DATA_T) , vid , b[p] , &reply_reduce);
                                    mem_fence(); 
                                    for (rj = 0; rj < size_b; rj++) b[p][rj] += b_reduce[rj];
                                    mem_fence(); 
                                    CRTS_ssync_peer(vid);
                                }
                            }
                            else{
                                CRTS_ssync_peer(reduce_root);
                                // CRTS_rma_put(b, size_b*sizeof(DATA_T) , reduce_root , b_reduce , &reply_reduce);
                                CRTS_rma_wait_value (&reply_reduce, 1);
                                CRTS_ssync_peer(reduce_root);  
                            }
                        }
                        
                        //rd_spmv.reduce_sum(reduce_root,1,reduce_ncpe,reinterpret_cast<doublev8*>(b[p]),(size_b+8-1)/8);

                        #ifdef Count_Slave
                            reduce_end = CRTS_stime_cycle();
                            reduce_time += reduce_end - reduce_start;
                            dmab_start = CRTS_stime_cycle();
                        #endif

                        //依次写回每个B向量的值,并额外计算偏移
                        if (id == reduce_root){
                            if (is_zero(beta)){

                                for (p = 0 ; p < parallel_num ; p++){
                                    DMA_WRITE(_b + p * ldy + row_offset_record, b[p], row_length*sizeof(DATA_T));
                                }   
                            }
                            else{
                                for (p = 0 ; p < parallel_num ; p++){
                                    DMA_READ(_b + p * ldy + row_offset_record, b_tmp[p], row_length*sizeof(DATA_T));

                                    for (j = 0 ; j < row_length ; j++){
                                        b[p][j] += beta * b_tmp[p][j];
                                    }
                                    DMA_WRITE(_b + p * ldy + row_offset_record, b[p], row_length*sizeof(DATA_T));
                                }

                            }
                        }

                        #ifdef Count_Slave
                            dmab_end = CRTS_stime_cycle();
                            dmab_time += dmab_end - dmab_start;
                        #endif

                    }                     
                    i ++;
                }
                else
                {   
                    int sub_task_size = 1;
                    int sub_nnz_length = tasks[i].nnz_length;
                    while((i+sub_task_size) < task_size && sub_nnz_length + tasks[i+sub_task_size].nnz_length < params.BUFFER_NNZ){
                        sub_nnz_length += tasks[i+sub_task_size].nnz_length;
                        sub_task_size ++;
                    }

                    #ifdef Count_Slave
                        dma_start = CRTS_stime_cycle();
                    #endif

                    if (sub_nnz_length){
                        DMA_IREAD(_row_col + tasks[i].nnz_offset, row_col, sub_nnz_length*sizeof(int));
                        DMA_READ (_value   + tasks[i].nnz_offset, value,   sub_nnz_length*sizeof(DATA_T));
                    }

                    #ifdef Count_Slave
                        dma_end = CRTS_stime_cycle();
                        dma_time += dma_end - dma_start;
                        nnz_tot += sub_nnz_length;
                    #endif

                    int target_i = i + sub_task_size;
                    int nnz_offset_record = 0;
                    for(i; i < target_i; i ++){
                        int row_offset = tasks[i].row_offset;
                        int row_length = tasks[i].row_length;
                        int col_offset = tasks[i].col_offset;
                        int col_length = tasks[i].col_length;
                        int nnz_offset = tasks[i].nnz_offset;
                        int nnz_length = tasks[i].nnz_length;
                        int reduce_root = tasks[i].reduce_root + rid * 8;
                        int reduce_ncpe = tasks[i].reduce_ncpe;
                        bool reduce_flag = tasks[i].reduce_flag;
                        bool job         = tasks[i].job;

                        if (job){  
                            if(row_offset_record != row_offset){
                                row_offset_record = row_offset;
                                for (p = 0 ; p < parallel_num; p++)
                                    for(j = 0; j < size_b; j += 1) b[p][j] = 0;
                            }

                            #ifdef Count_Slave
                                dma_start = CRTS_stime_cycle();
                            #endif
                            for (p = 0 ; p < parallel_num ; p++){
                                DMA_READ(_x + p * ldx + col_offset, x[p], col_length*sizeof(DATA_T));
                            }

                            #ifdef Count_Slave
                                dma_end = CRTS_stime_cycle();
                                dma_time += dma_end - dma_start;
                                x_tot += col_length;
                                calc_start = CRTS_stime_cycle();
                            #endif


                            for (p = 0 ; p < parallel_num ; p++){

                                if ( is_one(alpha) ){
                                    for(j = nnz_offset_record; j < nnz_offset_record + nnz_length; j ++)                         
                                        b[p][row_col[j]>>COL_IDX_DIGITS] += value[j] * x[p][row_col[j]&COL_IDX_MASK];
                                }
                                else{
                                    for(j = nnz_offset_record; j < nnz_offset_record + nnz_length; j ++)                         
                                        b[p][row_col[j]>>COL_IDX_DIGITS] += alpha * value[j] * x[p][row_col[j]&COL_IDX_MASK];
                                }
                            }

                            

                            #ifdef Count_Slave
                                calc_end = CRTS_stime_cycle();
                                calc_time += calc_end - calc_start;
                            #endif

                            nnz_offset_record += nnz_length;
                        }
                        else{
                            row_offset_record = row_offset;
                            for (p = 0 ; p < parallel_num; p++)
                                for(j = 0; j < size_b; j += 1) b[p][j] = 0;
                        }


                            
                        if (reduce_flag){

                            #ifdef Count_Slave
                                reduce_start = CRTS_stime_cycle();
                            #endif

                            //FUNCNAME(col_sum)(rid,reduce_root,reduce_ncpe,vb,(size_vb+3)/4);
                            //FUNCNAME(col_sum)(rid,reduce_root,reduce_ncpe,vb,(size_b+VECTOR_LEN-1)/VECTOR_LEN);

                            for (p = 0 ; p < parallel_num; p++){
                                if (id == reduce_root){
                                    int vid;
                                    int rj;
                                    for (vid = id - reduce_ncpe + 1; vid < id; vid ++){
                                        CRTS_ssync_peer(vid);
                                        mem_fence(); 
                                        CRTS_rma_get(b_reduce, size_b*sizeof(DATA_T) , vid , b[p] , &reply_reduce);
                                        mem_fence(); 
                                        for (rj = 0; rj < size_b; rj++) b[p][rj] += b_reduce[rj];
                                        mem_fence(); 
                                        CRTS_ssync_peer(vid);
                                    }
                                }
                                else{
                                    CRTS_ssync_peer(reduce_root);
                                    // CRTS_rma_put(b, size_b*sizeof(DATA_T) , reduce_root , b_reduce , &reply_reduce);
                                    CRTS_rma_wait_value (&reply_reduce, 1);
                                    CRTS_ssync_peer(reduce_root);  
                                }
                            }
                            
                            //rd_spmv.reduce_sum(reduce_root,1,reduce_ncpe,reinterpret_cast<doublev8*>(b[p]),(size_b+8-1)/8);

                            #ifdef Count_Slave
                                reduce_end = CRTS_stime_cycle();
                                reduce_time += reduce_end - reduce_start;
                                dmab_start = CRTS_stime_cycle();
                            #endif

                            if (id == reduce_root){
                                if (is_zero(beta)){

                                    for (p = 0 ; p < parallel_num ; p++){
                                        DMA_WRITE(_b + p * ldy + row_offset_record, b[p], row_length*sizeof(DATA_T));
                                    }   
                                }
                                else{
                                    for (p = 0 ; p < parallel_num ; p++){
                                        DMA_READ(_b + p * ldy + row_offset_record, b_tmp[p], row_length*sizeof(DATA_T));

                                        for (j = 0 ; j < row_length ; j++){
                                            b[p][j] += beta * b_tmp[p][j];
                                        }
                                        DMA_WRITE(_b + p * ldy + row_offset_record, b[p], row_length*sizeof(DATA_T));
                                    }

                                }
                            }

                            #ifdef Count_Slave
                                dmab_end = CRTS_stime_cycle();
                                dmab_time += dmab_end - dmab_start;
                            #endif

                        }



                
                    }
                }           
            } // end of while i
        }// end of for t

        #ifdef Count_Slave
            char sout[256];
            total_end = CRTS_stime_cycle();
            total_time = total_end - total_start;
            sprintf(sout,"[%d %d] %d %d %d %d %d %d %d %d\n",rid,cid,total_time , dma_time,dmab_time,dmat_time,reduce_time, calc_time,nnz_tot,x_tot);
            printf(sout);
        #endif

        return; 
    }

    //从核入口函数,转存参数信息并调用计算函数
    template<typename DATA_T>
    NOINLINE void spmm_cpe(void *p_args){
        
        int rid = ROW(CPE_ID);
        int cid = COL(CPE_ID);
        int id = rid + cid * 8;
        //DATA_T *b , *x;
        spmv_kernel_arg_t<DATA_T> args;
        DMA_DECL_DESC(READ_WRITE);
        DMA_READ(p_args, &args, sizeof(spmv_kernel_arg_t<DATA_T>));

        SpMV_Slave_Info info = args.infos[rid][cid];
        DATA_T *x = (DATA_T*)(info.x);
        DATA_T *b = (DATA_T*)(info.b);
        int vector_col = args.infos[rid][cid].vector_cols;
        int ldx = args.infos[rid][cid].ldx;
        int ldy = args.infos[rid][cid].ldy;
        int i , element_num;
        int parallel_num = 2;

        //根据X的所剩的向量个数,动态调整此次计算多少个X向量
        for (i = 0 ; i < vector_col ; i += parallel_num){
            element_num = min(parallel_num , vector_col - i);
            while (parallel_num > element_num) parallel_num >>= 1; 
            spmm_kernel<DATA_T>(b + i*ldy, x + i*ldx, &info, ldx, ldy, parallel_num);
        }
       

        return;
    }


CPE_TEMPLATE_KERNEL(spmm_cpe, CACHE_IGNORE)

}
