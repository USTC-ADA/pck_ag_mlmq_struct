#include <limits>
#include <crts.h>
#include "internal/kernel_args.h"
#include "internal/memory.h"
#include "internal/templates.h"
#include "internal/CPE_utils.h"
#include "internal/CPE_blas_kernels.h"
#include "internal/CPE_simd_math.h"
#include "internal/sptrf_common.h"   // equilibration routines

namespace swSparse {
template<typename DATA_T>
struct elemwise_params {
    static constexpr const Int chunk = 8192;
    static constexpr const Int chunk_2 = 8192;
    static_assert(sizeof(DATA_T) * chunk < 131072);
};
template<>
struct elemwise_params<double> {
    static constexpr const Int chunk = 8192;
    static constexpr const Int chunk_2 = 4096;
    static_assert(sizeof(double) * chunk < 131072);
};
template<>
struct elemwise_params<DComplex> {
    static constexpr const Int chunk = 4096;
    static constexpr const Int chunk_2 = 4096;
    static_assert(sizeof(DComplex) * chunk < 131072);
};

template<typename DATA_T>
inline constexpr const Int chunk = elemwise_params<DATA_T>::chunk;

template<typename REAL_T>
NOINLINE void ewise_exp_kernel(void *p_args) {  // not vectorized
    exponential<REAL_T> element_wise;
    ewise_exp_arg_t<REAL_T> args;
    DMA_DECL_DESC(READ_WRITE);
    DMA_READ(p_args, &args, sizeof(ewise_exp_arg_t<REAL_T>));

    SIMD_ALIGN REAL_T local_value[chunk<REAL_T>];
    Int size = ceiling_sra(args.n, 5);
    Int tid = memory_channel_mapping(CPE_ID), id = tid & 31, which = tid >> 5;
    Int begin = size * id;
    Int end = min(args.n, begin + size);
    REAL_T* target = (which == 0) ? args.rscale : args.cscale;

    for(Int i = begin; i < end; i += chunk<REAL_T>) {
        Int len = min(chunk<REAL_T>, end - i);
        DMA_READ(target+i, local_value, len * sizeof(REAL_T));
        element_wise.exp(local_value, len);
        DMA_SWRITE(target+i, local_value, len * sizeof(REAL_T));
    }
    DMA_WAIT_ALL;
}

template<typename DATA_T>
NOINLINE void ewise_scale_kernel(void *p_args) {
    constexpr Int chunk_size = elemwise_params<DATA_T>::chunk_2;
    ewise_scale_arg_t<DATA_T> args;
    scale_kernel_t<DATA_T> sc;
    DMA_DECL_DESC(READ_WRITE);
    DMA_READ(p_args, &args, sizeof(ewise_scale_arg_t<DATA_T>));

    SIMD_ALIGN DATA_T local_value[chunk_size];
    SIMD_ALIGN real_t<DATA_T> local_scale[chunk_size];
    Int size = ceiling_sra(args.n, 6);
    Int id = memory_channel_mapping(CPE_ID);
    Int begin = size * id;
    Int end = min(args.n, begin + size);

    for(Int i = begin; i < end; i += chunk_size) {
        Int len = min(chunk_size, end - i);
        DMA_IREAD(args.src +i, local_value, len * sizeof(DATA_T));
        DMA_READ(args.scale+i, local_scale, len * sizeof(real_t<DATA_T>));
        sc.ewise_scale(local_value, local_scale, len);
        DMA_SWRITE(args.dst+i, local_value, len * sizeof(DATA_T));
    }
    DMA_WAIT_ALL;
}

template<typename DATA_T, typename Conj>
NOINLINE void scale_kernel(void *p_args) {
    scale_arg_t<DATA_T> args;
    scale_kernel_t<DATA_T> scale_kernel;
    DMA_DECL_DESC(READ_WRITE);
    DMA_READ(p_args, &args, sizeof(scale_arg_t<DATA_T>));

    DATA_T alpha = args.alpha;
    SIMD_ALIGN DATA_T local_value[chunk<DATA_T>];
    Int size = ceiling_sra(args.n, 6);
    Int id = memory_channel_mapping(CPE_ID);
    Int begin = size * id;
    Int end = min(args.n, begin + size);

    for(Int i = begin; i < end; i += chunk<DATA_T>) {
        Int len = min(chunk<DATA_T>, end - i);
        DMA_READ(args.src+i, local_value, len * sizeof(DATA_T));
        scale_kernel.template scale<Conj>(local_value, len, alpha);
        DMA_SWRITE(args.dst+i, local_value, len * sizeof(DATA_T));
    }
    DMA_WAIT_ALL;
}

template<typename DATA_T>
NOINLINE void dense_scale_kernel(void *p_args) {
    dense_scale_arg_t<DATA_T> args;
    scale_kernel_t<DATA_T> scale_kernel;

    DMA_DECL_DESC(READ_WRITE);
    DMA_READ(p_args, &args, sizeof(dense_scale_arg_t<DATA_T>));

    DATA_T alpha = args.alpha;
    SIMD_ALIGN DATA_T local_value[chunk<DATA_T>];
    const DATA_T *src = args.src;
    DATA_T *dst = args.dst;
    Int id = CPE_ID, n = args.n, m = args.n_vec;
    Int group_j_shift = 6;
    for(Int s = 1; s < 6; ++s) {
        if(args.n_vec < (2 << s)) {
            group_j_shift = s;
            break;
        }
    }
    Int group_i_shift = 6 - group_j_shift;
    Int group_i_size = 1 << group_i_shift, group_j_size = 1 << group_j_shift;
    Int group_i = id & (group_i_size - 1), group_j = id >> group_i_shift;
    Int qi = n >> group_i_shift, ri = n & (group_i_size - 1);
    Int i_begin = qi * group_i + ((group_i < ri) ? group_i : ri), i_end = i_begin + qi + ((group_i < ri) ? 1 : 0);
    Int qj = m >> group_j_shift, rj = m & (group_j_size - 1);
    Int j_begin = qj * group_j + ((group_j < rj) ? group_j : rj), j_end = j_begin + qj + ((group_j < rj) ? 1 : 0);
    
    for(Int j = j_begin; j < j_end; ++ j) {
        for(Int i = i_begin; i < i_end; i += chunk<DATA_T>) {
            Int len = min(chunk<DATA_T>, i_end - i);
            DMA_READ(src + i + j * args.ldx, local_value, len * sizeof(DATA_T));
            scale_kernel.template scale<not_conjugate<DATA_T>>(local_value, len, alpha);
            DMA_SWRITE(dst + i + j * args.ldy, local_value, len * sizeof(DATA_T));
        }
    }
    DMA_WAIT_ALL;
}

NOINLINE void index_shift_kernel(void *p_args) {
    index_shift_arg_t args;
    DMA_DECL_DESC(READ_WRITE);
    DMA_READ(p_args, &args, sizeof(index_shift_arg_t));

    SIMD_ALIGN Int local_value[chunk<Int>];
    Int size = ceiling_sra(args.n, 6);
    Int id = memory_channel_mapping(CPE_ID);
    Int begin = size * id;
    Int end = min(args.n, begin + size);
    Int i, j;

    for(i = begin; i < end; i += chunk<Int>) {
        Int len = min(chunk<Int>, end - i);
        DMA_READ(args.in_index+i, local_value, len * sizeof(Int));
        shift(local_value, len, args.delta);
        DMA_SWRITE(args.out_index+i, local_value, len * sizeof(Int));
    }
    DMA_WAIT_ALL;
}

template<typename DATA_T>
struct perm_params {
    static constexpr const Int chunk_size = 8192;
    static_assert(sizeof(DATA_T) * chunk_size < 131072);
};
template<>
struct perm_params<DComplex> {
    static constexpr const Int chunk_size = 4096;
    static_assert(sizeof(DComplex) * chunk_size < 131072);
};

NOINLINE void id_perm_kernel(void *p_args) {
    constexpr const Int chunk_size = perm_params<dummy_t>::chunk_size;
    id_perm_args_t args;
    DMA_READ_NODESC(p_args, &args, sizeof(args));
    Int local_perm[chunk_size];
    Int size = args.n >> 6;
    Int id = memory_channel_mapping(CPE_ID);
    Int begin = size * id;
    Int end = (id == 63) ? args.n : (begin + size);
    Int i, j;

    DMA_DECL_DESC(READ_WRITE);

    for(i = begin; i < end; i += chunk_size) {
        Int len = min(chunk_size, end - i);
        for(j = 0; j < len; ++j) {
            local_perm[j] = i + j;
        }
        DMA_WRITE(args.perm+i, local_perm, len * sizeof(Int));
    }
}

template<typename DATA_T>
NOINLINE void gather_local(Int n, const DATA_T *table, DATA_T *local_dst, const Int *local_idx) {
    for(Int i = 0; i < n; ++i) {
        local_dst[i] = table[local_idx[i]];   // gld, need cache
    }
}


template<typename DATA_T>
NOINLINE void gather_by_indices_(Int n, const DATA_T* table, DATA_T* dst, const Int* indices) {
    constexpr const Int chunk_size = perm_params<DATA_T>::chunk_size;
    Int local_perm[chunk_size];
    DATA_T local_value[chunk_size];
    Int size = n >> 6;
    Int id = memory_channel_mapping(CPE_ID);
    Int begin = size * id;
    Int end = (id == 63) ? n : (begin + size);
    Int i, j;

    DMA_DECL_DESC(READ_WRITE);

    for(i = begin; i < end; i += chunk_size) {
        Int len = min(chunk_size, end - i);
        // comment 20230415: `dst` may be alias of `indices`, but access different `i`
        DMA_READ(indices+i, local_perm, len * sizeof(Int));
        gather_local(len, table, local_value, local_perm);
        DMA_IWRITE(dst+i, local_value, len * sizeof(DATA_T));
    }
    DMA_WAIT_ALL;
}

template<typename DATA_T>
NOINLINE static void gather_kernel(void *p_args) {
    gather_arg_t<DATA_T> args;
    DMA_READ_NODESC(p_args, &args, sizeof(args));
    gather_by_indices_(args.n, args.src, args.dst, args.indices);
}

template void gather_local<Int>(Int n, const Int *table, Int *dst, const Int *index);
template void gather_by_indices_<Int>(Int n, const Int* table, Int* dst, const Int* indices);

CPE_CONCRETE_KERNEL(id_perm_kernel, CACHE_IGNORE)
CPE_TEMPLATE_KERNEL_REUSE_S_FOR_I(gather_kernel, CACHE_128KB)
CPE_CONCRETE_KERNEL(index_shift_kernel, CACHE_IGNORE)
CPE_TEMPLATE_KERNEL(dense_scale_kernel, CACHE_IGNORE)
CPE_TEMPLATE_KERNEL(ewise_scale_kernel, CACHE_IGNORE)
WITH_CACHE_IGNORE(swSparse_s_ewise_exp_kernel, ewise_exp_kernel<float>)
WITH_CACHE_IGNORE(swSparse_d_ewise_exp_kernel, ewise_exp_kernel<double>)
WITH_CACHE_IGNORE(swSparse_s_scale_kernel, (scale_kernel<float,not_conjugate<float>>))
WITH_CACHE_IGNORE(swSparse_d_scale_kernel, (scale_kernel<double,not_conjugate<double>>))
WITH_CACHE_IGNORE(swSparse_c_scale_kernel, (scale_kernel<SComplex,not_conjugate<SComplex>>))
WITH_CACHE_IGNORE(swSparse_z_scale_kernel, (scale_kernel<DComplex,not_conjugate<DComplex>>))
WITH_CACHE_IGNORE(swSparse_c_scale_conj_kernel, (scale_kernel<SComplex,conjugate<SComplex>>))
WITH_CACHE_IGNORE(swSparse_z_scale_conj_kernel, (scale_kernel<DComplex,conjugate<DComplex>>))

}

