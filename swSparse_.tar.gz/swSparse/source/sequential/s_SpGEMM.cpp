#include "swSparse_blas.h"
#include "internal/rename.h"
#include "internal/templates.h"
#include "internal/memory.h"
#include "internal/debug.h"
#include "internal/utils.h"
#include "internal/reorder.h"
#include "internal/spblas_common.h"
#include "internal/spgemm_param.h"
#include "internal/algorithm_heap.h"

namespace swSparse {

typedef struct {
    Int a_position, b_position;
} state_t;

#define adjust_priority_queue_min(length, pq) adjust_heap_min_down(0, length, pq, heap_element_t::key())
#define init_priority_queue_min(length, pq) init_heap_min(length, pq, heap_element_t::key())

// for general beta
inline constexpr const Int a_pos_d = -1;

#define MAX_CHUNK_NUM 4096
#define PRINT_OVERFLOW \
    DEBUG_PRINTF("number of chunks too many: please set a bigger `spgemm_params::chunk_size_shift` in internal/spgemm_param.h\n")

template<typename DATA_T, typename ConjA, typename ConjB, typename Alpha, typename Beta>
ErrorStatus gemm_heap( \
    Alpha alpha, Beta beta, Int m, Int n, Int k, \
    MatrixCSRC *a, MatrixCSRC *b, MatrixCSRC *d, MatrixCSRC *c) {
    Int i, j, l, p, q;
    heap_element_t *heap;
    state_t *state;
    int64_t ub_total = 0;
    Int *offsets;
    Int *indices;
    DATA_T *values;
    Int *a_row_off = a->offsets, *a_col_idx = a->indices;
    Int *b_row_off = b->offsets, *b_col_idx = b->indices;
    DATA_T *a_values = VALUES(a, DATA_T), *b_values = VALUES(b, DATA_T);
    Int a_nnz = a_row_off[m];
    Int b_nnz = b_row_off[n];
    Int a_max_rnz = 0, ubrmax = 0;

    offsets = (Int*)swSparse_malloc(sizeof(Int) * (m+1));
    IF_ERR(offsets == nullptr) {
        return MALLOC_ERROR;
    }
    
    for(i = 0; i < m; ++i) {
        Int ub_row = 0;
        for(p = a_row_off[i]; p < a_row_off[i+1]; ++p) {
            l = a_col_idx[p];
            ub_row += b_row_off[l+1] - b_row_off[l];
        }
        ub_row = min(ub_row, n);
        ubrmax = max(ub_row, ubrmax);
        ub_total += ub_row;
        a_max_rnz = max(a_max_rnz, a_row_off[i+1] - a_row_off[i]);
    }

    const Int chunk_cap = ceil_pow_2(max(chunk_size<DATA_T> * 128, max(ubrmax, a_nnz + b_nnz)));
    Int *idx_chunks[MAX_CHUNK_NUM], *idx_temp;
    DATA_T *value_chunks[MAX_CHUNK_NUM], *value_temp;
    Int current_c = 0, current_p = 0, heap_size_max = a_max_rnz + 1;

    heap = (heap_element_t*)swSparse_malloc((sizeof(heap_element_t) + sizeof(state_t)) * heap_size_max);
    IF_ERR(heap == nullptr) {
        return clean_return(MALLOC_ERROR, offsets);
    }
    state = reinterpret_cast<state_t*>(heap + heap_size_max);

    idx_temp = (Int *)swSparse_malloc(sizeof(Int) * ubrmax);
    if(idx_temp == nullptr) {
        return clean_return(MALLOC_ERROR, heap, offsets);
    }
    value_temp = (DATA_T *)swSparse_malloc(sizeof(DATA_T) * ubrmax);
    if(value_temp == nullptr) {
        return clean_return(MALLOC_ERROR, heap, offsets, idx_temp);
    }

    idx_chunks[0] = (Int *)swSparse_malloc(sizeof(Int) * chunk_cap);
    if(idx_chunks[0] == nullptr) {
        return clean_return(MALLOC_ERROR, heap, offsets, idx_temp, value_temp);
    }
    value_chunks[0] = (DATA_T *)swSparse_malloc(sizeof(DATA_T) * chunk_cap);
    if(value_chunks[0] == nullptr) {
        return clean_return(MALLOC_ERROR, heap, offsets, idx_chunks[0], idx_temp, value_temp);
    }

    offsets[0] = 0;
    for(i = 0; i < m; ++i) {
        const Int remain = chunk_cap - current_p;
        Int *out_idx = (remain >= ubrmax) ? (idx_chunks[current_c] + current_p) : idx_temp;
        DATA_T *out_val = (remain >= ubrmax) ? (value_chunks[current_c] + current_p) : value_temp;
        Int nz_row = 0;
        Int offset = a_row_off[i];
        Int heap_size = 0, a_rnz = a_row_off[i+1] - offset;
        Int current_col_idx = -1;
        DATA_T current_value = DATA_T(0);
        for(p = 0; p < a_rnz; ++p) {
            Int a_pos = offset + p;
            Int b_row = a_col_idx[a_pos];
            /* B row not empty */
            if(b_row_off[b_row] < b_row_off[b_row+1]) {
                state[heap_size].a_position = a_pos;
                state[heap_size].b_position = b_row_off[b_row];
                heap[heap_size].index      = b_col_idx[b_row_off[b_row]];
                heap[heap_size].which      = heap_size;
                heap_size++;
            }
        }
        if constexpr(!is_zero_t<Beta>) {
            if(d->offsets[i] < d->offsets[i + 1]) {
                state[heap_size].a_position = a_pos_d;
                state[heap_size].b_position = d->offsets[i];
                heap[heap_size].index       = d->indices[d->offsets[i]];
                heap[heap_size].which       = heap_size;
                heap_size++;
            }
        }
        init_priority_queue_min(heap_size, heap);

        while(heap_size > 0) {
            /* take the top of the heap */
            Int which = heap[0].which;
            p = state[which].a_position;
            q = state[which].b_position;
            j = a_col_idx[p];
            l = heap[0].index;

            DATA_T a_val = ConjA::value(a_values[p]);
            DATA_T b_val = ConjB::value(b_values[q]);
            Int row_end = b_row_off[j+1];

            if constexpr(!is_zero_t<Beta>) {
                if(p == a_pos_d) {
                    a_val = beta;
                    b_val = VALUES(d, DATA_T)[q];
                    l = d->indices[q];
                    row_end = d->offsets[i+1];
                } else {
                    a_val = alpha * a_val;
                }
            } else {
                a_val = alpha * a_val;
            }

            /* insert the element into the result */
            if(l > current_col_idx) {
                if(current_col_idx >= 0) {
                    out_idx[nz_row] = current_col_idx;
                    out_val[nz_row] = current_value;
                    ++nz_row;
                }
                current_col_idx = l;
                current_value = a_val * b_val;
            } else {
                current_value += a_val * b_val;
            }

            /* update the heap */
            ++q;
            if(q < row_end) {
                Int *ptr = b_col_idx;
                if constexpr(! is_zero_t<Beta>) {
                    if(p == a_pos_d) {
                        ptr = d->indices;
                    }
                }
                state[which].b_position = q;
                heap[0].index = ptr[q];
            } else {
                heap[0] = heap[--heap_size];
            }
            
            adjust_priority_queue_min(heap_size, heap);
        }

        if(current_col_idx >= 0) {
            out_idx[nz_row] = current_col_idx;
            out_val[nz_row] = current_value;
            ++nz_row;
        }
        if(nz_row < remain) {
            if(out_idx == idx_temp) {
                swSparse_memcpy(idx_chunks[current_c] + current_p, idx_temp, sizeof(Int) * nz_row);
                swSparse_memcpy(value_chunks[current_c] + current_p, value_temp, sizeof(DATA_T) * nz_row);
            }
            current_p += nz_row;
        } else {  // allocate new chunk
            Int c_ = current_c++, p_ = current_p;
            current_p = nz_row - remain;
            
            IF_ERR(current_c >= MAX_CHUNK_NUM) {
                PRINT_OVERFLOW;
                clean_chunks(idx_chunks, current_c);
                clean_chunks(value_chunks, current_c);
                return clean_return(MALLOC_ERROR, heap, offsets, idx_temp, value_temp);
            }
            idx_chunks[current_c] = (Int *)swSparse_malloc(sizeof(Int) * chunk_cap);
            IF_ERR(idx_chunks[current_c] == nullptr) {
                clean_chunks(idx_chunks, current_c);
                clean_chunks(value_chunks, current_c);
                return clean_return(MALLOC_ERROR, heap, offsets, idx_temp, value_temp);
            }
            value_chunks[current_c] = (DATA_T *)swSparse_malloc(sizeof(DATA_T) * chunk_cap);
            IF_ERR(value_chunks[current_c] == nullptr) {
                clean_chunks(idx_chunks, current_c + 1);
                clean_chunks(value_chunks, current_c);
                return clean_return(MALLOC_ERROR, heap, offsets, idx_temp, value_temp);
            }
            swSparse_memcpy(idx_chunks[c_] + p_, idx_temp, sizeof(Int) * remain);
            swSparse_memcpy(value_chunks[c_] + p_, value_temp, sizeof(DATA_T) * remain);
            swSparse_memcpy(idx_chunks[current_c], idx_temp + remain, sizeof(Int) * current_p);
            swSparse_memcpy(value_chunks[current_c], value_temp + remain, sizeof(DATA_T) * current_p);
        } 
        offsets[i+1] = offsets[i] + nz_row;
    }
    free_all(idx_temp, value_temp, heap);
    
    indices = pack_chunks<Int>(idx_chunks, current_c, chunk_cap, current_p);
    IF_ERR(indices == nullptr) {
        if(current_c != 0 && current_p != 0) {
            clean_chunks<Int>(idx_chunks, current_c + 1);
            clean_chunks<DATA_T>(value_chunks, current_c + 1);
        }
        return clean_return(MALLOC_ERROR, offsets);
    }
    values = pack_chunks<DATA_T>(value_chunks, current_c, chunk_cap, current_p);
    IF_ERR(values == nullptr) {
        if(current_c != 0 && current_p != 0) {
            clean_chunks<DATA_T>(value_chunks, current_c + 1);
        }
        return clean_return(MALLOC_ERROR, offsets);
    }

    c->offsets = offsets;
    c->values = values;
    c->indices = indices;
    c->ordered = true;
    return SWSPARSE_SUCCESS;
}

#define HASH_SCALE 107

template<typename DATA_T, typename ConjA, typename ConjB, typename Alpha, typename Beta>
ErrorStatus gemm_hash( \
    Alpha alpha, Beta beta, Int m, Int n, Int k, \
    MatrixCSRC *a, MatrixCSRC *b, MatrixCSRC *d, MatrixCSRC *c) {
    Int i, j, l, p, q, h;
    Int *hash_idx;
    DATA_T *hash_values;
    Int *upper_bounds;
    int64_t ub_total = 0;
    Int *offsets;
    Int *indices;
    DATA_T *values;
    Int *a_row_off = a->offsets, *a_col_idx = a->indices;
    Int *b_row_off = b->offsets, *b_col_idx = b->indices;
    DATA_T *a_values = VALUES(a, DATA_T), *b_values = VALUES(b, DATA_T);
    Int a_nnz = a_row_off[m], b_nnz = b_row_off[n], ubrmax = 0;
    

    offsets = (Int*)swSparse_malloc(sizeof(Int) * (m+1));
    IF_ERR(offsets == nullptr) {
        return MALLOC_ERROR;
    }
    upper_bounds = offsets + 1;
    
    for(i = 0; i < m; ++i) {
        Int ub_row = 0;
        for(p = a_row_off[i]; p < a_row_off[i+1]; ++p) {
            l = a_col_idx[p];
            ub_row += b_row_off[l+1] - b_row_off[l];
        }
        ub_row = min(ub_row, n);
        upper_bounds[i] = ub_row;
        ubrmax = max(ub_row, ubrmax);
        ub_total += upper_bounds[i];
    }

    const Int chunk_cap = ceil_pow_2(max(chunk_size<DATA_T> * 128, max(ubrmax, a_nnz + b_nnz)));
    //const Int chunk_cap_mask = chunk_cap - 1;
    Int *idx_chunks[MAX_CHUNK_NUM];
    DATA_T *value_chunks[MAX_CHUNK_NUM];
    Int current_c = 0, current_p = 0;

    hash_values = (DATA_T*)swSparse_malloc((sizeof(Int) + sizeof(DATA_T)) * n);
    IF_ERR(hash_values == nullptr) {
        return clean_return(MALLOC_ERROR, offsets);
    }
    hash_idx = (Int*)((void*)(hash_values + n));

    idx_chunks[0] = (Int *)swSparse_malloc(sizeof(Int) * chunk_cap);
    if(idx_chunks[0] == nullptr) {
        return clean_return(MALLOC_ERROR, hash_values, offsets);
    }
    value_chunks[0] = (DATA_T *)swSparse_malloc(sizeof(DATA_T) * chunk_cap);
    if(value_chunks[0] == nullptr) {
        return clean_return(MALLOC_ERROR, hash_values, offsets, idx_chunks[0]);
    }

    offsets[0] = 0;
    for(i = 0; i < m; ++i) {
        Int cap = upper_bounds[i]; /* hash table capacity */
        Int nz_row = 0;
        for(p = 0; p < cap; ++p) {
            hash_idx[p] = -1;
        }
        for(p = a_row_off[i]; p < a_row_off[i+1]; ++p) {
            l = a_col_idx[p];
            for(q = b_row_off[l]; q < b_row_off[l+1]; ++q) {
                j = b_col_idx[q];
                h = (j * HASH_SCALE) % cap;
                while((hash_idx[h] != -1) && (hash_idx[h] != j)) {
                    h = (h == cap - 1) ? 0 : (h + 1);
                }
                if(hash_idx[h] == -1) {
                    hash_idx[h] = j;
                    hash_values[h] = alpha * ConjA::value(a_values[p]) * ConjB::value(b_values[q]);
                    ++ nz_row;
                } else {
                    hash_values[h] += alpha * ConjA::value(a_values[p]) * ConjB::value(b_values[q]);
                }
            }
        }
        if constexpr(!is_zero_t<Beta>) {
            for(p = d->offsets[i]; p < d->offsets[i+1]; ++p) {
                j = d->indices[p];
                h = (j * HASH_SCALE) % cap;
                while((hash_idx[h] != -1) && (hash_idx[h] != j)) {
                    h = (h == cap - 1) ? 0 : (h + 1);
                }
                if(hash_idx[h] == -1) {
                    hash_idx[h] = j;
                    hash_values[h] = beta * VALUES(d, DATA_T)[p];
                    ++ nz_row;
                } else {
                    hash_values[h] += beta * VALUES(d, DATA_T)[p];
                }
            }
        }
        offsets[i+1] = offsets[i] + nz_row;

        if(current_p + nz_row < chunk_cap) {
            for(p = 0; p < cap; ++p) {
                if(hash_idx[p] != -1) {
                    idx_chunks[current_c][current_p] = hash_idx[p];
                    value_chunks[current_c][current_p] = hash_values[p];
                    ++current_p;
                }
            }
        } else {
            for(p = 0; p < cap; ++p) {
                if(hash_idx[p] != -1) {
                    idx_chunks[current_c][current_p] = hash_idx[p];
                    value_chunks[current_c][current_p] = hash_values[p];

                    ++current_p;
                    /* expand */
                    if(current_p == chunk_cap) {
                        ++current_c;
                        current_p = 0;
                                
                        IF_ERR(current_c >= MAX_CHUNK_NUM) {
                            PRINT_OVERFLOW;
                            clean_chunks<Int>(idx_chunks, current_c);
                            clean_chunks<DATA_T>(value_chunks, current_c);
                            return clean_return(MALLOC_ERROR, hash_values, offsets);
                        }
                        idx_chunks[current_c] = (Int *)swSparse_malloc(sizeof(Int) * chunk_cap);
                        if(idx_chunks[current_c] == nullptr) {
                            clean_chunks<Int>(idx_chunks, current_c);
                            clean_chunks<DATA_T>(value_chunks, current_c);
                            return clean_return(MALLOC_ERROR, hash_values, offsets);
                        }
                        
                        value_chunks[current_c] = (DATA_T *)swSparse_malloc(sizeof(DATA_T) * chunk_cap);
                        IF_ERR(value_chunks[current_c] == nullptr) {
                            clean_chunks<Int>(idx_chunks, current_c + 1);
                            clean_chunks<DATA_T>(value_chunks, current_c);
                            return clean_return(MALLOC_ERROR, hash_values, offsets);
                        }
                    }
                }
            }
        }
    }
    swSparse_free(hash_values);
    
    indices = pack_chunks<Int>(idx_chunks, current_c, chunk_cap, current_p);
    IF_ERR(indices == nullptr) {
        if(current_c != 0 && current_p != 0) {
            clean_chunks<Int>(idx_chunks, current_c + 1);
            clean_chunks<DATA_T>(value_chunks, current_c + 1);
        }
        return clean_return(MALLOC_ERROR, offsets);
    }
    values = pack_chunks<DATA_T>(value_chunks, current_c, chunk_cap, current_p);
    IF_ERR(values == nullptr) {
        if(current_c != 0 && current_p != 0) {
            clean_chunks<DATA_T>(value_chunks, current_c + 1);
        }
        return clean_return(MALLOC_ERROR, offsets);
    }

    c->offsets = offsets;
    c->values = values;
    c->indices = indices;
    c->ordered = false;
    return SWSPARSE_SUCCESS;
}

template<typename DATA_T>
ErrorStatus gemm_csr( \
    DATA_T alpha, DATA_T beta, Int m, Int n, Int k, \
    MatrixCSRC *a, MatrixCSRC *b, MatrixCSRC *d, MatrixCSRC *c, Bool a_conj, Bool b_conj) {
    /* 
     * ensure order for heap method
     * not required for hash methods
     */
    if(!a->ordered) {
        ErrorStatus ret = sort_elements(m, a->offsets, a->indices, VALUES(a, DATA_T));
        IF_ERR(ret != SWSPARSE_SUCCESS) {
            return ret;
        } else {
            a->ordered = true;
        }
    }
    if(!b->ordered) {
        ErrorStatus ret = sort_elements(m, b->offsets, b->indices, VALUES(b, DATA_T));
        IF_ERR(ret != SWSPARSE_SUCCESS) {
            return ret;
        } else {
            b->ordered = true;
        }
    }

    using conj = conjugate<DATA_T>;
    using noconj = not_conjugate<DATA_T>;

    if(is_zero(beta)) {
        if(a_conj) {
            if(b_conj) {
                return gemm_heap<DATA_T, conj, conj>(alpha, zero_t(), m, n, k, a, b, d, c);
            } else {
                return gemm_heap<DATA_T, conj, noconj>(alpha, zero_t(), m, n, k, a, b, d, c);
            }
        } else {
            if(b_conj) {
                return gemm_heap<DATA_T, noconj, conj>(alpha, zero_t(), m, n, k, a, b, d, c);
            } else {
                return gemm_heap<DATA_T, noconj, noconj>(alpha, zero_t(), m, n, k, a, b, d, c);
            }
        }
    } else {
        if(a_conj) {
            if(b_conj) {
                return gemm_heap<DATA_T, conj, conj>(alpha, beta, m, n, k, a, b, d, c);
            } else {
                return gemm_heap<DATA_T, conj, noconj>(alpha, beta, m, n, k, a, b, d, c);
            }
        } else {
            if(b_conj) {
                return gemm_heap<DATA_T, noconj, conj>(alpha, beta, m, n, k, a, b, d, c);
            } else {
                return gemm_heap<DATA_T, noconj, noconj>(alpha, beta, m, n, k, a, b, d, c);
            }
        }
    }
}

template ErrorStatus gemm_csr<float>(float alpha, float beta, Int m, Int n, Int k, \
    MatrixCSRC *a, MatrixCSRC *b, MatrixCSRC *d, MatrixCSRC *c, Bool a_conj, Bool b_conj);
template ErrorStatus gemm_csr<double>(double alpha, double beta, Int m, Int n, Int k, \
    MatrixCSRC *a, MatrixCSRC *b, MatrixCSRC *d, MatrixCSRC *c, Bool a_conj, Bool b_conj);
template ErrorStatus gemm_csr<SComplex>(SComplex alpha, SComplex beta, Int m, Int n, Int k, \
    MatrixCSRC *a, MatrixCSRC *b, MatrixCSRC *d, MatrixCSRC *c, Bool a_conj, Bool b_conj);
template ErrorStatus gemm_csr<DComplex>(DComplex alpha, DComplex beta, Int m, Int n, Int k, \
    MatrixCSRC *a, MatrixCSRC *b, MatrixCSRC *d, MatrixCSRC *c, Bool a_conj, Bool b_conj);

} // namespace swSparse