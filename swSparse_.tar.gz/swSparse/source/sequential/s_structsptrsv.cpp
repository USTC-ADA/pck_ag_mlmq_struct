#include "swSparse_blas.h"
#include "internal/rename.h"
#include "internal/memory.h"
#include "internal/debug.h"
#include "internal/spblas_common.h"

#define DATA_TYPE_S
#include "s_structsptrsv.inl"
#undef DATA_TYPE_S
#define DATA_TYPE_D
#include "s_structsptrsv.inl"
#undef DATA_TYPE_D


