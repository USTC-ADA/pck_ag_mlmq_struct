#include "swSparse_blas.h"
#include "internal/rename.h"
#include "internal/memory.h"
#include "internal/debug.h"
#include "internal/spblas_common.h"
#include <stdio.h>

namespace swSparse {

template<typename DATA_T>
ErrorStatus
struct_ilu0_nonsymm(const DATA_T *a, DATA_T *l, DATA_T *u, swSparseInt dim_0, swSparseInt dim_1, swSparseInt dim_2, int nnz, const swSparseInt (*elem_pos)[3])
{
	int i, j, k;
	int ii, jj;
	int oi, oj, ok;
	int ti, tj, tk;
	int lnz, rnz;
	int M = dim_0, N = dim_1, L = dim_2;
	const DATA_T (*A)[nnz] = (const DATA_T (*)[nnz])a;

	int v[7][7][7];
	for (i = 0; i < 7; i++)
	for (j = 0; j < 7; j++)
	for (k = 0; k < 7; k++)
	{
		v[i][j][k] = -1;
	}
	for (i = 0; i < nnz; i++)
	{
		oi = elem_pos[i][0] + 3;
		oj = elem_pos[i][1] + 3;
		ok = elem_pos[i][2] + 3;
		v[oi][oj][ok] = i;
	}

	//get lnz
	lnz = 0;
	for (lnz = 0; lnz < nnz; lnz++)
	{
		oi = elem_pos[lnz][0];
		oj = elem_pos[lnz][1];
		ok = elem_pos[lnz][2];
		if (oi * 100 + oj * 10 + ok >= 0) break;
	}
	rnz = nnz - lnz;

	DATA_T rbuf[nnz];
	for (i = 0; i < M; i++)
	for (j = 0; j < N; j++)
	for (k = 0; k < L; k++)
	{
		int offset = i*N*L + j*L + k;
		for (ii = 0; ii < nnz; ii++)
		{
			rbuf[ii] = A[offset][ii];
		}
		for (ii = 0; ii < lnz; ii++)
		{
			oi = elem_pos[ii][0];
			oj = elem_pos[ii][1];
			ok = elem_pos[ii][2];
			ti = oi + i;
			tj = oj + j;
			tk = ok + k;
			if (ti >= 0 && ti < M && tj >= 0 && tj < N && tk >= 0 && tk < L)
			{
				int u_pos = (ti*N*L + tj*L + tk) * rnz;
				rbuf[ii] /= u[u_pos];
				for (jj = 1; jj < rnz; jj++)
				{
					int temp = lnz + jj;
					ti = oi + 3 + elem_pos[temp][0];
					tj = oj + 3 + elem_pos[temp][1];
					tk = ok + 3 + elem_pos[temp][2];
					if (ti >= 0 && ti < 7 && tj >= 0 && tj < 7 && tk >= 0 && tk < 7 && v[ti][tj][tk] != -1)
					{
						rbuf[v[ti][tj][tk]] -= rbuf[ii] * u[u_pos + jj];
					}
				}
			}
		}
		for (ii = 0; ii < lnz; ii++)
		{
			l[offset * lnz + ii] = rbuf[ii];
		}
		for (jj = 0; jj < rnz; jj++)
		{
			u[offset * rnz + jj] = rbuf[lnz + jj];
		}
	}
	return SWSPARSE_SUCCESS; 
}

template<typename DATA_T>
ErrorStatus
struct_ilu0_symm(const DATA_T *a, DATA_T *l, DATA_T *u, swSparseInt dim_0, swSparseInt dim_1, swSparseInt dim_2, int rnz, const swSparseInt (*elem_pos)[3])
{
	int i, j, k;
	int ii, jj;
	int oi, oj, ok;
	int ti, tj, tk;
	int lnz, nnz;
	int M = dim_0, N = dim_1, L = dim_2;
	const DATA_T (*A)[rnz] = (const DATA_T (*)[rnz])a;

	int v[7][7][7];
	for (i = 0; i < 7; i++)
	for (j = 0; j < 7; j++)
	for (k = 0; k < 7; k++)
	{
		v[i][j][k] = -1;
	}
	lnz = rnz - 1;
	nnz = lnz + rnz;
	for (i = rnz - 1; i >= 1; i--)
	{
		oi = -elem_pos[i][0] + 3;
		oj = -elem_pos[i][1] + 3;
		ok = -elem_pos[i][2] + 3;
		v[oi][oj][ok] = rnz - 1 - i;
	}
	for (i = 0; i < rnz; i++)
	{
		oi = elem_pos[i][0] + 3;
		oj = elem_pos[i][1] + 3;
		ok = elem_pos[i][2] + 3;
		v[oi][oj][ok] = lnz + i;
	}

	DATA_T rbuf[nnz];
	for (i = 0; i < M; i++)
	for (j = 0; j < N; j++)
	for (k = 0; k < L; k++)
	{
		int offset;
		for (ii = rnz - 1; ii >= 1; ii--)
		{
			oi = -elem_pos[ii][0];
			oj = -elem_pos[ii][1];
			ok = -elem_pos[ii][2];
			ti = oi + i;
			tj = oj + j;
			tk = ok + k;
			if (ti >= 0 && ti < M && tj >= 0 && tj < N && tk >= 0 && tk < L)
			{
				offset = ti*N*L + tj*L + tk;
				rbuf[rnz - 1 - ii] = A[offset][ii];
			}
			else
			{
				rbuf[rnz - 1 - ii] = 0;
			}
		}
		offset = i*N*L + j*L + k;
		for (ii = 0; ii < rnz; ii++)
		{
			rbuf[ii + lnz] = A[offset][ii];
		}
		for (ii = 0; ii < lnz; ii++)
		{
			oi = elem_pos[ii][0];
			oj = elem_pos[ii][1];
			ok = elem_pos[ii][2];
			ti = oi + i;
			tj = oj + j;
			tk = ok + k;
			if (ti >= 0 && ti < M && tj >= 0 && tj < N && tk >= 0 && tk < L)
			{
				int u_pos = (ti*N*L + tj*L + tk) * rnz;
				rbuf[ii] /= u[u_pos];
				for (jj = 1; jj < rnz; jj++)
				{
					int temp = lnz + jj;
					ti = oi + 3 + elem_pos[temp][0];
					tj = oj + 3 + elem_pos[temp][1];
					tk = ok + 3 + elem_pos[temp][2];
					if (ti >= 0 && ti < 7 && tj >= 0 && tj < 7 && tk >= 0 && tk < 7 && v[ti][tj][tk] != -1)
					{
						rbuf[v[ti][tj][tk]] -= rbuf[ii] * u[u_pos + jj];
					}
				}
			}
		}
		for (ii = 0; ii < lnz; ii++)
		{
			l[offset * lnz + ii] = rbuf[ii];
		}
		for (jj = 0; jj < rnz; jj++)
		{
			u[offset * rnz + jj] = rbuf[lnz + jj];
		}
	}
	return SWSPARSE_SUCCESS; 
}

template<typename DATA_T>
ErrorStatus
struct_ilu1_nonsymm(const DATA_T *a, DATA_T *l, DATA_T *u, swSparseInt dim_0, swSparseInt dim_1, swSparseInt dim_2, int nnz, const swSparseInt (*elem_pos)[3])
{
	int i, j, k;
	int ii, jj;
	int oi, oj, ok;
	int ti, tj, tk;
	int lnz, rnz;
	int annz = 0;
	int alnz, arnz;
	int M = dim_0, N = dim_1, L = dim_2;
	const DATA_T (*A)[nnz] = (const DATA_T (*)[nnz])a;
	int apos[nnz];

	int v[7][7][7];
	for (i = 0; i < 7; i++)
	for (j = 0; j < 7; j++)
	for (k = 0; k < 7; k++)
	{
		v[i][j][k] = -1;
	}

	//get lnz
	lnz = 0;
	for (lnz = 0; lnz < nnz; lnz++)
	{
		oi = elem_pos[lnz][0];
		oj = elem_pos[lnz][1];
		ok = elem_pos[lnz][2];
		if (oi * 100 + oj * 10 + ok >= 0) break;
	}
	rnz = nnz - lnz;

	for (i = 0; i < nnz; i++)
	{
		oi = elem_pos[i][0];
		oj = elem_pos[i][1];
		ok = elem_pos[i][2];
		v[oi + 3][oj + 3][ok + 3] = 1;
		if (i < lnz)
			for (j = lnz; j < nnz; j++)
			{
				ti = oi + elem_pos[j][0] + 3;
				tj = oj + elem_pos[j][1] + 3;
				tk = ok + elem_pos[j][2] + 3;
				v[ti][tj][tk] = 1;
				// printf("ti, tj, tk %d %d %d\n", ti, tj, tk);
			}
	}

	for (i = 0; i < 7; i++)
	for (j = 0; j < 7; j++)
	for (k = 0; k < 7; k++)
	{
		if (v[i][j][k] != -1) v[i][j][k] = (annz++);
	}

	alnz = -1;
	for (i = 0; i < nnz; i++)
	{
		oi = elem_pos[i][0];
		oj = elem_pos[i][1];
		ok = elem_pos[i][2];
		apos[i] = v[oi+3][oj+3][ok+3];
		if (oi * 100 + oj * 10 + ok == 0) alnz = apos[i];
	}
	if (alnz == -1) return SWSPARSE_INVALID_ARGS;
	arnz = annz - alnz;
	int fillpos[annz][3];
	int sum = 0;
	for (i = 0; i < 7; i++)
	for (j = 0; j < 7; j++)
	for (k = 0; k < 7; k++)
	{
		if (v[i][j][k] != -1)
		{
			fillpos[sum][0] = i - 3;
			fillpos[sum][1] = j - 3;
			fillpos[sum][2] = k - 3;
			sum++;
		}
	}

	DATA_T rbuf[annz];
	for (i = 0; i < M; i++)
	for (j = 0; j < N; j++)
	for (k = 0; k < L; k++)
	{
		int offset = i*N*L + j*L + k;
		for (ii = 0; ii < annz; ii++)
		{
			rbuf[ii] = 0;
		}
		for (ii = 0; ii < nnz; ii++)
		{
			rbuf[apos[ii]] = A[offset][ii];
		}
		for (ii = 0; ii < alnz; ii++)
		{
			oi = fillpos[ii][0];
			oj = fillpos[ii][1];
			ok = fillpos[ii][2];
			ti = oi + i;
			tj = oj + j;
			tk = ok + k;
			if (ti >= 0 && ti < M && tj >= 0 && tj < N && tk >= 0 && tk < L)
			{
				int u_pos = (ti*N*L + tj*L + tk) * arnz;
				rbuf[ii] /= u[u_pos];
				// if (i == 0 && j == 0 && k == 2)
				// {
				// 	printf("%d %d %d\n", oi, oj, ok);
				// 	printf("pos\n");
				// 	for (jj = 0; jj < annz; jj++)
				// 		printf("%d %d %d\n", fillpos[jj][0], fillpos[jj][1], fillpos[jj][2]);
				// 	printf("end\n");
				// 	printf("%.4f\n", rbuf[8]);
				// }
				for (jj = 1; jj < arnz; jj++)
				{
					int temp = alnz + jj;
					ti = oi + 3 + fillpos[temp][0];
					tj = oj + 3 + fillpos[temp][1];
					tk = ok + 3 + fillpos[temp][2];
					if (ti >= 0 && ti < 7 && tj >= 0 && tj < 7 && tk >= 0 && tk < 7 && v[ti][tj][tk] != -1)
					{
						rbuf[v[ti][tj][tk]] -= rbuf[ii] * u[u_pos + jj];
					}
					// if (i == 0 && j == 0 && k == 2)
					// {
					// 	printf("%d %d %d\n", ti, tj, tk);
					// }
				}
			}
		}
		for (ii = 0; ii < alnz; ii++)
		{
			l[offset * alnz + ii] = rbuf[ii];
		}
		for (jj = 0; jj < arnz; jj++)
		{
			u[offset * arnz + jj] = rbuf[alnz + jj];
		}
	}
	return SWSPARSE_SUCCESS; 
}

template<typename DATA_T>
ErrorStatus
struct_ilu1_symm(const DATA_T *a, DATA_T *l, DATA_T *u, swSparseInt dim_0, swSparseInt dim_1, swSparseInt dim_2, int rnz, const swSparseInt (*elem_pos)[3])
{
	int i, j, k;
	int ii, jj;
	int oi, oj, ok;
	int ti, tj, tk;
	int lnz, nnz;
	int annz = 0;
	int alnz, arnz;
	int M = dim_0, N = dim_1, L = dim_2;
	const DATA_T (*A)[rnz] = (const DATA_T (*)[rnz])a;
	lnz = rnz - 1;
	nnz = lnz + rnz;
	int apos[nnz];

	int v[7][7][7];
	for (i = 0; i < 7; i++)
	for (j = 0; j < 7; j++)
	for (k = 0; k < 7; k++)
	{
		v[i][j][k] = -1;
	}

	//get lnz
	// lnz = 0;
	// for (lnz = 0; lnz < nnz; lnz++)
	// {
	// 	oi =elem_pos[lnz][0];
	// 	oj =elem_pos[lnz][1];
	// 	ok =elem_pos[lnz][2];
	// 	if (oi * 100 + oj * 10 + ok >= 0) break;
	// }
	// rnz = nnz - lnz;

	for (i = rnz - 1; i >= 1; i--)
	{
		oi = -elem_pos[i][0];
		oj = -elem_pos[i][1];
		ok = -elem_pos[i][2];
		v[oi + 3][oj + 3][ok + 3] = 1;
		for (j = 0; j < rnz; j++)
		{
			ti = oi + elem_pos[j][0] + 3;
			tj = oj + elem_pos[j][1] + 3;
			tk = ok + elem_pos[j][2] + 3;
			v[ti][tj][tk] = 1;
			// printf("ti, tj, tk %d %d %d\n", ti, tj, tk);
		}
	}
	for (i = 0; i < rnz; i++)
	{
		oi = elem_pos[i][0];
		oj = elem_pos[i][1];
		ok = elem_pos[i][2];
		v[oi + 3][oj + 3][ok + 3] = 1;
	}

	for (i = 0; i < 7; i++)
	for (j = 0; j < 7; j++)
	for (k = 0; k < 7; k++)
	{
		if (v[i][j][k] != -1) v[i][j][k] = (annz++);
	}

	alnz = -1;
	for (i = rnz - 1; i >= 1; i--)
	{
		oi = -elem_pos[i][0];
		oj = -elem_pos[i][1];
		ok = -elem_pos[i][2];
		apos[rnz - 1 - i] = v[oi+3][oj+3][ok+3];
	}
	for (i = 0; i < rnz; i++)
	{
		oi = elem_pos[i][0];
		oj = elem_pos[i][1];
		ok = elem_pos[i][2];
		apos[lnz + i] = v[oi+3][oj+3][ok+3];
		if (oi * 100 + oj * 10 + ok == 0) alnz = apos[i];
	}
	if (alnz == -1) return SWSPARSE_INVALID_ARGS;
	arnz = annz - alnz;
	int fillpos[annz][3];
	int sum = 0;
	for (i = 0; i < 7; i++)
	for (j = 0; j < 7; j++)
	for (k = 0; k < 7; k++)
	{
		if (v[i][j][k] != -1)
		{
			fillpos[sum][0] = i - 3;
			fillpos[sum][1] = j - 3;
			fillpos[sum][2] = k - 3;
			sum++;
		}
	}

	DATA_T rbuf[annz];
	for (i = 0; i < M; i++)
	for (j = 0; j < N; j++)
	for (k = 0; k < L; k++)
	{
		int offset;
		for (ii = 0; ii < annz; ii++)
		{
			rbuf[ii] = 0;
		}
		for (ii = rnz - 1; ii >= 1; ii--)
		{
			oi = -elem_pos[ii][0];
			oj = -elem_pos[ii][1];
			ok = -elem_pos[ii][2];
			ti = oi + i;
			tj = oj + j;
			tk = ok + k;
			if (ti >= 0 && ti < M && tj >= 0 && tj < N && tk >= 0 && tk < L)
			{
				offset = ti*N*L + tj*L + tk;
				rbuf[apos[rnz - 1 - ii]] = A[offset][ii];
			}
		}
		offset = i*N*L + j*L + k;
		for (ii = 0; ii < rnz; ii++)
		{
			rbuf[apos[lnz + ii]] = A[offset][ii];
		}
		for (ii = 0; ii < alnz; ii++)
		{
			oi = fillpos[ii][0];
			oj = fillpos[ii][1];
			ok = fillpos[ii][2];
			ti = oi + i;
			tj = oj + j;
			tk = ok + k;
			if (ti >= 0 && ti < M && tj >= 0 && tj < N && tk >= 0 && tk < L)
			{
				int u_pos = (ti*N*L + tj*L + tk) * arnz;
				rbuf[ii] /= u[u_pos];
				// if (i == 0 && j == 0 && k == 2)
				// {
				// 	printf("%d %d %d\n", oi, oj, ok);
				// 	printf("pos\n");
				// 	for (jj = 0; jj < annz; jj++)
				// 		printf("%d %d %d\n", fillpos[jj][0], fillpos[jj][1], fillpos[jj][2]);
				// 	printf("end\n");
				// 	printf("%.4f\n", rbuf[8]);
				// }
				for (jj = 1; jj < arnz; jj++)
				{
					int temp = alnz + jj;
					ti = oi + 3 + fillpos[temp][0];
					tj = oj + 3 + fillpos[temp][1];
					tk = ok + 3 + fillpos[temp][2];
					if (ti >= 0 && ti < 7 && tj >= 0 && tj < 7 && tk >= 0 && tk < 7 && v[ti][tj][tk] != -1)
					{
						rbuf[v[ti][tj][tk]] -= rbuf[ii] * u[u_pos + jj];
					}
					// if (i == 0 && j == 0 && k == 2)
					// {
					// 	printf("%d %d %d\n", ti, tj, tk);
					// }
				}
			}
		}
		for (ii = 0; ii < alnz; ii++)
		{
			l[offset * alnz + ii] = rbuf[ii];
		}
		for (jj = 0; jj < arnz; jj++)
		{
			u[offset * arnz + jj] = rbuf[alnz + jj];
		}
	}
	return SWSPARSE_SUCCESS; 
}

}

#define DATA_TYPE_S
#include "s_structilu.inl"
#undef DATA_TYPE_S
#define DATA_TYPE_D
#include "s_structilu.inl"
#undef DATA_TYPE_D
#define DATA_TYPE_C
#include "s_structilu.inl"
#undef DATA_TYPE_C
#define DATA_TYPE_Z
#include "s_structilu.inl"
#undef DATA_TYPE_Z

