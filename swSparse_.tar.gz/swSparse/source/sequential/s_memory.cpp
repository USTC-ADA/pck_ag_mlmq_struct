#include<cmath>
#include<limits>
#include"internal/memory.h"
#include"internal/templates.h"

void swSparse_memset(void *dst, int value, size_t size) {
    memset(dst, value, size);
}

void swSparse_memcpy(void *dst, const void *src, size_t size) {
    memcpy(dst, src, size);
}

void swSparse_memmove(void *dst, const void *src, size_t size) {
    memmove(dst, src, size);
}

namespace swSparse {

template<typename DATA_T>
DATA_T *pack_chunks(DATA_T **chunks, Int full, Int cap, Int last) {
    if(full > 0) {
        int64_t size = (int64_t) full * (int64_t) cap + (int64_t) last;
        DATA_T *packed = (DATA_T *)expand_alloc(chunks[0], sizeof(DATA_T) * size, sizeof(DATA_T) * cap);
        if(packed != nullptr) {
            if(size > std::numeric_limits<Int>::max()) {
                DEBUG_PRINTF(swSparse_int32_overflow, size, __FILE__, __LINE__);
                swSparse_free(packed);
                return nullptr;
            } 
            for(Int i = 1; i < full; ++i) {
                swSparse_memcpy(packed + i * cap, chunks[i], sizeof(DATA_T) * cap);
            }
            swSparse_memcpy(packed + full * cap, chunks[full], sizeof(DATA_T) * last);
            for(Int i = 1; i <= full; ++i) {
                swSparse_free(chunks[i]);
            }
        }
        return packed;
    } else {
        return (DATA_T*)shrink_alloc(chunks[0], last, cap);
    }
}

template<typename DATA_T>
void clean_chunks(DATA_T **chunks, Int n) {
    Int i;
    for(i = 0; i < n; ++i) {
        swSparse_free(chunks[i]);
    }
}

template<typename DATA_T>
void vector_scale(DATA_T alpha, Int n, const DATA_T* RSTR x, DATA_T* RSTR y) {
    for(Int i = 0; i < n; ++i) {
        y[i] = alpha * x[i];
    }
}

template<typename DATA_T>
void vector_scale_conj(DATA_T alpha, Int n, const DATA_T* RSTR x, DATA_T* RSTR y) {
    for(Int i = 0; i < n; ++i) {
        y[i] = alpha * conj(x[i]);
    }
}

template<typename DATA_T>
void dense_scale(DATA_T alpha, Int n, Int nvec, const DATA_T* RSTR x, Int ldx, DATA_T* RSTR y, Int ldy) {
    for(Int i = 0; i < nvec; ++i) {
        vector_scale(alpha, n, x + i * ldx, y + i * ldy);
    }
}


#define EXPORT_TEMPLATES(type)  \
template type *pack_chunks<type>(type **chunks, Int full, Int cap, Int last); \
template void clean_chunks<type>(type **chunks, Int n); \
template void vector_scale<type>(type alpha, Int n, const type* RSTR x, type* RSTR y); \
template void dense_scale<type>(type alpha, Int n, Int nvec, const type* RSTR x, Int ldx, type* RSTR y, Int ldy);

EXPORT_TEMPLATES(float)
EXPORT_TEMPLATES(double)
EXPORT_TEMPLATES(SComplex)
EXPORT_TEMPLATES(DComplex)

template Int *pack_chunks<Int>(Int **chunks, Int full, Int cap, Int last);
template void clean_chunks<Int>(Int **chunks, Int n);
template void vector_scale_conj<SComplex>(SComplex alpha, Int n, const SComplex* x, SComplex* y);
template void vector_scale_conj<DComplex>(DComplex alpha, Int n, const DComplex* x, DComplex* y);


void index_shift(Int n, const Int* in_index, Int *out_index, Int delta) {
    for(Int i = 0; i < n; ++i) {
        out_index[i] = in_index[i] + delta;
    }
}

}