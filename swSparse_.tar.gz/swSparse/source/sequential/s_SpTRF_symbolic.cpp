#include <limits>
#include "swSparse_trf.h"
#include "internal/memory.h"
#include "internal/rename.h"
#include "internal/utils.h"
#include "internal/reorder.h"
#include "internal/algorithm_sort.h"
#include "internal/sptrf_param.h"
#include "internal/sptrf_common.h"
#include "internal/sptrf_suprelax.h"
#include "internal/debug.h"

typedef struct {
    Int krep, xdfs, maxdfs;
} stack_element_t;

#define IS_RELAXED_LEAF(s) ((s) > 0)

//#define ASSERT_POS(col, n, pos, begin, cnt) if(col + 1 < n) { ASSERT_LESS_EQUAL(pos, begin[col+1]); } else { ASSERT_LESS_EQUAL(pos, cnt); }

ErrorStatus swSparse_sptrf_symbolic(Matrix a, LUSup* lu, sym_analysis_result_t* sym_res, const swSparseTRFOptions* options) {
    const Int *etree = sym_res->etree;
    Int *l_begin = sym_res->colcnt, *u_begin = sym_res->rowcnt, *part_super = sym_res->part_super, height = sym_res->etree_height;
    col_status_t *status = sym_res->status;
    Int sup_max, n = a->n, nsup = 0, lcnz, lcnz_nondiag, ucnz, nseg, jsup, jrep, jld;
    Int *zeros, *stack_i, *marker, *l_prune_end, *l_indices, *u_indices, *u_seg, *a_off, *a_idx, *l_end, *u_end;
    Int *col2sup, *sup2col, *supetree, *v_offsets, *i_offsets, *temp, *u_offsets, *seg_offsets, *seg_nlz, *seg_indices;
    stack_element_t *stack;
    int64_t lcnt, ucnt, nli, nlv, nui, nuv, ni;
    switch (a->element_type)
    {
    case SWSPARSE_REAL_SINGLE:
        sup_max = swSparse::max_sup_size<4>;
        break;
    case SWSPARSE_REAL_DOUBLE:
    case SWSPARSE_COMPLEX_SINGLE:
        sup_max = swSparse::max_sup_size<8>;
        break;
    case SWSPARSE_COMPLEX_DOUBLE:
        sup_max = swSparse::max_sup_size<16>;
        break;
    default:
        return SWSPARSE_INVALID_ARGS;
    }

    a_off = a->matrix.csrc->offsets;
    a_idx = a->matrix.csrc->indices;

    lcnt = 0;
    ucnt = 0;
    for(Int i = 0; i < n; ++i) {
        // lcnt and ucnt are uint64_t
        // l_begin and u_begin are int32_t, may overflow.
        // But when it overflows, it runs out of memory
        Int t1 = lcnt, t2 = ucnt;  
        lcnt += l_begin[i];
        ucnt += u_begin[i];
        l_begin[i] = t1;
        u_begin[i] = t2;
    }
    l_indices = (Int*)swSparse_malloc(sizeof(Int) * lcnt);
    IF_ERR(l_indices == nullptr) {
        return MALLOC_ERROR;
    }

    u_indices = (Int*)swSparse_malloc(sizeof(Int) * ucnt);
    IF_ERR(u_indices == nullptr) {
        return clean_return(MALLOC_ERROR, l_indices);
    }

    IF_ERR(lcnt > std::numeric_limits<Int>::max()) {
        DEBUG_PRINTF(swSparse_int32_overflow, lcnt, __FILE__, __LINE__);
        return clean_return(SWSPARSE_NOT_SUPPORTED, u_indices, l_indices);
    }
    IF_ERR(ucnt > std::numeric_limits<Int>::max()) {
        DEBUG_PRINTF(swSparse_int32_overflow, ucnt, __FILE__, __LINE__);
        return clean_return(SWSPARSE_NOT_SUPPORTED, u_indices, l_indices);
    }

    l_end = (Int*)swSparse_malloc(sizeof(Int) * n * 2);
    u_end = l_end + n;
    IF_ERR(l_end == nullptr) {
        return clean_return(MALLOC_ERROR, u_indices, l_indices);
    }

    stack_i = (Int*)swSparse_malloc(sizeof(Int) * 3 * (n + height));
    stack = reinterpret_cast<stack_element_t*>(stack_i);
    marker = stack_i + height * 3;
    l_prune_end = marker + n;
    zeros = l_prune_end + n;
    IF_ERR(stack_i == nullptr) {
        return clean_return(MALLOC_ERROR, l_end, l_indices, u_indices);
    }
    swSparse_memset(marker, -1, sizeof(Int) * n);
    swSparse_memset(zeros, 0, sizeof(Int) * n);

    jld = jrep = -1;
    for(Int j = 0; j < n; ) {
        Bool new_super = true, j_is_leaf = IS_RELAXED_LEAF(status[j]);
        Int l_pos = l_begin[j], last_rep = jrep, last_ld = jld, singleton_size = j_is_leaf ? 0 : 1;

        if( j_is_leaf ) {  // relaxed supernode at leaf
            Int size = part_super[j], sup_end = j + size;
            for(Int col = j; col < sup_end; ++ col) {
                u_end[col] = u_begin[col];
            }
            for(Int k = a_off[j], a_end = a_off[sup_end]; k < a_end; ++k) {
                Int krow = a_idx[k];
                if ( krow >= sup_end /* off-diagonal */ && marker[krow] != j /* First time visit krow */ ) {
                    marker[krow] = j;
                    l_indices[l_pos++] = krow;
                }
            }
            
            ++ nsup;
            lcnz_nondiag = l_pos - l_begin[j];
            lcnz = size + lcnz_nondiag;
            Int fill_est = min((a_off[sup_end] - a_off[j]) * status[j], lcnz);  // guess the number of fill-in
            zeros[j] = lcnz * size - fill_est;
            jrep = j;
            jld = lcnz;
            j = sup_end;
        } else { // regular column
            Int u_pos = u_begin[j];
            for(Int k = a_off[j], a_end = a_off[j+1]; k < a_end; ++k) {
                Int krow = a_idx[k];
                if(krow >= j) {         // lower part
                    if ( marker[krow] != j ) { // First time visit krow
                        marker[krow] = j;
                        l_indices[l_pos++] = krow;
                    }
                } else if(krow < j) {  // upper part
                    Int krep = SUP_REP(krow, part_super);
                    if( marker[krep] != j ) {
                        Int stack_top = 0;
                        Int xdfs = l_begin[krep];
                        Int maxdfs = l_prune_end[krep];
                        marker[krep] = j;
                        
                        // start dfs from krep
                        for(;;) {
                            while ( xdfs < maxdfs ) {
                                Int kchild = l_indices[xdfs++];
                                if (kchild >= j) {         // kchild in lower part
                                    if ( marker[kchild] != j) {
                                        marker[kchild] = j;
                                        l_indices[l_pos++] = kchild;
                                    }
                                    if ( kchild == j && krep + part_super[krep] <= j /* not the same supernode */ ) {
                                        // symmetric pruning, if row-index of fill-in == j
                                        l_prune_end[krep] = xdfs;
                                    }
                                } else {                  // kchild in upper part
                                    Int chrep = SUP_REP(kchild, part_super);
                                    if ( marker[chrep] != j ) {
                                        // set U segment in pre-order
                                        marker[chrep] = j;
                                        // push stack
                                        ASSERT_LESS(stack_top, height);
                                        stack[stack_top].krep = krep;
                                        stack[stack_top].xdfs = xdfs;
                                        stack[stack_top++].maxdfs = maxdfs;
                                        krep = chrep;
                                        xdfs = l_begin[chrep];
                                        maxdfs = l_prune_end[chrep];
                                    }
                                }
                            }

                            // all children has been explored
                            if ( krep + part_super[krep] <= j ) { // only off-diagnal segments are stored in U
                                u_indices[u_pos++] = krep;
                            }
                            // pop stack
                            if( stack_top > 0 ) {
                                krep = stack[--stack_top].krep;
                                xdfs = stack[stack_top].xdfs;
                                maxdfs = stack[stack_top].maxdfs;
                            } else {
                                break; // stack empty, end DFS
                            }
                        }
                    }
                }
            } // End of column j

            lcnz = l_pos - l_begin[j];

            if(LIKELY(j > 0)) { // j == 0 then always new supernode
                Int d = j - last_rep;
                // determine whether or not in the same supernode
                if(part_super[j] == 0) { // not a relaxed leaf, not a branching point
                    if( (marker[last_rep] == j) && (lcnz + d == last_ld) ) {  // the same supernode
                        new_super = false;
                        part_super[j] = - d;
                    } else {                                         // start a new supernode
                        part_super[j] = part_super[last_rep] - d;
                        part_super[last_rep] = d;

                        if( marker[last_rep] == j ) { // if u has nonzero
                            u_indices[u_pos++] = last_rep;
                        }
                    }
                }
            }

            if( new_super ) {
                ++ nsup;
                jrep = j;
                jld = lcnz;
            }

            u_end[j] = u_pos;
            //ASSERT_POS(j, n, u_pos, u_begin, ucnt);
            swSparse::sort_int(u_indices + u_begin[j], u_pos - u_begin[j]);
            ++ j;
        }
        // post-processing previous supernode
        Bool last_determined = new_super, end_singleton = jrep == n - 1;
        if( j == n ) {
            last_determined = true;
            if( !new_super ) {
                ASSERT_EQUAL(jrep, last_rep);
                jrep = n;
            }
        }
        if( UNLIKELY(end_singleton) ) { // extremely rare: jrep=n-1 is singleton
            ASSERT_EQUAL( jrep, n - 1 );
            l_begin[jrep] += singleton_size;
        }
        if( last_determined && last_rep >= 0 && !IS_RELAXED_LEAF(status[last_rep]) ) {
            Int last_end = jrep, last_size = jrep - last_rep, last_zeros = 0;
            Int srep = last_rep, ssup_size = last_size, rescan_rep = last_rep, frep = jrep;
            if( UNLIKELY(ssup_size > sup_max) ) {  // rare: very big supernode, split
                const Int q = ssup_size / sup_max, r = ssup_size % sup_max;
                const Int nfull = q - ((r == 0) ? 1 : 0), first_size = (r == 0) ? sup_max : r;
                const Int off = l_begin[srep] - srep + sup_max;
                frep = srep + first_size;
                nsup += nfull;
                part_super[srep] = first_size;
                last_end = frep;
                last_size = first_size;
                rescan_rep = jrep - sup_max;
                l_begin[srep] += first_size; // remove indices of diagonal block
                for(Int prep = frep, qrep; prep < jrep; prep = qrep) {
                    qrep = prep + sup_max;
                    part_super[prep] = sup_max;
                    for(Int rcol = prep + 1; rcol < qrep; ++rcol) {
                        part_super[rcol] = prep - rcol;
                    }
                    l_begin[prep] = off + prep;
                    l_end[prep] = l_end[srep];
                    l_prune_end[prep] = l_prune_end[srep];
                }
                
            } else {
                l_begin[last_rep] += last_size;
                if( UNLIKELY(end_singleton) ) { // extremely rare: jrep=n-1 is singleton
                    // Try to merge jrep with last_rep
                    if(marker[last_rep] == jrep) {
                        Int merged_size = last_size + 1;
                        Int merged_ld = last_size + jld;
                        Int merged_zeros = (merged_ld - last_ld) * last_size;
                        Int merged_values = merged_ld * merged_size;
                        
                        if(should_merge(merged_size, merged_values, merged_zeros, status[last_rep])) {
                            part_super[last_rep] = merged_size;
                            part_super[jrep] = last_rep - jrep;
                            u_end[jrep] -= 1;
                            l_begin[last_rep] = l_begin[jrep];
                            l_end[last_rep] = l_pos;  // l_end[jrep] is not set yet, l_prune_end is not needed
                            last_size = merged_size;
                            last_ld = merged_ld;
                            last_zeros = merged_zeros;
                            last_end = n;
                            jrep = n;
                            -- nsup;
                            new_super = false;
                        }
                    }
                }
            }
            // by now diagonal block is removed from l_indices
            // Try to merge last_rep with previous
            Bool flag2 = false, flag1 = marker[last_rep] != jrep; // jrep may be n
            while(last_rep > 0) {
                Int k = last_rep - 1, krep = SUP_REP(k, part_super), u_count = 0;
                Int ksup_ld = l_end[krep] - l_begin[krep], kzeros = zeros[krep], ksup_size = part_super[krep];
                
                for(Int i = last_rep; i < last_end; ++ i) {
                    Int u_last = u_end[i] - 1;
                    if(u_last >= u_begin[i] && u_indices[u_last] == krep) {
                        ++u_count;
                    }
                }
                if(u_count > 0) {  // try merge krep with last_rep
                    Int merged_size = last_size + ksup_size;
                    Int merged_ld = last_ld + ksup_size;
                    Int merged_zeros = last_zeros + kzeros + (merged_ld - ksup_ld + last_size - u_count) * ksup_size;
                    Int merged_values = merged_ld * merged_size;
                    if(should_merge(merged_size, merged_values, merged_zeros, status[last_rep])) {
                        part_super[krep] = merged_size;
                        for(Int i = last_rep; i < last_end; ++ i) {
                            part_super[i] = krep - i;
                            Int u_last = u_end[i] - 1;
                            if(u_last >= u_begin[i] && u_indices[u_last] == krep) { // remove internal links
                                u_end[i] = u_last;
                            }
                        }
                        l_begin[krep] = l_begin[last_rep];  // remove internal links
                        l_end[krep] = l_end[last_rep];
                        l_prune_end[krep] = l_prune_end[last_rep];
                        last_size = merged_size;
                        last_ld = merged_ld;
                        last_zeros = merged_zeros;
                        last_rep = krep;
                        -- nsup;
                        flag2 = flag2 || (marker[krep] == jrep);
                        continue;
                    }
                }
                break;
            }
            zeros[last_rep] = last_zeros;

            for(Int prep = frep, qrep, sentinel = jrep - 1; prep < sentinel; prep = qrep) {
                qrep = prep + sup_max;
                for(Int rcol = prep; rcol < qrep; ++rcol) {
                    Int upos, ue = u_end[rcol], ub = u_begin[rcol];
                    for(upos = ue; upos > ub && u_indices[upos - 1] >= last_rep; --upos);  //  remove merged indices
                    u_indices[upos++] = last_rep;
                    for(Int urep = frep; urep < prep; urep += sup_max) { // add split indices
                        u_indices[upos++] = urep;
                    }
                    u_end[rcol] = upos;
                    //ASSERT_POS(rcol, n, upos, u_begin, ucnt);
                }
            }

            if(LIKELY(jrep < n)) {
                Int u_pos, ue = u_end[jrep], ub = u_begin[jrep];
                for(u_pos = ue; u_pos > ub && u_indices[u_pos - 1] > last_rep; --u_pos); // remove merged indices
                if( u_pos < ue && marker[last_rep] != jrep) {
                    u_indices[u_pos++] = last_rep;  // merge into last_rep
                }
                if( UNLIKELY(ssup_size > sup_max) && marker[srep] == jrep ) {  // add split indices
                    for(Int urep = frep; urep < jrep; urep += sup_max) {
                        u_indices[u_pos++] = urep;
                    }
                }
                u_end[jrep] = u_pos;
                //ASSERT_POS(jrep, n, u_pos, u_begin, ucnt);
            }

            if(flag1 & flag2) {  // generate fill-in caused by merging
                for(Int k = l_begin[rescan_rep], e = l_end[rescan_rep]; k < e; ++k) {
                    Int krow = l_indices[k];
                    if(marker[krow] != jrep) {
                        l_indices[l_pos++] = krow;
                    }
                }
            }
        }
        if( new_super ) {
            Int *i, len;
            if( UNLIKELY(end_singleton) ) {
                Int jj = n - 1, b = l_begin[jj] - singleton_size;
                i = l_indices + b;
                len = l_pos - b;
                l_end[jj] = l_prune_end[jj] = l_pos;
            } else {
                i = l_indices + l_begin[jrep];
                len = l_pos - l_begin[jrep];
                l_end[jrep] = l_prune_end[jrep] = l_pos;
            }
            swSparse::sort_int(i, len);
        }
    }
    swSparse_free(stack_i);
    i_offsets = (Int*)swSparse_malloc(sizeof(Int) * (nsup * 4 + n + 4));  /* nsup + 1 */
    v_offsets = i_offsets + nsup + 1;                                 /* nsup + 1 */
    sup2col   = v_offsets + nsup + 1;                                 /* nsup + 1 */
    col2sup   = sup2col + nsup + 1;                                   /* n + 1 */
    supetree  = col2sup + n + 1;
    IF_ERR(i_offsets == nullptr) {
        return clean_return(MALLOC_ERROR, l_end, l_indices, u_indices);
    }
    // count memory usage
    jsup = -1;
    nli = nlv = nui = 0;
    for(Int j = 0; j < n; ++j) {
        Int sup_size = part_super[j];
        ASSERT_NOT_EQUAL(sup_size, 0);
        if(sup_size > 0) {
            lcnz_nondiag = l_end[j] - l_begin[j];
            sup2col[++jsup] = j;
            i_offsets[jsup] = nli;
            v_offsets[jsup] = nlv;
            nli += lcnz_nondiag;
            nlv += (lcnz_nondiag + sup_size) * sup_size;
            ASSERT_LESS_EQUAL(0, lcnz_nondiag);
        }
        col2sup[j] = jsup;
        nui += u_end[j] - u_begin[j];
    }
    sup2col[++jsup] = n;
    i_offsets[jsup] = nli;
    v_offsets[jsup] = nlv;
    col2sup[n] = jsup;
    ASSERT_EQUAL( jsup, nsup );

#ifdef SWSPARSE_HAS_ASSERT
    //DEBUG_PRINTF("L: %d indices, %d values\n", nli, nlv);
#endif

    temp = nullptr;
    if( nli > 0 ) {
        temp = (Int*)swSparse_malloc(sizeof(Int) * nli);
        IF_ERR(temp == nullptr) {
            return clean_return(MALLOC_ERROR, l_end, l_indices, u_indices, i_offsets);
        }
        IF_ERR(nli > std::numeric_limits<Int>::max()) {
            DEBUG_PRINTF(swSparse_int32_overflow, nli, __FILE__, __LINE__);
            return clean_return(SWSPARSE_NOT_SUPPORTED, temp, l_end, l_indices, u_indices, i_offsets);
        }
    }

    // pack L indices
    ni = 0;
    for(jsup = 0; jsup < nsup; ++jsup) {
        Int b = i_offsets[jsup];
        lcnz_nondiag = i_offsets[jsup+1] - b;
        swSparse_memcpy(temp + ni, l_indices + l_begin[sup2col[jsup]], sizeof(Int) * lcnz_nondiag);
        ni += lcnz_nondiag;
        ASSERT_LESS_EQUAL(0, lcnz_nondiag);

        // transform to supernodal etree
        supetree[jsup] = col2sup[etree[sup2col[jsup + 1] - 1]];  // Note: col2sup[n] == nsuper
    }

    ASSERT_EQUAL( ni, nli );

    swSparse_free(l_indices);
    lu->l_i_offsets = i_offsets;
    lu->l_v_offsets = v_offsets;
    lu->col2sup = col2sup;
    lu->sup2col = sup2col;
    lu->l_indices = temp;
    lu->nsuper  = nsup;
    lu->sup_etree_parent = supetree;
    lu->l_ordered = true;
    /* values are not allocated here */

    u_offsets = (Int*)swSparse_malloc(sizeof(Int) * (n + 1 + nui * 2 + 1));
    IF_ERR(u_offsets == nullptr) {
        return clean_return(MALLOC_ERROR, i_offsets, l_end, u_indices, lu->l_indices);
    }
    IF_ERR(nui > std::numeric_limits<Int>::max()) {
        DEBUG_PRINTF(swSparse_int32_overflow, nui, __FILE__, __LINE__);
        return clean_return(SWSPARSE_NOT_SUPPORTED, u_offsets, i_offsets, l_end, u_indices, lu->l_indices);
    }
    seg_offsets   = u_offsets + n + 1;
    seg_indices   = seg_offsets + nui + 1;

    ni = 0;
    nuv = 0;
    for(Int j = 0; j < n; ++j) {
        Int krep, size = u_end[j] - u_begin[j];
        ASSERT_LESS_EQUAL(0, size);
        u_offsets[j] = ni;

        swSparse_memcpy(seg_indices + ni, u_indices + u_begin[j], sizeof(Int) * size);
        ni += size;

        for(Int k = u_offsets[j]; k < ni; ++k) {
            krep = seg_indices[k];
            seg_offsets[k] = nuv;
            nuv += part_super[krep];
            ASSERT_LESS( 0, part_super[krep] );
        }
    }
    u_offsets[n] = nui;
    seg_offsets[ni] = nuv;

    ASSERT_EQUAL(ni, nui);
#ifdef SWSPARSE_HAS_ASSERT
    //DEBUG_PRINTF("U: %d indices, %d values\n", nui, nuv);
#endif
        
    lu->u_col_offsets = u_offsets;
    lu->u_seg_offsets = seg_offsets;
    lu->u_seg_indices = seg_indices;
    /* values are not allocated here */

    return clean_return(SWSPARSE_SUCCESS, l_end, u_indices);
}

