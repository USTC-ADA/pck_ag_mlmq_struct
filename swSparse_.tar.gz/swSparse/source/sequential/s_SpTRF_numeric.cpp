#include "swSparse_trf.h"
#include "internal/memory.h"
#include "internal/rename.h"
#include "internal/templates.h"
#include "internal/reorder.h"
#include "internal/sptrf_common.h"
#include "internal/utils.h"
#include "internal/debug.h"

namespace swSparse {

inline constexpr Int panel_size = 128;

ErrorStatus trf_static_schedule(LUSup* lu) { return SWSPARSE_SUCCESS; }

template<typename DATA_T>
void pivot_permute(Int begin, Int end, DATA_T* RSTR x, const Int* RSTR ipiv) {  // permute under a certain pivot sequence
    for(Int i = begin; i < end; ++i) {
        Int piv_i = ipiv[i];
        DATA_T piv_v = x[piv_i];
        x[piv_i] = x[i];
        x[i] = piv_v;
    }
}

template<typename DATA_T>
void mv(Int nrow, Int ncol, Int ld, const DATA_T* RSTR l, const DATA_T* RSTR x, DATA_T* RSTR y) {
    swSparse_memset(y, 0, sizeof(DATA_T) * nrow);
    for(Int j = 0; j < ncol; ++j) {
        for(Int i = 0; i < nrow; ++i) {
            y[i] += l[i + j * ld] * x[j];
        }
    }
}

template<typename DATA_T>
void l_trsv(Int n, Int ld, const DATA_T* RSTR l, DATA_T* RSTR b) {
    for(Int j = 0; j < n; ++j) {
        for(Int i = j + 1; i < n; ++i) {
            b[i] -= l[i + j * ld] * b[j];
        }
    }
}

template<typename DATA_T>
void l_sup_update(Int nrow, Int panel_begin, Int panel_end, DATA_T* RSTR sup) {  // TRSM + GEMM
    for(Int k = 0; k < panel_begin; ++k) {
        for(Int j = panel_begin; j < panel_end; ++j) {
            for(Int i = k + 1; i < nrow; ++i) {
                sup[i + j * nrow] -= sup[i + k * nrow] * sup[k + j * nrow];
            }
        }    
    }
}


template<typename DATA_T, typename PERTURBATION>
Int l_sup_factorize(Int nrow, Int panel_begin, Int panel_end, Int sup_size, DATA_T* RSTR sup, Int* RSTR ipiv, real_t<DATA_T> t, real_t<DATA_T> r) {  // TRF
    PERTURBATION perturb(t, r);
    for(Int j = panel_begin; j < panel_end; ++j) {
        // update in panel
        for(Int k = panel_begin; k < j; ++k) {  
            for(Int i = k + 1; i < nrow; ++i) {
                sup[i + j * nrow] -= sup[i + k * nrow] * sup[k + j * nrow];
            }
        }

        // pivoting
        real_t<DATA_T> max_piv = fabs(sup[j + j * nrow]);
        Int max_piv_i = j;
        for(Int i = j + 1; i < sup_size; ++i) {
            real_t<DATA_T> mag = fabs(sup[i + j * nrow]);
            if(max_piv < mag) {
                max_piv = mag;
                max_piv_i = i;
            }
        }
        ipiv[j] = max_piv_i;
        if(max_piv_i != j) {
            for(Int k = panel_begin; k < panel_end; ++k) {
                DATA_T *sup_col = &sup[k * nrow];
                DATA_T tmp = sup_col[max_piv_i];
                sup_col[max_piv_i] = sup_col[j];
                sup_col[j] = tmp;
            }
        }

        // perturbation & scale
        DATA_T piv = perturb.rcp_pivot(sup[j + j * nrow], max_piv);
        sup[j + j * nrow] = piv;
        for(Int i = j + 1; i < nrow; ++i) {
            sup[i + j * nrow] *= piv;
        }
    }
    return perturb.count();
}

template<typename DATA_T, typename UPDATE>
INLINE void sparse_update(Int n_update, const Int* update_indices, const DATA_T* update_values, \
    Int sup_begin, Int sup_end, Int sup_size, \
    Int n_seg, const Int* u_seg_offsets_col, const Int* u_seg_indices_col, DATA_T* u_values, \
    Int n_l_idx, const Int* l_sup_idx, DATA_T* l_col_val, UPDATE &&update) {
    Int pos = 0, upos = 0, lpos = 0;

    for(; pos < n_update && update_indices[pos] < sup_begin; ++ pos) {
        Int row_idx = update_indices[pos];
        Int off_in_seg = row_idx - u_seg_indices_col[upos];
        while(off_in_seg >= u_seg_offsets_col[upos + 1] - u_seg_offsets_col[upos]) {
            off_in_seg = row_idx - u_seg_indices_col[++upos];
        }
        update(&u_values[u_seg_offsets_col[upos] + off_in_seg], update_values[pos]);

        ASSERT_LESS_EQUAL(0, off_in_seg);
    }
    ASSERT(upos < n_seg || n_seg == 0);

    for(; pos < n_update && update_indices[pos] < sup_end; ++ pos) {
        Int row_idx = update_indices[pos];
        update(&l_col_val[row_idx - sup_begin], update_values[pos]);
    }
    for(; pos < n_update; ++ pos) {
        Int row_idx = update_indices[pos];
        while(l_sup_idx[lpos] < row_idx) {
            ++lpos;
        }

        ASSERT_EQUAL(l_sup_idx[lpos], row_idx);

        update(&l_col_val[sup_size + (lpos++)], update_values[pos]);
    }
    ASSERT(lpos <= n_l_idx);
}


template<typename DATA_T>
ErrorStatus sptrf_numeric(Matrix a, LUSup* lu, real_t<DATA_T> thres, Int* riperm, numeric_result_t* res, const swSparseTRFOptions* options) {
    constexpr const DATA_T zero = DATA_T(0);
    struct {
        Int index, position;
    } next_seg[panel_size];
    Int n = a->n, nsup = lu->nsuper;
    const Int *a_column_offsets = a->matrix.csrc->offsets;
    const Int *a_row_indices = a->matrix.csrc->indices;
    const DATA_T *a_values = VALUES(a->matrix.csrc, DATA_T);
    const Int *l_i_offsets = lu->l_i_offsets;
    const Int *l_v_offsets = lu->l_v_offsets;
    Int *l_indices = lu->l_indices;  // maybe reordered in pivoting
    const Int *sup2col = lu->sup2col;
    const Int *col2sup = lu->col2sup;
    const Int *u_col_offsets = lu->u_col_offsets;
    const Int *u_seg_offsets = lu->u_seg_offsets;
    const Int *u_seg_indices = lu->u_seg_indices;
    Int l_nnz = l_v_offsets[nsup], u_nnz = u_seg_offsets[u_col_offsets[n]];
    Int perturb_count = 0;
    real_t<DATA_T> rcp_thres = reciprocal(thres);
    DATA_T *l_val = (DATA_T*) lu->l_values, *u_val = (DATA_T*) lu->u_values;

    Int (*supfact)(Int, Int, Int, Int, DATA_T* RSTR, Int* RSTR, real_t<DATA_T>, real_t<DATA_T>);
    
    if(options->perturbate != SWSPARSE_NO_PERTURBATE) {
        if(options->perturbate == SWSPARSE_PERTURBATE_0) {
            supfact = l_sup_factorize<DATA_T, perturb_zero<DATA_T>>;
        } else {
            supfact = l_sup_factorize<DATA_T, perturb_tiny<DATA_T>>;
        } 
    } else {
        supfact = l_sup_factorize<DATA_T, no_perturbation>;
    }

    DATA_T* temp = (DATA_T*)swSparse_malloc(sizeof(DATA_T) * n);
    IF_ERR(temp == nullptr) {
        return MALLOC_ERROR;
    }
    lu->l_values = l_val;
    lu->u_values = u_val;
    for(Int i = 0; i < panel_size; ++i) {
        next_seg[i].index = n;
    }

    // for each supernode
    for(Int jsup = 0; jsup < nsup; ++jsup) {
        DATA_T *l_sup_val = l_val + l_v_offsets[jsup];
        Int j_sup_begin = sup2col[jsup], j_sup_end = sup2col[jsup + 1];
        Int sup_i_off = l_i_offsets[jsup];
        Int sup_ni = l_i_offsets[jsup + 1] - sup_i_off;
        Int sup_size = j_sup_end - j_sup_begin, sup_ld = sup_size + sup_ni;
        Int *ipiv_local = riperm + j_sup_begin;
        Int *l_sup_idx = l_indices + sup_i_off;

        // for each panel
        for(Int j_panel = j_sup_begin; j_panel < j_sup_end; j_panel += panel_size) {
            Int ncol = min(panel_size, j_sup_end - j_panel);
            Int j_panel_end = j_panel + ncol;
            Int j_panel_rel = j_panel - j_sup_begin, j_panel_end_rel = j_panel_rel + ncol;
            Int pos, upos, lpos;

            // for each column
            for(Int jj = 0; jj < ncol; ++ jj) {
                Int jcol = j_panel + jj;
                Int u_begin = u_col_offsets[jcol], u_end = u_col_offsets[jcol + 1];
                Int a_begin = a_column_offsets[jcol], a_end = a_column_offsets[jcol + 1];
                DATA_T* l_col_val = l_sup_val + (jj + j_panel_rel) * sup_ld;

                next_seg[jj].position = u_begin;
                next_seg[jj].index = (u_begin < u_end) ? u_seg_indices[u_begin] : n;

                swSparse_memset(&u_val[u_seg_offsets[u_begin]], 0, \
                    sizeof(DATA_T) * (u_seg_offsets[u_end] - u_seg_offsets[u_begin]));
                swSparse_memset(l_col_val, 0, sizeof(DATA_T) * sup_ld);

                if((options->transpose & SWSPARSE_CONJUGATE) != SWSPARSE_CONJUGATE) {
                    sparse_update(a_end - a_begin, a_row_indices + a_begin, a_values + a_begin, \
                        j_sup_begin, j_sup_end, sup_size, \
                        u_end - u_begin, u_seg_offsets + u_begin, u_seg_indices + u_begin, u_val, \
                        sup_ni, l_sup_idx, l_col_val, \
                        [](DATA_T* target, DATA_T value) { *target = value; });
                } else {
                    sparse_update(a_end - a_begin, a_row_indices + a_begin, a_values + a_begin, \
                        j_sup_begin, j_sup_end, sup_size, \
                        u_end - u_begin, u_seg_offsets + u_begin, u_seg_indices + u_begin, u_val, \
                        sup_ni, l_sup_idx, l_col_val, \
                        [](DATA_T* target, DATA_T value) { *target = conjugate<DATA_T>::value(value); });
                }
            }

            // for each segment in this panel
            for (;;) {
                DATA_T *l_ksup_val;
                Int next = n, ksup, ksup_size, ksup_nrow;
                Int ksup_i_off, ksup_ld;
                for(Int jj = 0; jj < ncol; ++ jj) {
                    next = min(next, next_seg[jj].index);
                }
                if(next == n) {
                    break;
                }
                ksup = col2sup[next];
                ASSERT_LESS( ksup, jsup );
                ksup_size = sup2col[ksup + 1] - sup2col[ksup];
                l_ksup_val = l_val + l_v_offsets[ksup];              // previous supernode
                ksup_i_off = l_i_offsets[ksup];
                ksup_nrow = l_i_offsets[ksup + 1] - ksup_i_off;
                ksup_ld = ksup_nrow + ksup_size;

                for(Int jj = 0; jj < ncol; ++ jj) {
                    if(next_seg[jj].index == next) {  // non-zero segment
                        Int k = next_seg[jj].position;
                        Int nlz, seg_size, jcol = j_panel + jj;
                        Int seg_begin = u_seg_offsets[k] , segrep = u_seg_indices[k];

                        ASSERT_EQUAL(u_seg_offsets[k + 1], seg_begin + ksup_size);

                        // permute
                        pivot_permute(0, ksup_size, &u_val[seg_begin], &riperm[segrep]);
                        for(nlz = 0; (nlz < ksup_size) && (u_val[seg_begin + nlz] == zero); ++ nlz);
                        seg_size = ksup_size - nlz;

                        ++ k;
                        next_seg[jj].position = k;
                        if(k < u_col_offsets[jcol + 1]) {
                            next_seg[jj].index = u_seg_indices[k];
                        } else {
                            next_seg[jj].index = n;
                        }

                        if(seg_size > 0) {  // maybe numeric cancellation
                            // Note: in CPE version, we can collect all U segments in the panel into LDM
                            //       and use TRSM and GEMM

                            // update diagnal block
                            l_trsv(seg_size, ksup_ld, &l_ksup_val[nlz * ksup_ld + nlz], &u_val[seg_begin + nlz]);

                            // update off-diagnal block
                            if(ksup_nrow > 0) {
                                Int u_begin = k/* the next segment */, u_end = u_col_offsets[jcol + 1];
                                DATA_T* l_col_val = l_sup_val + (jj + j_panel_rel) * sup_ld;

                                mv(ksup_nrow, seg_size, ksup_ld, &l_ksup_val[nlz * ksup_ld + ksup_size], &u_val[seg_begin + nlz], temp);
                                
                                sparse_update(ksup_nrow, &l_indices[ksup_i_off], temp, \
                                    j_sup_begin, j_sup_end, sup_size, \
                                    u_end - u_begin, u_seg_offsets + u_begin, u_seg_indices + u_begin, u_val, \
                                    sup_ni, l_sup_idx, l_col_val, \
                                    [](DATA_T* target, DATA_T value) { *target -= value; });
                            }
                        }

                    }
                }
            }

            // permute panel
            for(Int jj = 0; jj < ncol; ++ jj) {
                DATA_T *l_col = l_sup_val + (jj + j_panel_rel) * sup_ld;
                pivot_permute(0, j_panel_rel, l_col, ipiv_local);
            }

            // inner update
            l_sup_update(sup_ld, j_panel_rel, j_panel_end_rel, l_sup_val);
            
            // inner factorize
            perturb_count += supfact(sup_ld, j_panel_rel, j_panel_end_rel, sup_size, l_sup_val, ipiv_local, thres, rcp_thres);
            
            // permute left L
            for(Int jrel = 0; jrel < j_panel_rel; ++jrel) {
                pivot_permute(j_panel_rel, j_panel_end_rel, &l_sup_val[jrel * sup_ld], ipiv_local);
            }
        }
    }
    Int interchange_count = 0;
    Int *rperm = reinterpret_cast<Int*>(temp);
    for(Int isup = 0; isup < nsup; ++isup) {
        Int begin = sup2col[isup], end = sup2col[isup + 1], supsize = end - begin;
        for(Int i = 0; i < supsize; ++i) {
            rperm[i] = i + begin;
        }
        for(Int i = 0; i < supsize; ++i) {
            Int piv_i = riperm[i + begin]; // local index (in supernodes) of pivots
            ASSERT_LESS(piv_i, supsize);
            ASSERT_LESS_EQUAL(0, piv_i);
            if(piv_i != i) {
                Int tt = rperm[i];
                rperm[i] = rperm[piv_i];
                rperm[piv_i] = tt;
                ++ interchange_count;
            }
        }
        for(Int i = 0; i < supsize; ++i) {
            riperm[rperm[i]] = i + begin;
        }
    }
    swSparse_free(temp);      
    res->perturbation_count = perturb_count;
    res->interchange_count = interchange_count;
    if(interchange_count > 0) {  
        lu->l_ordered = false;
        gather_by_indices(l_i_offsets[nsup], riperm, l_indices, l_indices);
    } 
    return SWSPARSE_SUCCESS;
}

#define INSTANTIATE(type) \
template ErrorStatus sptrf_numeric<type>(Matrix a, LUSup* lu, real_t<type> perterb_thres, Int* riperm, \
    numeric_result_t*, const swSparseTRFOptions* options);

INSTANTIATE(float)
INSTANTIATE(double)
INSTANTIATE(SComplex)
INSTANTIATE(DComplex)

}