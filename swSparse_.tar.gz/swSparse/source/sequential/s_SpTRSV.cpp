#include <algorithm>
#include "swSparse_blas.h"
#include "internal/rename.h"
#include "internal/spblas_common.h"
#include "internal/templates.h"
#include "internal/memory.h"
#include "internal/debug.h"
#include "internal/utils.h"
#include "internal/reorder.h"
#include "internal/dependency.h"

namespace swSparse  {

template<typename DATA_T>
static ErrorStatus trsv_inspect_csr(Matrix old_mat, Matrix *new_mat, Int *perm, Int *iperm, const swSparseTRSVOptions* options) {

    ErrorStatus ret;
    Matrix created;
    MatrixFormatType format = CSR;
    Int i, j, k;
    Int m = old_mat->m, n = old_mat->n, nnz = old_mat->nnz;
    Int* old_levels;
    Int* old_indices;
    Int* new_levels;

    const MatrixCSRC *otmp = old_mat->matrix.csrc;
    const DATA_T *oval = (DATA_T*) otmp->values; 
    
    new_levels = (Int*)swSparse_malloc(sizeof(Int) * n * 3);
    old_levels = new_levels + n;
    old_indices = old_levels + n;
    
    create_id_perm(n, old_indices);

    if((options->transpose & SWSPARSE_NON_TRANSPOSE) == SWSPARSE_NON_TRANSPOSE && options->uplo == SWSPARSE_LOWER_TRI) {
        swSparse_level_csr_lower(n, otmp->offsets, otmp->indices, old_levels);
        sort_levels(n, old_levels, old_indices, new_levels, perm);
    } else if((options->transpose & SWSPARSE_TRANSPOSE) == SWSPARSE_TRANSPOSE     && options->uplo == SWSPARSE_UPPER_TRI) {
        format = CSC;
        swSparse_level_csc_lower(n, otmp->offsets, otmp->indices, old_levels);
        sort_levels(n, old_levels, old_indices, new_levels, perm);
    } else if((options->transpose & SWSPARSE_NON_TRANSPOSE) == SWSPARSE_NON_TRANSPOSE && options->uplo == SWSPARSE_UPPER_TRI) {
        // reverse permutation, transform UPPER to LOWER
        swSparse_level_csr_upper_reverse(n, otmp->offsets, otmp->indices, old_levels);
        sort_levels_reverse(n, old_levels, old_indices, new_levels, perm);
    } else if((options->transpose & SWSPARSE_TRANSPOSE) == SWSPARSE_TRANSPOSE     && options->uplo == SWSPARSE_LOWER_TRI) {
        format = CSC;
        swSparse_level_csc_upper_reverse(n, otmp->offsets, otmp->indices, old_levels);
        sort_levels_reverse(n, old_levels, old_indices, new_levels, perm);
    }
    swSparse_free(new_levels);
    swSparse_perm_invert(n, perm, iperm);
    ret = reorder_row_col(old_mat, &created, iperm, iperm);
    if(ret == SWSPARSE_SUCCESS) {
        *new_mat = created;
        created->status = SWSPARSE_LOWER_TRI; // override
        created->format_type = format;
    }
    return ret;
}

template<typename DATA_T>
static ErrorStatus trsv_inspect_csc(Matrix old_mat, Matrix *new_mat, Int *perm, Int *iperm, const swSparseTRSVOptions* options) {

    ErrorStatus ret;
    Matrix created;
    MatrixFormatType format = CSC;
    Int i, j, k;
    Int m = old_mat->m, n = old_mat->n, nnz = old_mat->nnz;

    Int* old_levels;
    Int* old_indices;
    Int* new_levels;

    const MatrixCSRC *otmp = old_mat->matrix.csrc;
    const DATA_T *oval = (DATA_T*) otmp->values; 
    
    new_levels = (Int*)swSparse_malloc(sizeof(Int) * n * 3);
    old_levels = new_levels + n;
    old_indices = old_levels + n;
    
    create_id_perm(n, old_indices);

    if((options->transpose & SWSPARSE_NON_TRANSPOSE) == SWSPARSE_NON_TRANSPOSE && options->uplo == SWSPARSE_LOWER_TRI) {
        swSparse_level_csc_lower(n, otmp->offsets, otmp->indices, old_levels);
        sort_levels(n, old_levels, old_indices, new_levels, perm);
    } else if((options->transpose & SWSPARSE_TRANSPOSE) == SWSPARSE_TRANSPOSE     && options->uplo == SWSPARSE_UPPER_TRI) {
        format = CSR;
        swSparse_level_csr_lower(n, otmp->offsets, otmp->indices, old_levels);
        sort_levels(n, old_levels, old_indices, new_levels, perm);
    } else if((options->transpose & SWSPARSE_NON_TRANSPOSE) == SWSPARSE_NON_TRANSPOSE && options->uplo == SWSPARSE_UPPER_TRI) {
        // reverse permutation, transform UPPER to LOWER
        swSparse_level_csc_upper_reverse(n, otmp->offsets, otmp->indices, old_levels); 
        sort_levels_reverse(n, old_levels, old_indices, new_levels, perm);
    } else if((options->transpose & SWSPARSE_TRANSPOSE) == SWSPARSE_TRANSPOSE     && options->uplo == SWSPARSE_LOWER_TRI) {
        format = CSR;
        swSparse_level_csr_upper_reverse(n, otmp->offsets, otmp->indices, old_levels);
        sort_levels_reverse(n, old_levels, old_indices, new_levels, perm);
    }
    swSparse_free(new_levels);
    swSparse_perm_invert(n, perm, iperm);
    ret = reorder_row_col(old_mat, &created, iperm, iperm);
    if(ret == SWSPARSE_SUCCESS) {
        *new_mat = created;
        created->status = SWSPARSE_LOWER_TRI; // override
        created->format_type = format;
    }
    return ret;
}

template<typename DATA_T, typename Conj, typename Alpha = DATA_T>
static void trsv_execute_csr_upper(Alpha alpha, Matrix u, const DATA_T *b, DATA_T *x, const swSparseTRSVOptions* options) {
    const Int n = u->n;
    Int i;
    const Int *u_row_offsets = u->matrix.csrc->offsets;
    const Int *u_column_indices = u->matrix.csrc->indices;
    const DATA_T *u_values = (const DATA_T*)u->matrix.csrc->values;

    if((u->status & SWSPARSE_UNIT_DIAG) != 0) {
        for(i = n - 1; i >= 0; --i) {
            const Int begin = u_row_offsets[i], end = u_row_offsets[i+1];
            Int k;
            DATA_T tmp_x = alpha * b[i];
            for(k = end; k > begin; --k) {
                Int j = u_column_indices[k];
                tmp_x -= x[j] * Conj::value(u_values[k]);
            }
            x[i] = tmp_x;
        }
    } else if((u->status & SWSPARSE_RECP_DIAG) != 0) {
        for(i = n - 1; i >= 0; --i) {
            const Int begin = u_row_offsets[i], end = u_row_offsets[i+1]-1;
            Int k;
            DATA_T tmp_x = alpha * b[i];
            for(k = end; k > begin; --k) {
                Int j = u_column_indices[k];
                tmp_x -= x[j] * Conj::value(u_values[k]);
            }
            x[i] = tmp_x * Conj::value(u_values[begin]);
        }
    } else {
        for(i = n - 1; i >= 0; --i) {
            const Int begin = u_row_offsets[i], end = u_row_offsets[i+1]-1;
            Int k;
            DATA_T tmp_x = alpha * b[i];
            for(k = end; k > begin; --k) {
                Int j = u_column_indices[k];
                tmp_x -= x[j] * Conj::value(u_values[k]);
            }
            x[i] = tmp_x / Conj::value(u_values[begin]);
        }
    }
}

template<typename DATA_T, typename Conj, typename Alpha = DATA_T>
static void trsv_execute_csr_lower(Alpha alpha, Matrix l, const DATA_T *b, DATA_T *x, const swSparseTRSVOptions* options) {
    const Int n = l->n;
    Int i;
    const Int *l_row_offsets = l->matrix.csrc->offsets;
    const Int *l_column_indices = l->matrix.csrc->indices;
    const DATA_T *l_values = (const DATA_T*)l->matrix.csrc->values;
    
    if((l->status & SWSPARSE_UNIT_DIAG) != 0) {
        for(i = 0; i < n; ++i) {
            const Int begin = l_row_offsets[i], end = l_row_offsets[i+1];
            Int k;
            DATA_T tmp_x = alpha * b[i];
            for(k = begin; k < end; ++k) {
                Int j = l_column_indices[k];
                tmp_x -= x[j] * Conj::value(l_values[k]);
            }
            x[i] = tmp_x;
        }
    } else if((l->status & SWSPARSE_RECP_DIAG) != 0) {
        for(i = 0; i < n; ++i) {
            const Int begin = l_row_offsets[i], end = l_row_offsets[i+1];
            Int k;
            DATA_T tmp_x = alpha * b[i];
            for(k = begin; k < end-1; ++k) {
                Int j = l_column_indices[k];
                tmp_x -= x[j] * Conj::value(l_values[k]);
            }
            x[i] = tmp_x * Conj::value(l_values[end-1]);
        }
    } else {
        for(i = 0; i < n; ++i) {
            const Int begin = l_row_offsets[i], end = l_row_offsets[i+1];
            Int k;
            DATA_T tmp_x = alpha * b[i];
            for(k = begin; k < end-1; ++k) {
                Int j = l_column_indices[k];
                tmp_x -= x[j] * Conj::value(l_values[k]);
            }
            x[i] = tmp_x / Conj::value(l_values[end-1]);
        }
    }
}

template<typename DATA_T, typename Conj, typename Alpha = DATA_T>
static void trsv_execute_csc_upper(Alpha alpha, Matrix u, const DATA_T *b, DATA_T *x, const swSparseTRSVOptions* options) {
    const Int n = u->n;
    Int i;
    const Int *u_column_offsets = u->matrix.csrc->offsets;
    const Int *u_row_indices = u->matrix.csrc->indices;
    const DATA_T *u_values = (const DATA_T*)u->matrix.csrc->values;

    //swSparse_memcpy(x, b, n * sizeof(DATA_T));
    vector_scale(alpha, n, b, x); // x = alpha * b

    if((u->status & SWSPARSE_UNIT_DIAG) != 0) {

        for(i = n - 1; i >= 0; --i) {
            const Int begin = u_column_offsets[i], end = u_column_offsets[i+1];
            Int k;
            //x[i] = x[i];
            for(k = begin; k < end; ++k) {
                Int j = u_row_indices[k];
                x[j] -= x[i] * Conj::value(u_values[k]);
            }
        }
    } else if((u->status & SWSPARSE_RECP_DIAG) != 0) {

        for(i = n - 1; i >= 0; --i) {
            const Int begin = u_column_offsets[i], end = u_column_offsets[i+1]-1;
            Int k;
            x[i] = x[i] * Conj::value(u_values[end]);
            for(k = begin; k < end; ++k) {
                Int j = u_row_indices[k];
                x[j] -= x[i] * Conj::value(u_values[k]);
            }
        }
    } else {

        for(i = n - 1; i >= 0; --i) {
            const Int begin = u_column_offsets[i], end = u_column_offsets[i+1]-1;
            Int k;
            x[i] = x[i] / Conj::value(u_values[end]);
            for(k = begin; k < end; ++k) {
                Int j = u_row_indices[k];
                x[j] -= x[i] * Conj::value(u_values[k]);
            }
        }
    }
}

template<typename DATA_T, typename Conj, typename Alpha = DATA_T>
static void trsv_execute_csc_lower(Alpha alpha, Matrix l, const DATA_T *b, DATA_T *x, const swSparseTRSVOptions* options) {
    const Int n = l->n;
    Int i;
    const Int *l_column_offsets = l->matrix.csrc->offsets;
    const Int *l_row_indices = l->matrix.csrc->indices;
    const DATA_T *l_values = (const DATA_T*)l->matrix.csrc->values;
    
    //swSparse_memcpy(x, b, n * sizeof(DATA_T));
    vector_scale(alpha, n, b, x);

    if((l->status & SWSPARSE_UNIT_DIAG) != 0) {

        for(i = 0; i < n; ++i) {
            const Int begin = l_column_offsets[i], end = l_column_offsets[i+1];
            Int k;
            //x[i] = x[i];
            for(k = begin; k < end; ++k) {
                Int j = l_row_indices[k];
                x[j] -= x[i] * Conj::value(l_values[k]);
            }
        }
    } else if((l->status & SWSPARSE_RECP_DIAG) != 0) {

        for(i = 0; i < n; ++i) {
            const Int begin = l_column_offsets[i], end = l_column_offsets[i+1];
            Int k;
            x[i] = x[i] * Conj::value(l_values[begin]);
            for(k = begin + 1; k < end; ++k) {
                Int j = l_row_indices[k];
                x[j] -= x[i] * Conj::value(l_values[k]);
            }
        }
    } else {

        for(i = 0; i < n; ++i) {
            const Int begin = l_column_offsets[i], end = l_column_offsets[i+1];
            Int k;
            x[i] = x[i] / Conj::value(l_values[begin]);
            for(k = begin + 1; k < end; ++k) {
                Int j = l_row_indices[k];
                x[j] -= x[i] * Conj::value(l_values[k]);
            }
        }
    }
}

template<typename DATA_T>
INLINE ErrorStatus trsv_execute(DATA_T alpha, Matrix mat, const DATA_T *b, DATA_T *x, const swSparseTRSVOptions* options) {
    if(mat->m != mat->n) {
        DEBUG_PRINTF("error: The matrix is not square\n"); 
        return SWSPARSE_INVALID_ARGS;
    }
    if(mat->element_type != type_traits<DATA_T>::element_type) {
        DEBUG_PRINTF("error: The matrix element is not %s\n"); 
        return SWSPARSE_INVALID_ARGS;
    }
    using conj = conjugate<DATA_T>;
    using noconj = not_conjugate<DATA_T>;

    if(is_zero(alpha)) {
        swSparse_memset(x, 0, sizeof(DATA_T) * mat->m);
        return SWSPARSE_SUCCESS;
    }

    if(mat->status == SWSPARSE_LOWER_TRI) { // override
        switch(mat->format_type) {
        case CSC:
            trsv_execute_csc_lower<DATA_T, noconj>(alpha, mat, b, x, options);
            return SWSPARSE_SUCCESS;
        case CSR:
            trsv_execute_csr_lower<DATA_T, noconj>(alpha, mat, b, x, options);
            return SWSPARSE_SUCCESS;
        default:
            return SWSPARSE_INVALID_ARGS;
        }
    } else if((options->transpose & SWSPARSE_NON_TRANSPOSE) == SWSPARSE_NON_TRANSPOSE) {

        if((mat->status & SWSPARSE_UPPER_TRI)) {
            switch(mat->format_type) {
            case CSC:
                trsv_execute_csc_upper<DATA_T, noconj>(alpha, mat, b, x, options);
                return SWSPARSE_SUCCESS;
            case CSR:
                trsv_execute_csr_upper<DATA_T, noconj>(alpha, mat, b, x, options);
                return SWSPARSE_SUCCESS;
            default:
                return SWSPARSE_INVALID_ARGS;
            }

        } else if ((mat->status & SWSPARSE_LOWER_TRI)) {
            switch(mat->format_type) {
            case CSC:
                trsv_execute_csc_lower<DATA_T, noconj>(alpha, mat, b, x, options);
                return SWSPARSE_SUCCESS;
            case CSR:
                trsv_execute_csr_lower<DATA_T, noconj>(alpha, mat, b, x, options);
                return SWSPARSE_SUCCESS;
            default:
                return SWSPARSE_INVALID_ARGS;
            }
        } else {
            return SWSPARSE_INVALID_ARGS;
        }
    } else if((options->transpose & SWSPARSE_TRANSPOSE) == SWSPARSE_TRANSPOSE) {

        if((mat->status & SWSPARSE_UPPER_TRI)) {
            switch(mat->format_type) {
            case CSC:
                trsv_execute_csr_lower<DATA_T, noconj>(alpha, mat, b, x, options);
                return SWSPARSE_SUCCESS;
            case CSR:
                trsv_execute_csc_lower<DATA_T, noconj>(alpha, mat, b, x, options);
                return SWSPARSE_SUCCESS;
            default:
                return SWSPARSE_INVALID_ARGS;
            }

        } else if ((mat->status & SWSPARSE_LOWER_TRI)) {
            switch(mat->format_type) {
            case CSC:
                trsv_execute_csr_upper<DATA_T, noconj>(alpha, mat, b, x, options);
                return SWSPARSE_SUCCESS;
            case CSR:
                trsv_execute_csc_upper<DATA_T, noconj>(alpha, mat, b, x, options);
                return SWSPARSE_SUCCESS;
            default:
                return SWSPARSE_INVALID_ARGS;
            }
        } else {
            return SWSPARSE_INVALID_ARGS;
        }
    } else {
        DEBUG_PRINTF("error: invalid value of options.transpose in swSparse_%s_trsv.\n", type_traits<DATA_T>::name_short); 
        return SWSPARSE_INVALID_ARGS;
    }
}

template<typename DATA_T>
INLINE ErrorStatus trsm_execute(DATA_T alpha, Matrix mat, swSparseInt nvec, \
    const DATA_T *b, swSparseInt ldb, DATA_T *x, swSparseInt ldx, const swSparseTRSMOptions* options) {
    if(mat->m != mat->n) {
        DEBUG_PRINTF("error: The matrix is not square\n"); 
        return SWSPARSE_INVALID_ARGS;
    }
    if(mat->element_type != type_traits<DATA_T>::element_type) {
        DEBUG_PRINTF("error: The matrix element is not %s\n"); 
        return SWSPARSE_INVALID_ARGS;
    }
    swSparseTRSVOptions trsv_options;
    trsv_options.expected_ncall = options->expected_ncall;
    trsv_options.uplo           = options->uplo;
    trsv_options.transpose      = options->transpose;
    trsv_options.diagnal        = options->diagnal;

    for(Int i = 0; i < nvec; ++i) {
        trsv_execute<DATA_T>(alpha, mat, b + ldb * i, x + ldx * i, &trsv_options);
    }

    return SWSPARSE_SUCCESS;
}

} // namespcae swSparse

ErrorStatus swSparse_trsv_inspect(Matrix old_mat, Matrix *new_mat, Int *perm, Int *iperm, const swSparseTRSVOptions* options) {
    ErrorStatus ret;
    if(old_mat->m != old_mat->n) {
        DEBUG_PRINTF("The matirx must be square.\n");
        return SWSPARSE_INVALID_ARGS;
    }
    if(options->uplo != SWSPARSE_UPPER_TRI && options->uplo != SWSPARSE_LOWER_TRI) {
        DEBUG_PRINTF("The matrix should be upper tridiagnal or lower tridiagnal.\n");
        return SWSPARSE_INVALID_ARGS;
    }
    if(options->diagnal != SWSPARSE_GENERAL_DIAG && options->diagnal != SWSPARSE_UNIT_DIAG && 
       options->diagnal != SWSPARSE_RECP_DIAG) {
        DEBUG_PRINTF("The matrix diagnal option is invalid.\n");
        return SWSPARSE_INVALID_ARGS;
    }
    if(options->transpose != SWSPARSE_TRANSPOSE && options->transpose != SWSPARSE_NON_TRANSPOSE &&
       options->transpose != SWSPARSE_MAYBE_TRANSPOSE) {
        DEBUG_PRINTF("The matrix transpose option is invalid.\n");
        return SWSPARSE_INVALID_ARGS;
    }

    ret = swSparse_ensure_order(old_mat);
    if(ret == SWSPARSE_SUCCESS) {
        switch(old_mat->format_type) {
        case CSC:
            switch(old_mat->element_type) {
            case REAL_SINGLE:
                return swSparse::trsv_inspect_csc<float>(old_mat, new_mat, perm, iperm, options);
            case REAL_DOUBLE:
                return swSparse::trsv_inspect_csc<double>(old_mat, new_mat, perm, iperm, options);
            case COMPLEX_SINGLE:
                return swSparse::trsv_inspect_csc<SComplex>(old_mat, new_mat, perm, iperm, options);
            case COMPLEX_DOUBLE:
                return swSparse::trsv_inspect_csc<DComplex>(old_mat, new_mat, perm, iperm, options);
            }
        case CSR:
            switch(old_mat->element_type) {
            case REAL_SINGLE:
                return swSparse::trsv_inspect_csr<float>(old_mat, new_mat, perm, iperm, options);
            case REAL_DOUBLE:
                return swSparse::trsv_inspect_csr<double>(old_mat, new_mat, perm, iperm, options);
            case COMPLEX_SINGLE:
                return swSparse::trsv_inspect_csr<SComplex>(old_mat, new_mat, perm, iperm, options);
            case COMPLEX_DOUBLE:
                return swSparse::trsv_inspect_csr<DComplex>(old_mat, new_mat, perm, iperm, options);
            }
        default:
            return SWSPARSE_INVALID_ARGS;
        }
    } else {
        return ret;
    }
}

ErrorStatus swSparse_trsm_inspect(Matrix old_mat, Matrix *new_mat, Int *perm, Int *iperm, const swSparseTRSMOptions* options) {
    swSparseTRSVOptions trsv_options;
    trsv_options.expected_ncall = options->expected_ncall;
    trsv_options.transpose= options->transpose;
    trsv_options.uplo= options->uplo;
    trsv_options.diagnal= options->diagnal;

    return swSparse_trsv_inspect(old_mat, new_mat, perm, iperm, &trsv_options);
}

#define TRS_EXECUTE_CPP_TO_C(type, prefix) \
ErrorStatus prefix##trsv_execute(type alpha, Matrix mat, const type *b, type *x, const swSparseTRSVOptions* options) \
    { return swSparse::trsv_execute<type>(alpha, mat, b, x, options); } \
ErrorStatus prefix##trsm_execute(type alpha, Matrix mat, swSparseInt nvec, \
    const type *b, swSparseInt ldb, type *x, swSparseInt ldx, const swSparseTRSMOptions* options) \
    { return swSparse::trsm_execute<type>(alpha, mat, nvec, b, ldb, x, ldx, options); }

TRS_EXECUTE_CPP_TO_C(float, swSparse_s_)
TRS_EXECUTE_CPP_TO_C(double, swSparse_d_)
TRS_EXECUTE_CPP_TO_C(SComplex, swSparse_c_)
TRS_EXECUTE_CPP_TO_C(DComplex, swSparse_z_)
