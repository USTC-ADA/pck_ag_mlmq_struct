#include "internal/multicompile.h"

swSparseErrorStatus
FUNCNAME(struct_sptrsv_sequential_forward)(const DATA_T* a, DATA_T *x, const DATA_T* b, const int dim[3], int nnz, const int (*pos)[3])
{
	int i, j, k;
    int ti, tj, tk;
    int u;
    int M = dim[0], N = dim[1], L = dim[2];
    for (i = 0; i < M; i++)
    for (j = 0; j < N; j++)
    for (k = 0; k < L; k++)
    {
        DATA_T tmp = 0.0;
        int aoff = nnz * ((i)*(N)*(L) + (j)*(L) + (k));
        for (u = 0; u < nnz; u++)
        {
            ti = i + pos[u][0];
            tj = j + pos[u][1];
            tk = k + pos[u][2];
            if ((ti >= 0) && (ti < (M)) && (tj >= 0) && (tj < (N)) && (tk >= 0) && (tk < (L))) {
				tmp += a[aoff + u] * x[((ti)*(N)*(L) + (tj)*(L) + (tk))];
			
			}
        }
        x[((i)*(N)*(L) + (j)*(L) + (k))] = b[((i)*(N)*(L) + (j)*(L) + (k))]-tmp;
    }
	return SWSPARSE_SUCCESS; 
}

swSparseErrorStatus
FUNCNAME(struct_sptrsv_sequential_backward)(const DATA_T* a, DATA_T *x, const DATA_T* b, const int dim[3], int nnz, const int (*pos)[3])
{
	int i, j, k;
    int ti, tj, tk;
    int u;
    int M = dim[0], N = dim[1], L = dim[2];
    for (i = M-1; i >= 0; i--)
    for (j = N-1; j >= 0; j--)
    for (k = L-1; k >= 0; k--)
    {
		DATA_T para=1.0;
        DATA_T tmp = b[(i)*(N)*(L) + (j)*(L) + (k)];
        int aoff = nnz * ((i)*(N)*(L) + (j)*(L) + (k));
        for (u = 0; u < nnz; u++)
        {
            ti = i + pos[u][0];
            tj = j + pos[u][1];
            tk = k + pos[u][2];
            if ((ti >= 0) && (ti < (M)) && (tj >= 0) && (tj < (N)) && (tk >= 0) && (tk < (L))){
				if(ti==i && tj==j && tk==k)
				{
					para=a[aoff+u];
				}
				else{
				    DATA_T ttmp = a[aoff + u] * x[(ti)*(N)*(L) + (tj)*(L) + (tk)];
				    tmp -= ttmp;
        		}
			}
		}
	    x[(i)*(N)*(L) + (j)*(L) + (k)] =tmp;// para;
    }
	return SWSPARSE_SUCCESS;
}
