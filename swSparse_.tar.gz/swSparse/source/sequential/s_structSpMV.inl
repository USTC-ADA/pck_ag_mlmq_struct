#include "internal/multicompile.h"

SWSPARSE_API
FUNCNAME(struct_mv)(DATA_T alpha_, const DATA_T *a_, const DATA_T *x_, DATA_T beta_, DATA_T *y_, const swSparseInt *dim, swSparseInt nelem , const swSparseInt (*elem_pos)[3]){

    swSparseErrorStatus ret = SWSPARSE_SUCCESS;
    CONVERT_VALUE(alpha, alpha_)
    CONVERT_VALUE(beta, beta_)
    CONVERT_CPOINTER(a, a_)
    CONVERT_CPOINTER(x, x_)
    CONVERT_POINTER(y, y_)

    int i,j,k,p;
    int MM,NN,LL;
    int offset;
    int pos[3];
    CDATA_T result;

    MM = dim[0];
    NN = dim[1];
    LL = dim[2];

    for (i = 0 ; i <MM ; i++)
      for (j = 0 ; j < NN ; j++)
        for (k = 0 ; k < LL ; k++){
            result = ZERO;
            offset = nelem*(i*NN*LL+j*LL+k);
            for (p = 0 ; p < nelem ; p++){
                pos[0] = elem_pos[p][0];
                pos[1] = elem_pos[p][1];
                pos[2] = elem_pos[p][2];
                if ( (i+pos[0]>=0) && (i+pos[0]<MM) && (j+pos[1]>=0) && (j+pos[1]<NN) && (k+pos[2]>=0) && (k+pos[2]<LL) )
                   result += alpha * a[offset + p] * x[(i+pos[0])*NN*LL+(j+pos[1])*LL+(k+pos[2])];   
            }
            y[i*NN*LL+j*LL+k] = beta * y[i*NN*LL+j*LL+k] + result;    
        }

    return ret;
}