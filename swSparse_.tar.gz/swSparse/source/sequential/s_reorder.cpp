#include <algorithm>
#include "swSparse_base.h"
#include "swSparse_reorder.h"
#include "internal/rename.h"
#include "internal/utils.h"
#include "internal/reorder.h"
#include "internal/memory.h"
#include "internal/templates.h"
#include "internal/algorithm_sort.h"

ErrorStatus swSparse_perm_invert(Int n, const Int *perm, Int *iperm) {
    for(Int i = 0; i < n; ++i) {
        iperm[perm[i]] = i;
    }
    return SWSPARSE_SUCCESS;
}

void swSparse_create_id_perm(Int n, Int *perm) {
    for(Int i = 0; i < n; ++i) {
        perm[i] = i;
    }
}

namespace swSparse {

template<typename DATA_T>
INLINE void iperm_apply(Int n, const DATA_T *RSTR src, DATA_T *RSTR dst, const Int *RSTR iperm) {
    for(Int i = 0; i < n; ++i) {
        dst[iperm[i]] = src[i];
    }
}

template<typename DATA_T>
INLINE void perm_apply(Int n, const DATA_T *RSTR src, DATA_T *RSTR dst, const Int *RSTR perm) {
    for(Int i = 0; i < n; ++i) {
        dst[i] = src[perm[i]];
    }
}

template<typename DATA_T>
void csr423(Int first_dim, Int nnz, 
                    const Int *RSTR begins, const Int *RSTR ends, const Int *RSTR indices4, const DATA_T *RSTR values4,
                    Int *RSTR offsets, Int *RSTR indices3, DATA_T *RSTR values3) {
    Int i, j, k;
    offsets[0] = 0;
    for(i = 0; i < first_dim; ++i) {
        for(j = begins[i], k = offsets[i]; j < ends[i]; ++j, ++k) {
            indices3[k] = indices4[j];
            values3[k] = values4[j];
        }
        offsets[i+1] = k;
    }
}

template<typename DATA_T>
ErrorStatus csr423_perm(Int first_dim, Int nnz, 
                    const Int *RSTR begins, const Int *RSTR ends, const Int *RSTR indices4, const DATA_T *RSTR values4, const Int* RSTR iperm, 
                    Int *RSTR offsets, Int *RSTR indices3, DATA_T *RSTR values3) {
    Int i, j, k;
    offsets[0] = 0;
    for(i = 0; i < first_dim; ++i) {
        for(j = begins[i], k = offsets[i]; j < ends[i]; ++j, ++k) {
            indices3[k] = iperm[indices4[j]];
            values3[k] = values4[j];
        }
        offsets[i+1] = k;
        sort_index_value(indices3 + offsets[i], values3 + offsets[i], k - offsets[i]);
    }
    return SWSPARSE_SUCCESS;
}

template<typename DATA_T>
ErrorStatus sort_elements(Int first_dim, const Int *RSTR offsets,\
                             Int *RSTR indices, DATA_T *RSTR values) {
    int i;
    for(i = 0; i < first_dim; ++i) {
        sort_index_value(indices + offsets[i], values + offsets[i], offsets[i+1] - offsets[i]);
    }
    return SWSPARSE_SUCCESS;
}

void sort_int(Int *a, Int n) {
    //swSparse::sort_index_value(a, dummy_ptr, n);
    std::sort(a, a + n);
}

ErrorStatus sort_elements_in_pattern(Int first_dim, const Int *RSTR offsets, Int *RSTR indices) {
    int i;
    for(i = 0; i < first_dim; ++i) {
        sort_int(indices + offsets[i], offsets[i+1] - offsets[i]);
    }
    return SWSPARSE_SUCCESS;
}

#define EXPORT_TEMPLATE(type) \
template ErrorStatus sort_elements<type>(Int a, const Int *b, Int *c, type *d); \
template void csr423<type>(Int a, Int b,  const Int *c, const Int *d, const Int *e, const type *f, Int *g, Int *h, type *i); \
template ErrorStatus csr423_perm<type>(Int a, Int b,  const Int *c, const Int *d, const Int *e, const type *f, const Int* p, Int *g, Int *h, type *i);

EXPORT_TEMPLATE(float)
EXPORT_TEMPLATE(double)
EXPORT_TEMPLATE(SComplex)
EXPORT_TEMPLATE(DComplex)

static Int count_levels(Int size, const Int* RSTR old_levels, Int* RSTR counter) {
    Int max_levels = 0;
    swSparse_memset(counter, 0, sizeof(Int) * size);
    for(int i = 0; i < size; ++i) {
        counter[old_levels[i]]++;
        max_levels = max(max_levels, old_levels[i]);
    }
    return max_levels;
}

ErrorStatus sort_levels(Int size, const Int* RSTR old_levels, const Int *RSTR old_indices, Int* RSTR new_levels, Int* RSTR new_indices) {
    Int max_levels;
    Int *counter = (Int*)swSparse_malloc(sizeof(Int) * size);
    IF_ERR(counter == nullptr) {
        return MALLOC_ERROR;
    }
    max_levels = count_levels(size, old_levels, counter);
    for(int level = 0, prefix = 0; level <= max_levels; ++level) {
        Int current = counter[level];
        counter[level] = prefix;
        prefix += current;
    }
    for(int i = 0; i < size; ++i) {
        Int new_position = counter[old_levels[i]]++;
        new_indices[new_position] = old_indices[i];
    }
    swSparse_free(counter);
    return SWSPARSE_SUCCESS;
}

ErrorStatus sort_levels_reverse(Int size, const Int* RSTR old_levels, const Int *RSTR old_indices, Int* RSTR new_levels, Int* RSTR new_indices) {
    Int max_levels;
    Int *counter = (Int*)swSparse_malloc(sizeof(Int) * size);
    IF_ERR(counter == nullptr) {
        return MALLOC_ERROR;
    }
    max_levels = count_levels(size, old_levels, counter);
    for(int level = 0, prefix = 0; level <= max_levels; ++level) {
        Int current = counter[level];
        prefix += current;
        counter[level] = prefix;
    }
    for(int i = 0; i < size; ++i) {
        Int new_position = --counter[old_levels[i]];
        new_indices[new_position] = old_indices[i];
    }
    swSparse_free(counter);
    return SWSPARSE_SUCCESS;
}

} // namespace swSparse

// convert template functions to C functions
#define PERM_CPP_TO_C(type, prefix) \
ErrorStatus prefix##perm_apply(Int n, const type *RSTR src, type *RSTR dst, const Int *RSTR perm) \
    { swSparse::perm_apply<type>(n, src, dst, perm); return SWSPARSE_SUCCESS; } \
ErrorStatus prefix##iperm_apply(Int n, const type *RSTR src, type *RSTR dst, const Int *RSTR iperm) \
    { swSparse::iperm_apply<type>(n, src, dst, iperm); return SWSPARSE_SUCCESS;  }
PERM_CPP_TO_C(float, swSparse_s_)
PERM_CPP_TO_C(double, swSparse_d_)
PERM_CPP_TO_C(SComplex, swSparse_c_)
PERM_CPP_TO_C(DComplex, swSparse_z_)
PERM_CPP_TO_C(Int, swSparse_i_)
