#include "swSparse_blas.h"
#include "swSparse_matrix.h"
#include "internal/rename.h"
#include "internal/spblas_common.h"
#include "internal/templates.h"
#include "internal/memory.h"
#include "internal/debug.h"
#include "internal/utils.h"
#include "internal/reorder.h"
#include "swSparse_options.h"




// ErrorStatus swSparse_mm_inspect(Matrix old_mat, Matrix *new_mat,const swSparseMMOptions* options) {
//     switch(old_mat->format_type) {
//     case CSR:
//         return swSparse_copy(old_mat, new_mat);
//     default:
//         return SWSPARSE_INVALID_ARGS;
//     }
// }

namespace swSparse {

template<typename DATA_T , typename Conj>
ErrorStatus mv_execute_csr(const int m , const int n , DATA_T alpha , MatrixCSRC *mat, const DATA_T *x, DATA_T beta , DATA_T *y , const swSparseMVOptions* options){
    
    Int i, p;
    const Int *offsets = mat->offsets;
    const Int *indices = mat->indices;
    DATA_T *values = VALUES(mat, DATA_T);
    
    swSparseErrorStatus ret = SWSPARSE_SUCCESS;
    
    if ( (options->transpose & SWSPARSE_NON_TRANSPOSE ) == SWSPARSE_NON_TRANSPOSE){
        DATA_T y_tmp = 0;
        for(i = 0; i < m; ++i) {
            y_tmp = 0;
            for(p = offsets[i]; p < offsets[i+1]; ++p) {
                Int j = indices[p];
                y_tmp += x[j] * alpha * Conj::value(values[p]);
            }
            y[i] = beta * y[i] + y_tmp;
        }
    }
    else if ( (options->transpose & SWSPARSE_TRANSPOSE ) == SWSPARSE_TRANSPOSE ){
        DATA_T y_tmp = 0;
        for(i = 0; i < n; ++i) {
            y_tmp = 0;
            for(p = offsets[i]; p < offsets[i+1]; ++p) {
                Int j = indices[p];
                y_tmp += x[i] * alpha * Conj::value(values[p]);
            }
            y[i] = beta * y[i] + y_tmp;
        }
    }
    else if ( (options->symmetry & SWSPARSE_SYMMETRIC ) == SWSPARSE_SYMMETRIC ){
        swSparse::vector_scale(beta, m, y, y);
        for(i = 0; i < m; ++i) {
            for(p = offsets[i]; p < offsets[i+1]; ++p) {
                Int j = indices[p];
                y[i] += x[j] * alpha * Conj::value(values[p]);
                if(i != j) {
                    y[j] += x[i] * alpha * Conj::value(values[p]);
                }
            }
        }
    }  

    return ret;
}


template ErrorStatus mv_execute_csr<float,ID>(const int m , const int n ,float alpha , MatrixCSRC *mat, const float *x, float beta , float *y , const swSparseMVOptions* options);
template ErrorStatus mv_execute_csr<double,ID>(const int m , const int n ,double alpha , MatrixCSRC *mat, const double *x, double beta , double *y , const swSparseMVOptions* options);
template ErrorStatus mv_execute_csr<SComplex,ID>(const int m , const int n ,SComplex alpha , MatrixCSRC *mat, const SComplex *x, SComplex beta , SComplex *y , const swSparseMVOptions* options);
template ErrorStatus mv_execute_csr<DComplex,ID>(const int m , const int n ,DComplex alpha , MatrixCSRC *mat, const DComplex *x, DComplex beta , DComplex *y , const swSparseMVOptions* options);
template ErrorStatus mv_execute_csr<SComplex,CJ>(const int m , const int n ,SComplex alpha , MatrixCSRC *mat, const SComplex *x, SComplex beta , SComplex *y , const swSparseMVOptions* options);
template ErrorStatus mv_execute_csr<DComplex,CJ>(const int m , const int n ,DComplex alpha , MatrixCSRC *mat, const DComplex *x, DComplex beta , DComplex *y , const swSparseMVOptions* options);
} //namespace 
