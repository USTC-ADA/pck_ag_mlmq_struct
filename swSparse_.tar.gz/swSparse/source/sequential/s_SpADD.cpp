#include "swSparse_blas.h"
#include "internal/rename.h"
#include "internal/spblas_common.h"
#include "internal/templates.h"
#include "internal/memory.h"
#include "internal/debug.h"
#include "internal/utils.h"
#include "internal/reorder.h"

namespace swSparse {

template<typename DATA_T, typename ConjA, typename ConjB>
ErrorStatus add_csr_kernel( \
    DATA_T alpha, DATA_T beta, Int m, Int n, \
    MatrixCSRC *a, MatrixCSRC *b, MatrixCSRC *c) {
    Int annz = a->indices[m + 1], bnnz = b->indices[m + 1];
    DATA_T *va = (DATA_T*)a->values, *vb = (DATA_T*)b->values;
    DATA_T *c_val = (DATA_T*)swSparse_malloc(sizeof(DATA_T)*(annz + bnnz));
    Int *c_indx = (Int*)swSparse_malloc(sizeof(Int)*(annz + bnnz));
    Int *c_off = (Int*)swSparse_malloc(sizeof(Int)*(m+1));
    Int c_nnz = 0;
    c_off[0] = 0;
    int i, j;
    for (i = 0; i < m; i++)
    {
        int aj = a->offsets[i], ae = a->offsets[i+1];
        int bj = b->offsets[i], be = b->offsets[i+1];
        while (aj < ae && bj < be)
        {
            if (a->indices[aj] == b->indices[bj])
            {
                c_indx[c_nnz] = a->indices[aj];
                c_val[c_nnz] = alpha * ConjA::value(va[aj]) + beta * ConjB::value(vb[bj]);
                c_nnz++;
                aj++;
                bj++;
            }
            else if (a->indices[aj] < b->indices[bj])
            {
                c_indx[c_nnz] = a->indices[aj];
                c_val[c_nnz] = alpha * ConjA::value(va[aj]);
                c_nnz++;
                aj++;
            }
            else
            {
                c_indx[c_nnz] = b->indices[bj];
                c_val[c_nnz] = beta * ConjB::value(vb[bj]);
                c_nnz++;
                bj++;
            }
        }
        while (aj < ae)
        {
            c_indx[c_nnz] = a->indices[aj];
            c_val[c_nnz] = alpha * ConjA::value(va[aj]);
            c_nnz++;
            aj++;
        }
        while (bj < be)
        {
            c_indx[c_nnz] = b->indices[bj];
            c_val[c_nnz] = beta * ConjB::value(vb[bj]);
            c_nnz++;
            bj++;
        }
        c_off[i+1] = c_nnz;
    }
    c_val = (DATA_T*)shrink_alloc(c_val, c_nnz * sizeof(DATA_T), (a_nnz + b_nnz) * sizeof(DATA_T));
    c_indx = (Int*)shrink_alloc(c_indx, c_nnz * sizeof(Int), (a_nnz + b_nnz) * sizeof(Int));
    c->values = (void*)c_val;
    c->indices = c_indx;
    c->offsets = c_off;
    //c->ref_count = 1;
    c->ordered = true;

    return SWSPARSE_SUCCESS;
}

template<typename DATA_T>
ErrorStatus add_csr( \
    DATA_T alpha, DATA_T beta, Int m, Int n, \
    MatrixCSRC *a, MatrixCSRC *b, MatrixCSRC *c, Bool a_conj, Bool b_conj) {
    
    if(!a->ordered) {
        ErrorStatus ret = sort_elements(m, a->offsets, a->indices, VALUES(a, DATA_T));
        IF_ERR(ret != SWSPARSE_SUCCESS) {
            return ret;
        } else {
            a->ordered = true;
        }
    }
    if(!b->ordered) {
        ErrorStatus ret = sort_elements(m, b->offsets, b->indices, VALUES(b, DATA_T));
        IF_ERR(ret != SWSPARSE_SUCCESS) {
            return ret;
        } else {
            b->ordered = true;
        }
    }
    using conj = conjugate<DATA_T>;
    using noconj = not_conjugate<DATA_T>;
    if (a_conj && b_conj) return add_csr_kernel<DATA_T, conj, conj>(alpha, beta, m, n, a, b, c);
    if (!a_conj && b_conj) return add_csr_kernel<DATA_T, noconj, conj>(alpha, beta, m, n, a, b, c);
    if (a_conj && !b_conj) return add_csr_kernel<DATA_T, conj, noconj>(alpha, beta, m, n, a, b, c);
    if (!a_conj && !b_conj) return add_csr_kernel<DATA_T, noconj, noconj>(alpha, beta, m, n, a, b, c);
    return SWSPARSE_INVALID_ARGS;
}

template ErrorStatus add_csr<float>(float alpha, float beta, Int m, Int n, \
    MatrixCSRC *a, MatrixCSRC *b, MatrixCSRC *c, Bool a_conj, Bool b_conj);
template ErrorStatus add_csr<double>(double alpha, double beta, Int m, Int n, \
    MatrixCSRC *a, MatrixCSRC *b, MatrixCSRC *c, Bool a_conj, Bool b_conj);
template ErrorStatus add_csr<SComplex>(SComplex alpha, SComplex beta, Int m, Int n, \
    MatrixCSRC *a, MatrixCSRC *b, MatrixCSRC *c, Bool a_conj, Bool b_conj);
template ErrorStatus add_csr<DComplex>(DComplex alpha, DComplex beta, Int m, Int n, \
    MatrixCSRC *a, MatrixCSRC *b, MatrixCSRC *c, Bool a_conj, Bool b_conj);

} // namespace swSparse