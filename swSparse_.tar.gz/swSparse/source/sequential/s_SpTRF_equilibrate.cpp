#include<cmath>
#include<limits>
#include"internal/memory.h"
#include"internal/templates.h"
#include"internal/sptrf_common.h"

namespace swSparse {

template<typename REAL_T>
void ewise_exp(Int n, REAL_T* RSTR x, REAL_T* RSTR y) {
    for(Int i = 0; i < n; ++i) {
        x[i] = std::exp(x[i]);
        y[i] = std::exp(y[i]);
    }
}

template<typename DATA_T>
void ewise_mul(Int n, const DATA_T* y, DATA_T* z, const real_t<DATA_T>* x) {
    for(Int i = 0; i < n; ++i) {
        z[i] = y[i] * x[i];
    }
}

template<typename DATA_T>
real_t<DATA_T> mc64_preprocess(Int n, Int nnz, const Int* RSTR offsets, const DATA_T* x, real_t<DATA_T>* y, real_t<DATA_T>* col_max) {    
    constexpr real_t<DATA_T> neg_inf = std::numeric_limits<real_t<DATA_T>>::lowest();
    real_t<DATA_T> nrm = 0;
    for(Int i = 0; i < n; ++i) {
        real_t<DATA_T> s = 0, cmax = neg_inf;
        for(Int p = offsets[i]; p < offsets[i + 1]; ++p) {
            real_t<DATA_T> mag = fabs(x[p]);
            real_t<DATA_T> logmag = is_zero(mag) ? neg_inf : std::log(mag);
            s += mag;
            cmax = (cmax > logmag) ? cmax : logmag;
            y[p] = logmag;
        }
        col_max[i] = cmax;
        nrm = (nrm > s) ? nrm : s;
    }
    return nrm;
}

// returns the 1-norm
template<typename DATA_T>
real_t<DATA_T> norm_1_sparse_rescale_colmax(Int n, Int nnz, const Int* RSTR offsets, const Int* RSTR indices, \
    const DATA_T* RSTR src, DATA_T* RSTR dst, const real_t<DATA_T>* RSTR rscale, real_t<DATA_T>* RSTR cscale) {
	real_t<DATA_T> norm_1 = 0;
	for(Int i = 0; i < n; ++i) {
		real_t<DATA_T> sum = 0, m = 0;
		for(Int p = offsets[i]; p < offsets[i + 1]; ++p) {
			DATA_T rs = src[p] * rscale[indices[p]];
			real_t<DATA_T> rsabs = fabs(rs);
			dst[p] = rs;
			m = (m > rsabs) ? m : rsabs;
			sum += rsabs;
		}
		if(m == 0.0) {
			return 0.0;
		}
		m = reciprocal(m);
		cscale[i] = m;
		sum *= m;
		for(Int p = offsets[i]; p < offsets[i + 1]; ++p) {
			dst[p] = dst[p] * m;
		}
		norm_1 = (norm_1 > sum) ? norm_1 : sum;
	}
	return norm_1;
}

// returns the 1-norm
template<typename DATA_T>
real_t<DATA_T> norm_1_sparse_scale(Int n, Int nnz, const Int* RSTR offsets, const Int* RSTR indices, \
    const DATA_T* RSTR src, DATA_T* RSTR dst, const real_t<DATA_T>* RSTR rscale, const real_t<DATA_T>* RSTR cscale) {
	real_t<DATA_T> norm_1 = 0;
	for(Int i = 0; i < n; ++i) {
		real_t<DATA_T> sum = 0;
		for(Int p = offsets[i]; p < offsets[i + 1]; ++p) {
			dst[p] = src[p] * (rscale[indices[p]] * cscale[i]);
			sum += fabs(dst[p]);
		}
		norm_1 = (norm_1 > sum) ? norm_1 : sum;
	}
	return norm_1;
}


#define EXPORT_TEMPLATES(type)  \
template void ewise_mul<type>(Int n, const type* RSTR y, type* RSTR z, const real_t<type>* RSTR x); \
template real_t<type> mc64_preprocess<type>(Int n, Int nnz, const Int* RSTR offsets, const type* x, real_t<type>* y, real_t<type>* z); \
template real_t<type> norm_1_sparse_rescale_colmax(Int n, Int nnz, const Int* RSTR offsets, const Int* RSTR indices, \
    const type* RSTR src, type* RSTR dst, const real_t<type>* RSTR rscale, real_t<type>* RSTR cscale); \
template real_t<type> norm_1_sparse_scale(Int n, Int nnz, const Int* RSTR offsets, const Int* RSTR indices, \
    const type* RSTR src, type* RSTR dst, const real_t<type>* RSTR rscale, const real_t<type>* RSTR cscale);

EXPORT_TEMPLATES(float)
EXPORT_TEMPLATES(double)
EXPORT_TEMPLATES(SComplex)
EXPORT_TEMPLATES(DComplex)

template void ewise_exp<float>(Int n, float* RSTR x, float* RSTR y);
template void ewise_exp<double>(Int n, double* RSTR x, double* RSTR y);


void index_shift(Int n, const Int* in_index, Int *out_index, Int delta) {
    for(Int i = 0; i < n; ++i) {
        out_index[i] = in_index[i] + delta;
    }
}

}