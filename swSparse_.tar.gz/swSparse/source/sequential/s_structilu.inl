#include "internal/multicompile.h"

swSparseErrorStatus
FUNCNAME(struct_ilu)(swSparseInt iluk, const DATA_T *a, DATA_T *l, DATA_T *u, \
                    const swSparseInt *dim, swSparseInt npoints, \
                    const swSparseInt (*stencil)[3], const swSparseTRFOptions *options)
{
	if (iluk == 0 && options->symmetry != SWSPARSE_SYMMETRIC)
	{
		return swSparse::struct_ilu0_nonsymm<DATA_T>(a, l, u, dim[0], dim[1], dim[2], npoints, stencil);
	}
	if (iluk == 0 && options->symmetry == SWSPARSE_SYMMETRIC)
	{
		return swSparse::struct_ilu0_symm<DATA_T>(a, l, u, dim[0], dim[1], dim[2], npoints, stencil);
	}
	if (iluk == 1 && options->symmetry != SWSPARSE_SYMMETRIC)
	{
		return swSparse::struct_ilu1_nonsymm<DATA_T>(a, l, u, dim[0], dim[1], dim[2], npoints, stencil);
	}
	if (iluk == 1 && options->symmetry == SWSPARSE_SYMMETRIC)
	{
		return swSparse::struct_ilu1_symm<DATA_T>(a, l, u, dim[0], dim[1], dim[2], npoints, stencil);
	}
	return SWSPARSE_INVALID_ARGS;
}