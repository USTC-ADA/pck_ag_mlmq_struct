#include "swSparse_base.h"
#include "swSparse_matrix.h"
#include "internal/rename.h"
#include "internal/memory.h"
#include "internal/reorder.h"
#include "internal/templates.h"

namespace swSparse {

template<typename DATA_T>
ErrorStatus transpose_csr(Int m, Int n, Int nnz, \
               const Int * RSTR a_row_offsets, const Int * RSTR a_column_indices, const DATA_T * RSTR a_values, \
               Int * RSTR at_row_offsets, Int * RSTR at_column_indices, DATA_T * RSTR at_values) {
    Int *at_row_ends = at_row_offsets + 1;
    Int a_nonzero, a_row, at_row, prefix;

    swSparse_memset(at_row_offsets, 0, sizeof(Int) * (n + 1));
    for(a_nonzero = 0; a_nonzero < nnz; ++ a_nonzero) {
        ++ at_row_ends[a_column_indices[a_nonzero]];
    }

    prefix = 0;
    for(at_row = 0; at_row < n; ++at_row) {
        Int next = prefix + at_row_ends[at_row];
        at_row_ends[at_row] = prefix;
        prefix = next;
    }

    for(a_row = 0; a_row < m; ++a_row) {
        for(a_nonzero = a_row_offsets[a_row]; a_nonzero < a_row_offsets[a_row+1]; ++ a_nonzero) {
            Int at_nonzero = at_row_ends[a_column_indices[a_nonzero]] ++;
            at_column_indices[at_nonzero] = a_row;
            at_values[at_nonzero] = a_values[a_nonzero];
        }
    }
    return SWSPARSE_SUCCESS;
}

template<typename DATA_T>
ErrorStatus convert_coo2csr(Int m, Int n, Int nnz, \
               const Int *RSTR row_indices, const Int *RSTR coo_column_indices, const DATA_T *coo_values, \
               Int *RSTR row_offsets, Int *RSTR csr_column_indices, DATA_T *csr_values) {
    Int *RSTR row_ends = row_offsets + 1;
    Int coo_nonzero, row, prefix;

    swSparse_memset(row_offsets, 0, sizeof(Int) * (m + 1));
    for(coo_nonzero = 0; coo_nonzero < nnz; ++ coo_nonzero) {
        ++ row_ends[row_indices[coo_nonzero]];
    }

    prefix = 0;
    for(row = 0; row < m; ++row) {
        Int next = prefix + row_ends[row];
        row_ends[row] = prefix;
        prefix = next;
    }

    for(coo_nonzero = 0; coo_nonzero < nnz; ++ coo_nonzero) {
        Int csr_nonzero = row_ends[row_indices[coo_nonzero]] ++;
        csr_column_indices[csr_nonzero] = coo_column_indices[coo_nonzero];
        csr_values[csr_nonzero] = coo_values[coo_nonzero];
    }
    sort_elements(m, row_offsets, csr_column_indices, csr_values);
    return SWSPARSE_SUCCESS;
}

void convert_csr2coo(Int m, Int *RSTR row_offsets, Int *RSTR row_indices) {
    Int row, nonzero;
    for(row = 0; row < m; ++row) {
        for(nonzero = row_offsets[row]; nonzero < row_offsets[row+1]; ++nonzero) {
            row_indices[nonzero] = row;
        }
    }
}

#define EXPORT_TEMPLATES(type) \
template ErrorStatus transpose_csr<type>(Int a, Int b, Int c, const Int* RSTR d, const Int* RSTR e, const type* RSTR f, Int* RSTR g, Int* RSTR h, type* RSTR i); \
template ErrorStatus convert_coo2csr<type>(Int a, Int b, Int c, const Int* RSTR d, const Int* RSTR e, const type* RSTR f, Int* RSTR g, Int* RSTR h, type* RSTR i);

EXPORT_TEMPLATES(float)
EXPORT_TEMPLATES(double)
EXPORT_TEMPLATES(SComplex)
EXPORT_TEMPLATES(DComplex)

}  // namespace swSparse