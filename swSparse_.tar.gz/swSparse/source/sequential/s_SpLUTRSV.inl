#include "internal/multicompile.h"

ErrorStatus FUNCNAME(lutrsv)(Int n, swSparseMatrix *lu, const DATA_T* b, DATA_T *x, \
        Int* riperm, Int* ciperm, const REAL_T* rscale, const REAL_T* cscale) {
	return swSparse::lutrsv<DATA_T>(n, lu, b, x, riperm, ciperm, rscale, cscale);
}