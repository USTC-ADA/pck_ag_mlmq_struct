#include <sys/time.h>
#include "swSparse_splutrsv.h"
#include "internal/rename.h"
#include "internal/memory.h"
#include "internal/templates.h"
#include "internal/splutrsv_param.h"

#ifdef LUTRSV_STATISTIC
#define DECL_TIMER struct timeval begin, end;
#define TIMER_BEGIN gettimeofday(&begin, nullptr);
#define TIMER_END   gettimeofday(&end, nullptr);

struct LUTRSV_STATISTICS {
	double time_[LUTRSV_STAGE_NUM];
    const char * const swSparse_lutrsv_timing_names_[LUTRSV_STAGE_NUM] = {
        "lutrsv_preprocess", "lutrsv_lsolve", "lutrsv_usolve"
    };
	int64_t lmemory_, lflop_, umemory_, uflop_;
	LUTRSV_STATISTICS() {
		memset(time_, 0, sizeof(time_));
        lflop_ = 0;
        uflop_ = 0;
        lmemory_ = 0;
        umemory_ = 0;
	}
    void set_time(const struct timeval* begin, const struct timeval* end, int stage) {
		time_[stage] = 1e3 * (end->tv_sec - begin->tv_sec) + 1e-3 * (end->tv_usec - begin->tv_usec);
	}
	void add_time(const struct timeval* begin, const struct timeval* end, int stage) {
		time_[stage] += 1e3 * (end->tv_sec - begin->tv_sec) + 1e-3 * (end->tv_usec - begin->tv_usec);
	}
    // 前代回代之后再调用此函数，确保静态调度成功
    void get_flop_and_memory(Int n, swSparseMatrix *lu, size_t size_of_type) {
        swSparseLUSupernodes* lusup = (*lu)->matrix.lusuper;
        // flop
        Int* sup2col = lusup->sup2col;
        Int* col2sup = lusup->col2sup;
        Int* l_v_offsets = lusup->l_v_offsets;
        Int* l_i_offsets = lusup->l_i_offsets;
        Int* u_seg_offsets = lusup->u_seg_offsets;
        Int* u_col_offsets = lusup->u_col_offsets;
        Int nsup = lusup->nsuper;
        Int lnnz = l_v_offsets[nsup], unnz = u_seg_offsets[u_col_offsets[n]];
        int64_t uflop = (lnnz << 1), lflop = (unnz << 1);    
        for(Int i = 0; i < nsup; ++i) {
            Int j_sup_begin = sup2col[i], j_sup_end = sup2col[i+1];
            Int supsize = j_sup_end - j_sup_begin;
            int64_t _tmp = (supsize + 1) * supsize;
            uflop -= _tmp;
            lflop += (_tmp - supsize);
        }
        lflop_ = lflop;
        uflop_ = uflop;

        // memory
        lmemory_ = (nsup + 1) * sizeof(Int) * 3;   // sup2col, l_i_offsets, l_v_offsets
        lmemory_ += (n + 1) * sizeof(Int); // u_col_offsets
        lmemory_ += u_col_offsets[n] * sizeof(Int) * 2;  // u_seg_offsets, u_seg_indices
        lmemory_ += ((lflop + n) >> 1) * size_of_type;

        umemory_ = (nsup + 1) * sizeof(Int) * 3;   // sup2col, l_i_offsets, l_v_offsets
        umemory_ += l_i_offsets[nsup] * sizeof(Int); // l_indice
        umemory_ += (uflop >> 1) * size_of_type;
    }
	void print() const {
		for(int i = 0; i < 3; ++ i) {
			const char* name = swSparse_lutrsv_timing_names_[i];
			printf("%18s time: %.3lf ms\n", name, time_[i]);
		}
        printf("lutrsv lflop: %lld, lmemeory: %lld, uflop: %lld, umemory: %lld\n", \
            lflop_, lmemory_, uflop_, umemory_);
	}
};

static LUTRSV_STATISTICS swSparse_lutrsv_stat;
void swSparse_lutrsv_get_flop_and_memory(Int n, swSparseMatrix* lu, size_t size_of_type) {
	swSparse_lutrsv_stat.get_flop_and_memory(n, lu, size_of_type);
}
void swSparse_print_lutrsv_info() { swSparse_lutrsv_stat.print(); }

#else
#define DECL_TIMER
#define TIMER_BEGIN
#define TIMER_END
#endif


namespace swSparse {

template <typename DATA_T>
ErrorStatus lutrsv(Int n, swSparseMatrix *lu, const DATA_T* b, DATA_T *x, Int* riperm, Int* ciperm, const real_t<DATA_T>* rscale, const real_t<DATA_T>* cscale)
{   
    size_t malloc_size = sizeof(DATA_T) * n;
    DATA_T* work = (DATA_T*)swSparse_malloc(malloc_size);
    IF_ERR(work == nullptr) {
        return SWSPARSE_MALLOC_ERROR;
    }

    if constexpr (std::is_same<DATA_T, float>::value) {
        swSparse_s_elementwise_multiply(n, b, work, cscale);
        swSparse_s_iperm_apply(n, work, x, ciperm);
    } else if constexpr (std::is_same<DATA_T, double>::value) { 
        swSparse_d_elementwise_multiply(n, b, work, cscale);
        swSparse_d_iperm_apply(n, work, x, ciperm);
    } else if constexpr (std::is_same<DATA_T, SComplex>::value) { 
        swSparse_c_elementwise_multiply(n, b, work, cscale);
        swSparse_c_iperm_apply(n, work, x, ciperm);
    } else if constexpr (std::is_same<DATA_T, DComplex>::value) { 
        swSparse_z_elementwise_multiply(n, b, work, cscale);
        swSparse_z_iperm_apply(n, work, x, ciperm);
    } else {                                   
        printf("Unsupported type\n");
        return SWSPARSE_NOT_SUPPORTED;
    }

#ifdef LUTRSV_STATISTIC    
    DECL_TIMER
    TIMER_BEGIN
#endif
    swSparseLUSupernodes* lusup = (*lu)->matrix.lusuper; 
    Int nsup = lusup->nsuper;
    DATA_T *l_values = static_cast<DATA_T*>(lusup->l_values); 
    Int *l_indices = lusup->l_indices;
    Int *l_i_offsets = lusup->l_i_offsets;
    Int *l_v_offsets = lusup->l_v_offsets;
    Int *sup2col = lusup->sup2col;
    DATA_T *u_values = static_cast<DATA_T*>(lusup->u_values);
    Int *u_col_offsets = lusup->u_col_offsets;
    Int *u_seg_offsets = lusup->u_seg_offsets;
    Int *u_seg_indices = lusup->u_seg_indices;

    for(Int jsup = 0; jsup < nsup; ++jsup) {
        Int p, k, j_sup_begin = sup2col[jsup], j_sup_end = sup2col[jsup + 1], supsize = j_sup_end - j_sup_begin;
        Int v_off = l_v_offsets[jsup];
        Int ld = l_i_offsets[jsup + 1] - l_i_offsets[jsup] + supsize;
        const DATA_T* l_sup_val = &l_values[v_off];
        for(Int j = j_sup_begin; j < j_sup_end; ++j) {
            for(k = u_col_offsets[j]; k < u_col_offsets[j + 1]; ++k) {  // off-diagnal block
                Int segoff = u_seg_offsets[k], segsize = u_seg_offsets[k + 1] - segoff;
                Int segrep = u_seg_indices[k];
                for(p = 0; p < segsize; ++p) {
                    x[j] -= u_values[segoff + p] * x[segrep + p];
                }
            }
            Int jrel = j - j_sup_begin;
            const DATA_T* l_row_val = &l_sup_val[jrel * ld];
            for(p = 0; p < jrel; ++p) {                    // diagnal block
                x[j] -= l_row_val[p] * x[j_sup_begin + p];
            }
            x[j] = x[j] * l_row_val[jrel];                // reciprocal diagnal
        }
    }
#ifdef LUTRSV_STATISTIC
    TIMER_END
    swSparse_lutrsv_stat.set_time(&begin, &end, LUTRSV_LSOLVE);
    TIMER_BEGIN
#endif
    for(Int jsup = nsup - 1; jsup >= 0; --jsup) {
        Int p, j_sup_begin = sup2col[jsup], j_sup_end = sup2col[jsup + 1], supsize = j_sup_end - j_sup_begin;
        Int v_off = l_v_offsets[jsup], i_off = l_i_offsets[jsup] - supsize;
        Int ld = l_i_offsets[jsup + 1] - i_off;
        const DATA_T* l_sup_val = &l_values[v_off];
        const Int *l_sup_idx = &l_indices[i_off];

        for(Int j = j_sup_end - 1; j >= j_sup_begin; --j) {
            Int jrel = j - j_sup_begin;
            const DATA_T* l_row_val = &l_sup_val[jrel * ld];
            for(p = supsize; p < ld; ++p) {        // off-diagnal block
                x[j] -= l_row_val[p] * x[l_sup_idx[p]];
            }
            for(p = jrel + 1; p < supsize; ++p) {  // diagnal block
                x[j] -= l_row_val[p] * x[j_sup_begin + p];
            }
        }
    }
#ifdef LUTRSV_STATISTIC
    TIMER_END
    swSparse_lutrsv_stat.set_time(&begin, &end, LUTRSV_USOLVE);
#endif

    if constexpr (std::is_same<DATA_T, float>::value) {
        swSparse_s_perm_apply(n, x, work, riperm);
        swSparse_s_elementwise_multiply(n, work, x, rscale);
    } else if constexpr (std::is_same<DATA_T, double>::value) { 
        swSparse_d_perm_apply(n, x, work, riperm);
        swSparse_d_elementwise_multiply(n, work, x, rscale);
    } else if constexpr (std::is_same<DATA_T, SComplex>::value) { 
        swSparse_c_perm_apply(n, x, work, riperm);
        swSparse_c_elementwise_multiply(n, work, x, rscale);
    } else if constexpr (std::is_same<DATA_T, DComplex>::value) { 
        swSparse_z_perm_apply(n, x, work, riperm);
        swSparse_z_elementwise_multiply(n, work, x, rscale);
    } else {                                   
        printf("Unsupported type\n");
        return SWSPARSE_NOT_SUPPORTED;
    }

    swSparse_free(work);
    return SWSPARSE_SUCCESS;
}

} // namespace swSparse

#define DATA_TYPE_S
#include "s_SpLUTRSV.inl"
#undef  DATA_TYPE_S
#define DATA_TYPE_D
#include "s_SpLUTRSV.inl"
#undef  DATA_TYPE_D
#define DATA_TYPE_C
#include "s_SpLUTRSV.inl"
#undef  DATA_TYPE_C
#define DATA_TYPE_Z
#include "s_SpLUTRSV.inl"
#undef  DATA_TYPE_Z