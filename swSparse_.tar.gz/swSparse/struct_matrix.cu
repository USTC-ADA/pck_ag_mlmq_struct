#include "struct_data.h"
#include "../utils/utils.h"
#include <stdio.h>
#include <stdlib.h>

#define dtype float

#define GET_INDEX3(i, j, ik, n, k) ((i) * (n) * (k) + (j) * (k) + (ik))
#define GET_INDEX2(i, j, n) ((i) * (n) + (j))

#define VALID(im, in, ik, m, n, k) (im >= 0 && im < m && in >= 0 && in < n && ik >= 0 && ik < k)

int m, n, k, pos_n, pos_kn;
int *pos_h, *pos_d;
dtype *values_h, *x_h, *b_h, *x_baseline_h;

template<typename T>
void init_rand_data(T *array, int n)
{
    for (int i = 0; i < n; i++)
        array[i] = 1.0 * rand() / RAND_MAX;
}

template<typename T>
void init_zero_data(T *array, int n)
{
    for (int i = 0; i < n; i++)
        array[i] = 0;
}

void get_host_data()
{
    auto s = pes2();
    m = s.m;
    n = s.n;
    k = s.k;
    pos_n = s.pos_n;
    pos_kn = s.pos_kn;

    pos_h = (int*)malloc(sizeof(int) * pos_n * 3);
    for (int i = 0; i < pos_n * 3; i++)
        pos_h[i] = s.pos[i];

    values_h = (dtype*)malloc(sizeof(dtype) * m * n * k * (pos_n + 1));
    x_h = (dtype*)malloc(sizeof(dtype) * m * n * k);
    x_baseline_h = (dtype*)malloc(sizeof(dtype) * m * n * k);
    b_h = (dtype*)malloc(sizeof(dtype) * m * n * k);

    srand(241001);
    init_rand_data<dtype>(values_h, m * n * k * (pos_n + 1));
    init_zero_data<dtype>(x_h, m * n * k);
    init_zero_data<dtype>(x_baseline_h, m * n * k);
    init_rand_data<dtype>(b_h, m * n * k);
}

int main()
{
    get_host_data();

    int row_num = m * n * k;
    int nnz = row_num * (pos_n + 1);

    int RowPtr[row_num + 1];
    int ColIdx[nnz];
    RowPtr[0] = 0;

    int nnz_count = 0;
    for (int iter_m = 0; iter_m < m; iter_m++)
    for (int iter_n = 0; iter_n < n; iter_n++)
    for (int iter_k = 0; iter_k < k; iter_k++)
    {
        int tmp_count = 0;
        for (int iter_pos = 0; iter_pos < pos_n; iter_pos++)
        {
            int dep_row = iter_m + pos_h[iter_pos * 3];
            int dep_col = iter_n + pos_h[iter_pos * 3 + 1];
            int dep_k = iter_k + pos_h[iter_pos * 3 + 2];

            if (VALID(dep_row, dep_col, dep_k, m, n, k))
            {
                ColIdx[nnz_count + tmp_count] = GET_INDEX3(dep_row, dep_col, dep_k, n, k);
                tmp_count++;
            }
        }

        ColIdx[nnz_count + tmp_count] = GET_INDEX3(iter_m, iter_n, iter_k, n, k);
        tmp_count++;

        nnz_count += tmp_count;
        RowPtr[GET_INDEX3(iter_m, iter_n, iter_k, n, k) + 1] = nnz_count;
    }
    nnz = RowPtr[row_num];

    printf("%d %d %d\n", row_num, nnz, pos_n);

    // get_host_data();
    write_tri("/data/struct_triangular/pes2.csr", row_num, nnz, RowPtr, ColIdx, values_h);

    printf("Write done!\n");
}