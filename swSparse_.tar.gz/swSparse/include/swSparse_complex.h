#ifndef SWSPARSE_COMPLEX_H_INCLUDED
#define SWSPARSE_COMPLEX_H_INCLUDED 1

#ifdef __cplusplus
#include <cmath>

// We can use std::complex
// But if swg++ produces compile error, then replace it


/*
 * SWSPARSE_COMPLEX_SAFE_NUMERICS = 0, 1, 2
 *
 * if the value of SWSPARSE_COMPLEX_SAFE_NUMERICS is low:
 *     In complex arithmetics, we calculate `real*real+imag*imag` internally, so the valid range is square-rooted.
 *     Even if the magnitude is in `[DOUBLE_MIN, DOUBLE_MAX]`, if it is beyond `[sqrt(DOUBLE_MIN), sqrt(DOUBLE_MAX)]`, it still overflows
 *
 * if the value of SWSPARSE_COMPLEX_SAFE_NUMERICS is high:
 *     We will deal with overflow in some situations. It may be a little slower.
 */
#ifndef SWSPARSE_COMPLEX_SAFE_NUMERICS
#define SWSPARSE_COMPLEX_SAFE_NUMERICS 0
#endif

namespace swSparse {

template<typename T>
struct cplx {
    T real, imag;
    constexpr cplx(T r, T i) : real(r), imag(i) {}
    constexpr cplx(T r) : real(r), imag(0) {}
    constexpr cplx() {}
    cplx operator+(const cplx& x) const {
        return cplx(this->real + x.real, this->imag + x.imag);
    }
    cplx operator-(const cplx& x) const {
        return cplx(this->real - x.real, this->imag - x.imag);
    }
    cplx operator-() const {
        return cplx(- this->real, - this->imag);
    }
    cplx operator*(const cplx& x) const {
        return cplx(this->real * x.real - this->imag * x.imag, this->real * x.imag + this->imag * x.real);
    }
    cplx operator/(const cplx& x) const {               // this * conj(x) / abs(x)^2
#if SWSPARSE_COMPLEX_SAFE_NUMERICS > 1                  // Avoid overflow
        if(std::fabs(x.real) >= std::fabs(x.imag)) {    // reduce x.real
            T xir = x.imag / x.real;
            T denumerator = x.real * (1 + xir * xir);
            return cplx((this->real + this->imag * xir) / denumerator, \
                        (this->imag - this->real * xir) / denumerator);
        } else {                                        // reduce x.imag
            T xri = x.real / x.imag;
            T denumerator = x.imag * (xri * xri + 1);
            return cplx((this->real * xri + this->imag) / denumerator, \
                        (this->imag * xri - this->real) / denumerator);
        }
#else
        T denumerator = x.real * x.real + x.imag * x.imag;
        return cplx((this->real * x.real + this->imag * x.imag) / denumerator, \
                    (this->imag * x.real - this->real * x.imag) / denumerator);
#endif
    }
    cplx operator*(T x) const {
        return cplx(this->real * x, this->imag * x);
    }
    cplx operator/(T x) const {
        return cplx(this->real / x, this->imag / x);
    }
#define SWSPARSE_ASSIGN_OP(op, as, type) cplx& operator as(type x) { *this = *this op x; return *this; }
    SWSPARSE_ASSIGN_OP(+, +=, const cplx&)
    SWSPARSE_ASSIGN_OP(-, -=, const cplx&)
    SWSPARSE_ASSIGN_OP(*, *=, const cplx&)
    SWSPARSE_ASSIGN_OP(/, /=, const cplx&)
    SWSPARSE_ASSIGN_OP(*, *=, T)
    SWSPARSE_ASSIGN_OP(/, /=, T)
#undef SWSPARSE_ASSIGN_OP
    bool operator==(const cplx& x) const {
        return (this->real == x.real) && (this->imag == x.imag);
    }
    bool operator!=(const cplx& x) const {
        return (this->real != x.real) || (this->imag != x.imag);
    }
};

template<typename T>
inline cplx<T> conj(const cplx<T>& x) {
    return cplx<T>(x.real, -x.imag);
}

#ifdef SWSPARSE_REAL_DIVIDED_BY_COMPLEX
template<typename T>
inline cplx<T> operator/(T num, const cplx<T>& den) {  // num / den
#if SWSPARSE_COMPLEX_SAFE_NUMERICS > 1                 // Avoid overflow
    if(std::fabs(den.real) >= std::fabs(den.imag)) {   // reduce den.real
        T xir = den.imag / den.real;
        T factor = num / (den.real * (1 + xir * xir));
        return cplx(factor, - xir * factor);
    } else {                                           // reduce den.imag
        T xri = den.real / den.imag;
        T factor = num / (den.imag * (xri * xri + 1));
        return cplx(xri * factor, - factor);
    }
#else
    T factor = num / (den.real * den.real + den.imag * den.imag);
    return cplx(den.real * factor, - den.imag * factor);
#endif
}
#endif

/* 
 * hypot avoids OVERFLOW by using 
 *     b * sqrt(1 + (a / b) * (a / b))
 *  or a * sqrt(1 + (b / a) * (b / a))
 */
template<typename T>
inline T fabs(const cplx<T>& x) {
#if SWSPARSE_COMPLEX_SAFE_NUMERICS > 1
    return std::hypot(x.real, x.imag);
#else 
    return std::sqrt(x.real * x.real + x.imag * x.imag);
#endif
}

template<typename T>
using complex = cplx<T>;

} // namespace swSparse

#endif

#endif
