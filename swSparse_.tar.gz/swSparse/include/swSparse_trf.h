#ifndef SPTRF_H_INCLUDED
#define SPTRF_H_INCLUDED 1

#include"swSparse_base.h"
#include"swSparse_options.h"

/* 
 *       Pr * Dr * A * Dc * Pc^T = L * U
 * If    A * x = b
 * i.e.  L * U * (Pc^{-1} * Dc^{-1} * x) = Pr * Dr * b
 * Then  x = Dc * Pc^T * U^{-1} * L^{-1} * Pr * Dr * b
 * 
 * If options->pattern == SWSPARSE_NEW_MATRIX
 *     Input:  a, options
 *     Output: lu, riperm, ciperm, rscale, cscale
 * 
 * Elseif options->pattern == SWSPARSE_SAME_PATTERN
 *     Input:  a, lu, riperm, ciperm, rscale, cscale, options
 *     Update: lu, riperm, cscale
 */
SWSPARSE_API
swSparse_s_trf(swSparseMatrix a, swSparseMatrix *lu, \
             swSparseInt *riperm, swSparseInt *ciperm, float *rscale, float *cscale, const swSparseTRFOptions* options);
SWSPARSE_API
swSparse_d_trf(swSparseMatrix a, swSparseMatrix *lu, \
             swSparseInt *riperm, swSparseInt *ciperm, double *rscale, double *cscale, const swSparseTRFOptions* options);
SWSPARSE_API
swSparse_c_trf(swSparseMatrix a, swSparseMatrix *lu, \
             swSparseInt *riperm, swSparseInt *ciperm, float *rscale, float *cscale, const swSparseTRFOptions* options);
SWSPARSE_API
swSparse_z_trf(swSparseMatrix a, swSparseMatrix *lu, \
             swSparseInt *riperm, swSparseInt *ciperm, double *rscale, double *cscale, const swSparseTRFOptions* options);

/* 
 * auxiliary functions for equilibration 
 * `src` and `dst` can alias
 */
SWSPARSE_API
swSparse_s_elementwise_multiply(swSparseInt n, const float* src, float* dst, const float* scale);
SWSPARSE_API
swSparse_d_elementwise_multiply(swSparseInt n, const double* src, double* dst, const double* scale);
SWSPARSE_API
swSparse_c_elementwise_multiply(swSparseInt n, const swSparseSComplex* src, swSparseSComplex* dst, const float* scale);
SWSPARSE_API
swSparse_z_elementwise_multiply(swSparseInt n, const swSparseDComplex* src, swSparseDComplex* dst, const double* scale);
#endif
