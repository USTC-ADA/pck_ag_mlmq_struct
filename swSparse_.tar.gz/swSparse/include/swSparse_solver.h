#ifndef SOVLER_H_INCLUDED
#define SOVLER_H_INCLUDED

#include "swSparse_base.h"
#include "swSparse_options.h"

typedef struct {
    swSparseInt *xiperm;
    swSparseInt *biperm;
    void *rscale;
    void *cscale;
    swSparseMatrix lu;
    swSparseTRSMOptions solve_options;
} swSparseSolverData;

typedef swSparseSolverData *swSparseSolver;

SWSPARSE_API
swSparse_create_solver(swSparseSolver *solver, swSparseMatrix a, \
                       const swSparseSolverOptions* options);

SWSPARSE_API
swSparse_destroy_solver(swSparseSolver solver);

SWSPARSE_API
swSparse_s_solve_v(float alpha, swSparseSolver solver, const float *b, float *x);
SWSPARSE_API
swSparse_d_solve_v(double alpha, swSparseSolver solver, const double *b, double *x);
SWSPARSE_API
swSparse_c_solve_v(swSparseSComplex alpha, swSparseSolver solver, const swSparseSComplex *b, swSparseSComplex *x);
SWSPARSE_API
swSparse_z_solve_v(swSparseDComplex alpha, swSparseSolver solver, const swSparseDComplex *b, swSparseDComplex *x);

SWSPARSE_API
swSparse_s_solve_m(float alpha, swSparseSolver solver, swSparseInt nvec, \
                    const float *b, swSparseInt ldb, float *x, swSparseInt ldx);
SWSPARSE_API
swSparse_d_solve_m(double alpha, swSparseSolver solver, swSparseInt nvec, \
                    const double *b, swSparseInt ldb, double *x, swSparseInt ldx);
SWSPARSE_API
swSparse_c_solve_m(swSparseSComplex alpha, swSparseSolver solver, swSparseInt nvec, \
                    const swSparseSComplex *b, swSparseInt ldb, swSparseSComplex *x, swSparseInt ldx);
SWSPARSE_API
swSparse_z_solve_m(swSparseDComplex alpha, swSparseSolver solver, swSparseInt nvec, \
                    const swSparseDComplex *b, swSparseInt ldb, swSparseDComplex *x, swSparseInt ldx);

#endif
