#ifndef SWSPARSE_BASE_H_INCLUDED
#define SWSPARSE_BASE_H_INCLUDED 1

#include "swSparse_types.h"
#include "swSparse_formats.h"

/* Matrix */
typedef struct swSparseA {
    void *values;
    swSparseInt *offsets;
    swSparseInt *indices;
    swSparseInt ref_count;
    swSparseBool ordered;
} swSparseMatrixCSRC;

typedef struct swSparseB {
    void *values;
    swSparseInt *row_indices;
    swSparseInt *column_indices;
    swSparseInt ref_count;
} swSparseMatrixCOO;

typedef union {
    swSparseMatrixCSRC* csrc; /* CSR or CSC */
    swSparseMatrixCOO* coo;
    swSparseMatrixSWCOO* swcoo;
    swSparseMatrixSLTCOO* sltcoo;
    swSparseLUSupernodes* lusuper;
} swSparseMatrixRepresentation;

typedef enum swSparseC {
    SWSPARSE_CSR, SWSPARSE_CSC, SWSPARSE_COO,
    SWSPARSE_SWCOO, SWSPARSE_SLTCOO,
    SWSPARSE_LU_SUPERNODES
} swSparseMatrixFormatType;

typedef enum swSparseD {
    SWSPARSE_REAL_SINGLE, SWSPARSE_REAL_DOUBLE,
    SWSPARSE_COMPLEX_SINGLE, SWSPARSE_COMPLEX_DOUBLE
} swSparseMatrixElementType;

typedef struct swSparseF {
    swSparseMatrixRepresentation matrix;
    swSparseInt m, n, nnz;
    swSparseMatrixFormatType format_type;
    swSparseMatrixElementType element_type;
    swSparseMatrixStatus status;
} swSparseMatrixData;

typedef swSparseMatrixData *swSparseMatrix;

#endif
