#ifndef FILE_IO_H_INCLUDED
#define FILE_IO_H_INCLUDED 1

#include <stdio.h>
#include "swSparse_base.h"

/* precision */
#define SWSPARSE_SINGLE     0x01
#define SWSPARSE_DOUBLE     0x02

SWSPARSE_API
swSparse_read_mtx_opened(swSparseMatrix *mat, FILE *file, \
                         const char *file_name, swSparseInt precision, swSparseMatrixFormatType format);

SWSPARSE_API
swSparse_read_mtx(swSparseMatrix *mat, \
                  const char *file_name, swSparseInt precision, swSparseMatrixFormatType format);
                  
SWSPARSE_API
swSparse_read_mtx_cached(swSparseMatrix *mat, const char *file_name, const char *cache_directory, \
                         swSparseInt precision, swSparseMatrixFormatType format);

SWSPARSE_API
swSparse_read_binary_opened(swSparseMatrix *mat, FILE *file, const char *file_name);

SWSPARSE_API
swSparse_read_binary(swSparseMatrix *mat, const char *file_name);
                  
SWSPARSE_API
swSparse_write_binary_opened(swSparseMatrix mat, FILE *file, const char *file_name);

SWSPARSE_API
swSparse_write_binary(swSparseMatrix mat, const char *file_name);


/* Wang Xinliang's lagacy files, removed */
/*
SWSPARSE_API
swSparse_read_lagacy_opened(swSparseMatrix *mat, FILE *file, const char *file_name);

SWSPARSE_API
swSparse_read_lagacy(swSparseMatrix *mat, const char *file_name);
*/
#ifdef __cplusplus
extern "C" {
#endif
swSparseBool swSparse_compare(swSparseMatrix a, swSparseMatrix b);
swSparseBool swSparse_valid(swSparseMatrix a);
#ifdef __cplusplus
}
#endif
#endif
