#ifndef SPBLAS_H_INCLUDED
#define SPBLAS_H_INCLUDED 1

#include"swSparse_base.h"
#include"swSparse_options.h"

SWSPARSE_API
swSparse_mv_inspect(swSparseMatrix old_format, swSparseMatrix *new_format, const swSparseMVOptions* options);

SWSPARSE_API
swSparse_s_mv_execute(float alpha, swSparseMatrix matrix, const float *x, \
                    float beta, float *y, const swSparseMVOptions* options);
SWSPARSE_API
swSparse_d_mv_execute(double alpha, swSparseMatrix matrix, const double *x, \
                    double beta, double *y, const swSparseMVOptions* options);
SWSPARSE_API
swSparse_c_mv_execute(swSparseSComplex alpha, swSparseMatrix matrix, const swSparseSComplex *x, \
                    swSparseSComplex beta, swSparseSComplex *y, const swSparseMVOptions* options);
SWSPARSE_API
swSparse_z_mv_execute(swSparseDComplex alpha, swSparseMatrix matrix, const swSparseDComplex *x, \
                    swSparseDComplex beta, swSparseDComplex *y, const swSparseMVOptions* options);

SWSPARSE_API
swSparse_mm_inspect(swSparseMatrix old_format, swSparseMatrix *new_format, const swSparseMMOptions*  options);

SWSPARSE_API
swSparse_s_mm_execute(float alpha, swSparseMatrix matrix, swSparseInt nvec, \
                    const float *x, swSparseInt ldx, \
                    float beta, float *y, swSparseInt ldy, const swSparseMMOptions*  options);
SWSPARSE_API
swSparse_d_mm_execute(double alpha, swSparseMatrix matrix, swSparseInt nvec, \
                    const double *x, swSparseInt ldx, \
                    double beta, double *y, swSparseInt ldy, const swSparseMMOptions*  options);
SWSPARSE_API
swSparse_c_mm_execute(swSparseSComplex alpha, swSparseMatrix matrix, swSparseInt nvec, \
                    const swSparseSComplex *x, swSparseInt ldx, \
                    swSparseSComplex beta, swSparseSComplex *y, swSparseInt ldy, const swSparseMMOptions*  options);
SWSPARSE_API
swSparse_z_mm_execute(swSparseDComplex alpha, swSparseMatrix matrix, swSparseInt nvec, \
                    const swSparseDComplex *x, swSparseInt ldx, \
                    swSparseDComplex beta, swSparseDComplex *y, swSparseInt ldy, const swSparseMMOptions*  options);

SWSPARSE_API
swSparse_trsv_inspect(swSparseMatrix old_format, swSparseMatrix *new_format, \
                      swSparseInt *perm, swSparseInt *iperm, const swSparseTRSVOptions* options);

SWSPARSE_API
swSparse_s_trsv_execute(float alpha, swSparseMatrix matrix, const float *b, float *x, const swSparseTRSVOptions* options);
SWSPARSE_API
swSparse_d_trsv_execute(double alpha, swSparseMatrix matrix, const double *b, double *x, const swSparseTRSVOptions* options);
SWSPARSE_API
swSparse_c_trsv_execute(swSparseSComplex alpha, swSparseMatrix matrix, \
                        const swSparseSComplex *b, swSparseSComplex *x, const swSparseTRSVOptions* options);
SWSPARSE_API
swSparse_z_trsv_execute(swSparseDComplex alpha, swSparseMatrix matrix, \
                        const swSparseDComplex *b, swSparseDComplex *x, const swSparseTRSVOptions* options);

SWSPARSE_API
swSparse_trsm_inspect(swSparseMatrix old_format, swSparseMatrix *new_format, \
                      swSparseInt *perm, swSparseInt *iperm, const swSparseTRSMOptions* options);

SWSPARSE_API
swSparse_s_trsm_execute(float alpha, swSparseMatrix matrix, swSparseInt nvec, \
                    const float *b, swSparseInt ldb, float *x, swSparseInt ldx, const swSparseTRSMOptions* options);
SWSPARSE_API
swSparse_d_trsm_execute(double alpha, swSparseMatrix matrix, swSparseInt nvec, \
                    const double *b, swSparseInt ldb, double *x, swSparseInt ldx, const swSparseTRSMOptions* options);
SWSPARSE_API
swSparse_c_trsm_execute(swSparseSComplex alpha, swSparseMatrix matrix, swSparseInt nvec, \
                    const swSparseSComplex *b, swSparseInt ldb, swSparseSComplex *x, swSparseInt ldx, const swSparseTRSMOptions* options);
SWSPARSE_API
swSparse_z_trsm_execute(swSparseDComplex alpha, swSparseMatrix matrix, swSparseInt nvec, \
                    const swSparseDComplex *b, swSparseInt ldb, swSparseDComplex *x, swSparseInt ldx, const swSparseTRSMOptions* options);

SWSPARSE_API
swSparse_s_add(float alpha, swSparseMatrix a, float beta, swSparseMatrix b, \
                swSparseMatrix *c, const swSparseADDOptions* options);
SWSPARSE_API
swSparse_d_add(double alpha, swSparseMatrix a, double beta, swSparseMatrix b, \
                swSparseMatrix *c, const swSparseADDOptions* options);
SWSPARSE_API
swSparse_c_add(swSparseSComplex alpha, swSparseMatrix a, swSparseSComplex beta, swSparseMatrix b, \
                swSparseMatrix *c, const swSparseADDOptions* options);
SWSPARSE_API
swSparse_z_add(swSparseDComplex alpha, swSparseMatrix a, swSparseDComplex beta, swSparseMatrix b, \
                swSparseMatrix *c, const swSparseADDOptions* options);

// C = A*B
// swSparseMatrix c = NULL, c_new;
// swSparse_d_gemm(1.0, a, b, 0.0, c, &c_new, option);
// c = c_new;
SWSPARSE_API
swSparse_s_gemm(float alpha, swSparseMatrix a, swSparseMatrix b, \
                float beta, swSparseMatrix d, swSparseMatrix *c, const swSparseGEMMOptions* options);
SWSPARSE_API
swSparse_d_gemm(double alpha, swSparseMatrix a, swSparseMatrix b, \
                double beta, swSparseMatrix d, swSparseMatrix *c, const swSparseGEMMOptions* options);
SWSPARSE_API
swSparse_c_gemm(swSparseSComplex alpha, swSparseMatrix a, swSparseMatrix b, \
                swSparseSComplex beta, swSparseMatrix d, swSparseMatrix *c, const swSparseGEMMOptions* options);
SWSPARSE_API
swSparse_z_gemm(swSparseDComplex alpha, swSparseMatrix a, swSparseMatrix b, \
                swSparseDComplex beta, swSparseMatrix d, swSparseMatrix *c, const swSparseGEMMOptions* options);

SWSPARSE_API
swSparse_s_struct_mv(float alpha, const float *a, const float *x, float beta, float *y, \
                    const swSparseInt *dim, swSparseInt nelem , const swSparseInt (*elem_pos)[3]);
SWSPARSE_API
swSparse_d_struct_mv(double alpha, const double *a, const double *x, double beta, double *y, \
                    const swSparseInt *dim, swSparseInt nelem , const swSparseInt (*elem_pos)[3]);
SWSPARSE_API
swSparse_c_struct_mv(swSparseSComplex alpha, const swSparseSComplex *a, const swSparseSComplex *x, \
                    swSparseSComplex beta, swSparseSComplex *y, \
                    const swSparseInt *dim, swSparseInt nelem , const swSparseInt (*elem_pos)[3]);
SWSPARSE_API
swSparse_z_struct_mv(swSparseDComplex alpha, const swSparseDComplex *a, const swSparseDComplex *x, \
                    swSparseDComplex beta, swSparseDComplex *y, \
                    const swSparseInt *dim, swSparseInt nelem , const swSparseInt (*elem_pos)[3]);

SWSPARSE_API
swSparse_s_struct_sptrsv_forward(const float *l, float *x, const float *b, \
                    const swSparseInt *dim, swSparseInt npoints, \
                    const swSparseInt (*stencil_pos)[3]);
SWSPARSE_API
swSparse_d_struct_sptrsv_forward(const double *l, double *x, const double *b, \
                    const swSparseInt *dim, swSparseInt npoints, \
                    const swSparseInt (*stencil_pos)[3]);
SWSPARSE_API
swSparse_c_struct_sptrsv_forward(const swSparseSComplex *l, swSparseSComplex *x, const swSparseSComplex *b, \
                    const swSparseInt *dim, swSparseInt npoints, \
                    const swSparseInt (*stencil_pos)[3]);
SWSPARSE_API
swSparse_z_struct_sptrsv_forward(const swSparseDComplex *l, swSparseDComplex *x, const swSparseDComplex *b, \
                    const swSparseInt*dim, swSparseInt npoints, \
                    const swSparseInt (*stencil_pos)[3]);
SWSPARSE_API
swSparse_s_struct_sptrsv_backward(const float *u, float *x, const float *b, \
                    const swSparseInt *dim, swSparseInt npoints, \
                    const swSparseInt (*stencil_pos)[3]);
SWSPARSE_API
swSparse_d_struct_sptrsv_backward(const double *u, double *x, const double *b, \
                    const swSparseInt *dim, swSparseInt npoints, \
                    const swSparseInt (*stencil_pos)[3]);
SWSPARSE_API
swSparse_c_struct_sptrsv_backward(const swSparseSComplex *u, swSparseSComplex *x, const swSparseSComplex *b, \
                    const swSparseInt *dim, swSparseInt npoints, \
                    const swSparseInt (*stencil_pos)[3]);
SWSPARSE_API
swSparse_z_struct_sptrsv_backward(const swSparseDComplex *u, swSparseDComplex *x, const swSparseDComplex *b, \
                    const swSparseInt*dim, swSparseInt npoints, \
                    const swSparseInt (*stencil_pos)[3]);
///
SWSPARSE_API
swSparse_s_struct_sptrsv_sequential_forward(const float* a, float *x, const float* b, const int dim[3], int nnz, const int (*pos)[3]);

SWSPARSE_API
swSparse_d_struct_sptrsv_sequential_forward(const double* a, double *x, const double* b, const int dim[3], int nnz, const int (*pos)[3]);

SWSPARSE_API
swSparse_s_struct_sptrsv_sequential_backward(const float* a, float *x, const float* b, const int dim[3], int nnz, const int (*pos)[3]);

SWSPARSE_API
swSparse_d_struct_sptrsv_sequential_backward(const double* a, double *x, const double* b, const int dim[3], int nnz, const int (*pos)[3]);
///

SWSPARSE_API
swSparse_s_struct_ilu(swSparseInt iluk, const float *a, float *l, float *u, \
                    const swSparseInt *dim, swSparseInt npoints, \
                    const swSparseInt (*stencil)[3], const swSparseTRFOptions *options);
SWSPARSE_API
swSparse_d_struct_ilu(swSparseInt iluk, const double *a, double *l, double *u, \
                    const swSparseInt *dim, swSparseInt npoints, \
                    const swSparseInt (*stencil)[3], const swSparseTRFOptions *options);
SWSPARSE_API
swSparse_c_struct_ilu(swSparseInt iluk, const swSparseSComplex *a, swSparseSComplex *l, swSparseSComplex *u, \
                    const swSparseInt *dim, swSparseInt npoints, \
                    const swSparseInt (*stencil)[3], const swSparseTRFOptions *options);
SWSPARSE_API
swSparse_z_struct_ilu(swSparseInt iluk, const swSparseDComplex *a, swSparseDComplex *l, swSparseDComplex *u, \
                    const swSparseInt *dim, swSparseInt npoints, \
                    const swSparseInt (*stencil)[3], const swSparseTRFOptions *options);

SWSPARSE_API
swSparse_ilu_analysis(swSparseInt iluk, swSparseInt npoints, \
                    const swSparseInt (*stencil)[3], swSparseInt *l_npoints, swSparseInt (**l_stencil_pos)[3], \
                    swSparseInt *u_npoints, swSparseInt (**u_stencil_pos)[3]);

#endif

