#ifndef SWSPARSE_H_INCLUDED
#define SWSPARSE_H_INCLUDED 1

#include"swSparse_matrix.h"
#include"swSparse_auxiliary.h"
#include"swSparse_reorder.h"
#include"swSparse_blas.h"
#include"swSparse_trf.h"
#include"swSparse_solver.h"

#endif
