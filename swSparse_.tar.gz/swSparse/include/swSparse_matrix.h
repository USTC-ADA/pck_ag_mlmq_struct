#ifndef MATRIX_MANIP_H_INCLUDED
#define MATRIX_MANIP_H_INCLUDED 1


#include"swSparse_base.h"

SWSPARSE_API
swSparse_s_create_csr(swSparseMatrix *matrix, swSparseInt m, swSparseInt n, swSparseInt nnz,\
                      swSparseInt *row_offsets, swSparseInt *column_indices, float *values);
SWSPARSE_API
swSparse_d_create_csr(swSparseMatrix *matrix, swSparseInt m, swSparseInt n, swSparseInt nnz,\
                      swSparseInt *row_offsets, swSparseInt *column_indices, double *values);
SWSPARSE_API
swSparse_c_create_csr(swSparseMatrix *matrix, swSparseInt m, swSparseInt n, swSparseInt nnz,\
                      swSparseInt *row_offsets, swSparseInt *column_indices, swSparseSComplex *values);
SWSPARSE_API
swSparse_z_create_csr(swSparseMatrix *matrix, swSparseInt m, swSparseInt n, swSparseInt nnz,\
                      swSparseInt *row_offsets, swSparseInt *column_indices, swSparseDComplex *values);
                    
SWSPARSE_API
swSparse_s_create_csc(swSparseMatrix *matrix, swSparseInt m, swSparseInt n, swSparseInt nnz, \
                      swSparseInt *column_offsets, swSparseInt *row_indices, float *values);
SWSPARSE_API
swSparse_d_create_csc(swSparseMatrix *matrix, swSparseInt m, swSparseInt n, swSparseInt nnz, \
                      swSparseInt *column_offsets, swSparseInt *row_indices, double *values);
SWSPARSE_API
swSparse_c_create_csc(swSparseMatrix *matrix, swSparseInt m, swSparseInt n, swSparseInt nnz, \
                      swSparseInt *column_offsets, swSparseInt *row_indices, swSparseSComplex *values);
SWSPARSE_API
swSparse_z_create_csc(swSparseMatrix *matrix, swSparseInt m, swSparseInt n, swSparseInt nnz, \
                      swSparseInt *column_offsets, swSparseInt *row_indices, swSparseDComplex *values);

SWSPARSE_API
swSparse_s_create_coo(swSparseMatrix *matrix, swSparseInt m, swSparseInt n, swSparseInt nnz, \
                      swSparseInt *row_indices, swSparseInt *column_indices, float *values);
SWSPARSE_API 
swSparse_d_create_coo(swSparseMatrix *matrix, swSparseInt m, swSparseInt n, swSparseInt nnz, \
                      swSparseInt *row_indices, swSparseInt *column_indices, double *values);
SWSPARSE_API
swSparse_c_create_coo(swSparseMatrix *matrix, swSparseInt m, swSparseInt n, swSparseInt nnz, \
                      swSparseInt *row_indices, swSparseInt *column_indices, swSparseSComplex *values);
SWSPARSE_API
swSparse_z_create_coo(swSparseMatrix *matrix, swSparseInt m, swSparseInt n, swSparseInt nnz, \
                      swSparseInt *row_indices, swSparseInt *column_indices, swSparseDComplex *values);


SWSPARSE_API
swSparse_s_allocate_csr(swSparseMatrix *matrix, swSparseInt m, swSparseInt n, swSparseInt nnz);
SWSPARSE_API
swSparse_d_allocate_csr(swSparseMatrix *matrix, swSparseInt m, swSparseInt n, swSparseInt nnz);
SWSPARSE_API
swSparse_c_allocate_csr(swSparseMatrix *matrix, swSparseInt m, swSparseInt n, swSparseInt nnz);
SWSPARSE_API
swSparse_z_allocate_csr(swSparseMatrix *matrix, swSparseInt m, swSparseInt n, swSparseInt nnz);
                    
SWSPARSE_API
swSparse_s_allocate_csc(swSparseMatrix *matrix, swSparseInt m, swSparseInt n, swSparseInt nnz);
SWSPARSE_API
swSparse_d_allocate_csc(swSparseMatrix *matrix, swSparseInt m, swSparseInt n, swSparseInt nnz);
SWSPARSE_API
swSparse_c_allocate_csc(swSparseMatrix *matrix, swSparseInt m, swSparseInt n, swSparseInt nnz);
SWSPARSE_API
swSparse_z_allocate_csc(swSparseMatrix *matrix, swSparseInt m, swSparseInt n, swSparseInt nnz);

SWSPARSE_API
swSparse_s_allocate_coo(swSparseMatrix *matrix, swSparseInt m, swSparseInt n, swSparseInt nnz);
SWSPARSE_API 
swSparse_d_allocate_coo(swSparseMatrix *matrix, swSparseInt m, swSparseInt n, swSparseInt nnz);
SWSPARSE_API
swSparse_c_allocate_coo(swSparseMatrix *matrix, swSparseInt m, swSparseInt n, swSparseInt nnz);
SWSPARSE_API
swSparse_z_allocate_coo(swSparseMatrix *matrix, swSparseInt m, swSparseInt n, swSparseInt nnz);

/* always return SWSPARSE_SUCCESS */
SWSPARSE_API
swSparse_destroy(swSparseMatrix matrix);

SWSPARSE_API
swSparse_s_rw_export_csr(swSparseMatrix matrix, swSparseInt *m, swSparseInt *n, swSparseInt *nnz, \
                      swSparseInt **row_offsets, swSparseInt **column_indices, float **values);
SWSPARSE_API
swSparse_d_rw_export_csr(swSparseMatrix matrix, swSparseInt *m, swSparseInt *n, swSparseInt *nnz, \
                      swSparseInt **row_offsets, swSparseInt **column_indices, double **values);
SWSPARSE_API
swSparse_c_rw_export_csr(swSparseMatrix matrix, swSparseInt *m, swSparseInt *n, swSparseInt *nnz, \
                      swSparseInt **row_offsets, swSparseInt **column_indices, swSparseSComplex **values);
SWSPARSE_API
swSparse_z_rw_export_csr(swSparseMatrix matrix, swSparseInt *m, swSparseInt *n, swSparseInt *nnz, \
                      swSparseInt **row_offsets, swSparseInt **column_indices, swSparseDComplex **values);

SWSPARSE_API
swSparse_s_rw_export_csc(swSparseMatrix matrix, swSparseInt *m, swSparseInt *n, swSparseInt *nnz, \
                      swSparseInt **column_offsets, swSparseInt **row_indices, float **values);
SWSPARSE_API
swSparse_d_rw_export_csc(swSparseMatrix matrix, swSparseInt *m, swSparseInt *n, swSparseInt *nnz, \
                      swSparseInt **column_offsets, swSparseInt **row_indices, double **values);
SWSPARSE_API
swSparse_c_rw_export_csc(swSparseMatrix matrix, swSparseInt *m, swSparseInt *n, swSparseInt *nnz, \
                      swSparseInt **column_offsets, swSparseInt **row_indices, swSparseSComplex **values);
SWSPARSE_API
swSparse_z_rw_export_csc(swSparseMatrix matrix, swSparseInt *m, swSparseInt *n, swSparseInt *nnz, \
                      swSparseInt **column_offsets, swSparseInt **row_indices, swSparseDComplex **values);

SWSPARSE_API
swSparse_s_rw_export_coo(swSparseMatrix matrix, swSparseInt *m, swSparseInt *n, swSparseInt *nnz, \
                      swSparseInt **row_indices, swSparseInt **column_indices, float **values);
SWSPARSE_API
swSparse_d_rw_export_coo(swSparseMatrix matrix, swSparseInt *m, swSparseInt *n, swSparseInt *nnz, \
                      swSparseInt **row_indices, swSparseInt **column_indices, double **values);
SWSPARSE_API
swSparse_c_rw_export_coo(swSparseMatrix matrix, swSparseInt *m, swSparseInt *n, swSparseInt *nnz, \
                      swSparseInt **row_indices, swSparseInt **column_indices, swSparseSComplex **values);
SWSPARSE_API
swSparse_z_rw_export_coo(swSparseMatrix matrix, swSparseInt *m, swSparseInt *n, swSparseInt *nnz, \
                      swSparseInt **row_indices, swSparseInt **column_indices, swSparseDComplex **values);

SWSPARSE_API
swSparse_s_ro_export_csr(swSparseMatrix matrix, swSparseInt *m, swSparseInt *n, swSparseInt *nnz, \
                      const swSparseInt **row_offsets, const swSparseInt **column_indices, const float **values);
SWSPARSE_API
swSparse_d_ro_export_csr(swSparseMatrix matrix, swSparseInt *m, swSparseInt *n, swSparseInt *nnz, \
                      const swSparseInt **row_offsets, const swSparseInt **column_indices, const double **values);
SWSPARSE_API
swSparse_c_ro_export_csr(swSparseMatrix matrix, swSparseInt *m, swSparseInt *n, swSparseInt *nnz, \
                      const swSparseInt **row_offsets, const swSparseInt **column_indices, const swSparseSComplex **values);
SWSPARSE_API
swSparse_z_ro_export_csr(swSparseMatrix matrix, swSparseInt *m, swSparseInt *n, swSparseInt *nnz, \
                      const swSparseInt **row_offsets, const swSparseInt **column_indices, const swSparseDComplex **values);

SWSPARSE_API
swSparse_s_ro_export_csc(swSparseMatrix matrix, swSparseInt *m, swSparseInt *n, swSparseInt *nnz, \
                      const swSparseInt **column_offsets, const swSparseInt **row_indices, const float **values);
SWSPARSE_API
swSparse_d_ro_export_csc(swSparseMatrix matrix, swSparseInt *m, swSparseInt *n, swSparseInt *nnz, \
                      const swSparseInt **column_offsets, const swSparseInt **row_indices, const double **values);
SWSPARSE_API
swSparse_c_ro_export_csc(swSparseMatrix matrix, swSparseInt *m, swSparseInt *n, swSparseInt *nnz, \
                      const swSparseInt **column_offsets, const swSparseInt **row_indices, const swSparseSComplex **values);
SWSPARSE_API
swSparse_z_ro_export_csc(swSparseMatrix matrix, swSparseInt *m, swSparseInt *n, swSparseInt *nnz, \
                      const swSparseInt **column_offsets, const swSparseInt **row_indices, const swSparseDComplex **values);

SWSPARSE_API
swSparse_s_ro_export_coo(swSparseMatrix matrix, swSparseInt *m, swSparseInt *n, swSparseInt *nnz, \
                      const swSparseInt **row_indices, const swSparseInt **column_indices, const float **values);
SWSPARSE_API
swSparse_d_ro_export_coo(swSparseMatrix matrix, swSparseInt *m, swSparseInt *n, swSparseInt *nnz, \
                      const swSparseInt **row_indices, const swSparseInt **column_indices, const double **values);
SWSPARSE_API
swSparse_c_ro_export_coo(swSparseMatrix matrix, swSparseInt *m, swSparseInt *n, swSparseInt *nnz, \
                      const swSparseInt **row_indices, const swSparseInt **column_indices, const swSparseSComplex **values);
SWSPARSE_API
swSparse_z_ro_export_coo(swSparseMatrix matrix, swSparseInt *m, swSparseInt *n, swSparseInt *nnz, \
                      const swSparseInt **row_indices, const swSparseInt **column_indices, const swSparseDComplex **values);

SWSPARSE_API
swSparse_set_order(swSparseMatrix mat, swSparseBool ordered);

SWSPARSE_API
swSparse_set_nnz(swSparseMatrix mat, swSparseInt nnz);

SWSPARSE_API 
swSparse_copy(swSparseMatrix old_mat, swSparseMatrix *new_mat);

SWSPARSE_API
swSparse_convert_coo(swSparseMatrix old_mat, swSparseMatrix *new_mat);

SWSPARSE_API
swSparse_convert_csr(swSparseMatrix old_mat, swSparseMatrix *new_mat);

SWSPARSE_API
swSparse_convert_csc(swSparseMatrix old_mat, swSparseMatrix *new_mat);

SWSPARSE_API
swSparse_transpose(swSparseMatrix old_mat, swSparseMatrix *new_mat);

SWSPARSE_API
swSparse_s_set_element(swSparseMatrix mat, swSparseInt row_idx, swSparseInt col_idx, float new_val);
SWSPARSE_API
swSparse_d_set_element(swSparseMatrix mat, swSparseInt row_idx, swSparseInt col_idx, double new_val);
SWSPARSE_API
swSparse_c_set_element(swSparseMatrix mat, swSparseInt row_idx, swSparseInt col_idx, swSparseSComplex new_val);
SWSPARSE_API
swSparse_z_set_element(swSparseMatrix mat, swSparseInt row_idx, swSparseInt col_idx, swSparseDComplex new_val);

SWSPARSE_API
swSparse_s_modify_element(swSparseMatrix mat, swSparseInt row_idx, swSparseInt col_idx, float delta);
SWSPARSE_API
swSparse_d_modify_element(swSparseMatrix mat, swSparseInt row_idx, swSparseInt col_idx, double delta);
SWSPARSE_API
swSparse_c_modify_element(swSparseMatrix mat, swSparseInt row_idx, swSparseInt col_idx, swSparseSComplex delta);
SWSPARSE_API
swSparse_z_modify_element(swSparseMatrix mat, swSparseInt row_idx, swSparseInt col_idx, swSparseDComplex delta);

#endif
