#ifndef REORDER_H_INCLUDED
#define REORDER_H_INCLUDED 1

#include "swSparse_base.h"

SWSPARSE_API
swSparse_perm_invert(swSparseInt n, const swSparseInt *perm, swSparseInt *iperm);

SWSPARSE_API
swSparse_perm_compose(swSparseInt n, const swSparseInt *first, const swSparseInt *second, swSparseInt *composed);

SWSPARSE_API
swSparse_iperm_compose(swSparseInt n, const swSparseInt *first, const swSparseInt *second, swSparseInt *composed);

SWSPARSE_API
swSparse_i_iperm_apply(swSparseInt n, const swSparseInt *src, \
                        swSparseInt *dst, const swSparseInt *iperm);
SWSPARSE_API
swSparse_s_iperm_apply(swSparseInt n, const float *src, \
                        float *dst, const swSparseInt *iperm);
SWSPARSE_API
swSparse_d_iperm_apply(swSparseInt n, const double *src, \
                        double *dst, const swSparseInt *iperm);
SWSPARSE_API
swSparse_c_iperm_apply(swSparseInt n, const swSparseSComplex *src, \
                        swSparseSComplex *dst, const swSparseInt *iperm);
SWSPARSE_API
swSparse_z_iperm_apply(swSparseInt n, const swSparseDComplex *src, \
                        swSparseDComplex *dst, const swSparseInt *iperm);

SWSPARSE_API
swSparse_i_perm_apply(swSparseInt n, const swSparseInt *src, \
                        swSparseInt *dst, const swSparseInt *perm);
SWSPARSE_API
swSparse_s_perm_apply(swSparseInt n, const float *src, \
                        float *dst, const swSparseInt *perm);
SWSPARSE_API
swSparse_d_perm_apply(swSparseInt n, const double *src, \
                        double *dst, const swSparseInt *perm);
SWSPARSE_API
swSparse_c_perm_apply(swSparseInt n, const swSparseSComplex *src, \
                        swSparseSComplex *dst, const swSparseInt *perm);
SWSPARSE_API
swSparse_z_perm_apply(swSparseInt n, const swSparseDComplex *src, \
                        swSparseDComplex *dst, const swSparseInt *perm);

SWSPARSE_API
swSparse_reorder_rows(swSparseMatrix old_mat, swSparseMatrix *new_mat, \
                      const swSparseInt *riperm);
                 
SWSPARSE_API
swSparse_reorder_columns(swSparseMatrix old_mat, swSparseMatrix *new_mat, \
                         const swSparseInt *ciperm);

SWSPARSE_API
swSparse_reorder_row_col(swSparseMatrix old_mat, swSparseMatrix *new_mat, \
                         const swSparseInt *riperm, const swSparseInt *ciperm);

SWSPARSE_API
swSparse_mark_order(swSparseMatrix mat, swSparseBool ordered);

#endif
