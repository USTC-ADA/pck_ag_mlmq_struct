#ifndef SPLUTRSV_H_INCLUDED
#define SPLUTRSV_H_INCLUDED

#include <crts.h>
#include <stdio.h>
#include "swSparse_base.h"
#include "swSparse_options.h"
#include "internal/rename.h"

EXTERN
void lutrsv_destroy();

SWSPARSE_API
swSparse_s_lutrsv(Int n, swSparseMatrix *lu, const float* b, float* x, Int* riperm, Int* ciperm, const float* rscale, const float* cscale);

SWSPARSE_API
swSparse_d_lutrsv(Int n, swSparseMatrix *lu, const double* b, double* x, Int* riperm, Int* ciperm, const double* rscale, const double* cscale);

SWSPARSE_API
swSparse_c_lutrsv(Int n, swSparseMatrix *lu, const SComplex* b, SComplex* x, Int* riperm, Int* ciperm, const float* rscale, const float* cscale);

SWSPARSE_API
swSparse_z_lutrsv(Int n, swSparseMatrix *lu, const DComplex* b, DComplex* x, Int* riperm, Int* ciperm, const double* rscale, const double* cscale);

#endif