#ifndef SPECIAL_FORMATS_H_INCLUDED
#define SPECIAL_FORMATS_H_INCLUDED 1

#include "swSparse_types.h"

typedef struct {
  int tile_nnz,id;
} swSparse_SpMV_Matrix_tile;


typedef struct{

int numbers; //tiles this worker do
int *tiles;  //array of tile id
int *nnzs;   //array of tile nnz
int *masks;  //array of which slaves do each tile
int *number_workers; //array of each tile is done by how many slavers

} swSparse_SpMV_CSR_Tile; //from tile to block(sub-matrix)  , owned by each worker

typedef struct
{
    int row_offset, row_length;
    int col_offset, col_length;
    int worker_id;
    int slaver_id;
    int mask;
    int nnz;
} swSparse_SpMV_CSR_BLOCK;

typedef struct
{
    int row_offset, row_length;
    int col_offset, col_length;
    int worker_id;
    int slaver_id;
    int put_id; //-1: store back to main memory
    int get_id; //
    int reduce_root;  //use swSparse_d_col_sum
    int reduce_ncpe;
    bool reduce_flag;
    bool store_flag;
    int nnz;
    bool job;
} swSparse_SpMV_CSR_TASK_SIMPLE;


typedef struct
{
    int tile_size;
    int nworkers;
    int nslavers;
    int avg_blocks;
    double tolerate;
    int element_size;
    int cache_element_size;
}swSparse_SpMV_Format_Config;

typedef struct
{
    int row_offset, row_length;
    int col_offset, col_length;
    int nnz_offset, nnz_length;
    int put_id;
    int get_id;
    int reduce_root;  //use swSparse_d_col_sum
    int reduce_ncpe;
    bool reduce_flag;
    bool store_flag;
    int nnz;
    bool job;
}swSparse_SpMV_Slave_TASK;

typedef struct
{
    const void *x;
    void *b;
    int *row_idx;
    int *col_idx;
    void *value;
    void *ratio;
    swSparse_SpMV_Slave_TASK *tasks;
    int rows, cols, ntasks;
    int nnz_offset, nnz_length;
    int tile_size;
    int vector_cols , ldx , ldy;
} swSparse_SpMV_Slave_Info;

typedef struct {

  int tile_num;
  int *row_idx;
  int *col_idx;
  void *value;
  swSparse_SpMV_Slave_TASK *tasks;
  swSparse_SpMV_Slave_Info infos[8][8];
  int rows, cols, nnz, ntasks;
  double real_mem , mem_size, compute_size, vector_size;
  int best_para_element_size,best_para_cache_element_size;

} swSparseMatrixSWCOO;

typedef struct {
    void *values;
    swSparseInt *row_indices;
    swSparseInt *column_indices;
    
    swSparseInt levels, plevels;
    swSparseInt *level;          //the number of rows in each level 
    swSparseInt *plevel;         //nnz in each level???
    swSparseInt *_idx, *idx[32]; //???
    swSparseInt *_cnt, *cnt[32]; //[32][levels] 
    swSparseInt n_vec;

	void * trsv_tune;

#ifdef SWSPARSE_SWAPS_TEST
    long long pro_swaps[32];
    long long con_swaps[32];
#endif
} swSparseMatrixSLTCOO;


/******** supernode format for LU ********/

typedef struct swSparseLU {
    void *l_values;            // malloc
    swSparseInt *l_indices;    // malloc or null if all in diagonal block
    swSparseInt *l_i_offsets;  // malloc
    swSparseInt *l_v_offsets;
    swSparseInt *sup_etree_parent;
    swSparseInt *sup2col;
    swSparseInt *col2sup;
    void *u_values;              // malloc or null if lower triangular
    swSparseInt *u_col_offsets;  // malloc
    swSparseInt *u_seg_offsets;
    swSparseInt *u_seg_indices;

    /*********** static schedule ************/
    /*
     * status[i] >= 0 : `task_queue[status[i]]` is snode `i`
     * status[i] <  0 : in a subtree that is assigned to CPE `status[i] + 64`
     */
    void* subtrees;       // malloc or null
    void* task_queue;     // malloc or null
    swSparseInt* snode_status;
    swSparseInt subtree_offsets[65];     /* N_CPE + 1 */
    swSparseInt task_queue_size;

    swSparseInt nsuper;
    swSparseBool l_ordered;    // the order of off-diagonal indices, may be destroyed by pivoting
} swSparseLUSupernodes;

#endif
