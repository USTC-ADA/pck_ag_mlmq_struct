#ifndef SWSPARSE_TYPES_H_INCLUDED
#define SWSPARSE_TYPES_H_INCLUDED 1

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
    #ifdef SWSPARSE_USE_STD_COMPLEX
    #include <complex>
    #else
    #include "swSparse_complex.h"
    #endif
#else
    #ifdef SWSPARSE_USE_STD_COMPLEX
    #include <complex.h>
    #endif
    #include <stdbool.h>
#endif

/* MatrixStatus */
typedef uint32_t swSparseMatrixStatus;

/* ErrorStatus */
typedef enum swSparseE {
    SWSPARSE_SUCCESS, SWSPARSE_INVALID_ARGS, SWSPARSE_MALLOC_ERROR, SWSPARSE_IO_ERROR, SWSPARSE_NOT_SUPPORTED, SWSPARSE_UNKNOWN_ERROR
} swSparseErrorStatus;

/* Basic data types */
typedef bool swSparseBool;
typedef int32_t swSparseInt;

#ifdef __cplusplus
#define SWSPARSE_API extern "C" swSparseErrorStatus

#ifdef SWSPARSE_USE_STD_COMPLEX
typedef std::complex<float> swSparseSComplex;
typedef std::complex<double> swSparseDComplex;
#else
typedef swSparse::complex<float> swSparseSComplex;
typedef swSparse::complex<double> swSparseDComplex;
#endif

#else
#define SWSPARSE_API swSparseErrorStatus

/* ensure the calling convention of passing complex argument is consistent for C and C++  */
typedef struct { float real, imag; } swSparseSComplex;
typedef struct { double real, imag; } swSparseDComplex;

#endif

#endif
