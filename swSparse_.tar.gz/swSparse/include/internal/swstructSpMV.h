#ifndef SWSTRUCTSPMV_H_INCLUDED
#define SWSTRUCTSPMV_H_INCLUDED 1

#include "rename.h"
#include "swSparse_types.h"

typedef struct
{
    void *b;
    const void *a, *x;
    int nx, ny, nz;
    int lx, ly, lz;
    int ln,lm,ll;
    int height;
    int rank;
    int rnnz;
    int *pos;
    int row,col;

} Data_spmv;



#endif
