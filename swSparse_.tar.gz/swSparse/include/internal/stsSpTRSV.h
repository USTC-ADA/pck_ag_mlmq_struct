#ifndef STRUCT_SPTRSV_H_INCLUDED
#define STRUCT_SPTRSV_H_INCLUDED 1

#include "swSparse_base.h"
#include "internal/rename.h"
#include "internal/templates.h"

template<typename T>
void ststrsv_forward_execute(const T *l, T *x, const T *b, \
                    const int dim[3], int nnz, const int (*p)[2], \
                    int *col_id, int *z_off, int halo, int cols, int skew);

template<typename T>
void ststrsv_backward_execute(const T *l, T *x, const T *b, \
                    const int dim[3], int nnz, const int (*p)[2], \
                    int *col_id, int *z_off, int halo, int cols, int skew);

template<typename T>
struct struct_info{
    const T *a;
    T *x;
    const T *b;
    int M;
    int N;
    int L;
    int nnz;
    int *p;
    int *col_id;
    int *z_off;
    int halo;
    int cols;
    int skew;
};


#endif



