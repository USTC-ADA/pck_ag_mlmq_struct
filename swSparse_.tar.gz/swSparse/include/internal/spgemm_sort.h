#ifndef SPGEMM_SORT_H_INCLUDED
#define SPGEMM_SORT_H_INCLUDED

/*
 * THIS FILE IS NOT USED NOW
 */

#include "swSparse_base.h"
#include "internal/rename.h"
#include "internal/utils.h"
#include "internal/CPE_simd_utils.h"

#define SIGN_BIT (1 << 31)
#define MAX_ROW_BITS 5
#define MIN_COL_BITS 27

typedef struct {
    intv16 shfl_i[18];
    intv16 ioff_init;
} SortCombineD;

EXTERN int swSparse_d_sort_combine(int length, int *idx_in, void *val_in, \
                            int *idx_out, void *val_out, const SortCombineD *sc) NOTHROW;
EXTERN int swSparse_d_sort_combine_mr(int length, int *idx_in, void *val_in, \
                            int *idx_out, void *val_out, const SortCombineD *sc, int rowshift, int* rowcnt) NOTHROW;

EXTERN const int swSparse_prime_steps[32];

#ifdef __cplusplus
namespace swSparse {

template<typename DATA_T>
class sort_combiner {
    // not implemented
};

template<>
class sort_combiner<double> : public SortCombineD {
    int prime_steps[32];
public:
    constexpr static const int thres_min = 64, thres_max = 1024;

    sort_combiner() {
        DMA_DECL_DESC(READ);
        DMA_IREAD(swSparse_prime_steps, prime_steps, sizeof(swSparse_prime_steps));
        this->ioff_init = swSparse_intv16_iota << 2;
        swSparse_load_shuffle_indices(this->shfl_i, 0, 18);
        DMA_WAIT_ALL;
    }
    int get_step(int num_rows) const { return prime_steps[num_rows - 1]; }

    int sort_combine(int length, int *idx_in, double *val_in, int *idx_out, double *val_out) const {
        return swSparse_d_sort_combine(length, idx_in, val_in, idx_out, val_out, this);
    }
                  
    // compute multiple rows of SpGEMM
    // row and column indices are encoded into `idx_in`, but `idx_out` is only the decoded column indices
    // `rowcnt` has length `1 << (32 - rowshift)`, and must be initialized as 0         
    int sort_combine_mr(int length, int *idx_in, double *val_in, int *idx_out, double *val_out, int rowshift, int* rowcnt) const {
        return swSparse_d_sort_combine_mr(length, idx_in, val_in, idx_out, val_out, this, rowshift, rowcnt);
    }
};

inline constexpr const int sort_max_row_bits = 5, sort_max_n_row = 1 << sort_max_row_bits;

INLINE int get_row_index_bits(int n) {
    return min(sort_max_row_bits, __builtin_clz(n));
}

}
#endif

#endif


/*
// code for sorting spgemm
            // other types are not implemented
            if constexpr(std::is_same<DATA_T, double>::value) {
                if(flop <= sort_combiner<DATA_T>::thres_max) {
                    const Int rowbits = get_row_index_bits(n), max_nrow = min(1 << rowbits, r_end - (i + j));
                    Int sort_nrow, sort_cnt = flop, next_cnt = flop + local_c_rnz[j + 1];  // local_c_rnz[len] has dummy value

                    // check if compute multiple rows
                    for(sort_nrow = 1; sort_nrow < max_nrow && sort_cnt < sort_combiner<DATA_T>::thres_min \
                            && next_cnt <= sort_combiner<DATA_T>::thres_max; ++ sort_nrow) {
                        Int temp_j = j + sort_nrow + 1; // sort_nrow < max_nrow => temp_j <= r_end - i
                        sort_cnt = next_cnt;
                        
                        //  initial      : [ x x x x x x y y y y y y y y y ]
                        //  write back x : [ _ _ _ _ _ _ y y y y y y y y y ]
                        //  move forward : [ y y y y y y y y y _ _ _ _ _ _ ]
                        //  read z       : [ y y y y y y y y y z z z z z z ]
                        
                        if(UNLIKELY(temp_j == m_tile)) {  // j > 0, n_fill > 0
                            const Int i_end = i + m_tile, n_fill = min(j, r_end - i_end);
                            Int* i_space;
                            DMA_WRITE(c_row_nz + i, local_c_rnz, sizeof(Int) * j);
                            i_space = std::move(local_c_rnz + j, local_c_rnz + m_tile, local_c_rnz);
                            DMA_IREAD(c_row_nz + i_end, i_space, sizeof(Int) * n_fill);
                            i_space[n_fill] = L1_hash_size<DATA_T>;
                            i_space = std::move(local_a_off + j, local_a_off + m_tile + 1, local_a_off);
                            DMA_IREAD(a_row_off + (i_end + 1), i_space, sizeof(Int) * n_fill);
                            if(d_row_off != nullptr) {
                                i_space = std::move(local_d_off + j, local_d_off + m_tile + 1, local_d_off);
                                DMA_IREAD(a_row_off + (i_end + 1), i_space, sizeof(Int) * n_fill);
                            }
                            i += j;
                            j = 0;
                            len = min(m_tile, r_end - i);
                            DMA_WAIT_ALL;
                        }
                        
                        next_cnt += local_c_rnz[temp_j];
                    }

                    const Int rowshift = 32 - rowbits, maskdelta = 1 << rowshift;
                    const Int nvec = (sort_cnt + 15) >> 4, padded_cnt = nvec << 4;
                    const Int neg_step = - sort_combine.get_step(nvec), threshold = padded_cnt + neg_step;
                    Int *iout = L1_hash_idx + (L1_hash_size<DATA_T> >> 1);
                    DATA_T *vout = L1_hash_val + (L1_hash_size<DATA_T> >> 1);
                    Int isort = 0, rowmask = (sort_nrow == 1) ? 0 : SIGN_BIT;
                    for(Int jj = 0; jj < sort_nrow; ++ jj, rowmask += maskdelta) {
                        Int temp_j = j + jj;
                        Int a_begin = local_a_off[temp_j], a_end = local_a_off[temp_j + 1];
                        if (d_row_off != nullptr) {  // beta != 0
                            Int d_begin = local_d_off[temp_j], d_end = local_d_off[temp_j + 1];
                            for(Int r = d_begin; r < d_end; ++r) {
                                Int new_idx = isort - (isort < threshold) ? neg_step : threshold;
                                L1_hash_idx[isort] = rowmask | d_col_idx[r];
                                L1_hash_val[isort] = beta * d_values[r];
                                isort = new_idx;
                            }
                        }
                        for(Int p = a_begin; p < a_end; p += p_tile<DATA_T>) {
                            const Int rlen = min(p_tile<DATA_T>, a_end - p);
                            DMA_IREAD_2(a_values + p, local_a_val, rlen * sizeof(DATA_T));
                            DMA_IREAD(  a_col_idx + p, local_a_idx, rlen * sizeof(Int));
                            DMA_WAIT_ALL_2;
                            scale_kernel.template scale<ConjA>(local_a_val, rlen, alpha);  // overlap with DMA
                            DMA_WAIT_ALL;
                            for(Int q = 0; q < rlen; ++q) {
                                const Int k = local_a_idx[q], b_row_begin = b_row_off[k], b_row_end = b_row_off[k+1];
                                const DATA_T a_val = local_a_val[q];
                                for(Int r = b_row_begin; r < b_row_end; ++r) {
                                    Int new_idx = isort - (isort < threshold) ? neg_step : threshold;
                                    L1_hash_idx[isort] = rowmask | b_col_idx[r];
                                    L1_hash_val[isort] = a_val * ConjB::value(b_values[r]);
                                    isort = new_idx;
                                }
                            }
                        }
                    }
                    while(isort != 0) {
                        Int new_idx = isort - (isort < threshold) ? neg_step : threshold;
                        L1_hash_idx[isort] = L1_hash_idx[isort - 1];
                        L1_hash_val[isort] = DATA_T(0);
                        isort = new_idx;
                    }
                    if(sort_nrow == 1) {
                        c_rnz = sort_combine.sort_combine(padded_cnt, L1_hash_idx, L1_hash_val, iout, vout);
                        local_c_rnz[j] = c_rnz;
                    } else {
                        fill(local_rowcnt, sort_nrow, 0);
                        c_rnz = sort_combine.sort_combine_mr(padded_cnt, L1_hash_idx, L1_hash_val, iout, vout, rowshift, local_rowcnt);
                        memcpy(local_c_rnz + j, local_rowcnt, sizeof(Int) * sort_nrow);
                        j += (sort_nrow - 1);
                    }
                    c_nnz += c_rnz;
                    chunk_rest = chunk_size<DATA_T> - chunk_offset;
                    if(c_rnz > chunk_rest) {
                        Int temp_size = c_rnz - chunk_rest;
                        l_state->L2_begin = 0;
                        l_state->L2_end = 0;
                        l_state->L2_nnz = 0;
                        l_state->L1_nnz = temp_size;
                        l_state->begin_row = i + j + 1;
                        l_state->total_nnz = c_nnz;
                        DMA_IWRITE(chunk_idx + chunk_offset, iout, chunk_rest * sizeof(Int));
                        DMA_IWRITE(chunk_val + chunk_offset, vout, chunk_rest * sizeof(DATA_T));
                        DMA_IWRITE(c_row_nz + i, local_c_rnz, (j + 1) * sizeof(Int));
                        DMA_IWRITE(g_state, l_state, sizeof(spgemm_hash_state_t));
                        DMA_IWRITE(L1_dump_idx, iout + chunk_rest, temp_size * sizeof(Int));
                        DMA_WRITE (L1_dump_val, vout + chunk_rest, temp_size * sizeof(DATA_T));
                        return;
                    } else {
                        DMA_IWRITE(chunk_idx + chunk_offset, iout, c_rnz * sizeof(Int));
                        DMA_IWRITE(chunk_val + chunk_offset, vout, c_rnz * sizeof(DATA_T));
                        chunk_offset += c_rnz;
                        DMA_WAIT_ALL;
                        continue;
                    }
                }
            }
*/