#ifndef DEPENDENCY_H_INCLUDED
#define DEPENDENCY_H_INCLUDED 1
#include "swSparse_base.h"
#include "internal/rename.h"

HOST_C_FUNCTION void swSparse_level_csr_lower(Int n, const Int *row_offsets, const Int *column_indices, Int *levels) NOTHROW;
HOST_C_FUNCTION void swSparse_level_csr_upper(Int n, const Int *row_offsets, const Int *column_indices, Int *levels) NOTHROW;
HOST_C_FUNCTION void swSparse_level_csc_lower(Int n, const Int *column_offsets, const Int *row_indices, Int *levels) NOTHROW;
HOST_C_FUNCTION void swSparse_level_csc_upper(Int n, const Int *column_offsets, const Int *row_indices, Int *levels) NOTHROW;
HOST_C_FUNCTION void swSparse_level_csr_upper_reverse(Int n, const Int *row_offsets, const Int *column_indices, Int *levels) NOTHROW;
HOST_C_FUNCTION void swSparse_level_csc_upper_reverse(Int n, const Int *column_offsets, const Int *row_indices, Int *levels) NOTHROW;

#endif
