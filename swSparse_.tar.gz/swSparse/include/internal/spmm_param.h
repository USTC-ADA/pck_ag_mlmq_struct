#define worker_num 8
#define slaver_num 8
#define ins_tolerate 0.1
  
#ifdef DATA_TYPE_D

#undef ins_tile_size
#define ins_tile_size 256 
#undef ins_avg_blocks
#define ins_avg_blocks 4  
#undef ins_element_size
#define ins_element_size 32
#undef ins_cache_element_size
#define ins_cache_element_size 8

#undef BUFFER_B
#define  BUFFER_B 2048
#undef BUFFER_X
#define  BUFFER_X 2048
#undef BUFFER_NNZ
#define  BUFFER_NNZ 1024
#undef BUFFER_I
#define  BUFFER_I 128
#undef BUFFER_TASK
#define  BUFFER_TASK 128
#undef Size_RLC
#define  Size_RLC 1
#undef DATA_RLC
#define  DATA_RLC doublev4
  
#endif

#ifdef DATA_TYPE_S

#undef ins_tile_size
#define ins_tile_size 256 
#undef ins_avg_blocks
#define ins_avg_blocks 4  
#undef ins_element_size
#define ins_element_size 32
#undef ins_cache_element_size
#define ins_cache_element_size 8    

#undef BUFFER_B
#define  BUFFER_B 2048
#undef BUFFER_X
#define  BUFFER_X 2048  
#undef BUFFER_NNZ
#define  BUFFER_NNZ 1024
#undef BUFFER_I
#define  BUFFER_I 128
#undef BUFFER_TASK
#define  BUFFER_TASK 128
#undef Size_RLC
#define  Size_RLC 1
#undef DATA_RLC
#define  DATA_RLC floatv4 
#endif

#ifdef DATA_TYPE_Z

#undef ins_tile_size
#define ins_tile_size 128 
#undef ins_avg_blocks
#define ins_avg_blocks 2  
#undef ins_element_size
#define ins_element_size 16
#undef ins_cache_element_size
#define ins_cache_element_size 8

#undef BUFFER_B
#define  BUFFER_B 1024
#undef BUFFER_X
#define  BUFFER_X 1024
#undef BUFFER_NNZ
#define  BUFFER_NNZ 256
#undef BUFFER_I
#define  BUFFER_I 64
#undef BUFFER_TASK
#define  BUFFER_TASK 128
#undef Size_RLC
#define  Size_RLC 2
#undef DATA_RLC
#define  DATA_RLC doublev4
#undef DATA_CPY
#define  DATA_CPY doublev4  

#endif

#ifdef DATA_TYPE_C

#undef ins_tile_size
#define ins_tile_size 128 
#undef ins_avg_blocks
#define ins_avg_blocks 2  
#undef ins_element_size
#define ins_element_size 16
#undef ins_cache_element_size
#define ins_cache_element_size 8

#undef BUFFER_B
#define  BUFFER_B 1024
#undef BUFFER_X
#define  BUFFER_X 1024
#undef BUFFER_NNZ
#define  BUFFER_NNZ 256
#undef BUFFER_I
#define  BUFFER_I 64
#undef BUFFER_TASK
#define  BUFFER_TASK 128
#undef Size_RLC
#define  Size_RLC 2
#undef DATA_RLC
#define  DATA_RLC floatv4 
#undef DATA_CPY
#define  DATA_CPY floatv4  
#endif
