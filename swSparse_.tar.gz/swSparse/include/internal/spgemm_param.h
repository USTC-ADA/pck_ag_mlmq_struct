#ifndef SPGEMM_PARAM_H_INCLUDED
#define SPGEMM_PARAM_H_INCLUDED

#include <stddef.h>
#include "swSparse_base.h"
#include "internal/rename.h"
#include "internal/utils.h"

struct HES {
    Int begin_row, end_row, total_nnz;
    Int remain_begin, remain_end;
};

template<typename DATA_T>
struct HEB {
    DATA_T *chunk_val;
    Int *chunk_idx;
    DATA_T *temp_val;
    Int *temp_idx;
};

struct HAS {
    Int begin_row, end_row, total_nnz;
    Int L1_nnz, L2_begin, L2_end, L2_nnz;
};

template<typename DATA_T>
struct HAB {
    DATA_T *chunk_val;
    Int *chunk_idx;
    DATA_T *L1_dump_val;
    Int *L1_dump_idx;
    DATA_T *L2_val;
    Int *L2_idx;
};

template<typename TEMP, typename STATE>
struct PT {
    TEMP buffer;
    STATE state;
    Int chunk_offset;
};

using spgemm_heap_state_t = HES;
template<typename DATA_T>
using spgemm_heap_buffer_t = HEB<DATA_T>;
template<typename DATA_T>
using spgemm_heap_per_thread_t = PT<HEB<DATA_T>, HES>;

using spgemm_hash_state_t = HAS;
template<typename DATA_T>
using spgemm_hash_buffer_t = HAB<DATA_T>;
template<typename DATA_T>
using spgemm_hash_per_thread_t = PT<HAB<DATA_T>, HAS>;

template<typename DATA_T>
struct ARG0 {
    DATA_T alpha, beta;
    bool a_conj, b_conj;
    spgemm_heap_per_thread_t<DATA_T> *per_thread;
    const Int *a_row_off;
    const Int *a_col_idx;
    const DATA_T *a_values;
    const Int *b_row_off;
    const Int *b_col_idx;
    const DATA_T *b_values;
    const Int *d_row_off;
    const Int *d_col_idx;
    const DATA_T *d_values;
    Int *c_row_off;
    Int m, n;
#ifdef PARTITION_A_NNZ 
    Int a_nnz; // a_nnz for partition
#endif
};

template<typename DATA_T>
struct ARG1 {
    DATA_T alpha, beta;
    spgemm_hash_per_thread_t<DATA_T> *per_thread;
    const Int *a_row_off;
    const Int *a_col_idx;
    const DATA_T *a_values;
    const Int *b_row_off;
    const Int *b_col_idx;
    const DATA_T *b_values;
    const Int *d_row_off;
    const Int *d_col_idx;
    const DATA_T *d_values;
    Int *c_row_off;
    Int m, n; // a_nnz;
    bool a_conj, b_conj;
};

template<typename DATA_T>
using spgemm_heap_compute_arg_t = ARG0<DATA_T>;
template<typename DATA_T>
using spgemm_hash_compute_arg_t = ARG1<DATA_T>;

struct spgemm_result_t {
    void **buffers;
    Int nfull, last, tgt_offset, begin_row, end_row;
};

template<typename DATA_T>
struct spgemm_postprocess_arg_t {
    spgemm_result_t *results;
    Int *c_offsets;
    Int *c_col_idx;
    DATA_T *c_values;
};

namespace spgemm {

    template<typename DATA_T>
    struct PP {
        Int *c_col_idx;
        DATA_T *c_values;
    };

    template<typename DATA_T>
    struct COM {
        DATA_T alpha, beta;
        const Int *a_row_off;
        const Int *a_col_idx;
        const DATA_T *a_values;
        const Int *b_row_off;
        const Int *b_col_idx;
        const DATA_T *b_values;
        const Int *d_row_off;
        const Int *d_col_idx;
        const DATA_T *d_values;
        Int *c_row_off;
        Int m, n, config;
#ifdef SPGEMM_PARTITION_ANNZ
        Int a_nnz;
#define GET_ANNZ(args) , args.a_nnz
#define REQUIRE_ANNZ(a_nnz) , Int a_nnz
#else
#define GET_ANNZ(args)
#define REQUIRE_ANNZ(a_nnz)
#endif
    };

    struct EB {
        __atomic volatile int64_t sync_signal;
        int32_t dist[64 * CRTS_MAX_MPE_NUM];
        union {
            int64_t i64[64 * 3];
            int32_t i32[64 * CRTS_MAX_MPE_NUM];
        };
    };

    struct RT {
        void **buffers;
        Int nfull, last, tgt_offset;
    };

    struct ST {
        Int total_nnz;
        Bool complete;
    };
    
    struct CST {
        Int current_row, end_row, L1_nnz, L2_begin, L2_end, L2_nnz, total_nnz, chunk_offset;
        Int max_nnz;
    };

    template<typename DATA_T>
    union PT { // struct PT {
        HAB<DATA_T> buffer;
        RT result;
        ST state;
    };

    template<typename DATA_T>
    using compute_t = COM<DATA_T>;
    template<typename DATA_T>
    using postprocess_t = PP<DATA_T>;
    using ex_buffer_t = EB;
    template<typename DATA_T>
    using hash_buffer_t = HAB<DATA_T>;
    template<typename DATA_T>
    using perthread_t = PT<DATA_T>;
    using result_t = RT;
    using global_state_t = ST;
    using cpe_state_t = CST;

    template<typename DATA_T>
    struct arg_t {
        compute_t<DATA_T> compute_args;
        postprocess_t<DATA_T> postprocess_args;
        perthread_t<DATA_T> per_thread[64 * CRTS_MAX_MPE_NUM];
        ex_buffer_t exchange_buffer[CRTS_MAX_MPE_NUM];
    };
    
#define SYNC_SIGNAL_INITIAL  0ull
#define SYNC_SIGNAL_ECUT     0x11111111ull
#define SYNC_SIGNAL_BNFLOPS  0x22222222ull
#define SYNC_SIGNAL_ENFLOPS  0x33333333ull
#define SYNC_SIGNAL_BDIST    0x87654321ull
#define SYNC_SIGNAL_EDIST    0x12345678ull
#define SYNC_SIGNAL_BCOMP    0x88888888ull
#define SYNC_SIGNAL_MCOMP    0x99999999ull
#define SYNC_SIGNAL_ECOMP    0xabcdef01ull
#define SYNC_SIGNAL_BPOST    0x10fedcbaull
#define SYNC_SIGNAL_EXCEPT   0xffffffffull

#define CONFIG_MASK_COMPUTE_NCG     0x00000F
#define CONFIG_MASK_PREPROCESS_NCG  0x0000F0
#define CONFIG_SHIFT_PREPROCESS_NCG 4
#define CONFIG_MASK_FIRST_CG        0x000F00
#define CONFIG_SHIFT_FIRST_CG       8
#define CONFIG_MASK_NGROUP          0x00F000
#define CONFIG_SHIFT_NGROUP         12
#define CONFIG_MASK_JCUT_NCG        0x0F0000
#define CONFIG_SHIFT_JCUT_NCG       16
#define CONFIG_MASK_A_CONJUGATE     0x100000
#define CONFIG_MASK_B_CONJUGATE     0x200000

/* 2D SpGEMM, not inmplemented */
    template<typename DATA_T>
    struct PP2D {
        Int *c_row_off;
        Int *c_col_idx;
        DATA_T *c_values;
    };

    template<typename DATA_T>
    struct COM2D {
        DATA_T alpha, beta;
        const Int *a_row_off;
        const Int *a_col_idx;
        const DATA_T *a_values;
        const Int *b_row_off;
        const Int *b_col_idx;
        const DATA_T *b_values;
        const Int *d_row_off;
        const Int *d_col_idx;
        const DATA_T *d_values;
        const Int *b_row_off_2d;
        const Int *d_row_off_2d;
        Int *c_row_off_2d;
        Int m, n, a_nnz, config;
    };

    struct RT2D {
        void **buffers;
        Int *buff_offsets;
    };
    
    template<typename DATA_T>
    union PT2D {
        HAB<DATA_T> buffer;
        ST state;
    };

    template<typename DATA_T>
    using postprocess2d_t = PP2D<DATA_T>;
    template<typename DATA_T>
    using compute2d_t = COM2D<DATA_T>;
    template<typename DATA_T>
    using perthread2d_t = PT2D<DATA_T>;
    using result2d_t = RT2D;

    template<typename DATA_T>
    struct arg2d_t {
        compute2d_t<DATA_T> compute_args;
        postprocess2d_t<DATA_T> postprocess_args;
        perthread2d_t<DATA_T> per_thread[64 * CRTS_MAX_MPE_NUM];
        result2d_t results[CRTS_MAX_MPE_NUM];
        ex_buffer_t exchange_buffer[CRTS_MAX_MPE_NUM];
    };
}

template<size_t element_size, size_t cache_size>
struct spgemm_ldm_params;

template<size_t element_size>
struct spgemm_params;

template<>
struct spgemm_params<4> {
    constexpr static const int chunk_size_shift = 19;
    constexpr static const int p_tile = 128;
};
template<>
struct spgemm_params<8> {
    constexpr static const int chunk_size_shift = 18;
    constexpr static const int p_tile = 128;
};
template<>
struct spgemm_params<16> {
    constexpr static const int chunk_size_shift = 17;
    constexpr static const int p_tile = 64;
};


template<>
struct spgemm_ldm_params<4, 128> { // cache 128 kb
    constexpr static const int copy_tile = 4096;
    constexpr static const int L1_hash_size_shift = 13;  // 8192
};
template<>
struct spgemm_ldm_params<8, 128> {
    constexpr static const int copy_tile = 4096;
    constexpr static const int L1_hash_size_shift = 13;  // 8192
};
template<>
struct spgemm_ldm_params<16, 128> {
    constexpr static const int copy_tile = 2048;
    constexpr static const int L1_hash_size_shift = 12;  // 4096
};

template<>
struct spgemm_ldm_params<4, 32> { // cache 32 kb
    constexpr static const int copy_tile = 4096;
    constexpr static const int L1_hash_size_shift = 14;  // 16384
};
template<>
struct spgemm_ldm_params<8, 32> {
    constexpr static const int copy_tile = 4096;
    constexpr static const int L1_hash_size_shift = 14;  // 16384
};
template<>
struct spgemm_ldm_params<16, 32> {
    constexpr static const int copy_tile = 2048;
    constexpr static const int L1_hash_size_shift = 13;  // 8192
};


template<typename DATA_T>
inline constexpr const int chunk_size_shift = spgemm_params<sizeof(DATA_T)>::chunk_size_shift;
template<typename DATA_T>
inline constexpr const int chunk_size = 1 << chunk_size_shift<DATA_T>;
template<typename DATA_T>
inline constexpr const int chunk_size_mask = chunk_size<DATA_T> - 1;
template<typename DATA_T>
inline constexpr const int L1_hash_size_shift = spgemm_ldm_params<sizeof(DATA_T), 128>::L1_hash_size_shift;
template<typename DATA_T>
inline constexpr const int L1_hash_size = 1 << L1_hash_size_shift<DATA_T>;
template<typename DATA_T>
inline constexpr const int L1_hash_size_mask = L1_hash_size<DATA_T> - 1;
template<typename DATA_T>
inline constexpr const int L1_hash_max_1 = static_cast<int>(L1_hash_size<DATA_T> * 0.7);
template<typename DATA_T>
inline constexpr const int p_tile = spgemm_params<sizeof(DATA_T)>::p_tile;
template<size_t element_size>
inline constexpr const int chunk_size_i = 1 << spgemm_params<element_size>::chunk_size_shift;
template<size_t element_size>
inline constexpr const int copy_tile_i = spgemm_ldm_params<element_size, 128>::copy_tile;
template<typename DATA_T>
inline constexpr const int copy_tile = copy_tile_i<sizeof(DATA_T)>;
inline constexpr const int m_tile = 128;
inline constexpr const int ptr_tile = 256;
inline constexpr const int output_buffer_size = 512;
inline constexpr const int output_buffer_mask = output_buffer_size - 1;

template<typename DATA_T>
INLINE int L2_max_size(int n) {
    Int c = n - L1_hash_max_1<DATA_T>;
    return (c > 0) ? ceil_pow_2(c) : 0;
}

namespace swSparse {
void partition_spgemm_flops(Int m, const Int *a_row_off, const Int *a_col_idx, const Int* b_row_off, \
    const Int* d_row_off, Int *flops, Int *dist) NOTHROW;
}

#endif