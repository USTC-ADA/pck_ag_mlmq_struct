#ifndef CPE_COMMUNICATORS_H_INCLUDED
#define CPE_COMMUNICATORS_H_INCLUDED

/* functions on CPE */

#include <crts.h>
#include "internal/CPE.h"
#include "internal/templates.h"
#include "internal/utils.h"
#include "internal/CPE_utils.h"
#include "internal/CPE_simd_asm.h"

namespace swSparse {
namespace RDC {
template<typename T>
struct A {
    static inline void reduce(T *y, const T *x, int n_vec) NOTHROW {
        int j, j_end;
        for(j = 0, j_end = n_vec - 3; j < j_end; j += 4) {  // loop unrolling
            T x0 = x[j],    x1 = x[j+1],  x2 = x[j+2],  x3 = x[j+3];
            T y0 = y[j],    y1 = y[j+1],  y2 = y[j+2],  y3 = y[j+3];
            T z0 = x0 + y0, z1 = x1 + y1, z2 = x2 + y2, z3 = x3 + y3;
            y[j] = z0; y[j+1] = z1; y[j+2] = z2; y[j+3] = z3;
        }
        for(; j < n_vec; ++j) {
            y[j] += x[j];
        }
    }
};

struct MX {
    static inline void reduce(intv16 *y, const intv16 *x, int n_vec) NOTHROW {
        int j, j_end;
        const intv16 zero = 0;
        for(j = 0, j_end = n_vec - 3; j < j_end; j += 4) {  // loop unrolling
            intv16 x0 = x[j],    x1 = x[j+1],  x2 = x[j+2],  x3 = x[j+3];
            intv16 y0 = y[j],    y1 = y[j+1],  y2 = y[j+2],  y3 = y[j+3];
            intv16 m0 = simd_vcmpltw(x0, y0);
            intv16 m1 = simd_vcmpltw(x1, y1);
            intv16 m2 = simd_vcmpltw(x2, y2);
            intv16 m3 = simd_vcmpltw(x3, y3);
            intv16 k0 = zero - m0;
            intv16 k1 = zero - m1;
            intv16 k2 = zero - m2;
            intv16 k3 = zero - m3;
            intv16 z0 = simd_blend_i16(k0, x0, y0);
            intv16 z1 = simd_blend_i16(k1, x1, y1);
            intv16 z2 = simd_blend_i16(k2, x2, y2);
            intv16 z3 = simd_blend_i16(k3, x3, y3);
            y[j] = z0; y[j+1] = z1; y[j+2] = z2; y[j+3] = z3;
        }
        for(; j < n_vec; ++j) {
            intv16 x0 = x[j], y0 = y[j];
            intv16 z0 = simd_blend_i16(zero - simd_vcmpltw(x0, y0), x0, y0);
            y[j] = z0;
        }
    }
};

struct BO {
    static inline void reduce(intv16 *y, const intv16 *x, int n_vec) NOTHROW {
        int j, j_end;
        const intv16 zero = 0;
        for(j = 0, j_end = n_vec - 3; j < j_end; j += 4) {  // loop unrolling
            intv16 x0 = x[j],    x1 = x[j+1],  x2 = x[j+2],  x3 = x[j+3];
            intv16 y0 = y[j],    y1 = y[j+1],  y2 = y[j+2],  y3 = y[j+3];
            intv16 z0 = x0 | y0, z1 = x1 | y1, z2 = x2 | y2, z3 = x3 | y3;
            y[j] = z0; y[j+1] = z1; y[j+2] = z2; y[j+3] = z3;
        }
        for(; j < n_vec; ++j) {
            intv16 x0 = x[j], y0 = y[j];
            intv16 z0 = x0 | y0;
            y[j] = z0;
        }
    }
};
}

template<typename T>
inline void add(T *y, const T *x, int n_vec) {
    int j, j_end;
    for(j = 0, j_end = n_vec - 3; j < j_end; j += 4) {  // loop unrolling
        T x0 = x[j],    x1 = x[j+1],  x2 = x[j+2],  x3 = x[j+3];
        T y0 = y[j],    y1 = y[j+1],  y2 = y[j+2],  y3 = y[j+3];
        T z0 = x0 + y0, z1 = x1 + y1, z2 = x2 + y2, z3 = x3 + y3;
        y[j] = z0; y[j+1] = z1; y[j+2] = z2; y[j+3] = z3;
    }
    for(; j < n_vec; ++j) {
        y[j] += x[j];
    }
}

template<typename T>
using reduce_add_t = RDC::A<T>;
using reduce_imax_t = RDC::MX;
using reduce_bitor_t = RDC::BO;

template<typename T>
inline void rst_copy(T *y, const T *x, int n_vec, int tid) {
    T* yr = remote_ldm_addr(y, tid);
    int j, j_end;
    for(j = 0, j_end = n_vec - 3; j < j_end; j += 4) {  // loop unrolling
        T x0 = x[j], x1 = x[j+1],  x2 = x[j+2],  x3 = x[j+3];
        yr[j] = x0;  yr[j+1] = x1; yr[j+2] = x2; yr[j+3] = x3;
    }
    for(; j < n_vec; ++j) {
        yr[j] = x[j];
    }
}

/* synchronizer */
struct SA {
    void synchronize() const { CRTS_ssync_array(); }
};

/* mapper */
template<typename Sync>
struct M1 : public Sync {
    bool is_producer(int tid) const { return tid >> 5; }
    int tid2pid(int tid) const { return tid & 31; }
    int tid2cid(int tid) const { return tid; }
    int pid2tid(int pid) const { return pid | 32; }
    int cid2tid(int cid) const { return cid; }
};

template<typename Sync>
struct M2 : public Sync {
    bool is_producer(int tid) const { return (tid >> 4) & 1; }
    int tid2pid(int tid) const { return (tid & 15) | ((tid & 32) >> 1); }
    int tid2cid(int tid) const { return (tid & 15) | ((tid & 32) >> 1); }
    int pid2tid(int pid) const { return (pid | 16) | ((pid & 16) << 1); }
    int cid2tid(int cid) const { return (cid & 15) | ((cid & 16) << 1); }
};

template<typename Sync>
struct M3 : public Sync {
    bool is_producer(int tid) const { return ((tid >> 4) & 1) ^ (tid >> 5); }
    int tid2pid(int tid) const { return tid - 16; }
    int tid2cid(int tid) const { return tid & 31; }
    int pid2tid(int pid) const { return pid + 16; }
    int cid2tid(int cid) const { return cid | ((cid & 16) << 1); }
};

using simple_mapper = M1<SA>;
using strided_mapper = M2<SA>;
using sandwich_mapper = M3<SA>;

/* Send */
struct S1 {
    static inline void send(const void *src, size_t size, int tid, void *dst, crts_rply_t *reply) {
        mem_fence();
        CRTS_rma_put(const_cast<void*>(src), size, tid, dst, reply);
    }
};

template<typename granularity>
struct S2 {
    static inline void send(const void *src, size_t size, int tid, void *dst, crts_rply_t *reply, long sig){
        swSparse::rst_copy(static_cast<granularity*>(dst), static_cast<const granularity*>(src), size / sizeof(granularity), tid);
        mem_fence();
        *remote_ldm_addr(reply, tid) = sig;
    }
};

using rma_put_t = S1;
using rst_simd_t = S2<intv16>;

/* producer status */
struct producer_status_unit {
    crts_rply_t rma_complete;
    uint32_t count;
};

/* nonblock */
template <uint32_t n_consumers>
class producer_status_i {
    producer_status_unit status[n_consumers];

public:
    producer_status_i() {
        for (uint32_t i = 0; i < n_consumers; ++i) {
            status[i].rma_complete = 1;
            status[i].count = 0;
        }
    }

    producer_status_unit &operator[](int idx) {
        return status[idx];
    }
};

/* block */
template <uint32_t n_consumers>
class producer_status_b {
    uint32_t count[n_consumers];  
public:
    producer_status_b() {
        for (uint32_t i = 0; i < n_consumers; ++i) {
            count[i] = 0;
        }
    }

    uint32_t &operator[](int idx) {
        return count[idx];
    }
};

/* pc_communicators */
template <typename Mapper>
class pc_communicator_base : protected Mapper {
    int my_id;
    bool is_prod;

public:
    pc_communicator_base(int tid, const Mapper &mapper) : Mapper(mapper) {
        is_prod = Mapper::is_producer(tid);
        if (is_prod) {
            my_id = Mapper::tid2pid(tid);
        } else {
            my_id = Mapper::tid2cid(tid);
        }
    }
    int get_id() const { return my_id; }
    bool is_producer() const { return is_prod; }
};

template <typename Message, uint32_t buffer_size, typename Mapper, uint32_t n_neighbors>
class NBPC : public pc_communicator_base<Mapper> {
    buffer<Message, buffer_size> buffers_[n_neighbors][2];
    crts_rply_t signal_[n_neighbors][2];
    uint32_t which_[n_neighbors];

    void init_buffers(int signal) {
        for (int i = 0; i < n_neighbors; ++i) {
            signal_[i][0] = signal;
            signal_[i][1] = signal;
            which_[i] = 0;
        }
    }

public:
    using base = pc_communicator_base<Mapper>;
    using producer_status = producer_status_i<n_neighbors>;

    NBPC(int tid, const Mapper &mapper = Mapper()) : base(tid, mapper) {
        init_buffers(base::is_producer());
        base::synchronize();
    }
    ~NBPC() {
        base::synchronize();
    }

    void send(const Message &msg, uint32_t cid, producer_status &status) {
        uint32_t which = which_[cid];
        buffers_[cid][which].data[status[cid].count++] = msg;
        if (status[cid].count == buffer_size) {
            CRTS_rma_wait_value(&signal_[cid][which], 1);
            CRTS_rma_wait_value(&status[cid].rma_complete, 1);
            status[cid].rma_complete = 0;
            signal_[cid][which] = 0;
            mem_fence();
            CRTS_rma_iput(buffers_[cid][which].data, &status[cid].rma_complete,
                          sizeof(Message) * buffer_size, base::cid2tid(cid),
                          buffers_[base::get_id()][which].data, &signal_[base::get_id()][which]);
            which_[cid] = which ^ 1;
            status[cid].count = 0;
        }
    }

    void flush(int cid, producer_status &status) {
        if (status[cid].count > 0) {
            uint32_t which = which_[cid];
            CRTS_rma_wait_value(&signal_[cid][which], 1);
            CRTS_rma_wait_value(&status[cid].rma_complete, 1);
            signal_[cid][which] = 0;
            mem_fence();
            CRTS_rma_put(buffers_[cid][which].data, sizeof(Message) * status[cid].count,
                         base::cid2tid(cid), buffers_[base::get_id()][which].data,
                         &signal_[base::get_id()][which]);
            which_[cid] = which ^ 1;
            status[cid].count = 0;
        }
    }

    template <typename Mask, typename Function>
    void consume_message(Mask receive_mask, Function&& function) {
        for (uint32_t pid = 0; receive_mask != 0; pid = (pid + 1) % n_neighbors) {
            Mask bit = 1 << pid;
            if((receive_mask & bit) != 0) {
                uint32_t which = which_[pid];
                int signal = signal_[pid][which];
                if (signal != 0) {
                    for (uint32_t i = 0; i < buffer_size; ++i) {
                        auto is_last = function(buffers_[pid][which].data[i]);
                        if (is_last) {
                            receive_mask &= ~bit;
                            break;
                        }
                    }
                    crts_rply_t *remote = remote_ldm_addr(signal_[base::get_id()], base::pid2tid(pid));
                    which_[pid] = which ^ 1;
                    signal_[pid][which] = 0;
                    mem_fence();
                    remote[which] = 1;
                }
            }
        }
    }
};

template <typename Message, uint32_t buffer_size, typename Mapper, uint32_t n_neighbors, typename Send>
class BPC : public pc_communicator_base<Mapper>
{
    buffer<Message, buffer_size> buffers_[n_neighbors];
    crts_rply_t signal_[n_neighbors];

    void init_buffers(int signal)
    {
        for (int i = 0; i < n_neighbors; ++i)
        {
            signal_[i] = signal;
        }
    }

public:
    using base = pc_communicator_base<Mapper>;
    using producer_status = producer_status_b<n_neighbors>;

    BPC(int tid, const Mapper &mapper = Mapper()) : base(tid, mapper) {
        init_buffers(base::is_producer());
        base::synchronize();
    }
    ~BPC() {
        base::synchronize();
    }

    void send(const Message &msg, uint32_t cid, producer_status &status) {
        buffers_[cid].data[status[cid]++] = msg;
        if (status[cid] == buffer_size)
        {
            CRTS_rma_wait_value(&signal_[cid], 1);
            signal_[cid] = 0;
            Send::send(buffers_[cid].data, sizeof(Message) * buffer_size,
                       base::cid2tid(cid), buffers_[base::get_id()].data, &signal_[base::get_id()]);
            status[cid] = 0;
        }
    }

    void flush(int cid, producer_status &status) {
        if (status[cid] > 0) {
            CRTS_rma_wait_value(&signal_[cid], 1);
            signal_[cid] = 0;
            Send::send(buffers_[cid].data, sizeof(Message) * status[cid],
                       base::cid2tid(cid), buffers_[base::get_id()].data, &signal_[base::get_id()]);
            status[cid] = 0;
        }
    }

    template <typename Mask, typename Function>
    void consume_message(Mask receive_mask, Function&& function) {
        for (uint32_t pid = 0; receive_mask != 0; pid = (pid + 1) % n_neighbors) {
            Mask bit = 1 << pid;
            if((receive_mask & bit) != 0) {
                int signal = signal_[pid];
                if (signal != 0) {
                    for (uint32_t i = 0; i < buffer_size; ++i) {
                        auto is_last = function(pid, buffers_[pid].data[i]);
                        if (is_last) {
                            receive_mask &= ~bit;
                            break;
                        }
                    }
                    auto remote = remote_ldm_addr(&signal_[base::get_id()], base::pid2tid(pid));
                    signal_[pid] = 0;
                    mem_fence();
                    *remote = 1;
                }
            }
        }
    }
};

template<typename Message, uint32_t buffer_size, typename Send>
class RD {
    buffer<Message, buffer_size> buffer_;
    crts_rply_t remote_;
    long expect_;
    int tid_;
    
    // dummy Send
    struct SDUM {
        static inline void send(const void *src, size_t size, int tid, void *dst, crts_rply_t *reply) { }
    };

    template<typename Reduce>
    struct Recv {
        static inline void recv_reduce(Message* dst, size_t len, const Message* recv_buffer, crts_rply_t* reply, long& sig) {
            ++sig;
            CRTS_rma_wait_value(reply, sig);
            Reduce::reduce(dst, recv_buffer, len);
        }
    };

    // dummy RecvAdd
    struct RDUM {
        static inline void recv_reduce(Message* dst, size_t len, const Message* recv_buffer, crts_rply_t* reply, long sig) {}
    };

    template<typename SEND, typename RecvAdd>
    void sendrecv_reduce_template(int dest_id, Message *x, int n_msg) {
        for(int i = 0; i < n_msg; i += buffer_size) {
            int j, len = min(buffer_size, n_msg - i);
            Message *y = x + i;
            CRTS_ssync_peer(dest_id);
            SEND::send(y, sizeof(Message) * len, dest_id, buffer_.data, &remote_);
            RecvAdd::recv_reduce(y, len, buffer_.data, &remote_, expect_);
        }
    }
public:
    RD(int tid) : tid_(tid), remote_(0), expect_(0) {}

    template<typename Reduce>
    void allreduce(int nrow, int ncol, Message *x, int n_msg) {
        constexpr const int row_begin = TID(1, 0), col_begin = TID(0, 1);
        const int row_end = TID(nrow, 0), col_end = TID(0, ncol);
        for(int bit = col_begin; bit < col_end; bit = bit << 1) {
            sendrecv_reduce_template<Send, Recv<Reduce>>(tid_ ^ bit, x, n_msg);
        }
        for(int bit = row_begin; bit < row_end; bit = bit << 1) {
            sendrecv_reduce_template<Send, Recv<Reduce>>(tid_ ^ bit, x, n_msg);
        }
    }

    template<typename Reduce>
    void reduce(int root_id, int nrow, int ncol, Message *x, int n_msg) {
        constexpr const int row_begin = TID(1, 0), col_begin = TID(0, 1);
        const int diff = tid_ ^ root_id;
        const int col_diff = diff & COL_MASK, col_end = lowest_bit(col_diff | TID(0, ncol));
        for(int bit = col_begin; bit < col_end; bit = bit << 1) {
            sendrecv_reduce_template<SDUM, Recv<Reduce>>(tid_ ^ bit, x, n_msg);
        }
        if(col_diff != 0) {
            sendrecv_reduce_template<Send, RDUM>(tid_ ^ col_end, x, n_msg);
            return;
        }
        const int row_diff = diff & ROW_MASK, row_end = lowest_bit(row_diff | TID(nrow, 0));
        for(int bit = row_begin; bit < row_end; bit = bit << 1) {
            sendrecv_reduce_template<SDUM, Recv<Reduce>>(tid_ ^ bit, x, n_msg);
        }
        if(row_diff != 0) {
            sendrecv_reduce_template<Send, RDUM>(tid_ ^ row_end, x, n_msg);
        }
    }
    void reduce_sum(int root_id, int nrow, int ncol, Message *x, int n_msg) {
        reduce<swSparse::reduce_add_t<Message>>(root_id, nrow, ncol, x, n_msg);
    }
    void allreduce_sum(int nrow, int ncol, Message *x, int n_msg) {
        allreduce<swSparse::reduce_add_t<Message>>(nrow, ncol, x, n_msg);
    }
};

template<typename Message, uint32_t buffer_size, typename Send>
class RD_F {
    buffer<Message, buffer_size> buffer_;
    crts_rply_t remote_;
    int tid_;
    
    // dummy Send
    struct SDUM {
        static inline void send(const void *src, size_t size, int tid, void *dst, crts_rply_t *reply, long sig) { }
    };

    struct RecvAdd {
        static inline void recv_add(Message* dst, size_t len, const Message* recv_buffer, crts_rply_t* reply, long sig) {
            CRTS_rma_wait_value(reply, sig);
            swSparse::add(dst, recv_buffer, len);
        }
    };

    // dummy RecvAdd
    struct RDUM {
        static inline void recv_add(Message* dst, size_t len, const Message* recv_buffer, crts_rply_t* reply, long sig) {}
    };

    template<typename SEND, typename RecvAdd>
    void sendrecv_add_template(int dest_id, Message *x, int n_msg) {
        long count = remote_;
        for(int i = 0; i < n_msg; i += buffer_size) {
            int j, len = min(buffer_size, n_msg - i);
            Message *y = x + i;
            CRTS_ssync_peer(dest_id);
            SEND::send(y, sizeof(Message) * len, dest_id, buffer_.data, &remote_, ++count);
            RecvAdd::recv_add(y, len, buffer_.data, &remote_, count);
        }
    }
public:
    RD_F(int tid) : tid_(tid), remote_(0) {}
    void sendrecv_add(int dest_id, Message *x, int n_msg) {
        sendrecv_add_template<Send, RecvAdd>(dest_id, x, n_msg);
    }
    void recv_add(int dest_id, Message *x, int n_msg) {
        sendrecv_add_template<SDUM, RecvAdd>(dest_id, x, n_msg);
    }
    void send(int dest_id, Message *x, int n_msg) {
        sendrecv_add_template<Send, RDUM>(dest_id, x, n_msg);
    }

    void allreduce_sum(int nrow, int ncol, Message *x, int n_msg) {
        constexpr const int row_begin = TID(1, 0), col_begin = TID(0, 1);
        const int row_end = TID(nrow, 0), col_end = TID(0, ncol);
        for(int bit = col_begin; bit < col_end; bit = bit << 1) {
            sendrecv_add(tid_ ^ bit, x, n_msg);
        }
        for(int bit = row_begin; bit < row_end; bit = bit << 1) {
            sendrecv_add(tid_ ^ bit, x, n_msg);
        }
    }

    void reduce_sum(int root_id, int nrow, int ncol, Message *x, int n_msg) {
        constexpr const int row_begin = TID(1, 0), col_begin = TID(0, 1);
        const int diff = tid_ ^ root_id;
        const int col_diff = diff & COL_MASK, col_end = lowest_bit(col_diff | TID(0, ncol));
        for(int bit = col_begin; bit < col_end; bit = bit << 1) {
            recv_add(tid_ ^ bit, x, n_msg);
        }
        if(col_diff != 0) {
            send(tid_ ^ col_end, x, n_msg);
            remote_ = 0;
            return;
        }
        const int row_diff = diff & ROW_MASK, row_end = lowest_bit(row_diff | TID(nrow, 0));
        for(int bit = row_begin; bit < row_end; bit = bit << 1) {
            recv_add(tid_ ^ bit, x, n_msg);
        }
        if(row_diff != 0) {
            send(tid_ ^ row_end, x, n_msg);
        }
        remote_ = 0;
    }
};

template <typename Message, uint32_t buffer_size, typename Mapper = sandwich_mapper, uint32_t n_neighbors = 32>
using iput_pc_communicator = NBPC<Message, buffer_size, Mapper, n_neighbors>;
template <typename Message, uint32_t buffer_size, typename Mapper = sandwich_mapper, uint32_t n_neighbors = 32>
using put_pc_communicator = BPC<Message, buffer_size, Mapper, n_neighbors, rma_put_t>;

template <typename Message, uint32_t buffer_size>
using put_rd_communicator = RD<Message, buffer_size, rma_put_t>;
template <typename Message, uint32_t buffer_size>
using rst_rd_communicator = RD_F<Message, buffer_size, rst_simd_t>;

/* 
 * organize a 2D-mesh into 1D-ring
 * establish a bijection between (row_id, col_id) between (rank, prev, next) 
 */

struct RING {
    int rank, prev, next;
    /* Constructors */
    RING(int tid_this, int tid_first_row_first_col, int rows, int cols) NOTHROW;
    void sync_neighbor() const {
        if((this->rank & 1) == 0) {
            CRTS_ssync_peer(this->next);
            CRTS_ssync_peer(this->prev);
        } else {
            CRTS_ssync_peer(this->prev);
            CRTS_ssync_peer(this->next);
        }
    }
};

using cpe_ring = RING;

/* 
 * rows and cols must be 2, 4 or 8
 * example: if you want to organize these 4x4 mesh into a unidirectional ring
 * 
 *  --- --- --- --- --- --- --- ---
 * |   |   |   |   |   |   |   |   |
 *  --- --- --- --- --- --- --- ---
 * |   |   |   |   |   |   |   |   |
 *  --- --- --- --- --- --- --- ---
 * |   |   |   |   |   |   |   |   |
 *  --- --- --- --- --- --- --- ---
 * |   |   |   |   |   |   |   |   |
 *  --- --- --- --- --- --- --- ---
 * |   |   |   |   | x | x | x | x |
 *  --- --- --- --- --- --- --- ---
 * |   |   |   |   | x | x | x | x |
 *  --- --- --- --- --- --- --- ---
 * |   |   |   |   | x | x | x | x |
 *  --- --- --- --- --- --- --- ---
 * |   |   |   |   | x | x | x | x |
 *  --- --- --- --- --- --- --- ---
 *   0   1   2   3   4   5   6   7
 * 
 * then call cpe_ring ring(my_id, 36, 4, 4, col_major_t());
 */

int write_all_sum_int2(int i0, int i1, Int *mem) NOTHROW;
template<typename REAL_T>
void write_max_real(REAL_T value, REAL_T *mem) NOTHROW;

}

#endif
