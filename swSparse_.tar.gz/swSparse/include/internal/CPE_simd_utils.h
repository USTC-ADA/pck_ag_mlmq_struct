#ifndef CPE_SIMD_UTILS_H_INCLUDED 
#define CPE_SIMD_UTILS_H_INCLUDED 1

/*
 * TO sw9gcc:
 *     please change
 *         intv16 __builtin_sw_load(int*); 
 *     to 
 *         intv16 __builtin_sw_load(const int*);
 * 
 * simd_load is not used in swSparse for now, because it discards `const` qualifier.
 */

/* functions on CPE */

#include <crts.h>
#include <simd.h>
#include "internal/CPE.h"
#include "internal/utils.h"
#include "internal/CPE_utils.h"

/*
 * data transformation between 
 * column-major layout or AOS complex number layout (input/output of interface) 
 * and SIMD layout
 * used in SpMM, SpTRSM and on-LDM BLAS
 */

/* Don't use these directly */
#define SWSPARSE_INDEX_SHUFFLE_4_BYTES  14
#define SWSPARSE_INDEX_SHUFFLE_8_BYTES  18
EXTERN const intv16 swSparse_intv16_iota;
EXTERN void swSparse_load_shuffle_indices(void *index, int offset, int size) NOTHROW;
EXTERN void swSparse_colmaj2simd_shuffle(const void *RSTR x, void *RSTR y, int n_bytes, int ld_bytes, const intv16 shuffle_idx[]) NOTHROW;
EXTERN void swSparse_simd2colmaj_shuffle(const void *RSTR x, void *RSTR y, int n_bytes, int ld_bytes, const intv16 shuffle_idx[]) NOTHROW;
EXTERN void swSparse_cplx_simd_shuffle(void *RSTR x, int n_bytes, const intv16 shuffle_idx[]) NOTHROW;

#ifdef __cplusplus
#include "internal/templates.h"

namespace swSparse {
// C++ overloads

#define OVERLOAD_SIMD_SHUFFLE(name, vtype) \
INLINE vtype simd_shuffle(vtype a, vtype b, intv16 idx) { return name(a, b, idx); }
#define OVERLOAD_SIMD_CONCAT(name, vtype, stype) \
INLINE vtype simd_concat(vtype a, vtype b, intptr_t idx) { return name(a, b, (void*)(idx * sizeof(stype))); }
OVERLOAD_SIMD_SHUFFLE(simd_vshfw, intv16)
OVERLOAD_SIMD_SHUFFLE(simd_vshfd, doublev8)
OVERLOAD_SIMD_SHUFFLE(simd_vshfs, floatv8)
OVERLOAD_SIMD_CONCAT(simd_vconw, intv16, int)
OVERLOAD_SIMD_CONCAT(simd_vcond, doublev8, double)
OVERLOAD_SIMD_CONCAT(simd_vcons, floatv8, float)

/* abstraction over simd intrinsics */

#define OVERLOAD_SIMD_INTRINSICS_V2S(overload_name, intrinsic_name_s, intrinsic_name_d, intrinsic_name_i) \
INLINE float    overload_name(floatv8 a)     { return intrinsic_name_s(a); } \
INLINE double   overload_name(doublev8 a)    { return intrinsic_name_d(a); } \
INLINE SComplex overload_name(SV8Complex a)  { return SComplex(intrinsic_name_s(a.real), intrinsic_name_s(a.imag)); } \
INLINE DComplex overload_name(DV8Complex a)  { return DComplex(intrinsic_name_d(a.real), intrinsic_name_d(a.imag)); } \
INLINE int      overload_name(intv16 a)     { return intrinsic_name_i(a); }

#define OVERLOAD_SIMD_INTRINSICS_SV2V(overload_name, intrinsic_name_s, intrinsic_name_d, intrinsic_name_i) \
INLINE floatv8    overload_name(float i, floatv8 a)     { return intrinsic_name_s(i, a); } \
INLINE doublev8   overload_name(double i, doublev8 a)    { return intrinsic_name_d(i, a); } \
INLINE SV8Complex overload_name(SComplex i, SV8Complex a)  { return SV8Complex(intrinsic_name_s(i.real, a.real), intrinsic_name_s(i.imag, a.imag)); } \
INLINE DV8Complex overload_name(DComplex i, DV8Complex a)  { return DV8Complex(intrinsic_name_d(i.real, a.real), intrinsic_name_d(i.imag, a.imag)); } \
INLINE intv16     overload_name(int x, intv16 y) { return intrinsic_name_i(x, y); }

OVERLOAD_SIMD_INTRINSICS_V2S(simd_extract0,  simd_vextfs0, simd_vextfd0, simd_vextw0)
OVERLOAD_SIMD_INTRINSICS_V2S(simd_extract1,  simd_vextfs1, simd_vextfd1, simd_vextw1)
OVERLOAD_SIMD_INTRINSICS_V2S(simd_extract2,  simd_vextfs2, simd_vextfd2, simd_vextw2)
OVERLOAD_SIMD_INTRINSICS_V2S(simd_extract3,  simd_vextfs3, simd_vextfd3, simd_vextw3)
OVERLOAD_SIMD_INTRINSICS_V2S(simd_extract4,  simd_vextfs4, simd_vextfd4, simd_vextw4)
OVERLOAD_SIMD_INTRINSICS_V2S(simd_extract5,  simd_vextfs5, simd_vextfd5, simd_vextw5)
OVERLOAD_SIMD_INTRINSICS_V2S(simd_extract6,  simd_vextfs6, simd_vextfd6, simd_vextw6)
OVERLOAD_SIMD_INTRINSICS_V2S(simd_extract7,  simd_vextfs7, simd_vextfd7, simd_vextw7)
OVERLOAD_SIMD_INTRINSICS_SV2V(simd_insert0,  simd_vinsfs0, simd_vinsfd0, simd_vinsw0)
OVERLOAD_SIMD_INTRINSICS_SV2V(simd_insert1,  simd_vinsfs1, simd_vinsfd1, simd_vinsw1)
OVERLOAD_SIMD_INTRINSICS_SV2V(simd_insert2,  simd_vinsfs2, simd_vinsfd2, simd_vinsw2)
OVERLOAD_SIMD_INTRINSICS_SV2V(simd_insert3,  simd_vinsfs3, simd_vinsfd3, simd_vinsw3)
OVERLOAD_SIMD_INTRINSICS_SV2V(simd_insert4,  simd_vinsfs4, simd_vinsfd4, simd_vinsw4)
OVERLOAD_SIMD_INTRINSICS_SV2V(simd_insert5,  simd_vinsfs5, simd_vinsfd5, simd_vinsw5)
OVERLOAD_SIMD_INTRINSICS_SV2V(simd_insert6,  simd_vinsfs6, simd_vinsfd6, simd_vinsw6)
OVERLOAD_SIMD_INTRINSICS_SV2V(simd_insert7,  simd_vinsfs7, simd_vinsfd7, simd_vinsw7)


/* broadcast */
INLINE floatv8    simd_broadcast(float a)    { floatv8 av = a; return av; }
INLINE doublev8   simd_broadcast(double a)   { doublev8 av = a; return av; }
INLINE SV8Complex simd_broadcast(SComplex a)   { floatv8 r = a.real, i = a.imag; return SV8Complex(r, i); }
INLINE DV8Complex simd_broadcast(DComplex a)   { doublev8 r = a.real, i = a.imag; return DV8Complex(r, i); }
/* c - a * b */
template<typename Btype>
INLINE floatv8    simd_nma(floatv8 a, Btype b, floatv8 c)        { return simd_vnmas(a, b, c); }
template<typename Btype>
INLINE doublev8   simd_nma(doublev8 a, Btype b, doublev8 c)      { return simd_vnmad(a, b, c); }
template<typename Btype>
INLINE SV8Complex simd_nma(SV8Complex a, Btype b, SV8Complex c)  {
    floatv8 r = simd_vnmas(a.real, b.real, simd_vmas(a.imag, b.imag, c.real));
    floatv8 i = simd_vnmas(a.real, b.imag, simd_vnmas(a.imag, b.real, c.imag));
    return SV8Complex(r, i);
}
template<typename Btype>
INLINE DV8Complex simd_nma(DV8Complex a, Btype b, DV8Complex c)  {
    doublev8 r = simd_vnmad(a.real, b.real, simd_vmad(a.imag, b.imag, c.real));
    doublev8 i = simd_vnmad(a.real, b.imag, simd_vnmad(a.imag, b.real, c.imag));
    return DV8Complex(r, i);
}

// [A,B,C,D], [a,b,c,d] -----shuffle-----> [A,a,B,b], [C,c,D,d]
// [A,a,B,b], [C,c,D,d] ----unshuffle----> [A,B,C,D], [a,b,c,d]
template<int GRANULARITY>
class shuffler {
    intv16 index[4];
public:
    INLINE shuffler() {
        swSparse_load_shuffle_indices(index, SWSPARSE_INDEX_SHUFFLE_4_BYTES - 4 + GRANULARITY, 4);
    }
    INLINE const intv16* shuffle() const {
        return &index[0];
    }
    INLINE const intv16* unshuffle() const {
        return &index[2];
    }
    INLINE intv16 shuffle_lo() const {
        return index[0];
    }
    INLINE intv16 shuffle_hi() const {
        return index[1];
    }
    INLINE intv16 unshuffle_lo() const {
        return index[2];
    }
    INLINE intv16 unshuffle_hi() const {
        return index[3];
    }
};

class simd_register_transposer {  // for dense TRSM in LU
protected:
    shuffler<sizeof(double)> shfl;
public:
    template<typename SIMD_REAL_T>
    INLINE void transpose_8x8(SIMD_REAL_T& x0, SIMD_REAL_T& x1, SIMD_REAL_T& x2, SIMD_REAL_T& x3, \
                          SIMD_REAL_T& x4, SIMD_REAL_T& x5, SIMD_REAL_T& x6, SIMD_REAL_T& x7) const {
        SIMD_REAL_T z0, z1, z2, z3, z4, z5, z6, z7, y0, y1, y2, y3, y4, y5, y6, y7;
        const intv16 shflo = shfl.shuffle_lo();
        const intv16 shfhi = shfl.shuffle_hi();
        y0 = simd_shuffle(x0, x4, shflo);
        y4 = simd_shuffle(x0, x4, shfhi);
        y1 = simd_shuffle(x1, x5, shflo);
        y5 = simd_shuffle(x1, x5, shfhi);
        y2 = simd_shuffle(x2, x6, shflo);
        y6 = simd_shuffle(x2, x6, shfhi);
        y3 = simd_shuffle(x3, x7, shflo);
        y7 = simd_shuffle(x3, x7, shfhi);
        z0 = simd_shuffle(y0, y2, shflo);
        z2 = simd_shuffle(y0, y2, shfhi);
        z1 = simd_shuffle(y1, y3, shflo);
        z3 = simd_shuffle(y1, y3, shfhi);
        z4 = simd_shuffle(y4, y6, shflo);
        z6 = simd_shuffle(y4, y6, shfhi);
        z5 = simd_shuffle(y5, y7, shflo);
        z7 = simd_shuffle(y5, y7, shfhi);
        x0 = simd_shuffle(z0, z1, shflo);
        x1 = simd_shuffle(z0, z1, shfhi);
        x2 = simd_shuffle(z2, z3, shflo);
        x3 = simd_shuffle(z2, z3, shfhi);
        x4 = simd_shuffle(z4, z5, shflo);
        x5 = simd_shuffle(z4, z5, shfhi);
        x6 = simd_shuffle(z6, z7, shflo);
        x7 = simd_shuffle(z6, z7, shfhi);
    }
    template<typename SIMD_REAL_T>
    INLINE void transpose_4x8(SIMD_REAL_T& x0, SIMD_REAL_T& x1, SIMD_REAL_T& x2, SIMD_REAL_T& x3, \
                          const SIMD_REAL_T& x4, const SIMD_REAL_T& x5, const SIMD_REAL_T& x6, const SIMD_REAL_T& x7) const {
        SIMD_REAL_T z0, z1, z2, z3, y0, y1, y2, y3;
        const intv16 shflo = shfl.shuffle_lo();
        const intv16 shfhi = shfl.shuffle_hi();
        y0 = simd_shuffle(x0, x4, shflo);
        y1 = simd_shuffle(x1, x5, shflo);
        y2 = simd_shuffle(x2, x6, shflo);
        y3 = simd_shuffle(x3, x7, shflo);
        z0 = simd_shuffle(y0, y2, shflo);
        z2 = simd_shuffle(y0, y2, shfhi);
        z1 = simd_shuffle(y1, y3, shflo);
        z3 = simd_shuffle(y1, y3, shfhi);
        x0 = simd_shuffle(z0, z1, shflo);
        x1 = simd_shuffle(z0, z1, shfhi);
        x2 = simd_shuffle(z2, z3, shflo);
        x3 = simd_shuffle(z2, z3, shfhi);
    }
    // the input value of x4567 is not used
    template<typename SIMD_REAL_T>
    INLINE void transpose_8x4(SIMD_REAL_T& x0, SIMD_REAL_T& x1, SIMD_REAL_T& x2, SIMD_REAL_T& x3, \
                          SIMD_REAL_T& x4, SIMD_REAL_T& x5, SIMD_REAL_T& x6, SIMD_REAL_T& x7) const {
        SIMD_REAL_T z0, z1, z2, z3, y0, y1, y2, y3;
        const intv16 shflo = shfl.unshuffle_lo();
        const intv16 shfhi = shfl.unshuffle_hi();
        y0 = simd_shuffle(x0, x1, shflo);
        y1 = simd_shuffle(x0, x1, shfhi);
        y2 = simd_shuffle(x2, x3, shflo);
        y3 = simd_shuffle(x2, x3, shfhi);
        z0 = simd_shuffle(y0, y2, shflo);
        z2 = simd_shuffle(y0, y2, shfhi);
        z1 = simd_shuffle(y1, y3, shflo);
        z3 = simd_shuffle(y1, y3, shfhi);
        x0 = simd_shuffle(z0, z0, shflo);
        x4 = simd_shuffle(z0, z0, shfhi);
        x1 = simd_shuffle(z1, z1, shflo);
        x5 = simd_shuffle(z1, z1, shfhi);
        x2 = simd_shuffle(z2, z2, shflo);
        x6 = simd_shuffle(z2, z2, shfhi);
        x3 = simd_shuffle(z3, z3, shflo);
        x7 = simd_shuffle(z3, z3, shfhi);
    }
    
    template<typename SIMD_REAL_T>
    INLINE void transpose_2x8(SIMD_REAL_T& x0, SIMD_REAL_T& x1, const SIMD_REAL_T& x2, const SIMD_REAL_T& x3, \
                          const SIMD_REAL_T& x4, const SIMD_REAL_T& x5, const SIMD_REAL_T& x6, const SIMD_REAL_T& x7) const {
        SIMD_REAL_T z0, z1, y0, y1, y2, y3;
        const intv16 shflo = shfl.shuffle_lo();
        const intv16 shfhi = shfl.shuffle_hi();
        y0 = simd_shuffle(x0, x4, shflo);
        y1 = simd_shuffle(x1, x5, shflo);
        y2 = simd_shuffle(x2, x6, shflo);
        y3 = simd_shuffle(x3, x7, shflo);
        z0 = simd_shuffle(y0, y2, shflo);
        z1 = simd_shuffle(y1, y3, shflo);
        x0 = simd_shuffle(z0, z1, shflo);
        x1 = simd_shuffle(z0, z1, shfhi);
    }
    // the input value of x234567 is not used
    template<typename SIMD_REAL_T>
    INLINE void transpose_8x2(SIMD_REAL_T& x0, SIMD_REAL_T& x1, SIMD_REAL_T& x2, SIMD_REAL_T& x3, \
                          SIMD_REAL_T& x4, SIMD_REAL_T& x5, SIMD_REAL_T& x6, SIMD_REAL_T& x7) const {
        SIMD_REAL_T y0, y1;
        const intv16 shflo = shfl.shuffle_lo();
        const intv16 shfhi = shfl.shuffle_hi();
        x4 = simd_shuffle(x0, x1, shfhi);
        x0 = simd_shuffle(x0, x1, shflo);
        x1 = simd_concat(x0, x0, 2);
        x2 = simd_concat(x0, x0, 4);
        x3 = simd_concat(x0, x0, 6);
        x5 = simd_concat(x4, x4, 2);
        x6 = simd_concat(x4, x4, 4);
        x7 = simd_concat(x4, x4, 6);
    }
    template<typename SIMD_REAL_T>
    INLINE void transpose_4x4(SIMD_REAL_T& x0, SIMD_REAL_T& x1, SIMD_REAL_T& x2, SIMD_REAL_T& x3) const {
        SIMD_REAL_T y0, y1;
        const intv16 shflo = shfl.shuffle_lo();
        const intv16 shfhi = shfl.shuffle_hi();
        y0 = simd_shuffle(x0, x2, shflo);
        y1 = simd_shuffle(x1, x3, shflo);
        x0 = simd_shuffle(y0, y1, shflo);
        x2 = simd_shuffle(y0, y1, shfhi);
        x1 = simd_concat(x0, x0, 4);
        x3 = simd_concat(x2, x2, 4);
    }
    template<typename SIMD_REAL_T>
    INLINE void transpose_2x4(SIMD_REAL_T& x0, SIMD_REAL_T& x1, const SIMD_REAL_T& x2, const SIMD_REAL_T& x3) const {
        SIMD_REAL_T y0, y1;
        const intv16 shflo = shfl.shuffle_lo();
        const intv16 shfhi = shfl.shuffle_hi();
        y0 = simd_shuffle(x0, x2, shflo);
        y1 = simd_shuffle(x1, x3, shflo);
        x0 = simd_shuffle(y0, y1, shflo);
        x1 = simd_concat(x0, x0, 4);
    }
    template<typename SIMD_REAL_T>
    INLINE void transpose_4x2(SIMD_REAL_T& x0, SIMD_REAL_T& x1, SIMD_REAL_T& x2, SIMD_REAL_T& x3) const {
        SIMD_REAL_T y0, y1;
        const intv16 shflo = shfl.shuffle_lo();
        const intv16 shfhi = shfl.shuffle_hi();
        y0 = simd_shuffle(x0, x0, shflo);
        y1 = simd_shuffle(x1, x1, shflo);
        x0 = simd_shuffle(y0, y1, shflo);
        x2 = simd_shuffle(y0, y1, shfhi);
        x1 = simd_concat(x0, x0, 4);
        x3 = simd_concat(x2, x2, 4);
    }
    template<typename SIMD_REAL_T>
    INLINE void transpose_2x2(SIMD_REAL_T& x0, SIMD_REAL_T& x1) const {
        const intv16 shflo = shfl.shuffle_lo();
        const intv16 shfhi = shfl.shuffle_hi();
        x0 = simd_shuffle(x0, x1, shflo);
        x1 = simd_concat(x0, x0, 2);
    }
};

// 实数，不需要转换
class dummy_real {
public:
    template<typename SIMD_T>
    INLINE void complex_to_simd(SIMD_T *RSTR x, int n_vec) const {}
    template<typename SIMD_T>
    INLINE void simd_to_complex(SIMD_T *RSTR x, int n_vec) const {}
    template<typename SIMD_T>
    INLINE SIMD_T complex_to_simd(SIMD_T x) const { return x; }
    template<typename SIMD_T>
    INLINE SIMD_T simd_to_complex(SIMD_T x) const { return x; }
};

// 单精度复数
class c_simd_ldm_converter {
    shuffler<sizeof(float)> shfl;
public:
    INLINE void complex_to_simd(SV8Complex *RSTR x, int n_vec) const {  // unshuffle
        swSparse_cplx_simd_shuffle(x, n_vec * sizeof(SV8Complex), shfl.unshuffle());
    }
    INLINE void simd_to_complex(SV8Complex *RSTR x, int n_vec) const {  // shuffle
        swSparse_cplx_simd_shuffle(x, n_vec * sizeof(SV8Complex), shfl.shuffle());
    }
};

// 双精度复数
class z_simd_converter : public simd_register_transposer { // reuse shuffle indices
public:
    template<typename SIMD_REAL_T>
    INLINE complex<SIMD_REAL_T> complex_to_simd(complex<SIMD_REAL_T> x) const {
        SIMD_REAL_T ya = simd_shuffle(x.real, x.imag, this->shfl.unshuffle_lo());
        SIMD_REAL_T yb = simd_shuffle(x.real, x.imag, this->shfl.unshuffle_hi());  // unshuffle
        return complex<SIMD_REAL_T>(ya, yb);
    }
    template<typename SIMD_REAL_T>
    INLINE complex<SIMD_REAL_T> simd_to_complex(complex<SIMD_REAL_T> x) const {
        SIMD_REAL_T ya = simd_shuffle(x.real, x.imag, this->shfl.shuffle_lo());
        SIMD_REAL_T yb = simd_shuffle(x.real, x.imag, this->shfl.shuffle_hi());  // shuffle
        return complex<SIMD_REAL_T>(ya, yb);
    }
    INLINE void complex_to_simd(DV8Complex *RSTR x, int n_vec) const {  // unshuffle
        swSparse_cplx_simd_shuffle(x, n_vec * sizeof(DV8Complex), this->shfl.unshuffle());
    }
    INLINE void simd_to_complex(DV8Complex *RSTR x, int n_vec) const {  // shuffle
        swSparse_cplx_simd_shuffle(x, n_vec * sizeof(DV8Complex), this->shfl.shuffle());
    }
};

template<typename DATA_T>
struct simd_cplx {
    CHECK_FUNDAMENTAL_TYPE(DATA_T);
    using reg = dummy_real;
    using ldm = dummy_real;
    using regldm = dummy_real;
};

template<> struct simd_cplx <SComplex> {
    using reg = z_simd_converter;
    using ldm = c_simd_ldm_converter;
    class regldm : public z_simd_converter, public c_simd_ldm_converter {};
};

template<> struct simd_cplx <DComplex> {
    using reg = z_simd_converter;
    using ldm = z_simd_converter;
    using regldm = z_simd_converter;
};

template<typename DATA_T>
using complex_simd_ldm_converter = typename simd_cplx<DATA_T>::ldm;
template<typename DATA_T>
using complex_simd_register_converter = typename simd_cplx<DATA_T>::reg;
template<typename DATA_T>
using complex_simd_ldm_register_converter = typename simd_cplx<DATA_T>::regldm;

/*
 * 用于 SpMM 和 SpTRSM 中，将列优先的多个向量转换成SIMD友好的布局，见文档
 * requirements:
 *     ld % 8 == 0
 *     n <= ld
 */
template<typename DATA_T, typename REAL_T = real_t<DATA_T>>
class column_major_simd_converter {
    shuffler<sizeof(REAL_T)> shfl;
public:
    INLINE void column_major_to_simd(const DATA_T *RSTR x, simd_t<DATA_T> *RSTR y, int n, int ld) const {
        swSparse_colmaj2simd_shuffle(x, y, n * sizeof(DATA_T), ld * sizeof(DATA_T), shfl.shuffle());  // shuffle
    }
    INLINE void simd_to_column_major(const simd_t<DATA_T> *RSTR x, DATA_T *RSTR y, int n, int ld) const {
        swSparse_simd2colmaj_shuffle(x, y, n * sizeof(DATA_T), ld * sizeof(DATA_T), shfl.unshuffle());  // unshuffle
    }
};

// converter + DMA，见文档
template<typename DATA_T, uint32_t dma_buffer_size = 4096 / sizeof(DATA_T)>
class column_major_simd_dma : public column_major_simd_converter <DATA_T> {
    static_assert(dma_buffer_size % simd_width<DATA_T> == 0);
    buffer<DATA_T, dma_buffer_size> buffer_[simd_width<DATA_T>];
    crts_rply_t reply_;
public:
    column_major_simd_dma() : reply_(0), column_major_simd_converter <DATA_T>() {}
    void read_simd_from_column_major(const DATA_T* RSTR mem, simd_t<DATA_T>* RSTR ldm, int len, int mem_ld, int n_vec) {
        constexpr int buffer_ld = buffer_[1].data - buffer_[0].data;
        rply_counter_t count = reply_;
        for(int i = 0; i < len; i += dma_buffer_size) {
            int temp_len = min(dma_buffer_size, len - i);
            const DATA_T* g = mem + i;
            simd_t<DATA_T>* l = ldm + i;
            count += n_vec;
            for(int j = 0; j < n_vec; ++j) {
                CRTS_DMA_IGET(buffer_[j].data, g + j * mem_ld, temp_len * sizeof(DATA_T), &reply_);
            }
            CRTS_dma_wait_value(&reply_, count);
            this->column_major_to_simd(buffer_[0].data, l, temp_len, buffer_ld);
        }
    }
    void write_simd_to_column_major(const simd_t<DATA_T>* RSTR ldm, DATA_T* RSTR mem, int len, int mem_ld, int n_vec) {
        constexpr int buffer_ld = buffer_[1].data - buffer_[0].data;
        rply_counter_t count = reply_;
        for(int i = 0; i < len; i += dma_buffer_size) {
            int temp_len = min(dma_buffer_size, len - i);
            const simd_t<DATA_T>* l = ldm + i;
            DATA_T* g = mem + i;
            this->simd_to_column_major(l, buffer_[i].data, temp_len, buffer_ld);
            count += n_vec;
            for(int j = 0; j < n_vec; ++j) {
                CRTS_DMA_IPUT(g + j * mem_ld, buffer_[j].data, temp_len * sizeof(DATA_T), &reply_);
            }
            CRTS_dma_wait_value(&reply_, count);
        }
    }
};

// complex argument should split, in order to use registers 
template<typename REAL_T>
void fill_real(REAL_T* RSTR x, Int size, REAL_T value) NOTHROW;
template<typename REAL_T>
void fill_cplx(complex<REAL_T>* RSTR x, Int size, REAL_T real, REAL_T imag) NOTHROW;

template<typename REAL_T>
INLINE void fill(REAL_T* x, Int size, REAL_T value) {
    fill_real(x, size, value);
}
template<typename REAL_T>
INLINE void fill(complex<REAL_T>* x, Int size, const complex<REAL_T>& value) {
    fill_cplx(x, size, value.real, value.imag);
}

template<typename DATA_T>
void shift(DATA_T* RSTR x, Int size, DATA_T delta) NOTHROW;

} // namespace swSparse


#endif

#endif
