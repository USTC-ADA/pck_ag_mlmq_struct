#ifndef CPE_SIMD_MATH_H
#define CPE_SIMD_MATH_H

/* functions on CPE */

#include "internal/CPE_simd_utils.h"

#define SEXP_CONTANT_SIZE   7
#define SLOG_CONTANT_OFFSET 5
#define SLOG_CONTANT_SIZE   8
#define S_CONTANT_SIZE      13

#define DEXP_CONTANT_SIZE   11
#define DLOG_CONTANT_OFFSET 9
#define DLOG_CONTANT_SIZE   14
#define D_CONTANT_SIZE      23

typedef struct {
    intv16 shfl_idx[2];
    float math_const[SLOG_CONTANT_SIZE];
} clogabs_table_t;

typedef struct {
    intv16 shfl_idx[2];
    double math_const[DLOG_CONTANT_SIZE];
} zlogabs_table_t;

EXTERN void swSparse_s_vec_exp(float* data, int len, const float* table) NOTHROW;
EXTERN void swSparse_d_vec_exp(double* data, int len, const double* table) NOTHROW;
EXTERN void swSparse_s_vec_log_abs(const float* data, float* abs_data, float* log_data, int len, const float* table) NOTHROW;
EXTERN void swSparse_d_vec_log_abs(const double* data, double* abs_data, double* log_data, int len, const double* table) NOTHROW;
EXTERN void swSparse_c_vec_log_abs(const void* data, float* abs_data, float* log_data, int len, const clogabs_table_t* table) NOTHROW;
EXTERN void swSparse_z_vec_log_abs(const void* data, double* abs_data, double* log_data, int len, const zlogabs_table_t* table) NOTHROW;
EXTERN const float swSparse_s_math_constant[S_CONTANT_SIZE];
EXTERN const double swSparse_d_math_constant[D_CONTANT_SIZE];

#ifdef __cplusplus
#ifdef SWSPARSE_USE_LIBM_SLAVE
struct empty_table_t {
    constexpr std::nullptr_t get_table() const { return nullptr; }
};
template<typename REAL_T, size_t Size, ptrdiff_t Offset>
using table_t = empty_table_t;
template<typename Base, size_t Size, ptrdiff_t Offset>
using ctable_t = empty_table_t;
#else
INLINE void load_math_constants(float* table, size_t size, ptrdiff_t offset) {
    DMA_READ_NODESC(&swSparse_s_math_constant[offset], table, sizeof(float) * size);
}
INLINE void load_math_constants(double* table, size_t size, ptrdiff_t offset) {
    DMA_READ_NODESC(&swSparse_d_math_constant[offset], table, sizeof(double) * size);
}
template<typename REAL_T, size_t Size, ptrdiff_t Offset>
struct table_t {
    REAL_T math_const[Size];
    table_t() {
        load_math_constants(&this->math_const[0], Size, Offset);
    }
    const REAL_T* get_table() const { return &this->math_const[0]; }
};
template<typename Base, size_t Size, ptrdiff_t Offset>
struct ctable_t : public Base {
    ctable_t() {
        load_math_constants(&this->math_const[0], Size, Offset);
        swSparse_load_shuffle_indices(this->shfl_idx, SWSPARSE_INDEX_SHUFFLE_8_BYTES + 2, 2);
    }
    const Base* get_table() const { return this; }
};
#endif

using sexp_table = table_t<float,SEXP_CONTANT_SIZE,0>;
using dexp_table = table_t<double,DEXP_CONTANT_SIZE,0>;
using slog_table = table_t<float,SLOG_CONTANT_SIZE,SLOG_CONTANT_OFFSET>;
using dlog_table = table_t<double,DLOG_CONTANT_SIZE,DLOG_CONTANT_OFFSET>;
using clog_table = ctable_t<clogabs_table_t,SLOG_CONTANT_SIZE,SLOG_CONTANT_OFFSET>;
using zlog_table = ctable_t<zlogabs_table_t,DLOG_CONTANT_SIZE,DLOG_CONTANT_OFFSET>;

template<typename REAL_T>
class exponential;
template<typename DATA_T>
class absolute_logarithmic;

#define DECLARE_EXPONENTIAL(type, table_type, func_name) \
    template <> class exponential<type> : table_type  {  \
    public:                                              \
        void exp(type *x, int len) const noexcept {      \
            func_name(x, len, this->get_table());        \
        }                                                \
    };

#define DECLARE_LOGABS(type, table_type, func_name)                                             \
    template <> class absolute_logarithmic<type> : table_type {                                 \
    public:                                                                                     \
        void log_abs(const type *x, real_t<type> *y, real_t<type> *z, int len) const noexcept { \
            func_name(x, y, z, len, this->get_table());                                         \
        }                                                                                       \
    };

DECLARE_EXPONENTIAL(float, sexp_table, swSparse_s_vec_exp)
DECLARE_EXPONENTIAL(double, dexp_table, swSparse_d_vec_exp)
DECLARE_LOGABS(float, slog_table, swSparse_s_vec_log_abs)
DECLARE_LOGABS(double, dlog_table, swSparse_d_vec_log_abs)
DECLARE_LOGABS(SComplex, clog_table, swSparse_c_vec_log_abs)
DECLARE_LOGABS(DComplex, zlog_table, swSparse_z_vec_log_abs)

#endif

#endif