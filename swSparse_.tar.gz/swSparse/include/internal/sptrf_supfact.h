#ifndef SPTRF_SUPER_H_INCLUDED 
#define SPTRF_SUPER_H_INCLUDED 1

#ifdef __cplusplus
#include "internal/rename.h"
#include "internal/templates.h"
#include "internal/CPE_blas_kernels.h"
#include "internal/sptrf_param.h"

namespace swSparse {
namespace supfact {
/* factorize functions returns the number of pertubated pivots */

// base
template<typename DATA_T>
class B : public BLAS<DATA_T> { // base
protected:
    real_t<DATA_T> perturb_thres, rcp_thres;
    Int panel_size, fact_block_row, trsm_block_row, left_ld_, right_ld_;
public:
#ifdef LU_CPE_PROFILE
    mutable unsigned long tcomp, tcomm, tcontmem;
#endif
    B(real_t<DATA_T> thres, real_t<DATA_T> rthres) : BLAS<DATA_T>(), perturb_thres(thres), rcp_thres(rthres) {
#ifdef LU_CPE_PROFILE
    tcomp = tcomm = tcontmem = 0;
#endif
    }
    template<typename PERTURB>
    INLINE Int supfact_seq(DATA_T *ldm, DATA_T *mem, Int *ipiv, Int jpanel_begin, Int jpanel_end, Int sup_size, Int sup_ld) const;
    void pivot_permute_L_seq(DATA_T *l_sup_val, Int *sup_ipiv, Int sup_size, Int sup_ld) const;
    INLINE void new_super(Int sup_size) {
        sptrf_params<sizeof(DATA_T)>::select_panel_size(sup_size, 1, 
            this->panel_size, this->fact_block_row, this->trsm_block_row, this->left_ld_, this->right_ld_);
        this->set_factorize_layout(this->left_ld_, this->right_ld_);
    }
};

template <typename DATA_T, typename PERTURB>
NOINLINE Int supfact_seq(DATA_T *ldm, DATA_T *mem, Int *ipiv, \
        Int jpanel_begin, Int jpanel_end, Int sup_size, Int sup_ld, const B<DATA_T>* this_);

// sequential fact
template<typename DATA_T>
class F : public B<DATA_T> {
    typedef Int (*fact_func)(DATA_T*, DATA_T*, Int*, Int, Int, Int, Int, const B<DATA_T>*);
    fact_func fact;
public:
    F(real_t<DATA_T> thres, real_t<DATA_T> rthres, Int perturb_op);
    INLINE Int factorize_super_seq(DATA_T *ldm, DATA_T *mem, Int *ipiv, Int jpanel_begin, Int jpanel_end, Int sup_size, Int sup_ld) const {
        return this->fact(ldm, mem, ipiv, jpanel_begin, jpanel_end, sup_size, sup_ld, this);
    }
};

struct G {    //  group
    const volatile int8_t *partners;
    Int group_size;
    Int group_rank;
    uint64_t group_member_mask;
};

// parallel fact
template<typename DATA_T>
class P : public B<DATA_T> {
    typedef B<DATA_T> base;
    typedef Int (*fact_func)(DATA_T*, DATA_T*, Int*, Int*, Int, Int, Int, Int, const P<DATA_T>*);
    typedef void (*permute_func)(DATA_T*, Int*, Int*, Int, Int, const P<DATA_T>*);

    fact_func fact, fact_seq, fact_par;
    permute_func permute, permute_seq, permute_par;
    G comm;
public:
    P(real_t<DATA_T> thres, real_t<DATA_T> rthres, Int perturb_op);
    INLINE void new_super(Int sup_size, const volatile int8_t *partners, Int group_size, Int group_rank) {
        comm.partners = partners;
        comm.group_size = group_size;
        comm.group_rank = group_rank;
        sptrf_params<sizeof(DATA_T)>::select_panel_size(sup_size, group_size, 
                this->panel_size, this->fact_block_row, this->trsm_block_row, this->left_ld_, this->right_ld_);
        this->set_factorize_layout(this->left_ld_, this->right_ld_);
        if(group_size == 1) {
            this->fact = fact_seq;
            this->permute = permute_seq;
        } else {
            this->fact = fact_par;
            this->permute = permute_par;
        }
    }
    template<typename PERTURB>
    INLINE Int supfact_par(DATA_T *ldm, DATA_T *mem, Int *ipiv_ldm, Int *ipiv, \
        Int jgroup_begin, Int jgroup_end, Int sup_size, Int sup_ld) const;
    INLINE void pivot_permute_L_par(DATA_T *l_sup_val, Int *ipiv_ldm, Int *sup_ipiv, Int sup_size, Int sup_ld) const;

    INLINE void pivot_permute_L_parallel(DATA_T *l_sup_val, Int *ipiv_ldm, Int *sup_ipiv, Int sup_size, Int sup_ld) const {
        this->permute(l_sup_val, ipiv_ldm, sup_ipiv, sup_size, sup_ld, this);
    }
    INLINE Int factorize_super_par(DATA_T *ldm, DATA_T *mem, Int *ipiv_ldm, Int *ipiv, \
        Int jgroup_begin, Int jgroup_end, Int sup_size, Int sup_ld) const {
        return this->fact(ldm, mem, ipiv_ldm, ipiv, jgroup_begin, jgroup_end, sup_size, sup_ld, this);
    }
};

} // namespace supfact

// export

// 基类
template<typename DATA_T>
using dense_fact_base = supfact::B<DATA_T>;

// 串行内部分解
template<typename DATA_T>
using dense_fact = supfact::F<DATA_T>;

// 并行内部分解
template<typename DATA_T>
using dense_par_fact = supfact::P<DATA_T>;

// 用于并行内部分解的组内通信子
using group_communicator = supfact::G;

template<typename DATA_T>
INLINE void cached_read_mtx(DATA_T* dst, const DATA_T* src, Int rows, Int cols, Int dst_ld, Int src_ld) {
    const DATA_T* temp_mem = src;
    DATA_T* temp_ldm = dst;
    for (Int jj = 0; jj < cols; ++jj, temp_mem += src_ld, temp_ldm += dst_ld) {
        cached_read(temp_ldm, temp_mem, sizeof(DATA_T) * rows);
    }
}

// bc: block-cyclic
template<typename DATA_T>
INLINE void cached_write_mtx(DATA_T* dst, const DATA_T* src, Int rows, Int cols, Int dst_ld, Int src_ld) {
    DATA_T* temp_mem = dst;
    const DATA_T* temp_ldm = src;
    for (Int jj = 0; jj < cols; ++jj, temp_mem += dst_ld, temp_ldm += src_ld) {
        cached_write(temp_mem, temp_ldm, sizeof(DATA_T) * rows);
    }
}

template<typename DATA_T>
INLINE void cached_read_mtx_bc(DATA_T* dst, const DATA_T* src, Int rows, Int nbc_not_last, Int group_cycle_size, Int ncol_last, Int dst_ld, Int src_ld) {
    const Int ldmblock = block_cycle_size * dst_ld, memblock = group_cycle_size * src_ld;
    for (Int panel = 0; panel < nbc_not_last; ++panel, dst += ldmblock, src += memblock) {
        cached_read_mtx(dst, src, rows, block_cycle_size, dst_ld, src_ld);
    }
    if(ncol_last > 0) {
        cached_read_mtx(dst, src, rows, ncol_last, dst_ld, src_ld);
    }
}

template<typename DATA_T>
INLINE void cached_write_mtx_bc(DATA_T* dst, const DATA_T* src, Int rows, Int nbc_not_last, Int group_cycle_size, Int ncol_last, Int dst_ld, Int src_ld) {
    const Int ldmblock = block_cycle_size * src_ld, memblock = group_cycle_size * dst_ld;
    for (Int panel = 0; panel < nbc_not_last; ++panel, dst += memblock, src += ldmblock) {
        cached_write_mtx(dst, src, rows, block_cycle_size, dst_ld, src_ld);
    }
    if(ncol_last > 0) {
        cached_write_mtx(dst, src, rows, ncol_last, dst_ld, src_ld);
    }
}

} // namespace swSparse
#endif
#endif
