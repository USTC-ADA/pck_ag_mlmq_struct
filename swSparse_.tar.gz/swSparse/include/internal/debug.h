#ifndef DEBUG_H_INCLUDED
#define DEBUG_H_INCLUDED 1

//#define C_FPRINTF     // use unified fprintf in C and C++
#ifndef DEBUG_LEVEL
#define DEBUG_LEVEL 1 // 0, 1, 2
#endif

#if DEBUG_LEVEL > 0
#ifdef __sw_slave__
#include<stdio.h>
#endif
#if DEBUG_LEVEL > 1
#include <assert.h>
#include <signal.h>
#endif
#endif

#ifdef __cplusplus
#include "swSparse_complex.h"
#endif
#include "internal/rename.h"
#ifdef __sw_slave__
#include "internal/CPE.h"
#endif

#if DEBUG_LEVEL > 0
#define DEBUG_ARG_DECL , const char *file__, int line__
#define DEBUG_ARGS     , file__, line__
#define DEBUG_PARAMS   , __FILE__, __LINE__
#else
#define DEBUG_ARG_DECL
#define DEBUG_ARGS
#define DEBUG_PARAMS
#endif

/* print debug information */
#if DEBUG_LEVEL > 0
    #ifndef __sw_slave__
        #define DEBUG_PRINTF(...)           fprintf(stderr, __VA_ARGS__) 
        #define DEBUG_PRINT_ENDL            fputc('\n', stderr);
        #define DEBUG_PRINT_OOM(req)        fprintf(stderr, swSparse_malloc_error_msg, req DEBUG_ARGS);
        extern const char swSparse_malloc_error_msg[58];
        extern const char swSparse_int32_overflow[86];
    #else 
        #define DEBUG_PRINTF(...) printf(__VA_ARGS__)  // 从核上直接用printf打印
        #define DEBUG_PRINT_ENDL  printf("\n");
    #endif
#else
    #define DEBUG_PRINTF(...)  // DEBUG_LEVEL == 0, 屏蔽所有输出信息
    #define DEBUG_PRINT_ENDL
    #define DEBUG_PRINT_OOM(req)
#endif

/* ASSERTIONS */
#ifdef __cplusplus
template<typename T>
inline void print_value(T x) { DEBUG_PRINTF("%e", x); }
template<typename T>
inline void print_value(const swSparse::complex<T>& x) { DEBUG_PRINTF("%e + %e i", x.real, x.imag); }
template<typename T>
inline void println_value(T x) { print_value(x); DEBUG_PRINT_ENDL; }
#endif

#if DEBUG_LEVEL > 1
INLINE void assert_failure(const char* file, int line, int x, const char *op, int y) {
#ifdef __sw_slave__
    DEBUG_PRINTF("assertion failed at %s line %d CPE %d: %d %s %d is false\n", file, line, CPE_ID, x, op, y);
#else
    DEBUG_PRINTF("assertion failed at %s line %d: %d %s %d is false\n", file, line, x, op, y);
#endif
    raise(SIGABRT); 
}

#define SWSPARSE_HAS_ASSERT 1
#define ASSERT(pred) assert(pred)
#define ASSERT_EQUAL(x__, y__)      if(UNLIKELY((x__) != (y__))) { assert_failure(__FILE__, __LINE__, x__, "==", y__); }
#define ASSERT_NOT_EQUAL(x__, y__)  if(UNLIKELY((x__) == (y__))) { assert_failure(__FILE__, __LINE__, x__, "!=", y__); }
#define ASSERT_LESS(x__, y__)       if(UNLIKELY((x__) >= (y__))) { assert_failure(__FILE__, __LINE__, x__, "<", y__); }
#define ASSERT_LESS_EQUAL(x__, y__) if(UNLIKELY((x__) > (y__))) { assert_failure(__FILE__, __LINE__, x__, "<=", y__); }
#else
#define ASSERT(pred)
#define ASSERT_EQUAL(x__, y__)
#define ASSERT_NOT_EQUAL(x__, y__)
#define ASSERT_LESS(x__, y__)
#define ASSERT_LESS_EQUAL(x__, y__)
#endif

#endif
