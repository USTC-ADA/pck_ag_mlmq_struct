#ifndef SPGEMM_PARAM_H_INCLUDED
#define SPGEMM_PARAM_H_INCLUDED

#include <stddef.h>
#include "swSparse_base.h"
#include "internal/rename.h"
#include "internal/utils.h"

template<size_t element_size>
struct spmv_params;

template<>
struct spmv_params<4> {
    constexpr static const int BUFFER_B = 2048;
    constexpr static const int BUFFER_X = 2048;
    constexpr static const int BUFFER_NNZ = 2048;
    constexpr static const int BUFFER_I = 128;  
    constexpr static const int BUFFER_TASK = 128;
};
template<>
struct spmv_params<8> {
    constexpr static const int BUFFER_B = 2048;
    constexpr static const int BUFFER_X = 2048;
    constexpr static const int BUFFER_NNZ = 2048;
    constexpr static const int BUFFER_I = 128;  
    constexpr static const int BUFFER_TASK = 128;
};
template<>
struct spmv_params<16> {
    constexpr static const int BUFFER_B = 1024;
    constexpr static const int BUFFER_X = 1024;
    constexpr static const int BUFFER_NNZ = 1024;
    constexpr static const int BUFFER_I = 64;  
    constexpr static const int BUFFER_TASK = 128;
};

#endif
