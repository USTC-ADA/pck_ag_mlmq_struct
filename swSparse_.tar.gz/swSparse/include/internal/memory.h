#ifndef MEMORY_H_INCLUDED
#define MEMORY_H_INCLUDED 1

#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include <athread.h>

#include "swSparse_base.h"
#include "internal/rename.h"
#include "internal/debug.h"

// #define MULTIPLE_CORE_GROUPS

#if DEBUG_LEVEL > 2
#define MEMORY_ALLOCATION_DEBUG
#endif

#ifndef __sw_slave__
/* Memory allocate, wrapped for debug */
#ifdef MULTIPLE_CORE_GROUPS
    static inline void *swSparse_malloc_raw(size_t size) {
    #ifdef MEMORY_ALLOCATION_DEBUG
        DEBUG_PRINTF("malloc(%llu)\n", size);
        void *p = _sw_xmalloc(size);
        DEBUG_PRINTF(" -> get %p\n", p);
        return p;
    #else
        return _sw_xmalloc(size);
    #endif
    }
    static inline void swSparse_free(void* ptr) {
    #ifdef MEMORY_ALLOCATION_DEBUG
        DEBUG_PRINTF("   free %p\n", ptr);
    #endif
        _sw_xfree(ptr);
    }
#else
    #define HAS_REALLOC 1
    static inline void *swSparse_malloc_raw(size_t size) {
    #ifdef MEMORY_ALLOCATION_DEBUG
        DEBUG_PRINTF("malloc(%llu)\n", size);
        void *p = malloc(size);
        DEBUG_PRINTF(" -> get %p\n", p);
        return p;
    #else
        return malloc(size);
    #endif
    }
    static inline void swSparse_free(void* ptr) {
    #ifdef MEMORY_ALLOCATION_DEBUG
        DEBUG_PRINTF("   free(%p)\n", ptr);
    #endif
        free(ptr);
    }
    static inline void *swSparse_realloc_raw(void* ptr, size_t size) {
    #ifdef MEMORY_ALLOCATION_DEBUG
        DEBUG_PRINTF("realloc(%p, %llu)\n", ptr, size);
        void *p = realloc(ptr, size);
        DEBUG_PRINTF(" -> get %p\n", p);
        return p;
    #else
        return realloc(ptr, size);
    #endif
    }
#endif

static inline void swSparse_free_if(void* ptr) {
    if(ptr != NULL) {
        swSparse_free(ptr);
    }
}

/* utility to free multiple pointers */
EXTERN ErrorStatus swSparse_clean_return(ErrorStatus err, void *ptr, ...) NOTHROW;
EXTERN ErrorStatus swSparse_clean_return_s(ErrorStatus err, size_t size, void **ptr) NOTHROW;

#ifdef __cplusplus
// safer clean functions in C++
template<typename ... PTR_TYPES>
INLINE ErrorStatus clean_return_s(ErrorStatus err, PTR_TYPES* ... ptrs) {
    void* p_array[sizeof...(PTR_TYPES)] = { ptrs ... };
    return swSparse_clean_return_s(err, sizeof...(PTR_TYPES), p_array);
}
#define clean_return(...)  swSparse_clean_return(__VA_ARGS__, (void*)nullptr)
#else
#define clean_return(...)  swSparse_clean_return(__VA_ARGS__, NULL)
#endif

#define free_all(...)    clean_return(SWSPARSE_SUCCESS, __VA_ARGS__)
#define free_all_s(...)  clean_return_s(SWSPARSE_SUCCESS, __VA_ARGS__)

BEGIN_C_FUNCTIONS

void swSparse_memset(void *dst, int value, size_t size);
void swSparse_memcpy(void *dst, const void *src, size_t size);
void swSparse_memmove(void *dst, const void *src, size_t size);

static inline void *swSparse_malloc_checked(size_t size DEBUG_ARG_DECL) {
    void *p = swSparse_malloc_raw(size);
#if DEBUG_LEVEL > 0
    if(p == NULL) {
        DEBUG_PRINT_OOM(size);
    }
#endif
    return p;
}
#define swSparse_malloc(size)       swSparse_malloc_checked(size DEBUG_PARAMS)
#define swSparse_realloc(ptr, size) swSparse_realloc_checked(ptr, size DEBUG_PARAMS)
#define MALLOC_ERROR                SWSPARSE_MALLOC_ERROR

#ifdef HAS_REALLOC
static inline void *swSparse_realloc_checked(void *ptr, size_t size DEBUG_ARG_DECL) {
    void *p = swSparse_realloc_raw(ptr, size);
#if DEBUG_LEVEL > 0
    if(p == NULL) {
        DEBUG_PRINT_OOM(size);
    }
#endif
    return p;
}
    #define shrink_alloc(ptr, new_size, old_size)  swSparse_realloc(ptr, new_size)
    #define expand_alloc(ptr, new_size, old_size)  swSparse_realloc(ptr, new_size)
    #define resize_alloc(ptr, new_size, old_size)  swSparse_realloc(ptr, new_size)
#else
    #define shrink_alloc(ptr, new_size, old_size)  ptr
    static inline void *expand_alloc_checked(void* ptr, size_t new_size, size_t old_size DEBUG_ARG_DECL) {
        void *p = swSparse_malloc_raw(new_size);
        if(p == NULL) {
#if DEBUG_LEVEL > 0
            DEBUG_PRINT_OOM(new_size);
#endif
            return NULL;
        }
        swSparse_memcpy(p, ptr, old_size);
        swSparse_free(ptr);
        return p;
    }
    static inline void *resize_alloc_checked(void* ptr, size_t new_size, size_t old_size DEBUG_ARG_DECL) {
        return (new_size > old_size) ? expand_alloc_checked(ptr, new_size, old_size DEBUG_ARGS) : shrink_alloc(ptr, new_size, old_size);
    }
    #define expand_alloc(ptr, new_size, old_size)  expand_alloc_checked(ptr, new_size, old_size DEBUG_PARAMS)
    #define resize_alloc(ptr, new_size, old_size)  resize_alloc_checked(ptr, new_size, old_size DEBUG_PARAMS)
#endif

#define TYPE_ARG(DATA_T) type_traits<DATA_T>::element_type, sizeof(DATA_T)

ErrorStatus init_csrc_data(MatrixCSRC *matrix, Int m, Int n, Int ld, Int nnz, size_t value_size) NOTHROW;
ErrorStatus init_coo_data(MatrixCOO *matrix, Int m, Int n, Int nnz, size_t value_size) NOTHROW;
ErrorStatus init_csrc(Matrix matrix, Int m, Int n, Int ld, Int nnz, \
                          MatrixElementType type, size_t value_size) NOTHROW;
ErrorStatus init_coo(Matrix matrix, Int m, Int n, Int nnz, \
                          MatrixElementType type, size_t value_size) NOTHROW;
ErrorStatus new_csrc(Matrix *matrix, Int m, Int n, Int ld, Int nnz, \
                          MatrixElementType type, size_t value_size) NOTHROW;
ErrorStatus new_coo(Matrix *matrix, Int m, Int n, Int nnz, \
                    MatrixElementType type, size_t value_size) NOTHROW ;

ErrorStatus swSparse_destruct(Matrix matrix) NOTHROW;


ErrorStatus swSparse_ensure_ownership_csrc(Matrix mat);
ErrorStatus swSparse_ensure_ownership_coo(Matrix mat);

END_C_FUNCTIONS

#ifdef __cplusplus
namespace swSparse {
template<typename DATA_T>
DATA_T *pack_chunks(DATA_T **chunks, Int full, Int cap, Int last);
template<typename DATA_T>
void clean_chunks(DATA_T **chunks, Int n); 
}
#endif

#else
// deprecated

static inline void *swSparse_cpe_malloc(size_t size) {
    //puts("malloc");
    return malloc(size);
}

static inline void swSparse_cpe_free(void* ptr) {
    //puts("free");
    free(ptr);
}
#endif

#endif
