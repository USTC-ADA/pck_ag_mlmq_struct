#include <type_traits>
#include "internal/templates.h"
#include <string.h>
#define MEM_FENCE asm volatile("memb":::"memory")

#ifndef __sw_slave__
#include <crts.h>
// x86 emulation: per-thread stack base for inter-CPE Remote Memory Access
// Each CPE kernel registers its local &done_k[0] in _ldm_base[id] before
// the first sync barrier. All threads share identical stack layout,
// so an offset from _ldm_base[my_id] points to the same variable
// at _ldm_base[target_id].
static volatile void* _ldm_base[64] = {0};
#endif

/* 访问其他从核的LDM */
template <typename T>
inline T *remote_ldm_addr(volatile T *ptr, uintptr_t id) {
#ifndef __sw_slave__
    uintptr_t off = reinterpret_cast<uintptr_t>(ptr) -
                    reinterpret_cast<uintptr_t>(_ldm_base[CRTS_smng_get_tid()]);
    if (_ldm_base[id] == NULL)
        fprintf(stderr, "RMA-ERR: target id=%d base=NULL src_tid=%d\n",
                (int)id, (int)CRTS_smng_get_tid());
    return reinterpret_cast<T *>(
        reinterpret_cast<uintptr_t>(_ldm_base[id]) + off);
#else
    uintptr_t x = reinterpret_cast<uintptr_t>(ptr), y = id << 20, z = 1ull << 45;
    return reinterpret_cast<T *>(x | y | z);
#endif
}


template <typename T>
static inline void rstore8(T* buf,volatile T* p, uintptr_t id){
    T *addr = remote_ldm_addr((p), id);
	memcpy(reinterpret_cast<void*>(addr), reinterpret_cast<void*>(buf), sizeof(simd_t<T>));
}

template <typename T>
static inline void vec_loadu(simd_t<T> &vbuf, T *buf){
	    memcpy(reinterpret_cast<void*>(&vbuf), reinterpret_cast<void*>(buf), sizeof(simd_t<T>));

}

template <typename T>
static inline void vec_storeu(simd_t<T> vbuf, T *buf){
	    memcpy(reinterpret_cast<void*>(buf), reinterpret_cast<void*>(&vbuf), sizeof(simd_t<T>));

}
