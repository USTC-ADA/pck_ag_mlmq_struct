
#ifndef STRUCT_SPTRSV_
#define STRUCT_SPTRSV_

#include <crts.h>
#include <simd.h>

#define ROW_P 8
#define COL_P 8

#define INDEX3(i, j, k, N, L) ((i)*(N)*(L) + (j)*(L) + (k))
#define VALID(i, j, k, M, N, L) ((i >= 0) && (i < (M)) && (j >= 0) && (j < (N)) && (k >= 0) && (k < (L)))

#define CAL_ID(row, col) (((row) >= 0 && (col) >= 0 && (row) < ROW_P && (col) < COL_P)? ((row) * ROW_P + (col)) : -1)

#define gridmax(x, y) (((x) > (y))? (x): (y))
#define gridmin(x, y) (((x) < (y))? (x): (y))

#define syc_rcol(sid, syc) (syc - 1 - sid)

template<int DATA_T_SIZE>
struct strTRSV_params;
template<>
struct strTRSV_params<4> {
    constexpr static const int LM = 256;
    constexpr static const int GRA = 32;
    floatv8 simd_set_nnz(float* src, int nnz, int nnz2, int nnz3, int nnz4, int nnz5, int nnz6, int nnz7){ 
		return simd_set_floatv8(*src, *(src + nnz), *(src + nnz2), *(src + nnz3), *(src + nnz4), *(src + nnz5), *(src + nnz6), *(src + nnz7));
    }
};
template<>
struct strTRSV_params<8> {
    constexpr static const int LM = 512;
    constexpr static const int GRA = 64;
    doublev8 simd_set_nnz(double* src, int nnz, int nnz2, int nnz3, int nnz4, int nnz5, int nnz6, int nnz7){
		return simd_set_doublev8(*src, *(src + nnz), *(src + nnz2), *(src + nnz3), *(src + nnz4), *(src + nnz5), *(src + nnz6), *(src + nnz7));
    }
};

#endif

