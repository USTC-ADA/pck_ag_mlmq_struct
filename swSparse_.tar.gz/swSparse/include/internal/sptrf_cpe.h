#ifndef SPTRF_CPE
#define SPTRF_CPE 1
#ifdef __cplusplus

#include "internal/templates.h"
#include "internal/CPE.h"
#include "internal/sptrf_param.h"
#include "internal/debug.h"

namespace swSparse {

class communicator_interface_base;
class SIC;
class WIC;
class TIC;

// the LU communicator
class LUC {
    struct SCHED {
        Int signal[64];       // workers send completion signal to the scheduler, and request a new task
    };

    struct WORK {
        union {
            int8_t v[64];
            intv16 packed;
        } partners;
        union {
            struct {
                Int sup_id, group_rank, group_size;
                // multiple predicates to find ready descendents, better pipeline parallelism
                Int fb_rank_queue;  // for supernode `s` in the queue, if snode_status[s] < fb_rank, then s is finished
                Int nb_child;       // if nb_child == 0, then all dependencies are done
            } t;
            intv16 packed;
        } task;
    };
    union Dyn {
        SCHED scheduler;
        WORK  worker;
    };
    struct TREE {   // for supernode `s` in a subtree, if s < fb_sup_subtree, then s is finished
        Int fb_sup_subtree, req_sup;
    };
    volatile Dyn dynamic_queue;
    volatile TREE subtree;
public:
#ifdef LU_CPE_PROFILE
    unsigned long tblascomp, tcontmem, tsupwait, tsparse, tfactcomm;
    void print_profile(Int my_id, unsigned long total) const {
        printf("%2d,%15lu,%15lu,%15lu,%15lu,%15lu,%15lu\n", 
            my_id, total, tblascomp, tcontmem, tsupwait, tsparse, tfactcomm);
    }
#endif
    static inline constexpr Int empty = -7;
    static inline constexpr Int end = -1;
    using scheduler_message = SCHED;
    using worker_message = WORK;
    using tree_info = TREE;

    LUC(Int my_id) {
        if(my_id == scheduler_id) {
            for(Int i = 0; i < 64; ++i) {
                dynamic_queue.scheduler.signal[i] = empty;
            }
        } else {
            dynamic_queue.worker.task.t.sup_id = empty;
            dynamic_queue.worker.task.t.fb_rank_queue = 0;
        }
        subtree.fb_sup_subtree = 0;
        subtree.req_sup = 0;
#ifdef LU_CPE_PROFILE
        tblascomp = tcontmem = tsupwait = tsparse = tfactcomm = 0;
#endif
    }

    friend class communicator_interface_base;
    INLINE SIC scheduler_interface();
    INLINE WIC worker_interface();
    INLINE TIC subtree_interface();
};

using trf_communicator = LUC;

// different interfaces to LU communicator

class communicator_interface_base {
    trf_communicator& comm;
protected:
    communicator_interface_base(trf_communicator& c) : comm(c) {}
    INLINE auto& worker() { return comm.dynamic_queue.worker; }
    INLINE auto& worker() const { return comm.dynamic_queue.worker; }
    INLINE auto& scheduler() { return comm.dynamic_queue.scheduler; }
    INLINE auto& scheduler() const { return comm.dynamic_queue.scheduler; }
    INLINE auto& subtree() { return comm.subtree; }
    INLINE auto& subtree() const { return comm.subtree; }
#ifdef LU_CPE_PROFILE
public:
    INLINE void record_update_timing(unsigned long t0, unsigned long t1, unsigned long t2, unsigned long t3) {
        comm.tblascomp += t0;
        comm.tcontmem += t1;
        comm.tsupwait += t2;
        comm.tsparse += t3;
    }
    INLINE void record_fact_timing(unsigned long t0, unsigned long t1, unsigned long t2) {
        comm.tblascomp += t0;
        comm.tcontmem += t1;
        comm.tfactcomm += t2;
    }
#endif
};

class TIC : public communicator_interface_base {
public:
    TIC(trf_communicator& c) : communicator_interface_base(c) {}
    INLINE Int check_req_sup_subtree() const {
        return this->subtree().req_sup;
    }
    INLINE void update_fb_sup_subtree(Int fb_sup) {
        mem_fence();
        this->subtree().fb_sup_subtree = fb_sup;
    }
};

class queue_communicator : public communicator_interface_base {
public:
    queue_communicator(trf_communicator& c) : communicator_interface_base(c) {}
    INLINE Int get_fb_sup_subtree(Int cpe_id) const {
        auto remote = remote_ldm_addr(&this->subtree(), cpe_id);
        return remote->fb_sup_subtree;
    }
};

class SIC : public queue_communicator {
public:
    SIC(trf_communicator& c) : queue_communicator(c) {}
    INLINE void update_nbchild(Int tid) {
        ASSERT_LESS_EQUAL(0, tid);
        ASSERT_LESS(tid, 64);
        *remote_ldm_addr(&this->worker().task.t.nb_child, tid) = 0;
    }
    INLINE volatile Int& scheduler_signal(Int id) {
        return this->scheduler().signal[id];
    }
    INLINE void schedule_response(const trf_communicator::worker_message& msg, Int tid) {
        volatile trf_communicator::worker_message* tgt = remote_ldm_addr(&this->worker(), tid);
        mem_fence();  // make sure that signal[id] is reset to empty
        tgt->task.packed     = msg.task.packed;
        if(msg.task.t.group_size > 1) {
            tgt->partners.packed = msg.partners.packed;
        }
    }
    INLINE void update_fb_rank_queue(Int fb_rank, Int tid) {
        *remote_ldm_addr(&this->worker().task.t.fb_rank_queue, tid) = fb_rank;
    }
};

class WIC : public queue_communicator {
public:
    WIC(trf_communicator& c) : queue_communicator(c) {}
    INLINE const volatile trf_communicator::worker_message& get_worker_message() const {
        return this->worker();
    }
    INLINE Int request_fbsup_subtree(Int req, Int cpe_id) {
        auto remote = remote_ldm_addr(&this->subtree(), cpe_id);
        if (remote->req_sup < req) {          // not atomic, but doesn't matter if wrong
            remote->req_sup = req;
        }
        return remote->fb_sup_subtree;
    }
    INLINE void update_partners() {
        Int rank = this->worker().task.t.group_rank;
        Int size = this->worker().task.t.group_size;
        Int temp = size - 1;
        if(rank == temp && 0 != temp) {
            for(Int partner = rank - 1; partner >= 0; -- partner) {
                Int id = get_worker_message().partners.v[partner];
                *remote_ldm_addr(&this->worker().partners.packed, id) = this->worker().partners.packed;
            }
        }
    } 
    INLINE Int get_fb_rank_queue() const {
        auto &info = this->worker().task.t;
        return info.fb_rank_queue;
    }
    INLINE Int request_new_task(Int my_id, Int pos) {
        volatile Int& slot = this->worker().task.t.sup_id;
        Int sup_id;
        mem_fence();   // make sure last task is written back
        *remote_ldm_addr(&this->scheduler().signal[pos], scheduler_id) = my_id;/* any non-empty value*/
        
        for(sup_id = slot; sup_id == trf_communicator::empty; sup_id = slot);
        slot = trf_communicator::empty;
        return sup_id;
    }
};

using scheduler_communicator = SIC;
using worker_communicator = WIC;
using subtree_communicator = TIC;

scheduler_communicator trf_communicator::scheduler_interface() { return scheduler_communicator(*this); }
worker_communicator    trf_communicator::worker_interface()    { return worker_communicator(*this); }
subtree_communicator   trf_communicator::subtree_interface()   { return subtree_communicator(*this); }

template<typename DATA_T>
Int subtree_part(const sptrf_arg_t<DATA_T>& args, subtree_communicator comm) NOTHROW;
template<typename DATA_T>
Int queue_worker(const sptrf_arg_t<DATA_T>& args, worker_communicator comm) NOTHROW;
void queue_scheduler(const trf_task_t* queue, Int queue_size, const Int* subtree_offsets, const trf_subtree_t* subtrees, 
            const Int* sup2col, scheduler_communicator&& comm) NOTHROW;
Int ipiv2iperm(Int n, Int nsuper, const Int* sup2col, Int* indices) NOTHROW;  // cache ignore

struct next_seg_t {
    Int position, index;
};
struct current_seg_t {
    Int val_off, seg_pos, dense_pos;
};

/* 根据之前分解中的行交换结果，对当前计算的数据也进行行交换 */
template<typename DATA_T>
void pivot_permute_dense(DATA_T* val, const Int* ipiv, Int left_off, Int left_ncol, Int right_ncol, Int ld) NOTHROW;
template<typename DATA_T>
void pivot_permute_U_seg(DATA_T* u_val, const Int* ipiv, Int ipiv_off, Int ipiv_cols, Int nuseg, current_seg_t* current_seg) NOTHROW;
template<typename DATA_T>
void pivot_permute_U_spa(DATA_T* u_val, const Int* ipiv, Int ipiv_off, Int ipiv_cols, Int nuseg, current_seg_t* current_seg) NOTHROW;

/* NOT USED */
template<typename DATA_T>
static void sparse_update_spa(DATA_T* spa, const Int* update_indices, const DATA_T* update_values, Int n_update, Int ldm_ld, \
        current_seg_t* segment, Int nseg) NOTHROW {   
    auto temp_val = update_values;
    for(Int ii, jj = 0; jj < nseg; ++ jj, temp_val += ldm_ld) {
        DATA_T* s = spa + segment[jj].dense_pos;
        for(ii = 3; ii < n_update; ii += 4) {
            auto p0 = s + update_indices[ii - 3], p1 = s + update_indices[ii - 2];
            auto p2 = s + update_indices[ii - 1], p3 = s + update_indices[ii];
            auto v0 = *p0 + temp_val[ii - 3], v1 = *p1 + temp_val[ii - 2];
            auto v2 = *p2 + temp_val[ii - 1], v3 = *p3 + temp_val[ii];
            *p0 = v0; *p1 = v1; *p2 = v2; *p3 = v3;
        }
        for(ii -= 3; ii < n_update; ++ii) {
            s[update_indices[ii]] +=  temp_val[ii];
        }
    }
}

// 将GEMM的结果更新到U
// too many arguments, inline
template<typename DATA_T>
INLINE Int sparse_update_U(Int n_update, const Int* update_indices, const DATA_T* update_values, Int sup_begin, \
    const Int* u_seg_offsets, const Int* u_seg_indices, DATA_T* u_values, current_seg_t* segment) NOTHROW {
    Int pos = 0, upos = segment->seg_pos;

    for(; pos < n_update && update_indices[pos] < sup_begin; ++ pos) {
        Int row_idx = update_indices[pos];
        Int off_in_seg = row_idx - u_seg_indices[upos];
        while(off_in_seg >= u_seg_offsets[upos + 1] - u_seg_offsets[upos]) {
            off_in_seg = row_idx - u_seg_indices[++upos];
        }
        ASSERT_LESS_EQUAL(0, off_in_seg);
        u_values[u_seg_offsets[upos] + off_in_seg] += update_values[pos];
    }

    segment->seg_pos = upos;
    return pos;
}

// 将GEMM的结果更新到L
// too many arguments, inline
template<typename DATA_T>
INLINE Int sparse_update_L(Int n_update, const Int* update_indices, const DATA_T* update_values, Int ldm_ld, \
    Int sup_begin, Int sup_end, Int sup_size, Int lpos, \
    const Int* l_sup_idx, DATA_T* l_panel_val, current_seg_t* segment, Int nseg) NOTHROW {
    Int pos = 0;

    for(; pos < n_update && update_indices[pos] < sup_end; ++ pos) {
        const DATA_T *temp_ldm = update_values;
        Int row_idx = update_indices[pos];
        Int position = row_idx - sup_begin;
        for(Int jj = 0; jj < nseg; ++jj, temp_ldm += ldm_ld) {
            l_panel_val[position + segment[jj].dense_pos] += temp_ldm[pos];
        }
    }
    for(; pos < n_update; ++ pos) {
        const DATA_T *temp_ldm = update_values;
        Int row_idx = update_indices[pos];
        Int position;
        while(l_sup_idx[lpos] < row_idx) {
            ++lpos;
        }
        ASSERT_EQUAL(l_sup_idx[lpos], row_idx);
        position = sup_size + (lpos++);
        for(Int jj = 0; jj < nseg; ++jj, temp_ldm += ldm_ld) {
            l_panel_val[position + segment[jj].dense_pos] += temp_ldm[pos];
        }
    }
    return lpos;
}

}

#endif
#endif
