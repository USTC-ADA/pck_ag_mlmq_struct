#ifndef RENAME_H_INCLUDED
#define RENAME_H_INCLUDED 1

#include "swSparse.h"

typedef swSparseInt                  Int;
typedef swSparseBool                 Bool;
typedef swSparseSComplex             SComplex;
typedef swSparseDComplex             DComplex;
typedef swSparseMatrixStatus         MatrixStatus;
typedef swSparseErrorStatus          ErrorStatus;
typedef swSparseMatrixCSRC           MatrixCSRC;
typedef swSparseMatrixCOO            MatrixCOO;
typedef swSparseMatrixRepresentation MatrixRepresentation;
typedef swSparseMatrixFormatType     MatrixFormatType;
typedef swSparseMatrixElementType    MatrixElementType;
typedef swSparseMatrixData           MatrixData;
typedef swSparseMatrix               Matrix;
typedef swSparseMatrixSWCOO          MatrixSWCOO;
typedef swSparseLUSupernodes         LUSup;

#define trsv_inspect            swSparse_trsv_inspect
#define trsm_inspect            swSparse_trsm_inspect
#define mv_inspect              swSparse_mv_inspect
#define mm_inspect              swSparse_mm_inspect
#define init_csrc_data          swSparse_init_csrc_data
#define init_coo_data           swSparse_init_coo_data
#define init_csrc               swSparse_init_csrc
#define init_coo                swSparse_init_coo
#define new_csrc                swSparse_new_csrc
#define new_coo                 swSparse_new_coo
#define create_id_perm          swSparse_create_id_perm
#define reorder_columns         swSparse_reorder_columns
#define reorder_row_col         swSparse_reorder_row_col
#define reorder_rows            swSparse_reorder_rows

/* For Wangxinliang's legacy code */
#define SpMV_Matrix_tile        swSparse_SpMV_Matrix_tile
#define SpMV_CSR_Tile           swSparse_SpMV_CSR_Tile
#define SpMV_CSR_BLOCK          swSparse_SpMV_CSR_BLOCK
#define SpMV_CSR_TASK_SIMPLE    swSparse_SpMV_CSR_TASK_SIMPLE
#define SpMV_Format_Config      swSparse_SpMV_Format_Config
#define SpMV_Slave_TASK         swSparse_SpMV_Slave_TASK
#define SpMV_Slave_Info         swSparse_SpMV_Slave_Info
#define SpMV_info               swSparseSpMVInfo


#define NO_TRANS       SWSPARSE_NON_TRANSPOSE
#define TRANS          SWSPARSE_TRANSPOSE
#define COO            SWSPARSE_COO
#define CSR            SWSPARSE_CSR
#define CSC            SWSPARSE_CSC
#define COO            SWSPARSE_COO
#define SWCOO          SWSPARSE_SWCOO
#define SLTCOO         SWSPARSE_SLTCOO
#define LU_SUPERNODES  SWSPARSE_LU_SUPERNODES
#define REAL_SINGLE    SWSPARSE_REAL_SINGLE
#define REAL_DOUBLE    SWSPARSE_REAL_DOUBLE
#define COMPLEX_SINGLE SWSPARSE_COMPLEX_SINGLE
#define COMPLEX_DOUBLE SWSPARSE_COMPLEX_DOUBLE


#ifdef __cplusplus
#define BEGIN_C_FUNCTIONS extern "C" {
#define END_C_FUNCTIONS   }
#define EXTERN            extern "C"
#define NOTHROW           noexcept
#define INLINE           [[gnu::always_inline]] inline 
#define NOINLINE         [[gnu::noinline]] 
#define SIMD_ALIGN       alignas(64)
#define RSTR             __restrict__
#define VALUES(x, type)  static_cast<type*>((x)->values)
#else
#define BEGIN_C_FUNCTIONS
#define END_C_FUNCTIONS
#define EXTERN        extern
#define NOTHROW       __attribute__((__nothrow__))
#define INLINE        __attribute__((always_inline)) static inline 
#define NOINLINE      __attribute__((noinline))
#define SIMD_ALIGN    __attribute__((aligned(64)))
#define RSTR          restrict
#endif

#define UNREACHABLE    __builtin_unreachable()
#define LIKELY(x__)    __builtin_expect(x__, true)
#define UNLIKELY(x__)  __builtin_expect(x__, false)
#define IF_ERR(cond__) if(UNLIKELY(cond__))
#endif

#define HOST_FUNCTION
#define SLAVE_FUNCTION
#define HOST_C_FUNCTION  EXTERN
#define SLAVE_C_FUNCTION EXTERN