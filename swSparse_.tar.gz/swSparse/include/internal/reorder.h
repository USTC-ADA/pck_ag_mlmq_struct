#ifndef INTERNAL_REORDER_H_INCLUDED
#define INTERNAL_REORDER_H_INCLUDED 1
#include "swSparse_base.h"
#include "internal/rename.h"


#ifdef __cplusplus
namespace swSparse {
template<typename DATA_T>
void csr423(Int first_dim, Int nnz, 
                    const Int *RSTR begins, const Int *RSTR ends, const Int *RSTR indices4, const DATA_T *RSTR values4,
                    Int *RSTR offsets, Int *RSTR indices3, DATA_T *RSTR values3);

template<typename DATA_T>
ErrorStatus sort_elements(Int first_dim, const Int *RSTR offsets,\
                             Int *RSTR indices, DATA_T *RSTR values);
ErrorStatus sort_elements_in_pattern(Int first_dim, const Int *RSTR offsets, Int *RSTR indices);

// csr423_perm = { csr423, "permute" and sort }
template<typename DATA_T>
ErrorStatus csr423_perm(Int first_dim, Int nnz, 
                    const Int *RSTR begins, const Int *RSTR ends, const Int *RSTR indices4, const DATA_T *RSTR values4,
                    const Int *RSTR iperm, Int *RSTR offsets, Int *RSTR indices3, DATA_T *RSTR values3);

// TODO: parallel version
ErrorStatus sort_levels(Int size, const Int* RSTR old_levels, const Int *RSTR old_indices, Int* RSTR new_levels, Int* RSTR new_indices);
// for upper triangular
ErrorStatus sort_levels_reverse(Int size, const Int* RSTR old_levels, const Int *RSTR old_indices, Int* RSTR new_levels, Int* RSTR new_indices);
}
#endif

BEGIN_C_FUNCTIONS

ErrorStatus swSparse_ensure_order(Matrix a);

void create_id_perm(Int n, Int *perm);

END_C_FUNCTIONS

/*
 * mid[i] = src[first[i]];
 * dst[i] = mid[second[i]];
 * -> dst[i] = src[first[second[i]]];
 * -> composed[i] = first[second[i]];
 */
#define perm_compose(n, first, second, composed)  swSparse_i_perm_apply(n, first, composed, second)

/*
 * mid[first[i]] = src[i];
 * dst[second[i]] = mid[i];
 * -> dst[second[first[i]]] = src[i];
 * -> composed[i] = second[first[i]];
 */
#define iperm_compose(n, first, second, composed) swSparse_i_perm_apply(n, second, composed, first)

// dst[i] = table[indices[i]]
// `dst` can be alias of `indices`
//    usually used to reorder columns of CSR, or rows of CSC
//    can be used on column indices of CSR or row indices of CSC in-place
#define gather_by_indices(n, table, dst, indices)   swSparse_i_perm_apply(n, table, dst, indices)

#endif
