#ifndef ALGORITHM_H_INCLUDED
#define ALGORITHM_H_INCLUDED
#ifdef __cplusplus
#include "internal/rename.h"
#include "internal/utils.h"
#include "internal/templates.h"
#include "internal/debug.h"


namespace swSparse {
template<size_t element_size>
struct rowwise_params {
    constexpr static const int merge_k = 256;
};

template<>
struct rowwise_params<16> {
    constexpr static const int merge_k = 128;
};

inline constexpr const int offset_tile = 1024;
template<typename DATA_T>
inline constexpr const int merge_k = rowwise_params<sizeof(DATA_T)>::merge_k;
inline constexpr const int merge_buffer_size = 64;
template<typename DATA_T>
inline constexpr const int sort_tile = merge_k<DATA_T> * merge_buffer_size;

template<typename DATA_T>
INLINE Int init_which(Int n) {
    if(n < sort_tile<DATA_T>) {
        return 0;
    } else if(n < sort_tile<DATA_T> * merge_k<DATA_T>) {
        return 1;
    } else {
        if constexpr(sizeof(DATA_T) > 8) {
            if(n < sort_tile<DATA_T> * merge_k<DATA_T> * merge_k<DATA_T>) {
                return 0;
            } else {
                return 1;
            }
        } else {
            return 0;
        }
    }
}

// radix_bits = 4 mean radix-16 sort
template<typename DATA_T>
void sort_index_value(Int *RSTR idx, DATA_T *RSTR val, Int n) NOTHROW;
template<typename DATA_T>
void sort_index_value(Int *RSTR ridx, Int *RSTR cidx, DATA_T *RSTR val, Int n) NOTHROW;

inline constexpr const Int empty = -13;
INLINE Int hash(Int index) { return index * 71; /* (index << 6) + (index << 3) - index */ }
INLINE Int binary_search(const Int* indices, Int begin, Int end, Int value) {
    Int count, step, it;
    count = end - begin;
    while (count > 0) {
        it = begin; 
        step = count / 2; 
        it += step;
        if (indices[it] < value) {
            begin = ++it; 
            count -= step + 1; 
        }
        else
            count = step;
    }
    return begin;
}
}

#endif
#endif