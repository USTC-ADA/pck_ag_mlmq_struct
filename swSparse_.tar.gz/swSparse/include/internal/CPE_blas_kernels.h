#ifndef CPE_BLAS_KERNELS_H_INCLUDED 
#define CPE_BLAS_KERNELS_H_INCLUDED 1

/* functions on CPE */

#ifdef __cplusplus
#include "internal/templates.h"
#include "internal/CPE_simd_utils.h"
namespace swSparse {

template<typename DATA_T>
class ESC : public complex_simd_register_converter<DATA_T> {
public:
    /* 逐元素相乘 */
    void ewise_scale(DATA_T* y, const real_t<DATA_T>* RSTR x, Int n) const NOTHROW;
};

/* x = alpha * x
 */
template<typename REAL_T>
void scale_real(REAL_T* RSTR x, Int n, REAL_T alpha) NOTHROW;

/* x = x - alpha * y
 */
template<typename REAL_T>
void minus_scale_real(REAL_T* RSTR x, const REAL_T* RSTR y, Int n, REAL_T alpha) NOTHROW;

template<typename REAL_T>
class SC : public ESC<REAL_T> {
public:
    template<typename Conj>
    INLINE void scale(REAL_T* x, Int n, REAL_T alpha) const NOTHROW {
        scale_real<REAL_T>(x, n, alpha);
    }
    INLINE void minus_scale(REAL_T* x, const REAL_T* y, Int n, REAL_T alpha) const NOTHROW {
        minus_scale_real<REAL_T>(x, y, n, alpha);
    }
};

/* 全名 scale_kernel_t，用于BLAS1的计算 */
template<typename REAL_T>
class SC<complex<REAL_T>> : public ESC<complex<REAL_T>> {
    template<typename Conj>
    void scale_cplx(complex<REAL_T>* RSTR x, Int n, REAL_T real, REAL_T imag) const NOTHROW;
    void minus_scale_cplx(complex<REAL_T>* RSTR x, const complex<REAL_T>* RSTR y, Int n, REAL_T real, REAL_T imag) const NOTHROW;
public:
    template<typename Conj>
    INLINE void scale(complex<REAL_T>* x, Int n, complex<REAL_T> alpha) const NOTHROW {
        this->template scale_cplx<Conj>(x, n, alpha.real, alpha.imag);
    }
    INLINE void minus_scale(complex<REAL_T>* x, const complex<REAL_T>* y, Int n, complex<REAL_T> alpha) const NOTHROW {
        this->minus_scale_cplx(x, y, n, alpha.real, alpha.imag);
    }
};

template<typename DATA_T>
using scale_kernel_t = SC<DATA_T>;

/**
 * @brief 用于直接求解中，局部稠密块的BLAS计算，包含GEMM和TRSM，功能详细说明见文档
 */
template<typename REAL_T>
class BLAS : public scale_kernel_t<REAL_T> {
    simd_register_transposer transposer;
    Int update_left_ld, update_right_ld, fact_left_ld, fact_right_ld;
    void l_trsm_update_real(Int left_col, Int right_col, Int nrow, REAL_T* left, REAL_T* right, Int left_ld, Int right_ld) const NOTHROW;
    INLINE void l_trsm_8x8_real(Int right_col, REAL_T* left, REAL_T* right, Int right_ld) const NOTHROW;
    template <Int COLUMNS>
    INLINE void l_trsm_kernel(Int left_col, Int nrow, Int i_end, REAL_T *left, REAL_T *right, Int left_ld, Int right_ld) const NOTHROW;
public:
    /* 更新时的layout。当前的实现是记录ld这个变量。在后续的优化实现中，ld可能是在每个函数中写死的，此时可以设置函数指针 */
    void set_update_layout(Int left_ld, Int right_ld) {
        update_left_ld = left_ld;
        update_right_ld = right_ld;
    }
    /* 内部分解时的layout。当前的实现是记录ld这个变量。在后续的优化实现中，ld可能是在每个函数中写死的，此时可以设置函数指针 */
    void set_factorize_layout(Int left_ld, Int right_ld) {
        fact_left_ld = left_ld;
        fact_right_ld = right_ld;
    }
    /* 更新时用到的功能 */
    void mm_update(Int left_col, Int right_col, Int nrow, REAL_T* left, REAL_T* right_up, REAL_T* right_down) const NOTHROW;
    void mm_negative(Int left_col, Int right_col, Int nrow, REAL_T* left, REAL_T* right_up, REAL_T* right_down) const NOTHROW;
    void l_trsm_update(Int left_col, Int right_col, Int nrow, REAL_T* left, REAL_T* right) const NOTHROW;
    /* 内部分解时使用的功能 */
    void l_trsm_update_fact(Int left_col, Int right_col, REAL_T* left, REAL_T* right) const NOTHROW;
    void l_trsm_8x8(Int right_col, REAL_T* left, REAL_T* right) const NOTHROW;
    void ud_trsm(Int ncol, Int nrow, REAL_T* right_up, REAL_T* right_down) const NOTHROW;
    void mm_update_fact(Int left_col, Int right_col, Int nrow, REAL_T* left, REAL_T* right_up, REAL_T* right_down) const NOTHROW;
    void rank8_update(Int right_col, Int nrow, REAL_T* left, REAL_T* right_up, REAL_T* right_down) const NOTHROW;
};


/* 复数版本BLAS，未实现 */
template<typename REAL_T>
class BLAS<complex<REAL_T>> : public scale_kernel_t<complex<REAL_T>> {
    simd_register_transposer transposer;
    Int update_left_ld, update_right_ld, fact_left_ld, fact_right_ld;
    using CPLX_T = complex<REAL_T>;
    void l_trsm_update_cplx(Int left_col, Int right_col, Int nrow, CPLX_T* left, CPLX_T* right, Int left_ld, Int right_ld) const NOTHROW;
    INLINE void ud_trsm_cplx(Int ncol, Int nrow, CPLX_T* right_up, CPLX_T* right_down, Int left_ld, Int right_ld) const NOTHROW;
    void mm_update_cplx(Int left_col, Int right_col, Int nrow, CPLX_T* left, CPLX_T* right_up, CPLX_T* right_down, Int left_ld, Int right_ld) const NOTHROW;
    INLINE void mm_negative_cplx(Int left_col, Int right_col, Int nrow, CPLX_T* left, CPLX_T* right_up, CPLX_T* right_down, Int left_ld, Int right_ld) const NOTHROW;
    INLINE void rank8_update_cplx(Int right_col, Int nrow, CPLX_T* left, CPLX_T* right_up, CPLX_T* right_down, Int left_ld, Int right_ld) const NOTHROW;
    INLINE void l_trsm_8x8_cplx(Int right_col, CPLX_T* left, CPLX_T* right, Int left_ld, Int right_ld) const NOTHROW;
public:

    void set_update_layout(Int left_ld, Int right_ld) {
        update_left_ld = left_ld;
        update_right_ld = right_ld;
    }
    void set_factorize_layout(Int left_ld, Int right_ld) {
        fact_left_ld = left_ld;
        fact_right_ld = right_ld;
    }
    void l_trsm_update(Int left_col, Int right_col, Int nrow, CPLX_T* left, CPLX_T* right) const NOTHROW;
    void l_trsm_update_fact(Int left_col, Int right_col, CPLX_T* left, CPLX_T* right) const NOTHROW;
    void l_trsm_8x8(Int right_col, CPLX_T* left, CPLX_T* right) const NOTHROW;
    void ud_trsm(Int ncol, Int nrow, CPLX_T* right_up, CPLX_T* right_down) const NOTHROW;
    void mm_update_fact(Int left_col, Int right_col, Int nrow, CPLX_T* left, CPLX_T* right_up, CPLX_T* right_down) const NOTHROW;
    void mm_update(Int left_col, Int right_col, Int nrow, CPLX_T* left, CPLX_T* right_up, CPLX_T* right_down) const NOTHROW;
    void mm_negative(Int left_col, Int right_col, Int nrow, CPLX_T* left, CPLX_T* right_up, CPLX_T* right_down) const NOTHROW;
    void rank8_update(Int right_col, Int nrow, CPLX_T* left, CPLX_T* right_up, CPLX_T* right_down) const NOTHROW;
};

} // namespace swSparse
#endif
#endif
