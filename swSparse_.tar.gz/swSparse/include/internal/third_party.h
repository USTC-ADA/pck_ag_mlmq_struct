#ifndef THIRD_PARTY_H_INCLUDED
#define THIRD_PARTY_H_INCLUDED 1

#include "swSparse_base.h"
#include "internal/rename.h"

/* COLAMD */
typedef struct Colamd_Col_struct
{
    Int start ;		/* index for A of first row in this column, or DEAD */
			/* if column is dead */
    Int length ;	/* number of rows in this column */
    union
    {
	Int thickness ;	/* number of original columns represented by this */
			/* col, if the column is alive */
	Int parent ;	/* parent in parent tree super-column structure, if */
			/* the column is dead */
    } shared1 ;
    union
    {
	Int score ;	/* the score used to maintain heap, if col is alive */
	Int order ;	/* pivot ordering of this column, if col is dead */
    } shared2 ;
    union
    {
	Int headhash ;	/* head of a hash bucket, if col is at the head of */
			/* a degree list */
	Int hash ;	/* hash value, if col is not in a degree list */
	Int prev ;	/* previous column in degree list, if col is in a */
			/* degree list (but not at the head of a degree list) */
    } shared3 ;
    union
    {
	Int degree_next ;	/* next column, if col is in a degree list */
	Int hash_next ;		/* next column, if col is in a hash list */
    } shared4 ;

} Colamd_Col ;

typedef struct Colamd_Row_struct
{
    Int start ;		/* index for A of first col in this row */
    Int length ;	/* number of principal columns in this row */
    union
    {
	Int degree ;	/* number of principal & non-principal columns in row */
	Int p ;		/* used as a row pointer in init_rows_cols () */
    } shared1 ;
    union
    {
	Int mark ;	/* for computing set differences and marking dead rows*/
	Int first_column ;/* first column in row (used in garbage collection) */
    } shared2 ;

} Colamd_Row ;

/* size of the Col and Row structures */
#define COLAMD_C(n_col) (((n_col) + 1) * (sizeof(Colamd_Col) / sizeof(Int)))
#define COLAMD_R(n_row) (((n_row) + 1) * (sizeof(Colamd_Row) / sizeof(Int)))

#ifdef __cplusplus
namespace swSparse {
namespace HSL {
template<typename DATA_T>
ErrorStatus mc64a(Int n, Int nnz, const Int* RSTR col_ptr, const Int* RSTR row_idx, const DATA_T* RSTR values, \
                          Int* riperm, real_t<DATA_T>* RSTR r, real_t<DATA_T>* RSTR c, real_t<DATA_T>* real_ptr, \
                          const swSparseTRFOptions* options);
}
}
extern "C" {
#endif


#define AT_PLUS_A_COUNT swSparse_SuiteSparse_at_plus_a_count
#define AT_PLUS_A       swSparse_SuiteSparse_at_plus_a
#define AMD             swSparse_SuiteSparse_amd
#define COLAMD          swSparse_SuiteSparse_colamd
#define CHOLNZCNT       swSparse_SuperLU_cholnzcnt
#define ETREE_POST      swSparse_SuperLU_post_order
#define RELAX_SNODE     swSparse_SuperLU_relax_snode

#define COLAMD_IWLEN(n_row, n_col, nnz) ((nnz) * 2 + COLAMD_C(n_col) + COLAMD_R(n_row) + (n_col) + (nnz) / 5)
#define AMD_IWLEN(n, nnz)               ((n) * 8 + (nnz) + (nnz) / 5)

/* Pe : column offsets */
/* Len : diff(Pe) */
/* Iw initially contains row indices; */
/* iwlen >= nnz + 7n,
 * ideally iwlen = 1.2 * nnz + 8n */
void AMD(Int n, Int* RSTR Pe, Int* RSTR Len, Int* RSTR Iw, Int iwlen, Int* RSTR iperm);

/* p: column offsets on input, iperm on output */
/* A initially contains row indices */
/* Alen >= 2*nnz + n_col + Col_size + Row_size,
 * ideally Alen = 2.2 * nnz + n_col + Col_size + Row_size */
void COLAMD(Int n_row, Int n_col, Int Alen, Int* RSTR A, Int* RSTR p);

Int AT_PLUS_A_COUNT(Int n, const Int* RSTR a_col_off, const Int *a_row_idx, 
        Int* RSTR b_col_off, Int* RSTR b_col_nz, Int* RSTR iwork);
void AT_PLUS_A(Int n, const Int* RSTR a_col_off, const Int *a_row_idx, Int* RSTR b_col_off, Int* RSTR b_row_idx, Int* RSTR iwork);

void ETREE_POST(Int n, const Int *RSTR parent, Int *RSTR iperm, Int *RSTR iwork);
Int CHOLNZCNT(Int neqns, const Int *xadj, const Int *adjncy,
                const Int *perm, const Int *iperm, const Int *etpar, 
                Int *colcnt, Int *rowcnt, Int *nchild /* length n+1 */, Int *iwork);
#ifdef __cplusplus
}
#endif
#endif
