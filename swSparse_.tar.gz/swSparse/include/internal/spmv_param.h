#define seq_nnz 2048 //串行执行的阈值范围

#define worker_number 8 //使用几行从核
#define slaver_number 8 //每行使用几个从核
#define ins_tolerate 0.1 //矩阵带内不同从核间负载均衡差异阈值

#ifdef DATA_TYPE_D

#undef ins_tile_size
#define ins_tile_size 2048 //矩阵带宽度
#undef ins_avg_blocks
#define ins_avg_blocks 4  //每个从核负责矩阵块数量
#undef ins_element_size
#define ins_element_size 32 //为加快判断范围内是否有非零元,将若干列看成1列,若32列中有1列中存在非零元,则认为这32列的范围内存在非零元。如此设置即可加快预处理扫描速度,又能保证LDM每次访存的粒度足够大
#undef ins_cache_element_size
#define ins_cache_element_size 64 //一个小块的宽度,以size为最小单位,此处表示每个分块宽度为32*64=2048

#undef BUFFER_B
#define  BUFFER_B 2048 //从核上存放右端向量数组大小,需大于等于ins_tile_size
#undef BUFFER_X
#define  BUFFER_X 2048 //从核上存放x向量的数组大小,需大于等于ins_element_size*ins_cache_element_size
#undef BUFFER_NNZ
#define  BUFFER_NNZ 2048 //从核上存放非零元值的数组大小
#undef BUFFER_I
#define  BUFFER_I 256 //从核上存放coo坐标的数组大小
#undef BUFFER_TASK 
#define  BUFFER_TASK 128 //从核上存放swcoo结构中任务信息结构体的数组大小
#undef Size_RLC
#define  Size_RLC 1 //核间通信参数,实数为1,复数为2
#undef DATA_RLC
#define  DATA_RLC doublev4 //核间通信时谁用的向量化类型

#endif

#ifdef DATA_TYPE_S

#undef ins_tile_size
#define ins_tile_size 2048 
#undef ins_avg_blocks
#define ins_avg_blocks 4  
#undef ins_element_size
#define ins_element_size 32
#undef ins_cache_element_size
#define ins_cache_element_size 64

#undef BUFFER_B
#define  BUFFER_B 2048 
#undef BUFFER_X
#define  BUFFER_X 2048  
#undef BUFFER_NNZ
#define  BUFFER_NNZ 2048
#undef BUFFER_I
#define  BUFFER_I 256
#undef BUFFER_TASK
#define  BUFFER_TASK 128
#undef Size_RLC
#define  Size_RLC 1
#undef DATA_RLC
#define  DATA_RLC floatv4 

#endif

#ifdef DATA_TYPE_Z

#undef ins_tile_size
#define ins_tile_size 1024 
#undef ins_avg_blocks
#define ins_avg_blocks 2 
#undef ins_element_size
#define ins_element_size 32
#undef ins_cache_element_size
#define ins_cache_element_size 32

#undef BUFFER_B
#define  BUFFER_B 1024 
#undef BUFFER_X
#define  BUFFER_X 1024
#undef BUFFER_NNZ
#define  BUFFER_NNZ 512
#undef BUFFER_I
#define  BUFFER_I 64
#undef BUFFER_TASK
#define  BUFFER_TASK 128
#undef Size_RLC
#define  Size_RLC 2
#undef DATA_RLC
#define  DATA_RLC doublev4
#undef DATA_CPY
#define  DATA_CPY doublev4  

#endif

#ifdef DATA_TYPE_C

#undef ins_tile_size
#define ins_tile_size 1024 
#undef ins_avg_blocks
#define ins_avg_blocks 2 
#undef ins_element_size
#define ins_element_size 32
#undef ins_cache_element_size
#define ins_cache_element_size 32

#undef BUFFER_B
#define  BUFFER_B 1024 
#undef BUFFER_X
#define  BUFFER_X 1024
#undef BUFFER_NNZ
#define  BUFFER_NNZ 512
#undef BUFFER_I
#define  BUFFER_I 64
#undef BUFFER_TASK
#define  BUFFER_TASK 128
#undef Size_RLC
#define  Size_RLC 2
#undef DATA_RLC
#define  DATA_RLC floatv4 
#undef DATA_CPY
#define  DATA_CPY floatv4
#endif

