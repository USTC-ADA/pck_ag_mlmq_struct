#ifndef SPLUTRSV_PARAM_H_INCLUDED
#define SPLUTRSV_PARAM_H_INCLUDED

#include <crts.h>
#include <stdio.h>
#include "swSparse_base.h"
#include "swSparse_options.h"
#include "internal/rename.h"

namespace swSparse {

// 统计前代回代信息
#define LUTRSV_STATISTIC
#define LUTRSV_STAGE_NUM 3
#define LUTRSV_PREPROCESS 0
#define LUTRSV_LSOLVE 1
#define LUTRSV_USOLVE 2

// 使用的从核数
#define CPE_FOR_LUTRSV 64
// 从核 iperm 所需最小 n
#define CPE_IPERM_N 8192
// 从核加速负载估计所需最小超节点数
#define CPE_ESTIMATE_NSUPER 8192

template<typename DATA_T>
struct lutrsv_iperm_arg_t {
    Int n;
    DATA_T* src;
    DATA_T* dst;
    Int * iperm;
};

using lutrsv_weight_t = float;
struct lutrsv_static_estimate_arg_t {
    Int nsuper;
    lutrsv_weight_t *lweight;
    lutrsv_weight_t *uweight; 
    swSparseLUSupernodes *lu;

    // flop
    lutrsv_weight_t flop;
    // dense mem
    lutrsv_weight_t alpha;
    // sparse mem
    lutrsv_weight_t beta;
};

struct lutrsv_group_t {
    int8_t partner[64];
    // size: group 大小, npart: 分区数，每个区处理一行，id: 当前核心在 group 中的 id
    // 假设 2 个分区，group_size 为 6，以 aij 表示第 i 区的第 j 个核心，排列如下
    // a00, a10, a01, a11, a02, a12 (a[part_num][part_id])
    // 对角块只由每个分区第 0 个核心计算，即 a10, a20 计算，其余核心计算非对角块
    Int size, npart, id;
};

struct lutrsv_task_t {
    Int sup_id, stride, queue_id;
    struct lutrsv_group_t group;
};

struct lutrsv_static_schedule_arg_t {
    Int* first_child;
    Int* next_sibling;

    void* lsubtrees;
    Int* lsubtree_offsets;
    void* ltasks;
    Int* ltask_offsets;
    void* ltask_queue;
    Int* lnode_status;

    void* usubtrees;
    Int* usubtree_offsets;
    void* utasks;
    Int* utask_offsets;
    void* utask_queue;
    Int* unode_status;
};

// 传递给从核的参数
template<typename DATA_T>
struct splutrsv_arg_t {
    Int n;
    DATA_T *x;
    swSparseLUSupernodes *lusup;
    Int* first_child;
    Int* next_sibling;
    Int* snode_status;
    void* subtrees;
    Int* subtree_offsets;
    void* tasks;
    Int* task_offsets;
    void* task_queue;
};

ErrorStatus lutrsv_static_schedule(LUSup* lu, lutrsv_static_schedule_arg_t* args);

void lutrsv_destroy_static_schedule_arg(lutrsv_static_schedule_arg_t* args);

} // namespace swSparse 

EXTERN void swSparse_lutrsv_get_flop_and_memory(Int n, swSparseMatrix* lu, size_t size_of_type);
EXTERN void swSparse_print_lutrsv_info();

#endif