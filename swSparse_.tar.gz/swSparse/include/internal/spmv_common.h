#ifndef SPMV_COMMON_H_INCLUDED
#define SPMV_COMMON_H_INCLUDED 1

#include "swSparse_base.h"
#include "internal/rename.h"

#ifdef __cplusplus
#include "internal/templates.h"
namespace swSparse {

template<typename DATA_T, typename Conj>
ErrorStatus mv_execute_csr(const int m , const int n , DATA_T alpha , MatrixCSRC *mat, const DATA_T *x, DATA_T beta , DATA_T *y , const swSparseMVOptions* options);

template<typename DATA_T, typename Conj>
ErrorStatus mv_execute_swcoo(DATA_T alpha, swSparseMatrix New_Matrix, const DATA_T *x, DATA_T beta, DATA_T *y, const swSparseMVOptions* options);

template<typename DATA_T , typename Conj>
ErrorStatus mm_execute_swcoo(DATA_T alpha , swSparseMatrix New_Matrix, Int nvec, const DATA_T *x, Int step_x, DATA_T beta , DATA_T *y, Int step_y , const swSparseMMOptions* options);

template<typename DATA_T , typename Conj>
ErrorStatus struct_mv_execute(DATA_T alpha, const DATA_T *aa, const DATA_T *xx, DATA_T beta,  DATA_T *bb, const swSparseInt *dim ,  swSparseInt rnnz , const swSparseInt (*inpos)[3]);

} // namespace swSparse
#endif

SWSPARSE_API
swSparse_mv_inspect_to_csr(Matrix old_mat, Matrix *new_mat, const swSparseMVOptions* options);
SWSPARSE_API
swSparse_mv_inspect_to_swcoo(Matrix old_mat, Matrix *new_mat, const swSparseMVOptions* options);

#endif
