#ifndef DEBUG_ARRAY_H_INCLUDED
#define DEBUG_ARRAY_H_INCLUDED 1

#include "internal/debug.h"
#ifdef __cplusplus
#include "internal/templates.h"
#ifdef __sw_slave__
#include "internal/CPE_simd_utils.h"
#endif
#endif

/* 如果需要检查定长数组是否越界，可以在数组的访问中插装相关检查 */
/* 但目前该类并没有广泛应用于整个项目，很多地方仍然使用原生数组 */
#ifdef __cplusplus
namespace swSparse {
template<typename TYPE, size_t SIZE, size_t ALIGN>
class ARR {
protected:
    alignas(ALIGN) TYPE data[SIZE];
public:
    inline TYPE& operator[](ptrdiff_t i) {
        return data[i];
    }
    inline const TYPE& operator[](ptrdiff_t i) const {
        return data[i];
    }
    template<size_t A>
    inline void copy_from(const ARR<TYPE, SIZE, A>& other) {
        memcpy(this->data, other.data, SIZE * sizeof(TYPE));
    }
    template<size_t S, size_t A>
    inline void copy_from(const ARR<TYPE, S, A>& other, size_t size) {
        memcpy(this->data, other.data, size * sizeof(TYPE));
    }
    inline operator TYPE*() { return &data[0]; }
};

template<typename TYPE, size_t SIZE>
using Array = ARR<TYPE, SIZE, alignof(TYPE)>;

#ifdef __sw_slave__
template<typename TYPE, size_t SIZE>
class AAR : public ARR<TYPE, SIZE, 64> {
    static_assert((sizeof(TYPE) * SIZE) % 64 == 0);
public:
    inline void fill(as_arg<TYPE> value) {
        ::swSparse::fill(this->data, SIZE, value);
    }
};

template<typename TYPE, size_t SIZE>
using AArray = AAR<TYPE, SIZE>;
#endif
}
#endif
#endif