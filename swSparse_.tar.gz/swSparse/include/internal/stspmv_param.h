#ifndef STSPMV_PARAM_H_INCLUDED
#define STSPMV_PARAM_H_INCLUDED

#include <stddef.h>
#include "swSparse_base.h"
#include "internal/rename.h"
#include "internal/utils.h"

template<size_t element_size>
struct stspmv_params_27;
template<>
struct stspmv_params_27<4> {
    constexpr static const int len = 64;
};
template<>
struct stspmv_params_27<8> {
    constexpr static const int len = 64;
};
template<>
struct stspmv_params_27<16> {
    constexpr static const int len = 32;
};

template<size_t element_size>
struct stspmv_params_125;
template<>
struct stspmv_params_125<4> {
    constexpr static const int len = 128;
};
template<>
struct stspmv_params_125<8> {
    constexpr static const int len = 128;
};
template<>
struct stspmv_params_125<16> {
    constexpr static const int len = 64;
};

template<size_t element_size>
struct stspmv_params_343;
template<>
struct stspmv_params_343<4> {
    constexpr static const int len = 128;
};
template<>
struct stspmv_params_343<8> {
    constexpr static const int len = 64;
};
template<>
struct stspmv_params_343<16> {
    constexpr static const int len = 32;
};

#endif
