#ifndef TEMPLATES_H_INCLUDED
#define TEMPLATES_H_INCLUDED 1
#ifdef __cplusplus

//#include <cstddef>
#include <type_traits>
#include <crts.h>
#include <simd.h>
#include "swSparse.h"
#include "internal/rename.h"

#ifdef SWSPARSE_USE_STD_COMPLEX
using std::complex;
using std::conj;
template<typename T>
inline T fabs(const complex<T>& x) {
    return std::abs(x);
}
#else
using swSparse::complex;
using swSparse::conj;
using swSparse::fabs;
#endif
namespace swSparse {
using std::fabs;
}

#ifdef __sw_slave__
    using SV8Complex = complex<floatv8>;
    using DV8Complex = complex<doublev8>;
    #define SIMD_REAL_SINGLE using S = floatv8; using SR = floatv8;
    #define SIMD_REAL_DOUBLE using S = doublev8; using SR = doublev8;
    #define SIMD_COMPLEX_SINGLE using S = SV8Complex; using SR = floatv8;
    #define SIMD_COMPLEX_DOUBLE using S = DV8Complex; using SR = doublev8;
    #define SIMD_INT using S = intv16; using SR = intv16;
#else // SIMD on MPE is not used 
    #define SIMD_REAL_SINGLE
    #define SIMD_REAL_DOUBLE
    #define SIMD_COMPLEX_SINGLE
    #define SIMD_COMPLEX_DOUBLE
    #define SIMD_INT
#endif

template<typename T>
struct Template_sturctT;

template<typename T>
using type_traits = Template_sturctT<T>;

template<>
struct Template_sturctT<float> {
    constexpr static const MatrixElementType element_type = REAL_SINGLE;
    constexpr static const char name_short = 's';
    constexpr static const int simd_width = 8;
    constexpr static const int simd_real_width = 8;
    using A = float;
    using R = float;
    SIMD_REAL_SINGLE
};

template<>
struct Template_sturctT<double> {
    constexpr static const MatrixElementType element_type = REAL_DOUBLE;
    constexpr static const char name_short = 'd';
    constexpr static const int simd_width = 8;
    constexpr static const int simd_real_width = 8;
    using A = double;
    using R = double;
    SIMD_REAL_DOUBLE
};

template<>
struct Template_sturctT<SComplex> {
    constexpr static const MatrixElementType element_type = COMPLEX_SINGLE;
    constexpr static const char name_short = 'c';
    constexpr static const int simd_width = 8;
    constexpr static const int simd_real_width = 4;
    using A = const SComplex&;
    using R = float;
    SIMD_COMPLEX_SINGLE
};

template<>
struct Template_sturctT<DComplex> {
    constexpr static const MatrixElementType element_type = COMPLEX_DOUBLE;
    constexpr static const char name_short = 'z';
    constexpr static const int simd_width = 8;
    constexpr static const int simd_real_width = 4;
    using A = const DComplex&;
    using R = double;
    SIMD_COMPLEX_DOUBLE
};

template<>
struct Template_sturctT<int> {
    constexpr static const int simd_width = 16;
    constexpr static const int simd_real_width = 16;
    using A = int;
    using R = int;
    SIMD_INT
};

#ifdef __sw_slave__
template<>
struct Template_sturctT<floatv8> {
    constexpr static const int simd_width = 8;
    using S = float;
    using SR = float;
};
template<>
struct Template_sturctT<doublev8> {
    constexpr static const int simd_width = 8;
    using S = double;
    using SR = double;
};
template<>
struct Template_sturctT<SV8Complex> {
    constexpr static const int simd_width = 8;
    using SR = float;
    using S = SComplex;
};
template<>
struct Template_sturctT<DV8Complex> {
    constexpr static const int simd_width = 8;
    using SR = double;
    using S = DComplex;
};
template<>
struct Template_sturctT<intv16> {
    constexpr static const int simd_width = 16;
    using S = int;
};
#endif
template<typename T>
inline constexpr const int simd_width = Template_sturctT<T>::simd_width;
template<typename T>
inline constexpr const int simd_real_width = Template_sturctT<T>::simd_real_width;

// 模板结构体TT, 不同的数据类型中定义了不同是数据结构
template<typename T>
using real_t = typename Template_sturctT<T>::R;

// We may pass complex types as reference (const DComplex&)
// However, we can just pass as value. It becomes the same under the compiler optimization 
template<typename T>
using as_arg = typename Template_sturctT<T>::A;

#ifdef __sw_slave__
    // use simd_t when complex arithmetics can be vectorized
    // use simd_real_t when only real arithmetics can be vectorized
    template<typename T>
    using simd_t = typename Template_sturctT<T>::S;
    template<typename T>
    using simd_real_t = typename Template_sturctT<T>::SR;
    template<typename T>
    using scalar_t = typename Template_sturctT<T>::S;
    template<typename T>
    using scalar_real_t = typename Template_sturctT<T>::SR;
#endif


/* special values of alpha and beta */
template<int val>
struct C {
    C() {}
    C(const C&) {}
    C& operator=(const C&) {
        return *this;
    }
    // can convert to different types, unlike std::integral_constant
    template<typename T>
    inline constexpr operator T() const { return T(val); }
};

using zero_t = C<0>;
using one_t = C<1>;

template<typename T>
inline constexpr T operator*(zero_t, T) { return T(0); }
template<typename T>
inline constexpr T operator*(T, zero_t) { return T(0); }
template<typename T>
inline constexpr T operator*(one_t, T x) { return x; }
template<typename T>
inline constexpr T operator*(T x, one_t) { return x; }

template<typename T>
inline constexpr const bool is_zero_t = std::is_same<T, zero_t>::value;
template<typename T>
inline constexpr const bool is_one_t = std::is_same<T, one_t>::value;

template<typename T>
inline bool is_zero(T v) { return v == T(0); }
template<typename T>
inline bool is_zero(const complex<T>& v) { return is_zero(v.real) && is_zero(v.imag); }
template<typename T>
inline bool is_one(T v) { return v == T(1); }
template<typename T>
inline bool is_one(const complex<T>& v) { return is_one(v.real) && is_zero(v.imag); }

// Can be optimized out by the compiler
// Do NOT use memcpy, DMA or RMA on dummy_t. 
// If DATA_T can be dummy_t, do NOT: memcpy(dst, src, sizeof(DATA_T) * length);  
using dummy_t = one_t;
inline constexpr dummy_t* dummy_ptr = nullptr;

#define CHECK_FUNDAMENTAL_TYPE(REAL_T) static_assert(std::is_fundamental<REAL_T>::value, #REAL_T" should be fundamental type")

/* conjugate or non-conjugate */
struct ID {
    template<typename T>
    INLINE static T value(T x) { return x; }
};
struct CJ {
    template<typename T>
    INLINE static complex<T> value(complex<T> x) { return conj(x); }
};

// let conjugate<float> and not_conjugate<float> be the same type
// reduce binary bloating

template<typename T>
struct conjugate_selector {
    using type = ID;
    using sign_t = dummy_t;
    constexpr static sign_t get_imaginary_sign(bool c) { return dummy_t(); }
};
template<typename T>
struct conjugate_selector<complex<T>> {
    using type = CJ;
    using sign_t = T;
    INLINE static sign_t get_imaginary_sign(bool c) { return c ? T(-1) : T(1); }
};

template<typename T>
using not_conjugate = ID;

template<typename T>
using conjugate = typename conjugate_selector<T>::type;

template<typename T>
using sign_t = typename conjugate_selector<T>::sign_t;

template<typename T>
INLINE sign_t<T> get_imaginary_sign(bool c) { return conjugate_selector<T>::get_imaginary_sign(c); }
template<typename T>
INLINE T conjugate_value(T val, sign_t<T> sign) { return val; }
template<typename T>
INLINE complex<T> conjugate_value(const complex<T>& val, sign_t<complex<T>> sign) { return complex<T>(val.real, val.imag * sign); }

/* athread_spawn cannot spawn C++ templated kernels because of name mangling */
#if defined(__sw_slave__)
    INLINE int get_cache_size() {
        switch(get_slave_cache_size()) {
        case 128l*1024l:
            return CACHE_128KB;
        case 32l*1024l:
            return CACHE_32KB;
        default:
            return CACHE_0KB;
        }
    }

    #define WITH_CACHE_SIZE(name, kernel, cache_size) \
        extern "C" void name(void* args) { \
            int old_size = get_cache_size(); \
            if(old_size != cache_size) set_cache_size(cache_size); \
            kernel(args); \
            if(old_size != cache_size) set_cache_size(old_size); \
        }
    #define IGNORE_CACHE_SIZE(name, kernel)     extern "C" void name(void* args) { kernel(args); }
    #define WITH_CACHE_0KB(name, kernel)        WITH_CACHE_SIZE(name, kernel, CACHE_0KB)
    #define WITH_CACHE_32KB(name, kernel)       WITH_CACHE_SIZE(name, kernel, CACHE_32KB)
    #define WITH_CACHE_128KB(name, kernel)      WITH_CACHE_SIZE(name, kernel, CACHE_128KB)
    #define WITH_CACHE_IGNORE(name, kernel)     IGNORE_CACHE_SIZE(name, kernel)
    #define CPE_CONCRETE_KERNEL(kernel, cache)  WITH_##cache(swSparse_##kernel, kernel) 
    #define CPE_TEMPLATE_KERNEL(kernel, cache) \
        WITH_##cache(swSparse_s_##kernel, kernel<float>)  \
        WITH_##cache(swSparse_d_##kernel, kernel<double>)  \
        WITH_##cache(swSparse_c_##kernel, kernel<SComplex>)  \
        WITH_##cache(swSparse_z_##kernel, kernel<DComplex>)
    #define CPE_TEMPLATE_KERNEL_REUSE_S_FOR_I(kernel, cache) \
        WITH_##cache(swSparse_i_##kernel, kernel<uint32_t>)  \
        WITH_##cache(swSparse_s_##kernel, kernel<uint32_t>)  \
        WITH_##cache(swSparse_d_##kernel, kernel<double>)  \
        WITH_##cache(swSparse_c_##kernel, kernel<SComplex>)  \
        WITH_##cache(swSparse_z_##kernel, kernel<DComplex>) 
#elif defined(__sw_host__)
    #define ATHREAD_SPAWN_KERNEL(kernel_name, argtype, prefixed_name) \
    extern "C" void prefixed_name(void* args); \
    INLINE int athread_spawn_##kernel_name(argtype* arg) { \
        return __real_athread_spawn(reinterpret_cast<void*>(prefixed_name), arg, 1); \
    }  
    #define ATHREAD_SPAWN_CONCRETE_ARGTYPE(kernel_name, argtype) ATHREAD_SPAWN_KERNEL(kernel_name, argtype, slave_swSparse_##kernel_name)
    #define ATHREAD_SPAWN_TEMPLATE_ARGTYPE(kernel_name, argtype) \
        ATHREAD_SPAWN_KERNEL(kernel_name, argtype<float>, slave_swSparse_s_##kernel_name) \
        ATHREAD_SPAWN_KERNEL(kernel_name, argtype<double>, slave_swSparse_d_##kernel_name) \
        ATHREAD_SPAWN_KERNEL(kernel_name, argtype<SComplex>, slave_swSparse_c_##kernel_name) \
        ATHREAD_SPAWN_KERNEL(kernel_name, argtype<DComplex>, slave_swSparse_z_##kernel_name)

    #define ATHREAD_SPAWN_MULTICG_KERNEL(kernel_name, argtype, prefixed_name) \
    extern "C" void prefixed_name(void* args); \
    INLINE int athread_spawn_##kernel_name(argtype* arg, int cgmask) { \
        return __real_athread_spawn_cgmask(cgmask, reinterpret_cast<void*>(prefixed_name), arg, 1); \
    }  
    #define ATHREAD_SPAWN_MULTICG_CONCRETE_ARGTYPE(kernel_name, argtype) ATHREAD_SPAWN_MULTICG_KERNEL(kernel_name, argtype, slave_swSparse_##kernel_name)
    #define ATHREAD_SPAWN_MULTICG_TEMPLATE_ARGTYPE(kernel_name, argtype) \
        ATHREAD_SPAWN_MULTICG_KERNEL(kernel_name, argtype<float>, slave_swSparse_s_##kernel_name) \
        ATHREAD_SPAWN_MULTICG_KERNEL(kernel_name, argtype<double>, slave_swSparse_d_##kernel_name) \
        ATHREAD_SPAWN_MULTICG_KERNEL(kernel_name, argtype<SComplex>, slave_swSparse_c_##kernel_name) \
        ATHREAD_SPAWN_MULTICG_KERNEL(kernel_name, argtype<DComplex>, slave_swSparse_z_##kernel_name)
#endif


/* 
 * example:
 * 
 *  cpe.cpp:
 *      template<typename DATA_T>
 *      NOINLINE static void spmv_kernel(void* args) { ... }
 * 
 *      CPE_TEMPLATE_KERNEL(spmv_kernel, CACHE_128KB)
 * 
 * or ignore cache_size:
 *      CPE_TEMPLATE_KERNEL(spmv_kernel, CACHE_IGNORE)
 * 
 *  mpe.cpp:
 *      ATHREAD_SPAWN_TEMPLATE_ARGTYPE(spmv_kernel, spmv_args)
 * 
 *      ...
 *          spmv_args<DATA_T> args;
 *          athread_spawn_spmv_kernel(&args);
 *          athread_join();
 *      ...
 */

/* For Array of Structure layout of COO */
template<typename IDX, typename VAL>
struct COO_tuple_t {
    VAL value;
    IDX row_idx, col_idx;
};
#endif
#endif
