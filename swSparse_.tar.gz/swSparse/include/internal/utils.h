#ifndef UTILS_H_INCLUDED
#define UTILS_H_INCLUDED 1

#include<ctype.h>

#include "swSparse_base.h"
#include "internal/rename.h"


INLINE int32_t num_bits(int32_t x) {
    return 32 - __builtin_clz(x);
}

INLINE int32_t ceil_log_2(int32_t x) {
    Int y = num_bits(x - 1);
    return (x <= 0) ? 0 : y;
}

INLINE int32_t ceil_pow_2(int32_t x) {
    Int y = num_bits(x - 1);
    return (x <= 0) ? 1 : (1 << y);
}

INLINE int32_t ceiling_div(int32_t num, int32_t den) {
    return (num - 1) / den + 1;
}

INLINE int64_t ceiling_divl(int64_t num, int64_t den) {
    return (num - 1) / den + 1;
}

INLINE int32_t ceiling_sra(int32_t num, int32_t shift) {
    return ((num - 1) >> shift) + 1;
}

INLINE int32_t min(int32_t a, int32_t b) {
    return (a < b) ? a : b;
}

INLINE int32_t max(int32_t a, int32_t b) {
    return (a > b) ? a : b;
}

INLINE int64_t minl(int64_t a, int64_t b) {
    return (a < b) ? a : b;
}

INLINE int64_t maxl(int64_t a, int64_t b) {
    return (a > b) ? a : b;
}

INLINE int32_t lowest_bit(int32_t x) {
    return x & (-x);
}

/* used in parsing matrix market files */
INLINE void str_to_lower(char *p) {
    while(*p != '\0') {
        *p = tolower(*p);
        ++p;
    }
}

// both MPE and CPE
INLINE void mem_fence() {
    asm volatile("memb" ::: "memory");
}

INLINE size_t element_size(MatrixElementType type) {
    switch (type) {
    case REAL_SINGLE:
        return sizeof(float);
    case REAL_DOUBLE:
        return sizeof(double);
    case COMPLEX_SINGLE:
        return sizeof(SComplex);
    case COMPLEX_DOUBLE:
        return sizeof(DComplex);
    default:
        UNREACHABLE;
    }
}


EXTERN Bool swSparse_valid_permutation(int n, const int* perm, int* work);
EXTERN float swSparse_s_mse(int n, const float *a, const float *b);
EXTERN double swSparse_d_mse(int n, const double *a, const double *b);
EXTERN float swSparse_s_norm_2(int n, const float *a);
EXTERN double swSparse_d_norm_2(int n, const double *a);

#endif
