#ifndef CPE_SIMD_ASM_H
#define CPE_SIMD_ASM_H

/* functions on CPE */

#include <simd.h>
#include "internal/rename.h"

#define ASM_SRC_REGISTER_TYPE "f"
#define ASM_DST_REGISTER_TYPE "=f"

INLINE intv16 simd_ptab_readw(intv16 vbase_addr, intv16 voffset) {
    intv16 value;
    asm volatile("plutw %1,%2,%0" 
                 : ASM_DST_REGISTER_TYPE(value) : ASM_SRC_REGISTER_TYPE(voffset), ASM_SRC_REGISTER_TYPE(vbase_addr) : "memory");
    return value;
}

INLINE void simd_ptab_writew(intv16 vbase_addr, intv16 voffset, intv16 value) {
    asm volatile("pwrtw %1,%2,%0"
                 : : ASM_SRC_REGISTER_TYPE(value), ASM_SRC_REGISTER_TYPE(voffset), ASM_SRC_REGISTER_TYPE(vbase_addr)  : "memory");
}

INLINE doublev8 simd_ptab_readd(intv16 vbase_addr, intv16 voffset) {
    doublev8 value;
    asm volatile("plutw %1,%2,%0" 
                 : ASM_DST_REGISTER_TYPE(value) : ASM_SRC_REGISTER_TYPE(voffset), ASM_SRC_REGISTER_TYPE(vbase_addr) : "memory");
    return value;
}

INLINE void simd_ptab_writed(intv16 vbase_addr, intv16 voffset, doublev8 value) {
    asm volatile("pwrtw %1,%2,%0"
                 : : ASM_SRC_REGISTER_TYPE(value), ASM_SRC_REGISTER_TYPE(voffset), ASM_SRC_REGISTER_TYPE(vbase_addr)  : "memory");
}

INLINE intv16 simd_blend_i16(intv16 ph, intv16 if_zero, intv16 if_one) {
    intv16 result;
    asm volatile("vseleqh %1,%2,%3,%0"
                 : ASM_DST_REGISTER_TYPE(result) : ASM_SRC_REGISTER_TYPE(ph), ASM_SRC_REGISTER_TYPE(if_zero), ASM_SRC_REGISTER_TYPE(if_one));
    return result;
}

#endif