#ifndef ALGORITHM_HEAP_H_INCLUDED
#define ALGORITHM_HEAP_H_INCLUDED

// C++ template functions, header only

#ifdef __cplusplus
#include "internal/rename.h"
#include "internal/utils.h"
#include "internal/templates.h"
#include "internal/debug.h"
#include "internal/algorithm.h"

namespace swSparse {

/* heap operation */
template<typename Element, typename Key>
INLINE void adjust_heap_min_down(Int i, Int size, Element *heap, Key && key) {
    Element tmp_element = heap[i];
    auto temp_key = key(tmp_element);
    for(Int k = i * 2 + 1; k < size; k = k * 2 + 1){
        Int k_1 = k + 1;
        Int k_2 = (k_1 >= size) ? k : k_1;
        k = (key(heap[k]) > key(heap[k_2])) ? k_2 : k;
        if(temp_key > key(heap[k])) {
            heap[i] = heap[k];
            i = k;
        } else {
            break;
        }
    }
    heap[i] = tmp_element;
}


template<typename Element, typename Key>
INLINE void adjust_heap_max_down(Int i, Int size, Element *heap, Key && key) {
    Element tmp_element = heap[i];
    auto temp_key = key(tmp_element);
    for(Int k = i * 2 + 1; k < size; k = k * 2 + 1){
        Int k_1 = k + 1;
        Int k_2 = (k_1 >= size) ? k : k_1;
        k = (key(heap[k]) < key(heap[k_2])) ? k_2 : k;
        if(temp_key < key(heap[k])) {
            heap[i] = heap[k];
            i = k;
        } else {
            break;
        }
    }
    heap[i] = tmp_element;
} 

template<typename Element, typename Key>
INLINE void adjust_heap_min_up(Int i, Element *heap, Key && key) {
    Element tmp_element = heap[i];
    auto temp_key = key(tmp_element);
    for(Int k = (i - 1) >> 1; k >= 0; k = (k - 1) >> 1){  // (-1) >> 1 == -1. (k - 1) / 2 is wrong
        if(temp_key < key(heap[k])) {
            heap[i] = heap[k];
            i = k;
        } else {
            break;
        }
    }
    heap[i] = tmp_element;
}

template<typename Element, typename Key>
INLINE void adjust_heap_max_up(Int i, Element *heap, Key && key) {
    Element tmp_element = heap[i];
    auto temp_key = key(tmp_element);
    for(Int k = (i - 1) >> 1; k >= 0; k = (k - 1) >> 1){  // (-1) >> 1 == -1. (k - 1) / 2 is wrong
        if(temp_key > key(heap[k])) {
            heap[i] = heap[k];
            i = k;
        } else {
            break;
        }
    }
    heap[i] = tmp_element;
}

template<typename Element, typename Key>
INLINE void init_heap_min(Int size, Element *heap, Key && key) {
    for(Int q = (size >> 1) - 1; q >= 0; --q) {
        adjust_heap_min_down(q, size, heap, key);
    }
}

template<typename Element, typename Key>
INLINE void init_heap_max(Int size, Element *heap, Key && key) {
    for(Int q = (size >> 1) - 1; q >= 0; --q) {
        adjust_heap_max_down(q, size, heap, key);
    }
}

struct heap_element_t {
    Int index, which;
    struct key {
        Int operator()(const heap_element_t& h) const { return h.index; }
    };
};

// not inlined
SLAVE_FUNCTION void init_heap_min(Int size, heap_element_t *heap) NOTHROW;

}

#endif
#endif