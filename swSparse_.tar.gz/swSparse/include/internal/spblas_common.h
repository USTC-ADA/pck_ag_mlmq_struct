#ifndef SPBLAS_COMMON_H_INCLUDED
#define SPBLAS_COMMON_H_INCLUDED 1

#include "swSparse_base.h"
#include "internal/rename.h"

#ifdef __cplusplus
#include "internal/templates.h"
namespace swSparse {


template<typename DATA_T>
ErrorStatus add_csr( \
    DATA_T alpha, DATA_T beta, Int m, Int n, \
    MatrixCSRC *a, MatrixCSRC *b, MatrixCSRC *c, Bool a_conj, Bool b_conj);

template<typename DATA_T>
ErrorStatus gemm_csr( \
    DATA_T alpha, DATA_T beta, Int m, Int n, Int k, \
    MatrixCSRC *a, MatrixCSRC *b, MatrixCSRC *d, MatrixCSRC *c, Bool a_conj, Bool b_conj);

template<typename DATA_T, typename Conj>
ErrorStatus mv_execute_csr(const int m , const int n , DATA_T alpha , MatrixCSRC *mat, const DATA_T *x, DATA_T beta , DATA_T *y , const swSparseMVOptions* options);
    
// y = alpha * x
template<typename DATA_T>
void vector_scale(DATA_T alpha, Int n, const DATA_T* RSTR x, DATA_T* RSTR y);

// y = alpha * conj(x)
template<typename DATA_T>
void vector_scale_conj(DATA_T alpha, Int n, const DATA_T* RSTR x, DATA_T* RSTR y);

// Y = alpha * X
template<typename DATA_T>
void dense_scale(DATA_T alpha, Int n, Int nvec, const DATA_T* RSTR x, Int ldx, DATA_T* RSTR y, Int ldy);

// out = in + delta
void index_shift(Int n, const Int *RSTR in_index, Int *RSTR out_index, Int delta);

} // namespace swSparse
#endif

// SWSPARSE_API
// swSparse_mv_inspect_to_csr(Matrix old_mat, Matrix *new_mat, const swSparseMVOptions* options);
// SWSPARSE_API
// swSparse_mv_inspect_to_swcoo(Matrix old_mat, Matrix *new_mat, const swSparseMVOptions* options);

#define COL_IDX_DIGITS 16
#define ROW_IDX_DIGITS 16

#endif
