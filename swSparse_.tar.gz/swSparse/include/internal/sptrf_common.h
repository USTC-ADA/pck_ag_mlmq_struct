#ifndef SPTRF_COMMON_H_INCLUDED
#define SPTRF_COMMON_H_INCLUDED 1

// 输出运行中统计数据
#define LU_PRINT_STATS

#include <stdint.h>
#include <math.h>
#ifdef LU_PRINT_STATS
#include <sys/time.h>
#endif
#include "swSparse.h"
#include "internal/rename.h"

typedef int8_t col_status_t;

// 预处理中进行对称化结构分析的结果
typedef struct {
	Int *riperm;
	Int *ciperm;
	Int *etree;
	col_status_t *status;
	Int *part_super;
	Int *rowcnt;
	Int *colcnt;
    Int *to_clean;
    Int etree_height;
} sym_analysis_result_t;

BEGIN_C_FUNCTIONS
// allocates `l->i_offsets`, `u->col_offsets`, `u->seg_offsets`
// allocates `l->indices` if its size is not 0
ErrorStatus swSparse_sptrf_symbolic(Matrix a, LUSup* lu, sym_analysis_result_t* sym_res, const swSparseTRFOptions* options);
ErrorStatus swSparse_symmetric_analysis(Int n, const Int* offsets, const Int* indices, sym_analysis_result_t* result, uint8_t algorithm);
END_C_FUNCTIONS

#ifdef __cplusplus
#include "internal/templates.h"
namespace swSparse {

template<typename REAL_T>
struct PR : public sym_analysis_result_t {
	REAL_T perterb_threshold;
};

struct NR {
    Int interchange_count, perturbation_count;
};

// 预处理的结果 
template<typename REAL_T>
using preprocess_result_t = PR<REAL_T>;

// 数值分解中，影响数值精度的事件记录：interchange - 为选主元而进行的行交换；perturbation - 当对角块内不存在足够大的主元时，加以扰动
using numeric_result_t = NR;

template<typename DATA_T>
ErrorStatus sptrf_preprocess(Matrix a, Matrix pa, preprocess_result_t<real_t<DATA_T>>* result, \
		real_t<DATA_T>* rscale, real_t<DATA_T>* cscale, const swSparseTRFOptions* options);
template<typename DATA_T>
ErrorStatus sptrf_preprocess_same_pattern(Matrix a, Matrix pa, preprocess_result_t<real_t<DATA_T>>* result, \
		real_t<DATA_T>* rscale, real_t<DATA_T>* cscale, const swSparseTRFOptions* options);
template<typename DATA_T>
ErrorStatus sptrf_numeric(Matrix a, LUSup* lu, real_t<DATA_T> perterb_thres, \
        Int* riperm, numeric_result_t* res, const swSparseTRFOptions* options);

class SYM {  // Raluca Portase, Bora Ucar, Matrix symmetrization and sparse direct solvers
    Bool* a_candidate;
    int dense_threshold;
public:
    template<typename REAL_T>
    ErrorStatus select_candidates(Int n, Int nnz, const Int* RSTR col_ptr, const Int* RSTR row_idx, \
            REAL_T* RSTR minus_log, const REAL_T* RSTR rlogscale, REAL_T* RSTR rwork);
    ErrorStatus symmetrize_matching(Int n, Int nnz, const Int* RSTR col_ptr, const Int* RSTR row_idx, Int* RSTR i_mate);
};

struct SBT {
    Int sup_begin, sup_end, parent_task;
    explicit operator Int() const { return sup_begin; }
    bool operator<(const SBT& t) const { return sup_begin < t.sup_begin; }
};

struct TSK {
    Int parent, sup_id, level_id;
};

using trf_subtree_t = SBT;
using trf_task_t = TSK;
using matrix_symmetrizer_t = SYM;

EXTERN ErrorStatus swSparse_trf_static_schedule(LUSup* lusup);
#define trf_static_schedule(arg_)  swSparse_trf_static_schedule(arg_)

/*
 * These routines can be used to:
 *     scaling_factor: calculate the scaling factor for equilibration
 *     scale:          calculate the equlibrated matrix
 *     norm_1:         calculate 1-norm 
 *     check_diagnal:  check if there are structural zeros on the diagnal
 * for better data locality, multiple targets are completed in one traversal
 */

enum preprocess_status_t {
	STATUS_GOOD, STATUS_ZERO_DIAG /* recoverable */, STATUS_SINGULAR /* not recoverable */
};

// return norm1
template<typename DATA_T>
real_t<DATA_T> mc64_preprocess(Int n, Int nnz, const Int* RSTR offsets, const DATA_T* x, real_t<DATA_T>* y, real_t<DATA_T>* col_max);
template<typename DATA_T>
real_t<DATA_T> norm_1_sparse_scale(Int n, Int nnz, const Int* RSTR offsets, const Int* RSTR indices, \
    const DATA_T* RSTR src, DATA_T* RSTR dst, const real_t<DATA_T>* RSTR rscale, const real_t<DATA_T>* RSTR cscale);
template<typename DATA_T>
real_t<DATA_T> norm_1_sparse_rescale_colmax(Int n, Int nnz, const Int* RSTR offsets, const Int* RSTR indices, \
    const DATA_T* RSTR src, DATA_T* RSTR dst, const real_t<DATA_T>* RSTR rscale, real_t<DATA_T>* RSTR cscale);

#define scaling_factor_check_diagonal(a_,b_,c_,d_,e_,f_,g_,h_)  scale_alternate_direction(a_,b_,c_,d_,e_,f_,g_,h_)
//#define scaling_factor_check_diagonal(a_,b_,c_,d_,e_,f_,g_,h_)  scale_symmetric(a_,b_,c_,d_,e_,f_,g_,h_)

//   find the scaling factor for equlibration, from alternating directions: column -> row -> column -> row -> ...
// NOTE: this routine is only called when [MC64 is disabled] OR when [refact on the same pattern]
template<typename DATA_T>
preprocess_status_t scaling_factor_check_diagonal(Int n, Int nnz, const Int* RSTR offsets, const Int* RSTR indices, \
    const DATA_T* RSTR values, real_t<DATA_T>* RSTR rscale, real_t<DATA_T>* RSTR cscale, real_t<DATA_T>* RSTR rwork);

template<typename DATA_T>
preprocess_status_t norm_1_check_diagonal(Int n, Int nnz, const Int* RSTR offsets, const Int* RSTR indices, \
					const DATA_T* RSTR values, real_t<DATA_T> *norm_1_ptr);

template<typename REAL_T>
void ewise_exp(Int n, REAL_T* RSTR x, REAL_T* RSTR y);
template<typename DATA_T>
void ewise_mul(Int n, const DATA_T* y, DATA_T* z, const real_t<DATA_T>* x);

namespace PT {  // for perturbation

template<typename REAL_T>
INLINE REAL_T reciprocal(REAL_T x) {  // can we use `frecpd`?
    return REAL_T(1) / x;
}

template<typename REAL_T>
struct precision;
template<> struct precision<float> {
    constexpr static const float epsilon = 0x1p-23f;
    constexpr static const float sqrt_epsilon = 0x1.6a09e6p-12f;
};
template<> struct precision<double> {
    constexpr static const double epsilon = 0x1p-52;
    constexpr static const double sqrt_epsilon = 0x1p-26;
};


template<typename REAL_T>
inline complex<REAL_T> reciprocal(const complex<REAL_T>& x, REAL_T xabs) {
    // keep the precision, don't use `reciprocal(xabs)`
#if SWSPARSE_COMPLEX_SAFE_NUMERICS > 0
    return (conj(x) / xabs) / xabs;
#else
    return conj(x) / (xabs * xabs);
#endif
}

// scales `x` to the `target_magnitude` and returns its reciprocal
// returns 1 / (target_magnitude * (x / xabs)), i.e. (conj(x) / xabs) / target_magnitude
template<typename REAL_T>
inline complex<REAL_T> scaled_reciprocal(const complex<REAL_T>& x, REAL_T xabs, REAL_T rcp_magnitude) {
    // used in perturbation, the precision is not important
    REAL_T rabs = reciprocal(xabs);
#if SWSPARSE_COMPLEX_SAFE_NUMERICS > 0
    return (conj(x) * rabs) * rcp_magnitude;
#else
    return conj(x) * (rabs * rcp_magnitude);
#endif
}

template<typename REAL_T>
struct T {  // perturbation on tiny pivots
    REAL_T threshold, replace_value;
    T(REAL_T thres, REAL_T rthres) : threshold(thres), replace_value(rthres) {}

    INLINE bool should_perturb(REAL_T piv_abs) const {
        return piv_abs < threshold;
    }

    INLINE REAL_T value(REAL_T piv) const {
        return copysign(replace_value, piv);
    }

    INLINE complex<REAL_T> value(const complex<REAL_T>& piv, REAL_T piv_abs) const {
        if(piv_abs == 0) {
            return complex<REAL_T>(replace_value);
        } else {
            return scaled_reciprocal(piv, piv_abs, replace_value);
        }
    }
};

template<typename REAL_T>
struct Z {  // perturbation on zero pivots
    REAL_T replace_value;
    Z(REAL_T, REAL_T rthres) : replace_value(rthres) {}

    INLINE bool should_perturb(REAL_T piv_abs) const { return piv_abs == REAL_T(0); }

    INLINE REAL_T value(REAL_T) const {
        return replace_value;
    }

    INLINE complex<REAL_T> value(const complex<REAL_T>&, REAL_T piv_abs) const {
        return complex<REAL_T>(replace_value);
    }
};

template<typename REAL_T, typename PERT_BASE>
class P : protected PERT_BASE {  // perturbation
protected:
    Int perturb_count;
    CHECK_FUNDAMENTAL_TYPE(REAL_T);
public:
    P(REAL_T thres, REAL_T rthres) : perturb_count(0), PERT_BASE(thres, rthres) {}
    INLINE Int count() const { return perturb_count; }

    INLINE REAL_T rcp_pivot(REAL_T piv, REAL_T piv_abs) {
        if(this->should_perturb(piv_abs)) {
            ++perturb_count;
            return this->value(piv);
        }
        return reciprocal(piv);
    }
    INLINE complex<REAL_T> rcp_pivot(const complex<REAL_T>& piv, REAL_T piv_abs) {
        if(this->should_perturb(piv_abs)) {
            ++this->perturb_count;
            return this->value(piv, piv_abs);
        } 
        return reciprocal(piv, piv_abs);
    }
};

class N {  // no perturbation
public:
    template<typename ... ANY_TYPE>
    constexpr N(ANY_TYPE ...) {}
    constexpr Int count() const { return 0; }

    template<typename REAL_T>
    INLINE REAL_T rcp_pivot(REAL_T piv, REAL_T piv_abs) {
        return reciprocal(piv);
    }
    template<typename REAL_T>
    INLINE complex<REAL_T> rcp_pivot(const complex<REAL_T>& piv, REAL_T piv_abs) {
        return reciprocal(piv, piv_abs);
    }
};

} // namespace PT

// export
// 当主元小于阈值时，替换为阈值
template<typename DATA_T>
using perturb_tiny = PT::P<real_t<DATA_T>, PT::T<real_t<DATA_T>>>;
// 当主元等于零时，替换为阈值
template<typename DATA_T>
using perturb_zero = PT::P<real_t<DATA_T>, PT::Z<real_t<DATA_T>>>;
// 不加任何扰动
using no_perturbation = PT::N;

using PT::reciprocal;
template<typename REAL_T>
using precision = PT::precision<REAL_T>;
}

#endif

/* Only used when `LU_PRINT_STATS` is defined */
#define LU_TIMING_MC64    0
#define LU_TIMING_FILL    1
#define LU_TIMING_PRE     2
#define LU_TIMING_REPRE   3
#define LU_TIMING_SYMBOL  4
#define LU_TIMING_NUM_ALL 5
#define LU_TIMING_SIZE    6
EXTERN void swSparse_set_lu_timing(const struct timeval* begin, const struct timeval* end, int index);
EXTERN void swSparse_set_lu_stats(int ntree, int nsuptree, float wtree, int nsupqueue, int nlvltree, float wqueue);
EXTERN void swSparse_print_trf_info();
EXTERN void swSparse_fact_time(double* t);

#endif
