#ifndef SPTRSV_H_INCLUDED
#define SPTRSV_H_INCLUDED 1

#include "internal/rename.h"

#define NEW_DESIGN

#define CACHE_X                   	4096
#define CACHE_X_LOG2                12
#define CONSUMER_CACHE              1024 
#define CONSUMER_CACHE_LOG2         10
#define CONSUMER_BUFFER           	1024 
#define CONSUMER_BUFFER_LOG2      	10
#define PRODUCER_BUFFER           	1024
#define PRODUCER_BUFFER_LOG2      	10 
#define PRODUCER_CACHE_LEVEL        1024 
#define PRODUCER_CACHE_LEVEL_LOG2   10
#define PRODUCER_CACHE_IDX          64 
#define PRODUCER_CACHE_IDX_LOG2     6 
#define PRODUCER_BUFFER_A           512 
#define PRODUCER_BUFFER_A_LOG2      9  
#define MAX_PRODUCERS				32
#define MAX_CONSUMERS				32

#define CACHE_X_2NUM              	(CACHE_X-1)
#define CONSUMER_CACHE_2NUM       	(CONSUMER_CACHE-1)
#define CONSUMER_BUFFER_2NUM   	  	(CONSUMER_BUFFER-1)
#define PRODUCER_BUFFER_2NUM   	  	(PRODUCER_BUFFER-1)
#define PRODUCER_CACHE_LEVEL_2NUM 	(PRODUCER_CACHE_LEVEL-1)
#define PRODUCER_CACHE_IDX_2NUM   	(PRODUCER_CACHE_IDX-1)
#define PRODUCER_BUFFER_A_2NUM    	(PRODUCER_BUFFER_A-1)

#ifdef NEW_DESIGN
//	#define COMM_PART				2
//	#define COMM_PART_LOG2			1
//
//	#define PART_WIDTH				4
//	#define PART_WIDTH_LOG2			2

	#define CORE_COLS				8
	#define CORE_COLS_LOG2			3
	#define CORE_COLS_2NUM			7
	
//	#define MAX_DIAG_BLOCK_PART		5
	#define MAX_COMM_PART			4
#else
	#define DIAG_BLOCK_PART			2
#endif


struct trsv_tune_t {
	Int couples_log2;  //producers = consumers
	Int vector_log2;   //supernode_size
	Int cache_x_log2;
	Int comm_part_log2;
};

#ifdef __cplusplus

template<typename DATA_T>
struct trsv_arg_t {
	DATA_T			alpha;
	DATA_T          *x;
	const DATA_T    *b;
	DATA_T          *aa;
	Int             *ai,   *aj;
	Int             *_idx, *idx[32];// [32][2]
	Int             *level;
	Int             *plevel;
	Int             *cnt[32];// [32][levels][32]
	Int             N, n, levels, plevels; 
	swSparseMatrixStatus status;
	trsv_tune_t     *trsv_tune;
#ifdef SWAPS_TEST
    long long       *pro_swaps[32];
    long long       *con_swaps[32];
#endif
};

#endif

#ifdef SPTRSV_1_0

#ifdef VECTOR                    
#undef VECTOR
#undef VECTOR_LOG2
#undef VECTOR_2NUM
#undef CACHE_X_V4               
#undef CACHE_X_V4_LOG2          
#undef CONSUMER_CACHE           
#undef CONSUMER_CACHE_LOG2      
#undef CONSUMER_BUFFER_V4       
#undef CONSUMER_BUFFER_V4_LOG2  
#undef PRODUCER_BUFFER_V4       
#undef PRODUCER_BUFFER_V4_LOG2  
#undef PRODUCER_CACHE_LEVEL     
#undef PRODUCER_CACHE_LEVEL_LOG2
#undef PRODUCER_CACHE_IDX       
#undef PRODUCER_CACHE_IDX_LOG2  
#undef PRODUCER_BUFFER_A        
#undef PRODUCER_BUFFER_A_LOG2   
#endif

#define PRODUCER_CONSUMER_ROWS      8
#define PRODUCER_CONSUMER_ROWS_LOG2 3
#define PRODUCER_CONSUMER_ROWS_2NUM (PRODUCER_CONSUMER_ROWS-1)
#define CONSUMER_COLS               4
#define CONSUMER_COLS_LOG2          2
#define CONSUMER_COLS_2NUM          (CONSUMER_COLS-1)
#define PRODUCER_COLS               4
#define PRODUCER_COLS_LOG2          2
#define PRODUCER_COLS_2NUM          (PRODUCER_COLS-1)
#define CONSUMER_ROWS               PRODUCER_CONSUMER_ROWS
#define CONSUMER_ROWS_LOG2          PRODUCER_CONSUMER_ROWS_LOG2
#define CONSUMER_ROWS_2NUM          PRODUCER_CONSUMER_ROWS_2NUM
#define PRODUCER_ROWS               PRODUCER_CONSUMER_ROWS
#define PRODUCER_ROWS_LOG2          PRODUCER_CONSUMER_ROWS_LOG2
#define PRODUCER_ROWS_2NUM          PRODUCER_CONSUMER_ROWS_2NUM
#define CONSUMERS                   (CONSUMER_ROWS*CONSUMER_COLS)
#define CONSUMERS_LOG2              (CONSUMER_ROWS_LOG2+CONSUMER_COLS_LOG2)
#define CONSUMERS_2NUM              (CONSUMERS-1)
#define PRODUCERS                   (PRODUCER_ROWS*PRODUCER_COLS)
#define PRODUCERS_LOG2              (PRODUCER_ROWS_LOG2+PRODUCER_COLS_LOG2)
#define PRODUCERS_2NUM              (PRODUCERS-1)

#if defined(DATA_TYPE_S) || defined(DATA_TYPE_D)

#define VECTOR                       4
#define VECTOR_LOG2                  2
#define VECTOR_2NUM                  (VECTOR-1)

#elif defined(DATA_TYPE_C) || defined(DATA_TYPE_Z)

#define VECTOR                       2 
#define VECTOR_LOG2                  1 
#define VECTOR_2NUM                  (VECTOR-1)

#endif

#if defined(DATA_TYPE_S) || defined(DATA_TYPE_D) || defined(DATA_TYPE_C)

#define CACHE_X_V4                   1024
#define CACHE_X_V4_LOG2              10
//#define CACHE_X_V4                   512
//#define CACHE_X_V4_LOG2              9
//#define CACHE_X_V4                   256
//#define CACHE_X_V4_LOG2              8
#define CONSUMER_CACHE               1024 
#define CONSUMER_CACHE_LOG2          10
#define CONSUMER_BUFFER_V4           256 
#define CONSUMER_BUFFER_V4_LOG2      8 
#define PRODUCER_BUFFER_V4           256 
#define PRODUCER_BUFFER_V4_LOG2      8 
//#define CONSUMER_BUFFER_V4           128
//#define CONSUMER_BUFFER_V4_LOG2      7 
//#define PRODUCER_BUFFER_V4           128 
//#define PRODUCER_BUFFER_V4_LOG2      7 
//#define CONSUMER_BUFFER_V4           64
//#define CONSUMER_BUFFER_V4_LOG2      6 
//#define PRODUCER_BUFFER_V4           64 
//#define PRODUCER_BUFFER_V4_LOG2      6 
#define PRODUCER_CACHE_LEVEL         1024 
#define PRODUCER_CACHE_LEVEL_LOG2    10
#define PRODUCER_CACHE_IDX           64 
#define PRODUCER_CACHE_IDX_LOG2      6 
#define PRODUCER_BUFFER_A            512 
#define PRODUCER_BUFFER_A_LOG2       9  

#elif defined(DATA_TYPE_Z)

#define CACHE_X_V4                   512
#define CACHE_X_V4_LOG2              9
#define CONSUMER_CACHE               512
#define CONSUMER_CACHE_LOG2          9 
#define CONSUMER_BUFFER_V4           128
#define CONSUMER_BUFFER_V4_LOG2      7 
#define PRODUCER_BUFFER_V4           128
#define PRODUCER_BUFFER_V4_LOG2      7 
#define PRODUCER_CACHE_LEVEL         512
#define PRODUCER_CACHE_LEVEL_LOG2    9 
#define PRODUCER_CACHE_IDX           32 
#define PRODUCER_CACHE_IDX_LOG2      5 
#define PRODUCER_BUFFER_A            256
#define PRODUCER_BUFFER_A_LOG2       8 

#endif

#define CACHE_X_V4_2NUM           (CACHE_X_V4-1)
#define CACHE_X                   (CACHE_X_V4*VECTOR)
#define CACHE_X_LOG2              (CACHE_X_V4_LOG2+VECTOR_LOG2)
#define CACHE_X_2NUM              (CACHE_X-1)

#define CONSUMER_CACHE_2NUM       (CONSUMER_CACHE-1)
#define CONSUMER_BUFFER_V4_2NUM   (CONSUMER_BUFFER_V4-1)
#define PRODUCER_BUFFER_V4_2NUM   (PRODUCER_BUFFER_V4-1)
#define PRODUCER_CACHE_LEVEL_2NUM (PRODUCER_CACHE_LEVEL-1)
#define PRODUCER_CACHE_IDX_2NUM   (PRODUCER_CACHE_IDX-1)
#define PRODUCER_BUFFER_A_2NUM    (PRODUCER_BUFFER_A-1)

#define MAX_SUB_LEVELS            (PRODUCER_ROWS+1)

#define BIG_BLOCK                 (PRODUCERS*CACHE_X_V4*VECTOR)
#define BIG_BLOCK_LOG2            (PRODUCERS_LOG2+CACHE_X_V4_LOG2+VECTOR_LOG2)
#define BIG_BLOCK_2NUM            (BIG_BLOCK-1)
#define BIG_BLOCK_V4              (PRODUCERS*CACHE_X_V4)
#define BIG_BLOCK_V4_LOG2         (PRODUCERS_LOG2+CACHE_X_V4_LOG2)
#define BIG_BLOCK_V4_2NUM         (BIG_BLOCK_V4-1)

/******************************************** TRSM macro *******************************************/

#define TRSM_CACHE_X_V4                256
#define TRSM_CACHE_X_V4_LOG2           8
#define TRSM_CACHE_X_V4_2NUM           (TRSM_CACHE_X_V4-1)
#define TRSM_CACHE_X                   (TRSM_CACHE_X_V4*VECTOR)
#define TRSM_CACHE_X_LOG2              (TRSM_CACHE_X_V4_LOG2+VECTOR_LOG2)
#define TRSM_CACHE_X_2NUM              (TRSM_CACHE_X-1)

#define TRSM_CONSUMER_BUFFER_V4        64
#define TRSM_CONSUMER_BUFFER_V4_LOG2   6
#define TRSM_CONSUMER_BUFFER_V4_2NUM   (TRSM_CONSUMER_BUFFER_V4-1)

#define TRSM_PRODUCER_BUFFER_V4        64
#define TRSM_PRODUCER_BUFFER_V4_LOG2   6
#define TRSM_PRODUCER_BUFFER_V4_2NUM   (TRSM_PRODUCER_BUFFER_V4-1)

#define TRSM_BIG_BLOCK                 (PRODUCERS*TRSM_CACHE_X_V4*VECTOR)
#define TRSM_BIG_BLOCK_LOG2            (PRODUCERS_LOG2+TRSM_CACHE_X_V4_LOG2+VECTOR_LOG2)
#define TRSM_BIG_BLOCK_2NUM            (TRSM_BIG_BLOCK-1)
#define TRSM_BIG_BLOCK_V4              (PRODUCERS*TRSM_CACHE_X_V4)
#define TRSM_BIG_BLOCK_V4_LOG2         (PRODUCERS_LOG2+TRSM_CACHE_X_V4_LOG2)
#define TRSM_BIG_BLOCK_V4_2NUM         (TRSM_BIG_BLOCK_V4-1)

/**************************************************/

int swSparse_compare_levels(const void*, const void*);

/**************************************************/
#endif

#endif

