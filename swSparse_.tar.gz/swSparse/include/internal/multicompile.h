
#ifdef FUNCNAME
#undef FUNCNAME
#undef SLAVE_FUNCNAME
#undef ATHREAD_SPAWN
#undef DATA_T
#undef REAL_T
#undef TYPENAME_STR
#undef TYPENAME_CHAR
#undef VECTOR_T
#undef VECTOR_LEN
#undef VECTOR
#undef CDATA_T
#undef CONVERT_VALUE
#undef CONVERT_POINTER
#undef CONVERT_CPOINTER
#undef VECTOR_LOG2
#undef VECTOR_2NUM
#endif
#ifdef ELEMENT_TYPE
#undef ELEMENT_TYPE
#undef SABS
#undef ZERO
#undef ONE
#endif
#ifdef TYPENAME
#undef TYPENAME
#endif

#ifndef SWSPARSE_STRING_CONSTANTS
#define SWSPARSE_STRING_CONSTANTS
extern const char swSparse_cstr_float[14];
extern const char swSparse_cstr_double[15];
#endif

#if defined(DATA_TYPE_S)
#define FUNCNAME(name) swSparse_s_##name
#define SLAVE_FUNCNAME(name) slave_swSparse_s_##name
#define ATHREAD_SPAWN(name, args) __real_athread_spawn(slave_swSparse_s_##name, args, 1)
#define TYPENAME(name) name##_s
#define DATA_T float
#define REAL_T float
#define CDATA_T float
#define CONVERT_VALUE(x, y)    float x = y;
#define CONVERT_POINTER(x, y)  float *x = y;
#define CONVERT_CPOINTER(x, y) const float *x = y;
#define VECTOR_T floatv8
#define VECTOR_LEN 8
#define ELEMENT_TYPE REAL_SINGLE
#define SABS(x) ((x) * (x))
#define ZERO 0.0f
#define ONE 1.0f
#define TYPENAME_STR &swSparse_cstr_float[8]
#define TYPENAME_CHAR 's'

#define VECTOR                    8
#define VECTOR_LOG2               3
#define VECTOR_2NUM               (VECTOR-1)

#elif defined(DATA_TYPE_D)
#define FUNCNAME(name) swSparse_d_##name
#define SLAVE_FUNCNAME(name) slave_swSparse_d_##name
#define ATHREAD_SPAWN(name, args) __real_athread_spawn(slave_swSparse_d_##name, args, 1)
#define TYPENAME(name) name##_d
#define DATA_T double
#define REAL_T double
#define CDATA_T  double
#define CONVERT_VALUE(x, y)    double x = y;
#define CONVERT_POINTER(x, y)  double *x = y;
#define CONVERT_CPOINTER(x, y) const double *x = y;
#define VECTOR_T doublev8
#define VECTOR_LEN 8
#define ELEMENT_TYPE REAL_DOUBLE
#define SABS(x) ((x) * (x))
#define ZERO 0.0
#define ONE 1.0
#define TYPENAME_STR &swSparse_cstr_double[8]
#define TYPENAME_CHAR 'd'

#define VECTOR                    8
#define VECTOR_LOG2               3
#define VECTOR_2NUM               (VECTOR-1)

#elif defined(DATA_TYPE_C)
#define FUNCNAME(name) swSparse_c_##name
#define SLAVE_FUNCNAME(name) slave_swSparse_c_##name
#define ATHREAD_SPAWN(name, args) __real_athread_spawn(slave_swSparse_c_##name, args, 1)
#define TYPENAME(name) name##_c
#define DATA_T swSparseSComplex
#define REAL_T float
#define CDATA_T float complex
#define CONVERT_VALUE(x, y)    float complex x = CMPLXF(y.real, y.imag);
#define CONVERT_POINTER(x, y)  float complex *x = (float complex*)y;
#define CONVERT_CPOINTER(x, y) const float complex *x = (const float complex*)y;
#define ELEMENT_TYPE COMPLEX_SINGLE
#define SABS(x) ((x) * conjf(x))
#define ZERO 0.0f
#define ONE 1.0f
#define TYPENAME_STR &swSparse_cstr_float[0]
#define TYPENAME_CHAR 'c'

#define VECTOR                    4
#define VECTOR_LOG2               2
#define VECTOR_2NUM               (VECTOR-1)

#elif defined(DATA_TYPE_Z)
#define FUNCNAME(name) swSparse_z_##name
#define SLAVE_FUNCNAME(name) slave_swSparse_z_##name
#define ATHREAD_SPAWN(name, args) __real_athread_spawn(slave_swSparse_z_##name, args, 1)
#define TYPENAME(name) name##_z
#define DATA_T swSparseDComplex
#define REAL_T double
#define CDATA_T double complex
#define CONVERT_VALUE(x, y)    double complex x = CMPLX(y.real, y.imag);
#define CONVERT_POINTER(x, y)  double complex *x = (double complex*)y;
#define CONVERT_CPOINTER(x, y) const double complex *x = (const double complex*)y;
#define ELEMENT_TYPE COMPLEX_DOUBLE
#define SABS(x) ((x) * conj(x))
#define ZERO 0.0
#define ONE 1.0
#define TYPENAME_STR &swSparse_cstr_double[0]
#define TYPENAME_CHAR 'z'

#define VECTOR                    4
#define VECTOR_LOG2               2
#define VECTOR_2NUM               (VECTOR-1)

#elif defined(DATA_TYPE_I)
#define FUNCNAME(name) swSparse_i_##name
#define SLAVE_FUNCNAME(name) slave_swSparse_i_##name
#define ATHREAD_SPAWN(name, args) __real_athread_spawn(slave_swSparse_i_##name, args, 1)
#define TYPENAME(name) name##_i
#define DATA_T Int
#define REAL_T Int
#define VECTOR_T intv16
#define VECTOR_LEN 16

#elif defined(DATA_TYPE_L)
#include <stdint.h>
#define FUNCNAME(name) swSparse_l_##name
#define SLAVE_FUNCNAME(name) slave_swSparse_l_##name
#define ATHREAD_SPAWN(name, args) __real_athread_spawn(slave_swSparse_l_##name, args, 1)
#define TYPENAME(name) name##_l
#define DATA_T int64_t
#define REAL_T int64_t
#define VECTOR_T int512
#define VECTOR_LEN 8

#elif defined(DATA_TYPE_NULL)
#define FUNCNAME(name) swSparse_n_##name
#define SLAVE_FUNCNAME(name) slave_swSparse_n_##name
#define ATHREAD_SPAWN(name, args) __real_athread_spawn(slave_swSparse_n_##name, args, 1)
#define TYPENAME(name) name##_n
#define DATA_T void
#define REAL_T void
#define VECTOR_T void

#endif
