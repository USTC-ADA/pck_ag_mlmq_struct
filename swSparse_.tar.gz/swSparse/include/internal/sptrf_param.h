#ifndef SPTRF_PARAM
#define SPTRF_PARAM 1
#ifdef __cplusplus

#include "internal/templates.h"
#include "internal/sptrf_common.h"

//#define LU_CPE_PROFILE 1
#ifdef LU_CPE_PROFILE
#define DECLARE_TIMER unsigned long timer1, timer2, timer3, timer4;
#define TIMER_SET(tvar) tvar = CRTS_stime_cycle();
#define TIMER_GET(tt, t1, t2) tt += t2 - t1;
#else
#define DECLARE_TIMER
#define TIMER_SET(t_)
#define TIMER_GET(x_, y_, z_)
#endif

namespace swSparse {

inline constexpr Int scheduler_id              = 27;
inline constexpr Int cpe_for_subtree           = 64;
inline constexpr uint8_t options_perturb_zero  = 0x1;
inline constexpr uint8_t options_perturb_tiny  = 0x3;
inline constexpr uint8_t options_conj          = 0xC0;

// 子树排序的从核参数
struct sort_subtrees_arg_t {
    const Int* subtree_offsets;
    trf_subtree_t* subtrees;
    trf_subtree_t* temp;
};

// LU分解的从核参数
template<typename DATA_T>
struct sptrf_arg_t {
    const Int* a_col_off;
    const Int* a_row_idx;
    const DATA_T* a_val;
    const Int* sup2col;
    const Int* col2sup;
    const Int* l_i_off;
    const Int* l_v_off;
    Int* l_row_idx;  // not const, may be permuted
    DATA_T* l_val;
    const Int* u_col_off;
    const Int* u_seg_off;
    const Int* u_seg_idx;
    DATA_T* u_val;
#ifdef SWSPARSE_LU_USE_SPA
    DATA_T* spa;
#endif
    Int* ipiv;   // output as riperm
    const Int* subtree_offsets;
    const trf_subtree_t* subtrees;
    const Int* snode_status;
    const trf_task_t* task_queue;
    real_t<DATA_T> perturb_threshold, rcp_thres;
#ifdef SWSPARSE_LU_USE_SPA
    Int spa_cols;
#endif
    Int n, nsuper, task_queue_size;
    uint8_t options;  // perturb, diag, conj
    Int numstats[2];  // output argument
};

// 程序中的固定参数，用于稠密块计算中选择分块大小
template<size_t element_size>
struct sptrf_params;

template<>
struct sptrf_params<4> {
    /*
     32    16    32    32
    512   512   256   128
     16    32    64   128
     */
    inline static constexpr Int max_sup_size = 63*8*4;
    inline static constexpr Int val_size = 26624;
    inline static constexpr Int idx_size = 512;
    INLINE static void select_update_block_size(Int segsize, Int nseg, Int& update_block_col, Int& update_block_row, Int& left_ld, Int& right_ld) {
        if(segsize > 64) {
            update_block_col = 128;
            update_block_row = 128;
            left_ld = 128;
            right_ld = 256;
        } else if(nseg <= 16) {
            if(segsize <= 32) {
                update_block_col = 32;
                update_block_row = 512;
                left_ld = right_ld = 544;
            } else {
                update_block_col = 64;
                update_block_row = 256;
                left_ld = 256;
                right_ld = 320;
            }
        } else {
            if(segsize <= 16) {
                update_block_col = 16;
                update_block_row = 528;
                left_ld = right_ld = 544;
            } else {
                update_block_col = 64;
                update_block_row = 256;
                left_ld = 256;
                right_ld = 320;
            }
        }
    }
    INLINE static void select_panel_size(Int sup_size, Int group_size, 
        Int& fact_panel_size, Int& fact_block_row, Int& trsm_block_row, Int& left_ld, Int& right_ld) {
        if ( sup_size <= 8 * group_size || sup_size > 1104) {
            fact_panel_size = 8;
            fact_block_row = trsm_block_row = 2208;
            left_ld = 1104;
            right_ld = 2216;
        } else if ( sup_size <= 16 * group_size || sup_size > 544 ) {
            fact_panel_size = 16;
            trsm_block_row  = 1088;
            fact_block_row = left_ld = right_ld = 1104;
        } else {
            fact_panel_size = 32;
            trsm_block_row  = 512;
            fact_block_row = left_ld = right_ld = 544;
        } 
        static_assert(2216 * 8 + 1104 * 8 <= val_size);
        static_assert(1104 * (16 + 8) <= val_size);
        static_assert(544 * (32 + 16) <= val_size);
    }
};

template<>
struct sptrf_params<8> {
    /*
     32    16    32
    256   256   128
     16    32    64
     */
    inline static constexpr Int max_sup_size = 63*8*2;
    inline static constexpr Int val_size = 14336;
    inline static constexpr Int idx_size = 512;
    INLINE static void select_update_block_size(Int segsize, Int nseg, Int& update_block_col, Int& update_block_row, Int& left_ld, Int& right_ld) {
        if(nseg <= 16) {
            if(segsize <= 32) {
                update_block_col = 32;
                update_block_row = 256;
                left_ld = right_ld = 288;
            } else {
                update_block_col = 64;
                update_block_row = 128;
                left_ld = 128;
                right_ld = 192;
            }
        } else {
            if(segsize <= 16) {
                update_block_col = 16;
                update_block_row = 272;
                left_ld = right_ld = 288;
            } else {
                update_block_col = 64;
                update_block_row = 128;
                left_ld = 128;
                right_ld = 192;
            }
        }
    }
    INLINE static void select_panel_size(Int sup_size, Int group_size, 
        Int& fact_panel_size, Int& fact_block_row, Int& trsm_block_row, Int& left_ld, Int& right_ld) {
        if ( sup_size <= 8 * group_size || sup_size > 592) {
            fact_panel_size = 8;
            fact_block_row = trsm_block_row  = 1152;
            left_ld = 576;
            right_ld = 1160;
        } else if ( sup_size <= 16 * group_size || sup_size > 288 ) {
            fact_panel_size = 16;
            trsm_block_row  = 576;
            fact_block_row = left_ld = right_ld = 592;
        } else {
            fact_panel_size = 32;
            trsm_block_row  = 256;
            fact_block_row = left_ld = right_ld = 288;
        } 
        static_assert(1160 * 8 + 576 * 8 <= val_size);
        static_assert(592 * (16 + 8) <= val_size);
        static_assert(288 * (32 + 16) <= val_size);
    }
};

template<>
struct sptrf_params<16> {
    /*
     32    16    32    16
    128   128    64    64
     16    32    32    64
     */
    inline static constexpr Int max_sup_size = 63*8;
    inline static constexpr Int val_size = 7168;
    inline static constexpr Int idx_size = 256;
    INLINE static void select_update_block_size(Int segsize, Int nseg, Int& update_block_col, Int& update_block_row, Int& left_ld, Int& right_ld) {
        if(nseg <= 16) {
            if(segsize <= 32) {
                update_block_col = 32;
                update_block_row = 128;
                left_ld = 128;
                right_ld = 160;
            } else {
                update_block_col = 64;
                update_block_row = 64;
                left_ld = 64;
                right_ld = 128;
            }
        } else {
            if(segsize <= 16) {
                update_block_col = 16;
                update_block_row = 128;
                left_ld = 128;
                right_ld = 160;
            } else {
                update_block_col = 32;
                update_block_row = 64;
                left_ld = 64;
                right_ld = 128;
            }
        }
    }
    
    INLINE static void select_panel_size(Int sup_size, Int group_size, 
        Int& fact_panel_size, Int& fact_block_row, Int& trsm_block_row, Int& left_ld, Int& right_ld) {
        if ( sup_size <= 8 * group_size || sup_size > 288 ) {
            fact_panel_size = 8;
            fact_block_row = trsm_block_row = 576;
            left_ld = 288;
            right_ld = 584;
        } else if ( sup_size <= 16 * group_size || sup_size > 144 ) {
            fact_panel_size = 16;
            trsm_block_row  = 272;
            fact_block_row = left_ld = right_ld = 288;
        } else {
            fact_panel_size = 32;
            trsm_block_row  = 112;
            fact_block_row = left_ld = right_ld = 144;
        } 
        static_assert(584 * 8 + 288 * 8 <= val_size);
        static_assert(288 * (16 + 8) <= val_size);
        static_assert(144 * (32 + 16) <= val_size);
    }
};

inline constexpr Int segment_block_size = 32;
inline constexpr Int block_cycle_shift = 3;
inline constexpr Int block_cycle_size = 1 << block_cycle_shift;
inline constexpr Int block_cycle_mask = block_cycle_size - 1;
inline constexpr Int update_panel_shift = 7;
inline constexpr Int update_panel_size = 1 << update_panel_shift;
inline constexpr Int update_panel_mask = update_panel_size - 1;
inline constexpr Int update_panel_ncycles = update_panel_size >> block_cycle_shift;
template<size_t elem_size>
inline constexpr Int max_sup_size = sptrf_params<elem_size>::max_sup_size;  // ensure pivoting on LDM
template<typename DATA_T>
inline constexpr Int trf_idx_size = sptrf_params<sizeof(DATA_T)>::idx_size;
template<typename DATA_T>
inline constexpr Int trf_val_size = sptrf_params<sizeof(DATA_T)>::val_size;

INLINE Int block_cyclic_local_to_global(Int i, Int group_size) {
    Int x = i & (~block_cycle_mask);
    Int y = i & block_cycle_mask;
    return (x * group_size) | y;
}

}

#endif
#endif
