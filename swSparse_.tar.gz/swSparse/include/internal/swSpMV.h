#ifndef SWSPMV_H_INCLUDED
#define SWSPMV_H_INCLUDED 1


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "internal/multicompile.h"
#include "rename.h"
#include "swSparse_types.h"

#define ROW_IDX_DIGITS 16
#define COL_IDX_DIGITS 16
#define ELEMENT_SIZE 32
#define ROW_IDX_DIGITS 16
#define COL_IDX_DIGITS 16
#define COL_IDX_MASK 65535



#endif
