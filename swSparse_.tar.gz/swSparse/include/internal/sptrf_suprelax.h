#ifndef SPTRF_SUPRELAX_H_INCLUDED
#define SPTRF_SUPRELAX_H_INCLUDED 1

#include <stdint.h>
#include "swSparse.h"
#include "internal/rename.h" 
#include "internal/sptrf_common.h" 

#define SUP_REP(j, part_super)             ((part_super[j] >= 0) ? (j) : ((j) + part_super[j]))
#define SUP_END(rep, part_super)           ((rep) + part_super[rep])
#define SUP_SIZE_RAW(j, krep, part_super)  min(part_super[krep], (j) + 1 - (krep));

#define IF_ACCEPT_RELAX_LEAF(nchild_) if(nchild_ > 1)  // only accept branch nodes
//#define IF_ACCEPT_RELAX_LEAF(nchild_)  // alway accept

#define RELAX_SIZE_0   8
#define RELAX_SIZE_1   16
#define RELAX_SIZE_2   48
#define RELAX_SIZE_3   160
#define RELAX_SIZE_4   504
#define CHECK_RELAX_1  relax_ratio<2,3>
#define CHECK_RELAX_2  relax_ratio<1,7>
#define CHECK_RELAX_3  relax_ratio<1,13>
#define CHECK_RELAX_4  relax_ratio_chain<1,20>  // only merge chains

#ifdef __cplusplus
template<Int cnum, Int cden>
inline Bool relax_ratio(Int num, Int den, col_status_t not_branching_point) {
    return num * cden < cnum * den;
}

template<Int cnum, Int cden>
inline Bool relax_ratio_chain(Int num, Int den, col_status_t not_branching_point) {
    return (not_branching_point >= 0) && (num * cden < cnum * den);
}

inline Bool should_merge(Int ncolumns, Int nvalues, Int nzeros, col_status_t not_branching_point) {
    if (ncolumns <= RELAX_SIZE_2) {
        if(ncolumns <= RELAX_SIZE_1) {
            return ncolumns <= RELAX_SIZE_0 || CHECK_RELAX_1(nzeros, nvalues, not_branching_point);
        } else {
            return CHECK_RELAX_2(nzeros, nvalues, not_branching_point);
        }
    } else if (ncolumns <= RELAX_SIZE_3) {
        return CHECK_RELAX_3(nzeros, nvalues, not_branching_point);
    } else {
        return (ncolumns <= RELAX_SIZE_4 && CHECK_RELAX_4(nzeros, nvalues, not_branching_point));
    }
}

#endif
#endif