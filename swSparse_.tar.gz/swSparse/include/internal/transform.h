#ifndef TRANSFORM_H_INCLUDED
#define TRANSFORM_H_INCLUDED 1

#include "swSparse_base.h"
#include "internal/rename.h"

#ifdef __cplusplus
namespace swSparse {

template<typename DATA_T>
ErrorStatus transpose_csr(Int m, Int n, Int nnz, \
               const Int * a_row_offsets, const Int * a_column_indices, const DATA_T * a_values, \
               Int * at_row_offsets, Int * at_column_indices, DATA_T * at_values);

template<typename DATA_T>
ErrorStatus convert_coo2csr(Int m, Int n, Int nnz, \
               const Int *row_indices, const Int *coo_column_indices, const DATA_T *coo_values, \
               Int *row_offsets, Int *csr_column_indices, DATA_T *csr_values);

void convert_csr2coo(Int m, Int *row_offsets, Int *row_indices);

template<typename DATA_T>
ErrorStatus transpose_csr_x(Int m, Int n, MatrixCSRC *a, MatrixCSRC *at);

}
#endif

typedef struct{
	int* idx;
	const int* offset;
	int m;
	int nnz;
} off2idx_arg_t;

typedef struct{
	const int* idx;
	int* offset;
	int m;
	int nnz;
} idx2off_arg_t;

#endif
