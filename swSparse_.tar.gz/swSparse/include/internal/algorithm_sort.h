#ifndef ALGORITHM_SORT_H_INCLUDED
#define ALGORITHM_SORT_H_INCLUDED 1

// C++ template functions, header only

#ifdef __cplusplus
#include "internal/rename.h"
#include "internal/utils.h"
#include "internal/templates.h"
#include "internal/debug.h"
#include "internal/algorithm.h"

namespace swSparse {
// sequential radix sort, top-down, non-recursive
// duplicated entry is not allowed

template<typename DATA_T>
static void insert_sort(Int *RSTR ri, DATA_T *RSTR v, Int begin, Int end, Int recover) NOTHROW {
    Int i, j;
    if(end > begin) {
        ri[begin] += recover;
        for(i = begin + 1; i < end; ++i) {
            Int pr = ri[i] + recover;
            DATA_T pd = v[i];
            for(j = i - 1; j >= begin && pr < ri[j]; --j) {
                ri[j+1] = ri[j];
                v[j+1] = v[j];
            }
            ri[j+1] = pr;
            v[j+1] = pd;
        }
    }
}

inline bool index_less(Int xr, Int xc, Int yr, Int yc) {
    return (xr < yr) || ((xr == yr) && (xc < yc));
}

template<typename DATA_T>
static void insert_sort(Int *RSTR ri, Int* RSTR ci, DATA_T *RSTR v, Int begin, Int end, Int rr, Int rc) NOTHROW {
    Int i, j;
    if(end > begin) {
        ri[begin] += rr;
        ci[begin] += rc;
        for(i = begin + 1; i < end; ++i) {
            Int pr = ri[i] + rr;
            Int pc = ci[i] + rc;
            DATA_T pd = v[i];
            for(j = i - 1; j >= begin && (index_less(pr, pc, ri[j], ci[j])); --j) {
                ri[j+1] = ri[j];
                ci[j+1] = ci[j];
                v[j+1] = v[j];
            }
            ri[j+1] = pr;
            ci[j+1] = pc;
            v[j+1] = pd;
        }
    }
}

template<Int radix, typename Bit, typename Preprocess>
static void count_radix(Int* RSTR ri, Int begin, Int end, Int* count, Int* cursor, \
        Bit bit, Preprocess preprocess) NOTHROW {
    for(Int i = begin; i < end; ++i) {
        preprocess(ri[i]);
        ++count[bit(ri[i])];
    }
    for(Int prefix = begin, i = 0; i < radix; ++i) {
        Int temp = prefix;
        prefix += count[i];
        count[i] = temp;
        cursor[i] = temp;
    }
    count[radix] = end;
}

template<Int radix, typename Bit, typename Preprocess>
static void count_radix(Int* RSTR ri, Int* RSTR ci, Int begin, Int end, Int* count, Int* cursor, \
        Bit bit, Preprocess preprocess) NOTHROW {
    for(Int i = begin; i < end; ++i) {
        preprocess(ri[i], ci[i]);
        ++count[bit(ri[i], ci[i])];
    }
    for(Int prefix = begin, i = 0; i < radix; ++i) {
        Int temp = prefix;
        prefix += count[i];
        count[i] = temp;
        cursor[i] = temp;
    }
    count[radix] = end;
}

template<Int radix, typename DATA_T, typename Bit>
static void partition_radix(Int* RSTR ri, DATA_T *RSTR v, Int begin, Int end, Int* partition, Int* cursor, \
        Bit bit) NOTHROW {
    Int i, k, bin_i, current;
    for(current = 0; cursor[current] == partition[current + 1]; ++ current);

    for(i = cursor[current], bin_i = bit(ri[i]); ; bin_i = bit(ri[i])) {
        Int reg_ri = ri[i];
        DATA_T reg_v = v[i];
        while(bin_i != current) {
            Int bin_k;
            Int temp_ri = reg_ri;
            DATA_T temp_v = reg_v;
            for(k = cursor[bin_i], bin_k = bit(ri[k]); bin_k == bin_i; ++k, bin_k = bit(ri[k]));
            reg_ri = ri[k];
            reg_v = v[k];
            cursor[bin_i] = k + 1;
            bin_i = bin_k;
            ri[k] = temp_ri;
            v[k] = temp_v;
        } 
        ri[i] = reg_ri;
        v[i] = reg_v;
        for(++cursor[current]; (current < radix) && (cursor[current] == partition[current + 1]); ++ current);
        if(current >= radix) {
            break;
        }
        i = cursor[current];
    }
}

// In-place partition of multiple bins
template<Int radix, typename DATA_T, typename Bit>
static void partition_radix(Int* RSTR ri, Int* RSTR ci, DATA_T *RSTR v, Int begin, Int end, \
        Int* partition, Int* cursor, Bit bit) NOTHROW {
    Int i, k, bin_i, current;
    for(current = 0; cursor[current] == partition[current + 1]; ++ current);

    for(i = cursor[current], bin_i = bit(ri[i], ci[i]); ; bin_i = bit(ri[i], ci[i])) {
        Int reg_ri = ri[i];
        Int reg_ci = ci[i];
        DATA_T reg_v = v[i];
        while(bin_i != current) {
            Int bin_k;
            Int temp_ri = reg_ri;
            Int temp_ci = reg_ci;
            DATA_T temp_v = reg_v;
            for(k = cursor[bin_i], bin_k = bit(ri[k], ci[k]); bin_k == bin_i; ++k, bin_k = bit(ri[k], ci[k]));
            reg_ri = ri[k];
            reg_ci = ci[k];
            reg_v = v[k];
            cursor[bin_i] = k + 1;
            bin_i = bin_k;
            ri[k] = temp_ri;
            ci[k] = temp_ci;
            v[k] = temp_v;
        } 
        ri[i] = reg_ri;
        ci[i] = reg_ci;
        v[i] = reg_v;
        for(++cursor[current]; (current < radix) && (cursor[current] == partition[current + 1]); ++ current);
        if(current >= radix) {
            break;
        }
        i = cursor[current];
    }
}

template<Int mask>
class Bit1 {
    Int shift;
public:
    Bit1(Int s) : shift(s) {}
    Int operator()(Int x) const { return (x >> shift) & mask; }
    template<typename Any>
    Int operator()(Int x, const Any&) const { return (x >> shift) & mask; }
};

template<Int mask>
class BitMix{
    Int shift, ynbits;
public:
    BitMix(Int s, Int y) : shift(s), ynbits(y) {}
    Int operator()(Int x, Int y) const { return ((x << (ynbits - shift)) | (y >> shift)) & mask; }
};

template<Int radix>
struct stack_element_t {
    Int seg[radix + 1];
    Int shift, which;
};

// radix-16 sort on (indices, values)
template<typename DATA_T>
static void sort_index_value(Int *RSTR idx, DATA_T *RSTR val, Int n) NOTHROW {
    constexpr const Int radix_bits = 4, radix = 1 << radix_bits, radix_1 = radix - 1, stack_size = 31 / radix_bits + 2;
    using Bit = Bit1<radix_1>;
    if(n > 1) {
        stack_element_t<radix> stack[stack_size];
        Int cursor[radix];
        Int top, shift, nbits, u = idx[0], l = idx[0];
        
        /* shrink range */
        for(Int i = 1; i < n; ++i) {
            l = min(l, idx[i]);
            u = max(u, idx[i]);
        }

        auto substract = [=](Int& x) { x -= l; };
        auto nop       = [ ](Int   ) { };

        nbits = num_bits(u - l);
        shift = max(0, nbits - radix_bits);
        memset(stack[0].seg, 0, sizeof(Int) * (radix + 1));
        count_radix<radix>(idx, 0, n, stack[0].seg, cursor, Bit(shift), substract);
        partition_radix<radix>(idx, val, 0, n, stack[0].seg, cursor, Bit(shift));

        stack[0].shift = shift;
        stack[0].which = 0;

        for(top = 0; ; ) {
            Int which = stack[top].which++;
            Int begin = stack[top].seg[which], end = stack[top].seg[which+1], size = end - begin;
            shift = stack[top].shift;
            ASSERT_LESS(which, radix);
            ASSERT(top >= 0);
            if(size > radix) {
                // if no duplicated entry, then shift >= 0
                Int new_shift = max(0, shift - radix_bits);
                memset(stack[++top].seg, 0, sizeof(Int) * (radix + 1));
                count_radix<radix>(idx, begin, end, stack[top].seg, cursor, Bit(new_shift), nop);
                partition_radix<radix>(idx, val, begin, end, stack[top].seg, cursor, Bit(new_shift));
                stack[top].shift = new_shift;
                stack[top].which = 0;
            } else {
                insert_sort(idx, val, begin, end, l);
                which = stack[top].which;
                while(which == radix && top > 0) {
                    which = stack[--top].which;
                }
                if(which == radix) {
                    break;
                }
            }
        }
    }
}

// radix-16 sort on (row_indices, column_indices, values)
template<typename DATA_T>
static void sort_index_value(Int *RSTR ridx, Int *RSTR cidx, DATA_T *RSTR val, Int n) NOTHROW {
    constexpr const Int radix_bits = 4, radix = 1 << radix_bits, radix_1 = radix - 1, stack_size = 63 / radix_bits + 2;
    using BitR = Bit1<radix_1>;
    using BitRC = BitMix<radix_1>;
    if(n > 1) {
        stack_element_t<radix> stack[stack_size];
        Int cursor[radix];
        Int top, shift, nbits, cnbits, t, ur = ridx[0], lr = ridx[0], uc = cidx[0], lc = cidx[0];
        
        /* shrink range */
        for(Int i = 1; i < n; ++i) {
            lr = min(lr, ridx[i]);
            ur = max(ur, ridx[i]);
            lc = min(lc, cidx[i]);
            uc = max(uc, cidx[i]);
        }

        auto substract = [=](Int& x, Int& y) { x -= lr; y -= lc; };
        auto recover   = [=](Int& x, Int& y) { x += lr; y += lc; };
        auto nop       = [ ](Int   , Int   ) { };

        cnbits = num_bits(uc - lc);
        nbits = num_bits(ur - lr) + cnbits;
        shift = max(0, nbits - radix_bits);
        t = cnbits - radix_bits;
        memset(stack[0].seg, 0, sizeof(Int) * (radix + 1));
        if(shift >= cnbits) {
            count_radix<radix>(ridx, cidx, 0, n, stack[0].seg, cursor, BitR(shift - cnbits), substract);
            partition_radix<radix>(ridx, cidx, val, 0, n, stack[0].seg, cursor, BitR(shift - cnbits));
        } else {
            count_radix<radix>(ridx, cidx, 0, n, stack[0].seg, cursor, BitRC(shift, cnbits), substract);
            partition_radix<radix>(ridx, cidx, val, 0, n, stack[0].seg, cursor, BitRC(shift, cnbits));
        }
        
        stack[0].shift = max(0, shift - radix_bits);
        stack[0].which = 0;

        for(top = 0; ; ) {
            Int which = stack[top].which++;
            Int begin = stack[top].seg[which], end = stack[top].seg[which+1], size = end - begin;
            shift = stack[top].shift;
            if(size > radix) {
                memset(stack[++top].seg, 0, sizeof(Int) * (radix + 1));
                if(shift >= cnbits) {
                    count_radix<radix>(ridx, cidx, begin, end, stack[top].seg, cursor, BitR(shift - cnbits), nop);
                    partition_radix<radix>(ridx, cidx, val, begin, end, stack[top].seg, cursor, BitR(shift - cnbits));
                } else if(shift > t) {
                    count_radix<radix>(ridx, cidx, begin, end, stack[top].seg, cursor, BitRC(shift, cnbits), nop);
                    partition_radix<radix>(ridx, cidx, val, begin, end, stack[top].seg, cursor, BitRC(shift, cnbits));
                } else {
                    // sort according to column-indices
                    count_radix<radix>(cidx, ridx, begin, end, stack[top].seg, cursor, BitR(shift), nop);
                    partition_radix<radix>(cidx, ridx, val, begin, end, stack[top].seg, cursor, BitR(shift));
                }
                stack[top].shift = max(0, shift - radix_bits);
                stack[top].which = 0;
            } else {
                insert_sort(ridx, cidx, val, begin, end, lr, lc);
                which = stack[top].which;
                while(which == radix && top > 0) {
                    which = stack[--top].which;
                }
                if(which == radix) {
                    break;
                }
            }
        }
    }
}

void sort_int(Int *a, Int n);

}

#endif
#endif