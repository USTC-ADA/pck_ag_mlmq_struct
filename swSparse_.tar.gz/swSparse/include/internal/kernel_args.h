#ifndef KERNELS_H_INCLUDED
#define KERNELS_H_INCLUDED 1

// 主核上将从核函数的参数打包成结构体传递给从核
// The MPE-CPE interface of some common CPE kernels

#include <stddef.h>
#include "swSparse_base.h"
#include "internal/rename.h"

typedef struct MEMSET_ARGS {
    void *dst;
    int value;
    size_t size;
} memset_arg_t;

typedef struct MEMCPY_ARGS {
    void *dst;
    const void *src;
    size_t size;
} memcpy_arg_t;

typedef memcpy_arg_t memmove_arg_t;

#ifdef __cplusplus

#include "internal/templates.h"

template<typename DATA_T, typename RS, typename CS>
struct SSARGS {
    real_t<DATA_T> norm_1;
    const Int *offsets;
    const Int *indices;
    const DATA_T *src;
    DATA_T *dst;
    RS rscale;
    CS cscale;
    Int n, nnz;
};

template<typename DATA_T>
using sparse_rescale_colmax_arg_t = SSARGS<DATA_T, const real_t<DATA_T>*, real_t<DATA_T>*>;
template<typename DATA_T>
using sparse_scale_arg_t = SSARGS<DATA_T, const real_t<DATA_T>*, const real_t<DATA_T>*>;

template<typename DATA_T>
struct mc64_preprocess_arg_t {
    real_t<DATA_T> norm_1;
    const Int *offsets;
    const DATA_T *src;
    real_t<DATA_T> *dst;
    real_t<DATA_T> *col_max;
    Int n, nnz;
};

template<typename DATA_T>
struct rowwise_sort_arg_t {
    DATA_T *values;
    DATA_T *temp_values;
    Int *indices;
    Int *temp_indices;
    const Int* offsets;
    Int m, nnz;
};

template<typename DATA_T>
struct csr423_arg_t {
    Int first_dim;
    Int nnz;
    const Int *begins;
    const Int *ends;
    const Int *indices4;
    const DATA_T *values4;
    Int *offsets;
    Int *indices3;
    DATA_T *values3;
};

template<typename DATA_T>
struct csr423_perm_arg_t {
    const Int *iperm;
    const Int *begins;
    const Int *ends;
    const Int *indices4;
    const DATA_T *values4;
    Int *offsets;
    Int *indices3;
    DATA_T *values3;
    Int *temp_indices3;
    DATA_T *temp_values3;
    Int first_dim;
    Int nnz;
};

template<typename DATA_T>
struct gather_arg_t {
    const Int *indices;
    const DATA_T *src;
    DATA_T *dst;
    Int n;
};

template<typename DATA_T>
struct scale_arg_t {
    DATA_T alpha;
    const DATA_T *src;
    DATA_T *dst;
    Int n;
};

template<typename DATA_T>
struct ewise_scale_arg_t {
    const real_t<DATA_T> *scale;
    const DATA_T *src;
    DATA_T *dst;
    Int n;
};

template<typename REAL_T>
struct ewise_exp_arg_t {
    REAL_T *rscale;
    REAL_T *cscale;
    Int n;
};

template<typename DATA_T>
struct dense_scale_arg_t {
    DATA_T alpha;
    const DATA_T *src;
    DATA_T *dst;
    Int n, n_vec, ldx, ldy;
};

struct index_shift_arg_t {
    const Int* in_index;
    Int *out_index;
    Int n, delta;
};

struct id_perm_args_t {
    Int *perm;
    Int n;
};

template<typename DATA_T>
struct spmv_kernel_arg_t {
    SpMV_Slave_Info infos[8][8];
};

template<typename DATA_T>
struct stspmv_kernel_arg_t {
    void *b;
    const void *a, *x;
    int nx, ny, nz;
    int lx, ly, lz;
    int ln,lm,ll;
    int height;
    int rank;
    int rnnz;
    int *pos;
    int row,col;
};


#endif

#endif
