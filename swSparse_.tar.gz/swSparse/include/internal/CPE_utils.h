#ifndef CPE_UTILS_H_INCLUDED 
#define CPE_UTILS_H_INCLUDED 1

/* functions on CPE */

#include <crts.h>
#include "internal/CPE.h"
#include "internal/utils.h"

#ifdef __cplusplus
#include "internal/templates.h"

namespace swSparse {

/* buffer */
template <typename Element, uint32_t buffer_size>
struct buffer {
    SIMD_ALIGN Element data[buffer_size];
};

template<typename DATA_T>
void gather_local(Int n, const DATA_T *table, DATA_T *local_dst, const Int *local_idx) NOTHROW;
template<typename DATA_T>
void gather_by_indices_(Int n, const DATA_T* table, DATA_T* dst, const Int* indices) NOTHROW;  // cache 128 KB

} // namespace swSparse
#endif

EXTERN void swSparse_collect_partition(Int *dist);
EXTERN void swSparse_partition_nnz(Int m, Int a_nnz, const Int *a_row_off, Int *dist, Int *ldm_buffer, Int ldm_size);

INLINE void* cached_read(void* dst, const void* src, size_t size) {
    return memcpy(dst, src, size);
}
INLINE void* cached_write(void* dst, const void* src, size_t size) {
    return memcpy(dst, src, size);
}

/* 从核号的重新映射 */
INLINE Int memory_channel_mapping(Int tid) {
    return ((tid >> 1) & 31) | ((tid << 5) & 32);
}

#endif
