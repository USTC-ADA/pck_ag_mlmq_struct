#ifndef SWSPARSE_OPTIONS_H_INCLUDED
#define SWSPARSE_OPTIONS_H_INCLUDED 1

#include "swSparse_types.h"

#define SWSPARSE_IN_PLACE      NULL
#define SWSPARSE_MATRIX_NULL   NULL

#define SWSPARSE_NON_TRANSPOSE     0x01
#define SWSPARSE_TRANSPOSE         0x02
#define SWSPARSE_MAYBE_TRANSPOSE   (SWSPARSE_TRANSPOSE | SWSPARSE_NON_TRANSPOSE)
#define SWSPARSE_CONJUGATE         0x04
#define SWSPARSE_HERMITIAN         (SWSPARSE_SYMMETRIC | SWSPARSE_CONJUGATE)
#define SWSPARSE_NON_SYMMETRIC     0x00
#define SWSPARSE_SYMMETRIC         0x08
#define SWSPARSE_LOWER_TRI         0x10
#define SWSPARSE_UPPER_TRI         0x20
#define SWSPARSE_LU                0x40
#define SWSPARSE_ILU               0x80
#define SWSPARSE_GENERAL_DIAG      0x00
#define SWSPARSE_UNIT_DIAG         0x01
#define SWSPARSE_RECP_DIAG         0x02
#define SWSPARSE_ORDERED           0x00
#define SWSPARSE_UNORDERED         0x01
#define SWSPARSE_NEW_MATRIX        0x00
#define SWSPARSE_SAME_PATTERN      0x01
#define SWSPARSE_NATURAL_ORDER     0x00
#define SWSPARSE_REORDER_AMD       0x01
#define SWSPARSE_REORDER_METIS     0x02
#define SWSPARSE_NO_MATCHING       0xFF
#define SWSPARSE_MATCHING_MC64     0x00
#define SWSPARSE_MATCHING_MC64_SYM 0x01
#define SWSPARSE_NO_EQUILIBRATE    0x01
#define SWSPARSE_EQUILIBRATE       0x00
#define SWSPARSE_NO_PERTURBATE     0x01
#define SWSPARSE_PERTURBATE_0      0x02
#define SWSPARSE_PERTURBATE_1      0x04
#define SWSPARSE_PERTURBATE_2      0x08

#define SWSPARSE_ITRF_MAX_LEVEL        254
#define SWSPARSE_DEFAULT_NVEC          4096
#define SWSPARSE_DEFAULT_NCALL         4096
#define SWSPARSE_DEFAULT_REFINE        10

typedef struct swSparseG {
    swSparseInt expected_ncall;   // default: SWSPARSE_DEFAULT_NCALL
    uint8_t transpose;            // default: SWSPARSE_NON_TRANSPOSE
    uint8_t symmetry;             // default: SWSPARES_NONSYMMETRIC
} swSparseMVOptions;

typedef struct swSparseH {
    swSparseInt expected_nvec;    // default: SWSPARSE_DEFAULT_NVEC
    swSparseInt expected_ncall;   // default: SWSPARSE_DEFAULT_NCALL
    uint8_t transpose;            // default: SWSPARSE_NON_TRANSPOSE
    uint8_t symmetry;             // default: SWSPARES_NONSYMMETRIC
} swSparseMMOptions;

#define SWSPARSE_MV_OPTION_DEFAULT     SWSPARSE_DEFAULT_NCALL, SWSPARSE_NON_TRANSPOSE, SWSPARSE_NON_SYMMETIRC
#define SWSPARSE_MV_OPTION_INITIALIZER { SWSPARSE_MV_OPTION_DEFAULT }
#define SWSPARSE_MM_OPTION_INITIALIZER { SWSPARSE_DEFAULT_NVEC, SWSPARSE_MV_OPTION_DEFAULT }

typedef struct swSparseI {
    swSparseInt expected_ncall;   // default: SWSPARSE_DEFAULT_NCALL
    uint8_t transpose;            // default: SWSPARSE_NON_TRANSPOSE
    uint8_t uplo;                 // default: SWSPARSE_LOWER_TRI
    uint8_t diagnal;              // default: SWSPARSE_GENERAL_DIAG
} swSparseTRSVOptions;

typedef struct swSparseJ {
    swSparseInt expected_nvec;    // default: SWSPARSE_DEFAULT_NVEC
    swSparseInt expected_ncall;   // default: SWSPARSE_DEFAULT_NCALL
    uint8_t transpose;            // default: SWSPARSE_NON_TRANSPOSE
    uint8_t uplo;                 // default: SWSPARSE_LOWER_TRI
    uint8_t diagnal;              // default: SWSPARSE_GENERAL_DIAG
} swSparseTRSMOptions;

#define SWSPARSE_TRSV_OPTION_DEFAULT     SWSPARSE_DEFAULT_NCALL, SWSPARSE_NON_TRANSPOSE, SWSPARSE_LOWER_TRI, SWSPARSE_GENERAL_DIAG
#define SWSPARSE_TRSV_OPTION_INITIALIZER { SWSPARSE_TRSV_OPTION_DEFAULT }
#define SWSPARSE_TRSM_OPTION_INITIALIZER { SWSPARSE_DEFAULT_NVEC, SWSPARSE_TRSV_OPTION_DEFAULT }

typedef struct swSparseK {
    uint8_t transpose_A;          // default: SWSPARSE_NON_TRANSPOSE
    uint8_t transpose_B;          // default: SWSPARSE_NON_TRANSPOSE
} swSparseADDOptions;

#define SWSPARSE_ADD_OPTION_INITIALIZER { SWSPARSE_NON_TRANSPOSE, SWSPARSE_NON_TRANSPOSE }

typedef struct swSparseL {
    uint8_t transpose_A;          // default: SWSPARSE_NON_TRANSPOSE
    uint8_t transpose_B;          // default: SWSPARSE_NON_TRANSPOSE
    uint8_t order_C;              // default: SWSPARSE_ORDERED
} swSparseGEMMOptions;

#define SWSPARSE_GEMM_OPTION_INITIALIZER { SWSPARSE_NON_TRANSPOSE, SWSPARSE_NON_TRANSPOSE, SWSPARSE_ORDERED }

typedef struct swSparseM {
//    double symmetric_diagnal_threshold;  // default: 0.1, only used if SWSPARSE_MATCHING_MC64_SYM
    uint8_t factor_type;             // default: SWSPARSE_LU
    // maybe SWSPARSE_CHOLESKY, SWSPARSE_ILU if implemented
    uint8_t symmetry;             // default: SWSPARSE_NON_SYMMETRIC
    uint8_t transpose;            // default: SWSPARSE_NON_TRANSPOSE
    uint8_t pattern;              // default: SWSPARSE_NEW_MATRIX
    uint8_t reorder;              // default: SWSPARSE_REORDER_AMD
    uint8_t matching;             // default: SWSPARSE_MATCHING_MC64
    uint8_t equilibrate;          // default: SWSPARSE_EQUILIBRATE
    uint8_t perturbate;           // default: SWSPARSE_PERTURBATE_1
} swSparseTRFOptions;

#define SWSPARSE_TRF_OPTION_DEFAULT      SWSPARSE_LU, SWSPARSE_NON_SYMMETRIC, SWSPARSE_NON_TRANSPOSE, SWSPARSE_NEW_MATRIX, SWSPARSE_REORDER_AMD, \
                                         SWSPARSE_MATCHING_MC64, SWSPARSE_EQUILIBRATE, SWSPARSE_PERTURBATE_1
#define SWSPARSE_TRF_OPTION_INITIALIZER  { SWSPARSE_TRF_OPTION_DEFAULT }

typedef struct swSparseN {
    uint8_t solver_type;             // default: SWSPARSE_LU
    // maybe SWSPARSE_CHOLESKY, SWSPARSE_ILU if implemented
    uint8_t symmetry;             // default: SWSPARSE_NON_SYMMETRIC
    uint8_t transpose;            // default: SWSPARSE_NON_TRANSPOSE
    uint8_t pattern;              // default: SWSPARSE_NEW_MATRIX
    uint8_t reorder;              // default: SWSPARSE_REORDER_AMD
    uint8_t matching;             // default: SWSPARSE_MATCHING_MC64
    uint8_t equilibrate;          // default: SWSPARSE_EQUILIBRATE
    uint8_t perturbate;           // default: SWSPARSE_PERTURBATE_1
    swSparseInt expected_nvec;    // default: SWSPARSE_DEFAULT_NVEC
    swSparseInt expected_ncall;   // default: SWSPARSE_DEFAULT_NCALL
    swSparseInt expected_refine;  // default: SWSPARSE_DEFAULT_REFINE
    // will call SpMV and SpTRSV `expected_ncall * expected_refine` times
    uint8_t uplo;                 // default: SWSPARSE_LOWER_TRI
	uint8_t diagnal;              // default: SWSPARSE_GENERAL_DIAG
} swSparseSolverOptions;

#define SWSPARSE_SOLVER_OPTION_INITIALIZER  { SWSPARSE_TRF_OPTION_DEFAULT, SWSPARSE_DEFAULT_NCALL, SWSPARSE_DEFAULT_NVEC, SWSPARSE_DEFAULT_REFINE }

#endif
