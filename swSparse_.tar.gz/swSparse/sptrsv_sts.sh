#!/bin/bash
LOGFILE=experiment_result_$(date +%Y%m%d_%H%M%S).log
bsub -b -I -q q_test_1 -n 1 -cgsp 64 -share_size 15000 -host_stack 4096 ./install/bin/stsptrsv_hetero_test 2>&1 | tee "$LOGFILE"
echo "Result saved to $LOGFILE"
