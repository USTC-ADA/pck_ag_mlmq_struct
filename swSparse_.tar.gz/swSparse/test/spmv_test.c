
#ifndef NO_CPE
#include <athread.h>
#endif
#include "swSparse.h"
#include "test.h"
#include <string.h>

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <sys/time.h>
#include <complex.h>

#define TIME(a, b) (1.0 * ((b).tv_sec - (a).tv_sec) + 1e-9 * ((b).tv_nsec - (a).tv_nsec))

void Print_Matrix(swSparseMatrixData *Matrix)
{

    int i, j;
    swSparseMatrixCSRC MatrixCSR;
    //m行数 n列数
    printf("In Print CSR!\n");
    printf("%d %d %d\n", Matrix->m, Matrix->n, Matrix->nnz);
    double *values = Matrix->matrix.coo->values;
    printf("CSR:\n");
    MatrixCSR = *(Matrix->matrix.csrc);
	printf("csr offset:");
    for (i = 0; i <= Matrix->m; i++)
        printf("%d ", Matrix->matrix.csrc->offsets[i]);
	printf("\ncsr col_idx:");
    for (i = 0; i < Matrix->nnz; i++)
        printf("%d ", Matrix->matrix.csrc->indices[i]);
    printf("\ncsr value:");
    double *v = Matrix->matrix.csrc->values;
    for (i = 0; i < Matrix->nnz; i++)
        printf("%.10f ", v[i]);
    printf("\n");
}

void Print_COOMatrix(swSparseMatrixData *Matrix)
{

    int i, j;
    swSparseMatrixCOO MatrixCOO;

    printf("In Print COO!\n");
    printf("%d %d %d\n", Matrix->n, Matrix->m, Matrix->nnz);
    double *values = Matrix->matrix.coo->values;

    printf("%d %d %lf\n",Matrix->matrix.coo->row_indices[3],Matrix->matrix.coo->column_indices[3],values[3]);
    printf("COO:\n");
    MatrixCOO = *(Matrix->matrix.coo);
	printf("coo row_idx:");
    for (i = 0; i < Matrix->nnz; i++)
        printf("%d ", Matrix->matrix.coo->row_indices[i]);
	printf("\ncoo col_idx:");
    for (i = 0; i < Matrix->nnz; i++)
        printf("%d ", Matrix->matrix.coo->column_indices[i]);
    printf("\ncoo value:");
    double *v = Matrix->matrix.coo->values;
    for (i = 0; i < Matrix->nnz; i++)
        printf("%.10f ", v[i]);
    printf("\n");
}

long long SpMV_Master_Answer_D(double alpha, swSparseMatrix Matrix_, double *x, double beta, double *b)
{

    int i, j;

    double *v = Matrix_->matrix.csrc->values;

    // unsigned long countS, countE;
    // penv_host_dacc_dcache_access_init();
    // penv_host_dacc_dcache_access_count(&countS);
    for (i = 0; i < Matrix_->m; i++){
        double tmp = 0;
        for (j = Matrix_->matrix.csrc->offsets[i]; j < Matrix_->matrix.csrc->offsets[i + 1]; j++){
            tmp += alpha * v[j] * x[Matrix_->matrix.csrc->indices[j]];
        }
        b[i] = b[i] * beta + tmp;
    }   
    
    // penv_host_dacc_dcache_access_count(&countE);
    // printf("countNum:%ld\n",countE-countS);
    return 0;
}

int check_d(double *a, double *b, int m)
{

    int i;
    double sa, sb;
    double ma = -1;
    /*
    for(i = 0; i < n; i ++)
    {
        double err = fabs(a[i]-b[i]);
        if (err / a[i] > ma || ma == -1) {
            ma = err;
            sa = a[i];
            sb = b[i];
        }
    }

    printf("Max diff %.16lf %.16lf %.16lf\n" , ma , sa , sb);
    */
    printf("Double: ");
    for (i = 0; i < m; i++)
    {
        double err = fabs(a[i] - b[i]);
        if (err / a[i] > 1e-10)
        {
            printf("Frist error in %d (%.16lf %.16lf)\n", i, a[i], b[i]);
            return -1;
        }
    }
    printf("Check success\n");
    return 0;
}

int test(cstr_t in_file, in_op_t in_op, cstr_t out_file, out_op_t out_op)
{
    struct timespec start, end;
    double t;
    swSparseMatrix a, b, c;
    swSparseErrorStatus ret = SWSPARSE_SUCCESS;
    swSparseMVOptions options;
    int i, j, k;
    double time_master, time_salve;
    double ratio;

    switch (in_op)
    {
    case MM:
        ret = swSparse_read_mtx(&c, in_file, SWSPARSE_DOUBLE, SWSPARSE_COO);
        break;
    case BIN:
        ret = swSparse_read_binary(&c, in_file);
        break;
    case WXL:
        break;
    }
    if (ret != SWSPARSE_SUCCESS)
    {
        return 2;
    }

#ifndef NO_CPE
    athread_init();
#endif
    ret = swSparse_convert_csr(c, &a);

    //Print_COOMatrix(c);
    //Print_Matrix(a);

    ret = swSparse_mv_inspect(a, &b, &options);

    double x[a->n];
    double b0[a->m];
    double b1[a->m];
    double alpha, beta, addional;

    alpha = 1.0;
    beta = 0.0;

    for (i = 0; i < a->n; i++)
        x[i] = 1;
    for (i = 0; i < a->m; i++)
        b0[i] = 0;
    for (i = 0; i < a->m; i++)
        b1[i] = 0;

    options.transpose = SWSPARSE_TRANSPOSE;

    clock_gettime(CLOCK_MONOTONIC, &start);
    SpMV_Master_Answer_D(alpha, a, x, beta, b0);
    clock_gettime(CLOCK_MONOTONIC, &end);

    time_master = TIME(start, end);
    printf("<Master> Time: %.10lfs\n", time_master);

    clock_gettime(CLOCK_MONOTONIC, &start);
    ret = swSparse_d_mv_execute(alpha, b, x, beta, b1, &options);
    clock_gettime(CLOCK_MONOTONIC, &end);
    time_salve = TIME(start, end);
    printf("<Slave> Time: %.10lfs\n", time_salve);

    check_d(b0, b1, a->m);

    if (alpha == 1.0)
        ratio = 2.0;
    else
        ratio = 3.0;

    if (beta == 0.0)
        addional = 0.0;
    else
        addional = a->m * 2;
    
    printf("acc %.4f , %.4f Gflops \n", time_master / time_salve, 0.000000001 * (ratio * a->nnz + addional) / time_salve);

    swSparse_destroy(a);
    swSparse_destroy(b);
    swSparse_destroy(c);

    return 0;
}
