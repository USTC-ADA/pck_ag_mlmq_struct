#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <float.h>
#include <math.h>
#include <sys/time.h>
#include <math.h>
#ifndef NO_CPE
#include <athread.h>
#endif
#include "swSparse.h"
#include "test.h"
  
//#define CSV_OUT
#define NUM_TEST
//#define PERF_TEST

static inline bool end_test(double ttotal, double tnum, double trefact, int rep) {
#if defined(NUM_TEST) || defined(NO_CPE)
    return true;
#elif  defined(PERF_TEST)
    return rep >= 5;
#endif
}

typedef int *intp_t;
typedef double *doublep_t;

typedef struct {
    int64_t flop, memory, zero_in, zero_out;
} stat_t;

stat_t get_stat(int n, int nsup, const int* a_col_offsets, const double* a_values, 
                const int *sup2col, const int *l_i_offsets, const int *l_v_offsets, const double *l_values, \
                const int *u_col_offsets, const int *u_seg_offsets, const int *u_seg_indices, const double *u_values);

void check_trf_parseq(int n, int nsup, const int *sup2col, const int *col2sup, \
                const int *l_i_offsets, const int *l_v_offsets, const int *l_indices, const double *l_values, \
                const int *u_col_off, const int *u_seg_offsets, const int *u_seg_indices, \
                const double *u_values, const int *riperm, const double *rscale, const double* cscale, cstr_t out_file, out_op_t out_op);
void check_trf(int n, int nsup, \
                const int *a_col_off, const int *a_row_idx, const double *a_val, \
                const int *sup2col, const int *l_i_offsets, const int *l_v_offsets, \
                const int *l_indices, const double *l_values, \
                const int *u_col_off, const int *u_seg_offsets, const int *u_seg_indices, \
                const double *u_val, \
                const int *riperm, const int *ciperm, const double *rscale, const double* cscale);
typedef struct {
    double value;
    int index;
} max_t;
max_t residual(int n, const int* col_off, const int* row_idx, const double* val, \
            const double* x, const double* b, double* res, double* abs_res);

extern void swSparse_fact_time(double *);      // back door
extern void swSparse_print_trf_info(); // back door

swSparseErrorStatus test_trf(swSparseMatrix a, swSparseMatrix *lu, \
            int* riperm, int* ciperm, double* rscale, double* cscale, \
            swSparseTRFOptions* opt, double* fact_time) {
    struct timeval begin, end;
    swSparseErrorStatus ret;
    int rep = 0;
    double t0 = 0, t1 = 0, t2 = 0, tmp[2] = {0};
    while(1) {
        gettimeofday(&begin, NULL);//double d   s float  c 单精度复数  z 双精度复数
        ret = swSparse_d_trf(a, lu, riperm, ciperm, rscale, cscale, opt);
        gettimeofday(&end, NULL);
        if(rep == 0) {
            t0 = TIME_DIFF(begin, end);
        } else {
            t1 += TIME_DIFF(begin, end);
        }
        ++ rep;
#ifdef NO_CPE
        t2 = t1 + t0;
#else
        swSparse_fact_time(tmp);
        t2 += tmp[1];
#endif
        if (end_test(t0, t2, t1, rep) || ret != SWSPARSE_SUCCESS) {
            break;
        }
        opt->pattern = SWSPARSE_SAME_PATTERN;
    }
    fact_time[0] = t0;
    fact_time[1] = tmp[0];
    swSparse_print_trf_info();
    if(rep > 1) {
        fact_time[2] = t1 / (rep - 1);
        fact_time[3] = t2 / rep;
    }
    return ret;
}

extern int global_argc;
extern cstr_t *global_argv;

char* append_suffix(char* ptr, uint8_t opt, int nopt, const uint8_t* option_table, const cstr_t* suffix) {
    for(int i = 0; i < nopt; ++i) {
        if(opt == option_table[i]) {
            cstr_t s = suffix[i];
            int len = strlen(s);
            memcpy(ptr, s, sizeof(char) * len);
            return ptr + len;
        }
    }
    return ptr;
}

int test(cstr_t in_file, in_op_t in_op, cstr_t out_file, out_op_t out_op) {
    double fact_time[4] = {0};
    swSparseMatrix a, lu;
    intp_t riperm, ciperm;
    doublep_t rscale, cscale;
    swSparseErrorStatus ret = SWSPARSE_SUCCESS;
    swSparseTRFOptions options = SWSPARSE_TRF_OPTION_INITIALIZER;
    int n, a_nnz, l_nnz, u_nnz, nsup;

    for(int i = 5; i < global_argc; ++i) {
        if (strcmp(global_argv[i], "metis") == 0) {
            options.reorder = SWSPARSE_REORDER_METIS;
        }
        if (strcmp(global_argv[i], "p2") == 0) {
            options.perturbate = SWSPARSE_PERTURBATE_2;
        }
        if (strcmp(global_argv[i], "p0") == 0) {
            options.perturbate = SWSPARSE_PERTURBATE_0;
        }
        if (strcmp(global_argv[i], "sym") == 0) {
            options.matching = SWSPARSE_MATCHING_MC64_SYM;
        }
    }
#ifndef NO_CPE
#define PARALLEL "parallel"
#else
#define PARALLEL "sequential"
#endif
#ifdef CSV_OUT
    char csvfilename[64] = "results_sptrf_"PARALLEL, *strptr = csvfilename + strlen(csvfilename);
    uint8_t option_table[3] = {SWSPARSE_PERTURBATE_0, SWSPARSE_PERTURBATE_1, SWSPARSE_PERTURBATE_2};
    const char* suffix[3] = {"_p0", "_p1", "_p2"};
    strptr = append_suffix(strptr, options.perturbate, 3, option_table, suffix);
    option_table[0] = SWSPARSE_MATCHING_MC64_SYM; suffix[0] = "_sym"; 
    strptr = append_suffix(strptr, options.matching, 1, option_table, suffix);
    option_table[0] = SWSPARSE_REORDER_AMD;       suffix[0] = "_amd"; 
    option_table[1] = SWSPARSE_REORDER_METIS;     suffix[1] = "_metis"; 
    strptr = append_suffix(strptr, options.reorder, 2, option_table, suffix);
    strcpy(strptr, ".csv");
#endif
    
#ifndef NO_CPE
    athread_init();
#endif
    switch (in_op)
    {
        case MM:
            ret = swSparse_read_mtx_cached(&a, in_file, "./data", SWSPARSE_DOUBLE, SWSPARSE_CSC);
            break;
        case BIN:
            ret = swSparse_read_binary(&a, in_file);
            break;
        case WXL:
            break;
    }
    if(ret != SWSPARSE_SUCCESS) {
        return 2;
    }
    if(a->n != a->m) {
        fprintf(stderr, "Matrix is not square.\n");
        return 6;
    }
    if(a->element_type != SWSPARSE_REAL_DOUBLE) {
        fprintf(stderr, "Complex is not supported yet.\n");
        return 666;
    }
    printf("Read matrix from %s\n", in_file);
    n = a->n;
    a_nnz = a->nnz;
    riperm = (intp_t)malloc(sizeof(int) * n * 2);
    ciperm = riperm + n;
    rscale = (doublep_t)malloc(sizeof(double) * n * 2);
    cscale = rscale + n;

    switch (a->format_type)
    {
        case SWSPARSE_COO:
        case SWSPARSE_CSR:
            ret = swSparse_convert_csc(a, SWSPARSE_IN_PLACE);
            if(ret != SWSPARSE_SUCCESS) {
                return ret;
            }
        /* fall through */
        case SWSPARSE_CSC:
            ret = test_trf(a, &lu, riperm, ciperm, rscale, cscale, &options, fact_time);
            break;
        default:
            return 21;
    }
    swSparseLUSupernodes* lusup = lu->matrix.lusuper;


#ifndef NO_CPE
    athread_halt();
#endif
    if(ret != SWSPARSE_SUCCESS) {
        fprintf(stderr, "swSparse_d_trf: error code = %d\n", ret);
        return 3;
    }
	l_nnz = lusup->l_v_offsets[lusup->nsuper];
	u_nnz = lusup->u_seg_offsets[lusup->u_col_offsets[n]];
    nsup = lusup->nsuper;

    stat_t stat = get_stat(n, nsup, a->matrix.csrc->offsets, a->matrix.csrc->values, lusup->sup2col, \
                     lusup->l_i_offsets, lusup->l_v_offsets, lusup->l_values, \
                     lusup->u_col_offsets, lusup->u_seg_offsets, \
                     lusup->u_seg_indices, lusup->u_values);

    check_trf_parseq(n, nsup, lusup->sup2col, lusup->col2sup, lusup->l_i_offsets, \
              lusup->l_v_offsets, lusup->l_indices, lusup->l_values, \
              lusup->u_col_offsets, lusup->u_seg_offsets, lusup->u_seg_indices, lusup->u_values, \
              riperm, rscale, cscale, out_file, out_op);

    check_trf(n, nsup, a->matrix.csrc->offsets, a->matrix.csrc->indices, a->matrix.csrc->values, \
              lusup->sup2col, lusup->l_i_offsets, lusup->l_v_offsets, \
              lusup->l_indices, lusup->l_values, \
              lusup->u_col_offsets, lusup->u_seg_offsets, \
              lusup->u_seg_indices, lusup->u_values, \
              riperm, ciperm, rscale, cscale);

    free(riperm);
    free(rscale);

    swSparse_destroy(a);
    swSparse_destroy(lu);

    printf("first run time: total %.3lf ms, factorization %.3lf ms\n", fact_time[0], fact_time[1]);
    if(fact_time[3] > 0) {
        printf("    rerun time: total %.6lf ms, factorization %.6lf ms\n", fact_time[2], fact_time[3]);
    }
    printf("N = %d, nnz(A) = %d, Nsuper = %d, nnz(L*) = %d, nnz(U*) = %d\n" \
            "Flop = %lld, memory = %lld, numeric zeros: A %lld, LU %lld\n", \
             n, a_nnz, nsup, l_nnz, u_nnz, stat.flop, stat.memory, stat.zero_in, stat.zero_out);
#ifdef CSV_OUT
    FILE *f = fopen(csvfilename, "a");
    fprint_matrix_name(f, in_file);
    fprintf(f, ", %d, %d, %d, %d, %d,%.3lf, %.3lf, %.6lf, %.6lf, %lld, %lld, %lld, %lld\n", n, a_nnz, nsup, l_nnz, u_nnz, \
        fact_time[0], fact_time[1], fact_time[2], fact_time[3], stat.flop, stat.memory, stat.zero_in, stat.zero_out);
    fclose(f);
#endif
    return 0;
}

static int64_t count_zero(int n, const double* val) {
    int64_t count = 0;
    for(int i = 0; i < n; ++i) {
        count += (val[i] == 0.0) ? 1 : 0;
    }
    return count;
}

stat_t get_stat(int n, int nsup, const int* a_col_offsets, const double* a_values, 
                const int *sup2col, const int *l_i_offsets, const int *l_v_offsets, const double *l_values, \
                const int *u_col_offsets, const int *u_seg_offsets, const int *u_seg_indices, const double *u_values) {
    stat_t stat;
    int64_t flop = 0, l_total = 0, size, numzero = 0;
    int i, j, p;
    intp_t u_row_nnz = (intp_t)malloc(sizeof(int) * n * 2);
    intp_t l_col_nnz = u_row_nnz + n;
    int lnnz = l_v_offsets[nsup], unnz = u_seg_offsets[u_col_offsets[n]];
    
    for(i = 0; i < nsup; ++i) {
        int j_sup_begin = sup2col[i], j_sup_end = sup2col[i+1];
        int ni = l_i_offsets[i + 1] - l_i_offsets[i];
        int supsize = j_sup_end - j_sup_begin;
        for(j = j_sup_begin; j < j_sup_end; ++ j) {
            int trailing = j_sup_end - j - 1; // without diagonal
            l_col_nnz[j] = ni + trailing;
            u_row_nnz[j] = trailing;
        }
        l_total += ni * supsize + ((supsize * (supsize - 1)) >> 1);
    }
    for(i = 0; i < n; ++i) {
        for(p = u_col_offsets[i]; p < u_col_offsets[i+1]; ++ p) {
            int seg_rep  = u_seg_indices[p];
            int seg_off  = u_seg_offsets[p];
            int seg_size = u_seg_offsets[p + 1] - seg_off;
            for(j = 0; j < seg_size; ++ j) {
                ++ u_row_nnz[seg_rep + j];
            }
        }
    }

    for(i = 0; i < n; ++i) {
        flop += u_row_nnz[i] * l_col_nnz[i];  // trailing update
    }

    free(u_row_nnz);
    stat.flop = (flop << 1) + l_total;     // trailing update + L scale
    size = (nsup + 1) * sizeof(int) * 4;   // l_i_offsets, l_v_offsets, sup2col, sup_etree
    size += l_i_offsets[nsup] * sizeof(int);
    size += lnnz * sizeof(double);
    size += (n + 1) * sizeof(int); // u_col_offsets
    size += u_col_offsets[n]  * sizeof(int) * 3;  // u_seg_offsets, u_seg_indices, col2sup
    size += unnz  * sizeof(double);
    stat.memory = size;
    stat.zero_out = count_zero(lnnz, l_values) + count_zero(unnz, u_values);
    stat.zero_in = count_zero(a_col_offsets[n], a_values);
    return stat;
}

void check_trf_parseq(int n, int nsup, const int *sup2col, const int *col2sup, \
                const int *l_i_offsets, const int *l_v_offsets, const int *l_indices, const double *l_values, \
                const int *u_col_off, const int *u_seg_offsets, const int *u_seg_indices, \
                const double *u_values, const int *riperm, const double *rscale, const double* cscale, cstr_t out_file, out_op_t out_op) {
    if(out_op == OUT) {
        FILE *f = fopen(out_file, "wb");
        if(f == NULL) {
            fprintf(stderr, "cannot open %s\n", out_file);
            return;
        }
        fwrite(l_values, sizeof(double), l_v_offsets[nsup], f);
        fwrite(u_values, sizeof(double), u_seg_offsets[u_col_off[n]], f);
        fwrite(rscale, sizeof(double), n, f);
        fwrite(cscale, sizeof(double), n, f);
        fwrite(riperm, sizeof(int), n, f);
        fclose(f);
        printf("write %d in L, %d in U, %d in R, %d in C, %d in riperm\n", l_v_offsets[nsup], u_seg_offsets[u_col_off[n]], n, n, n);
    } else {
        const double eps[] = {1e-12, 1e-8, 1e-4, 1e-2, 1e-1};
        int eps_idx = 0;
        FILE *f = fopen(out_file, "rb");
        if(f == NULL) {
            fprintf(stderr, "cannot open %s\n", out_file);
            return;
        }
        double *l_ref = malloc(sizeof(double) * l_v_offsets[nsup]);
        if(l_ref == NULL) {
            fprintf(stderr, "not enough memory for reference L\n", out_file);
            return;
        }
        double *u_ref = malloc(sizeof(double) * u_seg_offsets[u_col_off[n]]);
        if(u_ref == NULL) {
            free(l_ref);
            fprintf(stderr, "not enough memory for reference U\n", out_file);
            return;
        }
        double *r_ref = malloc(sizeof(double) * n * 2);
        if(r_ref == NULL) {
            free(l_ref);
            free(u_ref);
            fprintf(stderr, "not enough memory for equilibration factor\n", out_file);
            return;
        }
        double *c_ref = r_ref + n;
        int *perm_ref = malloc(sizeof(int) * n);
        if(perm_ref == NULL) {
            free(l_ref);
            free(u_ref);
            free(r_ref);
            fprintf(stderr, "not enough memory for permutation\n", out_file);
            return;
        }
        fread(l_ref, sizeof(double), l_v_offsets[nsup], f);
        fread(u_ref, sizeof(double), u_seg_offsets[u_col_off[n]], f);
        fread(r_ref, sizeof(double), n * 2, f);
        fread(perm_ref, sizeof(int), n, f);
        fclose(f);
        printf("read %d in L, %d in U, %d in R, %d in C, %d in riperm\n", l_v_offsets[nsup], u_seg_offsets[u_col_off[n]], n, n, n);

        for(int i = 0, tcount = 0; i < n; ++i) {
            double rse = rscale[i] - r_ref[i];
            double cse = cscale[i] - c_ref[i];
            double re = fabs(rse / r_ref[i]);
            double ce = fabs(cse / c_ref[i]);
            if(re > eps[eps_idx] || ce > eps[eps_idx]) {
                printf("row %d: %e %e (error %e), column %d: %e %e (error %e)\n", i, rscale[i], r_ref[i], re, i, cscale[i], c_ref[i], ce);
                if(++tcount == 10) {
                    break;
                }
            }
            if(riperm[i] != perm_ref[i]) {
                printf("row perm %d: %d %d\n", i, riperm[i], perm_ref[i]);
                if(++tcount == 10) {
                    break;
                }
            }
        }
        for(int i = 0; i < nsup; ++i) {
            int count = 0, tidx = eps_idx;
            for(int j = sup2col[i]; j < sup2col[i + 1]; ++j) {
                for(int k = u_col_off[j]; k < u_col_off[j + 1]; ++k) {
                    for(int p = u_seg_offsets[k]; p < u_seg_offsets[k + 1]; ++p) {
                        double se = u_values[p] - u_ref[p];
                        double e = fabs(se / u_ref[p]);
                        if(e > eps[eps_idx]) {
                            int row_idx = u_seg_indices[k];
                            printf("U sup %d col %d (sup %d, row index %d, seg pos %d, val off %d~%d): %.10e %.10e (error %e)\n", i, j, col2sup[row_idx], row_idx, k, p, u_seg_offsets[k], u_values[p], u_ref[p], e);
                            ++count;
                            if(tidx < 5 && e > eps[tidx]) {
                                count = 0;
                                do { ++ tidx; } while (tidx < 5 && e > eps[tidx]);
                            }
                            if(count >= 30) goto CHECK_L;
                        }
                    }
                }
            }
            CHECK_L:
            for(int p = l_v_offsets[i]; p < l_v_offsets[i + 1]; ++p) {
                double se = l_values[p] - l_ref[p];
                double e = fabs(se / l_ref[p]);
                if(e > eps[eps_idx]) {
                    int sup_size = sup2col[i+1] - sup2col[i];
                    int ld = l_i_offsets[i+1] - l_i_offsets[i] + sup_size;
                    int pp = p - l_v_offsets[i], rr = pp % ld, cc = pp / ld;
                    if(rr < sup_size) {
                        printf("L sup %d col %d~%d, (%d, %d): %.10e %.10e (error %e)\n", i, sup2col[i], sup2col[i+1], rr, cc, l_values[p], l_ref[p], e);
                    } else {
                        printf("L sup %d col %d~%d, (%d, %d), index %d: %.10e %.10e (error %e)\n", i, sup2col[i], sup2col[i+1], rr, cc, \
                            l_indices[l_i_offsets[i] + rr - sup_size], l_values[p], l_ref[p], e);
                    }
                    ++count;
                    if(tidx < 5 && e > eps[tidx]) {
                        count = 0;
                        do { ++ tidx; } while (tidx < 5 && e > eps[tidx]);
                    }
                    if(count >= 50) goto INNER_LOOP;
                }
            }
            INNER_LOOP:
            eps_idx = tidx;
            if(eps_idx >= 5) {
                break;
            }
        }
        
        free(perm_ref);
        free(l_ref);
        free(u_ref);
        free(r_ref);
    }
}

static const int randmaxclz = __builtin_clz(RAND_MAX);

static inline void rand_2_gaussian(double* x_true) {
    double x[2] = {1.0, 1.0};
    uint64_t bits[2];
    memcpy(bits, x, sizeof(x));
    bits[0] |= ((uint64_t)rand() << (20 + randmaxclz)) | (1ull << (19 + randmaxclz));
    bits[1] |= ((uint64_t)rand() << (20 + randmaxclz)) | (1ull << (19 + randmaxclz));
    memcpy(x, bits, sizeof(bits)); // x are in (1, 2)
    double r = sqrt(- 2.0 * log(x[0] - 1.0)), theta = 6.283185307179586 * (x[1] - 1.0);
    x_true[0] = r * sin(theta);
    x_true[1] = r * cos(theta);     // the real solution
}

void check_trf(int n, int nsup, \
                const int *a_col_off, const int *a_row_idx, const double *a_values, \
                const int *sup2col, const int *l_i_offsets, const int *l_v_offsets, \
                const int *l_indices, const double *l_values, \
                const int *u_col_off, const int *u_seg_offsets, const int *u_seg_indices, \
                const double *u_values, \
                const int *riperm, const int *ciperm, const double *rscale, const double* cscale) {
    int j, jsup, iter;
    double berr, converge;
    doublep_t xs, v0, v1, b, res;
    const char *msg;
    xs = (doublep_t)malloc(sizeof(double) * n * 4);
    b  = xs +   n;
    v0 = xs + 2*n;
    v1 = xs + 3*n;

    memset(xs, 0, sizeof(double) * n * 2);
    for(j = 0; j < n; j += 2) {
        int p, k = j + 1, begin = a_col_off[j], end = a_col_off[j+1];
        double x_true[2];
        rand_2_gaussian(x_true);
        for(p = begin; p < end; ++p) {
            b[a_row_idx[p]] += a_values[p] * x_true[0];
        }
        if(k < n) {
            begin = a_col_off[k], end = a_col_off[k+1];
            for(p = begin; p < end; ++p) {
                b[a_row_idx[p]] += a_values[p] * x_true[1];
            }
        }
    }

    /* A * x = b
     * Pr * Dr * A * Dc * Pc = L * U
     *   --->
     * (Pr * Dr * A * Dc * Pc) * (Pc^-1 * Dc^-1 * x) = Pr * Dr * b
     *   --->
     * (Pc^-1 * Dc^-1 * x) = y = U^-1 * L^-1 * Pr * Dr * b
     * x = Dc * Pc * y = Dc * Pc * U^-1 * L^-1 * Pr * Dr * b
     * 
     * Note:
     *    A * Pc is a column permutation P
     *    Pc * y is the inverse of P applying on y
     */
    iter = 0;
    msg = "direct solution";

    berr = 1.0;
    res = b;
    do {
        swSparse_d_elementwise_multiply(n, res, v1, rscale);
        swSparse_d_iperm_apply(n, v1, v0, riperm);

        for(jsup = 0; jsup < nsup; ++jsup) {
            int p, j_sup_begin = sup2col[jsup], j_sup_end = sup2col[jsup + 1], supsize = j_sup_end - j_sup_begin;
            int v_off = l_v_offsets[jsup], i_off = l_i_offsets[jsup] - supsize;
            int ld = l_i_offsets[jsup + 1] - i_off;
            const double *l_sup_val = &l_values[v_off];
            const int *l_sup_idx = &l_indices[i_off];

            for(j = j_sup_begin; j < j_sup_end; ++j) {
                int jrel = j - j_sup_begin;
                double xj = v0[j];
                const double *l_col_val = &l_sup_val[jrel * ld];
                for(p = jrel + 1; p < supsize; ++p) {  // diagnal block
                    v0[j_sup_begin + p] -= l_col_val[p] * xj;
                }
                for(p = supsize; p < ld; ++p) {        // off-diagnal block
                    v0[l_sup_idx[p]] -= l_col_val[p] * xj;
                }
            }
        }

        for(jsup = nsup - 1; jsup >= 0; --jsup) {
            int p, k, j_sup_begin = sup2col[jsup], j_sup_end = sup2col[jsup + 1], supsize = j_sup_end - j_sup_begin;
            int v_off = l_v_offsets[jsup];
            int ld = l_i_offsets[jsup + 1] - l_i_offsets[jsup] + supsize;
            const double *l_sup_val = &l_values[v_off];
            for(j = j_sup_end - 1; j >= j_sup_begin; --j) {
                int jrel = j - j_sup_begin;
                const double *l_col_val = &l_sup_val[jrel * ld];
                double xj = v0[j] * l_col_val[jrel];                // reciprocal diagnal
                v0[j] = xj;
                for(p = jrel - 1; p >= 0; --p) {                    // diagnal block
                    v0[j_sup_begin + p] -= l_col_val[p] * xj;
                }
                for(k = u_col_off[j + 1] - 1; k >= u_col_off[j]; --k) {  // off-diagnal block
                    int segoff = u_seg_offsets[k], segsize = u_seg_offsets[k + 1] - segoff;
                    int segrep = u_seg_indices[k];
                    for(p = segsize - 1; p >= 0; --p) {
                        v0[segrep + p] -= u_values[segoff + p] * xj;
                    }
                }
            }
        }

        swSparse_d_perm_apply(n, v0, v1, ciperm);
        swSparse_d_elementwise_multiply(n, v1, v0, cscale);

        for(j = 0; j < n; ++j) {
            xs[j] += v0[j];
        }

        max_t stat = residual(n, a_col_off, a_row_idx, a_values, xs, b, v0, v1);
        converge = berr;
        berr = stat.value;
        res = v0;

        fprintf(stderr, "check backward error of %-20s: %12.6e (at %d)\n", msg, berr, stat.index);
        msg = "iterative refinement";
        ++iter;
    } while (berr > DBL_EPSILON && berr <= converge && iter < 10);
    
    free(xs);
}

max_t residual(int n, const int* col_off, const int* row_idx, const double* val, \
            const double* x, const double* b, double* res, double* abs_res) {
    for(int i = 0; i < n; ++i) {
        res[i] = b[i];
        abs_res[i] = fabs(b[i]);
    }

    for(int j = 0; j < n; ++j) {
        int p, begin = col_off[j], end = col_off[j+1];
        double u = x[j], abs_u = fabs(u);
        for(p = begin; p < end; ++p) {
            int idx = row_idx[p];
            double v = val[p];
            res[idx] -= u * v;
            abs_res[idx] += abs_u * fabs(v);
        }
    }
    
    double err = 0;
    int idx = 0;
    for(int i = 0; i < n; ++i) {
        double e = fabs(res[i]) / abs_res[i];
        if(err < e) {
            err = e;
            idx = i;
        } else if(isnan(e)) {
            err = e;
            idx = i;
            break;
        }
    }
    max_t m = {err, idx};
    return m;
}
