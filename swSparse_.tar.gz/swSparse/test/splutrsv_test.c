#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <float.h>
#include <math.h>
#include <sys/time.h>
#include <math.h>
#ifndef NO_CPE
#include <athread.h>
#endif
#include "swperf.h"
#include "swSparse.h"
#include "swSparse_splutrsv.h"
#include "test.h"


//#define USE_FLOAT
// 不支持复数，仅测试单精度和双精度实数
#ifdef USE_FLOAT
#define float_type float
#define sw_prefix(func_name) swSparse_s_##func_name
#define READ_PRECISON SWSPARSE_SINGLE
#define REAL_DATA_TYPE SWSPARSE_REAL_SINGLE
#else
#define float_type double
#define sw_prefix(func_name) swSparse_d_##func_name
#define READ_PRECISON SWSPARSE_DOUBLE
#define REAL_DATA_TYPE SWSPARSE_REAL_DOUBLE
#endif

// 按正态分布生成随机数
static inline void rand_2_gaussian(double* x_true);
typedef struct {
    double value;
    int index;
} max_t;
// 计算后向误差 berr = |b - Ax| / (|A||x| + |b|)
max_t residual(int n, const int* row_off, const int* col_idx, const float_type* val, \
            const float_type* x, const float_type* b, float_type* res, float_type* abs_res);
// backdoor
extern void swSparse_lutrsv_get_flop_and_memory(Int n, swSparseMatrix* lu, size_t size_of_type);
extern void swSparse_print_trf_info();
extern void swSparse_print_lutrsv_info();

extern int global_argc;
extern cstr_t *global_argv;

swSparseErrorStatus test_solver(swSparseMatrix a, swSparseMatrix *lu, int* riperm, int* ciperm, \
    float_type* rscale, float_type* cscale, float_type* x, float_type* b, swSparseTRFOptions* opt, double* time) {    
    
    struct timeval begin, end;
    // swSparse_(type)_trf + swSparse_(type)_lutrsv, only support csr
    // type: double---d  s---float  c---单精度复数  z---双精度复数，暂不支持复数求解

    // LU decomposition
    gettimeofday(&begin, NULL);
    swSparseErrorStatus ret = sw_prefix(trf)(a, lu, riperm, ciperm, rscale, cscale, opt);
    if(ret != SWSPARSE_SUCCESS) {
        fprintf(stderr, "swSparse_trf: error code = %d\n", ret);
        return ret;
    }
    gettimeofday(&end, NULL);
    time[0] = TIME_DIFF(begin, end);
    
    // forward and backward substitution
    gettimeofday(&begin, NULL);
    ret = sw_prefix(lutrsv)(a->n, lu, b, x, riperm, ciperm, rscale, cscale);
    if(ret != SWSPARSE_SUCCESS) {
        fprintf(stderr, "swSparse_splutrsv: error code = %d\n", ret);
        return ret;
    }
    gettimeofday(&end, NULL);
    time[1] = TIME_DIFF(begin, end);
    return SWSPARSE_SUCCESS;
}

ErrorStatus serial_splutrsv(Int n, swSparseMatrix *lu, float_type* x, const float_type *b, Int* riperm, Int* ciperm, const float_type* rscale, const float_type* cscale)
{   
    size_t malloc_size = sizeof(float_type) * n;
    float_type* work = (float_type*)malloc(malloc_size);
    IF_ERR(work == NULL) {
        return SWSPARSE_MALLOC_ERROR;
    }
    sw_prefix(elementwise_multiply)(n, b, work, cscale);
    sw_prefix(iperm_apply)(n, work, x, ciperm);

    swSparseLUSupernodes* lusup = (*lu)->matrix.lusuper; 
    int nsup = lusup->nsuper;
    float_type *l_values = (float_type*)(lusup->l_values); 
    int *l_indices = lusup->l_indices;
    int *l_i_offsets = lusup->l_i_offsets;
    int *l_v_offsets = lusup->l_v_offsets;
    int *sup2col = lusup->sup2col;
    float_type *u_values = (float_type*)(lusup->u_values);
    int *u_col_offsets = lusup->u_col_offsets;
    int *u_seg_offsets = lusup->u_seg_offsets;
    int *u_seg_indices = lusup->u_seg_indices;

    for(int jsup = 0; jsup < nsup; ++jsup) {
        int p, k, j_sup_begin = sup2col[jsup], j_sup_end = sup2col[jsup + 1], supsize = j_sup_end - j_sup_begin;
        int v_off = l_v_offsets[jsup];
        int ld = l_i_offsets[jsup + 1] - l_i_offsets[jsup] + supsize;
        const float_type* l_sup_val = &l_values[v_off];
        for(int j = j_sup_begin; j < j_sup_end; ++j) {
            for(k = u_col_offsets[j]; k < u_col_offsets[j + 1]; ++k) {  // off-diagnal block
                int segoff = u_seg_offsets[k], segsize = u_seg_offsets[k + 1] - segoff;
                int segrep = u_seg_indices[k];
                for(p = 0; p < segsize; ++p) {
                    x[j] -= u_values[segoff + p] * x[segrep + p];
                }
            }
            int jrel = j - j_sup_begin;
            const float_type* l_row_val = &l_sup_val[jrel * ld];
            for(p = 0; p < jrel; ++p) {                    // diagnal block
                x[j] -= l_row_val[p] * x[j_sup_begin + p];
            }
            x[j] = x[j] * l_row_val[jrel];                // reciprocal diagnal
        }
    }

    for(int jsup = nsup - 1; jsup >= 0; --jsup) {
        int p, j_sup_begin = sup2col[jsup], j_sup_end = sup2col[jsup + 1], supsize = j_sup_end - j_sup_begin;
        int v_off = l_v_offsets[jsup], i_off = l_i_offsets[jsup] - supsize;
        int ld = l_i_offsets[jsup + 1] - i_off;
        const float_type* l_sup_val = &l_values[v_off];
        const int *l_sup_idx = &l_indices[i_off];

        for(int j = j_sup_end - 1; j >= j_sup_begin; --j) {
            int jrel = j - j_sup_begin;
            const float_type* l_row_val = &l_sup_val[jrel * ld];
            for(p = supsize; p < ld; ++p) {        // off-diagnal block
                x[j] -= l_row_val[p] * x[l_sup_idx[p]];
            }
            for(p = jrel + 1; p < supsize; ++p) {  // diagnal block
                x[j] -= l_row_val[p] * x[j_sup_begin + p];
            }
        }
    }

    sw_prefix(perm_apply)(n, x, work, riperm);
    sw_prefix(elementwise_multiply)(n, work, x, rscale);

    free(work);
    return SWSPARSE_SUCCESS;
}

int test(cstr_t in_file, in_op_t in_op, cstr_t out_file, out_op_t out_op) {
    double fact_time[4] = {0};
    swSparseMatrix a, lu;
    int *riperm, *ciperm;
    float_type *rscale, *cscale;
    swSparseErrorStatus ret = SWSPARSE_SUCCESS;
    swSparseTRFOptions options = SWSPARSE_TRF_OPTION_INITIALIZER;
    int n, a_nnz, l_nnz, u_nnz, nsup;

    for(int i = 5; i < global_argc; ++i) {
        if (strcmp(global_argv[i], "metis") == 0) {
            options.reorder = SWSPARSE_REORDER_METIS;
        }
        if (strcmp(global_argv[i], "p2") == 0) {
            options.perturbate = SWSPARSE_PERTURBATE_2;
        }
        if (strcmp(global_argv[i], "p0") == 0) {
            options.perturbate = SWSPARSE_PERTURBATE_0;
        }
        if (strcmp(global_argv[i], "sym") == 0) {
            options.matching = SWSPARSE_MATCHING_MC64_SYM;
        }
    }
    
#ifndef NO_CPE
    athread_init();
#endif
    switch (in_op)
    {
        case MM:
            ret = swSparse_read_mtx_cached(&a, in_file, "./data", READ_PRECISON, SWSPARSE_CSR);
            break;
        case BIN:
            ret = swSparse_read_binary(&a, in_file);
            break;
        case WXL:
            break;
    }
    if(ret != SWSPARSE_SUCCESS) {
        return 2;
    }
    if(a->n != a->m) {
        fprintf(stderr, "Matrix is not square.\n");
        return 6;
    }
    if(a->element_type != REAL_DATA_TYPE) {
        fprintf(stderr, "Complex is not supported yet.\n");
        return 666;
    }
    printf("Read matrix from %s\n", in_file);
    
    n = a->n;
    a_nnz = a->nnz;
    riperm = (int*)malloc(sizeof(int) * n * 2);
    ciperm = riperm + n;
    rscale = (float_type*)malloc(sizeof(float_type) * n * 2);
    cscale = rscale + n;

    switch (a->format_type)
    {
        // only support csr
        case SWSPARSE_CSC:
            ret = swSparse_convert_csr(a, SWSPARSE_IN_PLACE);
            if(ret != SWSPARSE_SUCCESS) {
                return ret;
            }
            break;
        case SWSPARSE_CSR:
            break;
        default:
            return 21;
    }

    int* a_row_off = a->matrix.csrc->offsets;
    int* a_col_idx = a->matrix.csrc->indices;
    float_type* a_values =  a->matrix.csrc->values;

    float_type *xs, *v0, *v1, *b, *res;
    const char *msg;
    xs = (float_type*)malloc(sizeof(float_type) * n * 4);
    b  = xs +   n;
    v0 = xs + 2*n;
    v1 = xs + 3*n;
    memset(xs, 0, sizeof(float_type) * n * 2);

    // generate x
    for(int j = 0; j < n; j += 2) {
        double x_true[2];
        rand_2_gaussian(x_true);
        xs[j] = x_true[0];
        int k = j + 1;
        if(k < n) {
            xs[k] = x_true[1];
        }
    }
    // generate b
    for(int j = 0; j < n; j += 1) {
        int begin = a_row_off[j], end = a_row_off[j+1];
        for(int p = begin; p < end; ++p) {
            b[j] += a_values[p] * xs[a_col_idx[p]];
        }
    }

    struct timeval begin, end;
    double parallel_solve_time[3], serial_substitution_time;
    
    // parallel forward and backward substitution
    memset(xs, 0, sizeof(float_type) * n);
    msg = "parallel substitution";
    gettimeofday(&begin, NULL);
    ret = test_solver(a, &lu, riperm, ciperm, rscale, cscale, xs, b, &options, parallel_solve_time);
    if(ret != SWSPARSE_SUCCESS) {
        return ret;
    }
    gettimeofday(&end, NULL);
    parallel_solve_time[2] = TIME_DIFF(begin, end);
    // 打印详细信息
    swSparse_lutrsv_get_flop_and_memory(a->n, &lu, sizeof(float_type));
    swSparse_print_trf_info();
    swSparse_print_lutrsv_info();
    printf("lu decomposition time: %.3lf ms\n", parallel_solve_time[0]);
    printf("substitution time: %.3lf ms\n", parallel_solve_time[1]);
    printf("solve time: total %.3lf ms\n", parallel_solve_time[2]);
    // check backward err
    max_t res_info = residual(n, a_row_off, a_col_idx, a_values, xs, b, v0, v1);
    fprintf(stderr, "check backward error of %-20s: %12.6e (at %d)\n", msg, res_info.value, res_info.index);

    // serial forward and backward substitution
    memset(xs, 0, sizeof(float_type) * n);
    msg = "serial substitution";
    gettimeofday(&begin, NULL);
    serial_splutrsv(n, &lu, xs, b, riperm, ciperm, rscale, cscale);
    if(ret != SWSPARSE_SUCCESS) {
        return ret;
    }
    gettimeofday(&end, NULL);
    serial_substitution_time = TIME_DIFF(begin, end);
    printf("serial substitution time: %.3lf ms\n", serial_substitution_time);
    // check backward err
    res_info = residual(n, a_row_off, a_col_idx, a_values, xs, b, v0, v1);
    fprintf(stderr, "check backward error of %-20s: %12.6e (at %d)\n", msg, res_info.value, res_info.index);

    printf("----------------------------\n");
    printf("N = %d, nnz(A) = %d, Nsuper = %d\n", n, a_nnz, lu->matrix.lusuper->nsuper);
    printf("----------------------------\n");
    
    // 释放内存
    free(xs);
    free(riperm);
    free(rscale);
    swSparse_destroy(a);
    swSparse_destroy(lu);
    return 0;
}

static const int randmaxclz = __builtin_clz(RAND_MAX);

static inline void rand_2_gaussian(double* x_true) {
    double x[2] = {1.0, 1.0};
    uint64_t bits[2];
    memcpy(bits, x, sizeof(x));
    bits[0] |= ((uint64_t)rand() << (20 + randmaxclz)) | (1ull << (19 + randmaxclz));
    bits[1] |= ((uint64_t)rand() << (20 + randmaxclz)) | (1ull << (19 + randmaxclz));
    memcpy(x, bits, sizeof(bits)); // x are in (1, 2)
    double r = sqrt(- 2.0 * log(x[0] - 1.0)), theta = 6.283185307179586 * (x[1] - 1.0);
    x_true[0] = r * sin(theta);
    x_true[1] = r * cos(theta);     // the real solution
}

max_t residual(int n, const int* row_off, const int* col_idx, const float_type* val, \
            const float_type* x, const float_type* b, float_type* res, float_type* abs_res) {
    for(int i = 0; i < n; ++i) {
        res[i] = b[i];
        abs_res[i] = fabs(b[i]);
    }

    for(int j = 0; j < n; ++j) {
        int p, begin = row_off[j], end = row_off[j+1];
        for(p = begin; p < end; ++p) {
            double u = x[col_idx[p]], abs_u = fabs(u);
            double v = val[p];
            res[j] -= u * v;
            abs_res[j] += abs_u * fabs(v);
        }
        
    }
    
    double err = 0;
    int idx = 0;
    for(int i = 0; i < n; ++i) {
        double e = fabs(res[i]) / abs_res[i];
        if(err < e) {
            err = e;
            idx = i;
        } else if(isnan(e)) {
            err = e;
            idx = i;
            break;
        }
    }
    max_t m = {err, idx};
    return m;
}
