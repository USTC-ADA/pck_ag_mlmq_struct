#include <stdint.h>
#include <stdlib.h>
#include <sys/time.h>
#ifndef NO_CPE
#include <athread.h>
#endif
//#include <simd.h>
#include "swSparse.h"
#include "test.h"

#define MY_D
//#define MY_S
//#define MY_C
//#define MY_Z

#define TIME(a,b) (1.0*((b).tv_sec-(a).tv_sec)+0.000001*((b).tv_usec-(a).tv_usec))

#ifdef MY_S
#define TYPE float
#define STYPE float
#define FLOAT
#endif

#ifdef MY_D
#define TYPE double
#define STYPE double
#define DOUBLE
#endif

#ifdef MY_C
#define TYPE swSparseSComplex
#define COMPLEX_C
#define STYPE float
#endif

#ifdef MY_Z
#define TYPE swSparseDComplex
#define COMPLEX_Z
#define STYPE double
#endif

void show_csrc(swSparseMatrix a)
{
    printf("-- Matrix information --\n");
    int i, j;
    printf("-- row offset --\n");
    for (i = 0; i < a->m + 1; i++)
    {
        printf("%d ", a->matrix.csrc->offsets[i]);
    }
    printf("\n");
    printf("-- col index --\n");
    for (i = 0; i < a->nnz; i++)
    {
        printf("%d ", a->matrix.csrc->indices[i]);
    }
    printf("\n");
    printf("-- values --\n");
    TYPE* values = a->matrix.csrc->values;
    for (i = 0; i < a->nnz; i++)
    {
        #if ((defined DOUBLE) || (defined FLOAT))
            printf("%.2f ", values[i]);
        #else
            printf("%.2f+%.2fi ", ceal(values[i]), cimg(values[i]))
        #endif
    }
    printf("\n");
}

void init(TYPE *a, int length)
{
	int i;
	long long r = rand();
	#if ((defined DOUBLE) || (defined FLOAT))
	for (i = 0; i < length; i ++)
		a[i] = rand() / (double)RAND_MAX;
	#else
	for (i = 0; i < length; i ++)
	{
		a[i] = (rand() / (double)RAND_MAX) + \
		(rand() / (double)RAND_MAX) * I;
	}
	#endif
}

int test(cstr_t in_file, in_op_t in_op, cstr_t out_file, out_op_t out_op)
{
    swSparseMatrix a;
    swSparseMatrix b;
    swSparseMatrix c;

    int m = 5, n = 10;
    int a_nnz = 5, b_nnz = 2;

    /* malloc matrix */
    TYPE *a_values = (TYPE*)malloc(a_nnz * sizeof(TYPE));
    TYPE *b_values = (TYPE*)malloc(b_nnz * sizeof(TYPE));
    int *a_offsets = (int*)malloc(m * sizeof(int));
    int *b_offsets = (int*)malloc(m * sizeof(int));
    int *a_indices = (int*)malloc(a_nnz * sizeof(int));
    int *b_indices = (int*)malloc(b_nnz * sizeof(int));
    
    /* generate matrix */
    a_offsets[0] = 0; a_offsets[1] = 1; a_offsets[2] = 2; a_offsets[3] = 3; a_offsets[4] = 4; a_offsets[5] = 5;
    b_offsets[0] = 0; b_offsets[1] = 1; b_offsets[2] = 2; b_offsets[3] = 2; b_offsets[4] = 2; b_offsets[5] = 2;
    a_indices[0] = 1; a_indices[1] = 3; a_indices[2] = 5; a_indices[3] = 7; a_indices[4] = 9;
    a_values[0] = 0; a_values[1] = 1; a_values[2] = 2; a_values[3] = 3; a_values[4] = 4;
    b_indices[0] = 1; b_indices[1] = 3;// b_indices[2] = 5; b_indices[3] = 7; b_indices[4] = 10;
    b_values[0] = 0; b_values[1] = 1;// b_values[2] = 2; b_values[3] = 3; b_values[4] = 4;

    #ifdef MY_D
    swSparse_d_create_csr(&a, m, n, a_nnz, a_offsets, a_indices, a_values);
    swSparse_d_create_csr(&b, m, n, b_nnz, b_offsets, b_indices, b_values);
    #endif

    show_csrc(a);
    show_csrc(b);

    swSparseADDOptions options = SWSPARSE_ADD_OPTION_INITIALIZER;

#if defined(MY_S)
    swSparse_s_add_sequential(1.0, a, 1.0, b, &c, &options);
#endif
#if defined(MY_D)
    swSparse_d_add(1.0, a, 1.0, b, &c, &options);
#endif
#if defined(MY_C)
    swSparse_c_add_sequential(1.0, a, 1.0, b, &c, &options);
#endif
#if defined(MY_Z)
    swSparse_z_add_sequential(1.0, a, 1.0, b, &c, &options);
#endif
    
    show_csrc(c);
    return 0;
}
