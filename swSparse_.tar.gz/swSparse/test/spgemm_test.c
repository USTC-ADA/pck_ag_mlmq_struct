#include <stdint.h>
#include <stdio.h>
#include <math.h>
#include <complex.h>
#include <sys/time.h>
#ifndef NO_CPE
#include <athread.h>
#endif
#include "swSparse.h"
#include "test.h"

//#define PROFILE_SPGEMM_MULTICG
double swSparse_gemm_print_profile();

//#define CSV_OUT
#define DEBUG_TEST
//#define PERF_TEST

#if defined(DEBUG_TEST)
#define END_TEST(t_, rep_) true
#elif  defined(PERF_TEST)
#define END_TEST(t_, rep_) (rep_ >= 5)
#endif

#define L1SIZE 8192
//const int L1MAX = (int)(L1SIZE * 0.85);

struct stat_t {
    int64_t nmul, nmul_row_max;
    int rows_use_L2, c_row_max;
} ;

void data_feature(int m, const int *a_row_off, const int *a_col_idx, const int *b_row_off, const int *c_row_off, struct stat_t* s) {
    int i, p, rows_compressed = 0, rows_use_L2 = 0, c_row_max = 0;
    int64_t nmul = 0, nmul_row_max = 0;
    for(i = 0; i < m; ++i) {
        int64_t row_nmul = 0, cnnz = c_row_off[i+1] - c_row_off[i];
        for(p = a_row_off[i]; p < a_row_off[i+1]; ++p){
            int j = a_col_idx[p];
            row_nmul += (int64_t)(b_row_off[j+1] - b_row_off[j]);
        }
        nmul += row_nmul;
        nmul_row_max = (nmul_row_max > row_nmul) ? nmul_row_max : row_nmul;
        c_row_max = (c_row_max > cnnz) ? c_row_max : cnnz;
        if(row_nmul > L1SIZE) {
            ++rows_use_L2;
        }
    }
    s->nmul = nmul;
    s->nmul_row_max = nmul_row_max;
    s->c_row_max = c_row_max;
    s->rows_use_L2 = rows_use_L2;
}

swSparseErrorStatus test_gemm(swSparseMatrix a, swSparseMatrix b, swSparseMatrix* c, const swSparseGEMMOptions* opt, double* tp) {
    struct timeval start, end;
    int rep = 0;
    double t = 0;
    swSparseErrorStatus ret;
    gettimeofday(&start, NULL);
    ret = swSparse_d_gemm(1.0, a, b, 0.0, NULL, c, opt);   // warm-up for parallel version
    gettimeofday(&end, NULL);
    if (ret != SWSPARSE_SUCCESS) {
        return ret;
    }
#ifdef NO_CPE 
    *tp = TIME_DIFF(start, end);
    return ret;
#else
#ifdef PERF_TEST
    swSparse_destroy(*c);
    if(TIME_DIFF(start, end) < 100.0) {  // warm-up again
        ret = swSparse_d_gemm(1.0, a, b, 0.0, NULL, c, opt);
        swSparse_destroy(*c);
        if (ret != SWSPARSE_SUCCESS) {
            return ret;
        }
    }
#endif
    while(1) {  // test
        gettimeofday(&start, NULL);
        ret = swSparse_d_gemm(1.0, a, b, 0.0, NULL, c, opt);
        gettimeofday(&end, NULL);
        t += TIME_DIFF(start, end);
        ++ rep;
        if (END_TEST(t, rep) || ret != SWSPARSE_SUCCESS) {
            break;
        }
        swSparse_destroy(*c);
    }
    *tp = t / rep;
    return ret;
#endif
}

swSparseBool swSparse_valid(swSparseMatrix);
swSparseErrorStatus swSparse_ensure_order(swSparseMatrix);

int test(cstr_t in_file, in_op_t in_op, cstr_t out_file, out_op_t out_op) {
    struct stat_t stat = {0,0,0};
    double t, cr, fp;
    swSparseMatrix a, a_copy, b, c;
    swSparseErrorStatus ret = SWSPARSE_SUCCESS;
    swSparseGEMMOptions options = SWSPARSE_GEMM_OPTION_INITIALIZER;
    int n, a_nnz, b_nnz;
    options.order_C = SWSPARSE_UNORDERED;

#ifndef NO_CPE
    athread_init_all();
#endif


    switch (in_op)
    {
        case MM:
            ret = swSparse_read_mtx_cached(&a, in_file, "./data", SWSPARSE_DOUBLE, SWSPARSE_CSR);
            break;
        case BIN:
            ret = swSparse_read_binary(&a, in_file);
            break;
        case WXL:
            break;
    }
    if(ret != SWSPARSE_SUCCESS) {
        printf("While reading %s: Error code = %d\n", in_file, ret);
        return 2;
    }
    if(a->n != a->m) {
        printf("Matrix is not square.\n");
        return 6;
    }
    if(a->element_type != SWSPARSE_REAL_DOUBLE) {
        printf("Matrix is not real double type.\n");
        return 12;
    }
    printf("Read matrix from %s\n", in_file);

    switch (a->format_type)
    {
        case SWSPARSE_COO:
            ret = swSparse_convert_csr(a, SWSPARSE_IN_PLACE);
            if(ret != SWSPARSE_SUCCESS) {
                printf("In conversion of %s: Error code = %d\n", in_file, ret);
                return ret;
            }
        case SWSPARSE_CSC:
        case SWSPARSE_CSR:
            #if DEBUG_LEVEL > 1
                if(!swSparse_valid(a)) {
                    printf("Invalid input matrix format\n", ret);
                    return 114514;
                }
            #endif
            ret = swSparse_copy(a, &a_copy);
            if(ret != SWSPARSE_SUCCESS) {
                printf("While copying %s: Error code = %d\n", in_file, ret);
                return ret;
            }
            ret = test_gemm(a, a_copy, &b, &options, &t);
            break;
        default:
            return 21;
    }

#ifndef NO_CPE
    
    swSparse_gemm_print_profile();
	athread_halt();
    //swSparse_gemm_print_profile();
#endif
    if(ret != SWSPARSE_SUCCESS) {
        printf("Error code = %d\n", ret);
        return 3;
    }
#if DEBUG_LEVEL > 1
    if(!swSparse_valid(b)) {
        printf("Invalid output matrix format\n", ret);
        return 114514;
    }
#endif

    switch (a->format_type)
    {
        case SWSPARSE_CSR:
            data_feature(a->m, a->matrix.csrc->offsets, a->matrix.csrc->indices, 
                a_copy->matrix.csrc->offsets, b->matrix.csrc->offsets, &stat);
            break;
        case SWSPARSE_CSC:
            data_feature(a_copy->n, a_copy->matrix.csrc->offsets, a_copy->matrix.csrc->indices, 
                a->matrix.csrc->offsets, b->matrix.csrc->offsets, &stat);
            break;
        default:
            break;
    }
    swSparse_ensure_order(b);

    a_nnz = a->nnz;
    b_nnz = b->nnz;
    n = a->n;
    switch (out_op)
    {
        case REF:
            ret = swSparse_read_binary(&c, out_file);
            if(ret != SWSPARSE_SUCCESS) {
                printf("Failed in reading reference %s: Error code = %d\n", out_file, ret);
                //return 4;
            } else {
                if(!swSparse_compare(c, b)) {
                    printf("Wrong result of %s: Error code = %d\n", in_file, ret);
                    {
                    int *boff = b->matrix.csrc->offsets;
                    int *coff = c->matrix.csrc->offsets;
                    int *bidx = b->matrix.csrc->indices;
                    int *cidx = c->matrix.csrc->indices;
                    double *bval = (double*)b->matrix.csrc->values;
                    double *cval = (double*)c->matrix.csrc->values;
                    int flag = 0;
                    for(int i = 0; i < b->m; ++i) {
                        int bnz = boff[i+1] - boff[i];
                        int cnz = coff[i+1] - coff[i];
                        if(bnz != cnz) {
                            int k1 = (i - 5 >= 0) ? (i - 5) : 0;
                            int k2 = (i + 5 < b->m) ? (i + 5) : b->m;
                            for(int j = k1; j < k2; ++j) {
                                printf("row %d: b_offset %d b_rnz %d, c_offset %d, c_rnz %d\n", j, boff[j], boff[j+1]-boff[j], coff[j], coff[j+1]-coff[j]);
                            }
                            flag = 1;
                            break;
                        }
                    }
                    if(flag == 0) {
                        for(int i = 0; i < b->m; ++i) {
                            int bnz = boff[i+1] - boff[i];
                            int cnz = coff[i+1] - coff[i];
                            for(int j = boff[i]; j < boff[i+1]; ++j) {
                                if(cidx[j] != bidx[j]) {
                                    flag = j + 1;
                                    break;
                                }
                            }
                            if(flag > 0) {
                                printf("row %d: B nnz %d, C nnz %d\n", i, bnz, cnz);
                                for(int j = coff[i]; j < coff[i+1]; ++j) {
                                    printf("%10d %10d %c\n", bidx[j], cidx[j], (j + 1 == flag) ? 'x':' ');
                                }
                                break;
                            }
                        }
                    }
                    }
                    return 5;
                }
                swSparse_destroy(c);
            }
            break;
        case INOUT:
            ret = swSparse_write_binary(a, out_file);
            if(ret != SWSPARSE_SUCCESS) {
                return 4;
            }
            /* fall through */
        case OUT:
            ret = swSparse_write_binary(b, out_file);
            if(ret != SWSPARSE_SUCCESS) {
                printf("Failed in writing %s: Error code = %d\n", out_file, ret);
                return 4;
            }
            break;
    }

    swSparse_destroy(a);
    swSparse_destroy(a_copy);
    swSparse_destroy(b);
    
    cr = (double)(stat.nmul) / b_nnz; // compress rate
    fp = (stat.nmul << 1) / (1e6 * t);            // floating point performance

#ifndef NO_CPE
#define TYPE "parallel"
#else
#define TYPE "sequential"
#endif

    printf(TYPE" run time: %.3lf ms, %lf Gflop/s, compress rate = %.3lf (%ld / %d)\n", t, fp, cr, stat.nmul, b_nnz);
	printf("%d, %d, %d, %lld, %.3lf, %lf, %d, %lld, %d\n", n, a_nnz, b_nnz, stat.nmul, t, fp, stat.c_row_max, stat.nmul_row_max, stat.rows_use_L2);
#ifdef CSV_OUT
    FILE *f = fopen("results_spgemm_"TYPE".csv","a");
    fprint_matrix_name(f, in_file);
    /* format: name, n, nnz of input, nnz of output, number of multiplications, time, performance */
    fprintf(f, ", %d, %d, %d, %lld, %.3lf, %lf, %d, %lld, %d\n", n, a_nnz, b_nnz, stat.nmul, t, fp, \
            stat.c_row_max, stat.nmul_row_max, stat.rows_use_L2);
    fclose(f);
#endif
    return 0;
}

