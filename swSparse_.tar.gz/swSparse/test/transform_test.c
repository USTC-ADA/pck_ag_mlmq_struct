#include <sys/time.h>
#ifndef NO_CPE
#include <athread.h>
#endif
#include "swSparse.h"
#include "test.h"

int test(cstr_t in_file, in_op_t in_op, cstr_t out_file, out_op_t out_op) {
    struct timeval start, end;
    double t;
    swSparseMatrix a, b, c;
    swSparseErrorStatus ret = SWSPARSE_SUCCESS;

    switch (in_op)
    {
        case MM:
            ret = swSparse_read_mtx(&a, in_file, SWSPARSE_SINGLE, SWSPARSE_COO);
            break;
        case BIN:
            ret = swSparse_read_binary(&a, in_file);
            break;
    }
    if(ret != SWSPARSE_SUCCESS) {
        return 2;
    }
#ifndef NO_CPE
    athread_init();
#endif

    switch (a->format_type)
    {
        case SWSPARSE_CSR:
            gettimeofday(&start, NULL);
            ret = swSparse_convert_csc(a, &b);
            gettimeofday(&end, NULL);
            break;
        case SWSPARSE_CSC:
        case SWSPARSE_COO:	
            gettimeofday(&start, NULL);
            ret = swSparse_convert_csr(a, &b);
            gettimeofday(&end, NULL);
            break;
        default:
            return 21;
    }
	
#ifndef NO_CPE
    athread_halt();
#endif
    if(ret != SWSPARSE_SUCCESS) {
        return 3;
    }
    switch (out_op)
    {
        case REF:
            ret = swSparse_read_binary(&c, out_file);
            if(ret != SWSPARSE_SUCCESS) {
                return 4;
            }
            if(!swSparse_compare(b, c)) {
                return 5;
            }
            break;
        case INOUT: /* do not use this option now */
            ret = swSparse_write_binary(a, out_file);
            if(ret != SWSPARSE_SUCCESS) {
                return 4;
            }
            /* fall through */
        case OUT:
            ret = swSparse_write_binary(b, out_file);
            if(ret != SWSPARSE_SUCCESS) {
                return 4;
            }
            break;
    }

    swSparse_destroy(a);
    swSparse_destroy(b);
    
    t = TIME_DIFF(start, end);
#ifndef NO_CPE
#define TYPE "parallel"
#else
#define TYPE "sequential"
#endif

    printf(TYPE" run time: %.3lf ms\n", t);
#ifdef CSV_OUT
    FILE *f = fopen("results_spgemm_"TYPE".csv","a");
    fprint_matrix_name(f, in_file);
    fprintf(f, ", %lf\n", t);
    fclose(f);
#endif
    return 0;
}

