#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <complex.h>
#include <time.h>
#ifndef NO_CPE
#include <athread.h>
#endif
#include <sys/time.h>
#include "swSparse.h"
#include "internal/rename.h"
#include "internal/memory.h"

#define MIN(a,b) ((a) < (b) ? (a) : (b))
#define MAX(a,b) ((a) > (b) ? (a) : (b))

#define TIME(a,b) (1.0*((b).tv_sec-(a).tv_sec)+0.000001*((b).tv_usec-(a).tv_usec))

//#define debug
#define TEST

//#define PtF  //Data Print to File
#define RfF  //Data Read from File
//#define DIA  //数据是否对角占优

void Init_Zero(double *data, int length){
  int i;
  for(i = 0; i < length; i ++)
    data[i] = 0;
}

void Init_Zero_S(float *data, int length){
  int i;
  for(i = 0; i < length; i ++)
    data[i] = 0;
}

// void Init_Zero_Z(DComplex *data, int length){
//   int i;
//   for(i = 0; i < length; i ++)
//     data[i] = 0 + 0i;
// }

// void Init_Zero_C(SComplex *data, int length){
//   int i;
//   for(i = 0; i < length; i ++)
//     data[i] = 0 + 0i;
// }

void Init(double *data, int length,int flag){
  int i;
  long long r = rand();
  for(i = 0; i < length; i ++){
    if (flag == 0){
      r = rand();
      data[i] = 0.1 + (double)((r++)%10000)*1e-2;
    }
    else data[i] = 1.0;
  }
}

void Init_S(float *data, int length){
  int i;
  long long r = rand();
  for(i = 0; i < length; i ++){
    r = rand();  
    data[i] = 0.1 + (float)((r++)%10000)*1e-2;
    //data[i] = 1.0;
  }
    
}

// void Init_Z(DComplex *data, int length){
//   int i;
//   long long r = rand();
//   for(i = 0; i < length; i ++){
//     r = rand();
//     data[i] = 0.1 + (double)((r++)%10000)*1e-2 + (0.1 + (double)((r++)%10000)*1e-2) * I;
//   }
//     //data[i] = 1.0 + 1.0i;
// }

// void Init_C(SComplex *data, int length){
//   int i;
//   long long r = rand();
//   for(i = 0; i < length; i ++){
//     r = rand();
//     data[i] = 0.1 + (float)((r++)%10000)*1e-2 + (0.1 + (float)((r++)%10000)*1e-2) * I;
//   }
//     //data[i] = 1.0 + 1.0i;

// }

void check_D(int flag , double *A, double *B, int length, int M, int N, int L){
  int i;
  
  fprintf(stderr,"Check 3D%d Double: ",flag); 

  for(i = 0; i < length; i ++)
  {
    double t = A[i]-B[i];
    if(t < 0) t = -t;
    if(t > 1e-8)
    {
      fprintf(stderr,"Warning: The first wrong %d(%d,%d,%d)(%.16f %.16f)\n", i + 1, i/(N*L), (i/L)%N, i%L, A[i], B[i]);
      return;
    }
  }
  
  fprintf(stderr,"Pass!\n");

}

void check_S(int flag , float *A, float *B, int length, int M, int N, int L){
  int i;
  
  fprintf(stderr,"Check 3D%d Single: ",flag); 
  
  for(i = 0; i < length; i ++)
  {
    float t = A[i]-B[i];
    if(t < 0) t = -t;
    if(t > 1e-5)
    {
      fprintf(stderr,"Warning: The first wrong %d(%d,%d,%d)(%.16lf %.16lf)\n", i, i/(N*L), (i/L)%N, i%L, A[i], B[i]);
      return;
    }
  }
  
  fprintf(stderr,"Pass!\n");

}

// void check_Z(int flag , DComplex *A, DComplex *B, int length, int M, int N, int L){
//   int i;
  
//   fprintf(stderr,"Check 3D%d Dcomplex: ",flag);

//   for(i = 0; i < length; i ++)
//   {
//     DComplex t = A[i]-B[i];
//     if(creal(t) > 1e-8 || creal(t) < -1e-8 || cimag(t) > 1e-8 || cimag(t) < -1e-8)
//     {
//       fprintf(stderr,"Warning: The first wrong %d(%d,%d,%d)(%.16lf+%.16lfi %.16lf+%.16lfi)\n", i, i/(N*L), (i/L)%N, i%L, creal(A[i]) , cimag(A[i]), creal(B[i]) , cimag(B[i]));
//       return;
//     }
//   }
  
//   fprintf(stderr,"Pass!\n");

// }

// void check_C(int flag , SComplex *A, SComplex *B, int length, int M, int N, int L){
//   int i;
  
//   fprintf(stderr,"Check 3D%d SComplex: ",flag);

//   for(i = 0; i < length; i ++)
//   {
//     SComplex t = A[i]-B[i];
//     if(creal(t) > 1e-6 || creal(t) < -1e-6 || cimag(t) > 1e-6 || cimag(t) < -1e-6)
//     {
//       fprintf(stderr,"Warning: The first wrong %d(%d,%d,%d)(%.16lf+%.16lfi %.16lf+%.16lfi)\n", i, i/(N*L), (i/L)%N, i%L, creal(A[i]) , cimag(A[i]), creal(B[i]) , cimag(B[i]));
//       return;
//     }
//   }
  
//   fprintf(stderr,"Pass!\n");

// }

int Init_Pos(int *pos , int rnnz , int flag){

  int det[7]={0,1,-1,2,-2,3,-3};
  int all_pos[1500];
  int done[400];
  int i,j,k,p,d,x,me;

  p=0;

  for (i = 0 ; i<3 ; i++)
    for (j = 0 ; j<3 ; j++)
      for (k = 0 ; k<3 ; k++){
        all_pos[p*3] = det[i];
        all_pos[p*3 + 1] = det[j];
        all_pos[p*3 + 2] = det[k];
        p++;
  }

  for (i = 0 ; i<5 ; i++)
    for (j = 0 ; j<5 ; j++)
      for (k = 0 ; k<5 ; k++){
        if (i<3 && j<3 && k<3) continue;
        all_pos[p*3] = det[i];
        all_pos[p*3 + 1] = det[j];
        all_pos[p*3 + 2] = det[k];
        p++;
  }

  for (i = 0 ; i<7 ; i++)
    for (j = 0 ; j<7 ; j++)
      for (k = 0 ; k<7 ; k++){
        if (i<5 && j<5 && k<5) continue;
        all_pos[p*3] = det[i];
        all_pos[p*3 + 1] = det[j];
        all_pos[p*3 + 2] = det[k];
        p++;
  }

  memset(done , 0 , sizeof(done));
  d = 0;
  srand((unsigned)time(NULL));

  if (flag){
    for (i=0 ; i<MIN(27,rnnz) ; i++){
      x = rand() % 27;
      while (done[x]) x = rand() % 27;
      done[x] = 1;
      pos[i * 3] =  all_pos[x * 3];
      pos[i * 3 + 1] =  all_pos[x * 3 + 1];
      pos[i * 3 + 2] =  all_pos[x * 3 + 2];
    }

    if (rnnz >27){

      for (i=27 ; i<MIN(125,rnnz) ; i++){
        x = rand() % 125;
        while (done[x]) x = rand() % 125;
        done[x] = 1;
        pos[i * 3] =  all_pos[x * 3];
        pos[i * 3 + 1] =  all_pos[x * 3 + 1];
        pos[i * 3 + 2] =  all_pos[x * 3 + 2];
      }
    }

    if (rnnz >125){

      for (i=125 ; i<rnnz ; i++){
        x = rand() % 343;
        while (done[x]) x = rand() % 343;
        done[x] = 1;
        pos[i * 3] =  all_pos[x * 3];
        pos[i * 3 + 1] =  all_pos[x * 3 + 1];
        pos[i * 3 + 2] =  all_pos[x * 3 + 2];
      }
    }

  }
  else{
    for (i=0 ; i<rnnz ; i++){
      x = rand() % 343;
      while (done[x]) x = rand() % 343;
      done[x] = 1;
      pos[i * 3] =  all_pos[x * 3];
      pos[i * 3 + 1] =  all_pos[x * 3 + 1];
      pos[i * 3 + 2] =  all_pos[x * 3 + 2];
    }
  }

  for (i = 0 ; i < rnnz ; i++)
    if (pos[i*3] == 0 && pos[i*3+1] == 0 && pos[i*3+2] == 0){
      me = i;
      break;
    }

  return me;

}

void Print_To_File_P(char *fn , int rnnz , int *pos){

  char filename[100] = "";
  int i,j,k,n,l;
  


  l = strlen(fn);
  for (i = 0 ; i < l ; i++) filename[i] = fn[i];
  filename[l++] = '_';
  filename[l++] = 'P';
  filename[l++] = '.';
  filename[l++] = 't';
  filename[l++] = 'x';
  filename[l++] = 't';

  freopen(filename , "w" , stdout);
  printf("%d\n",rnnz);
  for (i=0;i<rnnz;i++) printf("%d %d %d\n",pos[i*3] , pos[i*3+1] , pos[i*3+2]);
  fclose(stdout);

}

void Print_To_File_D(char *fn , int m , int n , int l ,int rnnz , double *a , double *x , double *b){

  char fna[100] = "" , fnb[100] = "" , fnx[100] = "";
  int i,j,k,len;

  len = strlen(fn);
  for (i = 0 ; i < len ; i++) fna[i] = fnx[i] = fnb[i] = fn[i];

  fna[len++] = '_';
  fna[len++] = 'A';
  fna[len++] = '_';
  fna[len++] = 'D';
  fna[len++] = '.';
  fna[len++] = 't';
  fna[len++] = 'x';
  fna[len++] = 't';

  

  freopen(fna , "w" , stdout);
  printf("%d %d %d %d\n" , m,n,l,rnnz);
  for (i = 0 ; i < m*n*l*rnnz - 1 ; i++) printf("%.16f ",a[i]);
  printf("%.16f\n",a[m*n*l*rnnz - 1]);
  fclose(stdout);
  
  len = strlen(fn);
  fnb[len++] = '_';
  fnb[len++] = 'B';
  fnb[len++] = '_';
  fnb[len++] = 'D';
  fnb[len++] = '.';
  fnb[len++] = 't';
  fnb[len++] = 'x';
  fnb[len++] = 't';

  freopen(fnb , "w" , stdout);
  printf("%d %d %d\n" , m,n,l);
  for (i = 0 ; i < m*n*l - 1 ; i++) printf("%.16f ",b[i]);
  printf("%.16f\n",b[m*n*l - 1]);
  fclose(stdout);
  
  len = strlen(fn);
  fnx[len++] = '_';
  fnx[len++] = 'X';
  fnx[len++] = '_';
  fnx[len++] = 'D';
  fnx[len++] = '.';
  fnx[len++] = 't';
  fnx[len++] = 'x';
  fnx[len++] = 't';

  freopen(fnx , "w" , stdout);
  printf("%d %d %d\n" , m,n,l);
  for (i = 0 ; i < m*n*l - 1 ; i++) printf("%.16f ",x[i]);
  printf("%.16f\n",x[m*n*l - 1]);
  fclose(stdout);

}

void Print_To_File_S(char *fn , int m , int n , int l ,int rnnz , float *a , float *x , float *b){

  char fna[100] = "" , fnb[100] = "" , fnx[100] = "";
  int i,j,k,len;

  len = strlen(fn);
  for (i = 0 ; i < len ; i++) fna[i] = fnx[i] = fnb[i] = fn[i];

  fna[len++] = '_';
  fna[len++] = 'A';
  fna[len++] = '_';
  fna[len++] = 'S';
  fna[len++] = '.';
  fna[len++] = 't';
  fna[len++] = 'x';
  fna[len++] = 't';

  

  freopen(fna , "w" , stdout);
  printf("%d %d %d %d\n" , m,n,l,rnnz);
  for (i = 0 ; i < m*n*l*rnnz - 1 ; i++) printf("%.8f ",a[i]);
  printf("%.8f\n",a[m*n*l*rnnz - 1]);
  fclose(stdout);
  
  len = strlen(fn);
  fnb[len++] = '_';
  fnb[len++] = 'B';
  fnb[len++] = '_';
  fnb[len++] = 'S';
  fnb[len++] = '.';
  fnb[len++] = 't';
  fnb[len++] = 'x';
  fnb[len++] = 't';

  freopen(fnb , "w" , stdout);
  printf("%d %d %d\n" , m,n,l);
  for (i = 0 ; i < m*n*l - 1 ; i++) printf("%.8f ",b[i]);
  printf("%.8f\n",b[m*n*l - 1]);
  fclose(stdout);
  
  len = strlen(fn);
  fnx[len++] = '_';
  fnx[len++] = 'X';
  fnx[len++] = '_';
  fnx[len++] = 'S';
  fnx[len++] = '.';
  fnx[len++] = 't';
  fnx[len++] = 'x';
  fnx[len++] = 't';

  freopen(fnx , "w" , stdout);
  printf("%d %d %d\n" , m,n,l);
  for (i = 0 ; i < m*n*l - 1 ; i++) printf("%.8f ",x[i]);
  printf("%.8f\n",x[m*n*l - 1]);
  fclose(stdout);

}

// void Print_To_File_Z(char *fn , int m , int n , int l ,int rnnz , DComplex *a , DComplex *x , DComplex *b){

//   char fna[100] = "" , fnb[100] = "", fnx[100] = "";
//   int i,j,k,len;

//   len = strlen(fn);
//   for (i = 0 ; i < len ; i++) fna[i] = fnx[i] = fnb[i] = fn[i];

//   fna[len++] = '_';
//   fna[len++] = 'A';
//   fna[len++] = '_';
//   fna[len++] = 'Z';
//   fna[len++] = '.';
//   fna[len++] = 't';
//   fna[len++] = 'x';
//   fna[len++] = 't';

//   freopen(fna , "w" , stdout);
//   printf("%d %d %d %d\n" , m,n,l,rnnz);
//   for (i = 0 ; i < m*n*l*rnnz - 1 ; i++) printf("%.16f %.16f ",creal(a[i]) , cimag(a[i]));
//   printf("%.16f %.16f\n",creal(a[m*n*l*rnnz - 1]) , cimag(a[m*n*l*rnnz - 1]) );
//   fclose(stdout);
  
//   len = strlen(fn);
//   fnb[len++] = '_';
//   fnb[len++] = 'B';
//   fnb[len++] = '_';
//   fnb[len++] = 'Z';
//   fnb[len++] = '.';
//   fnb[len++] = 't';
//   fnb[len++] = 'x';
//   fnb[len++] = 't';

//   freopen(fnb , "w" , stdout);
//   printf("%d %d %d\n" , m,n,l);
//   for (i = 0 ; i < m*n*l - 1 ; i++) printf("%.16f %.16f ",creal(b[i]) , cimag(b[i]) );
//   printf("%.16f %.16f\n",creal(b[m*n*l - 1]) , cimag(b[m*n*l - 1]) );
//   fclose(stdout);
  
//   len = strlen(fn);
//   fnx[len++] = '_';
//   fnx[len++] = 'X';
//   fnx[len++] = '_';
//   fnx[len++] = 'Z';
//   fnx[len++] = '.';
//   fnx[len++] = 't';
//   fnx[len++] = 'x';
//   fnx[len++] = 't';

//   freopen(fnx , "w" , stdout);
//   printf("%d %d %d\n" , m,n,l);
//   for (i = 0 ; i < m*n*l - 1 ; i++) printf("%.16f %.16f ",creal(x[i]) , cimag(x[i]));
//   printf("%.16f %.16f\n",creal(x[m*n*l - 1]) ,cimag(x[m*n*l - 1]) );
//   fclose(stdout);
// }

// void Print_To_File_C(char *fn , int m , int n , int l ,int rnnz , SComplex *a , SComplex *x , SComplex *b){

//   char fna[100] = "", fnb[100] = "" , fnx[100] = "";
//   int i,j,k,len;

//   len = strlen(fn);
//   for (i = 0 ; i < len ; i++) fna[i] = fnx[i] = fnb[i] = fn[i];

//   fna[len++] = '_';
//   fna[len++] = 'A';
//   fna[len++] = '_';
//   fna[len++] = 'C';
//   fna[len++] = '.';
//   fna[len++] = 't';
//   fna[len++] = 'x';
//   fna[len++] = 't';

//   freopen(fna , "w" , stdout);
//   printf("%d %d %d %d\n" , m,n,l,rnnz);
//   for (i = 0 ; i < m*n*l*rnnz - 1 ; i++) printf("%.8f %.8f ",creal(a[i]) , cimag(a[i]));
//   printf("%.8f %.8f\n",creal(a[m*n*l*rnnz - 1]) , cimag(a[m*n*l*rnnz - 1]) );
//   fclose(stdout);
  
//   len = strlen(fn);
//   fnb[len++] = '_';
//   fnb[len++] = 'B';
//   fnb[len++] = '_';
//   fnb[len++] = 'C';
//   fnb[len++] = '.';
//   fnb[len++] = 't';
//   fnb[len++] = 'x';
//   fnb[len++] = 't';

//   freopen(fnb , "w" , stdout);
//   printf("%d %d %d\n" , m,n,l);
//   for (i = 0 ; i < m*n*l - 1 ; i++) printf("%.8f %.8f ",creal(b[i]) , cimag(b[i]) );
//   printf("%.8f %.8f\n",creal(b[m*n*l - 1]) , cimag(b[m*n*l - 1]) );
//   fclose(stdout);
  
//   len = strlen(fn);
//   fnx[len++] = '_';
//   fnx[len++] = 'X';
//   fnx[len++] = '_';
//   fnx[len++] = 'C';
//   fnx[len++] = '.';
//   fnx[len++] = 't';
//   fnx[len++] = 'x';
//   fnx[len++] = 't';

//   freopen(fnx , "w" , stdout);
//   printf("%d %d %d\n" , m,n,l);
//   for (i = 0 ; i < m*n*l - 1 ; i++) printf("%.8f %.8f ",creal(x[i]) , cimag(x[i]));
//   printf("%.8f %.8f\n",creal(x[m*n*l - 1]) ,cimag(x[m*n*l - 1]) );
//   fclose(stdout);
// }

void SpMV_MPE_Do_D(double *aa, double *X, double *B, int MM, int NN, int LL, int M, int N, int L , int rnnz , int *pos){
  int i, j, k,p;
  int offset;

  for ( i = 0; i < MM; i ++ )
  {
    for ( j = 0; j < NN; j ++ )
    {
      for ( k = 0; k < LL; k ++ )
      {
        double result = 0;
        offset = rnnz*(i*NN*LL+j*LL+k);
        for ( p = 0 ; p < rnnz ; p++) {
          result += aa[offset + p] * X[(i+pos[p*3])*N*L+(j+pos[p*3+1])*L+(k+pos[p*3+2])];
          if (i == 0 && j == 0 && k == 2)
            printf("B= %.2f A= %.2f X[%d][%d][%d]=%.2f\n",result,aa[offset + p],i+pos[p*3],j+pos[p*3+1],k+pos[p*3+2],X[(i+pos[p*3])*N*L+(j+pos[p*3+1])*L+(k+pos[p*3+2])]);
        }
        B[i*NN*LL+j*LL+k] = result;
      }
    }
  }
}

void SpMV_MPE_D(double *A, double *xx, double *bb, int M, int N, int L , int rnnz , int *pos){

  // int M = MM + 6;
  // int N = NN + 6;
  // int L = LL + 6;
  
  int i,j,k,p;
  int ii,jj,kk;
  int offset;
  double result;
  
  for (i = 0 ; i < M ; i++){
    for (j = 0 ;j < N ; j++){
      for (k = 0 ; k < L ; k++){
        offset = i * N * L + j * L + k;
        result = 0;
        for ( p = 0 ; p < rnnz ; p++){
          if ( 0<= i+pos[p*3] && i+pos[p*3]<M && 0<=j+pos[p*3+1] && j+pos[p*3+1] < N && 0<=k+pos[p*3+2] && k+pos[p*3+2]<L){
            result += A[offset + p] * xx[(i+pos[p*3])*N*L+(j+pos[p*3+1])*L+(k+pos[p*3+2])]; 
          }
          // if (i == 0 && j == 0 && k == 2)
          //   printf("B= %.2f A= %.2f X[%d][%d][%d]=%.2f\n",result,A[offset + p],i+pos[p*3],j+pos[p*3+1],k+pos[p*3+2],xx[(i+pos[p*3])*N*L+(j+pos[p*3+1])*L+(k+pos[p*3+2])]);
        }
        bb[i*N*L+j*L+k] = result;


      }
    }
  }
 
}

void SpMV_MPE_Do_S(float *aa, float *X, float *B, int MM, int NN, int LL, int M, int N, int L , int rnnz , int *pos){
  int i, j, k,p;
  int offset;
  for ( i = 0; i < MM; i ++ )
  {
    for ( j = 0; j < NN; j ++ )
    {
      for ( k = 0; k < LL; k ++ )
      {
        float result = 0;
        offset = rnnz*(i*NN*LL+j*LL+k);
        for ( p = 0 ; p < rnnz ; p++) {
          result += aa[offset + p] * X[(i+pos[p*3])*N*L+(j+pos[p*3+1])*L+(k+pos[p*3+2])];
        }
        B[i*NN*LL+j*LL+k] = result;
      }
    }
  }
}

void SpMV_MPE_S(float *A, float *xx, float *bb, int MM, int NN, int LL , int rnnz , int *pos){

  int M = MM + 6;
  int N = NN + 6;
  int L = LL + 6;
  
  float *X   = swSparse_malloc(M * N * L * sizeof(float));   

  int i,j,k,p;
  int offset;
  
  Init_Zero_S(X  , M * N * L);
   
  for(i = 1 + 2; i <= MM + 2; i ++){
    for(j = 1 + 2; j <= NN + 2; j ++){
      for(k = 1 + 2; k <= LL + 2; k ++){
        
        offset = i * N * L + j * L + k;
        X [offset] = xx[ (i-3) * NN * LL + (j-3) * LL + (k-3) ];
     
      }
    }
  }

  SpMV_MPE_Do_S(A, X+3*N*L+3*L+3, bb , MM, NN, LL, M, N, L , rnnz , pos);
 
  swSparse_free(X);

}

// void SpMV_MPE_Do_Z(DComplex *aa, DComplex *X, DComplex *B, int MM, int NN, int LL, int M, int N, int L , int rnnz , int *pos){
//   int i, j, k,p;
//   int offset;
//   for ( i = 0; i < MM; i ++ )
//   {
//     for ( j = 0; j < NN; j ++ )
//     {
//       for ( k = 0; k < LL; k ++ )
//       {
//         DComplex result = 0;
//         offset = rnnz*(i*NN*LL+j*LL+k);
//         for ( p = 0 ; p < rnnz ; p++) {
//           result += aa[offset + p] * X[(i+pos[p*3])*N*L+(j+pos[p*3+1])*L+(k+pos[p*3+2])];
//         }
//         B[i*NN*LL+j*LL+k] = result;
//       }
//     }
//   }
// }

// void SpMV_MPE_Z(DComplex *A, DComplex *xx, DComplex *bb, int MM, int NN, int LL , int rnnz , int *pos){

//   int M = MM + 6;
//   int N = NN + 6;
//   int L = LL + 6;
  
//   DComplex *X   = swSparse_malloc(M * N * L * sizeof(DComplex));   

//   int i,j,k,p;
//   int offset;
  
//   Init_Zero_Z(X  , M * N * L);
   
//   for(i = 1 + 2; i <= MM + 2; i ++){
//     for(j = 1 + 2; j <= NN + 2; j ++){
//       for(k = 1 + 2; k <= LL + 2; k ++){
        
//         offset = i * N * L + j * L + k;
//         X [offset] = xx[ (i-3) * NN * LL + (j-3) * LL + (k-3) ];
     
//       }
//     }
//   }

//   SpMV_MPE_Do_Z(A, X+3*N*L+3*L+3, bb , MM, NN, LL, M, N, L , rnnz , pos);
 
//   swSparse_free(X);

// }

// void SpMV_MPE_Do_C(SComplex *aa, SComplex *X, SComplex *B, int MM, int NN, int LL, int M, int N, int L , int rnnz , int *pos){
//   int i, j, k,p;
//   int offset;
//   for ( i = 0; i < MM; i ++ )
//   {
//     for ( j = 0; j < NN; j ++ )
//     {
//       for ( k = 0; k < LL; k ++ )
//       {
//         SComplex result = 0;
//         offset = rnnz*(i*NN*LL+j*LL+k);
//         for ( p = 0 ; p < rnnz ; p++) {
//           result += aa[offset + p] * X[(i+pos[p*3])*N*L+(j+pos[p*3+1])*L+(k+pos[p*3+2])];
//         }
//         B[i*NN*LL+j*LL+k] = result;
//       }
//     }
//   }
// }

// void SpMV_MPE_C(SComplex *A, SComplex *xx, SComplex *bb, int MM, int NN, int LL , int rnnz , int *pos){

//   int M = MM + 6;
//   int N = NN + 6;
//   int L = LL + 6;
  
//   SComplex *X   = swSparse_malloc(M * N * L * sizeof(SComplex));   

//   int i,j,k,p;
//   int offset;
  
//   Init_Zero_C(X  , M * N * L);
   
//   for(i = 1 + 2; i <= MM + 2; i ++){
//     for(j = 1 + 2; j <= NN + 2; j ++){
//       for(k = 1 + 2; k <= LL + 2; k ++){
        
//         offset = i * N * L + j * L + k;
//         X [offset] = xx[ (i-3) * NN * LL + (j-3) * LL + (k-3) ];
     
//       }
//     }
//   }

//   SpMV_MPE_Do_C(A, X+3*N*L+3*L+3, bb , MM, NN, LL, M, N, L , rnnz , pos);
 
//   swSparse_free(X);

// }

int main(int argc, char **argv){


  swSparseErrorStatus ret = SWSPARSE_SUCCESS;

  struct timeval t1, t2;
  int l,m,n,rnnz;
  int i,j,k;
  double real_mem,computer_size;
  int max_mn,max_l;
  int me;
  double tm,ts;

  char fn[100] = "struct_data/1d3";

  l = 100;
  m = 100;
  n = 100;

  srand((unsigned)time(NULL));


  
  #ifdef RfF
    freopen("struct_data/1d3_P_spmv_D.txt","r",stdin);
    scanf("%d",&rnnz);
    int *pos = malloc(rnnz * 3 * sizeof(int));
    for (i=0;i<rnnz;i++) {
      scanf("%d %d %d",&pos[i*3] , &pos[i*3+1] , &pos[i*3+2]);
      if (pos[i*3] == 0 && pos[i*3+1] == 0 && pos[i*3+2] == 0) me = i;
    }
  #else
     rnnz = 343;
     int *pos = malloc(rnnz * 3 * sizeof(int));
     me = Init_Pos(pos,rnnz,1);
  #endif
  
      

  //Print_To_File_P(fn,rnnz , pos);

  #ifdef PtF
    Print_To_File_P(fn,rnnz , pos);
  #endif  
  

  int inpos[rnnz][3];
  int dim[3];

  dim[0] = m;
  dim[1] = n;
  dim[2] = l;

  for (i=0 ; i<rnnz ; i++){
    inpos[i][0] = pos[i * 3];
    inpos[i][1] = pos[i * 3 + 1];
    inpos[i][2] = pos[i * 3 + 2];
  } 




  max_mn = 0;
  max_l  = 0;
  for (i=0;i<rnnz;i++){
    max_mn = MAX( max_mn , MAX( abs(pos[i*3]) , abs(pos[i*3+1]) ) );
    max_l  = MAX( max_l , abs(pos[i*3 + 2]) );
  }

  computer_size = 0.000000001 * (m*n*l*rnnz*2);

  if (max_mn <=1){
    real_mem = (( (n + 7) / 8 ) * ( (m + 7) / 8 ) * 10 * 10 * l + m * n * l + m * n * l * rnnz  )  * sizeof(double);
    real_mem *= 0.000001;
  }
  else if (max_mn <=2){
    real_mem = (( (n + 7) / 8 ) * ( (m + 7) / 8 ) * 12 * 12 * l  + m * n * l + m * n * l * rnnz )* sizeof(double);
    real_mem *= 0.000001;
  }
  else{
    real_mem = ( ( (n + 7) / 8 ) * ( (m + 7) / 8 ) * 14 * 14 * l  + m * n * l + m * n *l *rnnz) * sizeof(double);
    real_mem *= 0.000001;    
  }

  real_mem = (n*m*l*(rnnz+2)) * sizeof(double) * 0.000001;

  athread_init();
  
  // Double -------------------------------------------------------------------------

  // double *A  = malloc(rnnz * l * m * n * sizeof(double));
  // double *X  = malloc(l * m * n * sizeof(double));
  // double *B0 = malloc(l * m * n * sizeof(double));
  // double *B1 = malloc(l * m * n * sizeof(double));

  __attribute__ ((aligned(256))) double A[rnnz * l * m * n];
  __attribute__ ((aligned(256))) double X[l * m * n];
  __attribute__ ((aligned(256))) double B0[l * m * n];
  __attribute__ ((aligned(256))) double B1[l * m * n];

  
  Init(A , rnnz * l * m * n,1);
  
  #ifdef DIA
    A[me] *=-1;
    for (i = 0 ; i < m*n*l*rnnz ; i++) A[me] += A[i];
    A[me] *=2; 
  #endif

  Init(X , l * m * n,0);
  
  Init_Zero(B0 , m * n * l);
  Init_Zero(B1 , m * n * l); 
  
  fprintf(stderr,"Double:\n");

  gettimeofday(&t1, NULL);
  SpMV_MPE_D(A,X,B0,m,n,l,rnnz,pos);
  gettimeofday(&t2, NULL);
  tm = TIME(t1,t2);
  fprintf(stderr,"<Master> Time: %.6lfs\n",TIME(t1,t2));

  gettimeofday(&t1, NULL);
  swSparse_d_struct_mv(1, A , X , 0, B1 , dim , rnnz , (int*)inpos);
  gettimeofday(&t2, NULL);
  ts = TIME(t1,t2);
  fprintf(stderr,"<Slave> Time: %.6lfs\n",TIME(t1,t2));
  fprintf(stderr,"acc %.4f real_mem %.4f MB/s %.4f Gflops \n" ,tm/ts ,  real_mem / TIME(t1,t2) , computer_size / TIME(t1,t2)); 
   

  check_D(rnnz,B0,B1,m*n*l , m , n , l);

 
  #ifdef PtF
    Print_To_File_D(fn , m,n,l,rnnz,A,X,B0);
  #endif

  free(A);
  free(X);
  free(B0);
  free(B1);

  //Single --------------------------------------------------------------------------------------------------

  // float *As  = malloc(rnnz * l * m * n * sizeof(float));
  // float *Xs  = malloc(l * m * n * sizeof(float));
  // float *B0s = malloc(l * m * n * sizeof(float));
  // float *B1s = malloc(l * m * n * sizeof(float));
  
  // Init_S(As , rnnz * l * m * n);

  // #ifdef DIA
  //   As[me] *=-1;
  //   for (i = 0 ; i < m*n*l*rnnz ; i++) As[me] += As[i];
  //   As[me] *=2; 
  // #endif

  // Init_S(Xs , l * m * n);
  
  // Init_Zero_S(B0s , m * n * l);
  // Init_Zero_S(B1s , m * n * l); 
  
  // fprintf(stderr,"Single:\n");

  // gettimeofday(&t1, NULL);
  // SpMV_MPE_S(As,Xs,B0s,m,n,l,rnnz,pos);
  // gettimeofday(&t2, NULL);
  // fprintf(stderr,"<Master> Time: %.6lfs\n",TIME(t1,t2));
  // tm = TIME(t1,t2);

  // gettimeofday(&t1, NULL);
  // swSparse_s_struct_mv(1, As, Xs, 0, B1s, dim, rnnz, inpos);
  // gettimeofday(&t2, NULL);
  // fprintf(stderr,"<Slave> Time: %.6lfs\n",TIME(t1,t2));
  // ts = TIME(t1,t2);
  // fprintf(stderr,"acc %.4f real_mem %.4f MB/s %.4f Gflops \n" ,tm/ts , real_mem / TIME(t1,t2) , computer_size / TIME(t1,t2)); 
  
  // check_S(rnnz,B0s,B1s,m*n*l , m , n , l);


  // #ifdef PtF
  //   Print_To_File_S(fn , m,n,l,rnnz,As,Xs,B0s);
  // #endif  

  // free(As);
  // free(Xs);
  // free(B0s);
  // free(B1s);
  
  /*

  //DComplex --------------------------------------------------------------------------------------------------

  DComplex *Az  = malloc(rnnz * l * m * n * sizeof(DComplex));
  DComplex *Xz  = malloc(l * m * n * sizeof(DComplex));
  DComplex *B0z = malloc(l * m * n * sizeof(DComplex));
  DComplex *B1z = malloc(l * m * n * sizeof(DComplex));
  
  Init_Z(Az , rnnz * l * m * n);
  
  #ifdef DIA
    Az[me] *=-1;
    for (i = 0 ; i < m*n*l*rnnz ; i++) Az[me] += Az[i];
    Az[me] *=2; 
  #endif

  Init_Z(Xz , l * m * n);
  
  Init_Zero_Z(B0z , m * n * l);
  Init_Zero_Z(B1z , m * n * l); 
  
  fprintf(stderr,"DComplex:\n");

  gettimeofday(&t1, NULL);
  SpMV_MPE_Z(Az,Xz,B0z,m,n,l,rnnz,pos);
  gettimeofday(&t2, NULL);
  fprintf(stderr,"<Master> Time: %.6lfs\n",TIME(t1,t2));
  tm = TIME(t1,t2);

  gettimeofday(&t1, NULL);
  swSparse_z_struct_mv(Az , Xz , B1z , dim , rnnz , inpos);
  gettimeofday(&t2, NULL);
  fprintf(stderr,"<Slave> Time: %.6lfs\n",TIME(t1,t2));
  ts = TIME(t1,t2);
  fprintf(stderr,"acc %.4f real_mem %.4f MB/s %.4f Gflops \n" ,tm/ts ,  real_mem / TIME(t1,t2) , computer_size / TIME(t1,t2)); 
  
  check_Z(rnnz,B0z,B1z,m*n*l , m , n , l);

  #ifdef PtF
    Print_To_File_Z(fn , m,n,l,rnnz,Az,Xz,B0z);
  #endif  


  free(Az);
  free(Xz);
  free(B0z);
  free(B1z);

  //SComplex -------------------------------------------------------------------------------------------------------  
  
  SComplex *Ac  = malloc(rnnz * l * m * n * sizeof(SComplex));
  SComplex *Xc  = malloc(l * m * n * sizeof(SComplex));
  SComplex *B0c = malloc(l * m * n * sizeof(SComplex));
  SComplex *B1c = malloc(l * m * n * sizeof(SComplex));
  
  Init_C(Ac , rnnz * l * m * n);
  #ifdef DIA
    Ac[me] *=-1;
    for (i = 0 ; i < m*n*l*rnnz ; i++) Ac[me] += Ac[i];
    Ac[me] *=2; 
  #endif

  Init_C(Xc , l * m * n);
  
  Init_Zero_C(B0c , m * n * l);
  Init_Zero_C(B1c , m * n * l); 
  
  fprintf(stderr,"SComplex:\n");

  gettimeofday(&t1, NULL);
  SpMV_MPE_C(Ac,Xc,B0c,m,n,l,rnnz,pos);
  gettimeofday(&t2, NULL);
  fprintf(stderr,"<Master> Time: %.6lfs\n",TIME(t1,t2));
  tm = TIME(t1,t2);

  gettimeofday(&t1, NULL);
  swSparse_c_struct_mv(Ac , Xc , B1c , dim , rnnz , inpos);
  gettimeofday(&t2, NULL);
  fprintf(stderr,"<Slave> Time: %.6lfs\n",TIME(t1,t2));
  ts = TIME(t1,t2);
  fprintf(stderr,"acc %.4f real_mem %.4f MB/s %.4f Gflops \n" ,tm/ts , real_mem / TIME(t1,t2) , computer_size / TIME(t1,t2)); 
  
  check_C(rnnz,B0c,B1c,m*n*l , m , n , l);

  #ifdef PtF
    Print_To_File_C(fn , m,n,l,rnnz,Ac,Xc,B0c);
  #endif

  free(Ac);
  free(Xc);
  free(B0c);
  free(B1c);

  //----------------------------------------------------------------------------------------------------------------
  */
   return 0;

}
