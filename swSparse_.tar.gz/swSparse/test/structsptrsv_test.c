#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <time.h>
#include "math.h"
#ifndef NO_CPE
#include <athread.h>
#endif
#include "swSparse.h"
#include "test.h"

#define MISTAKE  1e-11
#define TIME(a,b) (1.0*((b).tv_sec-(a).tv_sec)+0.000001*((b).tv_usec-(a).tv_usec))

#define N_MATRICES 12

#define INDEX3(i, j, k, N, L) ((i)*(N)*(L) + (j)*(L) + (k))
#define VALID(i, j, k, M, N, L) \
    ((i) >= 0 && (i) < (M) && (j) >= 0 && (j) < (N) && (k) >= 0 && (k) < (L))

void init_and_rand(data_t *a, int size)
{
    int i;
    for (i = 0; i < size; i++)
        a[i] = (data_t)rand() / RAND_MAX / 3;
}

void init_and_zero(data_t *a, int size)
{
    int i;
    for (i = 0; i < size; i++)
        a[i] = 0.0;
}

int check(data_t *a, data_t *b, int size)
{
    int i;
    for (i = 0; i < size; i++)
        if (fabs(a[i] - b[i]) > MISTAKE) return i;
    return -1;
}

static void print_x_first_n(const char *label, const data_t *x,
    int M, int N, int L, int n)
{
    int total = M * N * L;
    int count = (n < total) ? n : total;
    int idx;
    printf("  %-12s (first %d):\n    ", label, count);
    for (idx = 0; idx < count; idx++)
    {
        int i = idx / (N * L);
        int j = (idx / L) % N;
        int k = idx % L;
        printf("(%d,%d,%d):% .6g  ", i, j, k, x[idx]);
        if ((idx + 1) % 5 == 0 && idx < count - 1)
            printf("\n    ");
    }
    printf("\n");
}

static int struct_sptrsv_sequential_forward(const data_t *a, data_t *x,
    const data_t *b, const int dim[3], int nnz, const int (*pos)[3])
{
    int i, j, k, u;
    int M = dim[0], N = dim[1], L = dim[2];
    for (i = 0; i < M; i++)
    for (j = 0; j < N; j++)
    for (k = 0; k < L; k++)
    {
        data_t tmp = 0.0;
        int aoff = nnz * INDEX3(i, j, k, N, L);
        for (u = 0; u < nnz; u++)
        {
            int ti = i + pos[u][0];
            int tj = j + pos[u][1];
            int tk = k + pos[u][2];
            if (VALID(ti, tj, tk, M, N, L))
                tmp += a[aoff + u] * x[INDEX3(ti, tj, tk, N, L)];
        }
        x[INDEX3(i, j, k, N, L)] = b[INDEX3(i, j, k, N, L)] - tmp;
    }
    return 0;
}

static double run_swsptrsv(const data_t *a, const data_t *b, data_t *x,
    int M, int N, int L, int nnz, int (*pos)[3])
{
    int total_pts = M * N * L;
    int i, j, k, u;

    int *row_offsets = (int*)malloc((total_pts + 1) * sizeof(int));
    int *col_indices = (int*)malloc((size_t)total_pts * (nnz + 1) * sizeof(int));
    data_t *csr_vals = (data_t*)malloc((size_t)total_pts * (nnz + 1) * sizeof(data_t));

    int idx = 0;
    row_offsets[0] = 0;

    for (i = 0; i < M; i++)
    for (j = 0; j < N; j++)
    for (k = 0; k < L; k++)
    {
        int row = INDEX3(i, j, k, N, L);
        int aoff = nnz * row;

        for (u = 0; u < nnz; u++)
        {
            int ti = i + pos[u][0];
            int tj = j + pos[u][1];
            int tk = k + pos[u][2];
            if (VALID(ti, tj, tk, M, N, L) && !(ti == i && tj == j && tk == k))
            {
                col_indices[idx] = INDEX3(ti, tj, tk, N, L);
                csr_vals[idx] = a[aoff + u];
                idx++;
            }
        }
        col_indices[idx] = row;
        csr_vals[idx] = 1.0;
        idx++;
        row_offsets[row + 1] = idx;
    }
    int csr_nnz = idx;

    swSparseMatrix mat, csc;
    swSparse_d_create_csr(&mat, total_pts, total_pts, csr_nnz,
                          row_offsets, col_indices, csr_vals);
    free(row_offsets);
    free(col_indices);
    free(csr_vals);

    swSparseInt *perm  = (swSparseInt*)malloc(total_pts * sizeof(swSparseInt));
    swSparseInt *iperm = (swSparseInt*)malloc(total_pts * sizeof(swSparseInt));

    swSparseTRSVOptions opts = SWSPARSE_TRSV_OPTION_INITIALIZER;
    for (u = 0; u < nnz; u++) {
        if (pos[u][0] > 0) {
            opts.uplo = SWSPARSE_UPPER_TRI;
            break;
        }
    }
    swSparse_trsv_inspect(mat, &csc, perm, iperm, &opts);
    if (mat != csc)
    {
        swSparse_destroy(mat);
        mat = csc;
    }

    data_t *b_add = (data_t*)malloc(total_pts * sizeof(data_t));
    data_t *x_add = (data_t*)malloc(total_pts * sizeof(data_t));
    swSparse_d_iperm_apply(total_pts, b, b_add, iperm);

    struct timeval st, ed;
    gettimeofday(&st, NULL);
    swSparse_d_trsv_execute(1.0, mat, b_add, x_add, &opts);
    gettimeofday(&ed, NULL);
    double elapsed = TIME(st, ed);

    swSparse_d_iperm_apply(total_pts, x_add, x, perm);

    free(b_add);
    free(x_add);
    free(perm);
    free(iperm);
    swSparse_destroy(mat);

    return elapsed;
}

int main()
{
    int i;
    FILE *fp = fopen("input.struct", "r");
    if (!fp)
    {
        printf("Cannot open input.struct\n");
        return 1;
    }

    athread_init();

    int    sizes[N_MATRICES][3];
    int    nnzs[N_MATRICES];
    double t_pure[N_MATRICES];
    double t_swstruct[N_MATRICES];
    double t_swsptrsv[N_MATRICES];
    double t_struct[N_MATRICES];
    int    struct_ok[N_MATRICES];
    int    valid_count = 0;

    while (valid_count < N_MATRICES)
    {
        int M, N, L, nnz;
        if (fscanf(fp, "%d%d%d%d", &M, &N, &L, &nnz) != 4) break;
        if (nnz <= 0 || M <= 0 || N <= 0 || L <= 0) continue;

        int (*p)[3] = (int(*)[3])malloc(nnz * sizeof(int[3]));
        for (i = 0; i < nnz; i++)
            fscanf(fp, "%d%d%d", &p[i][0], &p[i][1], &p[i][2]);

        int dim[3] = {M, N, L};
        int total_pts = M * N * L;

        sizes[valid_count][0] = M;
        sizes[valid_count][1] = N;
        sizes[valid_count][2] = L;
        nnzs[valid_count] = nnz;

        size_t a_bytes = (size_t)total_pts * nnz * sizeof(data_t);
        size_t v_bytes = (size_t)total_pts * sizeof(data_t);

        data_t *a = (data_t*)malloc(a_bytes);
        data_t *x_pure     = (data_t*)malloc(v_bytes);
        data_t *x_swstruct = (data_t*)malloc(v_bytes);
        data_t *x_swsptrsv = (data_t*)malloc(v_bytes);
        data_t *x_struct   = (data_t*)malloc(v_bytes);
        data_t *b          = (data_t*)malloc(v_bytes);

        srand(time(NULL));
        init_and_rand(a, total_pts * nnz);
        init_and_rand(b, total_pts);
        init_and_zero(x_pure, total_pts);
        init_and_zero(x_swstruct, total_pts);
        init_and_zero(x_swsptrsv, total_pts);
        init_and_zero(x_struct, total_pts);

        struct timeval st, ed;

        printf("\n----- Matrix %d: %d x %d x %d, nnz=%d, points=%d -----\n",
               valid_count + 1, M, N, L, nnz, total_pts);
        printf("  stencil:");
        for (i = 0; i < nnz; i++)
            printf(" (%d,%d,%d)", p[i][0], p[i][1], p[i][2]);
        printf("\n");

        gettimeofday(&st, NULL);
        struct_sptrsv_sequential_forward(a, x_pure, b, dim, nnz, p);
        gettimeofday(&ed, NULL);
        t_pure[valid_count] = TIME(st, ed);
        //printf("  纯CPU:         %.6f s\n", t_pure[valid_count]);

        gettimeofday(&st, NULL);
        swSparse_d_struct_sptrsv_sequential_forward(a, x_swstruct, b, dim, nnz, p);
        gettimeofday(&ed, NULL);
        t_swstruct[valid_count] = TIME(st, ed);
        //printf("  SW-struct:     %.6f s\n", t_swstruct[valid_count]);

        x_struct[0] = -999.0;
        //printf("  x_struct[0] before solve: %.1f\n", x_struct[0]);

        gettimeofday(&st, NULL);
        swSparse_d_struct_sptrsv_forward(a, x_struct, b, dim, nnz, p);
        gettimeofday(&ed, NULL);
        t_struct[valid_count] = TIME(st, ed);

        //printf("  struct-SpTRSV: %.6f s\n", t_struct[valid_count]);
        //printf("  x_struct[0] after  solve: %.6f (MPE+CPE %s)\n",
        //       x_struct[0], x_struct[0] == -999.0 ? "DID NOT EXECUTE" : "executed OK");

        // Fallback to backward solver if forward failed
        int is_backward = 0;
        if (x_struct[0] == -999.0) {
            is_backward = 1;
            //printf("  -> Forward failed, trying BACKWARD solver...\n");

            // Re-run pure CPU and SW-struct with backward direction
            init_and_zero(x_pure, total_pts);
            init_and_zero(x_swstruct, total_pts);
            init_and_zero(x_struct, total_pts);

            gettimeofday(&st, NULL);
            swSparse_d_struct_sptrsv_sequential_backward(a, x_pure, b, dim, nnz, p);
            gettimeofday(&ed, NULL);
            t_pure[valid_count] = TIME(st, ed);
            //printf("  纯CPU(bwd):    %.6f s\n", t_pure[valid_count]);

            gettimeofday(&st, NULL);
            swSparse_d_struct_sptrsv_sequential_backward(a, x_swstruct, b, dim, nnz, p);
            gettimeofday(&ed, NULL);
            t_swstruct[valid_count] = TIME(st, ed);
            //printf("  SW-struct(bwd):%.6f s\n", t_swstruct[valid_count]);

            gettimeofday(&st, NULL);
            swSparse_d_struct_sptrsv_backward(a, x_struct, b, dim, nnz, p);
            gettimeofday(&ed, NULL);
            t_struct[valid_count] = TIME(st, ed);
            //printf("  struct-BwSpTRSV:%.6f s\n", t_struct[valid_count]);
            //printf("  x_struct[0] after bwd: %.6f (MPE+CPE %s)\n",
            //       x_struct[0], x_struct[0] == 0.0 ? "DID NOT EXECUTE" : "executed OK");

            t_swsptrsv[valid_count] =
                run_swsptrsv(a, b, x_swsptrsv, M, N, L, nnz, p);
            //printf("  swSpTRSV:      %.6f s\n", t_swsptrsv[valid_count]);
        } else {
            t_swsptrsv[valid_count] =
                run_swsptrsv(a, b, x_swsptrsv, M, N, L, nnz, p);
            //printf("  swSpTRSV:      %.6f s\n", t_swsptrsv[valid_count]);
        }

        printf("  CPU=%.6f  SW-struct=%.6f  struct-SpTRSV=%.6f  swSpTRSV=%.6f\n",
               t_pure[valid_count], t_swstruct[valid_count],
               t_struct[valid_count], t_swsptrsv[valid_count]);

        //print_x_first_n("x_pure",     x_pure,     M, N, L, 5);
        //print_x_first_n("x_swstruct", x_swstruct, M, N, L, 5);
        //print_x_first_n("x_swsptrsv", x_swsptrsv, M, N, L, 5);
        //print_x_first_n("x_struct",   x_struct,   M, N, L, 5);

        int c1 = check(x_struct,   x_pure, total_pts);
        int c2 = check(x_swstruct, x_pure, total_pts);
        int c3 = check(x_swsptrsv, x_pure, total_pts);

        if (c1 >= 0) {
            int i = c1 / (N * L);
            int j = (c1 % (N * L)) / L;
            int k = c1 % L;
            //printf("  struct FAIL @ idx=%d (i=%d,j=%d,k=%d): x_struct=%.6f x_pure=%.6f\n",
            //       c1, i, j, k, x_struct[c1], x_pure[c1]);
            /* print next 4 mismatches */
            for (int mm = c1 + 1; mm < total_pts && mm < c1 + 5; mm++)
                if (fabs(x_struct[mm] - x_pure[mm]) > MISTAKE) {
                    i = mm / (N * L);
                    j = (mm % (N * L)) / L;
                    k = mm % L;
                    //printf("           @ idx=%d (i=%d,j=%d,k=%d): x_struct=%.6f x_pure=%.6f\n",
                    //       mm, i, j, k, x_struct[mm], x_pure[mm]);
                }
        }

        struct_ok[valid_count] = (t_struct[valid_count] >= 0.0 && c1 == -1) ? 1 : 0;
        printf("  struct=%s  SW-struct=%s  swSpTRSV=%s\n",
               c1 == -1 ? "OK" : "FAIL",
               c2 == -1 ? "OK" : "FAIL",
               c3 == -1 ? "OK" : "FAIL");

        free(a);
        free(x_pure);
        free(x_swstruct);
        free(x_swsptrsv);
        free(x_struct);
        free(b);
        free(p);

        valid_count++;
    }
    fclose(fp);

    printf("\n\n============================================================\n");
    printf("                    Speedup Summary\n");
    printf("============================================================\n");
    printf("%-3s %12s %6s %10s %10s %10s %10s %8s %8s %8s\n",
           "Mat", "Grid", "nnz", "PureCPU", "SW-struct", "swSpTRSV",
           "structSp", "vsCPU", "vsSW", "vsSpTRSV");
    printf("------------------------------------------------------------\n");

    double sum_cpu = 0, sum_sw = 0, sum_trsv = 0;
    int sum_n = 0;
    for (i = 0; i < valid_count; i++)
    {
        if (struct_ok[i]) {
            double sp_cpu  = t_pure[i]    / t_struct[i];
            double sp_sw    = t_swstruct[i] / t_struct[i];
            double sp_trsv = t_swsptrsv[i] / t_struct[i];
            printf("%-3d %dx%dx%d %6d %10.6f %10.6f %10.6f %10.6f %7.2fx %7.2fx %7.2fx\n",
                   i + 1,
                   sizes[i][0], sizes[i][1], sizes[i][2],
                   nnzs[i],
                   t_pure[i], t_swstruct[i], t_swsptrsv[i], t_struct[i],
                   sp_cpu, sp_sw, sp_trsv);
            sum_cpu  += sp_cpu;
            sum_sw    += sp_sw;
            sum_trsv += sp_trsv;
            sum_n++;
        } else {
            printf("%-3d %dx%dx%d %6d %10.6f %10.6f %10.6f %10s %8s %8s %8s\n",
                   i + 1,
                   sizes[i][0], sizes[i][1], sizes[i][2],
                   nnzs[i],
                   t_pure[i], t_swstruct[i], t_swsptrsv[i], "SKIP",
                   "-", "-", "-");
        }
    }
    if (sum_n > 0) {
        printf("------------------------------------------------------------\n");
        printf("AVG %36s %7.2fx %7.2fx %7.2fx\n", "",
               sum_cpu / sum_n, sum_sw / sum_n, sum_trsv / sum_n);
    }
    printf("============================================================\n\n");

    return 0;
}
