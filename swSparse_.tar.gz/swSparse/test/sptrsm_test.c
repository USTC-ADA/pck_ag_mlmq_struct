#include <stdint.h>
#include <stdlib.h>
#include <sys/time.h>
#include <string.h>
#ifndef NO_CPE
#include <athread.h>
#endif
#include <math.h>
#include "swSparse.h"
#include "../include/swSparse_base.h"
#include "../include/internal/rename.h"
#include "test.h"


#define MIN(a,b) ((a)<(b)?(a):(b))
#define MAX(a,b) ((a)>(b)?(a):(b))

//#define UPPER_TEST
//#define MKL_TEST
//#define UNIT_DIAG_TEST
//#define PERF_TEST
//#define NEW_ACCURACY
//#define TRSV_TEST

//extern int maxNnzNum(Matrix mat);
//extern int check_offset_new(vec_t x_ret, vec_t b_back, vec_t b_org, int n, int max_nnz_num, swSparseMatrix mat, FILE *file, char *mat_name);

swSparseBool swSparse_d_compare_vec(swSparseInt n, const vec_t a, const vec_t b);

void SpMV_seq_csc_n(swSparseMatrix mat, vec_t x, vec_t b, int n, int nvec)
{
    int i, j, k;
    int *col, *row;
    vec_t val;
    col = mat->matrix.csrc.offsets;
    row = mat->matrix.csrc.indices;
    val = mat->matrix.csrc.values;
    
    if(mat->element_type == SWSPARSE_REAL_SINGLE || mat->element_type == SWSPARSE_REAL_DOUBLE)
    {
        for(i = 0; i < n*nvec; i++)
            b[i] = 0.0;
    }
    else if(mat->element_type == SWSPARSE_COMPLEX_SINGLE || mat->element_type == SWSPARSE_COMPLEX_DOUBLE)
    {
        for(i = 0; i < n*nvec; i++)
            b[i] = 0.0 + 0.0 * _Complex_I;
    } 
    for(k = 0; k < nvec; k++)
    {
        for(i = 0; i < n; i++)
        {
            for(j = col[i]; j < col[i+1]; j++)
            {
                b[k*n+row[j]] += val[j] * x[k*n+i];
            }
        }
    }

}

#ifdef UPPER_TEST
void trsm_seq(swSparseMatrix matrix, vec_t b, vec_t x, int nvec)
{
    int   *col = matrix->matrix.csrc.offsets;
    int   *row = matrix->matrix.csrc.indices;
    vec_t  val = matrix->matrix.csrc.values;

    int i, j, k;
    int n = matrix->n;
    if(x != b)
        for(i = 0; i < nvec; i++)
            for(j = 0; j < n; j++)
                x[i*n+j] = b[i*n+j];

    for(k = 0; k < nvec; k++)
    {
        for(i = matrix->n-1; i >= 0; i--)
//        for(i = 0; i < n; i++)
        {
            x[k*n+i] /= val[col[i+1]-1];
//            x[k*n+i] /= val[col[i]];
//            for(j = col[i] + 1; j < col[i+1]; j++)
            for(j = col[i+1]-2; j >= col[i]; j--)
            {
                x[k*n+row[j]] -= val[j] * x[k*n+i];
            }
        }
    }
    
    return; 
}
#else
void trsm_seq(swSparseMatrix matrix, vec_t b, vec_t x, int nvec)
{
    int   *col = matrix->matrix.csrc.offsets;
    int   *row = matrix->matrix.csrc.indices;
    vec_t  val = matrix->matrix.csrc.values;

    int i, j, k;
    int n = matrix->n;
    if(x != b)
        for(i = 0; i < nvec; i++)
            for(j = 0; j < n; j++)
                x[i*n+j] = b[i*n+j];

    for(k = 0; k < nvec; k++)
    {
        for(i = 0; i < n; i++)
        {
            x[k*n+i] /= val[col[i]];
            for(j = col[i] + 1; j < col[i+1]; j++)
            {
                x[k*n+row[j]] -= val[j] * x[k*n+i];
            }
        }
    }
    
    return; 
}
#endif


#if defined(TEST_COMPLEX_SINGLE)
float cabs_m(data_t num)
{
    float ret = sqrt(creal(num)*creal(num) + cimag(num)*cimag(num));;
    return ret;
}
#elif defined(TEST_COMPLEX_DOUBLE) 
double cabs_m(data_t num)
{
    double ret = sqrt(creal(num)*creal(num) + cimag(num)*cimag(num));;
    return ret;
}
#endif

int check_offset_new(vec_t x_ret, vec_t b_back, vec_t b_org, int n, int max_nnz_num, swSparseMatrix mat, FILE *file, char *mat_name)
{
    int i;
    int nnz = mat->nnz;
    int result = 0;
    int error_num = 0;
    
#if defined(TEST_REAL_SINGLE) || defined(TEST_COMPLEX_SINGLE)
    float accuracy = 1e-7;
    float max_offset = 0.0;
#elif defined(TEST_REAL_DOUBLE) || defined(TEST_COMPLEX_DOUBLE)
    double accuracy = 1e-15;
    double max_offset = 0.0;
#endif

    vec_t fabs_b = (vec_t) malloc(n * sizeof(*fabs_b)); 
    vec_t fabs_x = (vec_t) malloc(n * sizeof(*fabs_x)); 
    vec_t fabs_v = (vec_t) malloc(nnz * sizeof(*fabs_v));

    memcpy(fabs_v, mat->matrix.csrc.values, nnz*sizeof(*fabs_v));

#if defined(TEST_REAL_SINGLE) || defined(TEST_REAL_DOUBLE) 
    for(i = 0; i < n; i++)
        fabs_x[i] = fabs(x_ret[i]);
    
    for(i = 0; i < nnz; i++)
        fabs_v[i] = fabs(fabs_v[i]);
#else
    for(i = 0; i < n; i++)
        fabs_x[i] = (data_t)cabs_m(x_ret[i]);
    
    for(i = 0; i < nnz; i++)
        fabs_v[i] = (data_t)cabs_m(fabs_v[i]);
#endif

    vec_t val_tmp = (vec_t)mat->matrix.csrc.values; 
    mat->matrix.csrc.values = fabs_v;
    SpMV_seq_csc_n(mat, fabs_x, fabs_b, n, 1);
    mat->matrix.csrc.values = val_tmp;

#if defined(TEST_REAL_SINGLE) || defined(TEST_COMPLEX_SINGLE)
    float  limit = (max_nnz_num * accuracy) / (1 -  accuracy);
#elif defined TEST_REAL_DOUBLE || defined(TEST_COMPLEX_DOUBLE)
    double limit = (max_nnz_num * accuracy) / (1 -  accuracy);
#endif

    for(i = 0; i < n; i++)
    {
#if defined(TEST_REAL_SINGLE) || defined(TEST_REAL_DOUBLE) 
        data_t tmp = fabs(b_back[i] - b_org[i]) / fabs_b[i];
#elif  defined(TEST_COMPLEX_SINGLE)
        float  tmp = cabs_m(b_back[i] - b_org[i]) / fabs_b[i];
#elif  defined(TEST_COMPLEX_DOUBLE)
        double tmp = cabs_m(b_back[i] - b_org[i]) / fabs_b[i];
#endif
        if(tmp > max_offset) 
            max_offset = tmp;
        
        if(tmp > limit)
        {
            error_num++;
//            printf("accuracy check: row %8d = %.16f\n", i, tmp);
        }
    }
    printf("error_num = %d\n", error_num);

    if(max_offset <= limit)
        result = 1;

#if defined(TEST_REAL_SINGLE) || defined(TEST_COMPLEX_SINGLE)
    printf("max_offset = %.8f, limit = %.8f\n", max_offset, limit);
#elif defined TEST_REAL_DOUBLE || defined(TEST_COMPLEX_DOUBLE)
    printf("max_offset = %.16f, limit = %.16f\n", max_offset, limit);
#endif

    free(fabs_x);
    free(fabs_b);
    free(fabs_v);
    return result;
}


/**
 *
 * x1: compute result
 * x2: verificated data
 * offset:
 */
int check_offset_n(vec_t x1, vec_t x2, vec_t offset, int nvec, int n, swSparseMatrix mat, FILE *file, vec_t rslt_q, vec_t rslt_s)
{
    int result = 1;
    int i,k;
    int *col, *row;
    vec_t values;
    col    = mat->matrix.csrc.offsets;
    row    = mat->matrix.csrc.indices;
    values = mat->matrix.csrc.values;
    data_t max_offset = 0.0;

#ifdef TEST_REAL_SINGLE
        for(k = 0; k < nvec; k++)
        {
            for(i = 0; i < n; i++)
            {
                if(fabs(x1[k*n+i] - x2[k*n+i]) > (2 * offset[k*n+i])) 
                {
                    printf("Warning: the wrong %d,%d(%.8e, %.8e) offset = %.8e\n", k, i, x1[k*n+i], x2[k*n+i], offset[k*n+i]);
                    result = 0;
                }
                data_t offset_tmp = fabs(x1[i] - x2[i]) / (2 * offset[i]);
                if(offset_tmp > max_offset)
                    max_offset = offset_tmp;
            }
        }
        fprintf(file, "%.8f\n", max_offset); 
#endif    
#ifdef TEST_REAL_DOUBLE
        for(k = 0; k < nvec; k++)
        {
            for(i = 0; i < n; i++)
            {
                if(fabs(x1[k*n+i] - x2[k*n+i]) > (2 * offset[k*n+i])) 
                {
                    printf("Warning: the wrong %d,%d(%.16e, %.16e) xq = %.16e, xs = %.16e, offset = %.16e\n", k, i, x1[k*n+i], x2[k*n+i], rslt_q[k*n+i], rslt_s[k*n+i], offset[k*n+i]);
                    result = 0;
                }
                data_t offset_tmp = fabs(x1[i] - x2[i]) / (2 * offset[i]);
                if(offset_tmp > max_offset)
                    max_offset = offset_tmp;
            }
        }
        fprintf(file, "%.20f\n", max_offset); 
#endif    
#ifdef TEST_COMPLEX_SINGLE
        //TODO
        for(k = 0; k < nvec; k++)
        {
            for(i = 0; i < n; i++)
            {
                if(fabs(creal(x1[k*n+i]) - creal(x2[k*n+i])) > 2 * creal(offset[k*n+i]) || fabs(cimag(x1[k*n+i]) - cimag(x2[k*n+i])) > 2 * cimag(offset[k*n+i])) {
                    printf("Warning: the wrong %d(%.8e + %.8ei, %.8e + %.8ei)\n", i, creal(x1[k*n+i]), cimag(x1[k*n+i]), creal(x2[k*n+i]), cimag(x2[k*n+i]));
                    result = 0;
                }
                data_t offset_tmp = fabs(x1[i] - x2[i]) / (2 * offset[i]);
    //            if(offset_tmp > max_offset)
    //                max_offset = offset_tmp;
            }
        }
#endif    
#ifdef TEST_COMPLEX_DOUBLE
        //TODO
        for(k = 0; k < nvec; k++)
        {
            for(i = 0; i < n; i++)
            {
                if(fabs(creal(x1[k*n+i]) - creal(x2[k*n+i])) > 2 * creal(offset[k*n+i]) || fabs(cimag(x1[k*n+i]) - cimag(x2[k*n+i])) > 2 * cimag(offset[k*n+i])) {
                    printf("Warning: the wrong %d(%.16e + %.16ei, %.16e + %.16ei)\n", i, creal(x1[k*n+i]), cimag(x1[k*n+i]), creal(x2[k*n+i]), cimag(x2[k*n+i]));
                    result = 0;
                }
                data_t offset_tmp = fabs(x1[i] - x2[i]) / (2 * offset[i]);
    //            if(offset_tmp > max_offset)
    //                max_offset = offset_tmp;
            }
        }
#endif    
    return result;
}


/*
 * read vector from file
 *
 */
vec_t read_verify_data_n(const char *file_name, swSparseMatrixElementType ele_type, int *nvec, int *n)
{
    FILE *file;
    vec_t vec;
    file = fopen(file_name, "rb");
    if(file == NULL)
    {
        printf("Cannot open file %s\n", file_name);
        return NULL;
    }
    int header[3];
    size_t count = fread(&header, sizeof(int), 3, file);
    if(count != 3) {
        printf("error in reading: header is not 3\n");
        return NULL;
    }
    
    //real numbers
    int tmp_nvec = *nvec = header[0];
    int tmp_n    = *n    = header[1];
    
#ifdef TEST_REAL_DOUBLE
    double *vec_tmp = malloc(tmp_nvec * tmp_n * sizeof(double));
    count = fread(vec_tmp, sizeof(double), tmp_nvec * tmp_n, file);
    
    if(count != tmp_nvec*tmp_n)
    {
        printf("error in reading: the count of data error\n");
        return NULL;
    }
    vec = vec_tmp;
#elif defined TEST_REAL_SINGLE
    double *vec_tmp = malloc(tmp_nvec * tmp_n * sizeof(double));
    count = fread(vec_tmp, sizeof(double), tmp_nvec * tmp_n, file);
    
    if(count != tmp_nvec*tmp_n)
    {
        printf("error in reading: the count of data error\n");
        return NULL;
    }
    vec = malloc(header[1] * tmp_nvec *sizeof(float));
    int i;
    for(i = 0; i < header[1] * tmp_nvec; i++)
    {
        vec[i] = (float)vec_tmp[i];
    }
    free(vec_tmp);
#elif defined TEST_COMPLEX_DOUBLE
    //complex numbers
    double complex *vec_tmp = malloc(tmp_nvec * header[1] * sizeof(double complex));
    count = fread(vec_tmp, sizeof(double complex), tmp_nvec * header[1], file);
    if(count != tmp_nvec * header[1])
    {
        printf("error in reading: the count of data error\n");
        return NULL;
    }
    vec = (vec_t)vec_tmp;
#elif defined TEST_COMPLEX_SINGLE
    double complex *vec_tmp = malloc(tmp_nvec * header[1] * sizeof(double complex));
    count = fread(vec_tmp, sizeof(double complex), tmp_nvec * header[1], file);
    if(count != tmp_nvec * header[1])
    {
        printf("error in reading: the count of data error\n");
        return NULL;
    }
    vec = malloc(tmp_nvec * header[1] * sizeof(float complex));
    int i;
    for(i = 0; i < header[1] * tmp_nvec; i++)
    {
        vec[i] = (float complex)vec_tmp[i];
    }
    free(vec_tmp);
#endif
    
    fclose(file); 
    return vec;
}


int maxNnzNum(Matrix mat)
{
    int max_n = 0;
    int i, j;
    int n = mat->n;
    
    int *nnz_row = (int*) malloc(mat->n * sizeof(int));
    for(i = 0; i < n; i++) nnz_row[i] = 0;

    if(mat->format_type == CSR)
    {
        for(i = 0; i < n; i++)
        {
            for(j = mat->matrix.csrc.offsets[i]; j < mat->matrix.csrc.offsets[i+1]; j++)
            {
                if(mat->matrix.csrc.indices[j] <= i)
                    nnz_row[i]++;
            }
        }
    }else if(mat->format_type == COO){
        for(i = 0; i < mat->nnz; i++)
        {
            if(mat->matrix.coo.column_indices[i] <= mat->matrix.coo.row_indices[i])
                nnz_row[mat->matrix.coo.row_indices[i]]++;
        }
    }
    for(i = 0; i < n; i++)
    {
        max_n = nnz_row[i] > max_n ? nnz_row[i] : max_n;
    }
    free(nnz_row);
    
    printf("maxNnzNum: n = %d, max_n = %d\n", n, max_n);

    return max_n;
}

int test(cstr_t in_argv, in_op_t in_op, cstr_t out_file, out_op_t out_op) {
    struct timeval start, end, all_start, all_end;
    double t1, t2, t3, fp;
    vec_t x, b, x_tmp, b_tmp, x_tmp2, b_tmp2, x_last, x_ret;
    vec_t x_ver, b_ver, offset_ver;
    perm_t perm, iperm;
    swSparseMatrix a, a_tmp;// old_a;
    swSparseErrorStatus ret = SWSPARSE_SUCCESS;
    int n, nnz, old_n, nvec;
    int i, j;
    int isCorrect = 1;
    int check_ret = 0;
    
    //test
    cstr_t in_file;
#ifdef MKL_TEST
    cstr_t *argv = (cstr_t *) in_argv;
    cstr_t in_data   = argv[5];
    cstr_t in_result = argv[6];
    cstr_t in_offset = argv[7];
    char   *mat_name = (char *)argv[8];
    
    int len = strlen(argv[2]);
    char *ftmp = malloc((len+1) * sizeof(char)); 
    strncpy(ftmp, argv[2], len);
#else
    int len = strlen(in_argv);
    char *ftmp     = malloc((len+1) * sizeof(char)); 
    char *mat_name = malloc((len+1) * sizeof(char)); 
    strncpy(ftmp, in_argv, len);
#endif
    if(in_op == WXL)
    {
        ftmp[len-3] = 'c';
        ftmp[len-2] = 's';
        ftmp[len-1] = 'r';
        ftmp[len]   = '\0';
    }
    else if(in_op == MM)
    {
        ftmp[len-3] = 'm';
        ftmp[len-2] = 't';
        ftmp[len-1] = 'x';
        ftmp[len]   = '\0';
    }
    in_file = (cstr_t) ftmp;
#ifdef MKL_TEST
    for(i = 0; i < strlen(mat_name); i++)
    {
        if(mat_name[i] == '.')
        {
            mat_name[i] = '\0';
        }
    }
    printf("----------------------------------------argv[2]   = %s\n", argv[2]);
    printf("----------------------------------------in_data   = %s\n", in_data);
    printf("----------------------------------------in_result = %s\n", in_result);
    printf("----------------------------------------in_offset = %s\n", in_offset);
#else
    for(i = strlen(in_file) - 1; i >= 0; i--)
    {
        if(in_file[i] == '/')
        {
            i++;
            j = 0;
            while(in_file[i] != '.')
            {
               mat_name[j] = in_file[i]; 
               i++;
               j++;
            }
            mat_name[j] = '\0';
            break;
        }
    }

#endif
    printf("----------------------------------------in_file   = %s\n", in_file);
    printf("----------------------------------------mat_name  = %s\n", mat_name);


    switch (in_op)
    {
        case MM:
#ifdef TEST_REAL_DOUBLE
            ret = swSparse_read_mtx(&a, in_file, SWSPARSE_DOUBLE, SWSPARSE_COO);
#elif defined TEST_REAL_SINGLE
            ret = swSparse_read_mtx(&a, in_file, SWSPARSE_SINGLE, SWSPARSE_COO);
#elif defined TEST_COMPLEX_DOUBLE
            ret = swSparse_read_mtx(&a, in_file, SWSPARSE_DOUBLE, SWSPARSE_COO);
#elif defined TEST_COMPLEX_SINGLE
            ret = swSparse_read_mtx(&a, in_file, SWSPARSE_SINGLE, SWSPARSE_COO);
#endif
            break;
        case BIN:
            //TODO
            ret = swSparse_read_binary(&a, in_file);
            break;
        case WXL:
//            ret = my_read_lagacy(&a, in_file, ele_type);
            break;
    }
    if(ret != SWSPARSE_SUCCESS) {
        printf("read matrix failed\n");
        return 2;
    }
    if(a->n != a->m) {
        fprintf(stderr, "Matrix is not square. n = %d, m = %d, nnz = %d\n", a->n, a->m, a->nnz);
        return 6;
    }
    
    printf("----------------------------------------n of matrix = %d, nnz = %d\n", a->n, a->nnz);
    n = a->n;
    nnz = 0;
    old_n = a->n;


#ifndef NO_CPE
    athread_init();
#endif
    
    int max_nnz_num = 0;
    //compute max nnz_num of per-row
    max_nnz_num = maxNnzNum(a); 

    ret = swSparse_convert_csc(a, SWSPARSE_IN_PLACE);
    if(ret != SWSPARSE_SUCCESS) {
        return ret;
    }
    printf("----------------------------------------convert finish\n");

    //read file
    swSparseMatrixElementType ele_type;
#ifdef TEST_REAL_DOUBLE
    ele_type = SWSPARSE_REAL_DOUBLE;
#elif defined TEST_REAL_SINGLE
    ele_type = SWSPARSE_REAL_SINGLE;
#elif defined TEST_COMPLEX_DOUBLE
    ele_type = SWSPARSE_COMPLEX_DOUBLE;
#elif defined TEST_COMPLEX_SINGLE
    ele_type = SWSPARSE_COMPLEX_SINGLE;
#endif

#ifdef MKL_TEST
    int data_num0, num_vec0;
    int data_num1, num_vec1;
    int data_num2, num_vec2;
    b_ver      = read_verify_data_n(in_data,   ele_type, &num_vec0, &data_num0);
    x_ver      = read_verify_data_n(in_result, ele_type, &num_vec1, &data_num1);
    offset_ver = read_verify_data_n(in_offset, ele_type, &num_vec2, &data_num2);
    
    if(data_num0 != data_num1 || data_num0 != data_num2)
        printf("----------------------------------------error: data_num is not same!\n");
    printf("----------------------------------------data_num = %d\n", data_num0);
    
    if(num_vec0 != num_vec1 || num_vec0 != num_vec2)
        printf("----------------------------------------error: num_vec is not same!\n");
    printf("----------------------------------------num_vec = %d\n", num_vec0);
    nvec = num_vec0;
    
    if(b_ver != NULL && x_ver != NULL && offset_ver != NULL)
        printf("----------------------------------------file read success\n");
#else
    nvec = 20;
#endif
    //create x by random function
    vec_t x_org = (vec_t) malloc(sizeof(*x_org) * n * nvec);
    vec_t b_org = (vec_t) malloc(sizeof(*b_org) * n * nvec);
    for(i = 0; i < n * nvec; ++i) 
    {
        x_org[i] = (data_t) rand() / RAND_MAX;
    }
    SpMV_seq_csc_n(a, x_org, b_org, n, nvec); 
    
#ifdef UNIT_DIAG_TEST
int unit_nnz = 0;
#endif
    //convert lower triangular matrix
    swSparseMatrix created     = (swSparseMatrix) malloc(sizeof(swSparseMatrixData));
    swSparseMatrix created_org = (swSparseMatrix) malloc(sizeof(swSparseMatrixData));
    for(i = 0; i < a->n; i++)
    {
      for(j = a->matrix.csrc.offsets[i]; j < a->matrix.csrc.offsets[i+1]; j++)
      {
#ifdef  UPPER_TEST
        if(a->matrix.csrc.indices[j] <= i)
#else
        if(a->matrix.csrc.indices[j] >= i)
#endif
          nnz++;
#ifdef UNIT_DIAG_TEST
        if(a->matrix.csrc.indices[j] > i)
          unit_nnz++;
#endif
      }
    }

    int *col, *row, *col_org, *row_org;
    vec_t val, val_org;
    created->m = created->n = a->n;
    created->nnz = nnz;
#ifdef UNIT_DIAG_TEST
    created->nnz = unit_nnz;
    col = created->matrix.csrc.offsets = (int *) malloc((n+1) * sizeof(int));
    row = created->matrix.csrc.indices = (int *) malloc((unit_nnz) * sizeof(int));
    val = created->matrix.csrc.values  = (vec_t) malloc((unit_nnz) * sizeof(*val));
#else
    col = created->matrix.csrc.offsets = (int *) malloc((n+1) * sizeof(int));
    row = created->matrix.csrc.indices = (int *) malloc((nnz) * sizeof(int));
    val = created->matrix.csrc.values  = (vec_t) malloc((nnz) * sizeof(*val));
#endif
    
    created_org->m = created_org->n = a->n;
    created_org->nnz = nnz;
    col_org = created_org->matrix.csrc.offsets = (int *) malloc((n+1) * sizeof(int));
    row_org = created_org->matrix.csrc.indices = (int *) malloc((nnz) * sizeof(int));
    val_org = created_org->matrix.csrc.values  = (vec_t) malloc((nnz) * sizeof(*val));
    if(col == NULL || row == NULL || val == NULL || col_org == NULL || row_org == NULL || val_org == NULL)
    {
        return SWSPARSE_MALLOC_ERROR;
    }
    int nz = 0;
#ifdef UNIT_DIAG_TEST
    int unit_nz = 0;
#endif
    col[0] = 0;
    col_org[0] = 0;
#ifdef TEST_REAL_DOUBLE
    vec_t old_values = (vec_t)a->matrix.csrc.values;
#elif defined TEST_REAL_SINGLE
    double *old_values = (double *)a->matrix.csrc.values;
#elif defined TEST_COMPLEX_DOUBLE
    vec_t old_values = (vec_t)a->matrix.csrc.values;
#elif defined TEST_COMPLEX_SINGLE
    double complex *old_values = (double complex*)a->matrix.csrc.values;
#endif
    int zero_ele = 0;
    for(i = 0; i < a->n; i++)
    {
      for(j = a->matrix.csrc.offsets[i]; j < a->matrix.csrc.offsets[i+1]; j++)
      { 
#ifdef UNIT_DIAG_TEST
        if(a->matrix.csrc.indices[j] > i)
        {
          row_org[nz] = a->matrix.csrc.indices[j];
          row[unit_nz]= a->matrix.csrc.indices[j];
#ifdef TEST_REAL_DOUBLE
          val_org[nz] = val[unit_nz] = old_values[j];
#endif
          unit_nz ++;
          nz++;
        }
        else if(a->matrix.csrc.indices[j] == i)
        {
          row_org[nz] = a->matrix.csrc.indices[j];
#ifdef TEST_REAL_DOUBLE
          val_org[nz] = 1.0;
#endif
            nz++;
        }

#else

#ifdef  UPPER_TEST
        if(a->matrix.csrc.indices[j] <= i)
#else
        if(a->matrix.csrc.indices[j] >= i)
#endif
        {
          row_org[nz] = row[nz] = a->matrix.csrc.indices[j];
#ifdef TEST_REAL_DOUBLE
          val_org[nz] = val[nz] = old_values[j];
#elif defined TEST_REAL_SINGLE
          val_org[nz] = val[nz] = (float)old_values[j];
#elif defined TEST_COMPLEX_DOUBLE
          val_org[nz] = val[nz] = old_values[j];
#elif defined TEST_COMPLEX_SINGLE
          val_org[nz] = val[nz] = (float complex)old_values[j];
#endif
          nz++; 
        }
#endif
      }
#ifdef UNIT_DIAG_TEST
      col_org[i+1] = nz;
      col[i+1] = unit_nz;
#else
      col_org[i+1] = col[i+1] = nz;
#endif
    }

    if(zero_ele >= 1)
    {
        printf("Warning: Exist zero elements in diagonal, ele_num = %d\n", zero_ele);
//        exit(54);
    }

    created->matrix.csrc.ordered = created_org->matrix.csrc.ordered = a->matrix.csrc.ordered;
    created->element_type        = created_org->element_type        = ele_type;
    created->format_type         = created_org->format_type         = a->format_type;
    created->status              = created_org->status              = a->status;
    swSparse_destroy(a);
    a = created;

    x = (vec_t) malloc(sizeof(*x) * nvec * n);
    if(x == NULL) {
        return SWSPARSE_MALLOC_ERROR;
    }
#ifdef NEW_ACCURACY
    b = b_org;
#else
    b = b_ver;
#endif
    
    x_tmp2 = (vec_t)malloc(sizeof(*x) * nvec * n);
    x_last = (vec_t)malloc(sizeof(*x) * nvec * n);
    b_tmp2 = (vec_t)malloc(sizeof(*x) * nvec * n);
    if(x_tmp2 == NULL || b_tmp2 == NULL || x_last == NULL)
        return SWSPARSE_MALLOC_ERROR;

printf("----------------------------------------sequence:\n");

//TODO: aqing test
#ifdef TRSV_TEST
nvec = 20;
#endif
//b = b + 1 * old_n;

    gettimeofday(&start, NULL);
    
    trsm_seq(a, b, x_tmp2, nvec);
    
    gettimeofday(&end, NULL);
    t3 = TIME_DIFF(start, end);

printf("----------------------------------------heterogeneous:\n");
#ifdef PERF_TEST

#ifdef SWAPS_TEST
    long long swaps   = 0; 
#endif

    int n2 = n;
    int *xiperm = (int*) malloc(sizeof(int) * n2);
    int *biperm = (int*) malloc(sizeof(int) * n2);
    b_tmp       = (vec_t)malloc(sizeof(*x)  * 4 * n2);
    x_tmp       = (vec_t)malloc(sizeof(*x)  * 4 * n2);
    x_ret       = (vec_t)malloc(sizeof(*x)  * 4 * n2);

    Matrix csc;
    double tbperm1 = 0.0;
    double txperm1 = 0.0;
    double tslt1   = 0.0; 
    double texec1  = 0.0; 
    double tmemcp  = 0.0; 
//    double tbperm2, txperm2, tslt2, texec2;
    

    /*
     * first: bucket sort version
     */
    gettimeofday(&all_start, NULL);

    gettimeofday(&start, NULL);
#ifdef UNIT_DIAG_TEST
    swSparse_trsm_inspect(a, &csc, xiperm, biperm, SWSPARSE_UNIT_DIAG);
#else

#ifndef TRSV_TEST
    swSparse_trsm_inspect(a, &csc, xiperm, biperm, SWSPARSE_LOWER_TRI);
#else

#ifdef UPPER_TEST
    swSparse_trsv_inspect(a, &csc, xiperm, biperm, SWSPARSE_UPPER_TRI);
#else
    swSparse_trsv_inspect(a, &csc, xiperm, biperm, SWSPARSE_LOWER_TRI);
#endif
#endif
#endif
    gettimeofday(&end, NULL);
    tslt1 = TIME_DIFF(start, end);
    
    swSparse_destroy(a);
//    a_tmp = a;
    a = csc;
//    n = a->matrix.sltcoo.n;

    
#ifdef TEST_REAL_DOUBLE
    for(i = 0; i < nvec; i+=4)
    {
        gettimeofday(&start, NULL);
        swSparse_d_iperm_apply(n, b+(i+0)*old_n, b_tmp,     biperm); 
        swSparse_d_iperm_apply(n, b+(i+1)*old_n, b_tmp+n,   biperm); 
        swSparse_d_iperm_apply(n, b+(i+2)*old_n, b_tmp+2*n, biperm); 
        swSparse_d_iperm_apply(n, b+(i+3)*old_n, b_tmp+3*n, biperm); 
        gettimeofday(&end, NULL);
        tbperm1 += TIME_DIFF(start, end);
        
        gettimeofday(&start, NULL);
        swSparse_d_trsm_execute(a, nvec, b_tmp, old_n, x_tmp, old_n);
        gettimeofday(&end, NULL);
        texec1 += TIME_DIFF(start, end);
        
        gettimeofday(&start, NULL);
        swSparse_d_iperm_apply(n, x_tmp,     x_ret,     xiperm); 
        swSparse_d_iperm_apply(n, x_tmp+1*n, x_ret+1*n, xiperm); 
        swSparse_d_iperm_apply(n, x_tmp+2*n, x_ret+2*n, xiperm); 
        swSparse_d_iperm_apply(n, x_tmp+3*n, x_ret+3*n, xiperm); 
        gettimeofday(&end, NULL);
        txperm1 += TIME_DIFF(start, end);
        
        gettimeofday(&start, NULL);
        memcpy(x+ i   *old_n, x_ret,     old_n * sizeof(*x));
        memcpy(x+(i+1)*old_n, x_ret+n,   old_n * sizeof(*x));
        memcpy(x+(i+2)*old_n, x_ret+2*n, old_n * sizeof(*x));
        memcpy(x+(i+3)*old_n, x_ret+3*n, old_n * sizeof(*x));
        gettimeofday(&end, NULL);
        tmemcp += TIME_DIFF(start, end);

#ifdef SWAPS_TEST
        int k;
        for(k = 0; k < 32; k++)
        {
            swaps += a->matrix.sltcoo.pro_swaps[k];
            swaps += a->matrix.sltcoo.con_swaps[k];
        }
#endif

    }
    if(i < nvec)
    {
        gettimeofday(&start, NULL);
        for(j = 0; j < nvec-i; j++)
        {
            swSparse_d_iperm_apply(n, b+(i+j)*old_n, b_tmp+j*n,     biperm); 
        }
        gettimeofday(&end, NULL);
        tbperm1 += TIME_DIFF(start, end);
        
        gettimeofday(&start, NULL);
        swSparse_d_trsm_execute(a, nvec, b_tmp, old_n, x_tmp, old_n);
        gettimeofday(&end, NULL);
        texec1 += TIME_DIFF(start, end);
        
        for(j = 0; j < nvec-i; j++)
        {
            gettimeofday(&start, NULL);
            swSparse_d_iperm_apply(n, x_tmp+j*n, x_ret+j*n, xiperm); 
            gettimeofday(&end, NULL);
            txperm1 += TIME_DIFF(start, end);
            
            gettimeofday(&start, NULL);
            memcpy(x+(i+j)*old_n, x_ret+j*n,   old_n * sizeof(*x));
            gettimeofday(&end, NULL);
            tmemcp += TIME_DIFF(start, end);
        }
#ifdef SWAPS_TEST
        int k;
        for(k = 0; k < 32; k++)
        {
            swaps += a->matrix.sltcoo.pro_swaps[k];
            swaps += a->matrix.sltcoo.con_swaps[k];
        }
#endif

    }
#elif defined TEST_REAL_SINGLE
    for(i = 0; i < nvec-3; i+=4)
    {
        gettimeofday(&start, NULL);
        swSparse_s_iperm_apply(n, b+(i+0)*old_n, b_tmp,     biperm); 
        swSparse_s_iperm_apply(n, b+(i+1)*old_n, b_tmp+n,   biperm); 
        swSparse_s_iperm_apply(n, b+(i+2)*old_n, b_tmp+2*n, biperm); 
        swSparse_s_iperm_apply(n, b+(i+3)*old_n, b_tmp+3*n, biperm); 
        gettimeofday(&end, NULL);
        tbperm1 += TIME_DIFF(start, end);
        
        gettimeofday(&start, NULL);
        swSparse_s_trsm_execute(a, nvec, b_tmp, old_n, x_tmp, old_n);
        gettimeofday(&end, NULL);
        texec1 += TIME_DIFF(start, end);
        
        gettimeofday(&start, NULL);
        swSparse_s_iperm_apply(n, x_tmp,     x_ret,     xiperm); 
        swSparse_s_iperm_apply(n, x_tmp+1*n, x_ret+1*n, xiperm); 
        swSparse_s_iperm_apply(n, x_tmp+2*n, x_ret+2*n, xiperm); 
        swSparse_s_iperm_apply(n, x_tmp+3*n, x_ret+3*n, xiperm); 
        gettimeofday(&end, NULL);
        txperm1 += TIME_DIFF(start, end);
        
        gettimeofday(&start, NULL);
        memcpy(x+ i   *old_n, x_ret,     old_n * sizeof(*x));
        memcpy(x+(i+1)*old_n, x_ret+n,   old_n * sizeof(*x));
        memcpy(x+(i+2)*old_n, x_ret+2*n, old_n * sizeof(*x));
        memcpy(x+(i+3)*old_n, x_ret+3*n, old_n * sizeof(*x));
        gettimeofday(&end, NULL);
        tmemcp += TIME_DIFF(start, end);

#ifdef SWAPS_TEST
        int k;
        for(k = 0; k < 32; k++)
        {
            swaps += a->matrix.sltcoo.pro_swaps[k];
            swaps += a->matrix.sltcoo.con_swaps[k];
        }
#endif

    }
    if(i < nvec)
    {
        gettimeofday(&start, NULL);
        for(j = 0; j < nvec-i; j++)
        {
            swSparse_s_iperm_apply(n, b+(i+j)*old_n, b_tmp+j*n,     biperm); 
        }
        gettimeofday(&end, NULL);
        tbperm1 += TIME_DIFF(start, end);
        
        gettimeofday(&start, NULL);
        swSparse_s_trsm_execute(a, nvec, b_tmp, old_n, x_tmp, old_n);
        gettimeofday(&end, NULL);
        texec1 += TIME_DIFF(start, end);
        
        for(j = 0; j < nvec-i; j++)
        {
            gettimeofday(&start, NULL);
            swSparse_s_iperm_apply(n, x_tmp+j*n, x_ret+j*n, xiperm); 
            gettimeofday(&end, NULL);
            txperm1 += TIME_DIFF(start, end);
            
            gettimeofday(&start, NULL);
            memcpy(x+(i+j)*old_n, x_ret+j*n,   old_n * sizeof(*x));
            gettimeofday(&end, NULL);
            tmemcp += TIME_DIFF(start, end);
        }
#ifdef SWAPS_TEST
        int k;
        for(k = 0; k < 32; k++)
        {
            swaps += a->matrix.sltcoo.pro_swaps[k];
            swaps += a->matrix.sltcoo.con_swaps[k];
        }
#endif

    }
#elif defined TEST_COMPLEX_SINGLE
    for(i = 0; i < nvec-3; i+=4)
    {
        gettimeofday(&start, NULL);
        swSparse_c_iperm_apply(n, b+(i+0)*old_n, b_tmp,     biperm); 
        swSparse_c_iperm_apply(n, b+(i+1)*old_n, b_tmp+n,   biperm); 
        swSparse_c_iperm_apply(n, b+(i+2)*old_n, b_tmp+2*n, biperm); 
        swSparse_c_iperm_apply(n, b+(i+3)*old_n, b_tmp+3*n, biperm); 
        gettimeofday(&end, NULL);
        tbperm1 += TIME_DIFF(start, end);
        
        gettimeofday(&start, NULL);
        swSparse_c_trsm_execute(a, nvec, b_tmp, old_n, x_tmp, old_n);
        gettimeofday(&end, NULL);
        texec1 += TIME_DIFF(start, end);
        
        gettimeofday(&start, NULL);
        swSparse_c_iperm_apply(n, x_tmp,     x_ret,     xiperm); 
        swSparse_c_iperm_apply(n, x_tmp+1*n, x_ret+1*n, xiperm); 
        swSparse_c_iperm_apply(n, x_tmp+2*n, x_ret+2*n, xiperm); 
        swSparse_c_iperm_apply(n, x_tmp+3*n, x_ret+3*n, xiperm); 
        gettimeofday(&end, NULL);
        txperm1 += TIME_DIFF(start, end);
        
        gettimeofday(&start, NULL);
        memcpy(x+ i   *old_n, x_ret,     old_n * sizeof(*x));
        memcpy(x+(i+1)*old_n, x_ret+n,   old_n * sizeof(*x));
        memcpy(x+(i+2)*old_n, x_ret+2*n, old_n * sizeof(*x));
        memcpy(x+(i+3)*old_n, x_ret+3*n, old_n * sizeof(*x));
        gettimeofday(&end, NULL);
        tmemcp += TIME_DIFF(start, end);

#ifdef SWAPS_TEST
        int k;
        for(k = 0; k < 32; k++)
        {
            swaps += a->matrix.sltcoo.pro_swaps[k];
            swaps += a->matrix.sltcoo.con_swaps[k];
        }
#endif

    }
    if(i < nvec)
    {
        gettimeofday(&start, NULL);
        for(j = 0; j < nvec-i; j++)
        {
            swSparse_c_iperm_apply(n, b+(i+j)*old_n, b_tmp+j*n,     biperm); 
        }
        gettimeofday(&end, NULL);
        tbperm1 += TIME_DIFF(start, end);
        
        gettimeofday(&start, NULL);
        swSparse_c_trsm_execute(a, nvec, b_tmp, old_n, x_tmp, old_n);
        gettimeofday(&end, NULL);
        texec1 += TIME_DIFF(start, end);
        
        for(j = 0; j < nvec-i; j++)
        {
            gettimeofday(&start, NULL);
            swSparse_c_iperm_apply(n, x_tmp+j*n, x_ret+j*n, xiperm); 
            gettimeofday(&end, NULL);
            txperm1 += TIME_DIFF(start, end);
            
            gettimeofday(&start, NULL);
            memcpy(x+(i+j)*old_n, x_ret+j*n,   old_n * sizeof(*x));
            gettimeofday(&end, NULL);
            tmemcp += TIME_DIFF(start, end);
        }
#ifdef SWAPS_TEST
        int k;
        for(k = 0; k < 32; k++)
        {
            swaps += a->matrix.sltcoo.pro_swaps[k];
            swaps += a->matrix.sltcoo.con_swaps[k];
        }
#endif

    }
#elif defined TEST_COMPLEX_DOUBLE
    for(i = 0; i < nvec-3; i+=4)
    {
        gettimeofday(&start, NULL);
        swSparse_z_iperm_apply(n, b+(i+0)*old_n, b_tmp,     biperm); 
        swSparse_z_iperm_apply(n, b+(i+1)*old_n, b_tmp+n,   biperm); 
        swSparse_z_iperm_apply(n, b+(i+2)*old_n, b_tmp+2*n, biperm); 
        swSparse_z_iperm_apply(n, b+(i+3)*old_n, b_tmp+3*n, biperm); 
        gettimeofday(&end, NULL);
        tbperm1 += TIME_DIFF(start, end);
        
        gettimeofday(&start, NULL);
        swSparse_z_trsm_execute(a, nvec, b_tmp, old_n, x_tmp, old_n);
        gettimeofday(&end, NULL);
        texec1 += TIME_DIFF(start, end);
        
        gettimeofday(&start, NULL);
        swSparse_z_iperm_apply(n, x_tmp,     x_ret,     xiperm); 
        swSparse_z_iperm_apply(n, x_tmp+1*n, x_ret+1*n, xiperm); 
        swSparse_z_iperm_apply(n, x_tmp+2*n, x_ret+2*n, xiperm); 
        swSparse_z_iperm_apply(n, x_tmp+3*n, x_ret+3*n, xiperm); 
        gettimeofday(&end, NULL);
        txperm1 += TIME_DIFF(start, end);
        
        gettimeofday(&start, NULL);
        memcpy(x+ i   *old_n, x_ret,     old_n * sizeof(*x));
        memcpy(x+(i+1)*old_n, x_ret+n,   old_n * sizeof(*x));
        memcpy(x+(i+2)*old_n, x_ret+2*n, old_n * sizeof(*x));
        memcpy(x+(i+3)*old_n, x_ret+3*n, old_n * sizeof(*x));
        gettimeofday(&end, NULL);
        tmemcp += TIME_DIFF(start, end);

#ifdef SWAPS_TEST
        int k;
        for(k = 0; k < 32; k++)
        {
            swaps += a->matrix.sltcoo.pro_swaps[k];
            swaps += a->matrix.sltcoo.con_swaps[k];
        }
#endif

    }
    if(i < nvec)
    {
        gettimeofday(&start, NULL);
        for(j = 0; j < nvec-i; j++)
        {
            swSparse_z_iperm_apply(n, b+(i+j)*old_n, b_tmp+j*n,     biperm); 
        }
        gettimeofday(&end, NULL);
        tbperm1 += TIME_DIFF(start, end);
        
        gettimeofday(&start, NULL);
        swSparse_z_trsm_execute(a, nvec, b_tmp, old_n, x_tmp, old_n);
        gettimeofday(&end, NULL);
        texec1 += TIME_DIFF(start, end);
        
        for(j = 0; j < nvec-i; j++)
        {
            gettimeofday(&start, NULL);
            swSparse_z_iperm_apply(n, x_tmp+j*n, x_ret+j*n, xiperm); 
            gettimeofday(&end, NULL);
            txperm1 += TIME_DIFF(start, end);
            
            gettimeofday(&start, NULL);
            memcpy(x+(i+j)*old_n, x_ret+j*n,   old_n * sizeof(*x));
            gettimeofday(&end, NULL);
            tmemcp += TIME_DIFF(start, end);
        }
#ifdef SWAPS_TEST
        int k;
        for(k = 0; k < 32; k++)
        {
            swaps += a->matrix.sltcoo.pro_swaps[k];
            swaps += a->matrix.sltcoo.con_swaps[k];
        }
#endif

    }
#endif

    
    gettimeofday(&all_end, NULL);
    t1 = TIME_DIFF(all_start, all_end);
    
    FILE *pfile;
#ifdef TEST_REAL_DOUBLE
    pfile = fopen("./out_files_trsm/perf_trsm_real_d.csv","a+");
#elif defined TEST_REAL_SINGLE
    pfile = fopen("./out_files_trsm/perf_trsm_real_s.csv","a+");
#elif defined TEST_COMPLEX_SINGLE
    pfile = fopen("./out_files_trsm/perf_trsm_cmp_s.csv","a+");
#elif defined TEST_COMPLEX_DOUBLE
    pfile = fopen("./out_files_trsm/perf_trsm_cmp_d.csv","a+");
#endif
    if(pfile == NULL)
    {
        printf("error: open file performance_trsm failed\n");
    }
    
    int levels  = a->matrix.sltcoo.levels;
    int plevels = a->matrix.sltcoo.plevels;
    int nod_num = a->matrix.sltcoo.plevels - a->matrix.sltcoo.plevels;
    int mat_t = (nvec >> 2) + (nvec & 3);
    printf("mat_t = %d\n", mat_t);
//    double bw = ((mat_t * nnz * 2 * sizeof(int) + (mat_t * nnz + 2 * nvec * n + nod_num * nvec * 1024) * sizeof(*x) \
               + mat_t * (levels + plevels \
               + 32*9*plevels+1 + 32*levels)*sizeof(int)) \
               / (texec1 * 1e-3)) / 1024 / 1024 / 1024;
    int dma_size = (mat_t * nnz * 2 * sizeof(int) + (mat_t * nnz + 2 * nvec * n + nod_num * nvec * 1024) * sizeof(*x) \
               + mat_t * (levels + plevels + 32*9*plevels+1 + 32*levels)*sizeof(int));
#ifdef SWAPS_TEST
    double bw = (swaps / (texec1 * 1e-3)) / 1024 / 1024 / 1024;
    
    fp = ((nnz << 1) - old_n) / (1e6 * texec1) * nvec;            // floating point performance
    
    double nnz_pern = nnz / n;
    double nnz_perl = (double)nnz / (double)levels;
    
    printf("dma_size = %d\n", dma_size);
    printf("swaps    = %lld\n", swaps);
    double swaps_kb = (double)swaps / 1024;
    double swaps_nnz =(double)swaps / (nnz * sizeof(*x));
    fprintf(pfile, "%s,%d,%d,%.3lf,%.3lf,%.3lf,%.3lf,%.3lf,%.3lf,%.3lf,%d,%.3lf,%.3lf,%.3lf,%.3lf\n", 
            mat_name, n, nnz, nnz_pern, t1, texec1, t3, t3/texec1, t3/t1, bw, levels, nnz_perl, fp, swaps_kb, swaps_nnz);
#endif
    fclose(pfile);

#else


    gettimeofday(&start, NULL);
    //solver
    swSparseSolver solver;
#ifdef UNIT_DIAG_TEST
#ifndef TRSV_TEST
    ret = swSparse_create_tr_m_solver(&solver, a, SWSPARSE_UNIT_DIAG);
#else
    int idx = 0;
    ret = swSparse_create_tr_v_solver(&solver, a, SWSPARSE_UNIT_DIAG);
#endif

#else

#ifndef TRSV_TEST
#ifdef  UPPER_TEST
    ret = swSparse_create_tr_m_solver(&solver, a, SWSPARSE_UPPER_TRI);
#else
    ret = swSparse_create_tr_m_solver(&solver, a, SWSPARSE_LOWER_TRI);
#endif
#else
    int idx = 0;
#ifdef  UPPER_TEST
    ret = swSparse_create_tr_v_solver(&solver, a, SWSPARSE_UPPER_TRI);
#else
    ret = swSparse_create_tr_v_solver(&solver, a, SWSPARSE_LOWER_TRI);
#endif

#endif
#endif
    if(ret != SWSPARSE_SUCCESS) {
        return ret;
    }
    n = a->n;
    gettimeofday(&end, NULL);
    t1 = TIME_DIFF(start, end);
    swSparse_destroy(a);
    a = solver->l;
printf("----------------------------------------heterogeneous excute:\n");

//aqing test
#ifdef TRSV_TEST
for(idx = 0; idx < nvec; idx++)
{
printf("idx = %d\n", idx);
#endif

#ifdef TEST_REAL_SINGLE
      gettimeofday(&start, NULL);
      ret = swSparse_s_solve_m(solver, nvec, b, old_n, x, old_n);
      gettimeofday(&end, NULL);
      t2 = TIME_DIFF(start, end);
#elif defined TEST_REAL_DOUBLE
      gettimeofday(&start, NULL);
#ifndef TRSV_TEST
      ret = swSparse_d_solve_m(solver, nvec, b, old_n, x, old_n);
#else
      ret = swSparse_d_solve_v(solver, b+idx*old_n, x);
#endif
      gettimeofday(&end, NULL);
      t2 = TIME_DIFF(start, end);
#elif defined TEST_COMPLEX_SINGLE
      gettimeofday(&start, NULL);
#ifndef TRSV_TEST
      printf("TRSM TEST\n");
      ret = swSparse_c_solve_m(solver, nvec, b, old_n, x, old_n);
#else
      printf("TRSV TEST\n");
      ret = swSparse_c_solve_v(solver, b+idx*old_n, x);
#endif
      gettimeofday(&end, NULL);
      t2 = TIME_DIFF(start, end);
#elif defined TEST_COMPLEX_DOUBLE
      gettimeofday(&start, NULL);
      ret = swSparse_z_solve_m(solver, nvec, b, old_n, x, old_n);
      gettimeofday(&end, NULL);
      t2 = TIME_DIFF(start, end);
#endif

#endif


    //check x   x_tmp2
    printf("----------------------------------------check heterogeneous with sequential  result:\n");
//    
//#ifndef TRSV_TEST
//    check_ret = check(x, x_tmp2, nvec, old_n, a, b);
//#else
//    check_ret = check(x, x_tmp2+idx*old_n, 1, old_n, a, b);
//#endif
    
    //compute b back with x
//#ifndef TRSV_TEST
//    verify(created_org, x, b_tmp2, nvec, old_n);
//#else
//    verify(created_org, x, b_tmp2, 1, old_n);
//#endif
#ifndef TRSV_TEST
    SpMV_seq_csc_n(created_org, x, b_tmp2, old_n, nvec);
#else
    SpMV_seq_csc_n(created_org, x, b_tmp2, old_n, 1);
#endif

    //check b_tmp2  b
    const char *file_name = "./out_files_trsm/offset_out";
    FILE *file = fopen(file_name, "a+");
    if(file == NULL)
    {
        printf("error: %s file open failed\n", file_name);
        return 0;
    }
    fprintf(file, "%s,", mat_name);
    printf("----------------------------------------check offsets of b_result and b:\n");

#ifdef NEW_ACCURACY
    check_ret = 1;
#ifndef TRSV_TEST
    for(i = 0; i < nvec; i++)
    {
        int tmp_ret= check_offset_new(x+i*old_n, b_tmp2+i*old_n, b_org+i*old_n, old_n, max_nnz_num, created_org, file, mat_name);
        if(tmp_ret == 0)
        {
            check_ret = 0;
        }
    }
#else
        int tmp_ret= check_offset_new(x, b_tmp2, b_org+idx*old_n, old_n, max_nnz_num, created_org, file, mat_name);
#endif

#else

#ifndef TRSV_TEST
    check_ret = check_offset_n(b_tmp2, b_ver, offset_ver, nvec, old_n, created_org, file, x, x_tmp2);
#else
    check_ret = check_offset_n(b_tmp2, b_ver+idx*old_n, offset_ver+idx*old_n, 1, old_n, created_org, file, x, x_tmp2+idx*old_n);
#endif

#endif

    fclose(file);
#ifdef TRSV_TEST
}
#endif
    


#ifndef NO_CPE
    athread_halt();
#endif
    switch (out_op)
    {
        case REF:
            ret = read_vec(n, x_tmp2, out_file);
            if(ret != SWSPARSE_SUCCESS) {
                return 4;
            }
            if(!swSparse_d_compare_vec(n, x, x_tmp2)) {
                return 5;
            }
            break;
        case INOUT:
            ret = swSparse_write_binary(a, out_file);
            if(ret != SWSPARSE_SUCCESS) {
                return 4;
            }
            /* fall through */
        case OUT:
//            ret = write_vec(n, x, out_file);
//            if(ret != SWSPARSE_SUCCESS) {
//                return 4;
//            }
            break;
    }
    
    
#ifndef NO_CPE
#define TYPE "parallel"
#else
#define TYPE "sequential"
#endif
    
#ifndef PERF_TEST
    int nod_num = a->matrix.sltcoo.plevels - a->matrix.sltcoo.plevels;
    double bw = ((nnz * 2 * sizeof(int) + (nnz + 2 * n + nod_num * 1024) * sizeof(*x)
               + (a->matrix.sltcoo.levels + a->matrix.sltcoo.plevels
               + 32*9*a->matrix.sltcoo.plevels+1 + 32)*sizeof(int))
               / (t2 * 1e-3)) / 1024 / 1024 / 1024;
    
    fp = ((nnz << 1) - n) / (1e6 * t2);            // floating point performance

    printf(TYPE" run time: %.3lf ms, %.3lf ms, %lf Gflop/s, my_sequential time: %.3lf ms, bandwidth = %.3lf GB/s, nod_num = %d\n", t1, t2, fp, t3, bw, nod_num);
#endif
    

    free(b);
    free(b_tmp2);
#ifdef MKL_TEST
    free(b_ver);
    free(x_ver);
    free(offset_ver);
#endif
//    free(x_tmp);
    free(x);
//    free(x_tmp2);
    free(x_last);
//    swSparse_destroy(a);
    swSparse_destroy(created_org);
//    swSparse_destroy_solver(solver);
    
    if(check_ret == 0)
    {
        printf("----------------------------------------check offsets of b_result and b failed :\n");
        return 51;
    }
    else
    {
        printf("----------------------------------------check offsets of b_result and b success:\n");
        return 50;
    }


#ifdef CSV_OUT
 //   FILE *f = fopen("results_sptrsv_"TYPE".csv","a");
 //   fprint_matrix_name(f, in_file);
 //   fprintf(f, ", %d, %d, %.3lf, %.3lf, %lf\n", n, a_nnz, t1, t2, fp);
 //   fclose(f);`
#endif
//    return 0;
}

