#include <string.h>
#include <stdlib.h>
#include "test.h"

static cstr_t help = "USAGE: %s <input format> <input file> (-o <output file> | -a <output file> | -r <reference input file>)\ninput formats:\n"\
"    -m Matrix Market\n"\
"    -b binary file\n"\
"    -l Wang Xinliang's lagacy file\n"\
"output format and reference input format are always binary file\n"\
"    -o write out result data\n"\
"    -a write out all data, including the test input and the result\n"\
"    -r read the reference result data and compare\n";

int global_argc = 0;
cstr_t *global_argv = NULL;

int main(int argc, cstr_t *argv) {
    int i;
    in_op_t in_op = MM;
    out_op_t out_op = REF;
    cstr_t in = NULL, out = NULL;
    if((argc == 2) && (strcmp(argv[1], "-h") == 0)) {
        printf(help, argv[0]);
        return 0;
    }

    if(argc < 5) {
        fprintf(stderr, help, argv[0]);
        return 1;
    }

    for(i = 1; i < 5; i += 2) {
        if((strcmp(argv[i], "-m") == 0)) {
            in_op = MM;
            in = argv[i + 1];
        } else if((strcmp(argv[i], "-b") == 0)) {
            in_op = BIN;
            in = argv[i + 1];
        } else if((strcmp(argv[i], "-l") == 0)) {
            in_op = WXL;
            in = argv[i + 1];
        } else if((strcmp(argv[i], "-r") == 0)) {
            out_op = REF;
            out = argv[i + 1];
        } else if((strcmp(argv[i], "-o") == 0)) {
            out_op = OUT;
            out = argv[i + 1];
        } else if((strcmp(argv[i], "-a") == 0)) {
            out_op = INOUT;
            out = argv[i + 1];
        } else {
            fprintf(stderr, "Invalid option: %s\n", argv[i]);
            fprintf(stderr, help, argv[0]);
            return 1;
        }
    }
    if((in == NULL) || (out == NULL)) {
        fprintf(stderr, "Invalid option: %s and %s\n", argv[1], argv[3]);
        fprintf(stderr, help, argv[0]);
        return 1;
    }
    
    fputs("Testing with", stderr);
    for(i = 0; i < argc; ++i) {
        fputc(' ', stderr);
        fputs(argv[i], stderr);
    }
    fputc('\n', stderr);
    global_argv = argv;
    global_argc = argc;
    return test(in, in_op, out, out_op);
}

void fprint_matrix_name(FILE *stream, cstr_t file_path) {
    cstr_t last_dot = file_path, last_slash = file_path, p;
    for(p = file_path; *p != '\0'; ++p) {
        if(*p == '/') {
            last_slash = p;
        } else if (*p == '.') {
            last_dot = p;
        }
    }
    for(p = last_slash + 1; p < last_dot; ++p) {
        fputc(*p, stream);
    }
}

perm_t malloc_random_perm(int n) {
    perm_t iperm;
    int i;
    srand(n);
    iperm = (perm_t) malloc(sizeof(*iperm) * n);
    iperm[0] = 0;
    for(i = 1; i < n; ++i) {
        int x = rand() % (i + 1);
        iperm[i] = iperm[x];
        iperm[x] = i;
    }
    return iperm;
}

vec_t malloc_random_vec(int n) {
    vec_t vec;
    int i;
    srand(n);
    vec = (vec_t) malloc(sizeof(*vec) * n);
    for(i = 0; i < n; ++i) {
        vec[i] = (double)rand() / RAND_MAX * 2.0 - 1.0;
    }
    return vec;
}

int read_vec(int n, vec_t vec, cstr_t file) {
    size_t count;
    FILE *f = fopen(file, "b");
    if(f == NULL) {
        return 2;
    }
    count = fread(vec, sizeof(*vec), n, f);
    fclose(f);
    return (count == n) ? 0 : 3;
}

int write_vec(int n, cvec_t vec, cstr_t file) {
    size_t count;
    FILE *f = fopen(file, "b");
    if(f == NULL) {
        return 2;
    }
    count = fwrite(vec, sizeof(*vec), n, f);
    fclose(f);
    return (count == n) ? 0 : 3;
}
