#ifndef TEST_H_INCLUDED
#define TEST_H_INCLUDED 1

#include <stdio.h>
#include <stdbool.h>
#include <complex.h>

#define TIME_DIFF(start, end) ((end.tv_sec - start.tv_sec) * 1e3 + (end.tv_usec - start.tv_usec) * 1e-3)

#define TEST_REAL_DOUBLE
//#define TEST_REAL_SINGLE
//#define TEST_COMPLEX_DOUBLE
//#define TEST_COMPLEX_SINGLE


typedef enum { MM, BIN, WXL } in_op_t;
typedef enum { OUT, INOUT, REF } out_op_t;
typedef const char *cstr_t;

typedef int *perm_t;

#ifdef TEST_REAL_DOUBLE
typedef double data_t;
typedef double *vec_t;
typedef const double *cvec_t;

#elif defined TEST_REAL_SINGLE
typedef float data_t;
typedef float *vec_t;
typedef const float *cvec_t;

#elif defined TEST_COMPLEX_DOUBLE
typedef double complex data_t;
typedef double complex *vec_t;
typedef const double complex *cvec_t;

#elif defined TEST_COMPLEX_SINGLE

typedef float complex data_t;
typedef float complex *vec_t;
typedef const float complex *cvec_t;

#endif


int test(cstr_t in_file, in_op_t in_op, cstr_t out_file, out_op_t out_op);

void fprint_matrix_name(FILE *stream, cstr_t file_path);

perm_t malloc_random_perm(int n);
vec_t malloc_random_vec(int n); 
int read_vec(int n, vec_t vec, cstr_t file);
int write_vec(int n, cvec_t vec, cstr_t file);

#endif
