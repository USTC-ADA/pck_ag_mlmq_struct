//将sptrsv中的一些debug宏定义测试删除，添加代码注释以及对主对角零元进行判断。
#include <stdint.h>
#include <stdlib.h>
#include <sys/time.h>
#include <string.h>
#ifndef NO_CPE
#include <athread.h>
#endif
#include <math.h>
#include "swSparse.h"
#include "../include/swSparse_base.h"
#include "../include/internal/rename.h"
#include "../include/swSparse_options.h"
#include "../include/internal/memory.h"
#include "test.h"

#define MIN(a,b) ((a)<(b)?(a):(b))
#define MAX(a,b) ((a)>(b)?(a):(b))

#define EXEC_TIMES 1		//计算执行次数
#define NEW_ACCURACY		//定义后向验证结果精度（与b向量进行对比），未定义则是前向验证结果精度（与x向量进行对比）。SpTRSV结果需要进行后向验证。
#define PERF_TEST			//使用三角求解器solver求解，否则将预处理和计算部分拆分成单独的函数进行测试求解
//#define TRSV_DEBUG		//调试输出测试信息
//#define OUTPUT_RESULT		//保存输出结果

//#define UPPER_TEST		//上三角形求解测试
//#define TRANSPOSE_TEST	//稀疏矩阵转置（ CSC <-> CSR ）

//计算两个数组之间的误差
swSparseBool swSparse_d_compare_vec(swSparseInt n, const vec_t a, const vec_t b);

//进行CSC格式的SpMV计算，用于后续的计算结果验证
void SpMV_seq_csc(swSparseMatrix mat, vec_t x, vec_t b, int n)
{
	int i, j;
	int *col, *row;
	vec_t val;
	col = mat->matrix.csrc->offsets;
	row = mat->matrix.csrc->indices;
	val = mat->matrix.csrc->values;

	if(mat->element_type == SWSPARSE_REAL_SINGLE || mat->element_type == SWSPARSE_REAL_DOUBLE)
	{
		for(i = 0; i < n; i++)
			b[i] = 0.0;
	}
	else if(mat->element_type == SWSPARSE_COMPLEX_SINGLE || mat->element_type == SWSPARSE_COMPLEX_DOUBLE)
	{
		for(i = 0; i < n; i++)
			b[i] = 0.0 + 0.0 * _Complex_I;
	} 
	for(i = 0; i < n; i++)
	{
		for(j = col[i]; j < col[i+1]; j++)
		{
			b[row[j]] += val[j] * x[i];
		}
	}
}

//串行程序的TRSV下三角求解计算（Ax = b）
#if defined(UPPER_TEST) && !defined(TRANSPOSE_TEST)
void trsv_seq_csc(swSparseMatrix matrix, vec_t b, vec_t x)
{
	int   *col = matrix->matrix.csrc->offsets;
	int   *row = matrix->matrix.csrc->indices;
	vec_t  val = matrix->matrix.csrc->values;

	int i, j;
	if(x != b)
		for(i = 0; i < matrix->n; i++)
			x[i] = b[i];

	for(i = matrix->n-1; i >= 0; i--)
	{
		x[i] /= val[col[i+1]-1];
		for(j = col[i+1]-2; j >= col[i]; j--)

		{
			x[row[j]] -= val[j] * x[i];
		}
	}
	return; 
}
#else
void trsv_seq_csc(swSparseMatrix matrix, vec_t b, vec_t x)
{
	int   *col = matrix->matrix.csrc->offsets;
	int   *row = matrix->matrix.csrc->indices;
	vec_t  val = matrix->matrix.csrc->values;

	int i, j;
	if(x != b)
		for(i = 0; i < matrix->n; i++)
			x[i] = b[i];

	for(i = 0; i < matrix->n; i++)
	{
		x[i] /= val[col[i]];
		for(j = col[i] + 1; j < col[i+1]; j++)
		{
			x[row[j]] -= val[j] * x[i];
		}
	}
	return; 
}
#endif

/**
 * 功能：检验x1和x2数组中的元素值是否大致相等（x1[i]==x2[i]）
 * TEST_REAL_DOUBLE 在test.h中对程序的数据类型进行定义（单双精度、实数复数）
 * x1: 计算结果
 * x2: 初始数据
 * n：数组长度
 **/
int check(vec_t x1, vec_t x2, int n)
{
	int result = 1;
	int i;
	int error_num = 0;

	for(i = 0; i < n; i++)
	{
#ifdef TEST_REAL_SINGLE
		if(fabs(x1[i] - x2[i]) / MAX(fabs(x2[i]), 1.0) > 1e-6)
		{
			printf("Warning: the wrong %d(%.8e, %.8e)\n", i, x1[i], x2[i]);
			result = 0;
			error_num++;
		}
#endif
#ifdef TEST_REAL_DOUBLE
		if(fabs(x1[i] - x2[i]) / MAX(fabs(x2[i]), 1.0) > 1e-12) 
		{
			printf("Warning: the wrong %5d(%.16e, %.16e)\n", i, x1[i], x2[i]);
			result = 0;
			error_num++;
		}
#ifdef TRSV_DEBUG
		else
		{
//			printf("the wrong %5d(%.16e, %.16e)\n", i, x1[i], x2[i]);
		}
#endif
#endif
#ifdef TEST_COMPLEX_SINGLE
		if(fabs(creal(x1[i]) - creal(x2[i])) / MAX(fabs(creal(x2[i])), 1.0) > 1e-6 || fabs(cimag(x1[i]) - cimag(x2[i])) / MAX(fabs(cimag(x2[i])), 1.0) > 1e-6) 
		{
			printf("Warning: the wrong %d(%.8e + %.8ei, %.8e + %.8ei)\n", i, creal(x1[i]), cimag(x1[i]), creal(x2[i]), cimag(x2[i]));
			result = 0;
		}
#endif
#ifdef TEST_COMPLEX_DOUBLE
		if(fabs(creal(x1[i]) - creal(x2[i])) / MAX(fabs(creal(x2[i])), 1.0) > 1e-12 || fabs(cimag(x1[i]) - cimag(x2[i])) / MAX(fabs(cimag(x2[i])), 1.0) > 1e-12)//TODO 
		{
			printf("Warning: the wrong %d(%.16e + %.16ei, %.16e + %.16ei)\n", i, creal(x1[i]), cimag(x1[i]), creal(x2[i]), cimag(x2[i]));
			result = 0;
		}
#endif
	}
	printf("error_num = %d\n", error_num);

	return result;
}

//计算复数的模sqrt(实部*实部+虚部*虚部)
#if defined(TEST_COMPLEX_SINGLE)
float cabs_m(data_t num)
{
	float ret = sqrt(creal(num)*creal(num) + cimag(num)*cimag(num));
	return ret;
}
#elif defined(TEST_COMPLEX_DOUBLE) 
double cabs_m(data_t num)
{
	double ret = sqrt(creal(num)*creal(num) + cimag(num)*cimag(num));
	return ret;
}
#endif

//Ax=b，进行后向结果验证
int check_offset_new(vec_t x_ret, vec_t b_back, vec_t b_org, int n, int max_nnz_num, swSparseMatrix mat, FILE *file, char *mat_name)
{
	int i;
	int nnz = mat->nnz;
	int result = 0;
	int error_num = 0;

	double max_offset = 0.0;
#if defined(TEST_REAL_SINGLE) || defined(TEST_COMPLEX_SINGLE)
	double accuracy = 1e-7;
#elif defined(TEST_REAL_DOUBLE) || defined(TEST_COMPLEX_DOUBLE)
	double accuracy = 1e-15;
#endif

	vec_t fabs_b = (vec_t) malloc(n * sizeof(*fabs_b)); 
	vec_t fabs_x = (vec_t) malloc(n * sizeof(*fabs_x)); 
	vec_t fabs_v = (vec_t) malloc(nnz * sizeof(*fabs_v));

	memcpy(fabs_v, mat->matrix.csrc->values, nnz*sizeof(*fabs_v));

#if defined(TEST_REAL_SINGLE) || defined(TEST_REAL_DOUBLE) 
	for(i = 0; i < n; i++)
		fabs_x[i] = fabs(x_ret[i]);

	for(i = 0; i < nnz; i++)
		fabs_v[i] = fabs(fabs_v[i]);
#else
	for(i = 0; i < n; i++)
		fabs_x[i] = (data_t)cabs_m(x_ret[i]);

	for(i = 0; i < nnz; i++)
		fabs_v[i] = (data_t)cabs_m(fabs_v[i]);
#endif

	vec_t val_tmp = (vec_t)mat->matrix.csrc->values; 
	mat->matrix.csrc->values = fabs_v;
	SpMV_seq_csc(mat, fabs_x, fabs_b, n);
	mat->matrix.csrc->values = val_tmp;

	double limit = (max_nnz_num * accuracy) / (1 -  accuracy);

	for(i = 0; i < n; i++)
	{
#if defined(TEST_REAL_SINGLE) || defined(TEST_REAL_DOUBLE) 
		data_t tmp = fabs(b_back[i] - b_org[i]) / fabs_b[i];
#elif  defined(TEST_COMPLEX_SINGLE)
		float  tmp = cabs_m(b_back[i] - b_org[i]) / fabs_b[i];
#elif  defined(TEST_COMPLEX_DOUBLE)
		double tmp = cabs_m(b_back[i] - b_org[i]) / fabs_b[i];
#endif
		if(tmp > max_offset) 
			max_offset = tmp;

		if(tmp > limit)
		{
			error_num++;
			printf("accuracy check: row %8d = %.16f\n", i, tmp);
		}
	}
	printf("error_num = %d\n", error_num);

	if(max_offset <= limit)
		result = 1;

#if defined(TEST_REAL_SINGLE) || defined(TEST_COMPLEX_SINGLE)
	printf("max_offset = %.8f, limit = %.8f\n", max_offset, limit);
#elif defined TEST_REAL_DOUBLE || defined(TEST_COMPLEX_DOUBLE)
	printf("max_offset = %.16f, limit = %.16f\n", max_offset, limit);
#endif

	free(fabs_x);
	free(fabs_b);
	free(fabs_v);
	return result;
}
/**
 *
 * x1: compute result
 * x2: verificated data
 * offset:
 */
int check_offset(vec_t x1, vec_t x2, vec_t offset, int n, swSparseMatrix mat, FILE *file, char *mat_name)
{
	int result = 1;
	int error_num = 0;
	int res_nan_num = 0;
	int res_inf_num = 0;
	int off_nan_num = 0;
	int off_inf_num = 0;
	int i;
	int *col, *row;
	vec_t values;
	col    = mat->matrix.csrc->offsets;
	row    = mat->matrix.csrc->indices;
	values = mat->matrix.csrc->values;
	data_t max_offset = 0.0;

#ifdef TEST_REAL_SINGLE
	for(i = 0; i < n; i++)
	{
		if(isnan(x1[i]) == 1)
			res_nan_num++;
		if(isinf(x1[i]) == 1)
			res_inf_num++;
		if(isnan(offset[i]) == 1)
			off_nan_num++;
		if(isinf(offset[i]) == 1)
			off_inf_num++;

		if(fabs(x1[i] - x2[i]) > (2 * offset[i])) 
		{
			printf("Warning: the wrong %d(%.8e, %.8e) offset = %.8e\n", i, x1[i], x2[i], offset[i]);
			result = 0;
			error_num++;
		}
		data_t offset_tmp = fabs(x1[i] - x2[i]) / (2 * offset[i]);
		if(offset_tmp > max_offset)
			max_offset = offset_tmp;
	}
	if(error_num > 0)
		fprintf(file, "%15s: %6d, %6d, %.2%%\n", mat_name, n, error_num, (error_num/n)*100); 
#elif defined TEST_REAL_DOUBLE
	for(i = 0; i < n; i++)
	{
		if(isnan(x1[i]) == 1)
			res_nan_num++;
		if(isinf(x1[i]) == 1)
			res_inf_num++;
		if(isnan(offset[i]) == 1)
			off_nan_num++;
		if(isinf(offset[i]) == 1)
			off_inf_num++;

		if(fabs(x1[i] - x2[i]) > (2 * offset[i])) 
		{
			printf("Warning: the wrong %d(%.16e, %.16e), %.16e, %.16e, %d\n", i, x1[i], x2[i], offset[i], values[col[i]], row[col[i]]);
			result = 0;
			error_num++;
		}
		data_t offset_tmp = fabs(x1[i] - x2[i]) / (2 * offset[i]);
		if(offset_tmp > max_offset)
			max_offset = offset_tmp;
	}
	if(error_num > 0)
		//        fprintf(file, "%15s: %6d, %6d, %.2f%%\n", mat_name, n, error_num, (error_num/n)*100); 
		printf("%15s: %6d, %6d, %.2f%%\n", mat_name, n, error_num, (error_num/n)*100); 
#elif defined TEST_COMPLEX_SINGLE
	for(i = 0; i < n; i++)
	{
		if(fabs(creal(x1[i]) - creal(x2[i])) > 2 * creal(offset[i]) || fabs(cimag(x1[i]) - cimag(x2[i])) > 2 * cimag(offset[i])) {
			printf("Warning: the wrong %d(%.8e + %.8ei, %.8e + %.8ei)\n", i, creal(x1[i]), cimag(x1[i]), creal(x2[i]), cimag(x2[i]));
			result = 0;
			error_num++;
		}
		data_t offset_tmp = fabs(x1[i] - x2[i]) / (2 * offset[i]);
		//            if(offset_tmp > max_offset)
		//                max_offset = offset_tmp;
	}
	if(error_num > 0)
		if(error_num > 0)
			//        fprintf(file, "%15s: %6d, %6d, %.2%%\n", mat_name, n, error_num, (error_num/n)*100); 
			printf("%15s: %6d, %6d, %.2f%%\n", mat_name, n, error_num, ((double)error_num/(double)n)*100); 
#elif defined TEST_COMPLEX_DOUBLE
	for(i = 0; i < n; i++)
	{
		if(fabs(creal(x1[i]) - creal(x2[i])) > 2 * creal(offset[i]) || fabs(cimag(x1[i]) - cimag(x2[i])) > 2 * cimag(offset[i])) {
			printf("Warning: the wrong %d(%.16e + %.16ei, %.16e + %.16ei)\n", i, creal(x1[i]), cimag(x1[i]), creal(x2[i]), cimag(x2[i]));
			result = 0;
			error_num++;
		}
		data_t offset_tmp = fabs(x1[i] - x2[i]) / (2 * offset[i]);
		//            if(offset_tmp > max_offset)
		//                max_offset = offset_tmp;
	}
	if(error_num > 0)
		//        fprintf(file, "%15s: %6d, %6d, %.2%%\n", mat_name, n, error_num, (error_num/n)*100); 
		printf("%15s: %6d, %6d, %.2f%%\n", mat_name, n, error_num, ((double)error_num/(double)n)*100); 
#endif    
	printf("res_nan = %d, res_inf = %d, off_nan = %d, off_inf = %d\n", res_nan_num, res_inf_num, off_nan_num, off_inf_num);
	if(res_nan_num > 0 || res_inf_num > 0)
		return 55;
	if(off_nan_num > 0 || off_inf_num > 0)
		return 56;
	return result;
}

/**
 * 功能：从文件中读取向量数据，
 * 输入参数：file_name（文件名） 、 ele_type（矩阵数据类型[未使用]） 、 n（设定向量长度值）
 * 返回参数：vec（double类型向量）
 * 输入向量文件格式：
 * 第一行：列数[1]  向量长度  复数或实数[ 0 | 1 ]
 * 第二行：data[0](实数|复数)
 * 第三行：data[1](实数|复数)
 *   .       .
 **/
vec_t read_verify_data(const char *file_name, swSparseMatrixElementType ele_type, int *n)
{
	FILE *file;
	vec_t vec;
	file = fopen(file_name, "rb");
	if(file == NULL)
	{
		printf("Cannot open file %s\n", file_name);
		return NULL;
	}
	int header[3];
	size_t count = fread(&header, sizeof(int), 3, file);
	if(count != 3) {
		printf("error in reading: header is not 3\n");
		return NULL;
	}
	if(header[0] != 1)
	{
		printf("error in reading: This is not a vector. N = %d\n", header[0]);
		return NULL;
	}

#if defined(TEST_REAL_DOUBLE) ||  defined(TEST_REAL_SINGLE)
	if(header[2] == 1)
	{
		//real numbers
		double *vec_tmp = malloc(header[1] * sizeof(double));
		count = fread(vec_tmp, sizeof(double), header[1], file);
		if(count != header[1])
		{
			printf("error in reading: the count of data error\n");
			return NULL;
		}
#ifdef TEST_REAL_DOUBLE
		vec = vec_tmp;
#elif defined TEST_REAL_SINGLE
		vec = malloc(header[1] * sizeof(float));
		int i;
		for(i = 0; i < header[1]; i++)
		{
			vec[i] = (float)vec_tmp[i];
		}
		free(vec_tmp);
#endif
	} 
#else
	if (header[2] == 0)
	{
		//complex numbers
		double complex *vec_tmp = malloc(header[1] * sizeof(double complex));
		count = fread(vec_tmp, sizeof(double complex), header[1], file);
		if(count != header[1])
		{
			printf("error in reading: the count of data error\n");
			return NULL;
		}
#ifdef TEST_COMPLEX_DOUBLE
		vec = (vec_t)vec_tmp;
#elif defined TEST_COMPLEX_SINGLE
		vec = malloc(header[1] * sizeof(float complex));
		int i;
		for(i = 0; i < header[1]; i++)
		{
			vec[i] = (float complex)vec_tmp[i];
		}
		free(vec_tmp);
#endif
	}
#endif

	*n = header[1];
	fclose(file); 
	return vec;
}

/**
 * 功能：计算下三角形矩阵中行非零元素个数的最大值
 * 输入参数：CSR或者COO格式的稀疏矩阵
 * 返回参数：max_n（最大行非零元素个数）
 * 打印：Matrix_n(矩阵的行数),Rows_max_nnz(最大行非零元素个数)
 **/
int maxNnzNum(Matrix mat)
{
	int max_n = 0;
	int i, j;
	int n = mat->n;

	int *nnz_row = (int*) malloc(mat->n * sizeof(int));
	for(i = 0; i < n; i++) nnz_row[i] = 0;

	if(mat->format_type == CSR)
	{
		for(i = 0; i < n; i++)
		{
			for(j = mat->matrix.csrc->offsets[i]; j < mat->matrix.csrc->offsets[i+1]; j++)
			{
				if(mat->matrix.csrc->indices[j] <= i)
					nnz_row[i]++;
			}
		}
	}else if(mat->format_type == COO){
		for(i = 0; i < mat->nnz; i++)
		{
			if(mat->matrix.coo->column_indices[i] <= mat->matrix.coo->row_indices[i])
				nnz_row[mat->matrix.coo->row_indices[i]]++;
		}
	}
	for(i = 0; i < n; i++)
	{
		max_n = nnz_row[i] > max_n ? nnz_row[i] : max_n;
	}
	free(nnz_row);

	printf("------- Matrix_n = %d, Rows_max_nnz = %d\n", n, max_n);

	return max_n;
}

int test(cstr_t in_argv, in_op_t in_op, cstr_t out_file, out_op_t out_op) {
	struct timeval start, end, all_start, all_end;	//计时结构体变量
	double t1, t2, t3, fp;	//计时变量
	vec_t x, b, x_add, b_add, x_seq, b_back, x_last;    //x_seq串行程序的计算结果； 
	swSparseMatrix a;    // old_a;
	swSparseErrorStatus ret = SWSPARSE_SUCCESS;
	int n, nnz, old_n;
	int i, j, k;

	//test
	cstr_t in_file;

	int len = strlen(in_argv);
	char *ftmp     = malloc((len+1) * sizeof(char)); 
	char *mat_name = malloc((len+1) * sizeof(char)); 
	strcpy(ftmp, in_argv);

	//输入矩阵文件为mtx
	if(in_op != MM && in_op != BIN)
	{
		printf("\n------*** The Matrix is not (.mtx) or (.bin) ! ***------\n");
		return 2;
	}

	in_file = (cstr_t) ftmp;

	//获取矩阵的名称（去除字符串中的 文件路径 以及 后缀.mtx）
	for(i = strlen(in_file) - 1; i >= 0; i--)
	{
		if(in_file[i] == '/')
		{
			i++;
			j = 0;
			while(in_file[i] != '.')
			{
				mat_name[j] = in_file[i]; 
				i++;
				j++;
			}
			mat_name[j] = '\0';
			break;
		}
	}

	printf("\n\n------- in_file   = %s\n", in_file);
	printf("------- mat_name  = %s\n", mat_name);

#if defined(TEST_REAL_DOUBLE)  || defined(TEST_COMPLEX_DOUBLE)
	Int opt = SWSPARSE_DOUBLE;
#elif defined(TEST_REAL_SINGLE)  || defined(TEST_COMPLEX_SINGLE)
	Int opt = SWSPARSE_SINGLE;
#endif

	switch (in_op)
	{
		case MM:
			ret = swSparse_read_mtx(&a, in_file, opt, SWSPARSE_COO);
			break;
		case BIN:
			ret = swSparse_read_binary(&a, in_file);
			break;
	}
	if(ret != SWSPARSE_SUCCESS) {
		printf("\n\nRead matrix failed\n\n");
		return 2;
	}
	if(a->n != a->m) {
		fprintf(stderr, "\n\nMatrix is not square. n = %d, m = %d, nnz = %d\n\n", a->n, a->m, a->nnz);
		return 6;
	}

	printf("------- Dim of Matrix = %d, nnz = %d\n", a->n, a->nnz);

	//后续的nnz：下三角矩阵非零元个数
	nnz = 0;
	
	n = a->n;
	old_n = a->n;

#ifndef NO_CPE
	//初始化神威快速线程库 
	athread_init();
#endif

	int max_nnz_num = 0;
	//计算最大行非零元素个数
	max_nnz_num = maxNnzNum(a); 

	//将稀疏矩阵格式转换为 CSC格式
	if(a->format_type != CSC)
		ret = swSparse_convert_csc(a, SWSPARSE_IN_PLACE);
	if(ret != SWSPARSE_SUCCESS) {
		return ret;
	}
	printf("\n--------------- Convert to CSC Format finish---------------\n");


	//设置计算时的数据类型（实复数_单双精度）
	swSparseMatrixElementType ele_type;
#ifdef TEST_REAL_DOUBLE
	ele_type = SWSPARSE_REAL_DOUBLE;
#elif defined TEST_REAL_SINGLE
	ele_type = SWSPARSE_REAL_SINGLE;
#elif defined TEST_COMPLEX_DOUBLE
	ele_type = SWSPARSE_COMPLEX_DOUBLE;
#elif defined TEST_COMPLEX_SINGLE
	ele_type = SWSPARSE_COMPLEX_SINGLE;
#endif

#if defined OUTPUT_RESULT
	const char *dir = "../seq_result/";
	const char *suffix = ".res";
	char *rfile_name = (char*)malloc(strlen(dir)+strlen(mat_name)+strlen(suffix));
	strcpy(rfile_name, dir);
	strcat(rfile_name, mat_name);
	strcat(rfile_name, suffix);
#endif

	//随机初始化x向量
	vec_t x_org = (vec_t) malloc(sizeof(*x_org) * n);
	vec_t b_org = (vec_t) malloc(sizeof(*b_org) * n);
	for(i = 0; i < n; ++i) 
	{
		x_org[i] = (data_t) rand() / RAND_MAX;
	}
	//csc格式SpMV计算初始化b向量
	SpMV_seq_csc(a, x_org, b_org, n); 


	//n_nnz：上三角矩阵非零元个数
	int n_nnz = 0;

	//将稀疏矩阵转化为下三角矩阵
	swSparseMatrix created     = (swSparseMatrix) malloc(sizeof(swSparseMatrixData));
	swSparseMatrix created_org = (swSparseMatrix) malloc(sizeof(swSparseMatrixData));
	created->matrix.csrc     = (swSparseMatrixCSRC*)malloc(sizeof(swSparseMatrixCSRC));
	created_org->matrix.csrc = (swSparseMatrixCSRC*)malloc(sizeof(swSparseMatrixCSRC));

	//统计上、下三角矩阵中非零元素的个数（均包含主对角线）。nnz：下三角矩阵非零元个数； n_nnz：上三角矩阵非零元个数
	for(i = 0; i < a->n; i++)//遍历0->n列
	{
		for(j = a->matrix.csrc->offsets[i]; j < a->matrix.csrc->offsets[i+1]; j++)//遍历每一列中的非零元素
		{
#if defined(UPPER_TEST)
			if(a->matrix.csrc->indices[j] <= i)
#else
			if(a->matrix.csrc->indices[j] >= i)//非零元素的行号 >= 列号
#endif
				nnz++;//下
			else
				n_nnz++;//上（上三角矩阵中不包含主对角线中的非零元素，需改写if条件判断）
		}
	}
	printf(" Lower triangular matrix nnz = %d, Upper triangular matrix(no main diagonal) nnz = %d\n", nnz, n_nnz);

	//malloc下三角矩阵所需的内存空间
	int *col, *row, *col_org, *row_org;
	vec_t val, val_org;
	//created下三角矩阵用于并行SpTRSV计算（会对矩阵进行预处理）
	created->m = created->n = a->n;//矩阵的维度（行数、列数）
	created->nnz = nnz;//下三角矩阵中非零元素个数
	col = created->matrix.csrc->offsets = (int *) malloc((n+1) * sizeof(int));//csc格式列偏移
	row = created->matrix.csrc->indices = (int *) malloc((nnz) * sizeof(int));//csc格式行号
	val = created->matrix.csrc->values  = (vec_t) malloc((nnz) * sizeof(*val));//csc格式非零元素值

	//created_org下三角矩阵用于最后的结果验证
	created_org->m = created_org->n = a->n;
	created_org->nnz = nnz;
	col_org = created_org->matrix.csrc->offsets = (int *) malloc((n+1) * sizeof(int));
	row_org = created_org->matrix.csrc->indices = (int *) malloc((nnz) * sizeof(int));
	val_org = created_org->matrix.csrc->values  = (vec_t) malloc((nnz) * sizeof(*val));
	if(col == NULL || row == NULL || val == NULL || col_org == NULL || row_org == NULL || val_org == NULL)
	{
		return SWSPARSE_MALLOC_ERROR;
	}
	int nz = 0;
	col[0] = 0;
	col_org[0] = 0;

//在test.h中根据所需的数据类型，定义了vec_t的数据类型
#ifdef TEST_REAL_DOUBLE
	vec_t old_values = (vec_t)a->matrix.csrc->values;
#elif defined TEST_REAL_SINGLE
	vec_t old_values = (vec_t)a->matrix.csrc->values;
#elif defined TEST_COMPLEX_DOUBLE
	vec_t old_values = (vec_t)a->matrix.csrc->values;
#elif defined TEST_COMPLEX_SINGLE
	double complex *old_values = (double complex*)a->matrix.csrc->values;
#endif
	
	//初始化org下三角形矩阵csc格式数据
	int nzero_ele = 0;//判断主对角线中是否存在零元（判断条件：zero_ele == n）
	for(i = 0; i < a->n; i++)//遍历矩阵的每一列
	{
		for(j = a->matrix.csrc->offsets[i]; j < a->matrix.csrc->offsets[i+1]; j++)//遍历每一列中的非零元素
		{ 
#if defined(UPPER_TEST)
			if(a->matrix.csrc->indices[j] <= i)
#else
			if(a->matrix.csrc->indices[j] >= i)//非零元行号 >= 列号  （下三角矩阵）
#endif
			{
				row_org[nz] = row[nz] = a->matrix.csrc->indices[j];//初始化下三角形矩阵csc格式的列号
#ifdef TEST_REAL_DOUBLE
				val_org[nz] = val[nz] = old_values[j];//初始化下三角形矩阵csc格式的非零元素值
				//	  printf("%d, %d val[%d] = %.12f\n", row[nz], i, nz, old_values[j]);
#elif defined TEST_REAL_SINGLE
				val_org[nz] = val[nz] = old_values[j];
				//	  printf("%d, %d val[%d] = %.12f\n", row[nz], i, nz, old_values[j]);
#elif defined TEST_COMPLEX_DOUBLE
				val_org[nz] = val[nz] = old_values[j];
#elif defined TEST_COMPLEX_SINGLE
				val_org[nz] = val[nz] = (float complex)old_values[j];
#endif
				nz++; 
			}

			if(a->matrix.csrc->indices[j] == i){
				if(fabs(old_values[j]) <= 1e-15){//判断非零元素值是否等于0（具体精度可能有待修改）
					printf("\nWarning: Exist zero elements in diagonal, zero elements row = %d\n\n", i);
					return 54;
				}
				//printf("%d\n",i);
				nzero_ele++;
			}
		}
		col_org[i+1] = col[i+1] = nz;//初始化下三角形矩阵csc格式的列偏移
	}
	printf("--------------- Main diagonal nnz:%d ---------------\n",nzero_ele);
	//判断主对角线中是否存在零元
	if(nzero_ele != a->n)
	{
		printf("------- Warning: Exist zero elements in diagonal! -------\n");
		return 54;
	}
	
	created->matrix.csrc->ordered = created_org->matrix.csrc->ordered = a->matrix.csrc->ordered;
	created->element_type        = created_org->element_type        = ele_type;
	created->format_type         = created_org->format_type         = a->format_type;
	created->status              = created_org->status              = a->status;
	swSparse_destroy(a);
	a = created;//a更新为下三角矩阵

	data_t alpha = 1.0;
#ifdef PERF_TEST
	swSparseTRSVOptions swOpts;//低层次接口
	/*
	*inspect 矩阵预处理
	*execute 执行求解过程
	*iperm_apply 进行重排序
	*/
#else
	swSparseSolverOptions swOpts;//高层次接口
	/*
	*create_solver 创建求解器
	*solve 求解方程组
	*destroy_solver 销毁求解器
	*destroy 销毁矩阵
	*/
#endif

#ifdef TRANSPOSE_TEST
	swOpts.transpose = SWSPARSE_TRANSPOSE;
#else
	swOpts.transpose = SWSPARSE_NON_TRANSPOSE;
#endif

	b = b_org;

	x 	   = (vec_t)malloc(sizeof(*x) * n);
	x_seq  = (vec_t)malloc(sizeof(*x) * n);
	x_last = (vec_t)malloc(sizeof(*x) * n);
	b_back = (vec_t)malloc(sizeof(*x) * n);
	if(x_seq == NULL || b_back == NULL || x_last == NULL || x == NULL || b == NULL)
		return SWSPARSE_MALLOC_ERROR;

	printf("--------------- Start Sequence SpTRSV:\n");


	//TODO CSC or CSR
#ifdef TRANSPOSE_TEST
	swSparseMatrix trans_mat;
	swSparse_transpose(a, &trans_mat);//矩阵转置

	gettimeofday(&start, NULL);
	trsv_seq_csc(trans_mat, b, x_seq);
	gettimeofday(&end, NULL);

	swSparse_destroy(trans_mat);
#else
	gettimeofday(&start, NULL);
	trsv_seq_csc(a, b, x_seq);//串行的SpTRSV计算，将计算结果存至x_seq中，a为下三角矩阵，b为已知向量
	gettimeofday(&end, NULL);
#endif

	t3 = TIME_DIFF(start, end);//统计了串行SpTRSV的计算时间

	printf("------------------------------ Sequence SpTRSV Times: %.3lf ms\n", t3);

	printf("--------------- Start Heterogeneous SpTRSV:\n");

#ifdef PERF_TEST
	swOpts.uplo = 
#else
	swOpts.uplo =  SWSPARSE_LOWER_TRI;//三角矩阵类型（下三角矩阵或上三角矩阵）
	swOpts.diagnal = SWSPARSE_GENERAL_DIAG;//对角非零元表示
	swOpts.solver_type = 
#endif
#ifdef UPPER_TEST
	SWSPARSE_UPPER_TRI;
//TODO a.status
#else
	SWSPARSE_LOWER_TRI;
#endif

#ifdef PERF_TEST
	int *xiperm = (int*) malloc(sizeof(int) * n);//用于将结果向量x由重排后的顺序变换为最初的顺序
	int *biperm = (int*) malloc(sizeof(int) * n);//用于将右端向量b由最初的顺序变换为重排后的顺序。biperm[xiperm[i]] = i。
	b_add       = (vec_t)malloc(sizeof(*x)  * n);
	x_add       = (vec_t)malloc(sizeof(*x)  * n);

	Matrix csc;
	double tbperm1, txperm1, tslt1, texec1;//计时变量
	double tbperm2, txperm2, tslt2, texec2;

	gettimeofday(&all_start, NULL);

	gettimeofday(&start, NULL);
	//对输入矩阵a进行分层、重排序(csc为预处理后的矩阵)，并将重排信息存储于xiperm、biperm，之后再构建SLTCOO格式矩阵
	swSparse_trsv_inspect(a, &csc, xiperm, biperm, &swOpts);
	gettimeofday(&end, NULL);
	tslt1 = TIME_DIFF(start, end);
	printf("------------------------------ SpTRSV swSparse_trsv_inspect Times: %.3lf ms\n", tslt1);
#ifdef TRSV_DEBUG
	for(i = 0; i < n; i++)
		printf("xiperm[%4d] = %4d   biperm[%4d] = %4d\n", i, xiperm[i], i, biperm[i]);
#endif
	if(a!=csc){
		swSparse_destroy(a);
	}
	a = csc;//将预处理后的矩阵变为a
#ifdef TEST_REAL_DOUBLE
	gettimeofday(&start, NULL);
	//向量重排：重排规则为 b_add[ biperm[i]] = b[i]
	swSparse_d_iperm_apply(n, b, b_add, biperm); 
	gettimeofday(&end, NULL);
	tbperm1 = TIME_DIFF(start, end);
	printf("------------------------------ SpTRSV swSparse_d_iperm_apply(biperm) Times: %.3lf ms\n", tbperm1);

	gettimeofday(&start, NULL);
	for(i = 0; i < EXEC_TIMES; i++){
	//利用预处理阶段生成的SLTCOO格式矩阵，进行稀疏下三角并行求解
		swSparse_d_trsv_execute(alpha, a, b_add, x_add, &swOpts);
	}
	gettimeofday(&end, NULL);
	texec1 = TIME_DIFF(start, end)/ EXEC_TIMES;
	printf("------------------------------ SpTRSV swSparse_d_trsv_execute Times: %.3lf ms\n", texec1);

	gettimeofday(&start, NULL);
	//向量重排：重排规则为 x[xperm[i]] = x_add[i]
	swSparse_d_iperm_apply(n, x_add, x, xiperm); 
	gettimeofday(&end, NULL);
	txperm1 = TIME_DIFF(start, end);
	printf("------------------------------ SpTRSV swSparse_d_iperm_apply(xiperm) Times: %.3lf ms\n", txperm1);
#elif defined TEST_REAL_SINGLE
	gettimeofday(&start, NULL);
	swSparse_s_iperm_apply(n, b, b_add, biperm); 
	gettimeofday(&end, NULL);
	tbperm1 = TIME_DIFF(start, end);

	gettimeofday(&start, NULL);
	swSparse_s_trsv_execute(alpha, a, b_add, x_add, &swOpts);
	gettimeofday(&end, NULL);
	texec1 = TIME_DIFF(start, end);

	gettimeofday(&start, NULL);
	swSparse_s_iperm_apply(n, x_add, x, xiperm); 
	gettimeofday(&end, NULL);
	txperm1 = TIME_DIFF(start, end);
#elif defined TEST_COMPLEX_SINGLE
	gettimeofday(&start, NULL);
	swSparse_c_iperm_apply(n, b, b_add, biperm); 
	gettimeofday(&end, NULL);
	tbperm1 = TIME_DIFF(start, end);

	gettimeofday(&start, NULL);
	swSparse_c_trsv_execute(alpha, a, b_add, x_add, &swOpts);
	gettimeofday(&end, NULL);
	texec1 = TIME_DIFF(start, end);

	gettimeofday(&start, NULL);
	swSparse_c_iperm_apply(n, x_add, x, xiperm); 
	gettimeofday(&end, NULL);
	txperm1 = TIME_DIFF(start, end);
#elif defined TEST_COMPLEX_DOUBLE
	gettimeofday(&start, NULL);
	swSparse_z_iperm_apply(n, b, b_add, biperm); 
	gettimeofday(&end, NULL);
	tbperm1 = TIME_DIFF(start, end);

	gettimeofday(&start, NULL);
	swSparse_z_trsv_execute(alpha, a, b_add, x_add, &swOpts);
	gettimeofday(&end, NULL);
	texec1 = TIME_DIFF(start, end);

	gettimeofday(&start, NULL);
	swSparse_z_iperm_apply(n, x_add, x, xiperm); 
	gettimeofday(&end, NULL);
	txperm1 = TIME_DIFF(start, end);
#endif

	gettimeofday(&all_end, NULL);
	t1 = TIME_DIFF(all_start, all_end);
	printf("------------------------------ SpTRSV Total(pretreatment + execute) Times: %.3lf ms\n", t1);

	FILE *pfile;
#ifdef TEST_REAL_DOUBLE
	pfile = fopen("perf_trsv_real_d.csv","a+");
#elif defined TEST_REAL_SINGLE
	pfile = fopen("perf_trsv_real_s.csv","a+");
#elif defined TEST_COMPLEX_SINGLE
	pfile = fopen("perf_trsv_cmp_s.csv","a+");
#elif defined TEST_COMPLEX_DOUBLE
	pfile = fopen("perf_trsv_cmp_d.csv","a+");
#endif
	if(pfile == NULL)
	{
		printf("error: open file performance_trsv failed\n");
	}

	long long swaps = 0;

	//计算带宽
#ifdef SWAPS_TEST
	for(i = 0; i < 32; i++)
	{
		swaps += a->matrix.sltcoo->pro_swaps[i];
		swaps += a->matrix.sltcoo->con_swaps[i];
	}
#endif

	int levels  = a->matrix.sltcoo->levels;//层次总数量
	int plevels = a->matrix.sltcoo->plevels;//稀疏层次块布局中，分块数量总和
	int nod_num = a->matrix.sltcoo->plevels - a->matrix.sltcoo->levels;
	int dma_size = (nnz * 2 * sizeof(int) + (nnz + 2 * old_n + nod_num * 1024) * sizeof(*x) \
			+ (levels + plevels + 32*9*plevels+1 + 32*levels)*sizeof(int));
	double bw = (swaps / (texec1 * 1e-3)) / 1024 / 1024 / 1024;//带宽

	fp = ((nnz << 1) - old_n) / (1e6 * texec1);//浮点计算性能
	double nnz_pern = (double)nnz / (double)old_n;
	double nnz_perl = (double)nnz / (double)levels;//平均每层次中非零元个数

	printf("------- dma_size = %d\n", dma_size);
	printf("------- swaps    = %d\n", swaps);//
	double swaps_kb = (double)swaps / 1024;
	double swaps_nnz =(double)swaps / (nnz * sizeof(*x));

	fprintf(pfile, "%s,%d,%d,%.3lf,%.3lf,%.3lf,%.3lf,%.3lf,%.3lf,%.3lf,%d,%.3lf,%.3lf,%.3lf,%.3lf\n", 
			mat_name, old_n, nnz, nnz_pern, t1, texec1, t3, t3/texec1, t3/t1, bw, levels, nnz_perl, fp, swaps_kb, swaps_nnz);

	printf("------- %s (rowNum: %d , nnzNum: %d , avgRow_nnz: %.3lf ): \n------- Total Time=%.3lf ms,  Execute Time=%.3lf ms,  Sequential Time=%.3lf ms\n", 
			mat_name, old_n, nnz, nnz_pern, t1, texec1, t3);
	printf("------- SeqTime/ExecTime=%.3lf,   SeqTime/TotalTime=%.3lf,  Bandwidth=%.3lf GB/s,  sltCOO->levels=%d,  nnz_per_levels=%.3lf\n",t3/texec1, t3/t1, bw, levels, nnz_perl);
	printf("------- Flops=%.3lf Gflop/s,  Swaps_kb=%.3lf,  Swaps_nnz=%.3lf\n", fp, swaps_kb, swaps_nnz);
	fclose(pfile);

#else

	gettimeofday(&start, NULL);
	//solver
	swSparseSolver solver;
	ret = swSparse_create_solver(&solver, a, &swOpts);
	if(ret != SWSPARSE_SUCCESS) {
		return ret;
	}
	gettimeofday(&end, NULL);
	t1 = TIME_DIFF(start, end);

#ifdef TRSV_DEBUG
	for(i = 0; i < n; i++)
		printf("xiperm[%4d] = %4d    biperm[%4d] = %4d\n", i, solver->xiperm[i], i, solver->biperm[i]);
#endif
	n = a->n;
	if(solver->lu != a){
		swSparse_destroy(a);
	}
	a = solver->lu;

	printf("----------------------------------------heterogeneous excute:\n");
  
#ifdef TEST_REAL_SINGLE
	gettimeofday(&start, NULL);
	ret = swSparse_s_solve_v(alpha, solver, b, x);
	gettimeofday(&end, NULL);
	t2 = TIME_DIFF(start, end);
#elif defined TEST_REAL_DOUBLE
	gettimeofday(&start, NULL);
	ret = swSparse_d_solve_v(alpha, solver, b, x);
	gettimeofday(&end, NULL);
	t2 = TIME_DIFF(start, end);
#elif defined TEST_COMPLEX_SINGLE
	gettimeofday(&start, NULL);
	ret = swSparse_c_solve_v(alpha, solver, b, x);
	gettimeofday(&end, NULL);
	t2 = TIME_DIFF(start, end);
#elif defined TEST_COMPLEX_DOUBLE
	gettimeofday(&start, NULL);
	ret = swSparse_z_solve_v(alpha, solver, b, x);
	gettimeofday(&end, NULL);
	t2 = TIME_DIFF(start, end);
#endif

#endif
	int check_ret = 0;
	//check x   x_seq
	printf("------------------------------ Check heterogeneous with sequential  result:\n");
	check_ret = check(x, x_seq, old_n);

#ifdef OUTPUT_RESULT

	FILE *res_file = fopen( rfile_name,"wb");
	if(res_file == NULL) {
		printf("%s open failed\n", mat_name);
	}
	int nvec = 1;
	int type_flag;
	if(created_org->element_type == SWSPARSE_REAL_SINGLE || created_org->element_type == SWSPARSE_REAL_DOUBLE) {
		type_flag = 1;
	} else {
		type_flag = 0;
	}

	fwrite(&nvec,      sizeof(int), 1, res_file);
	fwrite(&old_n,     sizeof(int), 1, res_file);
	fwrite(&type_flag, sizeof(int), 1, res_file);

	fwrite(x, sizeof(data_t), old_n, res_file);

	fclose(res_file);
#endif

	//compute b back with x
	SpMV_seq_csc(created_org, x, b_back, old_n);

	//check b_back  b
	const char *file_name = "offset_out";
	FILE *file = fopen(file_name, "a+");
	if(file == NULL)
	{
		printf("error: %s file open failed\n", file_name);
		return 0;
	}
	printf("------------------------------ Check offsets of b_result and b:\n");

#ifdef NEW_ACCURACY
	check_ret = check_offset_new(x, b_back, b, old_n, max_nnz_num, created_org, file, mat_name);
#endif

#ifdef TRSV_DEBUG_PRE 
	printf("------------------------------ TRSV_DEBUG:\n");
	for(i = 0; i < error_nums; i++)
	{
		int er = error_rows[i];
		data_t be = b[er];
		if(i == 0)
			printf("be = %.16f\n", be);
		for(j = 0; j < nnz_nums[i] - 1; j++)
		{
			be -= error_val[i][j] * x[error_col_idx[i][j]]; 
			if(i == 0)
				printf("be = %.16f, sub = %.16f, val = %.16f, x = %.16f\n", be, error_val[i][j] * x[error_col_idx[i][j]], error_val[i][j], x[error_col_idx[i][j]]);
		}
		if(i == 0)
			printf("be = %.16f\n", be);
		x[er] = be / error_val[i][j];
		//        printf("error row = %.10d, value = %.12f\n", er, x[er]);
	}

	//    check_ret = check(x, x_seq, old_n, a, b);
	SpMV_seq_csc(created_org, x, b_back, old_n);
#ifdef NEW_ACCURACY
	check_ret = check_offset_new(x, b_back, b, old_n, max_nnz_num, created_org, file, mat_name);
#endif
	
#endif //match TRSV_DEBUG


	fclose(file);

#ifndef NO_CPE
	athread_halt();
#endif
	switch (out_op)
	{
		case REF:
			ret = read_vec(n, x_seq, out_file);
			if(ret != SWSPARSE_SUCCESS) {
				return 4;
			}
			if(!swSparse_d_compare_vec(n, x, x_seq)) {
				return 5;
			}
			break;
		case INOUT:
			ret = swSparse_write_binary(a, out_file);
			if(ret != SWSPARSE_SUCCESS) {
				return 4;
			}
			/* fall through */
		case OUT:
			//            ret = write_vec(n, x, out_file);
			//            if(ret != SWSPARSE_SUCCESS) {
			//                return 4;
			//            }
			break;
	}

#ifndef NO_CPE
#define TYPE "parallel"
#else
#define TYPE "sequential"
#endif

#ifndef PERF_TEST
	int nod_num = a->matrix.sltcoo->plevels - a->matrix.sltcoo->plevels;
	double bw = ((nnz * 2 * sizeof(int) + (nnz + 2 * n + nod_num * 1024) * sizeof(*x)
				+ (a->matrix.sltcoo->levels + a->matrix.sltcoo->plevels
					+ 32*9*a->matrix.sltcoo->plevels+1 + 32)*sizeof(int))
			/ (t2 * 1e-3)) / 1024 / 1024 / 1024;

	fp = ((nnz << 1) - n) / (1e6 * t2);            // floating point performance

	printf(TYPE" run time: %.3lf ms, %.3lf ms, %lf Gflop/s, my_sequential time: %.3lf ms, bandwidth = %.3lf GB/s, nod_num = %d\n", t1, t2, fp, t3, bw, nod_num);
#endif

	free(b);
	free(b_back);

#ifdef PERF_TEST
	free(x_add);
	free(b_add);
#endif
	free(x);
	free(x_seq);
	free(x_last);
	swSparse_destroy(a);
	swSparse_destroy(created_org);
	//swSparse_destroy_solver(solver);

	if(check_ret == 0)
	{
		printf("------------------------------ Check offsets of b_result and b failed :\n");
		return 51;
	}
	else if(check_ret == 1)
	{
		printf("------------------------------ Check offsets of b_result and b success:\n");
		return 0;
	}
	else
	{
		printf("------------------------------ Exist nan or inf\n");
		return check_ret;
	}

#ifdef CSV_OUT
	//   FILE *f = fopen("results_sptrsv_"TYPE".csv","a");
	//   fprint_matrix_name(f, in_file);
	//   fprintf(f, ", %d, %d, %.3lf, %.3lf, %lf\n", n, a_nnz, t1, t2, fp);
	//   fclose(f);`
#endif
	
}


