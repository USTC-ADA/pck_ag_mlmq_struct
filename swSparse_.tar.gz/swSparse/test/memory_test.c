#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <athread.h>
#include <pthread.h>
#include <sys/time.h>
#include "swSparse.h"
#include "internal/memory.h"

int main(int argc, char **argv) {
    const int rep = 1;
    const int n = 7654321;
    struct timeval start, end;
    double *a, *b, *c;
    int i;
    double t1, t2;

    if(argc > 1 && strcmp(argv[1], "-x") == 0) {
        a = (double*)_sw_xmalloc(sizeof(double)*n);
        b = (double*)_sw_xmalloc(sizeof(double)*n);
        c = (double*)_sw_xmalloc(sizeof(double)*n);
    } else {
        a = (double*)malloc(sizeof(double)*n);
        b = (double*)malloc(sizeof(double)*n);
        c = (double*)malloc(sizeof(double)*n);
    }
    athread_init();

    if((a == NULL) || (b == NULL) || (c == NULL)) {
        return 2;
    }
    printf("Testing with");
    for(i = 0; i < argc; ++i) {
        printf(" %s", argv[i]);
    }
    printf("\n");
    
    //printf("initializing\n");
    srand(1234531);
    for(i = 0; i < n; ++i) {
        a[i] = (double)rand() / (double)RAND_MAX - 0.5;
    }
    //printf("start testing\n");

    gettimeofday(&start, NULL);
    for(i = 0; i < rep; ++i) {
        swSparse_memcpy(b, a, sizeof(double)*n);
    }
    gettimeofday(&end, NULL);
    t1 = 1e9 * (double)(end.tv_sec - start.tv_sec) + 1e3 * (double)(end.tv_usec - start.tv_usec);

    gettimeofday(&start, NULL);
    for(i = 0; i < rep; ++i) {
        memcpy(c, a, sizeof(double)*n);
    }
    gettimeofday(&end, NULL);
    t2 = 1e9 * (double)(end.tv_sec - start.tv_sec) + 1e3 * (double)(end.tv_usec - start.tv_usec);

    for(i = 0; i < n; ++i) {
        if(b[i] != c[i]) {
            fprintf(stderr, "error: b[%d] = %lf, c[%d] = %lf\n", i, b[i], i, c[i]);
        }
    }
    printf("swSparse_memcpy: %lfGB/s, memcpy: %lfGB/s\n", (2*sizeof(double)*n*rep)/t1, (2*sizeof(double)*n*rep)/t2);

    gettimeofday(&start, NULL);
    for(i = 0; i < rep; ++i) {
        swSparse_memset(b, 0, sizeof(double)*n);
    }
    gettimeofday(&end, NULL);
    t1 = 1e9 * (double)(end.tv_sec - start.tv_sec) + 1e3 * (double)(end.tv_usec - start.tv_usec);

    gettimeofday(&start, NULL);
    for(i = 0; i < rep; ++i) {
        memset(c, 0, sizeof(double)*n);
    }
    gettimeofday(&end, NULL);
    t2 = 1e9 * (double)(end.tv_sec - start.tv_sec) + 1e3 * (double)(end.tv_usec - start.tv_usec);

    for(i = 0; i < n; ++i) {
        if(b[i] != c[i]) {
            fprintf(stderr, "error: b[%d] = %lf, c[%d] = %lf\n", i, b[i], i, c[i]);
            return 1;
        }
    }
    printf("swSparse_memset: %lfGB/s, memset: %lfGB/s\n", (sizeof(double)*n*rep)/t1, (sizeof(double)*n*rep)/t2);
    //printf("stop testing\nfinalizing\n");
    if(argc > 1 && strcmp(argv[1], "-x") == 0) {
        _sw_xfree(a);
        _sw_xfree(b);
        _sw_xfree(c);
    } else {
        free(a);
        free(b);
        free(c);
    }
    athread_halt();
    return 0;
}
