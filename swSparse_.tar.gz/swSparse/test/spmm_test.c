#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <sys/time.h>
#include <complex.h>

#ifndef NO_CPE
#include "internal/crts.hpp"
#endif
#include "swSparse.h"
#include "test.h"

#define TIME(a,b) (1.0*((b).tv_sec-(a).tv_sec)+0.000001*((b).tv_usec-(a).tv_usec))

void Print_Matrix(swSparseMatrixData *Matrix){

  int i,j;
  swSparseMatrixCSRC MatrixCSR;

  printf("In Print!\n");

  printf("%d %d %d\n",Matrix->n,Matrix->m,Matrix->nnz);
  //!MatrixCSR = *(Matrix_->matrix.csrc);
  for ( i = 0;i<=Matrix->n ; i++) printf("%d ",Matrix->matrix.csrc->offsets[i]);
  printf("\n");
  for ( i = 0; i<Matrix->nnz;i++) printf("%d ",Matrix->matrix.csrc->indices[i]);
  printf("\n");
  double * v = Matrix->matrix.csrc->values;
  for ( i = 0; i<Matrix->nnz;i++) printf("%.10f ",v[i]);
  printf("\n");

}

long long SpMM_Master_Answer_D(double alpha , swSparseMatrix Matrix_  , int nvec, double *x, double beta , double *b ){


 int i, j,p ;

 double * v = Matrix_->matrix.csrc->values;
 double * b_tmp = malloc(Matrix_->m * nvec * sizeof(double)); 

    for (i = 0 ; i < Matrix_->m * nvec; i++) b_tmp[i] = 0.0;

    for (p = 0 ; p < nvec ; p++){

        for (i = 0 ; i < Matrix_->m ; i ++)
            for(j = Matrix_->matrix.csrc->offsets[i]; j < Matrix_->matrix.csrc->offsets[i+1] ; j ++){
                b_tmp[i + p * Matrix_->m] += alpha * v[j] * x[Matrix_->matrix.csrc->indices[j] + p * Matrix_->n];
            }
    

    }

    for (i = 0 ; i < Matrix_->m * nvec ; i ++){
        b[i] = b[i] * beta + b_tmp[i];
    }

    return 0;
}

int check_d(double *a, double *b, int m){

  int i;
  double sa,sb;
  double ma = -1;
 /*
  for(i = 0; i < n; i ++)
  {
    double err = fabs(a[i]-b[i]);
    if (err / a[i] > ma || ma == -1) {
      ma = err;
      sa = a[i];
      sb = b[i];
    }
  }

  printf("Max diff %.16lf %.16lf %.16lf\n" , ma , sa , sb);  
  */
   printf("Double: ");
   for(i = 0; i < m; i ++)
    {
        double err = fabs(a[i]-b[i]);
        if(err > 1e-10)
        {
            printf("Frist error in %d (%.12lf %.12lf)\n", i, a[i], b[i]);
            return -1;
        }
    }
    printf("Check success\n");
    return 0;

}

int test(cstr_t in_file, in_op_t in_op, cstr_t out_file, out_op_t out_op) {
    struct timeval start, end;
    double t;
    swSparseMatrix a, b, c;
    swSparseErrorStatus ret = SWSPARSE_SUCCESS;
    swSparseMMOptions options;
    int i,j,k;
    double time_master,time_salve;
    double ratio;

    switch (in_op)
    {
        case MM:
            ret = swSparse_read_mtx(&c, in_file, SWSPARSE_DOUBLE, SWSPARSE_COO);
            break;
        case BIN:
            ret = swSparse_read_binary(&c, in_file);
            break;
        case WXL:
            break;
    }
    if(ret != SWSPARSE_SUCCESS) {
        return 2;
    }

#ifndef NO_CPE
    athread_init();
#endif

    ret = swSparse_convert_csr(c,&a);
    
    //Print_Matrix(a);


    ret = swSparse_mm_inspect(a,&b,&options);

    printf("Finish inspect\n");


    int vector_col = 10;
    double *x = malloc(a->n*vector_col*sizeof(double));
    double *b0 = malloc(a->m*vector_col*sizeof(double));
    double *b1 = malloc(a->m*vector_col*sizeof(double));
    // double x[vector_col][a->n];
    // double b0[vector_col][a->m];
    // double b1[vector_col][a->m];  
    double alpha,beta,addional;

    alpha = 1.0;
    beta  = 0.0;

    for (i = 0 ; i <a->n * vector_col;  i++) x[i] = i / vector_col;
    for (i = 0 ; i <a->m * vector_col;  i++) b0[i] = 0;
    for (i = 0 ; i <a->m * vector_col;  i++) b1[i] = 0;

    int ldx = a->n;
    int ldy = a->m;

    options.transpose = SWSPARSE_NON_TRANSPOSE;
    
    gettimeofday(&start, NULL);
    SpMM_Master_Answer_D(alpha , a , vector_col, x, beta , b0 );
    gettimeofday(&end, NULL);
    
    time_master = TIME(start,end);
    printf("<Master> Time: %.6lfs\n",time_master);

    gettimeofday(&start, NULL);
    ret = swSparse_d_mm_execute(alpha , b, vector_col, x,ldx,beta , b1,ldy ,&options);
    gettimeofday(&end, NULL);
    time_salve = TIME(start,end);
    printf("<Slave> Time: %.6lfs\n",time_salve);

    check_d(b0,b1,a->m*vector_col);

    if (alpha == 1.0) ratio = 2.0;
    else ratio = 3.0;

    if (beta == 0.0) addional = 0.0;
    else addional = a->m*2;

    printf("acc %.4f , %.4f Gflops \n" ,time_master / time_salve ,  0.000000001*(ratio*a->nnz + addional) / time_salve );


    swSparse_destroy(a);
    swSparse_destroy(b);
    swSparse_destroy(c);

    

    return 0;
}