#include <sys/time.h>

#ifndef NO_CPE
#include <athread.h>
#endif
#include "swSparse.h"
#include "test.h"
#include <string.h>

void Print_Matrix(swSparseMatrixData *Matrix){

  int i,j;
  swSparseMatrixCSRC MatrixCSR;

  printf("In Print!\n");

  printf("%d %d %d\n",Matrix->n,Matrix->m,Matrix->nnz);
  //!MatrixCSR = *(Matrix_->matrix.csrc);
  for ( i = 0;i<=Matrix->n ; i++) printf("%d ",Matrix->matrix.csrc->offsets[i]);
  printf("\n");
  for ( i = 0; i<Matrix->nnz;i++) printf("%d ",Matrix->matrix.csrc->indices[i]);
  printf("\n");
  double * v = Matrix->matrix.csrc->values;
  for ( i = 0; i<Matrix->nnz;i++) printf("%.10f ",v[i]);
  printf("\n");

}

long long SpMV_Master_Answer_D(double alpha , swSparseMatrix Matrix_  , double *x, double beta , double *b  ){


 int i, j;

 double * v = Matrix_->matrix.csrc->values;
 double b_tmp[Matrix_->m];

    memset(b_tmp , 0 , sizeof(b_tmp));


    for (i = 0 ; i < Matrix_->m ; i ++)
        for(j = Matrix_->matrix.csrc->offsets[i]; j < Matrix_->matrix.csrc->offsets[i+1] ; j ++)
            b_tmp[i] += alpha * v[j] * x[Matrix_->matrix.csrc->indices[j]];
    for (i = 0 ; i < Matrix_->m ; i ++)
        b[i] = b[i] * beta + b_tmp[i];

    return 0;
}




int test(cstr_t in_file, in_op_t in_op, cstr_t out_file, out_op_t out_op) {
    struct timeval start, end;
    double t;
    swSparseMatrix a, b, c;
    swSparseErrorStatus ret = SWSPARSE_SUCCESS;
    swSparseMVOptions options;
    int i,j,k;
    double time_master,time_salve;
    double ratio;

    switch (in_op)
    {
        case MM:
            ret = swSparse_read_mtx(&c, in_file, SWSPARSE_DOUBLE, SWSPARSE_COO);
            break;
        case BIN:
            ret = swSparse_read_binary(&c, in_file);
            break;
        case WXL:
            break;
    }
    if(ret != SWSPARSE_SUCCESS) {
        return 2;
    }

#ifndef NO_CPE
    athread_init();
#endif
    ret = swSparse_convert_csr(c,&a);

    Print_Matrix(a);

    double x[a->n];
    double b0[a->m];
    double b1[a->m];  

    for (i = 0 ; i <a->n ;  i++) x[i] = 1;
    for (i = 0 ; i <a->m ;  i++) b0[i] = 0;
    for (i = 0 ; i <a->m ;  i++) b1[i] = 0;

    options.transpose = SWSPARSE_TRANSPOSE;
    
    SpMV_Master_Answer_D(1 , a , x,0 , b0 );
    for (i = 0 ; i <a->m ; i++) printf("%.4f ",b0[i]);
    printf("\n");

    ret = swSparse_d_mv_execute(1 , a, x,0 , b1 ,&options);
    for (i = 0 ; i <a->m ; i++) printf("%.4f ",b1[i]);
    printf("\n");


    swSparse_destroy(a);

    

    return 0;
}