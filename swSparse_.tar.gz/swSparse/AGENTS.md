# AGENTS.md — swSparse



## 构建

- 编译器仅支持神威平台：`sw9gcc` / `sw9g++`（非 Linux 原生 gcc，不可跨平台）
- 构建命令：`sh make.sh`（调用 `scripts/build.sh install install`）
- 产出：`install/bin/`（可执行文件）、`install/lib/`（`libswsparse.a` + `libswsparse_seq.a`）
- METIS 默认开启（`build.sh` 中 `LINK_LIBMETIS=ON`），需 `METIS_PATH` 正确配置

## 两个库目标

| 库 | CMake target | 用途 | 特殊宏 |
|---|---|---|---|
| `libswsparse.a` | `swsparse` | MPE + 64 CPE 异构版 | - |
| `libswsparse_seq.a` | `swsparse_seq` | 纯 MPE 串行版 | 链接时加 `-DNO_CPE` |

## 测试可执行文件

| 可执行文件 | 测试文件 | 功能 | 输入 |
|---|---|---|---|
| `stsptrsv_hetero_test` | `test/structsptrsv_test.c` | 结构化 SpTRSV | `input.struct` |
| `stspmv_hetero_test` | `test/structspmv_test.c` | 结构化 SpMV | `input.struct` |
| `sptrsv_hetero_test` | `test/sptrsv_test.c` | 非结构化 SpTRSV | 命令行传 `.mtx` |

## 四版本性能对比（结构化 SpTRSV）

| 版本 | 对应实现 | 说明 |
|---|---|---|
| 纯CPU | `struct_sptrsv_sequential_forward`（测试文件内本地函数） 或 `swSparse_d_struct_sptrsv_sequential_forward` | 纯串行基线 |
| swSpTRSV | `sptrsv_hetero_test` 或 SpTRSV solver API | 非结构化通用求解 |
| SW-struct | 结构化 SpTRSV MPE-only 版本 | 结构化但不用 CPE |
| struct-SpTRSV | `swSparse_d_struct_sptrsv_forward` | 结构化 + CPE 异构加速 |

## 结构化 SpTRSV 关键源码路径

```
include/swSparse_blas.h                             — 公共 API 声明
include/internal/stsSpTRSV.h                        — CPE 端模板
source/heterogeneous/MPE/hm_struct_SpTRSV.cpp        — MPE 调度
source/heterogeneous/CPE/hc_struct_SpTRSV.cpp        — CPE kernel
source/heterogeneous/CPE/structSpTRSV/               — struct SpTRSV 子模块
source/sequential/s_structsptrsv.cpp                 — 串行参考实现
```


