# 第三方软件

在swSparse的矩阵分解功能中，使用的了第三方开源软件中的部分功能

## 内置的第三方软件功能

* HSL-MC64: mc64a (job = 5), 其中的Fortran代码被人工翻译成C++，使用从0开始的下标

* SuiteSparse: AMD

* SuperLU: cholnzcnt, pxgstrf_relax_snode

## 外部链接

* METIS: 使用默认编译选项时不支持METIS重排序。若要使用METIS，需要在CMakeLists.txt中设置`METIS_PATH`，并在运行cmake时打开选项`LINK_LIBMETIS`

