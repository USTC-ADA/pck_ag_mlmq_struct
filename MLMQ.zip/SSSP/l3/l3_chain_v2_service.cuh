#pragma once

#if (L3_CHAIN_V2 == true)
// Distinct, warp-batched path for tagged segment tokens.  Ordinary vertices
// still go through simple_process without carrying chain index/snapshot
// variables.  The original L2 read credit stays live until this function has
// materialized all distances, durably submitted endpoint/requeue tokens, and
// returned to its caller.
template <typename QUEUE_TYPE>
__device__ __noinline__ void l3_chain_v2_service_batch(
    NODE_TYPE *node_in, NODE_TYPE *node_out, int node_in_num,
    QUEUE_TYPE &mlmq, int bid, int wid, int lane,
    VALUE_TYPE *node_data, VALUE_TYPE *last_processed,
    int v_begin, int v_end, unsigned *debug_time)
{
    assert(node_in_num >= 0 && node_in_num <= node_size);
    const l3_chain_v2_device_view view = g_l3_chain_v2;
    const bool token = lane < node_in_num &&
        (node_in[lane].id & L3_CHAIN_V2_TOKEN_TAG) != 0;
    int segment = -1;
    int base = 0, length = 0;
    unsigned long long claimed_epoch = 0;
    bool first_endpoint = false, last_endpoint = false;
    int first_id = 0, first_value = 0, last_id = 0, last_value = 0;
    if (token)
    {
        segment = node_in[lane].id & ~L3_CHAIN_V2_TOKEN_TAG;
        assert(view.route && segment >= 0 && segment < view.segment_count);
        const bool claimed = l3_chain_v2_claim(
            view.states, segment, claimed_epoch);
        assert(claimed); // duplicate/stale token would orphan ownership
        base = view.bases[segment];
        length = view.nodes[base].length;
        assert(base >= 0 && length >= 4 &&
               length <= view.node_count - base);
        for (int offset = 0; offset < length; ++offset)
            view.snapshot[base + offset] =
                l3_chain_v2_take_pending(view.pending, base + offset);
        l3_chain_v2_closure(view.nodes, base, view.snapshot, view.closed);
        for (int offset = 0; offset < length; ++offset)
        {
            const int index = base + offset;
            const int value = view.closed[index];
            if (value == INT_MAX) continue;
            const int id = view.nodes[index].id;
            const int local = id - v_begin;
            assert(local >= 1 && local <= v_end - v_begin);
            const int before = atomicMin(node_data + local, value);
            if (value >= before) continue;
            if (offset == 0)
            {
                first_endpoint = true;
                first_id = id;
                first_value = value;
            }
            else if (offset == length - 1)
            {
                last_endpoint = true;
                last_id = id;
                last_value = value;
            }
            else if (last_processed)
                atomicMin(last_processed + local, value);
        }
        // The token is now consumed by this dedicated path; the ordinary
        // worker sees an invalid ID and must not interpret it as a vertex.
        node_in[lane].id = 0;
    }
    __syncwarp();

    const unsigned first_mask = __ballot_sync(FULL_MASK, first_endpoint);
    const unsigned last_mask = __ballot_sync(FULL_MASK, last_endpoint);
    const int first_count = __popc(first_mask);
    const int output_count = first_count + __popc(last_mask);
    if (first_endpoint)
        node_out[__popc(first_mask & ((1u << lane) - 1u))] =
            NODE_TYPE(first_id, first_value);
    if (last_endpoint)
        node_out[first_count + __popc(last_mask & ((1u << lane) - 1u))] =
            NODE_TYPE(last_id, last_value);
    __syncwarp();
    if (output_count)
    {
        int write_num = output_count;
        const write_status status = mlmq.write_through(
            node_out, write_num, bid, wid, lane, debug_time);
        assert(status == WRITE_SUCCESS);
        __threadfence();
        __syncwarp();
    }

    bool requeue = false;
    int requeue_value = 0;
    if (token)
    {
        l3_chain_v2_complete(view.completed, view.closed, base, length,
                             view.states, segment, claimed_epoch);
        const l3_chain_v2_commit_result result = l3_chain_v2_commit(
            view.states, segment, claimed_epoch);
        assert(result != L3_CHAIN_V2_COMMIT_ERROR);
        requeue = result == L3_CHAIN_V2_REQUEUE;
#if (L3_CHAIN_V2_DEDICATED == true)
        if (requeue)
            l3_chain_v2_publish_ready(view, segment);
        else
            l3_chain_v2_finish_owner(view);
#else
        if (requeue)
        {
            int minimum = INT_MAX;
            for (int offset = 0; offset < length; ++offset)
            {
                const int value = view.pending[base + offset];
                if (value < minimum) minimum = value;
            }
            // An offer can be included in the claimed snapshot but increment
            // its version just before commit.  The harmless empty requeue is
            // prioritized immediately instead of carrying an INF queue key.
            requeue_value = minimum == INT_MAX ? 0 : minimum;
        }
#endif
    }
#if (L3_CHAIN_V2_DEDICATED == false)
    const unsigned requeue_mask = __ballot_sync(FULL_MASK, requeue);
    const int requeue_count = __popc(requeue_mask);
    if (requeue)
        node_out[__popc(requeue_mask & ((1u << lane) - 1u))] =
            NODE_TYPE(L3_CHAIN_V2_TOKEN_TAG | segment, requeue_value);
    __syncwarp();
    if (requeue_count)
    {
        int write_num = requeue_count;
        const write_status status = mlmq.write_through(
            node_out, write_num, bid, wid, lane, debug_time);
        assert(status == WRITE_SUCCESS);
        __threadfence();
        __syncwarp();
    }
#endif
}

#if (L3_CHAIN_V2_DEDICATED == true)
// The ordinary worker never sees a chain token in this mode.  A fixed set of
// service warps drains a per-owner ready bitmap; the segment state remains the
// unique responsibility, and outstanding stays nonzero until all endpoint
// outputs are durable and commit reaches IDLE.
template <typename QUEUE_TYPE>
__global__ void l3_chain_v2_service_kernel(
    QUEUE_TYPE mlmq, int *global_exit, VALUE_TYPE *node_data,
    VALUE_TYPE *last_processed, int v_begin, int v_end)
{
    static_assert(node_size == WARP_SIZE, "dedicated chain buffer geometry");
    constexpr int service_warps = 4;
    __shared__ NODE_TYPE input[service_warps * node_size];
    __shared__ NODE_TYPE output[service_warps * node_size * 2];
    const int tid = threadIdx.x;
    const int lane = tid & (WARP_SIZE - 1);
    const int wid = tid / WARP_SIZE;
    const int global_tid = blockIdx.x * blockDim.x + tid;
    const int total_threads = gridDim.x * blockDim.x;
    const l3_chain_v2_device_view view = g_l3_chain_v2;
    assert(blockDim.x == service_warps * WARP_SIZE &&
           view.ready_words && view.outstanding);
    int word_cursor = global_tid;
    unsigned claimed = 0;
    int claimed_word = -1;
    unsigned debug_time[3] = {0, 0, 0};
    while (true)
    {
        int stop = 0;
        if (!lane)
            stop = l3_atomic_load_acquire<cuda::thread_scope_device>(global_exit);
        stop = __shfl_sync(FULL_MASK, stop, 0);
        if (stop)
        {
            if (!lane) assert(!l3_chain_v2_busy());
            break;
        }
        if (!claimed && word_cursor < view.ready_word_count)
        {
            cuda::atomic_ref<unsigned, cuda::thread_scope_device> word(
                view.ready_words[word_cursor]);
            claimed = word.exchange(0u, cuda::memory_order_acquire);
            claimed_word = word_cursor;
            word_cursor += total_threads;
            if (word_cursor >= view.ready_word_count)
                word_cursor = global_tid;
        }
        int segment = -1;
        if (claimed)
        {
            const int bit = __ffs(claimed) - 1;
            claimed &= claimed - 1;
            segment = claimed_word * 32 + bit;
            assert(segment >= 0 && segment < view.segment_count);
        }
        input[wid * node_size + lane] = segment < 0 ?
            NODE_TYPE(0, 0) : NODE_TYPE(L3_CHAIN_V2_TOKEN_TAG | segment, 0);
        __syncwarp();
        if (__any_sync(FULL_MASK, segment >= 0))
            l3_chain_v2_service_batch(
                input + wid * node_size, output + wid * node_size * 2,
                node_size, mlmq, blockIdx.x, wid, lane, node_data,
                last_processed, v_begin, v_end, debug_time);
        else
            __nanosleep(128);
    }
}

template <typename QUEUE_TYPE>
void l3_chain_v2_prepare_service(int gpu)
{
    if (!l3_chain_v2_host[gpu].segment_count) return;
    // Load the entry before any persistent kernel starts. Lazy loading at
    // service launch can synchronize the context while the manager is
    // already waiting for workers that the host has not launched yet.
    cudaFuncAttributes attributes = {};
    l3_chain_v2_cuda_require(cudaFuncGetAttributes(
        &attributes, l3_chain_v2_service_kernel<QUEUE_TYPE>),
        "service preload");
}

template <typename QUEUE_TYPE>
void l3_chain_v2_launch_service(
    int gpu, QUEUE_TYPE mlmq, int *global_exit, VALUE_TYPE *node_data,
    VALUE_TYPE *last_processed, int v_begin, int v_end)
{
    const l3_chain_v2_device_view &view = l3_chain_v2_host[gpu];
    if (!view.segment_count) return;
    l3_chain_v2_service_kernel<<<1, 128, 0, l3_chain_v2_stream[gpu]>>>(
        mlmq, global_exit, node_data, last_processed, v_begin, v_end);
    l3_chain_v2_cuda_require(cudaGetLastError(), "service launch");
}
#endif
#endif
