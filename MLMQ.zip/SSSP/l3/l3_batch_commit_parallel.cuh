#pragma once
#include "l3_batch_peer_commit.cuh"

// One exclusive owner WARP. State headers remain lane-0-owned; lanes own
// disjoint required[] entries during APPLY. No other warp may use this table
// or mutate this state. Existing scalar adapters remain the reference path.
namespace l3_batch_commit_parallel {
namespace bc = l3_batch_commit;
namespace bw = l3_batch_commit_warp;
namespace pc = l3_batch_peer_commit;
namespace relay = l3_batch_relay;
constexpr unsigned mask = 0xffffffffu;
constexpr int table_size = 1024;
struct workspace { int indices[table_size]; }; // 0 empty, otherwise journal index + 1
__host__ __device__ inline unsigned bucket(int vertex) {
    return (unsigned(vertex) * 2654435761u) & (table_size - 1);
}

template<int N>
__device__ bool accept_journal(bc::state<N> &s, std::uint64_t generation,
    const bc::record *journal, int count, workspace &w, int lane) {
    static_assert(N < table_size, "bounded hash requires spare capacity");
    if (s.stage != bc::phase::borrowed || generation != s.generation ||
        !journal || count <= 0 || count > N) return false;
    bool valid = true;
    for (int i = lane; i < count; i += 32) {
        const auto r = journal[i];
        valid &= r.vertex >= 0 && r.vertex < s.vertices && r.distance >= 0 && r.distance < INT_MAX &&
                 r.certificate >= r.distance &&
                 ((r.vertex >= s.begin && r.vertex < s.end) || r.certificate == INT_MAX);
    }
    if (!__all_sync(mask, valid)) return false;
    for (int i = lane; i < table_size; i += 32) w.indices[i] = 0;
    __syncwarp(mask);
    for (int i = lane; i < count; i += 32) {
        unsigned h = bucket(journal[i].vertex);
        bool inserted = false;
        for (int probes = 0; probes < table_size; ++probes, h = (h + 1) & (table_size - 1)) {
            const int old = atomicCAS(w.indices + h, 0, i + 1);
            if (!old) { inserted = true; break; }
            if (journal[old - 1].vertex == journal[i].vertex) break;
        }
        valid &= inserted;
    }
    __syncwarp(mask); // immutable table from here, including all inserting lanes
    if (!__all_sync(mask, valid)) return false;
    // Validate every root BEFORE any authoritative distance update. Duplicate
    // roots are permitted; missing roots or a worse returned distance reject.
    for (int i = lane; i < s.seed_count; i += 32) {
        const auto root = s.roots[i];
        unsigned h = bucket(root.vertex);
        bool retained = false;
        for (int probes = 0; probes < table_size; ++probes, h = (h + 1) & (table_size - 1)) {
            const int item = w.indices[h];
            if (!item) break;
            const auto r = journal[item - 1];
            if (r.vertex == root.vertex) { retained = r.distance <= root.distance; break; }
        }
        valid &= retained;
    }
    if (!__all_sync(mask, valid)) return false;
    for (int j = lane; j < count; j += 32) {
        int required = INT_MAX;
        for (int i = 0; i < s.seed_count; ++i)
            if (s.roots[i].vertex == journal[j].vertex) required = min(required, s.roots[i].distance);
        s.required[j] = required;
    }
    __syncwarp(mask);
    if (!lane) {
        s.count = count; s.cursor = 0; s.journal = journal;
        s.wins = s.local_published = s.remote_published = 0;
        s.stage = bc::phase::apply;
    }
    __syncwarp(mask);
    return true;
}

// Same system-scope packet lifetime as pc::accept_return. Only validation and
// APPLY differ; helpers, remote receipts, local publication and recycle stay
// unchanged. A bad journal falls back before APPLY and keeps donor credit.
template<int N>
__device__ bool accept_return(bc::state<N> &s, pc::packet *p, bc::record *journal,
    workspace &w, int lane) {
    if (s.stage != bc::phase::borrowed) return false;
    const auto token = relay::encode(s.generation, relay::returned);
    int claimed = 0;
    if (!lane) claimed = relay::move(&p->channel, token, relay::committing);
    if (!__shfl_sync(mask, claimed, 0)) return false;
    const auto observed = relay::load(&p->channel);
    assert(__all_sync(mask, observed == relay::encode(s.generation, relay::committing)));
    bool intact = p->channel.seeds == s.seed_count;
    for (int i = lane; i < s.seed_count; i += 32) {
        const auto item = p->channel.input[i];
        intact &= item.vertex == s.roots[i].vertex && item.distance == s.roots[i].distance;
    }
    assert(__all_sync(mask, intact));
    const int count = p->channel.results;
    const bool valid = p->channel.result_status == relay::ok && count > 0 &&
                       count <= N && count <= l3_batch_compact::capacity;
    if (valid) for (int i = lane; i < count; i += 32)
        journal[i] = {p->channel.output[i].vertex, p->channel.output[i].distance, p->certificates[i]};
    __syncwarp(mask);
    const bool accepted = valid && accept_journal(s, s.generation, journal, count, w, lane);
    if (!lane && !accepted) { const bool restored = bc::start_fallback(s, s.generation); assert(restored); }
    __syncwarp(mask);
    return true;
}

template<int N>
__device__ bc::result prepare(bc::state<N> &s, std::uint64_t generation,
    bw::intent &p, int *distance, int lane) {
    if (s.stage != bc::phase::apply || s.generation != generation || p.status != bw::publication::empty)
        return bw::prepare(s, generation, p, distance, lane);
    const int remaining = s.count - s.cursor;
    const int index = s.cursor + lane;
    bool won = false;
    if (index < s.count) {
        const auto r = s.journal[index];
        if (r.vertex >= s.begin && r.vertex < s.end) {
            const int old = atomicMin(distance + r.vertex - s.begin, r.distance);
            won = r.distance < old;
            // A later competing improvement cannot erase this loan's winner.
            if (won) s.required[index] = min(s.required[index], r.distance);
        }
    }
    const unsigned winners = __ballot_sync(mask, won);
    __syncwarp(mask);
    if (!lane) {
        s.wins += __popc(winners);
        // Match the reference's at most 32 scalar steps, including its extra
        // phase-transition step when fewer than 32 records remain.
        if (remaining < 32) { s.cursor = 0; s.stage = bc::phase::remote; }
        else s.cursor += 32;
    }
    __syncwarp(mask);
    return bc::result::progress;
}
} // namespace l3_batch_commit_parallel
