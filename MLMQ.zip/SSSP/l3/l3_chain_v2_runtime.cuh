#pragma once

#if (L3_CHAIN_V2 == true)
#include "l3_chain_v2_index.h"
#include "l3_chain_v2_math.h"
#include "l3_chain_v2_state.cuh"
#include <cstdio>
#include <cstdlib>
#include <vector>

// One owner device per view; no pointer in this view is peer-accessed.
struct l3_chain_v2_device_view
{
    uint64_t *route;
    int *bases;
    l3_chain_partition_node *nodes;
    int *pending, *completed, *snapshot, *closed;
    l3_chain_v2_segment_state *states;
    int route_count, segment_count, node_count, min_nodes;
#if (L3_CHAIN_V2_DEDICATED == true)
    unsigned *ready_words;
    int *outstanding;
    int ready_word_count;
#endif
};

__device__ l3_chain_v2_device_view g_l3_chain_v2;
static l3_chain_v2_device_view l3_chain_v2_host[MAX_GPU] = {};
#if (L3_CHAIN_V2_DEDICATED == true)
static cudaStream_t l3_chain_v2_stream[MAX_GPU] = {};

__device__ __forceinline__ void l3_chain_v2_publish_ready(
    const l3_chain_v2_device_view &view, int segment)
{
    assert(view.ready_words && segment >= 0 && segment < view.segment_count);
    cuda::atomic_ref<unsigned, cuda::thread_scope_device> word(
        view.ready_words[segment >> 5]);
    word.fetch_or(1u << (segment & 31), cuda::memory_order_release);
}

__device__ __forceinline__ void l3_chain_v2_finish_owner(
    const l3_chain_v2_device_view &view)
{
    cuda::atomic_ref<int, cuda::thread_scope_device> count(*view.outstanding);
    const int prior = count.fetch_sub(1, cuda::memory_order_acq_rel);
    assert(prior > 0);
}

__device__ __forceinline__ bool l3_chain_v2_busy()
{
    const l3_chain_v2_device_view view = g_l3_chain_v2;
    if (!view.outstanding) return false;
    cuda::atomic_ref<int, cuda::thread_scope_device> count(*view.outstanding);
    return count.load(cuda::memory_order_acquire) != 0;
}
#endif

// Called only after an authoritative local atomicMin won.  Under the strict
// index, every interior has exactly its two local reciprocal in-edges, so a
// remote RX cannot be its entry point.  Local CSR relaxations (and an
// interior source's first ordinary expansion) are the actual chain frontier.
__device__ __noinline__ bool l3_chain_v2_route_local(
    int &id, int value, int v_begin)
{
    const l3_chain_v2_device_view view = g_l3_chain_v2;
    const int local = id - v_begin;
    if (!view.route || local <= 0 || local >= view.route_count)
        return true;
    const uint64_t route = view.route[local];
    if (!route) return true;
    const int segment = int(route >> 32) - 1;
    assert(segment >= 0 && segment < view.segment_count);
    const int base = view.bases[segment];
    if (view.nodes[base].length < view.min_nodes) return true;
    const int index = base + int(uint32_t(route));
    assert(index >= 0 && index < view.node_count &&
           view.nodes[index].id == id);
    const l3_chain_v2_offer_result offer = l3_chain_v2_offer(
        view.pending, view.completed, view.states, segment, index, value);
    assert(offer != L3_CHAIN_V2_ERROR);
    if (offer == L3_CHAIN_V2_NEW_TOKEN)
    {
#if (L3_CHAIN_V2_DEDICATED == true)
        cuda::atomic_ref<int, cuda::thread_scope_device> count(
            *view.outstanding);
        const int prior = count.fetch_add(1, cuda::memory_order_acq_rel);
        // Commit publishes IDLE before the old service drops its credit.
        // A new lifetime may therefore overlap that final decrement; this
        // counter measures responsibilities, not non-IDLE segment states.
        assert(prior >= 0 && prior < INT_MAX);
        l3_chain_v2_publish_ready(view, segment);
        return false;
#else
        id = L3_CHAIN_V2_TOKEN_TAG | segment;
        return true;
#endif
    }
    return false;
}

static inline void l3_chain_v2_cuda_require(
    cudaError_t status, const char *operation)
{
    if (status == cudaSuccess) return;
    std::fprintf(stderr, "L3_CHAIN_V2_CUDA_ERROR operation=%s error=%s\n",
                 operation, cudaGetErrorString(status));
    std::exit(2);
}

void l3_chain_v2_release(int gpu)
{
    l3_chain_v2_cuda_require(cudaSetDevice(gpu), "release device");
    l3_chain_v2_device_view &view = l3_chain_v2_host[gpu];
    if (view.route) l3_chain_v2_cuda_require(cudaFree(view.route), "route free");
    if (view.bases) l3_chain_v2_cuda_require(cudaFree(view.bases), "bases free");
    if (view.nodes) l3_chain_v2_cuda_require(cudaFree(view.nodes), "nodes free");
    if (view.pending) l3_chain_v2_cuda_require(cudaFree(view.pending), "pending free");
    if (view.completed) l3_chain_v2_cuda_require(cudaFree(view.completed), "completed free");
    if (view.snapshot) l3_chain_v2_cuda_require(cudaFree(view.snapshot), "snapshot free");
    if (view.closed) l3_chain_v2_cuda_require(cudaFree(view.closed), "closed free");
    if (view.states) l3_chain_v2_cuda_require(cudaFree(view.states), "states free");
#if (L3_CHAIN_V2_DEDICATED == true)
    if (view.ready_words) l3_chain_v2_cuda_require(
        cudaFree(view.ready_words), "ready words free");
    if (view.outstanding) l3_chain_v2_cuda_require(
        cudaFree(view.outstanding), "outstanding free");
    if (l3_chain_v2_stream[gpu]) l3_chain_v2_cuda_require(
        cudaStreamDestroy(l3_chain_v2_stream[gpu]), "service stream destroy");
    l3_chain_v2_stream[gpu] = nullptr;
#endif
    view = {};
    l3_chain_v2_cuda_require(cudaMemcpyToSymbol(
        g_l3_chain_v2, &view, sizeof(view)), "view clear");
}

void l3_chain_v2_install(
    int gpu, const l3_chain_partition_index &strict,
    const l3_chain_v2_index &dense)
{
    l3_chain_v2_release(gpu);
    if (dense.bases.empty())
    {
        std::printf("L3_CHAIN_V2_SETUP gpu=%d segments=0 nodes=0 bytes=0\n", gpu);
        return;
    }
    if (dense.route.size() >= size_t(L3_CHAIN_V2_TOKEN_TAG) ||
        dense.bases.size() >= size_t(L3_CHAIN_V2_TOKEN_TAG) ||
        strict.nodes.size() >= size_t(INT_MAX))
    {
        std::fprintf(stderr, "L3_CHAIN_V2_ERROR index range\n");
        std::exit(2);
    }
    l3_chain_v2_device_view &view = l3_chain_v2_host[gpu];
    view.route_count = static_cast<int>(dense.route.size());
    view.segment_count = static_cast<int>(dense.bases.size());
    view.node_count = static_cast<int>(strict.nodes.size());
#if (L3_CHAIN_V2_DEDICATED == true)
    view.ready_word_count = (view.segment_count + 31) / 32;
#endif
    view.min_nodes = 4;
    if (const char *setting = std::getenv("L3_CHAIN_V2_MIN_NODES"))
    {
        char *end = nullptr;
        const long requested = std::strtol(setting, &end, 10);
        if (end == setting || *end != '\0' || requested < 4 ||
            requested > INT_MAX)
        {
            std::fprintf(stderr, "L3_CHAIN_V2_ERROR invalid minimum nodes\n");
            std::exit(2);
        }
        view.min_nodes = static_cast<int>(requested);
    }
    const size_t route_bytes = dense.route.size() * sizeof(uint64_t);
    const size_t base_bytes = dense.bases.size() * sizeof(int);
    const size_t node_bytes = strict.nodes.size() * sizeof(l3_chain_partition_node);
    const size_t scratch_bytes = strict.nodes.size() * sizeof(int);
    const size_t state_bytes = dense.bases.size() * sizeof(l3_chain_v2_segment_state);
    l3_chain_v2_cuda_require(cudaMalloc(&view.route, route_bytes), "route alloc");
    l3_chain_v2_cuda_require(cudaMalloc(&view.bases, base_bytes), "bases alloc");
    l3_chain_v2_cuda_require(cudaMalloc(&view.nodes, node_bytes), "nodes alloc");
    l3_chain_v2_cuda_require(cudaMalloc(&view.pending, scratch_bytes), "pending alloc");
    l3_chain_v2_cuda_require(cudaMalloc(&view.completed, scratch_bytes), "completed alloc");
    l3_chain_v2_cuda_require(cudaMalloc(&view.snapshot, scratch_bytes), "snapshot alloc");
    l3_chain_v2_cuda_require(cudaMalloc(&view.closed, scratch_bytes), "closed alloc");
    l3_chain_v2_cuda_require(cudaMalloc(&view.states, state_bytes), "states alloc");
#if (L3_CHAIN_V2_DEDICATED == true)
    l3_chain_v2_cuda_require(cudaMalloc(
        &view.ready_words, size_t(view.ready_word_count) * sizeof(unsigned)),
        "ready words alloc");
    l3_chain_v2_cuda_require(cudaMalloc(&view.outstanding, sizeof(int)),
                             "outstanding alloc");
    l3_chain_v2_cuda_require(cudaStreamCreateWithFlags(
        &l3_chain_v2_stream[gpu], cudaStreamNonBlocking),
        "service stream create");
#endif
    l3_chain_v2_cuda_require(cudaMemcpy(
        view.route, dense.route.data(), route_bytes, cudaMemcpyHostToDevice),
        "route upload");
    l3_chain_v2_cuda_require(cudaMemcpy(
        view.bases, dense.bases.data(), base_bytes, cudaMemcpyHostToDevice),
        "bases upload");
    l3_chain_v2_cuda_require(cudaMemcpy(
        view.nodes, strict.nodes.data(), node_bytes, cudaMemcpyHostToDevice),
        "nodes upload");
    l3_chain_v2_cuda_require(l3_fill_values(
        view.pending, strict.nodes.size(), INT_MAX, view.completed),
        "pending/completed initialize");
    l3_chain_v2_cuda_require(cudaMemset(view.states, 0, state_bytes),
                             "states initialize");
#if (L3_CHAIN_V2_DEDICATED == true)
    l3_chain_v2_cuda_require(cudaMemset(
        view.ready_words, 0, size_t(view.ready_word_count) * sizeof(unsigned)),
        "ready words initialize");
    l3_chain_v2_cuda_require(cudaMemset(view.outstanding, 0, sizeof(int)),
                             "outstanding initialize");
#endif
    l3_chain_v2_cuda_require(cudaMemcpyToSymbol(
        g_l3_chain_v2, &view, sizeof(view)), "view bind");
    const size_t bytes = route_bytes + base_bytes + node_bytes +
                         4 * scratch_bytes + state_bytes
#if (L3_CHAIN_V2_DEDICATED == true)
                         + size_t(view.ready_word_count) * sizeof(unsigned)
                         + sizeof(int)
#endif
                         ;
    std::printf("L3_CHAIN_V2_SETUP gpu=%d segments=%d nodes=%d bytes=%zu "
                "min_nodes=%d\n", gpu, view.segment_count,
                view.node_count, bytes, view.min_nodes);
}

void l3_chain_v2_reset(int gpu)
{
    l3_chain_v2_cuda_require(cudaSetDevice(gpu), "reset device");
    const l3_chain_v2_device_view &view = l3_chain_v2_host[gpu];
    if (!view.segment_count) return;
    l3_chain_v2_cuda_require(l3_fill_values(
        view.pending, size_t(view.node_count), INT_MAX, view.completed),
        "pending/completed reset");
    l3_chain_v2_cuda_require(cudaMemset(
        view.states, 0, size_t(view.segment_count) *
                        sizeof(l3_chain_v2_segment_state)), "states reset");
#if (L3_CHAIN_V2_DEDICATED == true)
    l3_chain_v2_cuda_require(cudaMemset(
        view.ready_words, 0, size_t(view.ready_word_count) * sizeof(unsigned)),
        "ready words reset");
    l3_chain_v2_cuda_require(cudaMemset(view.outstanding, 0, sizeof(int)),
                             "outstanding reset");
#endif
}

// Outside solve timing, after both persistent kernels have synchronized.
// A zero-responsibility end state is mandatory even when the distance oracle
// happens to pass; it detects an offered segment whose token was lost.
void l3_chain_v2_audit(int gpu)
{
    l3_chain_v2_cuda_require(cudaSetDevice(gpu), "audit device");
    const l3_chain_v2_device_view &view = l3_chain_v2_host[gpu];
    if (!view.segment_count) return;
    std::vector<l3_chain_v2_segment_state> states(view.segment_count);
    std::vector<int> pending(view.node_count);
#if (L3_CHAIN_V2_DEDICATED == true)
    std::vector<unsigned> ready(view.ready_word_count);
    int outstanding = -1;
#endif
    l3_chain_v2_cuda_require(cudaMemcpy(
        states.data(), view.states, states.size() * sizeof(states[0]),
        cudaMemcpyDeviceToHost), "states audit read");
    l3_chain_v2_cuda_require(cudaMemcpy(
        pending.data(), view.pending, pending.size() * sizeof(int),
        cudaMemcpyDeviceToHost), "pending audit read");
#if (L3_CHAIN_V2_DEDICATED == true)
    l3_chain_v2_cuda_require(cudaMemcpy(
        ready.data(), view.ready_words, ready.size() * sizeof(unsigned),
        cudaMemcpyDeviceToHost), "ready audit read");
    l3_chain_v2_cuda_require(cudaMemcpy(
        &outstanding, view.outstanding, sizeof(outstanding),
        cudaMemcpyDeviceToHost), "outstanding audit read");
#endif
    size_t queued = 0, active = 0, invalid = 0, epoch_lag = 0, pending_finite = 0;
    size_t serviced_segments = 0;
    unsigned long long completed_versions = 0;
    for (const auto &entry : states)
    {
        const unsigned long long state =
            entry.ownership & L3_CHAIN_V2_STATE_MASK;
        if (state == L3_CHAIN_V2_QUEUED) ++queued;
        else if (state == L3_CHAIN_V2_ACTIVE) ++active;
        else if (state != L3_CHAIN_V2_IDLE) ++invalid;
        epoch_lag += entry.completed_epoch !=
                     (entry.ownership & ~L3_CHAIN_V2_STATE_MASK);
        if (entry.completed_epoch != 0) ++serviced_segments;
        completed_versions += entry.completed_epoch / L3_CHAIN_V2_VERSION_STEP;
    }
    for (const int value : pending) pending_finite += value != INT_MAX;
#if (L3_CHAIN_V2_DEDICATED == true)
    size_t ready_bits = 0;
    for (const unsigned word : ready) ready_bits += __builtin_popcount(word);
    std::printf("L3_CHAIN_V2_DEDICATED_FINAL gpu=%d ready_bits=%zu outstanding=%d\n",
                gpu, ready_bits, outstanding);
#endif
    std::printf("L3_CHAIN_V2_FINAL gpu=%d segments=%d queued=%zu active=%zu "
                "invalid=%zu epoch_lag=%zu pending=%zu "
                "serviced_segments=%zu completed_versions=%llu\n",
                gpu, view.segment_count, queued, active, invalid,
                epoch_lag, pending_finite, serviced_segments,
                completed_versions);
    if (queued || active || invalid || epoch_lag || pending_finite
#if (L3_CHAIN_V2_DEDICATED == true)
        || ready_bits || outstanding
#endif
       )
    {
        std::fprintf(stderr, "L3_CHAIN_V2_ERROR incomplete responsibility\n");
        std::exit(2);
    }
}
#endif
