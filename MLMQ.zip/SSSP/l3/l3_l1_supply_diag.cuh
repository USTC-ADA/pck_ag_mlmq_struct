#pragma once
#if (L3_L1_SUPPLY_DIAG == true)
#if (L3_OWNER_PROBE_DIAG == true)
#include "l3_owner_probe.cuh"
// Exactly one preselected slot per manager bin; no cross-warp scratch reuse.
__device__ l3_owner_probe::scratch g_l3_owner_probe_scratch[L3_Q2_TAIL_SLOTS];
__device__ l3_owner_probe::sample g_l3_owner_probe[L3_Q2_TAIL_SLOTS];
#endif
// Observation only: never reserve, move, filter, or complete queue work.
// A manager-issued epoch avoids comparing clock64 values across different SMs.
// Each worker samples at most once per epoch, AFTER publishing its outputs.
// Missing workers are unobserved, not empty; bins may observe the same work.
constexpr int L3_L1_SUPPLY_WARPS = 4096;
struct l3_l1_supply_sample {
    unsigned long long edges;
    unsigned raw_plus_one, eligible, invalid, max_degree;
};
__device__ int g_l3_l1_supply_epoch;
__device__ int g_l3_l1_supply_seen[L3_L1_SUPPLY_WARPS];
__device__ l3_l1_supply_sample
    g_l3_l1_supply[L3_Q2_TAIL_SLOTS][L3_L1_SUPPLY_WARPS];

#if (L3_L1_CAPTURE_DIAG == true)
// Deterministic rotating warp selection, NOT a first-winner race. These are
// asynchronous observations, never a transfer/reservation of responsibility.
constexpr int L3_L1_CAPTURE_SLOTS = 8;
struct l3_l1_capture_item {
    int vertex, queued, authoritative, processed, degree, eligible;
};
struct l3_l1_capture_batch {
    int warp_plus_one, begin, end, raw, eligible, inflight;
    l3_l1_capture_item items[MAX_L1SLF_BATCH_SIZE / 2];
};
__device__ int g_l3_l1_capture_warps;
__device__ l3_l1_capture_batch
    g_l3_l1_capture[L3_Q2_TAIL_SLOTS][L3_L1_CAPTURE_SLOTS];
__host__ __device__ inline int l3_l1_capture_slot(int bin, int warp, int warps) {
    if (warps <= 0) return -1;
    for (int slot = 0; slot < L3_L1_CAPTURE_SLOTS; ++slot)
        if ((bin * 37 + slot * 211) % warps == warp) return slot;
    return -1;
}
#endif

// Other queue templates are compiled but rejected by the host entry point.
template <class Queue>
__device__ __forceinline__ void l3_l1_supply_observe(
    Queue &, int, int, int, const int *, const VALUE_TYPE *, int, int,
    const VALUE_TYPE * = nullptr, int = 0,
    const int * = nullptr, const VALUE_TYPE * = nullptr) {}

__device__ __forceinline__ void l3_l1_supply_observe(
    ml_queue<NODE_TYPE, l1_SLF_queue<NODE_TYPE>, l2_delta_queue<NODE_TYPE>> &,
    int wid, int global_wid, int lane, const int *rows,
    const VALUE_TYPE *last_processed, int v_begin, int v_end,
    const VALUE_TYPE *node_data = nullptr, int inflight = 0,
    const int *columns = nullptr, const VALUE_TYPE *weights = nullptr)
{
    int epoch = 0;
    if (!lane) {
        epoch = l3_atomic_load_acquire<cuda::thread_scope_device>(
            &g_l3_l1_supply_epoch);
        if (epoch && g_l3_l1_supply_seen[global_wid] == epoch) epoch = 0;
        if (epoch) g_l3_l1_supply_seen[global_wid] = epoch;
    }
    epoch = __shfl_sync(FULL_MASK, epoch, 0);
    if (!epoch) return;

    extern __shared__ int s[];
    auto &queue = reinterpret_cast<l1_SLF_queue<NODE_TYPE> *>(s)[wid];
    const int size = queue.data_size;
    // SLF spills all contents when its size exceeds half capacity.
    assert(size >= 0 && size <= MAX_L1SLF_BATCH_SIZE / 2);
    unsigned eligible = 0, invalid = 0, max_degree = 0;
    unsigned long long edges = 0;
#if (L3_L1_CAPTURE_DIAG == true)
    const int capture_slot = l3_l1_capture_slot(epoch - 1, global_wid, g_l3_l1_capture_warps);
    l3_l1_capture_batch *capture = capture_slot >= 0 ?
        &g_l3_l1_capture[epoch - 1][capture_slot] : nullptr;
#endif
    for (int i = lane; i < size; i += WARP_SIZE) {
        int position = queue.l + i;
        if (position >= MAX_L1SLF_BATCH_SIZE) position -= MAX_L1SLF_BATCH_SIZE;
        NODE_TYPE item = queue.data[position];
        VALUE_TYPE processed = INT_MAX;
        int degree = 0;
        bool admitted = false;
        if (item.id - 1 < v_begin || item.id - 1 >= v_end) {
            ++invalid;
        } else {
            processed = last_processed ? *reinterpret_cast<const volatile VALUE_TYPE *>(
                last_processed + item.id - v_begin) : INT_MAX;
            admitted = last_processed == nullptr || item.get_data() < processed;
            degree = rows[item.id - v_begin] - rows[item.id - 1 - v_begin];
        }
        if (admitted) {
            // Matches simple_process's admission predicate. This is only an
            // instantaneous eligibility observation: another warp can process
            // the same vertex, and duplicate entries are NOT unique work.
            ++eligible;
            edges += degree;
            max_degree = unsigned(degree) > max_degree ? unsigned(degree) : max_degree;
        }
#if (L3_L1_CAPTURE_DIAG == true)
        if (capture) {
            // Deliberately separate from the eligibility read: other workers
            // can improve these values concurrently, no coherent graph snapshot.
            int authoritative = INT_MAX;
            if (node_data && item.id - 1 >= v_begin && item.id - 1 < v_end)
                authoritative = *reinterpret_cast<const volatile VALUE_TYPE *>(
                    node_data + item.id - v_begin);
            capture->items[i] = {item.id - 1, item.get_data(), authoritative,
                                 processed, degree, int(admitted)};
        }
#endif
    }
    for (int offset = 16; offset; offset >>= 1) {
        eligible += __shfl_down_sync(FULL_MASK, eligible, offset);
        invalid += __shfl_down_sync(FULL_MASK, invalid, offset);
        edges += __shfl_down_sync(FULL_MASK, edges, offset);
        const unsigned other = __shfl_down_sync(FULL_MASK, max_degree, offset);
        max_degree = other > max_degree ? other : max_degree;
    }
    __syncwarp();
    if (!lane && epoch == l3_atomic_load_acquire<cuda::thread_scope_device>(&g_l3_l1_supply_epoch)) {
        g_l3_l1_supply[epoch - 1][global_wid] = {
            edges, unsigned(size + 1), eligible, invalid, max_degree};
#if (L3_L1_CAPTURE_DIAG == true)
        if (capture) {
            capture->begin = v_begin;
            capture->end = v_end;
            capture->raw = size;
            capture->eligible = eligible;
            capture->inflight = inflight; // lane0's credit count, not raw size
            capture->warp_plus_one = global_wid + 1;
        }
#endif
    }
    __syncwarp();
#if (L3_OWNER_PROBE_DIAG == true)
    if (capture_slot == 0 && capture->warp_plus_one == global_wid + 1 && capture->eligible > 0 &&
        node_data && last_processed && columns && weights) {
        // The original L1 and its in-flight responsibility stay untouched.
        // This pauses ONLY the sampling donor warp, perturbing the schedule.
        auto *storage = &g_l3_owner_probe_scratch[epoch - 1];
        const bool selected = lane < capture->raw && capture->items[lane].eligible;
        const unsigned mask = __ballot_sync(FULL_MASK, selected);
        if (selected) {
            const int position = __popc(mask & (lane ? (1u << lane) - 1u : 0u));
            storage->channel.input[position] = {capture->items[lane].vertex, capture->items[lane].authoritative};
        }
        if (!lane) storage->channel.seeds = __popc(mask);
        __syncwarp();
        l3_owner_probe::observe(storage, &g_l3_owner_probe[epoch - 1],
            {rows, columns, weights, v_begin, v_end - v_begin}, node_data, last_processed, lane);
        if (!lane) g_l3_owner_probe[epoch - 1].epoch_end =
            l3_atomic_load_acquire<cuda::thread_scope_device>(&g_l3_l1_supply_epoch);
    }
#endif
}
#endif
