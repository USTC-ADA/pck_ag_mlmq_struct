#pragma once

// Exact batched closure for a strict bidirectional chain.  This is a pure
// primitive: its caller owns the pending snapshot, queue publication, and
// completed-propagation certificate.  No ordinary distance value is treated
// as a completion certificate here.
#include "l3_chain_partition.h"
#include <climits>

#if defined(__CUDACC__)
#define L3_CHAIN_V2_HD __host__ __device__ __forceinline__
#else
#define L3_CHAIN_V2_HD inline
#endif

L3_CHAIN_V2_HD int l3_chain_v2_saturate(long long distance)
{
    return distance >= INT_MAX ? INT_MAX : static_cast<int>(distance);
}

// One caller processes one segment.  `pending` and `out` use the index.nodes
// offsets.  INT_MAX means no candidate.  Node prefixes and nonnegative
// candidate distances follow l3_chain_partition_index::build's contract.
// The caller may run many independent short segments in parallel, one lane
// per segment; long-segment cooperative processing is a later specialization.
L3_CHAIN_V2_HD void l3_chain_v2_closure(
    const l3_chain_partition_node *nodes, int base,
    const int *pending, int *out)
{
    const int length = nodes[base].length;
    long long best = LLONG_MAX;
    for (int offset = 0; offset < length; ++offset)
    {
        const int index = base + offset;
        const int candidate = pending[index];
        if (candidate != INT_MAX)
        {
            const long long shifted =
                static_cast<long long>(candidate) - nodes[index].forward;
            if (shifted < best) best = shifted;
        }
        out[index] = best == LLONG_MAX ? INT_MAX :
            l3_chain_v2_saturate(best + nodes[index].forward);
    }

    best = LLONG_MAX;
    for (int offset = length - 1; offset >= 0; --offset)
    {
        const int index = base + offset;
        const int candidate = pending[index];
        if (candidate != INT_MAX)
        {
            const long long shifted =
                static_cast<long long>(candidate) + nodes[index].reverse;
            if (shifted < best) best = shifted;
        }
        if (best != LLONG_MAX)
        {
            const int reverse_distance =
                l3_chain_v2_saturate(best - nodes[index].reverse);
            if (reverse_distance < out[index]) out[index] = reverse_distance;
        }
    }
}

#undef L3_CHAIN_V2_HD
