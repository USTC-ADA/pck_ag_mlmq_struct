#pragma once
#include "l3_batch_bound.cuh"
#include "l3_batch_commit.h"

namespace l3_batch_return_bound {
// Caller owns the immutable owner-side journal until retirement/recycle.
// finished means all sticky APPLY wins, uncovered roots and remote outputs
// are durable. Never publish a helper-private or merely RETURNED payload.
template<int N>
__device__ __forceinline__ l3_batch_bound::sampled publish(int *mirror,
    const l3_batch_commit::state<N> &state,int mode,int lane) {
    l3_batch_bound::sampled observed{};
    if(!mode || state.stage!=l3_batch_commit::phase::finished || !state.journal) return observed;
    assert(mode>=1 && mode<=3 && mirror && state.count>=0 && state.count<=N);
    // All publisher lanes order their prior durable output writes before
    // making a bound visible to a different GPU. Reads may still see stale INF.
    __threadfence_system();
    for(int i=lane;i<state.count;i+=32) {
        const auto r=state.journal[i];++observed.reads;
        if(r.vertex<state.begin || r.vertex>=state.end)continue;
        assert(r.distance>=0 && r.distance<INT_MAX);
        l3_atomic_min_system(mirror+r.vertex-state.begin,r.distance);
        ++observed.finite;
    }
    return observed;
}
}
