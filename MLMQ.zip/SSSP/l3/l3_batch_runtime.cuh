#pragma once
#if (L3_BATCH_RUNTIME == true)
#include "l3_batch_l1_donor.cuh"
#include "l3_batch_peer_commit.cuh"
#include "l3_batch_peer_packed.cuh"
#include "l3_batch_remote_commit.cuh"
#include "l3_batch_commit_parallel.cuh"
#include <vector>
#include <chrono>
#include "l3_batch_completed_filter.cuh"
#include "l3_batch_return_bound.cuh"
namespace l3_batch_runtime {
namespace bc=l3_batch_commit;
namespace bw=l3_batch_commit_warp;
namespace pc=l3_batch_peer_commit;
namespace ld=l3_batch_l1_donor;
namespace rc=l3_batch_remote_commit;
namespace bp=l3_batch_commit_parallel;
namespace relay=l3_batch_relay;
constexpr int max_slots=128;
struct loan {
    bc::state<> state;
    bc::donor_ledger donor;
    bw::intent intent;
    ld::snapshot snapshot;
    rc::sender sender;
    rc::ticket ticket;
    bc::record journal[768];
    bp::workspace validation;
};
struct metrics {
    unsigned long long loans,seeds,records,local,remote,certificates,helpers,receipts;
    unsigned long long helper_by_warp[16];
#if (L3_BATCH_BOUND_NEIGHBORS == true)
    unsigned long long neighbor_reads,neighbor_finite;
#endif
#if (L3_BATCH_BOUND_RETURNED == true)
    unsigned long long returned_loans,returned_records,returned_published;
#endif
};
struct view {
    int slots,budget,min_seeds,force,begin,end,vertices,admit,probe_calls,services,service_poll;
    loan *loans;
    pc::packet *outgoing,*incoming;
    rc::channel *rx,*tx;
    rc::receiver *receivers;
    unsigned *ready,*peer_ready;
    int *active,*peer_active,*quiet,*peer_quiet,*completed;
    relay::graph_view peer_graph;
    metrics *stats;
    int *bound_mirror;
    l3_batch_bound::view peer_bound;
    l3_batch_bound::counters *bound_counts;
    int bound_mode,bound_steps;
#if (L3_BATCH_BOUND_PUBLISH_DIAG == true)
    l3_batch_bound::publisher_counters *publisher_counts;
#endif
#if (L3_BATCH_BOUND_NEIGHBORS == true)
    const int *owner_rows,*owner_columns;
    int neighbor_edge_limit;
#endif
#if (L3_BATCH_BOUND_HELPER_LOCAL == true)
    int *bound_storage; // physically local; holds the opposite owner's labels
#endif
#if (L3_BATCH_SEARCH_DIAG == true)
    l3_batch_search_diag::counters *search_counts;
#endif
};
__device__ __constant__ view device;
static view host[MAX_GPU]={};
static cudaStream_t helper_stream[MAX_GPU]={},rx_stream[MAX_GPU]={};
static std::vector<void*> allocations[MAX_GPU];
inline int helper_blocks() { return bench_env_int("MLMQ_BATCH_HELPER_BLOCKS",1,1,8); }

#if (L3_LIVE_SNAPSHOT == true)
// Read-only asynchronous observations; fields may be sampled at different
// instants and are diagnostic evidence, never a termination predicate.
struct observation {
    int active,peer_active,quiet;
    unsigned ready[max_slots/32];
    metrics stats;
    loan loans[max_slots];
    pc::packet packets[max_slots];
    rc::channel rx[max_slots],tx[max_slots];
    rc::receiver receivers[max_slots];
};
static observation *observations[MAX_GPU]={};
inline bool observe_enqueue(int gpu,cudaStream_t stream) {
    const auto v=host[gpu];if(!v.slots)return true;
    auto &o=*observations[gpu];
#define L3_BATCH_OBSERVE(dst,src,count) \
    if(cudaMemcpyAsync(dst,src,sizeof(*(dst))*(count),cudaMemcpyDeviceToHost,stream)!=cudaSuccess)return false
    L3_BATCH_OBSERVE(&o.active,v.active,1);L3_BATCH_OBSERVE(&o.peer_active,v.peer_active,1);
    L3_BATCH_OBSERVE(&o.quiet,v.quiet,1);L3_BATCH_OBSERVE(o.ready,v.ready,(v.slots+31)/32);
    L3_BATCH_OBSERVE(&o.stats,v.stats,1);L3_BATCH_OBSERVE(o.loans,v.loans,v.slots);
    L3_BATCH_OBSERVE(o.packets,v.outgoing,v.slots);L3_BATCH_OBSERVE(o.rx,v.rx,v.slots);
    L3_BATCH_OBSERVE(o.tx,v.tx,v.slots);L3_BATCH_OBSERVE(o.receivers,v.receivers,v.slots);
#undef L3_BATCH_OBSERVE
    return true;
}
inline void observe_emit(int gpu) {
    const auto v=host[gpu];if(!v.slots)return;
    const auto &o=*observations[gpu];const auto &m=o.stats;
    printf("L3_BATCH_LIVE gpu=%d active=%d peer_active=%d quiet=%d loans=%llu records=%llu helpers=%llu receipts=%llu ready=%x,%x,%x,%x\n",
        gpu,o.active,o.peer_active,o.quiet,m.loans,m.records,m.helpers,m.receipts,o.ready[0],o.ready[1],o.ready[2],o.ready[3]);
    for(int i=0;i<v.slots;++i) {
        const auto &l=o.loans[i];const auto &r=o.receivers[i];const auto &tx=o.tx[i];
        if(l.state.stage!=bc::phase::free || l.donor.outstanding || r.phase!=rc::rx_phase::empty)
            printf("L3_BATCH_SLOT gpu=%d slot=%d gen=%llu phase=%d count=%d cursor=%d credit=%d outstanding=%u intent=%u remote=%d packet=%llu ticket=%d epoch=%d txstate=%d,%d txack=%d,%d rxphase=%d rxepoch=%d\n",
                gpu,i,(unsigned long long)l.state.generation,int(l.state.stage),l.state.count,l.state.cursor,
                l.donor.ancestor_credits,l.donor.outstanding,unsigned(l.intent.status),int(l.intent.remote),
                o.packets[i].channel.control,int(l.ticket.live),l.ticket.identity.epoch,
                tx.state[0],tx.state[1],tx.ack[0],tx.ack[1],int(r.phase),r.last_epoch);
    }
    fflush(stdout);
}
#endif

__device__ inline int sys_read(int *p) {
    return cuda::atomic_ref<int,cuda::thread_scope_system>(*p).load(cuda::memory_order_acquire);
}
__device__ inline void active_add(int *p,int n) {
    const int prior=cuda::atomic_ref<int,cuda::thread_scope_system>(*p).fetch_add(n,cuda::memory_order_acq_rel);
    assert(prior+n>=0);
}
// Completed helper evidence has its own atomic array. Ordinary workers keep
// their original pre-expansion last_processed stores and never write here.
__device__ inline void publish_completed(int local,int distance) {
    auto a=cuda::atomic_ref<int,cuda::thread_scope_device>(device.completed[local]);
    int old=a.load(cuda::memory_order_relaxed);
    while(distance<old && !a.compare_exchange_weak(old,distance,cuda::memory_order_release,
                                                  cuda::memory_order_relaxed)) {}
}
__device__ __forceinline__ bool needs_recovery(int local,int distance,int ordinary) {
    if(distance>=ordinary)return false;
    const int *completed=device.completed;
    if(!completed)return true;
    const int certified=cuda::atomic_ref<const int,cuda::thread_scope_device>(completed[local]).load(cuda::memory_order_acquire);
    return distance<certified;
}
__device__ __forceinline__ bool busy(int lane) {
    const auto &v=device;int yes=0;
    if (!lane && v.slots) yes=sys_read(v.active)!=0 || sys_read(v.peer_active)!=0;
    return __shfl_sync(FULL_MASK,yes,0)!=0;
}

// Original worker exclusively owns each loan and its donor ledger. The peer
// never writes these ordinary fields. Only active/ready/channel are shared.
template<class Queue>
__device__ __noinline__ bool borrow(Queue &mlmq,int bid,int wid,int lane,
    int node_in_count,int fly,int *distance,int *term_req,int *bulk_req,NODE_TYPE *scratch) {
    const auto v=device;
    const int slot=v.force?bid*WARP_NUM_PER_BLOCK+wid:(wid==0?bid:-1);
    if (!v.admit || !v.slots || slot<0 || slot>=v.slots || node_in_count || fly<=0) return false;
    extern __shared__ int memory[];
    auto &q=* (reinterpret_cast<l1_SLF_queue<NODE_TYPE>*>(memory)+wid);
    int stopping=0;
    if(!lane) stopping=(term_req && l3_atomic_load_acquire<cuda::thread_scope_device>(term_req)) ||
                      (bulk_req && l3_atomic_load_acquire<cuda::thread_scope_device>(bulk_req));
    stopping=__shfl_sync(FULL_MASK,stopping,0);
    if (q.data_size<v.min_seeds || stopping) return false;
    int allowed=!lane ? (v.force || sys_read(v.peer_quiet)) : 0;
    if (!__shfl_sync(FULL_MASK,allowed,0)) return false;
    auto &l=v.loans[slot];
    if (!lane) { assert(!l.donor.outstanding && l.state.stage==bc::phase::free); l.donor={fly,0,false}; }
    __syncwarp();
    if (!ld::borrow(q,l.state,l.state.generation,l.donor,fly,0,0,distance+1,
                   v.begin,v.end,v.vertices,l.snapshot,scratch,lane)) {
        if(!lane) l.donor={0,0,true};
        __syncwarp();return false;
    }
    if (!lane) {
        active_add(v.active,1);
        atomicAdd(&v.stats->loans,1ull);atomicAdd(&v.stats->seeds,(unsigned long long)l.state.seed_count);
    }
    __syncwarp();
#if (L3_BATCH_BOUND_NEIGHBORS == true)
    if(v.bound_mode) {
        const auto observed=l3_batch_bound::publish_neighbors(v.bound_mirror,distance+1,
            v.owner_rows,v.owner_columns,v.begin,v.end-v.begin,l.state.roots,l.state.seed_count,
            v.neighbor_edge_limit,lane);
#if (L3_BATCH_BOUND_DIAG == true)
        unsigned reads=observed.reads,finite=observed.finite;
        for(int offset=16;offset;offset>>=1) {
            reads+=__shfl_down_sync(FULL_MASK,reads,offset);
            finite+=__shfl_down_sync(FULL_MASK,finite,offset);
        }
        if(!lane) {
            atomicAdd(&v.stats->neighbor_reads,(unsigned long long)reads);
            atomicAdd(&v.stats->neighbor_finite,(unsigned long long)finite);
        }
#endif
    }
    __syncwarp(); // original READY publication fences every lane afterwards
#endif
    assert(pc::publish_request(l.state,v.outgoing+slot,v.budget,lane));
    if (!lane) cuda::atomic_ref<unsigned,cuda::thread_scope_system>(v.peer_ready[slot/32]).fetch_or(1u<<(slot%32),cuda::memory_order_release);
    __syncwarp();return true;
}

template<class Queue>
__device__ __noinline__ bool progress(Queue &mlmq,int bid,int wid,int lane,
    int &fly,int *distance,int *processed,NODE_TYPE *scratch) {
    const auto v=device;const int slot=v.force?bid*WARP_NUM_PER_BLOCK+wid:bid;
    auto &l=v.loans[slot];auto &s=l.state;auto &p=l.intent;
    if (s.stage==bc::phase::borrowed) {
        if (!bp::accept_return(s,v.outgoing+slot,l.journal,l.validation,lane)) return true;
        if (!lane) atomicAdd(&v.stats->records,(unsigned long long)s.count);
        __syncwarp();
    }
    if (p.status==bw::publication::empty) bp::prepare(s,s.generation,p,distance+1,lane);
    if (p.status==bw::publication::prepared) {
        if (p.remote) {
            rc::send(s,s.generation,p,l.sender,l.ticket,v.tx+slot,lane);
            rc::poll(s,s.generation,p,l.sender,l.ticket,v.tx+slot,lane);
        } else assert(bw::publish_l2(s,s.generation,p,mlmq.q2,scratch,bid,wid,lane));
    }
    if (p.status==bw::publication::published) {
        if (!lane) {
            atomicAdd(p.remote?&v.stats->remote:&v.stats->local,(unsigned long long)p.count);
            assert(bw::acknowledge(s,s.generation,p));
        }
        __syncwarp();
    }
    if (s.stage!=bc::phase::finished) return true;
#if (L3_BATCH_BOUND_RETURNED == true)
    const auto published=l3_batch_return_bound::publish(v.bound_mirror,s,v.bound_mode,lane);
#if (L3_BATCH_BOUND_DIAG == true)
    unsigned seen=published.reads,writes=published.finite;
    for(int offset=16;offset;offset/=2) {seen+=__shfl_down_sync(FULL_MASK,seen,offset);writes+=__shfl_down_sync(FULL_MASK,writes,offset);}
    if(!lane && v.bound_mode && s.journal) {
        atomicAdd(&v.stats->returned_loans,1ull);
        atomicAdd(&v.stats->returned_records,static_cast<unsigned long long>(seen));
        atomicAdd(&v.stats->returned_published,static_cast<unsigned long long>(writes));
    }
#endif
    __syncwarp(); // finish every publisher before retirement/recycle
#endif
    // Only after ALL outputs are durable may helper full-row certificates
    // become completed labels. Never use ordinary last_processed as a helper
    // certificate or to elide an outstanding winner during APPLY.
    unsigned certificate_count=0; if (s.journal) for(int i=lane;i<s.count;i+=32) {
        const auto r=s.journal[i];
        if(r.vertex>=v.begin && r.vertex<v.end && r.certificate<INT_MAX) {
            publish_completed(r.vertex-v.begin+1,r.certificate);
            if(L3_BATCH_CERT_COUNT_AGGREGATE) ++certificate_count; else atomicAdd(&v.stats->certificates,1ull);
        }
    }
    __syncwarp(); if(L3_BATCH_CERT_COUNT_AGGREGATE) { for(int offset=16;offset;offset/=2) certificate_count+=__shfl_down_sync(FULL_MASK,certificate_count,offset); if(!lane && certificate_count) atomicAdd(&v.stats->certificates,static_cast<unsigned long long>(certificate_count)); }
    extern __shared__ int memory[];
    auto &q=*(reinterpret_cast<l1_SLF_queue<NODE_TYPE>*>(memory)+wid);
    const int retired=ld::retire(q,l.donor,fly,0,0,p.status==bw::publication::empty,lane);
    assert(retired>0 && fly==0);
    if (!lane) mlmq.update_done(retired);
    __syncwarp();
    assert(pc::recycle_committed(s,v.outgoing+slot,p,lane));
    if (!lane) active_add(v.active,-1);
    __syncwarp();return false;
}

__global__ void helper_kernel(int *exit) {
    const int lane=threadIdx.x%32,wid=threadIdx.x/32;
    const int worker=blockIdx.x*2+wid;
    const auto v=device;
    const int words=(v.slots+31)/32;
    __shared__ l3_batch_compact_packed::workspace scratch[2];
    while(true) {
        int stop=!lane?l3_atomic_load_acquire<cuda::thread_scope_device>(exit):0;
        if(__shfl_sync(FULL_MASK,stop,0)) break;
        // Diagnostic idle resident CTA: identical allocation, no queue reads.
        // Host forbids loan admission when service polling is disabled.
        if(!v.service_poll) { __nanosleep(64); continue; }
        for(int scan=0;scan<words;++scan) {
            const int w=(worker+scan)%words;
            int id=-1;
            if(!lane) {
                auto ready=cuda::atomic_ref<unsigned,cuda::thread_scope_system>(v.ready[w]);
                const unsigned bits=ready.load(cuda::memory_order_relaxed);
                if(bits) {
                    const unsigned bit=bits & (0u-bits);
                    // Clear only the claimed bit. Other helpers can work on
                    // the rest of this word concurrently. A competing loser
                    // accepts no packet and simply scans another word.
                    if(ready.fetch_and(~bit,cuda::memory_order_acq_rel)&bit) id=w*32+__ffs(bit)-1;
                }
            }
            id=__shfl_sync(FULL_MASK,id,0);
            if(id>=0) {
                assert(id<v.slots);
                const auto token=pc::try_claim(v.incoming+id,lane);
                assert(token);
                // Do not access packet fields after RETURNED publication.
                l3_batch_search_diag::counters *search=nullptr;
#if (L3_BATCH_SEARCH_DIAG == true)
                search=v.search_counts+worker;
#endif
#if (L3_BATCH_OWNER_BOUND == true)
                l3_batch_peer_packed::execute_claimed<L3_BATCH_BOUND_DIAG,L3_BATCH_SEARCH_DIAG,L3_BATCH_LABEL_SELECT>(v.incoming+id,token,v.peer_graph,
                    scratch+wid,lane,v.peer_bound,v.bound_counts+worker,search);
#else
                l3_batch_peer_packed::execute_claimed<false,L3_BATCH_SEARCH_DIAG,L3_BATCH_LABEL_SELECT>(v.incoming+id,token,v.peer_graph,scratch+wid,lane,{},nullptr,search);
#endif
                if(!lane) {
                    atomicAdd(&v.stats->helpers,1ull);
                    atomicAdd(v.stats->helper_by_warp+worker,1ull);
                }
            }
        }
        __nanosleep(64);
    }
}

template<class Queue>
__global__ void rx_kernel(Queue mlmq,int *exit,int *distance) {
    const int lane=threadIdx.x%32,wid=threadIdx.x/32;
    const auto v=device;
    __shared__ NODE_TYPE scratch[2][32];
    int bound_cursor=threadIdx.x;
#if (L3_BATCH_BOUND_PUBLISH_DIAG == true)
    l3_batch_bound::publisher_counters published{};
#endif
    while(true) {
        int stop=!lane?l3_atomic_load_acquire<cuda::thread_scope_device>(exit):0;
        if(__shfl_sync(FULL_MASK,stop,0)) break;
        if(!v.service_poll) { __nanosleep(64); continue; }
#if (L3_BATCH_OWNER_BOUND == true && L3_BATCH_BOUND_NEIGHBORS == false)
        if(v.bound_mode) {
            const auto observed=l3_batch_bound::publish(v.bound_mirror,distance+1,v.end-v.begin,
                                                       bound_cursor,threadIdx.x,v.bound_steps);
#if (L3_BATCH_BOUND_PUBLISH_DIAG == true)
            ++published.loops;published.reads+=observed.reads;published.finite+=observed.finite;
#endif
        }
#endif
        if(!threadIdx.x) cuda::atomic_ref<int,cuda::thread_scope_system>(*v.quiet).store(
            mlmq.q2.get_queue_size()==0,cuda::memory_order_release);
        for(int id=wid;id<v.slots;id+=2) {
            auto &r=v.receivers[id];
            if(!rc::claim(v.rx+id,r,v.begin,v.end,lane)) continue;
            assert(rc::apply(r,distance+1,v.begin,lane));
            assert(rc::publish_l2(r,mlmq.q2,scratch[wid],0,wid,lane));
            assert(rc::mark_done(v.rx+id,r,lane));
            assert(rc::acknowledge(v.rx+id,r,lane));
            if(!lane) atomicAdd(&v.stats->receipts,1ull);
        }
        __nanosleep(64);
    }
#if (L3_BATCH_BOUND_PUBLISH_DIAG == true)
    published.cursor=bound_cursor;
    // Index ownership is fixed modulo 64. Count wraps from lane 0's scans;
    // no per-entry instrumentation atomics or extra CTA synchronization.
    const unsigned long long lane_reads=published.reads;
    const unsigned positions=v.end-v.begin>int(threadIdx.x)?(v.end-v.begin-1-int(threadIdx.x))/64+1:0;
    published.wraps=positions?int(lane_reads/positions):0;
    for(int offset=16;offset;offset>>=1) {
        published.reads+=__shfl_down_sync(FULL_MASK,published.reads,offset);
        published.finite+=__shfl_down_sync(FULL_MASK,published.finite,offset);
    }
    if(!lane) v.publisher_counts[wid]=published;
#endif
}

inline void check(cudaError_t e,const char *what) {
    if(e!=cudaSuccess) { fprintf(stderr,"L3_BATCH_RUNTIME CUDA %s: %s\n",what,cudaGetErrorString(e));std::abort(); }
}
__global__ void reset_completed(int *completed,int n) {
    for(int i=blockIdx.x*blockDim.x+threadIdx.x;i<n;i+=gridDim.x*blockDim.x)completed[i]=INT_MAX;
}
template<class T> T *allocate(int gpu,size_t n) {
    T *p=nullptr;check(cudaMalloc(&p,sizeof(T)*n),"allocate");allocations[gpu].push_back(p);
    check(cudaMemset(p,0,sizeof(T)*n),"zero");return p;
}
__global__ void reset_kernel(view v) {
    const int i=blockIdx.x*blockDim.x+threadIdx.x;
    if(i<v.slots) {
        auto &l=v.loans[i];bc::initialize(l.state);l.donor={0,0,true};l.intent={};l.sender={};l.ticket={};
        v.outgoing[i].channel.control=relay::encode(1,relay::free);
        v.rx[i]={};v.receivers[i]={};
    }
    if(i<(v.slots+31)/32) v.ready[i]=0;
    if(!i) {*v.active=0;*v.quiet=0;*v.stats={};}
}
inline void reset(int gpu) {
    if(!host[gpu].slots)return;
    const auto v=host[gpu]; check(l3_batch_completed_filter::reset(),"completed filter reset");
    reset_completed<<<256,256>>>(v.completed,v.end-v.begin+1);check(cudaGetLastError(),"completed reset");
    reset_kernel<<<1,128>>>(host[gpu]);check(cudaGetLastError(),"query reset");
#if (L3_BATCH_SEARCH_DIAG == true)
    check(cudaMemset(v.search_counts,0,16*sizeof(l3_batch_search_diag::counters)),"search counts reset");
#endif
#if (L3_BATCH_OWNER_BOUND == true)
#if (L3_BATCH_BOUND_HELPER_LOCAL == true)
    // Reset on the storage GPU, using the opposite owner's length. The
    // existing two-device query barrier completes both resets before work.
    reset_completed<<<256,256>>>(v.bound_storage,v.peer_graph.vertices);check(cudaGetLastError(),"local helper bound reset");
#else
    reset_completed<<<256,256>>>(v.bound_mirror,v.end-v.begin);check(cudaGetLastError(),"bound reset");
#endif
    check(cudaMemset(v.bound_counts,0,16*sizeof(l3_batch_bound::counters)),"bound counts reset");
#if (L3_BATCH_BOUND_PUBLISH_DIAG == true)
    check(cudaMemset(v.publisher_counts,0,2*sizeof(l3_batch_bound::publisher_counters)),"publisher counts reset");
#endif
#endif
}

// Called after both ordinary contexts and peer mappings exist. Replication
// is outside solve, reported separately and must be charged for amortization.
inline void install(int n_gpu) {
    const auto started=std::chrono::steady_clock::now();
    if(n_gpu!=2 || !bench_env_int("MLMQ_BATCH_ENABLED",1,0,1)) return;
    const int slots=bench_env_int("MLMQ_BATCH_SLOTS",32,1,max_slots);
    for(int gpu=0;gpu<2;++gpu) {
        check(cudaSetDevice(gpu),"set device");auto &v=host[gpu];const auto &peer=gctx[1-gpu];
        v.slots=slots;v.budget=bench_env_int("MLMQ_BATCH_BUDGET",64,1,512);
        v.min_seeds=bench_env_int("MLMQ_BATCH_MIN_SEEDS",1,1,32);v.force=bench_env_int("MLMQ_BATCH_FORCE",0,0,1);
        // Diagnostic gate only: keep CSR replication, completed reset, helper
        // and RX kernels, and manager accounting installed when admission=0.
        v.admit=bench_env_int("MLMQ_BATCH_ADMIT",1,0,1);
        v.probe_calls=bench_env_int("MLMQ_BATCH_PROBE_CALLS",1,0,1);
        v.services=bench_env_int("MLMQ_BATCH_SERVICES",3,0,3);
        v.service_poll=bench_env_int("MLMQ_BATCH_SERVICE_POLL",1,0,1);
        g_benchmark.require(!v.admit || (v.probe_calls && v.services==3 && v.service_poll),
            "admitted loans require borrow probes and both polling services");
        v.begin=gctx[gpu].v_begin;v.end=gctx[gpu].v_end;v.vertices=gctx[gpu].m;
        v.loans=allocate<loan>(gpu,slots);v.outgoing=allocate<pc::packet>(gpu,slots);
        v.rx=allocate<rc::channel>(gpu,slots);v.receivers=allocate<rc::receiver>(gpu,slots);
        v.ready=allocate<unsigned>(gpu,(slots+31)/32);v.active=allocate<int>(gpu,1);v.quiet=allocate<int>(gpu,1);v.stats=allocate<metrics>(gpu,1);
        v.completed=allocate<int>(gpu,v.end-v.begin+1);
#if (L3_BATCH_SEARCH_DIAG == true)
        v.search_counts=allocate<l3_batch_search_diag::counters>(gpu,16);
#endif
#if (L3_BATCH_OWNER_BOUND == true)
        v.bound_mode=bench_env_int("MLMQ_BATCH_BOUND_MODE",2,0,3);
        v.bound_steps=bench_env_int("MLMQ_BATCH_BOUND_STEPS",32,1,1024);
#if (L3_BATCH_BOUND_HELPER_LOCAL == true)
        v.bound_storage=allocate<int>(gpu,peer.v_local);
#else
        v.bound_mirror=allocate<int>(gpu,v.end-v.begin);
#endif
        v.bound_counts=allocate<l3_batch_bound::counters>(gpu,16);
#if (L3_BATCH_BOUND_NEIGHBORS == true)
        v.owner_rows=gctx[gpu].RowPtr;v.owner_columns=gctx[gpu].ColIdx;
        v.neighbor_edge_limit=bench_env_int("MLMQ_BATCH_BOUND_EDGE_LIMIT",32,1,128);
#endif
#if (L3_BATCH_BOUND_PUBLISH_DIAG == true)
        v.publisher_counts=allocate<l3_batch_bound::publisher_counters>(gpu,2);
#endif
        int native=0;check(cudaDeviceGetP2PAttribute(&native,cudaDevP2PAttrNativeAtomicSupported,1-gpu,gpu),"bound native atomics");
        if(!native) { fprintf(stderr,"owner-bound requires bidirectional native peer atomics\n");std::exit(2); }
#endif
        int edges=0;check(cudaMemcpy(&edges,peer.RowPtr+peer.v_local,sizeof(int),cudaMemcpyDeviceToHost),"peer edge count");
        auto rows=allocate<int>(gpu,peer.v_local+1),cols=allocate<int>(gpu,std::max(edges,1)),weights=allocate<int>(gpu,std::max(edges,1));
        check(cudaMemcpyPeer(rows,gpu,peer.RowPtr,1-gpu,(peer.v_local+1)*sizeof(int)),"peer rows copy");
        check(cudaMemcpyPeer(cols,gpu,peer.ColIdx,1-gpu,edges*sizeof(int)),"peer columns copy");
        check(cudaMemcpyPeer(weights,gpu,peer.edge_data,1-gpu,edges*sizeof(int)),"peer weights copy");
        // Partition CSR keeps global zero-based destinations; only ordinary
        // queue items add one. The compact graph already uses this CSR basis.
        v.peer_graph={rows,cols,weights,peer.v_begin,peer.v_local};
        check(cudaStreamCreateWithFlags(&helper_stream[gpu],cudaStreamNonBlocking),"helper stream");
        check(cudaStreamCreateWithFlags(&rx_stream[gpu],cudaStreamNonBlocking),"RX stream");
        check(cudaDeviceSynchronize(),"install sync");
        printf("L3_BATCH_REPLICA gpu=%d vertices=%d edges=%d bytes=%llu\n",gpu,peer.v_local,edges,
            (unsigned long long)(peer.v_local+1+2ull*edges)*sizeof(int));
    }
    for(int gpu=0;gpu<2;++gpu) {
        check(cudaSetDevice(gpu),"bind device");auto &v=host[gpu];const auto &p=host[1-gpu];
        v.incoming=p.outgoing;v.tx=p.rx;v.peer_ready=p.ready;v.peer_active=p.active;v.peer_quiet=p.quiet;
#if (L3_BATCH_OWNER_BOUND == true)
#if (L3_BATCH_BOUND_HELPER_LOCAL == true)
        v.bound_mirror=p.bound_storage; // owner publishes to remote helper
        v.peer_bound.values=v.bound_storage; // helper reads its local storage
        cudaPointerAttributes publish{},read{};
        check(cudaPointerGetAttributes(&publish,v.bound_mirror),"publisher mirror location");
        check(cudaPointerGetAttributes(&read,v.peer_bound.values),"helper mirror location");
        g_benchmark.require(publish.type==cudaMemoryTypeDevice && publish.device==1-gpu &&
            read.type==cudaMemoryTypeDevice && read.device==gpu,"helper-local mirror physical placement");
#else
        v.peer_bound.values=p.bound_mirror;
#endif
        v.peer_bound.mode=v.bound_mode==3?0:v.bound_mode;
#endif
        check(cudaMemcpyToSymbol(device,&v,sizeof(v)),"install view");reset(gpu);check(cudaDeviceSynchronize(),"reset sync");
#if (L3_LIVE_SNAPSHOT == true)
        check(cudaMallocHost(&observations[gpu],sizeof(observation)),"observation pinned allocation");
#endif
    }
    printf("L3_BATCH_INSTALL slots=%d wall_ms=%.6f\n",slots,
        std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-started).count());
}

static size_t helper_dynamic[MAX_GPU]={},rx_dynamic[MAX_GPU]={};
template<class Queue> void prepare(int gpu,int queue_type,size_t worker_shared,size_t manager_shared) {
    if(!host[gpu].slots)return;
    g_benchmark.require(queue_type==L1SLF_L2DQ,"batch runtime requires SLF/DQ");
    const int requested=bench_env_int("MLMQ_BATCH_SERVICE_CARVEOUT",-1,-1,100);
    // A soft carveout preference, applied before any persistent launch.
    // Never change a legacy hard cache preference while services are live.
    if(requested>=0) {
        check(cudaFuncSetAttribute(helper_kernel,cudaFuncAttributePreferredSharedMemoryCarveout,requested),"helper carveout");
        check(cudaFuncSetAttribute(rx_kernel<Queue>,cudaFuncAttributePreferredSharedMemoryCarveout,requested),"RX carveout");
    }
    cudaFuncAttributes helper{},rx{};
    check(cudaFuncGetAttributes(&helper,helper_kernel),"helper preload");
    check(cudaFuncGetAttributes(&rx,rx_kernel<Queue>),"RX preload");
    int sm_shared=0,block_optin=0,sm_count=0;
    check(cudaDeviceGetAttribute(&sm_shared,cudaDevAttrMaxSharedMemoryPerMultiprocessor,gpu),"SM shared capacity");
    check(cudaDeviceGetAttribute(&block_optin,cudaDevAttrMaxSharedMemoryPerBlockOptin,gpu),"block shared capacity");
    check(cudaDeviceGetAttribute(&sm_count,cudaDevAttrMultiProcessorCount,gpu),"SM count");
    const int total=bench_env_int("MLMQ_BATCH_SERVICE_SHARED_BYTES",0,0,block_optin);
    helper_dynamic[gpu]=rx_dynamic[gpu]=0;
    if(total) {
        // Unused dynamic allocation is an opt-in placement diagnostic. It
        // prevents a service CTA sharing an SM with another persistent CTA.
        g_benchmark.require(size_t(total)>=helper.sharedSizeBytes && size_t(total)>=rx.sharedSizeBytes,
            "service shared target below static footprint");
        g_benchmark.require(size_t(total)+worker_shared>size_t(sm_shared) &&
            size_t(total)+manager_shared>size_t(sm_shared) && 2*size_t(total)>size_t(sm_shared),
            "service allocation does not exclude persistent co-residency");
        helper_dynamic[gpu]=size_t(total)-helper.sharedSizeBytes;
        rx_dynamic[gpu]=size_t(total)-rx.sharedSizeBytes;
        check(cudaFuncSetAttribute(helper_kernel,cudaFuncAttributeMaxDynamicSharedMemorySize,int(helper_dynamic[gpu])),"helper dynamic limit");
        check(cudaFuncSetAttribute(rx_kernel<Queue>,cudaFuncAttributeMaxDynamicSharedMemorySize,int(rx_dynamic[gpu])),"RX dynamic limit");
    }
    printf("L3_BATCH_SHARED_CONFIG gpu=%d requested=%d helper_static=%zu helper_dynamic=%zu rx_static=%zu rx_dynamic=%zu worker_total=%zu manager_total=%zu sm_capacity=%d block_capacity=%d sm_count=%d\n",
        gpu,total,helper.sharedSizeBytes,helper_dynamic[gpu],rx.sharedSizeBytes,rx_dynamic[gpu],
        worker_shared,manager_shared,sm_shared,block_optin,sm_count);
    // Returned preference is not a measurement of the hardware's actual split.
    printf("L3_BATCH_CACHE_CONFIG gpu=%d requested=%d helper_preferred=%d rx_preferred=%d helper_static=%zu rx_static=%zu\n",
        gpu,requested,helper.preferredShmemCarveout,rx.preferredShmemCarveout,helper.sharedSizeBytes,rx.sharedSizeBytes);
}
template<class Queue> void launch(int gpu,Queue mlmq,int *exit,int *distance) {
    if(!host[gpu].slots)return;
    const int blocks=helper_blocks();
    printf("L3_BATCH_HELPER_CONFIG gpu=%d blocks=%d warps=%d\n",gpu,blocks,2*blocks);
    printf("L3_BATCH_ADMISSION_CONFIG gpu=%d allowed=%d\n",gpu,host[gpu].admit);
    const auto v=host[gpu];
    printf("L3_BATCH_SERVICE_CONFIG gpu=%d helper=%d rx=%d probe_calls=%d\n",
        gpu,bool(v.services&1),bool(v.services&2),v.probe_calls);
    printf("L3_BATCH_POLL_CONFIG gpu=%d enabled=%d\n",gpu,v.service_poll);
#if (L3_BATCH_LABEL_SELECT == true)
    printf("L3_BATCH_SELECT_CONFIG gpu=%d enabled=1 stride=32\n",gpu);
#endif
#if (L3_BATCH_OWNER_BOUND == true)
#if (L3_BATCH_BOUND_RETURNED == true)
    printf("L3_BATCH_BOUND_RETURNED_CONFIG gpu=%d after_finished=1\n",gpu);
#endif
    printf("L3_BATCH_BOUND_CONFIG gpu=%d mode=%d steps=%d peer_bound=%d mirror_bytes=%llu\n",gpu,
        v.bound_mode,v.bound_steps,v.peer_bound.values!=nullptr,4ull*(v.end-v.begin));
#if (L3_BATCH_BOUND_NEIGHBORS == true)
    printf("L3_BATCH_BOUND_NEIGHBORS_CONFIG gpu=%d edge_limit=%d scan_enabled=0\n",gpu,v.neighbor_edge_limit);
#endif
#if (L3_BATCH_BOUND_HELPER_LOCAL == true)
    printf("L3_BATCH_BOUND_PLACEMENT gpu=%d owner_vertices=%d storage_vertices=%d publisher_target_gpu=%d helper_read_gpu=%d reset_gpu=%d\n",
        gpu,v.end-v.begin,v.peer_graph.vertices,1-gpu,gpu,gpu);
#endif
#endif
    if(v.services&1) { helper_kernel<<<blocks,64,helper_dynamic[gpu],helper_stream[gpu]>>>(exit);check(cudaGetLastError(),"helper launch"); }
    if(v.services&2) { rx_kernel<<<1,64,rx_dynamic[gpu],rx_stream[gpu]>>>(mlmq,exit,distance);check(cudaGetLastError(),"RX launch"); }
}
inline void audit(int gpu) {
    const auto v=host[gpu];if(!v.slots)return; check(l3_batch_completed_filter::report(gpu),"completed filter report");
    int active=-1;metrics stats{};
    check(cudaMemcpy(&active,v.active,sizeof(active),cudaMemcpyDeviceToHost),"active read");
    check(cudaMemcpy(&stats,v.stats,sizeof(stats),cudaMemcpyDeviceToHost),"metrics read");
    std::vector<loan> loans(v.slots);std::vector<pc::packet> packets(v.slots);std::vector<rc::receiver> rx(v.slots);
    check(cudaMemcpy(loans.data(),v.loans,loans.size()*sizeof(loan),cudaMemcpyDeviceToHost),"loan audit");
    check(cudaMemcpy(packets.data(),v.outgoing,packets.size()*sizeof(pc::packet),cudaMemcpyDeviceToHost),"relay audit");
    check(cudaMemcpy(rx.data(),v.receivers,rx.size()*sizeof(rc::receiver),cudaMemcpyDeviceToHost),"RX audit");
    g_benchmark.require(active==0,"batch final active loans");
    if(!v.admit) g_benchmark.require(!stats.loans && !stats.seeds && !stats.records && !stats.local &&
        !stats.remote && !stats.certificates && !stats.helpers && !stats.receipts,"disabled admission did work");
    for(int i=0;i<v.slots;++i) {
        const auto &l=loans[i];g_benchmark.require(l.state.stage==bc::phase::free && !l.donor.outstanding && l.donor.released &&
            l.intent.status==bw::publication::empty && !l.ticket.live && !l.sender.held[0] && !l.sender.held[1] &&
            packets[i].channel.control==relay::encode(l.state.generation,relay::free) && rx[i].phase==rc::rx_phase::empty,"batch final slot");
    }
    printf("L3_BATCH_RUNTIME_AUDIT gpu=%d slots=%d budget=%d force=%d loans=%llu seeds=%llu records=%llu local=%llu remote=%llu certificates=%llu helpers=%llu receipts=%llu active=0 PASS\n",
        gpu,v.slots,v.budget,v.force,stats.loans,stats.seeds,stats.records,stats.local,stats.remote,stats.certificates,stats.helpers,stats.receipts);
    unsigned long long total=0;int active_warps=0;
    for(int i=0;i<16;++i) {
        total+=stats.helper_by_warp[i];active_warps+=stats.helper_by_warp[i]>0;
        g_benchmark.require(i<2*helper_blocks() || !stats.helper_by_warp[i],"helper outside launch grid");
    }
    g_benchmark.require(total==stats.helpers,"helper warp count conservation");
    char line[512];
    int length=snprintf(line,sizeof(line),"L3_BATCH_HELPER_AUDIT gpu=%d blocks=%d active_warps=%d counts=",gpu,helper_blocks(),active_warps);
    for(int i=0;i<2*helper_blocks();++i)
        length+=snprintf(line+length,sizeof(line)-length,"%s%llu",i?",":"",stats.helper_by_warp[i]);
    printf("%s\n",line); // one stdio record even when both host threads audit
#if (L3_BATCH_SEARCH_DIAG == true)
    l3_batch_search_diag::counters search[16];
    check(cudaMemcpy(search,v.search_counts,sizeof(search),cudaMemcpyDeviceToHost),"search counts read");
    unsigned long long measured_loans=0;
    for(int warp=0;warp<16;++warp) {
        const auto &s=search[warp];measured_loans+=s.loans;
        g_benchmark.require(s.loans==stats.helper_by_warp[warp],"search/helper loan conservation");
        if(warp<2*helper_blocks())
            printf("L3_BATCH_SEARCH gpu=%d warp=%d loans=%llu seeds=%llu rows=%llu certified=%llu records=%llu remaining=%llu capacity=%llu empty=%llu budget=%llu failure=%llu\n",
                gpu,warp,s.loans,s.seeds,s.rows,s.certified,s.records,s.remaining,s.capacity,s.empty,s.budget,s.failure);
    }
    g_benchmark.require(measured_loans==stats.helpers,"search total loans");
#endif
#if (L3_BATCH_OWNER_BOUND == true)
    long long checks=-1,covered=-1,pruned=-1;
#if (L3_BATCH_BOUND_DIAG == true)
    l3_batch_bound::counters counts[16];
    check(cudaMemcpy(counts,v.bound_counts,sizeof(counts),cudaMemcpyDeviceToHost),"bound counts read");
    checks=covered=pruned=0;
    for(int i=0;i<16;++i) { checks+=counts[i].checks;covered+=counts[i].covered;pruned+=counts[i].pruned; }
#endif
    printf("L3_BATCH_BOUND_AUDIT gpu=%d mode=%d instrumented=%d checks=%lld covered=%lld pruned=%lld\n",
        gpu,v.bound_mode,int(L3_BATCH_BOUND_DIAG),checks,covered,pruned);
#if (L3_BATCH_BOUND_RETURNED == true)
    printf("L3_BATCH_BOUND_RETURNED_AUDIT gpu=%d instrumented=%d loans=%lld records=%lld published=%lld\n",gpu,
        int(L3_BATCH_BOUND_DIAG),L3_BATCH_BOUND_DIAG?(long long)stats.returned_loans:-1ll,
        L3_BATCH_BOUND_DIAG?(long long)stats.returned_records:-1ll,L3_BATCH_BOUND_DIAG?(long long)stats.returned_published:-1ll);
#endif
#if (L3_BATCH_BOUND_NEIGHBORS == true)
    printf("L3_BATCH_BOUND_NEIGHBORS_AUDIT gpu=%d instrumented=%d reads=%lld finite=%lld\n",gpu,
        int(L3_BATCH_BOUND_DIAG),L3_BATCH_BOUND_DIAG?(long long)stats.neighbor_reads:-1ll,
        L3_BATCH_BOUND_DIAG?(long long)stats.neighbor_finite:-1ll);
#endif
#if (L3_BATCH_BOUND_PUBLISH_DIAG == true)
    l3_batch_bound::publisher_counters publisher[2];
    check(cudaMemcpy(publisher,v.publisher_counts,sizeof(publisher),cudaMemcpyDeviceToHost),"publisher counts read");
    for(int warp=0;warp<2;++warp) {
        const auto &p=publisher[warp];
        printf("L3_BATCH_BOUND_PUBLISH gpu=%d warp=%d mode=%d vertices=%d loops=%llu reads=%llu finite=%llu cursor=%d wraps=%d\n",
            gpu,warp,v.bound_mode,v.end-v.begin,p.loops,p.reads,p.finite,p.cursor,p.wraps);
    }
#endif
#endif
}
} // namespace l3_batch_runtime
#endif
