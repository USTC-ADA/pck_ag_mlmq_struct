#pragma once
#include "l3_batch_relay.cuh"

// Standalone candidate, NOT connected to SSSP. Hashing deduplicates vertices;
// a bounded FIFO selects runnable slots, and touched[] enumerates the journal.
// FIFO changes bounded expansion order relative to the old hash-table sweep.
namespace l3_batch_compact {
constexpr int table_size = 1024;
constexpr int capacity = 768;
static_assert(capacity >= l3_batch_relay::seed_capacity, "retain all seeds");
static_assert(capacity <= l3_batch_relay::result_capacity, "return fits");
static_assert(table_size <= 65536, "indices fit unsigned short");
struct workspace {
    int vertices[table_size], distances[table_size], expanded[table_size];
    unsigned queued[table_size / 32];
    unsigned short touched[capacity], fifo[table_size];
    int count, rows, scans;
    unsigned head, tail;
};

// Insertion waves and dequeue waves are separated by full-warp barriers.
// This is NOT an independently concurrent multi-warp queue: tail reservation
// alone does not publish fifo payload. Every lane finishes insertion before
// any lane can consume the next wave. Scratch belongs to one claimed warp.
__device__ __forceinline__ void insert(workspace *work, int vertex, int distance,
                                      l3_batch_relay::graph_view graph) {
    unsigned index = (unsigned(vertex) * 2654435761u) & (table_size - 1);
    for (int probe = 0; probe < table_size; ++probe) {
        const int prior = atomicCAS(work->vertices + index, -1, vertex);
        if (prior == -1 || prior == vertex) {
            if (prior == -1) {
                const int position = atomicAdd(&work->count, 1);
                assert(position < capacity);
                work->touched[position] = static_cast<unsigned short>(index);
            }
            const int old = atomicMin(work->distances + index, distance);
            if (distance < old && vertex >= graph.begin && vertex - graph.begin < graph.vertices) {
                const unsigned bit = 1u << (index % 32);
                if (!(atomicOr(work->queued + index / 32, bit) & bit)) {
                    const unsigned ticket = atomicAdd(&work->tail, 1u);
                    // At most one pending entry per distinct journal slot.
                    assert(ticket - work->head < table_size);
                    work->fifo[ticket & (table_size - 1)] = static_cast<unsigned short>(index);
                }
            }
            return;
        }
        index = (index + 1) & (table_size - 1);
    }
    assert(false);
}

__device__ __forceinline__ void expand_payload(l3_batch_relay::slot *slot,
    l3_batch_relay::graph_view graph, workspace *work, int *certificates,
    int row_budget, int lane) {
    namespace relay = l3_batch_relay;
    for (int index = lane; index < table_size; index += 32) {
        work->vertices[index] = -1;
        work->distances[index] = work->expanded[index] = INT_MAX;
    }
    work->queued[lane] = 0;
    if (!lane) { work->count = work->rows = work->scans = 0; work->head = work->tail = 0; }
    __syncwarp(relay::mask);
    const int seeds = slot->seeds;
    bool valid = seeds > 0 && seeds <= relay::seed_capacity && row_budget >= 0;
    if (valid) for (int i = lane; i < seeds; i += 32) {
        const auto seed = slot->input[i];
        valid &= seed.vertex >= graph.begin && seed.vertex - graph.begin < graph.vertices && seed.distance >= 0;
    }
    int failure = __ballot_sync(relay::mask, valid) == relay::mask ? relay::ok : relay::bad_seed;
    if (failure == relay::ok) for (int i = lane; i < seeds; i += 32) {
        const auto seed = slot->input[i];
        insert(work, seed.vertex, seed.distance, graph);
    }
    __syncwarp(relay::mask);
    while (failure == relay::ok && work->rows < row_budget && work->head != work->tail) {
        const unsigned head = work->head;
        const int take = min(min(32u, work->tail - head), unsigned(row_budget - work->rows));
        int index = -1, snapshot = INT_MAX, first = 0, end = 0;
        bool expand = false;
        if (lane < take) {
            index = work->fifo[(head + lane) & (table_size - 1)];
            snapshot = work->distances[index];
            expand = snapshot < work->expanded[index];
            if (expand) {
                const int local = work->vertices[index] - graph.begin;
                assert(local >= 0 && local < graph.vertices);
                first = graph.rows[local]; end = graph.rows[local + 1];
            }
        }
        if (__ballot_sync(relay::mask, first < 0 || end < first)) { failure = relay::bad_seed; break; }
        unsigned long long additions = static_cast<unsigned long long>(end - first);
        for (int offset = 16; offset; offset >>= 1) additions += __shfl_down_sync(relay::mask, additions, offset);
        additions = __shfl_sync(relay::mask, additions, 0);
        // Complete-wave reservation before any key/certificate mutation.
        // On capacity stop, ALL labels and remaining debts are still returned.
        if (additions > static_cast<unsigned long long>(capacity - work->count)) break;
        const int rows = __popc(__ballot_sync(relay::mask, expand));
        if (lane < take) atomicAnd(work->queued + index / 32, ~(1u << (index % 32)));
        // Finish every snapshot and queued-bit clear before successors can
        // improve a currently executing slot and re-enqueue that slot.
        __syncwarp(relay::mask);
        if (!lane) work->head = head + take;
        __syncwarp(relay::mask);
        bool negative = false;
        for (int edge = first; edge < end; ++edge) {
            const int weight = graph.weights[edge];
            negative |= weight < 0;
            if (weight >= 0 && snapshot < INT_MAX - weight)
                insert(work, graph.columns[edge], snapshot + weight, graph);
        }
        __syncwarp(relay::mask);
        if (__ballot_sync(relay::mask, negative)) { failure = relay::bad_weight; break; }
        if (expand) work->expanded[index] = min(work->expanded[index], snapshot);
        if (!lane) { work->rows += rows; ++work->scans; }
        __syncwarp(relay::mask);
    }
    const int count = failure == relay::ok ? work->count : 0;
    for (int i = lane; i < count; i += 32) {
        const int index = work->touched[i];
        slot->output[i] = {work->vertices[index], work->distances[index]};
        certificates[i] = work->expanded[index];
    }
    if (!lane) { slot->results = count; slot->result_status = failure; }
    __syncwarp(relay::mask);
}

__device__ __forceinline__ void execute(l3_batch_relay::slot *slot,
    l3_batch_relay::word token, l3_batch_relay::graph_view graph,
    workspace *work, int *certificates, int budget, int lane) {
    namespace relay = l3_batch_relay;
    assert(relay::load(slot) == token && relay::state(token) == relay::active);
    expand_payload(slot, graph, work, certificates, budget, lane);
    // Same two-pass owner contract as the old workset. This journal never
    // authorizes dropping original credit before ALL outputs/debts are durable.
    relay::publish_exclusive(slot, relay::encode(relay::generation(token), relay::returned), lane);
}
} // namespace l3_batch_compact
