#pragma once
#include "l3_sync.cuh"
#include <climits>
#include <cassert>

// Dedicated distance mirror: owner-local loads match legacy device-scope
// writers; only this mirror is shared with the helper at system scope.
// Reset to INF and synchronize BOTH devices before each query's launches.
namespace l3_batch_bound {
struct view { int *values; int mode; }; // value-initialize for disabled mode
struct counters { unsigned long long checks, covered, pruned; };
struct sampled { unsigned reads, finite; };
struct publisher_counters { unsigned long long loops, reads, finite; int cursor, wraps; };

// Called by one persistent 64-thread RX block. Each index has exactly one
// writer (index % 64), including across wraps. Original distances only decrease
// within a query; stale larger mirror values merely miss pruning opportunities.
__device__ __forceinline__ sampled publish(int *mirror, int *distance, int n,
                                       int &cursor, int thread, int steps) {
    sampled observed{};
    for (int step = 0; step < steps; ++step) {
        if (cursor < n) {
            const int value = l3_atomic_load_relaxed<cuda::thread_scope_device>(distance + cursor);
            ++observed.reads;
            observed.finite += value < INT_MAX;
            if (value < INT_MAX)
                l3_atomic_store_relaxed<cuda::thread_scope_system>(mirror + cursor, value);
        }
        cursor += 64;
        if (cursor >= n) cursor = thread;
    }
    return observed; // ignored/optimized away in uninstrumented callers
}

// Called only after roots have been reserved, before their READY publication.
// The caller publishes a system fence after ALL lanes finish. Different donor
// warps may sample the same destination, so every mirror write is a system
// atomic min; the sequential RX publisher must be disabled in this mode.
// distance is a ZERO-BASED owner-local array; roots/columns use global IDs.
template<class Root>
__device__ __forceinline__ sampled publish_neighbors(int *mirror, int *distance,
    const int *rows, const int *columns, int begin, int vertices,
    const Root *roots, int seeds, int edge_limit, int lane) {
    sampled observed{};
    for(int i=lane;i<seeds;i+=32) {
        const int root=roots[i].vertex-begin;
        assert(root>=0 && root<vertices);
        const int first=rows[root], end=rows[root+1];
        assert(first>=0 && end>=first && edge_limit>0);
        const int take=min(end-first,edge_limit);
        for(int edge=0;edge<take;++edge) {
            const int vertex=columns[first+edge];
            if(vertex<begin || vertex-begin>=vertices) continue;
            const int local=vertex-begin;
            const int value=l3_atomic_load_relaxed<cuda::thread_scope_device>(distance+local);
            ++observed.reads;
            if(value<INT_MAX) {
                ++observed.finite;
                l3_atomic_min_system(mirror+local,value);
            }
        }
    }
    return observed; // observational counts disappear when unused
}

// Successors only. Roots bypass this function. Remote destinations bypass the
// mirror altogether. A finite value represents an existing responsibility,
// NOT a completed-row certificate and NOT permission to retire an APPLY win.
template<bool Track>
__device__ __forceinline__ bool skip(view bound, int vertex, int candidate,
                                    int begin, int vertices, counters &count) {
    if (!bound.mode || vertex < begin || vertex - begin >= vertices) return false;
    assert(bound.values);
    const int value = l3_atomic_load_relaxed<cuda::thread_scope_system>(bound.values + vertex - begin);
    // Mode 1 measures the load even in non-instrumented builds. Keep an opaque
    // use so dead-result optimization cannot remove or predicate it on mode 2.
    asm volatile("" : : "r"(value) : "memory");
    const bool covered = value <= candidate;
    const bool pruned = bound.mode == 2 && covered;
    if (Track) { ++count.checks; count.covered += covered; count.pruned += pruned; }
    return pruned;
}

// One writer per helper warp. Only host reads after all kernels synchronize.
// No global per-edge atomics are added to the executor.
__device__ __forceinline__ void accumulate(counters count, counters *total, int lane) {
    for (int offset = 16; offset; offset >>= 1) {
        count.checks += __shfl_down_sync(0xffffffffu, count.checks, offset);
        count.covered += __shfl_down_sync(0xffffffffu, count.covered, offset);
        count.pruned += __shfl_down_sync(0xffffffffu, count.pruned, offset);
    }
    if (!lane) {
        assert(total);
        total->checks += count.checks; total->covered += count.covered; total->pruned += count.pruned;
    }
}
} // namespace l3_batch_bound
