#pragma once
#include <climits>
#include <cstdint>

// Standalone, opt-in contract prototype. NOT connected to the SSSP worker.
// One owner lane exclusively mutates each state AND its donor_ledger. This is
// cooperative retry, not crash recovery or concurrent multi-committer support.
#ifdef __CUDACC__
#define L3_COMMIT_HD __host__ __device__
#else
#define L3_COMMIT_HD
#endif

namespace l3_batch_commit {
struct seed { int vertex, distance; };
struct record { int vertex, distance, certificate; };
enum class phase : unsigned { free, borrowed, apply, remote, local, fallback, finished };
enum class result : unsigned { progress, blocked, complete, stale };

// Credits count L2 ancestors, NOT exported seeds or private L1 descendants.
// Attach a loan BEFORE removing its original tasks from L1. An empty L1 does
// not permit ancestor release (or donor ACK) while outstanding != 0.
struct donor_ledger {
    int ancestor_credits;
    unsigned outstanding;
    bool released;
};
L3_COMMIT_HD inline int retire_if_idle(donor_ledger &donor, bool l1_empty) {
    if (!l1_empty || donor.outstanding || donor.released) return 0;
    donor.released = true;
    return donor.ancestor_credits;
}

template<int Capacity = 768> struct state {
    std::uint64_t generation;
    phase stage;
    int count, cursor, begin, end, vertices, seed_count;
    seed roots[512]; // immutable export-time distance snapshots, duplicates OK
    const record *journal; // immutable until finished and recycled
    donor_ledger *donor;
    // Minimum activation distance THIS loan owns. Initially original seeds;
    // subsequently includes this commit's winners. Sticky across all retries.
    int required[Capacity];
    unsigned wins, local_published, remote_published;
};

template<int N>
L3_COMMIT_HD void initialize(state<N> &s) {
    s.generation = 1;
    s.stage = phase::free;
    s.count = s.cursor = s.begin = s.end = s.vertices = s.seed_count = 0;
    s.journal = nullptr;
    s.donor = nullptr;
    s.wins = s.local_published = s.remote_published = 0;
}

// Reserve BEFORE removing L1 seeds/publishing a helper request. Distances must
// be authoritative export-time snapshots, not stale queued priorities. Other
// updates after each snapshot retain their OWN independent responsibility.
template<int N>
L3_COMMIT_HD bool reserve(state<N> &s, std::uint64_t generation,
    donor_ledger &donor, const seed *seeds, int seed_count,
    int owner_begin, int owner_end, int vertices) {
    if (s.stage != phase::free || generation != s.generation || !seeds ||
        seed_count <= 0 || seed_count > 512 || owner_begin < 0 ||
        owner_begin >= owner_end || owner_end > vertices || donor.released ||
        donor.ancestor_credits <= 0 || donor.outstanding == UINT_MAX) return false;
    for (int i = 0; i < seed_count; ++i)
        if (seeds[i].vertex < owner_begin || seeds[i].vertex >= owner_end ||
            seeds[i].distance < 0 || seeds[i].distance == INT_MAX) return false;
    s.begin = owner_begin;
    s.end = owner_end;
    s.vertices = vertices;
    s.seed_count = seed_count;
    s.count = s.cursor = 0;
    s.journal = nullptr;
    s.wins = s.local_published = s.remote_published = 0;
    for (int i = 0; i < seed_count; ++i) s.roots[i] = seeds[i];
    s.donor = &donor;
    ++donor.outstanding;
    s.stage = phase::borrowed;
    return true;
}

// Validation is deliberately O(records^2 + seeds*records), outside the commit
// hot path. This version establishes a contract, not a fast intake algorithm.
// Certificate path/complete-row validity must be checked by the producer (and
// independently in tests); shape validation alone cannot prove that validity.
template<int N>
L3_COMMIT_HD bool accept_journal(state<N> &s, std::uint64_t generation,
    const record *journal, int count) {
    if (s.stage != phase::borrowed || generation != s.generation || !journal || count <= 0 || count > N)
        return false;
    for (int i = 0; i < count; ++i) {
        const auto r = journal[i];
        if (r.vertex < 0 || r.vertex >= s.vertices || r.distance < 0 || r.distance == INT_MAX ||
            r.certificate < r.distance ||
            ((r.vertex < s.begin || r.vertex >= s.end) && r.certificate != INT_MAX))
            return false;
        for (int j = 0; j < i; ++j) if (journal[j].vertex == r.vertex) return false;
    }
    for (int i = 0; i < s.seed_count; ++i) {
        bool retained = false;
        for (int j = 0; j < count; ++j)
            retained |= journal[j].vertex == s.roots[i].vertex && journal[j].distance <= s.roots[i].distance;
        if (!retained) return false;
    }
    s.count = count;
    s.cursor = 0;
    s.journal = journal;
    s.wins = s.local_published = s.remote_published = 0;
    for (int j = 0; j < count; ++j) {
        s.required[j] = INT_MAX;
        for (int i = 0; i < s.seed_count; ++i)
            if (s.roots[i].vertex == journal[j].vertex && s.roots[i].distance < s.required[j])
                s.required[j] = s.roots[i].distance;
    }
    s.stage = phase::apply;
    return true;
}

// Call only after the helper has relinquished the slot (or before request
// publication). Invalid journals keep the loan alive; fallback requeues roots.
template<int N>
L3_COMMIT_HD bool start_fallback(state<N> &s, std::uint64_t generation) {
    if (s.stage != phase::borrowed || generation != s.generation) return false;
    s.cursor = 0;
    s.stage = phase::fallback;
    return true;
}

// Backend contract:
// * local_min returns the old authoritative distance from atomicMin.
// * publish_local / publish_remote return true ONLY after both the output and
//   its independent termination responsibility are durable. False accepts
//   nothing. They may be consumed immediately after true; no later rollback.
// * Every other distance updater must retain a valid queued/active/pending
//   responsibility until its outputs are durable. A bare finite distance, or
//   last_processed written before relaxation, does NOT satisfy this premise.
// No yield between local_min's return and saving required: exclusive owner
// retains the call frame and donor credit until the next cooperative step.
template<int N, class Backend>
L3_COMMIT_HD result step(state<N> &s, std::uint64_t generation, Backend &backend) {
    if (generation != s.generation || s.stage == phase::free) return result::stale;
    if (s.stage == phase::finished) return result::complete;
    if (s.stage == phase::borrowed) return result::blocked;
    if (s.stage == phase::fallback) {
        if (s.cursor == s.seed_count) {
            --s.donor->outstanding;
            s.stage = phase::finished;
            return result::complete;
        }
        const auto root = s.roots[s.cursor];
        if (!backend.publish_local(root.vertex, root.distance)) return result::blocked;
        ++s.local_published;
        ++s.cursor;
        return result::progress;
    }
    if (s.stage == phase::apply) {
        if (s.cursor == s.count) { s.cursor = 0; s.stage = phase::remote; return result::progress; }
        const int index = s.cursor;
        const auto r = s.journal[index];
        if (r.vertex >= s.begin && r.vertex < s.end) {
            const int old = backend.local_min(r.vertex, r.distance);
            if (r.distance < old) {
                if (r.distance < s.required[index]) s.required[index] = r.distance;
                ++s.wins;
            }
        }
        ++s.cursor;
        return result::progress;
    }
    if (s.stage == phase::remote) {
        if (s.cursor == s.count) { s.cursor = 0; s.stage = phase::local; return result::progress; }
        const auto r = s.journal[s.cursor];
        if (r.vertex < s.begin || r.vertex >= s.end) {
            // Never inspect peer distance to elide a remote output.
            if (!backend.publish_remote(r.vertex, r.distance)) return result::blocked;
            ++s.remote_published;
        }
        ++s.cursor;
        return result::progress;
    }
    if (s.cursor == s.count) {
        // All helper certificate effects are now durable, as are every
        // uncovered original seed and every uncovered sticky winner.
        --s.donor->outstanding;
        s.stage = phase::finished;
        return result::complete;
    }
    const int index = s.cursor;
    const auto r = s.journal[index];
    if (r.vertex >= s.begin && r.vertex < s.end && s.required[index] < r.certificate) {
        if (!backend.publish_local(r.vertex, s.required[index])) return result::blocked;
        ++s.local_published;
    }
    ++s.cursor;
    return result::progress;
}

template<int N>
L3_COMMIT_HD bool recycle(state<N> &s, std::uint64_t generation) {
    if (s.generation != generation || s.stage != phase::finished || generation == UINT64_MAX)
        return false; // fail closed on generation exhaustion; no ABA wrap
    ++s.generation;
    s.stage = phase::free;
    s.journal = nullptr;
    s.donor = nullptr;
    return true;
}
} // namespace l3_batch_commit
#undef L3_COMMIT_HD
