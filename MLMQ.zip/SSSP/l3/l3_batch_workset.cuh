#pragma once
#include "l3_batch_relay.cuh"

// New helper-local representation. This is NOT wired into SSSP yet.
// Keep labels/complete-row certificates locally while doing bounded work;
// only the compact journal crosses back to owner, not every traversed edge.
namespace l3_batch_workset {
constexpr int table_size = 1024;
constexpr int capacity = 768;
static_assert(capacity >= l3_batch_relay::seed_capacity, "retain every seed");
static_assert(capacity <= l3_batch_relay::result_capacity, "journal return fits");
struct workspace {
    int vertices[table_size];
    int distances[table_size];
    int expanded[table_size];
    int count, rows, scans;
};

__device__ __forceinline__ void insert(workspace *work, int vertex, int distance) {
    unsigned index = (unsigned(vertex) * 2654435761u) & (table_size - 1);
    // Empty cells' distance/certificate are initialized BEFORE any key can be
    // published. A losing inserter can immediately atomicMin the shared label.
    for (int probe = 0; probe < table_size; ++probe) {
        const int prior = atomicCAS(work->vertices + index, -1, vertex);
        if (prior == -1 || prior == vertex) {
            if (prior == -1) atomicAdd(&work->count, 1);
            atomicMin(work->distances + index, distance);
            return;
        }
        index = (index + 1) & (table_size - 1);
    }
    assert(false); // complete-row admission keeps at least 256 empty cells
}

// Every lane participates. Input seeds belong to graph's owner. Remote output
// vertices stay in the journal but are never expanded by this owner subgraph.
// Workspace is exclusively used by this warp. Separating payload execution
// keeps the SAME local algorithm available without the migration protocol.
__device__ __forceinline__ void expand_payload(l3_batch_relay::slot *slot,
    l3_batch_relay::graph_view graph,
    workspace *work, int *certificates, int row_budget, int lane) {
    namespace relay = l3_batch_relay;
    for (int index = lane; index < table_size; index += 32) {
        work->vertices[index] = -1;
        work->distances[index] = INT_MAX;
        work->expanded[index] = INT_MAX;
    }
    if (!lane) work->count = work->rows = work->scans = 0;
    __syncwarp(relay::mask);
    const int seeds = slot->seeds;
    bool valid = seeds > 0 && seeds <= relay::seed_capacity && row_budget >= 0;
    if (valid) {
        for (int index = lane; index < seeds; index += 32) {
            const auto seed = slot->input[index];
            valid &= seed.vertex >= graph.begin && seed.vertex - graph.begin < graph.vertices && seed.distance >= 0;
        }
    }
    int failure = __ballot_sync(relay::mask, valid) == relay::mask ? relay::ok : relay::bad_seed;
    if (failure == relay::ok) {
        for (int index = lane; index < seeds; index += 32) {
            const auto seed = slot->input[index];
            insert(work, seed.vertex, seed.distance);
        }
    }
    __syncwarp(relay::mask);
    int cursor = 0, empty_tiles = 0;
    while (failure == relay::ok && work->rows < row_budget && empty_tiles < table_size / 32) {
        const int index = cursor + lane;
        const int vertex = work->vertices[index];
        const int snapshot = work->distances[index];
        bool expand = vertex >= graph.begin && vertex - graph.begin < graph.vertices &&
                      snapshot < work->expanded[index];
        unsigned candidates = __ballot_sync(relay::mask, expand);
        const unsigned before_lane = lane ? (1u << lane) - 1u : 0u;
        const int rank = __popc(candidates & before_lane);
        expand &= rank < row_budget - work->rows;
        candidates = __ballot_sync(relay::mask, expand);
        const int rows = __popc(candidates);
        int first = 0, end = 0;
        if (expand) {
            first = graph.rows[vertex - graph.begin];
            end = graph.rows[vertex - graph.begin + 1];
        }
        if (__ballot_sync(relay::mask, first < 0 || end < first)) {
            failure = relay::bad_seed;
            break;
        }
        unsigned long long additions = static_cast<unsigned long long>(end - first);
        for (int offset = 16; offset; offset >>= 1)
            additions += __shfl_down_sync(relay::mask, additions, offset);
        additions = __shfl_sync(relay::mask, additions, 0);
        // Conservative reservation: even if every edge discovers a new key,
        // ALL admitted rows can finish. Never certify a partially stored row.
        if (additions > static_cast<unsigned long long>(capacity - work->count)) break;
        bool negative = false;
        for (int edge = first; edge < end; ++edge) {
            const int weight = graph.weights[edge];
            negative |= weight < 0;
            if (weight >= 0 && snapshot < INT_MAX - weight)
                insert(work, graph.columns[edge], snapshot + weight);
        }
        __syncwarp(relay::mask);
        if (__ballot_sync(relay::mask, negative)) {
            failure = relay::bad_weight;
            break;
        }
        if (expand) work->expanded[index] = min(work->expanded[index], snapshot);
        if (!lane) { work->rows += rows; ++work->scans; }
        __syncwarp(relay::mask);
        empty_tiles = rows ? 0 : empty_tiles + 1;
        cursor = (cursor + 32) & (table_size - 1);
    }
    int count = 0;
    if (failure == relay::ok) {
        for (int base = 0; base < table_size; base += 32) {
            const int index = base + lane;
            const bool present = work->vertices[index] >= 0;
            const unsigned active = __ballot_sync(relay::mask, present);
            const unsigned before_lane = lane ? (1u << lane) - 1u : 0u;
            const int position = count + __popc(active & before_lane);
            if (present) {
                slot->output[position] = {work->vertices[index], work->distances[index]};
                certificates[position] = work->expanded[index];
            }
            count += __popc(active);
        }
        assert(count == work->count && count <= capacity);
    }
    if (!lane) {
        slot->results = count;
        slot->result_status = failure;
    }
    __syncwarp(relay::mask);
}

// The caller owns ACTIVE(token); workspace is helper-local, certificates is
// owner memory parallel to slot.output. Publication covers both result arrays.
__device__ __forceinline__ void execute(l3_batch_relay::slot *slot,
    l3_batch_relay::word token, l3_batch_relay::graph_view graph,
    workspace *work, int *certificates, int row_budget, int lane) {
    namespace relay = l3_batch_relay;
    const auto acquired = relay::load(slot);
    assert(acquired == token && relay::state(token) == relay::active);
    expand_payload(slot, graph, work, certificates, row_budget, lane);
    // Owner must FIRST apply ALL labels/remote candidates, THEN compare current
    // authoritative labels with certificates and durably enqueue every debt.
    // Replaying only atomicMin winners loses newer/previously known work.
    relay::publish_exclusive(slot, relay::encode(relay::generation(token), relay::returned), lane);
}
} // namespace l3_batch_workset
