#pragma once
#include "l3_batch_compact.cuh"
#include "l3_batch_commit_warp.cuh"

// Isolated composition, NOT wired into SSSP. Owner keeps donor credit across
// reserve -> peer execution -> durable commit. The returned certificate sidecar
// shares the slot's system-release/acquire lifetime; it is not a separate inbox.
namespace l3_batch_peer_commit {
namespace relay = l3_batch_relay;
namespace bc = l3_batch_commit;
namespace bw = l3_batch_commit_warp;
constexpr unsigned mask = relay::mask;
struct packet {
    relay::slot channel;
    int budget;
    int certificates[l3_batch_compact::capacity];
};

// Caller must have reserved the original seeds/credit BEFORE this function.
// One exclusive owner warp; all lanes participate in every transition.
template<int N>
__device__ bool publish_request(const bc::state<N> &state, packet *p, int budget, int lane) {
    const auto generation = state.generation;
    if (state.stage != bc::phase::borrowed || generation > (ULLONG_MAX >> 3)) return false;
    int claimed = 0;
    if (!lane) claimed = relay::move(&p->channel, relay::encode(generation, relay::free), relay::filling);
    claimed = __shfl_sync(mask, claimed, 0);
    if (!claimed) return false;
    for (int i = lane; i < state.seed_count; i += 32)
        p->channel.input[i] = {state.roots[i].vertex, state.roots[i].distance};
    if (!lane) { p->channel.seeds = state.seed_count; p->budget = budget; }
    relay::publish(&p->channel, relay::encode(generation, relay::filling), relay::ready, lane);
    return true;
}

// Two or more helper warps may contend. Exactly one wins this generation.
// All lanes acquire ACTIVE before ANY request payload/sidecar access.
__device__ relay::word try_claim(packet *p, int lane) {
    relay::word token = relay::load(&p->channel);
    token = __shfl_sync(mask, token, 0);
    int claimed = 0;
    if (!lane && relay::state(token) == relay::ready)
        claimed = relay::move(&p->channel, token, relay::active);
    claimed = __shfl_sync(mask, claimed, 0);
    if (!claimed) return 0;
    const auto active = relay::encode(relay::generation(token), relay::active);
    const auto observed = relay::load(&p->channel); // actual acquire, not inside assert
    assert(__all_sync(mask, observed == active));
    return active;
}

__device__ void execute_claimed(packet *p, relay::word token, relay::graph_view graph,
                               l3_batch_compact::workspace *scratch, int lane) {
    const auto observed = relay::load(&p->channel);
    assert(__all_sync(mask, observed == token && relay::state(token) == relay::active));
    l3_batch_compact::execute(&p->channel, token, graph, scratch, p->certificates, p->budget, lane);
    // No lane may touch p's payload after RETURNED publication. Owner may
    // already be committing/recycling the slot on the other device.
}

// Copy the returned journal into owner-private storage before accepting it.
// Invalid payload retains original responsibility and uses the existing
// before-APPLY fallback. Paths/complete-row witnesses remain producer contracts.
template<int N>
__device__ bool accept_return(bc::state<N> &state, packet *p, bc::record *journal, int lane) {
    if (state.stage != bc::phase::borrowed) return false;
    const auto token = relay::encode(state.generation, relay::returned);
    int claimed = 0;
    if (!lane) claimed = relay::move(&p->channel, token, relay::committing);
    claimed = __shfl_sync(mask, claimed, 0);
    if (!claimed) return false;
    const auto observed = relay::load(&p->channel);
    assert(__all_sync(mask, observed == relay::encode(state.generation, relay::committing)));
    bool intact = p->channel.seeds == state.seed_count;
    for (int i = lane; i < state.seed_count; i += 32) {
        const auto item = p->channel.input[i];
        intact &= item.vertex == state.roots[i].vertex && item.distance == state.roots[i].distance;
    }
    assert(__all_sync(mask, intact));
    const int count = p->channel.results;
    const bool valid = p->channel.result_status == relay::ok && count > 0 &&
                       count <= N && count <= l3_batch_compact::capacity;
    if (valid) for (int i = lane; i < count; i += 32)
        journal[i] = {p->channel.output[i].vertex, p->channel.output[i].distance, p->certificates[i]};
    __syncwarp(mask);
    if (!lane) {
        const bool accepted = valid && bc::accept_journal(state, state.generation, journal, count);
        if (!accepted) {
            const bool restored = bc::start_fallback(state, state.generation);
            assert(restored);
        }
    }
    __syncwarp(mask);
    return true;
}

template<int N>
__device__ bool recycle_committed(bc::state<N> &state, packet *p, const bw::intent &intent, int lane) {
    const auto generation = state.generation;
    if (state.stage != bc::phase::finished || intent.status != bw::publication::empty ||
        generation >= (ULLONG_MAX >> 3)) return false;
    const auto token = relay::encode(generation, relay::committing);
    // One collective decision: a per-lane early return before recycle's
    // full-warp barriers would be unsafe if a caller violated the lifetime.
    const auto observed = relay::load(&p->channel);
    if (!__all_sync(mask, observed == token)) return false;
    relay::recycle(&p->channel, token, lane);
    if (!lane) { const bool recycled = bc::recycle(state, generation); assert(recycled); }
    __syncwarp(mask);
    return true;
}
} // namespace l3_batch_peer_commit
