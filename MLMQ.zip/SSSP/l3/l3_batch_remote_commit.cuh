#pragma once
#include <climits>
#include "l3_batch_commit_warp.cuh"
#include "l3_transport.cuh"

#if BULK_ROUND != true || BULK_INBOX_SLOTS != 2
#error "Independent remote-commit fixture requires a dedicated two-slot BULK channel"
#endif
#if L3_FAULT_INJECT_ACK_DELAY == true
#error "Remote commit controls ACK per receipt, not through the solver's global fault state"
#endif

// Independent SPSC transport + conservative RX. NOT connected to solver.
// One source warp owns sender and every ticket on this channel. One RX warp
// owns receiver. Channel storage is on the destination GPU; no solver inbox,
// epoch, termination flag, or global fault state may be shared with it.
namespace l3_batch_remote_commit {
namespace bc = l3_batch_commit;
namespace bw = l3_batch_commit_warp;
constexpr unsigned mask = bw::mask;
struct stamp {
    std::uint64_t generation;
    int start, end, count, epoch;
};
struct channel {
    int state[2], generation[2], epoch[2], ack[2];
    stamp identity[2];
    bc::seed payload[2][32];
};
struct ticket { stamp identity; const void *owner; bool live; };
struct sender {
    int last_epoch;
    bool held[2]; // an ACKed slot is still held until its source ticket is polled
};
enum class rx_phase { empty, copied, applied, published, done };
struct receiver {
    int last_epoch;
    stamp identity;
    bc::seed items[32];
    rx_phase phase;
};

__host__ __device__ inline bool same(const stamp &a, const stamp &b) {
    return a.generation == b.generation && a.start == b.start && a.end == b.end &&
           a.count == b.count && a.epoch == b.epoch;
}
__host__ __device__ inline bool binds(const stamp &a, const bw::intent &p) {
    return a.generation == p.generation && a.start == p.start && a.end == p.end && a.count == p.count;
}
// Every call, including unsuccessful probes, ends at a full-warp memory
// barrier. A caller may immediately overwrite a shared ticket after false;
// a vote/shuffle alone does not order the other lanes' preceding reads.
__device__ inline bool collective_result(bool value) {
    const unsigned values = __ballot_sync(mask, value);
    __syncwarp(mask);
    assert(values == 0u || values == mask);
    return values == mask;
}

// Zero initialization is valid for channel, sender, ticket and receiver.
// Epoch exhaustion rejects new sends, while the final outstanding receipt
// remains consumable. No truncation of the loan's 64-bit generation occurs.
template<int N>
__device__ bool send(const bc::state<N> &s, std::uint64_t generation, bw::intent &p,
                     sender &tx, ticket &t, channel *peer, int lane) {
    if (!bw::matches(s, generation, p) || !p.remote || p.count < 1 || p.count > 32 ||
        p.status != bw::publication::prepared || s.stage != bc::phase::remote) return collective_result(false);
    if (t.live) return collective_result(t.owner == &s && binds(t.identity, p)); // already sent; not a second write
    if (tx.last_epoch < 0 || tx.last_epoch == INT_MAX) return collective_result(false);
    const int epoch = tx.last_epoch + 1, slot = bulk_inbox_slot(epoch);
    if (tx.held[slot]) return collective_result(false);
    int claimed = 0;
    if (!lane) claimed = bulk_inbox_try_acquire_write(peer->state, peer->generation, peer->ack, slot, epoch);
    claimed = __shfl_sync(mask, claimed, 0);
    if (!claimed) return collective_result(false);
    __syncwarp(mask); // all sender/ticket snapshot reads precede lane-0 updates
    if (lane < p.count) peer->payload[slot][lane] = p.items[lane];
    if (!lane) {
        const stamp identity{generation, p.start, p.end, p.count, epoch};
        peer->identity[slot] = identity;
        t.identity = identity; t.owner = &s; t.live = true;
        tx.held[slot] = true; tx.last_epoch = epoch;
        l3_atomic_store_relaxed<cuda::thread_scope_system>(peer->epoch + slot, epoch);
    }
    __threadfence_system();
    __syncwarp(mask);
    if (!lane) l3_atomic_store_release<cuda::thread_scope_system>(peer->state + slot, BULK_SLOT_READY);
    __syncwarp(mask);
    return collective_result(true);
}

template<int N>
__device__ bool poll(const bc::state<N> &s, std::uint64_t generation, bw::intent &p,
                     sender &tx, ticket &t, channel *peer, int lane) {
    if (!t.live || t.owner != &s || !bw::matches(s, generation, p) || !binds(t.identity, p) || !p.remote ||
        p.status != bw::publication::prepared) return collective_result(false);
    const int epoch = t.identity.epoch;
    if (epoch <= 0 || epoch > tx.last_epoch) return collective_result(false);
    const int slot = bulk_inbox_slot(epoch);
    int complete = 0;
    if (!lane) {
        const int ack = l3_atomic_load_acquire<cuda::thread_scope_system>(peer->ack + slot);
        const int state = l3_atomic_load_acquire<cuda::thread_scope_system>(peer->state + slot);
        complete = tx.held[slot] && ack == epoch && state == BULK_SLOT_DONE;
        if (complete) {
            // Slot remains immutable: only this sender may reuse it, and
            // held is not released until this identity has been checked.
            complete = same(peer->identity[slot], t.identity);
        }
    }
    complete = __shfl_sync(mask, complete, 0);
    if (!complete) return collective_result(false);
    __syncwarp(mask);
    if (!lane) { p.status = bw::publication::published; tx.held[slot] = false; t.live = false; }
    __syncwarp(mask);
    return collective_result(true);
}

__device__ inline bool claim(channel *local, receiver &rx, int begin, int end, int lane) {
    if (rx.phase != rx_phase::empty || rx.last_epoch < 0 || rx.last_epoch == INT_MAX) return collective_result(false);
    const int epoch = rx.last_epoch + 1, slot = bulk_inbox_slot(epoch);
    int claimed = 0;
    if (!lane) claimed = bulk_inbox_claim_read(local->state, local->generation, local->epoch, slot, epoch);
    claimed = __shfl_sync(mask, claimed, 0);
    if (!claimed) return collective_result(false);
    const bool visible = bulk_inbox_confirm_read_lane(local->state + slot);
    assert(__all_sync(mask, visible));
    const stamp identity = local->identity[slot];
    bool valid = identity.epoch == epoch && identity.generation > 0 && identity.start >= 0 &&
                 identity.end > identity.start && identity.end - identity.start <= 32 &&
                 identity.count > 0 && identity.count <= identity.end - identity.start;
    if (valid && lane < identity.count) {
        const auto item = local->payload[slot][lane];
        valid = item.vertex >= begin && item.vertex < end && item.distance >= 0 && item.distance < INT_MAX;
        rx.items[lane] = item;
    }
    assert(__all_sync(mask, valid)); // malformed transport after APPLY is fail-stop, never seed fallback
    __syncwarp(mask); // claim guards may read shared receiver metadata
    if (!lane) { rx.identity = identity; rx.phase = rx_phase::copied; }
    __syncwarp(mask);
    return collective_result(true);
}

__device__ inline bool apply(receiver &rx, int *distance, int begin, int lane) {
    if (rx.phase != rx_phase::copied) return collective_result(false);
    if (lane < rx.identity.count) atomicMin(distance + rx.items[lane].vertex - begin, rx.items[lane].distance);
    __syncwarp(mask);
    if (!lane) rx.phase = rx_phase::applied;
    __syncwarp(mask);
    return collective_result(true);
}

// Conservative first version: EVERY received record gets independent L2
// credit, including atomicMin non-winners. No finite-label coverage assumption.
template<class Queue, class Record>
__device__ bool publish_l2(receiver &rx, Queue &q, Record *scratch, int bid, int wid, int lane) {
    if (rx.phase == rx_phase::published || rx.phase == rx_phase::done) return collective_result(true);
    if (rx.phase != rx_phase::applied) return collective_result(false);
    if (lane < rx.identity.count) scratch[lane] = Record(rx.items[lane].vertex + 1, rx.items[lane].distance);
    __syncwarp(mask);
    int count = rx.identity.count;
    const auto result = q.write(scratch, count, bid, wid, lane, nullptr);
    assert(__all_sync(mask, int(result) == 0)); // actual DQ capacity failure remains fatal
    __syncwarp(mask);
    if (!lane) rx.phase = rx_phase::published;
    __syncwarp(mask);
    return collective_result(true);
}

// DONE can be visible before ACK. The sender's normal reuse primitive still
// rejects the slot until ACK; source credit is retained during this interval.
__device__ inline bool mark_done(channel *local, receiver &rx, int lane) {
    if (rx.phase != rx_phase::published) return collective_result(false);
    __threadfence_system();
    __syncwarp(mask);
    if (!lane) {
        l3_atomic_store_release<cuda::thread_scope_system>(local->state + bulk_inbox_slot(rx.identity.epoch), BULK_SLOT_DONE);
        rx.phase = rx_phase::done;
    }
    __syncwarp(mask);
    return collective_result(true);
}

__device__ inline bool acknowledge(channel *local, receiver &rx, int lane) {
    if (rx.phase != rx_phase::done) return collective_result(false);
    const int epoch = rx.identity.epoch;
    __threadfence_system();
    __syncwarp(mask);
    if (!lane) {
        l3_atomic_store_release<cuda::thread_scope_system>(local->ack + bulk_inbox_slot(epoch), epoch);
        // No payload access after ACK: the source may immediately reuse it.
        rx.last_epoch = epoch; rx.phase = rx_phase::empty;
    }
    __syncwarp(mask);
    return collective_result(true);
}
} // namespace l3_batch_remote_commit
