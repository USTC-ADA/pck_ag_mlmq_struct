#pragma once
#include "l3_batch_relay.cuh"
#include "l3_batch_bound.cuh"
#include "l3_batch_search_diag.cuh"

// Packed variant of l3_batch_compact.cuh. Keep the reference implementation
// unchanged. Expansion, insertion order and return order are identical; only
// the touched index storage is compressed from 16 to 10 bits.
namespace l3_batch_compact_packed {
constexpr int table_size = 1024;
constexpr int capacity = 768;
static_assert(capacity >= l3_batch_relay::seed_capacity, "retain all seeds");
static_assert(capacity <= l3_batch_relay::result_capacity, "return fits");
static_assert(table_size <= 65536, "indices fit unsigned short");
constexpr int touched_bits = 10;
constexpr int touched_words = (capacity * touched_bits + 31) / 32;
static_assert(table_size == (1 << touched_bits), "exact index width");
static_assert(capacity * touched_bits % 32 == 0, "no partial final word");

// Positions are uniquely reserved, but adjacent fields share words. Atomic OR
// is required for both fragments. Clear all words before each insertion epoch;
// all writers finish at a full-warp barrier before any reader decodes them.
__device__ __forceinline__ void touched_write(unsigned *words, int position, unsigned index) {
    assert(position >= 0 && position < capacity && index < table_size);
    const unsigned bit = unsigned(position) * touched_bits;
    const unsigned word = bit >> 5, shift = bit & 31;
    atomicOr(words + word, index << shift);
    if (shift > 32 - touched_bits)
        atomicOr(words + word + 1, index >> (32 - shift));
}
__device__ __forceinline__ unsigned touched_read(const unsigned *words, int position) {
    assert(position >= 0 && position < capacity);
    const unsigned bit = unsigned(position) * touched_bits;
    const unsigned word = bit >> 5, shift = bit & 31;
    unsigned index = words[word] >> shift;
    if (shift > 32 - touched_bits)
        index |= words[word + 1] << (32 - shift);
    return index & (table_size - 1);
}
struct workspace {
    int vertices[table_size], distances[table_size], expanded[table_size];
    unsigned queued[table_size / 32];
    unsigned touched[touched_words];
    unsigned short fifo[table_size];
    int count, rows, scans;
    unsigned head, tail;
};
static_assert(sizeof(workspace) == 15444, "packed shared-memory footprint");

// A bounded priority choice, not a global Dijkstra minimum. Each lane owns
// offsets lane+32*k, so swaps cannot race even at a nonaligned/wrapped head.
// Distances are stable between insertion waves. Preserve the entire pending
// multiset, including when the following complete-wave capacity guard stops.
__device__ __forceinline__ int select_front(workspace *work,unsigned head,
    unsigned pending,int lane) {
    assert(unsigned(lane)<pending && pending<=table_size);
    const unsigned front=(head+lane)&(table_size-1);
    const unsigned original=work->fifo[front];
    unsigned best=original,position=front;
    int distance=work->distances[best];
    for(unsigned offset=unsigned(lane)+32;offset<pending;offset+=32) {
        const unsigned candidate_position=(head+offset)&(table_size-1);
        const unsigned candidate=work->fifo[candidate_position];
        if(work->distances[candidate]<distance) {
            best=candidate;position=candidate_position;distance=work->distances[candidate];
        }
    }
    work->fifo[position]=static_cast<unsigned short>(original);
    work->fifo[front]=static_cast<unsigned short>(best);
    return int(best);
}

// Insertion waves and dequeue waves are separated by full-warp barriers.
// This is NOT an independently concurrent multi-warp queue: tail reservation
// alone does not publish fifo payload. Every lane finishes insertion before
// any lane can consume the next wave. Scratch belongs to one claimed warp.
__device__ __forceinline__ void insert(workspace *work, int vertex, int distance,
                                      l3_batch_relay::graph_view graph) {
    unsigned index = (unsigned(vertex) * 2654435761u) & (table_size - 1);
    for (int probe = 0; probe < table_size; ++probe) {
        const int prior = atomicCAS(work->vertices + index, -1, vertex);
        if (prior == -1 || prior == vertex) {
            if (prior == -1) {
                const int position = atomicAdd(&work->count, 1);
                assert(position < capacity);
                touched_write(work->touched, position, index);
            }
            const int old = atomicMin(work->distances + index, distance);
            if (distance < old && vertex >= graph.begin && vertex - graph.begin < graph.vertices) {
                const unsigned bit = 1u << (index % 32);
                if (!(atomicOr(work->queued + index / 32, bit) & bit)) {
                    const unsigned ticket = atomicAdd(&work->tail, 1u);
                    // At most one pending entry per distinct journal slot.
                    assert(ticket - work->head < table_size);
                    work->fifo[ticket & (table_size - 1)] = static_cast<unsigned short>(index);
                }
            }
            return;
        }
        index = (index + 1) & (table_size - 1);
    }
    assert(false);
}

template<bool Track = false, bool Search = false, bool Select = false>
__device__ __forceinline__ void expand_payload(l3_batch_relay::slot *slot,
    l3_batch_relay::graph_view graph, workspace *work, int *certificates,
    int row_budget, int lane, l3_batch_bound::view bound = {},
    l3_batch_bound::counters *observations = nullptr,
    l3_batch_search_diag::counters *search = nullptr) {
    namespace relay = l3_batch_relay;
    l3_batch_bound::counters count_bound{};
    for (int index = lane; index < table_size; index += 32) {
        work->vertices[index] = -1;
        work->distances[index] = work->expanded[index] = INT_MAX;
    }
    work->queued[lane] = 0;
    for (int i = lane; i < touched_words; i += 32) work->touched[i] = 0;
    if (!lane) { work->count = work->rows = work->scans = 0; work->head = work->tail = 0; }
    __syncwarp(relay::mask);
    const int seeds = slot->seeds;
    bool valid = seeds > 0 && seeds <= relay::seed_capacity && row_budget >= 0;
    if (valid) for (int i = lane; i < seeds; i += 32) {
        const auto seed = slot->input[i];
        valid &= seed.vertex >= graph.begin && seed.vertex - graph.begin < graph.vertices && seed.distance >= 0;
    }
    int failure = __ballot_sync(relay::mask, valid) == relay::mask ? relay::ok : relay::bad_seed;
    if (failure == relay::ok) for (int i = lane; i < seeds; i += 32) {
        const auto seed = slot->input[i];
        insert(work, seed.vertex, seed.distance, graph);
    }
    __syncwarp(relay::mask);
    bool capacity_stop=false;
    while (failure == relay::ok && work->rows < row_budget && work->head != work->tail) {
        const unsigned head = work->head;
        const int take = min(min(32u, work->tail - head), unsigned(row_budget - work->rows));
        int index = -1, snapshot = INT_MAX, first = 0, end = 0;
        bool expand = false;
        if (lane < take) {
            index = Select?select_front(work,head,work->tail-head,lane):
                work->fifo[(head + lane) & (table_size - 1)];
            snapshot = work->distances[index];
            expand = snapshot < work->expanded[index];
            if (expand) {
                const int local = work->vertices[index] - graph.begin;
                assert(local >= 0 && local < graph.vertices);
                first = graph.rows[local]; end = graph.rows[local + 1];
            }
        }
        if (__ballot_sync(relay::mask, first < 0 || end < first)) { failure = relay::bad_seed; break; }
        unsigned long long additions = static_cast<unsigned long long>(end - first);
        for (int offset = 16; offset; offset >>= 1) additions += __shfl_down_sync(relay::mask, additions, offset);
        additions = __shfl_sync(relay::mask, additions, 0);
        // Complete-wave reservation before any key/certificate mutation.
        // On capacity stop, ALL labels and remaining debts are still returned.
        if (additions > static_cast<unsigned long long>(capacity - work->count)) {capacity_stop=true;break;}
        const int rows = __popc(__ballot_sync(relay::mask, expand));
        if (lane < take) atomicAnd(work->queued + index / 32, ~(1u << (index % 32)));
        // Finish every snapshot and queued-bit clear before successors can
        // improve a currently executing slot and re-enqueue that slot.
        __syncwarp(relay::mask);
        if (!lane) work->head = head + take;
        __syncwarp(relay::mask);
        bool negative = false;
        for (int edge = first; edge < end; ++edge) {
            const int weight = graph.weights[edge];
            negative |= weight < 0;
            if (weight >= 0 && snapshot < INT_MAX - weight) {
                const int vertex = graph.columns[edge], candidate = snapshot + weight;
                if (!l3_batch_bound::skip<Track>(bound, vertex, candidate, graph.begin, graph.vertices, count_bound))
                    insert(work, vertex, candidate, graph);
            }
        }
        __syncwarp(relay::mask);
        if (__ballot_sync(relay::mask, negative)) { failure = relay::bad_weight; break; }
        if (expand) work->expanded[index] = min(work->expanded[index], snapshot);
        if (!lane) { work->rows += rows; ++work->scans; }
        __syncwarp(relay::mask);
    }
    const int count = failure == relay::ok ? work->count : 0;
    unsigned certified=0;
    for (int i = lane; i < count; i += 32) {
        const int index = touched_read(work->touched, i);
        slot->output[i] = {work->vertices[index], work->distances[index]};
        certificates[i] = work->expanded[index];
        if(Search) certified+=work->expanded[index]<INT_MAX;
    }
    if (!lane) { slot->results = count; slot->result_status = failure; }
    __syncwarp(relay::mask);
    if (Track) l3_batch_bound::accumulate(count_bound, observations, lane);
    if(Search) {
        const int stop=failure!=relay::ok?3:capacity_stop?0:work->head==work->tail?1:2;
        l3_batch_search_diag::record(search,lane,seeds,work->rows,certified,count,
            work->tail-work->head,stop);
    }
}

template<bool Track = false, bool Search = false, bool Select = false>
__device__ __forceinline__ void execute(l3_batch_relay::slot *slot,
    l3_batch_relay::word token, l3_batch_relay::graph_view graph,
    workspace *work, int *certificates, int budget, int lane,
    l3_batch_bound::view bound = {}, l3_batch_bound::counters *observations = nullptr,
    l3_batch_search_diag::counters *search = nullptr) {
    namespace relay = l3_batch_relay;
    assert(relay::load(slot) == token && relay::state(token) == relay::active);
    expand_payload<Track,Search,Select>(slot, graph, work, certificates, budget, lane, bound, observations,search);
    // Same two-pass owner contract as the old workset. This journal never
    // authorizes dropping original credit before ALL outputs/debts are durable.
    relay::publish_exclusive(slot, relay::encode(relay::generation(token), relay::returned), lane);
}
} // namespace l3_batch_compact_packed
