#pragma once
#include "l3_batch_peer_commit.cuh"
#include "l3_batch_compact_packed.cuh"

// Same packet and publication lifetime as the reference producer. Only the
// helper-private workspace and executor change; owner receipt logic is shared.
namespace l3_batch_peer_packed {
template<bool Track = false, bool Search = false, bool Select = false>
__device__ void execute_claimed(l3_batch_peer_commit::packet *p,
    l3_batch_relay::word token, l3_batch_relay::graph_view graph,
    l3_batch_compact_packed::workspace *scratch, int lane,
    l3_batch_bound::view bound = {}, l3_batch_bound::counters *observations = nullptr,
    l3_batch_search_diag::counters *search = nullptr) {
    namespace relay = l3_batch_relay;
    const auto observed = relay::load(&p->channel);
    assert(__all_sync(relay::mask, observed == token && relay::state(token) == relay::active));
    l3_batch_compact_packed::execute<Track,Search,Select>(&p->channel, token, graph, scratch,
                                    p->certificates, p->budget, lane, bound, observations,search);
    // No payload access after RETURNED publication.
}
}
