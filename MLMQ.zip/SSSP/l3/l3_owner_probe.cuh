#pragma once
#include "l3_batch_compact.cuh"

// Diagnostic only. Does NOT write authoritative labels, last_processed, queues
// or credits. Executes locally on the sampled donor warp, not on a peer GPU.
namespace l3_owner_probe {
constexpr int row_budget = 64;
struct record {
    int vertex, distance, certificate;
    int owner_before, processed, owner_after;
};
struct sample {
    int done, seeds, status, count, rows, waves, epoch_end;
    unsigned long long cycles;
    record records[l3_batch_compact::capacity];
};
struct scratch {
    l3_batch_relay::slot channel;
    l3_batch_compact::workspace work;
    int certificates[l3_batch_compact::capacity];
};

// All 32 lanes participate; input seeds have already been frozen by caller.
// node_data/last_processed use the solver's ONE-based local layout. graph and
// journal use ZERO-based global IDs. Do not treat processed as completed: the
// ordinary worker may write it before all CSR effects have been published.
__device__ __noinline__ void observe(scratch *storage, sample *out,
    l3_batch_relay::graph_view graph, const int *node_data,
    const int *last_processed, int lane) {
    const unsigned long long start = clock64();
    l3_batch_compact::expand_payload(&storage->channel, graph, &storage->work,
                                    storage->certificates, row_budget, lane);
    const int count = storage->channel.results;
    for (int i = lane; i < count; i += 32) {
        const auto item = storage->channel.output[i];
        record row{item.vertex, item.distance, storage->certificates[i], -1, -1, -1};
        const int local = item.vertex - graph.begin;
        if (local >= 0 && local < graph.vertices) {
            // Separate volatile observations; not an atomic/coherent tuple.
            row.owner_before = reinterpret_cast<const volatile int *>(node_data)[local + 1];
            row.processed = reinterpret_cast<const volatile int *>(last_processed)[local + 1];
            row.owner_after = reinterpret_cast<const volatile int *>(node_data)[local + 1];
        }
        out->records[i] = row;
    }
    __syncwarp(l3_batch_relay::mask);
    if (!lane) {
        out->seeds = storage->channel.seeds;
        out->status = storage->channel.result_status;
        out->count = count;
        out->rows = storage->work.rows;
        out->waves = storage->work.scans;
        out->cycles = clock64() - start;
        out->done = 1;
    }
    __syncwarp(l3_batch_relay::mask);
}
} // namespace l3_owner_probe
