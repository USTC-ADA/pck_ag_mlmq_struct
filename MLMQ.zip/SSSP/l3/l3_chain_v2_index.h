#pragma once

#include "l3_chain_partition.h"
#include <cstddef>
#include <cstdint>
#include <stdexcept>
#include <vector>

// Dense segment IDs for versioned Chain 2.0 state.  The old strict-chain
// index remains the topology authority; this view does not alter the CSR or
// reuse its route encoding.  Route high32 = segment+1, low32 = entry offset.
struct l3_chain_v2_index
{
    std::vector<uint64_t> route;
    std::vector<int> bases;

    void build(const l3_chain_partition_index &strict, int begin, int end)
    {
        if (begin >= end ||
            strict.route.size() != static_cast<size_t>(end - begin + 1))
            throw std::runtime_error("Chain 2.0 index dimensions");
        route.assign(strict.route.size(), 0);
        bases.clear();
        int base = 0;
        int interiors = 0;
        while (base < static_cast<int>(strict.nodes.size()))
        {
            const int length = strict.nodes[base].length;
            if (length < 4 ||
                length > static_cast<int>(strict.nodes.size()) - base)
                throw std::runtime_error("Chain 2.0 segment length");
            if (bases.size() >= size_t(1u << 30))
                throw std::runtime_error("Chain 2.0 tagged segment range");
            const int segment = static_cast<int>(bases.size());
            bases.push_back(base);
            for (int offset = 1; offset < length - 1; ++offset)
            {
                const int index = base + offset;
                const int local = strict.nodes[index].id - begin;
                if (local <= 0 || local >= static_cast<int>(route.size()) ||
                    route[local] != 0)
                    throw std::runtime_error("Chain 2.0 duplicate interior");
                const uint64_t old_route = strict.route[local];
                if (static_cast<int>(old_route >> 32) != base + 1 ||
                    static_cast<int>(uint32_t(old_route)) != index)
                    throw std::runtime_error("Chain 2.0 strict route mismatch");
                route[local] = (uint64_t(segment + 1) << 32) |
                               uint32_t(offset);
                ++interiors;
            }
            base += length;
        }
        if (base != static_cast<int>(strict.nodes.size()) ||
            bases.size() != static_cast<size_t>(strict.segments) ||
            interiors != strict.interiors)
            throw std::runtime_error("Chain 2.0 index conservation");
        for (size_t local = 0; local < route.size(); ++local)
            if ((strict.route[local] != 0) != (route[local] != 0))
                throw std::runtime_error("Chain 2.0 route coverage mismatch");
    }
};
