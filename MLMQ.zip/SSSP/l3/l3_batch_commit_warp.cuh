#pragma once
#include <cuda_runtime.h>
#include <cassert>
#include "l3_batch_commit.h"

// Isolated full-warp publication adapter. NOT included by the SSSP worker.
// The original state remains lane-0-owned. All 32 lanes must call prepare and
// publish_l2 uniformly, using one exclusive intent and scratch per owner warp.
// Intent is NOT a queue: preparing it does not create independent credit.
namespace l3_batch_commit_warp {
namespace bc = l3_batch_commit;
constexpr unsigned mask = 0xffffffffu;
enum class publication : unsigned { empty, prepared, published };
struct intent {
    std::uint64_t generation;
    bc::phase source_phase;
    int start, end, count;
    bool remote;
    publication status;
    bc::seed items[32]; // zero-based global IDs; immutable until acknowledgement
};

__device__ inline void initialize(intent &p, int lane) {
    if (!lane) { p.status = publication::empty; p.generation = 0; p.count = 0; }
    __syncwarp(mask);
}

template<int N>
__device__ inline bool matches(const bc::state<N> &s, std::uint64_t generation, const intent &p) {
    return s.generation == generation && p.generation == generation &&
           s.stage == p.source_phase && s.cursor == p.start;
}

struct apply_backend {
    int *distance;
    int begin;
    __device__ int local_min(int vertex, int value) { return atomicMin(distance + vertex - begin, value); }
    __device__ bool publish_local(int, int) { assert(false); return false; }
    __device__ bool publish_remote(int, int) { assert(false); return false; }
};

// Caller supplies a zero-based LOCAL distance array (unlike SSSP's one-based
// node_data; adapt explicitly, never pass that array's sentinel as vertex 0).
template<int N>
__device__ bc::result prepare(bc::state<N> &s, std::uint64_t generation,
                            intent &p, int *distance, int lane) {
    if (s.generation != generation || s.stage == bc::phase::free) return bc::result::stale;
    if (p.status != publication::empty)
        return matches(s, generation, p) ? bc::result::blocked : bc::result::stale;
    if (s.stage == bc::phase::finished) return bc::result::complete;
    if (s.stage == bc::phase::borrowed) return bc::result::blocked;
    // Use the already tested scalar transition for APPLY and phase boundaries.
    // Do not advance a publication cursor before a durable receipt exists.
    const bool applying = s.stage == bc::phase::apply;
    const int limit = s.stage == bc::phase::fallback ? s.seed_count : s.count;
    if (applying || s.cursor == limit) {
        if (!lane) {
            apply_backend backend{distance, s.begin};
            if (applying) {
                for (int i = 0; i < 32 && s.stage == bc::phase::apply; ++i)
                    bc::step(s, generation, backend);
            } else bc::step(s, generation, backend);
        }
        __syncwarp(mask);
        return s.stage == bc::phase::finished ? bc::result::complete : bc::result::progress;
    }
    const int index = s.cursor + lane;
    const bool fallback = s.stage == bc::phase::fallback;
    const bool remote = s.stage == bc::phase::remote;
    int vertex = -1, value = INT_MAX;
    bool include = false;
    if (index < limit) {
        if (fallback) { vertex = s.roots[index].vertex; value = s.roots[index].distance; include = true; }
        else {
            const auto record = s.journal[index];
            vertex = record.vertex;
            const bool local = vertex >= s.begin && vertex < s.end;
            include = remote ? !local : local && s.required[index] < record.certificate;
            value = remote ? record.distance : s.required[index];
        }
    }
    const unsigned selected = __ballot_sync(mask, include);
    const unsigned below = lane ? (1u << lane) - 1u : 0u;
    if (include) p.items[__popc(selected & below)] = {vertex, value};
    __syncwarp(mask);
    if (!lane) {
        p.generation = generation;
        p.source_phase = s.stage;
        p.start = s.cursor;
        p.end = min(limit, s.cursor + 32);
        p.count = __popc(selected);
        p.remote = remote;
        // Empty windows have no output to publish, but still require an ack
        // before advancing the immutable cursor interval.
        p.status = p.count ? publication::prepared : publication::published;
    }
    __syncwarp(mask);
    return bc::result::progress;
}

// Queue::write is the actual warp-collective delta queue implementation. Its
// full-capacity path remains fail-stop: this adapter never catches/retries a
// trap and never claims a capacity-reservation precheck is authoritative.
// Record(int id,int distance) explicitly converts zero-based journal IDs into
// the destination queue's ID convention via vertex_bias (normally +1).
template<int N, class Queue, class Record>
__device__ bool publish_l2(const bc::state<N> &s, std::uint64_t generation,
                          intent &p, Queue &queue, Record *scratch,
                          int bid, int wid, int lane, int vertex_bias = 1) {
    if (p.status == publication::empty || !matches(s, generation, p) || p.remote) return false;
    if (p.status == publication::published) return true; // retry after flush, before ack: no second write
    assert(p.count > 0 && p.count <= 32);
    if (lane < p.count) scratch[lane] = Record(p.items[lane].vertex + vertex_bias, p.items[lane].distance);
    __syncwarp(mask);
    int count = p.count;
    const auto status = queue.write(scratch, count, bid, wid, lane, nullptr);
    // Actual core enum: WRITE_SUCCESS == 0. Keep this header independent of
    // queue includes; a non-success result is fail-stop, not a partial ack.
    assert(__all_sync(mask, int(status) == 0));
    __syncwarp(mask);
    if (!lane) p.status = publication::published;
    __syncwarp(mask);
    return true;
}

// Lane 0 only, then callers synchronize the warp before reading state again.
// This is a DEVICE-local receipt, not a cross-GPU system-scope ACK.
template<int N>
__device__ bool acknowledge(bc::state<N> &s, std::uint64_t generation, intent &p) {
    if (p.status != publication::published || !matches(s, generation, p)) return false;
    if (p.remote) s.remote_published += p.count;
    else s.local_published += p.count;
    s.cursor = p.end;
    p.status = publication::empty;
    return true;
}
} // namespace l3_batch_commit_warp
