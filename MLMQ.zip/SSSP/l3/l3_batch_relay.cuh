#pragma once
#include <cuda_runtime.h>
#include <cuda/atomic>
#include <cassert>
#include <climits>

// Experimental transport primitive, NOT connected to solver termination.
// A slot's owner retains the original responsibility until every returned
// relaxation has been durably committed. FREE must never mean "drop work".
namespace l3_batch_relay {
constexpr unsigned mask = 0xffffffffu;
constexpr int seed_capacity = 512;
constexpr int result_capacity = 4096;
using word = unsigned long long;
enum phase : word { free = 0, filling, ready, active, returned, committing };
enum status : int { ok = 0, bad_seed = 1, full = 2, bad_weight = 3 };
struct item { int vertex, distance; }; // zero-based GLOBAL vertex IDs
struct alignas(128) slot {
    word control;
    int seeds, results, result_status;
    alignas(128) item input[seed_capacity];
    alignas(128) item output[result_capacity];
};
struct graph_view {
    const int *rows, *columns, *weights;
    int begin, vertices;
};
__host__ __device__ constexpr word encode(word generation, phase state) {
    return (generation << 3) | word(state);
}
__host__ __device__ constexpr phase state(word value) { return phase(value & 7); }
__host__ __device__ constexpr word generation(word value) { return value >> 3; }
__device__ __forceinline__ word load(slot *s) {
    return cuda::atomic_ref<word, cuda::thread_scope_system>(s->control)
        .load(cuda::memory_order_acquire);
}
__device__ __forceinline__ bool move(slot *s, word expected, phase to) {
    const word next = encode(generation(expected), to);
    return cuda::atomic_ref<word, cuda::thread_scope_system>(s->control)
        .compare_exchange_strong(expected, next, cuda::memory_order_acq_rel,
                                  cuda::memory_order_acquire);
}

// All lanes call publication after writing their disjoint payload fields.
// The leader is the last accessor of this lifetime's payload. After RETURNED,
// helper lanes must not touch the slot payload: owner can already recycle it.
__device__ __forceinline__ void publish(slot *s, word token, phase to, int lane) {
    __threadfence_system();
    __syncwarp(mask);
    if (!lane) {
        const bool changed = move(s, token, to);
        assert(changed);
    }
    __syncwarp(mask);
}
// Reduced SPSC publication: valid ONLY with one producer/committer per slot.
// READY is owner-published; after the versioned claim, RETURNED is published
// by that unique helper. Producer can fill generation g+1 while control still
// says RETURNED(g): no helper may touch that payload again. A stale READY(g)
// claimant cannot claim READY(g+1). Original task responsibility is unchanged.
__device__ __forceinline__ void publish_exclusive(slot *s, word value, int lane) {
    __threadfence_system();
    __syncwarp(mask);
    if (!lane)
        cuda::atomic_ref<word, cuda::thread_scope_system>(s->control)
            .store(value, cuda::memory_order_release);
    __syncwarp(mask);
}
__device__ __forceinline__ void recycle(slot *s, word token, int lane) {
    __threadfence_system();
    __syncwarp(mask);
    if (!lane) {
        assert(state(token) == committing && generation(token) < (ULLONG_MAX >> 3));
        word expected = token;
        const bool changed = cuda::atomic_ref<word, cuda::thread_scope_system>(s->control)
            .compare_exchange_strong(expected, encode(generation(token) + 1, free),
                cuda::memory_order_acq_rel, cuda::memory_order_acquire);
        assert(changed);
    }
    __syncwarp(mask);
}

// One helper warp, bounded complete one-hop expansion. Neither authoritative
// distances nor queues are changed. On fallback, owner must replay ALL seeds;
// any partially written output is invalid. Signed distance overflow saturates.
// CSR may be owner-resident (P2P reads) or a static helper-local replica.
__device__ __forceinline__ void expand_payload(slot *s, graph_view graph, int lane) {
    const int count = s->seeds;
    int cursor = 0;
    int failure = (count < 1 || count > seed_capacity) ? bad_seed : ok;
    for (int base = 0; base < count && failure == ok; base += 32) {
        int first = 0, degree = 0, distance = INT_MAX;
        bool invalid = false;
        if (base + lane < count) {
            const item seed = s->input[base + lane];
            const int local = seed.vertex - graph.begin;
            invalid = local < 0 || local >= graph.vertices || seed.distance < 0;
            if (!invalid) {
                first = graph.rows[local];
                degree = graph.rows[local + 1] - first;
                distance = seed.distance;
                invalid = first < 0 || degree < 0 || degree > result_capacity;
            }
        }
        if (__ballot_sync(mask, invalid)) { failure = bad_seed; break; }
        int inclusive = degree;
        for (int offset = 1; offset < 32; offset <<= 1) {
            const int previous = __shfl_up_sync(mask, inclusive, offset);
            if (lane >= offset) inclusive += previous;
        }
        const int total = __shfl_sync(mask, inclusive, 31);
        if (total > result_capacity - cursor) { failure = full; break; }
        const int output_base = cursor + inclusive - degree;
        bool negative = false;
        for (int edge = 0; edge < degree; ++edge) {
            const int weight = graph.weights[first + edge];
            negative |= weight < 0;
            const int candidate = weight < 0 || distance > INT_MAX - weight ?
                INT_MAX : distance + weight;
            s->output[output_base + edge] = {graph.columns[first + edge], candidate};
        }
        if (__ballot_sync(mask, negative)) { failure = bad_weight; break; }
        cursor += total;
    }
    if (!lane) {
        s->results = failure == ok ? cursor : 0;
        s->result_status = failure;
    }
    __syncwarp(mask);
}
__device__ __forceinline__ void execute(slot *s, word token, graph_view graph, int lane,
                                      bool exclusive_return = false) {
    const word acquired = load(s); // acquire in EVERY payload-reading lane
    assert(acquired == token && state(token) == active);
    expand_payload(s, graph, lane);
    if (exclusive_return)
        publish_exclusive(s, encode(generation(token), returned), lane);
    else
        publish(s, token, returned, lane);
}
} // namespace l3_batch_relay
