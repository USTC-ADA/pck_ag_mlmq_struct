#pragma once
#include "l3_sync.cuh"
#include <cassert>
namespace l3_batch_search_diag {
struct counters {
    unsigned long long loans,seeds,rows,certified,records,remaining;
    unsigned long long capacity,empty,budget,failure;
};
// One helper warp owns one slot. Capture private state BEFORE RETURNED.
// Host reads only after both devices synchronize.
__device__ __forceinline__ void record(counters *out,int lane,int seeds,int rows,
    unsigned certified,int records,unsigned remaining,int stop) {
    for(int shift=16;shift;shift>>=1) certified+=__shfl_down_sync(0xffffffffu,certified,shift);
    if(!lane) {
        assert(out && stop>=0 && stop<4);
        ++out->loans;out->seeds+=seeds;out->rows+=rows;out->certified+=certified;
        out->records+=records;out->remaining+=remaining;
        out->capacity+=stop==0;out->empty+=stop==1;out->budget+=stop==2;out->failure+=stop==3;
    }
}
}
