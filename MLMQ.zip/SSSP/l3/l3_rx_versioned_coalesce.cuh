#pragma once

#if (L3_RX_VERSIONED_COALESCE == true)

// The low two bits encode ownership; the remaining 62 bits are a monotonic
// per-query version.  Every successful authoritative RX decrease increments
// the version before the inbox can be ACKed.
static constexpr unsigned long long L3_RX_RESP_STATE_MASK = 3ull;
static constexpr unsigned long long L3_RX_RESP_VERSION_STEP = 4ull;
static constexpr unsigned long long L3_RX_RESP_IDLE = 0ull;
static constexpr unsigned long long L3_RX_RESP_QUEUED = 1ull;
static constexpr unsigned long long L3_RX_RESP_ACTIVE = 2ull;

struct l3_rx_coalesce_metrics
{
    unsigned long long offers;
    unsigned long long tokens_created;
    unsigned long long queued_updates;
    unsigned long long active_updates;
    unsigned long long unindexed;
    unsigned long long claims;
    unsigned long long claim_misses;
    unsigned long long completed_idle;
    unsigned long long requeues;
    unsigned long long requeue_tokens;
    unsigned long long no_work_claims;
    unsigned long long state_errors;
};

#if (L3_RX_VERSIONED_COALESCE_DIAG == true)
__device__ l3_rx_coalesce_metrics g_l3_rx_coalesce_metrics;
#endif

__device__ __forceinline__ int l3_rx_coalesce_find_slot(
    const int *vertices, int count, int local_one_based)
{
    int first = 0;
    int last = count;
    while (first < last)
    {
        const int middle = first + (last - first) / 2;
        const int value = vertices[middle];
        if (value < local_one_based)
            first = middle + 1;
        else
            last = middle;
    }
    return first < count && vertices[first] == local_one_based ? first : -1;
}

// Returns true only when the caller must create the unique durable token.
// An unindexed vertex deliberately falls back to the ordinary token path.
__device__ __forceinline__ bool l3_rx_coalesce_offer(
    const int *vertices, unsigned long long *states, int count,
    int local_one_based, int &slot)
{
    slot = l3_rx_coalesce_find_slot(vertices, count, local_one_based);
#if (L3_RX_VERSIONED_COALESCE_DIAG == true)
    atomicAdd(&g_l3_rx_coalesce_metrics.offers, 1ull);
#endif
    if (slot < 0)
    {
#if (L3_RX_VERSIONED_COALESCE_DIAG == true)
        atomicAdd(&g_l3_rx_coalesce_metrics.unindexed, 1ull);
#endif
        return true;
    }

    cuda::atomic_ref<unsigned long long, cuda::thread_scope_device> state(
        states[slot]);
    unsigned long long old = state.load(cuda::memory_order_acquire);
    while (true)
    {
        const unsigned long long old_state = old & L3_RX_RESP_STATE_MASK;
        const unsigned long long next_state =
            old_state == L3_RX_RESP_IDLE ? L3_RX_RESP_QUEUED : old_state;
        const unsigned long long desired =
            ((old & ~L3_RX_RESP_STATE_MASK) +
             L3_RX_RESP_VERSION_STEP) | next_state;
        if (state.compare_exchange_weak(
                old, desired, cuda::memory_order_acq_rel,
                cuda::memory_order_acquire))
        {
#if (L3_RX_VERSIONED_COALESCE_DIAG == true)
            if (old_state == L3_RX_RESP_IDLE)
                atomicAdd(&g_l3_rx_coalesce_metrics.tokens_created, 1ull);
            else if (old_state == L3_RX_RESP_QUEUED)
                atomicAdd(&g_l3_rx_coalesce_metrics.queued_updates, 1ull);
            else if (old_state == L3_RX_RESP_ACTIVE)
                atomicAdd(&g_l3_rx_coalesce_metrics.active_updates, 1ull);
            else
                atomicAdd(&g_l3_rx_coalesce_metrics.state_errors, 1ull);
#endif
            // Unknown state is impossible under the protocol.  Preserve work
            // if corruption is observed instead of suppressing a token.
            if (old_state > L3_RX_RESP_ACTIVE)
                slot = -1;
            return old_state == L3_RX_RESP_IDLE || slot < 0;
        }
    }
}

__device__ __forceinline__ bool l3_rx_coalesce_claim(
    unsigned long long *states, int slot,
    unsigned long long &claimed_version)
{
    cuda::atomic_ref<unsigned long long, cuda::thread_scope_device> state(
        states[slot]);
    unsigned long long old = state.load(cuda::memory_order_acquire);
    while ((old & L3_RX_RESP_STATE_MASK) == L3_RX_RESP_QUEUED)
    {
        const unsigned long long desired =
            (old & ~L3_RX_RESP_STATE_MASK) | L3_RX_RESP_ACTIVE;
        if (state.compare_exchange_weak(
                old, desired, cuda::memory_order_acq_rel,
                cuda::memory_order_acquire))
        {
            claimed_version = old & ~L3_RX_RESP_STATE_MASK;
#if (L3_RX_VERSIONED_COALESCE_DIAG == true)
            atomicAdd(&g_l3_rx_coalesce_metrics.claims, 1ull);
#endif
            return true;
        }
    }
#if (L3_RX_VERSIONED_COALESCE_DIAG == true)
    atomicAdd(&g_l3_rx_coalesce_metrics.claim_misses, 1ull);
#endif
    return false;
}

// Must be called only after every relaxation and output queue write belonging
// to the claimed snapshot is durable.  Returns true when a newer RX version
// requires exactly one replacement token.
__device__ __forceinline__ bool l3_rx_coalesce_commit(
    unsigned long long *states, int slot,
    unsigned long long claimed_version)
{
    __threadfence();
    cuda::atomic_ref<unsigned long long, cuda::thread_scope_device> state(
        states[slot]);
    unsigned long long old = state.load(cuda::memory_order_acquire);
    while (true)
    {
        if ((old & L3_RX_RESP_STATE_MASK) != L3_RX_RESP_ACTIVE)
        {
#if (L3_RX_VERSIONED_COALESCE_DIAG == true)
            atomicAdd(&g_l3_rx_coalesce_metrics.state_errors, 1ull);
#endif
            // A missing owner must not silently suppress pending work.
            return true;
        }
        const bool changed =
            (old & ~L3_RX_RESP_STATE_MASK) != claimed_version;
        const unsigned long long desired =
            (old & ~L3_RX_RESP_STATE_MASK) |
            (changed ? L3_RX_RESP_QUEUED : L3_RX_RESP_IDLE);
        if (state.compare_exchange_weak(
                old, desired, cuda::memory_order_acq_rel,
                cuda::memory_order_acquire))
        {
#if (L3_RX_VERSIONED_COALESCE_DIAG == true)
            if (changed)
                atomicAdd(&g_l3_rx_coalesce_metrics.requeues, 1ull);
            else
                atomicAdd(&g_l3_rx_coalesce_metrics.completed_idle, 1ull);
#endif
            return changed;
        }
    }
}

__device__ __forceinline__ void l3_rx_coalesce_note_no_work()
{
#if (L3_RX_VERSIONED_COALESCE_DIAG == true)
    atomicAdd(&g_l3_rx_coalesce_metrics.no_work_claims, 1ull);
#endif
}

__device__ __forceinline__ void l3_rx_coalesce_note_requeue_token()
{
#if (L3_RX_VERSIONED_COALESCE_DIAG == true)
    atomicAdd(&g_l3_rx_coalesce_metrics.requeue_tokens, 1ull);
#endif
}

#endif
