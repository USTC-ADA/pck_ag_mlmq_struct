#pragma once

#if (L3_UPGRADE_DIAG == true)

// Stage-1 observation only.  None of these words participates in distance,
// queue, ACK, recovery, or termination decisions.
static constexpr int L3_UPGRADE_DIAG_BINS = 32;

struct l3_upgrade_diag_metrics
{
    unsigned long long rx_winners;
    unsigned long long before_first_expand;
    unsigned long long before_first_vertices;
    unsigned long long replacements_before_first;
    unsigned long long after_first_expand;
    unsigned long long bucket_behind;
    unsigned long long bucket_in_window;
    unsigned long long bucket_ahead;
    unsigned long long expansions;
    unsigned long long expansion_edges;
    unsigned long long unique_sources;
    unsigned long long repeated_sources;
    unsigned long long repeated_edges;
    unsigned long long worker_filtered;
    unsigned long long worker_filtered_edges;
    unsigned long long worker_invalid;
    unsigned long long lag_histogram[L3_UPGRADE_DIAG_BINS];
    unsigned long long delay_samples;
    unsigned long long delay_sum_ns;
    unsigned long long delay_max_ns;
    unsigned long long delay_histogram[L3_UPGRADE_DIAG_BINS];
};

__device__ l3_upgrade_diag_metrics g_l3_upgrade_diag;
__device__ unsigned *g_l3_upgrade_seen_before_expand = nullptr;
__device__ unsigned *g_l3_upgrade_expansion_started = nullptr;
__device__ unsigned long long *g_l3_upgrade_first_rx_ns = nullptr;

static unsigned *l3_upgrade_seen_storage[MAX_GPU] = {};
static unsigned *l3_upgrade_started_storage[MAX_GPU] = {};
static unsigned long long *l3_upgrade_clock_storage[MAX_GPU] = {};
static size_t l3_upgrade_local_vertices[MAX_GPU] = {};

static inline cudaError_t l3_upgrade_diag_allocate(int gpu, size_t local_vertices)
{
    cudaError_t status = cudaSetDevice(gpu);
    if (status != cudaSuccess) return status;
    const size_t words = (local_vertices + 32) / 32;
    status = cudaMalloc(&l3_upgrade_seen_storage[gpu], words * sizeof(unsigned));
    if (status != cudaSuccess) return status;
    status = cudaMalloc(&l3_upgrade_started_storage[gpu],
                        words * sizeof(unsigned));
    if (status != cudaSuccess)
    {
        cudaFree(l3_upgrade_seen_storage[gpu]);
        l3_upgrade_seen_storage[gpu] = nullptr;
        return status;
    }
    status = cudaMalloc(&l3_upgrade_clock_storage[gpu],
                        (local_vertices + 1) * sizeof(unsigned long long));
    if (status != cudaSuccess)
    {
        cudaFree(l3_upgrade_seen_storage[gpu]);
        cudaFree(l3_upgrade_started_storage[gpu]);
        l3_upgrade_seen_storage[gpu] = nullptr;
        l3_upgrade_started_storage[gpu] = nullptr;
        return status;
    }
    l3_upgrade_local_vertices[gpu] = local_vertices;
    status = cudaMemcpyToSymbol(g_l3_upgrade_seen_before_expand,
                                &l3_upgrade_seen_storage[gpu],
                                sizeof(unsigned *));
    if (status != cudaSuccess) return status;
    status = cudaMemcpyToSymbol(g_l3_upgrade_expansion_started,
                                &l3_upgrade_started_storage[gpu],
                                sizeof(unsigned *));
    if (status != cudaSuccess) return status;
    return cudaMemcpyToSymbol(g_l3_upgrade_first_rx_ns,
                              &l3_upgrade_clock_storage[gpu],
                              sizeof(unsigned long long *));
}

static inline cudaError_t l3_upgrade_diag_reset(int gpu)
{
    cudaError_t status = cudaSetDevice(gpu);
    if (status != cudaSuccess) return status;
    const size_t local_vertices = l3_upgrade_local_vertices[gpu];
    const size_t words = (local_vertices + 32) / 32;
    status = cudaMemset(l3_upgrade_seen_storage[gpu], 0,
                        words * sizeof(unsigned));
    if (status != cudaSuccess) return status;
    status = cudaMemset(l3_upgrade_started_storage[gpu], 0,
                        words * sizeof(unsigned));
    if (status != cudaSuccess) return status;
    status = cudaMemset(l3_upgrade_clock_storage[gpu], 0,
                        (local_vertices + 1) * sizeof(unsigned long long));
    if (status != cudaSuccess) return status;
    l3_upgrade_diag_metrics zero = {};
    return cudaMemcpyToSymbol(g_l3_upgrade_diag, &zero, sizeof(zero));
}

static inline void l3_upgrade_diag_release(int gpu)
{
    cudaSetDevice(gpu);
    unsigned *no_seen = nullptr;
    unsigned *no_started = nullptr;
    unsigned long long *no_clock = nullptr;
    cudaMemcpyToSymbol(g_l3_upgrade_seen_before_expand, &no_seen,
                       sizeof(no_seen));
    cudaMemcpyToSymbol(g_l3_upgrade_expansion_started, &no_started,
                       sizeof(no_started));
    cudaMemcpyToSymbol(g_l3_upgrade_first_rx_ns, &no_clock,
                       sizeof(no_clock));
    if (l3_upgrade_seen_storage[gpu])
        cudaFree(l3_upgrade_seen_storage[gpu]);
    if (l3_upgrade_started_storage[gpu])
        cudaFree(l3_upgrade_started_storage[gpu]);
    if (l3_upgrade_clock_storage[gpu])
        cudaFree(l3_upgrade_clock_storage[gpu]);
    l3_upgrade_seen_storage[gpu] = nullptr;
    l3_upgrade_started_storage[gpu] = nullptr;
    l3_upgrade_clock_storage[gpu] = nullptr;
    l3_upgrade_local_vertices[gpu] = 0;
}

__device__ __forceinline__ unsigned long long l3_upgrade_globaltimer_ns()
{
    unsigned long long value;
    asm volatile("mov.u64 %0, %%globaltimer;" : "=l"(value));
    return value;
}

__device__ __forceinline__ int l3_upgrade_log2_bin(unsigned long long value)
{
    if (value <= 1) return 0;
    int result = 63 - __clzll(value);
    return result < L3_UPGRADE_DIAG_BINS ? result : L3_UPGRADE_DIAG_BINS - 1;
}

__device__ __forceinline__ void l3_upgrade_record_rx_winner(
    int local, VALUE_TYPE value, long long base, int delta, int buckets)
{
    atomicAdd(&g_l3_upgrade_diag.rx_winners, 1ull);
    // This atomic read and the worker's atomicOr below define whether the RX
    // winner precedes the first accepted expansion.  A winner that loses the
    // subsequent timestamp race remains explicitly visible as unresolved.
    const unsigned bit = 1u << (local & 31);
    const unsigned started = atomicAdd(
        &g_l3_upgrade_expansion_started[local >> 5], 0u);
    if ((started & bit) == 0)
    {
        atomicAdd(&g_l3_upgrade_diag.before_first_expand, 1ull);
        const unsigned prior = atomicOr(
            &g_l3_upgrade_seen_before_expand[local >> 5], bit);
        if ((prior & bit) == 0)
        {
            atomicAdd(&g_l3_upgrade_diag.before_first_vertices, 1ull);
            atomicCAS(&g_l3_upgrade_first_rx_ns[local], 0ull,
                      l3_upgrade_globaltimer_ns());
        }
        else
        {
            atomicAdd(&g_l3_upgrade_diag.replacements_before_first, 1ull);
        }
    }
    else
    {
        atomicAdd(&g_l3_upgrade_diag.after_first_expand, 1ull);
    }

    const long long width = static_cast<long long>(delta) * buckets;
    const long long signed_value = static_cast<long long>(value);
    if (signed_value < base)
    {
        atomicAdd(&g_l3_upgrade_diag.bucket_behind, 1ull);
        const unsigned long long lag = static_cast<unsigned long long>(
            (base - signed_value) / (delta > 0 ? delta : 1));
        atomicAdd(&g_l3_upgrade_diag.lag_histogram[l3_upgrade_log2_bin(lag)],
                  1ull);
    }
    else if (signed_value >= base + width)
    {
        atomicAdd(&g_l3_upgrade_diag.bucket_ahead, 1ull);
    }
    else
    {
        atomicAdd(&g_l3_upgrade_diag.bucket_in_window, 1ull);
    }
}

__device__ __forceinline__ void l3_upgrade_record_expansion(
    int local, int edges)
{
    atomicAdd(&g_l3_upgrade_diag.expansions, 1ull);
    atomicAdd(&g_l3_upgrade_diag.expansion_edges,
              static_cast<unsigned long long>(edges));
    const unsigned bit = 1u << (local & 31);
    const unsigned prior = atomicOr(
        &g_l3_upgrade_expansion_started[local >> 5], bit);
    if (prior & bit)
    {
        atomicAdd(&g_l3_upgrade_diag.repeated_sources, 1ull);
        atomicAdd(&g_l3_upgrade_diag.repeated_edges,
                  static_cast<unsigned long long>(edges));
        return;
    }
    atomicAdd(&g_l3_upgrade_diag.unique_sources, 1ull);
    const unsigned long long first = atomicExch(
        &g_l3_upgrade_first_rx_ns[local], 0ull);
    if (!first) return;
    const unsigned long long now = l3_upgrade_globaltimer_ns();
    const unsigned long long delay = now >= first ? now - first : 0;
    atomicAdd(&g_l3_upgrade_diag.delay_samples, 1ull);
    atomicAdd(&g_l3_upgrade_diag.delay_sum_ns, delay);
    atomicMax(&g_l3_upgrade_diag.delay_max_ns, delay);
    atomicAdd(&g_l3_upgrade_diag.delay_histogram[l3_upgrade_log2_bin(delay)],
              1ull);
}

__device__ __forceinline__ void l3_upgrade_record_worker_filter(int edges)
{
    atomicAdd(&g_l3_upgrade_diag.worker_filtered, 1ull);
    atomicAdd(&g_l3_upgrade_diag.worker_filtered_edges,
              static_cast<unsigned long long>(edges));
}

__device__ __forceinline__ void l3_upgrade_record_worker_invalid()
{
    atomicAdd(&g_l3_upgrade_diag.worker_invalid, 1ull);
}

#endif
