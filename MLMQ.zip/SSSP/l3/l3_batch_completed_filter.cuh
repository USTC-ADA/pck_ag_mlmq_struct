#pragma once
#include "l3_sync.cuh"
#include <cuda_runtime.h>
#include <climits>
#include <cstdio>
#ifndef L3_BATCH_COMPLETED_FILTER
#define L3_BATCH_COMPLETED_FILTER false
#endif
#ifndef L3_BATCH_COMPLETED_FILTER_DIAG
#define L3_BATCH_COMPLETED_FILTER_DIAG false
#endif

namespace l3_batch_completed_filter {
#if (L3_BATCH_COMPLETED_FILTER_DIAG == true)
__device__ unsigned long long observations[2];
#endif

// The publisher certifies a FULL original CSR row only after all of its loan's
// outputs are durable. Acquire that certificate before reading the current
// authoritative label; a lower current label must retain its ordinary work.
// A later improvement has its own producer responsibility and is not retired
// here. This predicate never changes last_processed, a queue, or any credit.
__device__ __forceinline__ bool covered(const int *completed, int local,
                                       int *distance) {
    if (!completed) return false;
    const int certificate = cuda::atomic_ref<const int, cuda::thread_scope_device>(
        completed[local]).load(cuda::memory_order_acquire);
    const bool skip = certificate < INT_MAX &&
        l3_atomic_load_relaxed<cuda::thread_scope_system>(distance + local) >= certificate;
#if (L3_BATCH_COMPLETED_FILTER_DIAG == true)
    atomicAdd(observations, 1ull);
    if (skip) atomicAdd(observations + 1, 1ull);
#endif
    return skip;
}

inline cudaError_t reset() {
#if (L3_BATCH_COMPLETED_FILTER_DIAG == true)
    unsigned long long zero[2] = {};
    return cudaMemcpyToSymbol(observations, zero, sizeof(zero));
#else
    return cudaSuccess;
#endif
}
inline cudaError_t report(int gpu) {
    long long checks = -1, skipped = -1; // NOT_MEASURED in performance builds
#if (L3_BATCH_COMPLETED_FILTER_DIAG == true)
    unsigned long long counts[2];
    const auto rc = cudaMemcpyFromSymbol(counts, observations, sizeof(counts));
    if (rc != cudaSuccess) return rc;
    checks = counts[0]; skipped = counts[1];
#endif
    printf("L3_BATCH_COMPLETED_FILTER gpu=%d enabled=%d instrumented=%d checks=%lld skipped=%lld\n",
        gpu, int(L3_BATCH_COMPLETED_FILTER), int(L3_BATCH_COMPLETED_FILTER_DIAG), checks, skipped);
    return cudaSuccess;
}
} // namespace l3_batch_completed_filter
