#pragma once

// Device-scope ownership for one strict-chain segment.  This is a building
// block, not a termination protocol: the caller must publish each returned
// token durably before ACK/releasing the previous queue credit, and must keep
// ACTIVE work counted until every endpoint output is committed.
#include <cuda/atomic>
#include <climits>

constexpr unsigned long long L3_CHAIN_V2_STATE_MASK = 3ull;
constexpr unsigned long long L3_CHAIN_V2_VERSION_STEP = 4ull;
constexpr unsigned long long L3_CHAIN_V2_IDLE = 0ull;
constexpr unsigned long long L3_CHAIN_V2_QUEUED = 1ull;
constexpr unsigned long long L3_CHAIN_V2_ACTIVE = 2ull;

struct l3_chain_v2_segment_state
{
    unsigned long long ownership;
    unsigned long long completed_epoch;
};

enum l3_chain_v2_offer_result
{
    L3_CHAIN_V2_DOMINATED = 0,
    L3_CHAIN_V2_MERGED = 1,
    L3_CHAIN_V2_NEW_TOKEN = 2,
    L3_CHAIN_V2_ERROR = 3,
};

__device__ __forceinline__ l3_chain_v2_offer_result l3_chain_v2_offer(
    int *pending, const int *completed,
    l3_chain_v2_segment_state *segments, int segment, int index, int value)
{
    if (value < 0 || value >= INT_MAX) return L3_CHAIN_V2_ERROR;
    cuda::atomic_ref<int, cuda::thread_scope_device> envelope(
        *const_cast<int *>(completed + index));
    // A completed envelope is safe to consult only because the service
    // publishes it after all corresponding outputs become durable.
    if (value >= envelope.load(cuda::memory_order_acquire))
        return L3_CHAIN_V2_DOMINATED;

    cuda::atomic_ref<int, cuda::thread_scope_device> entry(pending[index]);
    int previous = entry.load(cuda::memory_order_acquire);
    while (value < previous)
    {
        if (entry.compare_exchange_weak(
                previous, value, cuda::memory_order_acq_rel,
                cuda::memory_order_acquire))
            break;
    }
    if (value >= previous) return L3_CHAIN_V2_MERGED;

    cuda::atomic_ref<unsigned long long, cuda::thread_scope_device> owner(
        segments[segment].ownership);
    unsigned long long old = owner.load(cuda::memory_order_acquire);
    while (true)
    {
        const unsigned long long state = old & L3_CHAIN_V2_STATE_MASK;
        if (state > L3_CHAIN_V2_ACTIVE ||
            old > ULLONG_MAX - L3_CHAIN_V2_VERSION_STEP)
            return L3_CHAIN_V2_ERROR;
        const unsigned long long next =
            ((old & ~L3_CHAIN_V2_STATE_MASK) +
             L3_CHAIN_V2_VERSION_STEP) |
            (state == L3_CHAIN_V2_IDLE ? L3_CHAIN_V2_QUEUED : state);
        if (owner.compare_exchange_weak(
                old, next, cuda::memory_order_acq_rel,
                cuda::memory_order_acquire))
            return state == L3_CHAIN_V2_IDLE ?
                L3_CHAIN_V2_NEW_TOKEN : L3_CHAIN_V2_MERGED;
    }
}

__device__ __forceinline__ bool l3_chain_v2_claim(
    l3_chain_v2_segment_state *segments, int segment,
    unsigned long long &claimed_epoch)
{
    cuda::atomic_ref<unsigned long long, cuda::thread_scope_device> owner(
        segments[segment].ownership);
    unsigned long long old = owner.load(cuda::memory_order_acquire);
    while ((old & L3_CHAIN_V2_STATE_MASK) == L3_CHAIN_V2_QUEUED)
    {
        const unsigned long long next =
            (old & ~L3_CHAIN_V2_STATE_MASK) | L3_CHAIN_V2_ACTIVE;
        if (owner.compare_exchange_weak(
                old, next, cuda::memory_order_acq_rel,
                cuda::memory_order_acquire))
        {
            claimed_epoch = old & ~L3_CHAIN_V2_STATE_MASK;
            return true;
        }
    }
    return false;
}

__device__ __forceinline__ int l3_chain_v2_take_pending(
    int *pending, int index)
{
    cuda::atomic_ref<int, cuda::thread_scope_device> entry(pending[index]);
    return entry.exchange(INT_MAX, cuda::memory_order_acq_rel);
}

// Precondition: all distance materialization and endpoint activations for
// this snapshot have been committed to durable queues.  `closed` is the exact
// multi-entry closure; INT_MAX entries do not change the certificate.
__device__ __forceinline__ void l3_chain_v2_complete(
    int *completed, const int *closed, int base, int length,
    l3_chain_v2_segment_state *segments, int segment,
    unsigned long long claimed_epoch)
{
    __threadfence();
    for (int offset = 0; offset < length; ++offset)
    {
        const int value = closed[base + offset];
        if (value == INT_MAX) continue;
        cuda::atomic_ref<int, cuda::thread_scope_device> envelope(
            completed[base + offset]);
        int previous = envelope.load(cuda::memory_order_acquire);
        while (value < previous && !envelope.compare_exchange_weak(
                   previous, value, cuda::memory_order_acq_rel,
                   cuda::memory_order_acquire)) {}
    }
    cuda::atomic_ref<unsigned long long, cuda::thread_scope_device> epoch(
        segments[segment].completed_epoch);
    epoch.store(claimed_epoch, cuda::memory_order_release);
}

enum l3_chain_v2_commit_result
{
    L3_CHAIN_V2_COMMIT_IDLE = 0,
    L3_CHAIN_V2_REQUEUE = 1,
    L3_CHAIN_V2_COMMIT_ERROR = 2,
};

__device__ __forceinline__ l3_chain_v2_commit_result l3_chain_v2_commit(
    l3_chain_v2_segment_state *segments, int segment,
    unsigned long long claimed_epoch)
{
    cuda::atomic_ref<unsigned long long, cuda::thread_scope_device> owner(
        segments[segment].ownership);
    unsigned long long old = owner.load(cuda::memory_order_acquire);
    while (true)
    {
        if ((old & L3_CHAIN_V2_STATE_MASK) != L3_CHAIN_V2_ACTIVE)
            return L3_CHAIN_V2_COMMIT_ERROR;
        const bool changed =
            (old & ~L3_CHAIN_V2_STATE_MASK) != claimed_epoch;
        const unsigned long long next =
            (old & ~L3_CHAIN_V2_STATE_MASK) |
            (changed ? L3_CHAIN_V2_QUEUED : L3_CHAIN_V2_IDLE);
        if (owner.compare_exchange_weak(
                old, next, cuda::memory_order_acq_rel,
                cuda::memory_order_acquire))
            return changed ? L3_CHAIN_V2_REQUEUE :
                             L3_CHAIN_V2_COMMIT_IDLE;
    }
}
