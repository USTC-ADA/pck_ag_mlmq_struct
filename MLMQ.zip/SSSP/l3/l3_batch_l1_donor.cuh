#pragma once
#include "l3_batch_commit.h"
#include "../../core/include/l1_queue.cuh"
#include <cassert>

// Independent SLF donor adapter, NOT included by the SSSP worker. One warp
// owns the real queue, ledger and loan. This first version forbids a new L2
// refill while a loan/credit epoch is live. Credits come from ml_queue::read.
namespace l3_batch_l1_donor {
namespace bc = l3_batch_commit;
constexpr unsigned mask = 0xffffffffu;
struct snapshot {
    int count, head, tail;
    int ids[32], priorities[32];
    bc::seed seeds[32];
};
__device__ inline bool collective(bool value) {
    const unsigned votes = __ballot_sync(mask, value);
    __syncwarp(mask);
    assert(votes == 0u || votes == mask);
    return votes == mask;
}

// Lane 0 only. Call only after the actual read supplied on_the_fly.
__device__ inline bool attach(bc::donor_ledger &d, int on_the_fly) {
    if (!d.released || d.outstanding || on_the_fly <= 0) return false;
    d = {on_the_fly, 0, false};
    return true;
}

template<int N, class Item>
__device__ bool borrow(l1_SLF_queue<Item> &q, bc::state<N> &s,
    std::uint64_t generation, bc::donor_ledger &donor, int on_the_fly,
    int input_count, int pending_outputs, int *distance, int begin, int end,
    int vertices, snapshot &snap, Item *removed, int lane) {
    if (input_count || pending_outputs || on_the_fly <= 0 ||
        donor.released || donor.outstanding || donor.ancestor_credits != on_the_fly ||
        q.data_size <= 0 || q.data_size > 32 || begin < 0 || end <= begin ||
        vertices < end || s.stage != bc::phase::free || s.generation != generation)
        return collective(false);
    const int count = q.data_size, head = q.l, tail = q.r;
    bool valid = true;
    if (lane < count) {
        const Item item = q.data[(head + lane) % MAX_L1SLF_BATCH_SIZE];
        const int v = item.id - 1;
        snap.ids[lane] = item.id; snap.priorities[lane] = item.dist;
        valid = v >= begin && v < end;
        if (valid) {
            const int d = atomicAdd(distance + v - begin, 0);
            valid = d >= 0 && d < INT_MAX;
            snap.seeds[lane] = {v, d};
        }
    }
    const bool all_valid = __all_sync(mask, valid);
    __syncwarp(mask);
    if (!all_valid) return collective(false);
    int reserved = 0;
    if (!lane) {
        snap.count = count; snap.head = head; snap.tail = tail;
        reserved = bc::reserve(s, generation, donor, snap.seeds, count, begin, end, vertices);
    }
    reserved = __shfl_sync(mask, reserved, 0);
    __syncwarp(mask);
    if (!reserved) return collective(false);
    // Ownership is retained BEFORE the original tasks are removed.
    assert(donor.outstanding == 1 && q.data_size == count && q.l == head && q.r == tail);
    int n = 0;
    const auto status = q.read(removed, n, lane);
    assert(status == READ_SUCCESS && n == count && q.data_size == 0);
    bool same = true;
    if (lane < count) same = removed[lane].id == snap.ids[lane] && removed[lane].dist == snap.priorities[lane];
    assert(__all_sync(mask, same));
    return collective(true);
}

// Returns the exact ancestor count once; caller then invokes update_done on
// lane 0 before any worker ACK. loan/intent/active-input checks are mandatory.
template<class Item>
__device__ int retire(l1_SLF_queue<Item> &q, bc::donor_ledger &donor,
    int &on_the_fly, int input_count, int pending_outputs, bool intents_empty, int lane) {
    const bool ready = !donor.released && !donor.outstanding && !q.data_size &&
        !input_count && !pending_outputs && intents_empty &&
        on_the_fly > 0 && donor.ancestor_credits == on_the_fly;
    if (!collective(ready)) return 0;
    int credits = 0;
    if (!lane) credits = bc::retire_if_idle(donor, true);
    credits = __shfl_sync(mask, credits, 0);
    assert(credits == on_the_fly);
    on_the_fly = 0;
    __syncwarp(mask);
    return credits;
}
} // namespace l3_batch_l1_donor
