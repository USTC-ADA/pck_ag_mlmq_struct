#pragma once
#ifndef L3_WAIT_DIAG
#define L3_WAIT_DIAG false
#endif
#ifndef L3_WAIT_WORKER_DIAG
#define L3_WAIT_WORKER_DIAG L3_WAIT_DIAG
#endif
#if (L3_WAIT_DIAG == true)
// Single lane writer, same-warp clock domain. No diagnostic value drives work.
struct l3_wait_sample {
    unsigned long long cycles[6], span, last_work;
};
__device__ l3_wait_sample g_l3_wait[258];
__device__ unsigned long long g_l3_wait_reason[18];
struct l3_wait_clock {
    l3_wait_sample data = {};
    unsigned long long start = 0, last = 0;
    int phase = 0;
    bool enabled;
    __device__ explicit l3_wait_clock(bool on): enabled(on) {
        if(enabled) start = last = clock64();
    }
    __device__ void tick(int next) {
        if(enabled) {
            const auto now = clock64();
            data.cycles[phase] += now-last;
            last=now; phase=next;
        }
    }
    __device__ void finish_read(bool ready) {
        if(enabled && ready) phase=2;
        tick(0);
    }
    __device__ void finish_work() {
        tick(0);
        if(enabled) data.last_work=last-start;
    }
    __device__ void save(int slot) {
        tick(0);
        if(enabled) { data.span=last-start; g_l3_wait[slot]=data; }
    }
};
#endif

#ifndef L3_WAIT_INJECT_DIAG
#define L3_WAIT_INJECT_DIAG false
#endif
#if (L3_WAIT_INJECT_DIAG == true)
#if (L3_WAIT_DIAG == false || L3_WAIT_WORKER_DIAG == true || L3_RECOVERY_MODE != 0 || BULK_ROUND == false || L3_TERM_HANDSHAKE == false || BULK_EPOCH == true || GLOBAL_ROUND == true || GLOBAL_ROUND_ASYNC == true || SEED_BARRIER == true)
#error "inject wait classification requires manager-only ordinary BULK wait diagnostics"
#endif
// Only diagnostic observations: phase snapshots can race transitions and are
// weighted by missing-ACK observations, never elapsed-time measurements.
__device__ unsigned long long g_l3_inject_wait[INJECT_WARP_NUM][6];
#define L3_INJECT_PHASE_DECL __shared__ int l3_inject_phase[INJECT_WARP_NUM]
#define L3_INJECT_PHASE_INIT() do { for(int j=0;j<INJECT_WARP_NUM;++j) l3_inject_phase[j]=0; } while(0)
#define L3_INJECT_PHASE_SET(p) do { if(!lane_id) l3_atomic_store_release<cuda::thread_scope_block>(l3_inject_phase+inj_id, int(p)); } while(0)
#define L3_INJECT_WAIT_OBSERVE() do { if(!lane_id) for(int j=0;j<INJECT_WARP_NUM;++j) { \
    if(l3_atomic_load_acquire<cuda::thread_scope_block>(l3_term_inject_ack+j)!=term_req_now) { \
        int p=l3_atomic_load_acquire<cuda::thread_scope_block>(l3_inject_phase+j); \
        assert(p>=0 && p<6); ++g_l3_inject_wait[j][p]; } } } while(0)
inline cudaError_t l3_inject_wait_reset() {
    unsigned long long zero[INJECT_WARP_NUM][6]={};
    return cudaMemcpyToSymbol(g_l3_inject_wait,zero,sizeof(zero));
}
inline cudaError_t l3_inject_wait_report(int gpu) {
    unsigned long long counts[INJECT_WARP_NUM][6];
    const auto rc=cudaMemcpyFromSymbol(counts,g_l3_inject_wait,sizeof(counts));
    if(rc!=cudaSuccess)return rc;
    for(int i=0;i<INJECT_WARP_NUM;++i) for(int p=0;p<6;++p)
        printf("L3_INJECT_WAIT gpu=%d inject=%d phase=%d count=%llu\n",gpu,i,p,counts[i][p]);
    return cudaSuccess;
}
#else
#define L3_INJECT_PHASE_DECL
#define L3_INJECT_PHASE_INIT() ((void)0)
#define L3_INJECT_PHASE_SET(p) ((void)0)
#define L3_INJECT_WAIT_OBSERVE() ((void)0)
inline cudaError_t l3_inject_wait_reset() { return cudaSuccess; }
inline cudaError_t l3_inject_wait_report(int) { return cudaSuccess; }
#endif
