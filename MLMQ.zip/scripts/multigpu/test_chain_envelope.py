#!/usr/bin/env python3
"""Deterministic sequential checks for the versioned chain-envelope model.

This is deliberately a CPU mathematical model.  It does not model CUDA memory
ordering, queue capacity, device scope, termination, or performance.
"""

from __future__ import annotations

import argparse
import json
import random
from dataclasses import dataclass
from pathlib import Path


INF = 1 << 60
SEED = 0x4C335550


def path_distance(i: int, j: int, forward: list[int], reverse: list[int]) -> int:
    if i <= j:
        return sum(forward[i:j])
    return sum(reverse[j:i])


def enumerate_closure(
    candidates: list[int], forward: list[int], reverse: list[int]
) -> list[int]:
    result = []
    for target in range(len(candidates)):
        result.append(
            min(
                (value + path_distance(source, target, forward, reverse)
                 for source, value in enumerate(candidates) if value < INF),
                default=INF,
            )
        )
    return result


def sweep_closure(
    candidates: list[int], forward: list[int], reverse: list[int]
) -> list[int]:
    """One forward and one reverse min-plus sweep; never performs INF math."""
    size = len(candidates)
    plus = [INF] * size
    minus = [INF] * size
    running = INF
    for index in range(size):
        if candidates[index] < running:
            running = candidates[index]
        plus[index] = running
        if running < INF and index + 1 < size:
            running += forward[index]
    running = INF
    for index in range(size - 1, -1, -1):
        if candidates[index] < running:
            running = candidates[index]
        minus[index] = running
        if running < INF and index > 0:
            running += reverse[index - 1]
    return [min(left, right) for left, right in zip(plus, minus)]


def prefix_formula(
    candidates: list[int], forward: list[int], reverse: list[int]
) -> list[int]:
    size = len(candidates)
    prefix_forward = [0] * size
    prefix_reverse = [0] * size
    for index in range(1, size):
        prefix_forward[index] = prefix_forward[index - 1] + forward[index - 1]
        prefix_reverse[index] = prefix_reverse[index - 1] + reverse[index - 1]

    result = [INF] * size
    best = INF
    for target in range(size):
        if candidates[target] < INF:
            best = min(best, candidates[target] - prefix_forward[target])
        if best < INF:
            result[target] = prefix_forward[target] + best
    best = INF
    for target in range(size - 1, -1, -1):
        if candidates[target] < INF:
            best = min(best, candidates[target] + prefix_reverse[target])
        if best < INF:
            result[target] = min(
                result[target], -prefix_reverse[target] + best
            )
    return result


@dataclass
class Responsibility:
    """Sequential abstraction of claim/offer/commit/rearm."""

    pending: int = INF
    version: int = 0
    completed_version: int = 0
    state: str = "IDLE"

    def offer(self, value: int) -> bool:
        self.pending = min(self.pending, value)
        self.version += 1
        if self.state == "IDLE":
            self.state = "QUEUED"
            return True
        return False

    def claim(self) -> tuple[int, int]:
        assert self.state == "QUEUED"
        self.state = "ACTIVE"
        snapshot = self.pending
        self.pending = INF
        return snapshot, self.version

    def commit(self, claimed_version: int) -> bool:
        assert self.state == "ACTIVE"
        self.completed_version = max(self.completed_version, claimed_version)
        if self.version != claimed_version:
            self.state = "QUEUED"
            return True
        self.state = "IDLE"
        return False


def run_model(chains: int, arrivals_per_chain: int) -> dict[str, object]:
    rng = random.Random(SEED)
    sweep_checks = 0
    formula_checks = 0
    dominated = 0
    required = 0

    for _ in range(chains):
        size = rng.randint(3, 24)
        forward = [rng.randint(0, 1000) for _ in range(size - 1)]
        reverse = [rng.randint(0, 1000) for _ in range(size - 1)]
        completed = [INF] * size

        for arrival in range(arrivals_per_chain):
            source = rng.randrange(size)
            value = rng.randint(0, 1_000_000)
            batch = [INF] * size
            batch[source] = value

            enumerated = enumerate_closure(batch, forward, reverse)
            swept = sweep_closure(batch, forward, reverse)
            formula = prefix_formula(batch, forward, reverse)
            assert swept == enumerated
            assert formula == enumerated
            sweep_checks += 1
            formula_checks += 1

            if value >= completed[source]:
                assert all(
                    completed[target] <= value + path_distance(
                        source, target, forward, reverse
                    )
                    for target in range(size)
                )
                dominated += 1
            else:
                completed = [
                    min(old, new) for old, new in zip(completed, enumerated)
                ]
                required += 1

        # A multi-entry batch verifies the same implementation beyond the
        # single-arrival dominance stream.
        candidates = [
            rng.randint(0, 1_000_000) if rng.random() < 0.4 else INF
            for _ in range(size)
        ]
        assert sweep_closure(candidates, forward, reverse) == enumerate_closure(
            candidates, forward, reverse
        )
        assert prefix_formula(candidates, forward, reverse) == enumerate_closure(
            candidates, forward, reverse
        )

    # A claim followed by a newer offer cannot be cleared by the old commit.
    responsibility = Responsibility()
    assert responsibility.offer(100)
    snapshot, version = responsibility.claim()
    assert (snapshot, version) == (100, 1)
    assert not responsibility.offer(40)
    assert responsibility.commit(version)
    assert responsibility.state == "QUEUED"
    snapshot, version = responsibility.claim()
    assert (snapshot, version) == (40, 2)
    assert not responsibility.commit(version)
    assert responsibility.state == "IDLE"
    assert responsibility.pending == INF
    assert responsibility.offer(25)
    snapshot, version = responsibility.claim()
    assert (snapshot, version) == (25, 3)
    assert not responsibility.commit(version)
    assert responsibility.state == "IDLE" and responsibility.pending == INF

    # Internal sources disprove endpoint-only recovery in the general case.
    unit_forward = [1, 1, 1, 1]
    unit_reverse = [1, 1, 1, 1]
    internal_source = [INF, INF, 0, INF, INF]
    internal_truth = sweep_closure(
        internal_source, unit_forward, unit_reverse
    )
    endpoint_only = [2 + index for index in range(5)]
    endpoint_only = [
        min(endpoint_only[index], 2 + (4 - index)) for index in range(5)
    ]
    assert internal_truth == [2, 1, 0, 1, 2]
    assert endpoint_only[2] == 4 and endpoint_only[2] != internal_truth[2]

    # A distance write is not a completed-propagation certificate.
    ordinary_distance = [INF, 7, INF]
    completed_envelope = [INF, INF, INF]
    assert ordinary_distance[1] < completed_envelope[1]

    total = chains * arrivals_per_chain
    assert dominated + required == total
    return {
        "schema": 1,
        "status": "PASS",
        "seed": SEED,
        "chains": chains,
        "candidate_arrivals": total,
        "sweep_checks": sweep_checks,
        "prefix_formula_checks": formula_checks,
        "dominated_arrivals": dominated,
        "required_arrivals": required,
        "claim_offer_commit_rearm": "PASS",
        "internal_source_counterexample": {
            "truth": internal_truth,
            "endpoint_only_middle": endpoint_only[2],
        },
        "ordinary_distance_not_completed_certificate": "PASS",
        "scope": (
            "sequential integer model only; no CUDA memory ordering, queue, "
            "termination, capacity, or performance claim"
        ),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--chains", type=int, default=1000)
    parser.add_argument("--arrivals-per-chain", type=int, default=100)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    if args.chains <= 0 or args.arrivals_per_chain <= 0:
        parser.error("counts must be positive")
    result = run_model(args.chains, args.arrivals_per_chain)
    payload = json.dumps(result, indent=2, sort_keys=True) + "\n"
    if args.output:
        args.output.write_text(payload)
    print(payload, end="")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
