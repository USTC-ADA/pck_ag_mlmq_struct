// Dedicated mirror + real packed peer executor. Pending tickets are fixture
// work, NOT production DQ/worker credit. Full-solver gates remain mandatory.
#include "../../SSSP/l3/l3_batch_peer_packed.cuh"
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <vector>
#include <algorithm>
#include <string>
namespace relay=l3_batch_relay;
namespace pc=l3_batch_peer_commit;
namespace packed=l3_batch_compact_packed;
namespace bound=l3_batch_bound;
namespace search=l3_batch_search_diag;
#ifndef L3_SEARCH_FIXTURE
#define L3_SEARCH_FIXTURE 0
#endif
#ifndef L3_SELECT_FIXTURE
#define L3_SELECT_FIXTURE 0
#endif
#ifndef L3_BOUND_FIXTURE_NEIGHBORS
#define L3_BOUND_FIXTURE_NEIGHBORS 0
#endif
#ifndef L3_BOUND_FIXTURE_HELPER_LOCAL
#define L3_BOUND_FIXTURE_HELPER_LOCAL 0
#endif
#if L3_BOUND_FIXTURE_HELPER_LOCAL && !L3_BOUND_FIXTURE_NEIGHBORS
#error "helper-local fixture requires atomic neighbor publisher"
#endif
constexpr int edge_limit=2;
#ifdef NDEBUG
#error "fixture requires assertions"
#endif
void check(cudaError_t rc) { if(rc!=cudaSuccess) {fprintf(stderr,"BOUND_CUDA %s\n",cudaGetErrorString(rc));std::exit(2);} }
void require(bool ok,const char *why) {if(!ok) {fprintf(stderr,"BOUND_FAIL %s\n",why);std::exit(3);} }
template<class T> T *allocate(size_t n) {T *p;check(cudaMalloc(&p,std::max(size_t(1),n)*sizeof(T)));return p;}
template<class T> void upload(T *p,const std::vector<T> &v) {if(!v.empty())check(cudaMemcpy(p,v.data(),v.size()*sizeof(T),cudaMemcpyHostToDevice));}
struct edge {int u,v,w;};
struct input {int n,begin,end,budget;std::vector<relay::item> roots,tickets;std::vector<edge> edges;};
__global__ void reset(int *distance,int *mirror,int n,const relay::item *roots,int seeds,int begin) {
    for(int i=threadIdx.x;i<n;i+=64) {distance[i]=INT_MAX;if(mirror) mirror[i]=INT_MAX;}
    __syncthreads();
    for(int i=threadIdx.x;i<seeds;i+=64) atomicMin(distance+roots[i].vertex-begin,roots[i].distance);
}
__global__ void reset_mirror(int *mirror,int n) {
    for(int i=threadIdx.x;i<n;i+=64) mirror[i]=INT_MAX;
}
__global__ void publish_owner(int *distance,int *mirror,int n,const relay::item *tickets,
    int count,int begin,int *gate,const int *rows,const int *columns,
    const relay::item *roots,int seeds,int mode,bound::sampled *observations) {
    while(l3_atomic_load_acquire<cuda::thread_scope_system>(gate)!=1) __nanosleep(64);
    // Tickets already reside on owner and remain pending after their winning
    // labels become visible; no bare lower-distance writes manufacture coverage.
    for(int i=threadIdx.x;i<count;i+=64) atomicMin(distance+tickets[i].vertex-begin,tickets[i].distance);
    __syncthreads();
    bound::sampled observed{};
#if L3_BOUND_FIXTURE_NEIGHBORS
    // Two independent donor warps sample the same root set concurrently.
    // This deliberately overlaps mirror writes across lanes AND warps.
    if(mode) observed=bound::publish_neighbors(mirror,distance,rows,columns,
        begin,n,roots,seeds,edge_limit,threadIdx.x%32);
#else
    int cursor=threadIdx.x;
    observed=bound::publish(mirror,distance,n,cursor,threadIdx.x,(n+63)/64+3);
#endif
    observations[threadIdx.x]=observed;
    __threadfence_system();
    __syncthreads();
    if(!threadIdx.x) l3_atomic_store_release<cuda::thread_scope_system>(gate,2);
}
__global__ void helper(pc::packet *packet,relay::graph_view graph,int *mirror,int mode,
    bound::counters *counts,int *rows,int *gate,search::counters *search_counts,int selection) {
    __shared__ packed::workspace work;
    const int lane=threadIdx.x;
    const auto token=pc::try_claim(packet,lane);assert(token);
    // The independent owner publishes after this loan is ACTIVE. Gate controls
    // timing for reproducibility; it is not a production synchronization change.
    if(!lane) l3_atomic_store_release<cuda::thread_scope_system>(gate,1);
    __syncwarp();
    while(l3_atomic_load_acquire<cuda::thread_scope_system>(gate)!=2) __nanosleep(64);
    if(selection) l3_batch_peer_packed::execute_claimed<true,L3_SEARCH_FIXTURE,true>(packet,token,graph,&work,lane,{mirror,mode},counts,search_counts);
    else l3_batch_peer_packed::execute_claimed<true,L3_SEARCH_FIXTURE,false>(packet,token,graph,&work,lane,{mirror,mode},counts,search_counts);
    if(!lane) *rows=work.rows; // helper-private workspace, never packet payload
}
void print_items(FILE *out,const std::vector<relay::item>&items) {
    fputc('[',out);
    for(size_t i=0;i<items.size();++i) fprintf(out,"%s[%d,%d]",i?",":"",items[i].vertex,items[i].distance);
    fputc(']',out);
}
#if L3_SELECT_FIXTURE
struct select_input {unsigned head;int pending,take,tie,seed;};
__global__ void select_test(const select_input *inputs,int *output) {
    __shared__ packed::workspace work;
    const auto m=inputs[blockIdx.x];const int lane=threadIdx.x;
    for(int i=lane;i<1024;i+=32) {
        work.fifo[i]=65535;work.distances[i]=m.tie?9:(i*37+m.seed)%97;
    }
    __syncwarp();
    for(int i=lane;i<m.pending;i+=32)work.fifo[(m.head+unsigned(i))&1023]=static_cast<unsigned short>((i*17+3)&1023);
    __syncwarp();
    if(lane<m.take)packed::select_front(&work,m.head,unsigned(m.pending),lane);
    __syncwarp();
    for(int i=lane;i<1024;i+=32)output[blockIdx.x*1024+i]=work.fifo[i];
}
void run_selection_cases(const std::string &path) {
    FILE *out=fopen(path.c_str(),"wx");require(out,"selection output must not exist");
    std::vector<select_input> input;
    for(int n:{1,7,31,32,33,64,65,127,512,768})
        for(unsigned head:{0u,3u,1001u,0xffffffefu})
            for(int take:{std::min(n,32),std::min(n,7),1})for(int tie:{0,1})
                input.push_back({head,n,take,tie,int(input.size())});
    for(int gpu=0;gpu<2;++gpu) {
        check(cudaSetDevice(gpu));auto data=allocate<select_input>(input.size());
        auto output=allocate<int>(input.size()*1024);upload(data,input);
        select_test<<<int(input.size()),32>>>(data,output);check(cudaGetLastError());check(cudaDeviceSynchronize());
        std::vector<int> observed(input.size()*1024);check(cudaMemcpy(observed.data(),output,observed.size()*sizeof(int),cudaMemcpyDeviceToHost));
        for(size_t i=0;i<input.size();++i) {
            const auto &m=input[i];
            fprintf(out,"{\"gpu\":%d,\"case\":%zu,\"head\":%u,\"pending\":%d,\"take\":%d,\"tie\":%d,\"seed\":%d,\"fifo\":[",gpu,i,m.head,m.pending,m.take,m.tie,m.seed);
            for(int j=0;j<1024;++j)fprintf(out,"%s%d",j?",":"",observed[i*1024+j]);
            fprintf(out,"]}\n");
        }
        check(cudaFree(data));check(cudaFree(output));
        printf("SELECT_QUEUE_PASS gpu=%d cases=%zu\n",gpu,input.size());
    }
    require(fclose(out)==0,"selection output close");
}
#endif
#if L3_SEARCH_FIXTURE
__global__ void failed_search(pc::packet *packet,const int *rows,const int *cols,
    const int *weights,search::counters *counts) {
    __shared__ packed::workspace work;
    // Controlled invalid input tests the diagnostic failure path, not a valid
    // graph oracle or a production packet/credit recovery claim.
    packed::expand_payload<false,true,L3_SELECT_FIXTURE>(&packet->channel,{rows,cols,weights,0,1},
        &work,packet->certificates,8,threadIdx.x,{},nullptr,counts);
}
void check_failed_search() {
    for(int gpu=0;gpu<2;++gpu) for(int kind=0;kind<2;++kind) {
        check(cudaSetDevice(gpu));auto packet=allocate<pc::packet>(1);
        auto rows=allocate<int>(2),cols=allocate<int>(1),weights=allocate<int>(1);
        auto counts=allocate<search::counters>(1);
        upload(rows,std::vector<int>{0,1});upload(cols,std::vector<int>{0});upload(weights,std::vector<int>{-1});
        pc::packet p{};p.channel.seeds=1;p.channel.input[0]={kind?0:1,0};
        check(cudaMemcpy(packet,&p,sizeof(p),cudaMemcpyHostToDevice));check(cudaMemset(counts,0,sizeof(*counts)));
        failed_search<<<1,32>>>(packet,rows,cols,weights,counts);check(cudaGetLastError());check(cudaDeviceSynchronize());
        search::counters s{};check(cudaMemcpy(&s,counts,sizeof(s),cudaMemcpyDeviceToHost));
        check(cudaMemcpy(&p,packet,sizeof(p),cudaMemcpyDeviceToHost));
        const int status=kind?relay::bad_weight:relay::bad_seed;
        require(p.channel.result_status==status && p.channel.results==0 && s.loans==1 && s.seeds==1 &&
            s.rows==0 && s.certified==0 && s.records==0 && s.failure==1 && s.capacity+s.empty+s.budget==0,
            "controlled search failure counters");
        printf("SEARCH_FAILURE_CASE gpu=%d kind=%d status=%d loans=%llu failure=%llu records=%llu\n",
            gpu,kind,p.channel.result_status,s.loans,s.failure,s.records);
        check(cudaFree(packet));check(cudaFree(rows));check(cudaFree(cols));check(cudaFree(weights));check(cudaFree(counts));
    }
}
#endif
int main(int argc,char **argv) {
    require(argc==3,"usage: fixture cases.txt output.jsonl");
    int devices=0;check(cudaGetDeviceCount(&devices));require(devices==2,"requires exactly two allocated GPUs");
    for(int gpu=0;gpu<2;++gpu) {
        check(cudaSetDevice(gpu));int access=0,native=0;check(cudaDeviceCanAccessPeer(&access,gpu,1-gpu));
        check(cudaDeviceGetP2PAttribute(&native,cudaDevP2PAttrNativeAtomicSupported,gpu,1-gpu));
        require(access&&native,"bidirectional native P2P atomics");
        check(cudaDeviceEnablePeerAccess(1-gpu,0));
        cudaFuncAttributes a{};check(cudaFuncGetAttributes(&a,helper));check(cudaFuncGetAttributes(&a,publish_owner));
    }
    std::ifstream in(argv[1]);require(bool(in),"input open");int size;in>>size;std::vector<input> cases(size);
    for(auto &c:cases) {
        int seeds,tickets,edges;in>>c.n>>c.begin>>c.end>>c.budget>>seeds>>tickets>>edges;
        c.roots.resize(seeds);c.tickets.resize(tickets);c.edges.resize(edges);
        for(auto &v:c.roots) in>>v.vertex>>v.distance;
        for(auto &v:c.tickets) in>>v.vertex>>v.distance;
        for(auto &e:c.edges) in>>e.u>>e.v>>e.w;
        require(bool(in)&&c.n>0&&c.begin>=0&&c.end<=c.n&&c.end>c.begin,"input shape");
    }
    FILE *out=fopen(argv[2],"wx");require(out,"output must not exist");int records=0;
    for(int owner=0;owner<2;++owner) for(int index=0;index<size;++index) {
        const auto &c=cases[index];const int peer=1-owner,n=c.end-c.begin;
        const int storage_gpu=L3_BOUND_FIXTURE_HELPER_LOCAL?peer:owner;
        std::vector<int> rows(n+1,0),columns,weights;
        for(int v=c.begin;v<c.end;++v) {
            for(const auto &e:c.edges) if(e.u==v) {columns.push_back(e.v);weights.push_back(e.w);}
            rows[v-c.begin+1]=int(columns.size());
        }
        check(cudaSetDevice(owner));
        auto distance=allocate<int>(n),gate=allocate<int>(1);
        check(cudaSetDevice(storage_gpu));auto mirror=allocate<int>(n);
        cudaPointerAttributes placement{};check(cudaPointerGetAttributes(&placement,mirror));
        require(placement.type==cudaMemoryTypeDevice&&placement.device==storage_gpu,"physical mirror placement");
        check(cudaSetDevice(owner));
        auto tickets=allocate<relay::item>(c.tickets.size());auto packet=allocate<pc::packet>(1);
        auto orows=allocate<int>(rows.size()),ocolumns=allocate<int>(columns.size());
        auto observations=allocate<bound::sampled>(64);
        upload(orows,rows);upload(ocolumns,columns);
        check(cudaSetDevice(peer));
        auto drows=allocate<int>(rows.size()),dcolumns=allocate<int>(columns.size()),dweights=allocate<int>(weights.size());
        auto counts=allocate<bound::counters>(1);auto expanded=allocate<int>(1);
        auto search_counts=allocate<search::counters>(1);
        upload(drows,rows);upload(dcolumns,columns);upload(dweights,weights);
        relay::graph_view graph{drows,dcolumns,dweights,c.begin,n};
        // Each mode reuses exactly the same allocations across query 0 -> 1.
        for(int selection=0;selection<=(L3_SELECT_FIXTURE?1:0);++selection)
        for(int mode=0;mode<=2;++mode) for(int query=0;query<2;++query) {
            auto roots=c.roots;auto pending=query?std::vector<relay::item>{}:c.tickets;
            if(query && c.roots[0].distance<INT_MAX-100) for(auto &v:roots) v.distance+=100;
            pc::packet host{};host.channel.control=relay::encode(query+17,relay::ready);
            host.channel.seeds=int(roots.size());host.budget=c.budget;
            std::copy(roots.begin(),roots.end(),host.channel.input);
            check(cudaSetDevice(owner));upload(tickets,pending);
            check(cudaMemcpy(packet,&host,sizeof(host),cudaMemcpyHostToDevice));check(cudaMemset(gate,0,sizeof(int)));
            reset<<<1,64>>>(distance,L3_BOUND_FIXTURE_HELPER_LOCAL?nullptr:mirror,n,packet->channel.input,int(roots.size()),c.begin);
            check(cudaGetLastError());check(cudaDeviceSynchronize());
            check(cudaSetDevice(peer));
            if(L3_BOUND_FIXTURE_HELPER_LOCAL) {reset_mirror<<<1,64>>>(mirror,n);check(cudaGetLastError());}
            check(cudaMemset(counts,0,sizeof(*counts)));check(cudaDeviceSynchronize());
            check(cudaMemset(search_counts,0,sizeof(*search_counts)));check(cudaDeviceSynchronize());
            // Both devices' reset/upload work is now complete before either
            // persistent launch. Eager preload above prevents lazy-load waits.
            helper<<<1,32>>>(packet,graph,mirror,mode,counts,expanded,gate,search_counts,selection);check(cudaGetLastError());
            check(cudaSetDevice(owner));
            publish_owner<<<1,64>>>(distance,mirror,n,tickets,int(pending.size()),c.begin,gate,
                orows,ocolumns,packet->channel.input,int(roots.size()),mode,observations);check(cudaGetLastError());
            check(cudaDeviceSynchronize());
            check(cudaSetDevice(peer));check(cudaDeviceSynchronize());
            bound::counters count{};int rowcount=-1;
            check(cudaMemcpy(&count,counts,sizeof(count),cudaMemcpyDeviceToHost));
            check(cudaMemcpy(&rowcount,expanded,sizeof(rowcount),cudaMemcpyDeviceToHost));
            search::counters observed_search{};
            check(cudaMemcpy(&observed_search,search_counts,sizeof(observed_search),cudaMemcpyDeviceToHost));
            check(cudaSetDevice(owner));std::vector<int> observed(n);std::vector<relay::item> kept(pending.size());
            check(cudaMemcpy(&host,packet,sizeof(host),cudaMemcpyDeviceToHost));
            check(cudaSetDevice(storage_gpu));
            check(cudaMemcpy(observed.data(),mirror,n*sizeof(int),cudaMemcpyDeviceToHost));
            check(cudaSetDevice(owner));
            bound::sampled seen[64];unsigned reads=0,finite=0;
            check(cudaMemcpy(seen,observations,sizeof(seen),cudaMemcpyDeviceToHost));
            for(const auto &s:seen) {reads+=s.reads;finite+=s.finite;}
            if(!kept.empty())check(cudaMemcpy(kept.data(),tickets,kept.size()*sizeof(relay::item),cudaMemcpyDeviceToHost));
            require(host.channel.control==relay::encode(query+17,relay::returned),"return token");
            require(host.channel.results>0&&host.channel.results<=packed::capacity,"result capacity");
            fprintf(out,"{\"case\":%d,\"owner\":%d,\"query\":%d,\"mode\":%d,\"status\":%d,\"rows\":%d,\"counts\":[%llu,%llu,%llu],\"tickets\":",
                index,owner,query,mode,host.channel.result_status,rowcount,count.checks,count.covered,count.pruned);
            print_items(out,kept);fprintf(out,",\"mirror\":[");
            for(int i=0;i<n;++i)fprintf(out,"%s%d",i?",":"",observed[i]);
            fprintf(out,"],\"publication\":\"%s\",\"edge_limit\":%d,\"publisher_counts\":[%u,%u],\"mirror_gpu\":%d",
                L3_BOUND_FIXTURE_NEIGHBORS?"neighbors":"scan",edge_limit,reads,finite,placement.device);
#if L3_SEARCH_FIXTURE
            const auto &s=observed_search;
            fprintf(out,",\"search\":{\"loans\":%llu,\"seeds\":%llu,\"rows\":%llu,\"certified\":%llu,\"records\":%llu,\"remaining\":%llu,\"capacity\":%llu,\"empty\":%llu,\"budget\":%llu,\"failure\":%llu}",
                s.loans,s.seeds,s.rows,s.certified,s.records,s.remaining,s.capacity,s.empty,s.budget,s.failure);
#endif
            fprintf(out,",\"selection\":%d,\"journal\":[",selection);
            for(int i=0;i<host.channel.results;++i)fprintf(out,"%s[%d,%d,%d]",i?",":"",host.channel.output[i].vertex,host.channel.output[i].distance,host.certificates[i]);
            fprintf(out,"]}\n");fflush(out);++records;
        }
        check(cudaSetDevice(storage_gpu));check(cudaFree(mirror));
        check(cudaSetDevice(owner));check(cudaFree(distance));check(cudaFree(gate));check(cudaFree(tickets));check(cudaFree(packet));
        check(cudaFree(orows));check(cudaFree(ocolumns));check(cudaFree(observations));
        check(cudaSetDevice(peer));check(cudaFree(drows));check(cudaFree(dcolumns));check(cudaFree(dweights));check(cudaFree(counts));check(cudaFree(expanded));
        check(cudaFree(search_counts));
    }
#if L3_SEARCH_FIXTURE
    check_failed_search();
#endif
#if L3_SELECT_FIXTURE
    run_selection_cases(std::string(argv[2])+".selection.jsonl");
#endif
    require(fclose(out)==0,"output close");printf("BOUND_COMPONENT_PASS devices=2 cases=%d records=%d\n",size,records);
}
