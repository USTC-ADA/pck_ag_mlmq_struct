// Independent compact -> owner -> remote RX -> real DQ/CSR test. Not SSSP.
#define L3_COMMIT_L2_TEST_LIBRARY
#include "test_l3_batch_commit_l2.cu"
#define BULK_ROUND true
#define BULK_INBOX_SLOTS 2
#define BULK_SLOT_FREE 0
#define BULK_SLOT_WRITING 1
#define BULK_SLOT_READY 2
#define BULK_SLOT_READING 3
#define BULK_SLOT_DONE 4
#define L3_FAULT_INJECT_CLAIM_RETRY false
#define L3_FAULT_INJECT_READY_DELAY false
#define L3_FAULT_INJECT_ACK_DELAY false
#include "../../SSSP/l3/l3_batch_remote_commit.cuh"
#include "../../SSSP/l3/l3_batch_peer_commit.cuh"
#include <fstream>
#ifdef NDEBUG
#error "Assertions must remain enabled"
#endif
namespace rc = l3_batch_remote_commit;
#ifdef L3_TEST_PARALLEL_OWNER
namespace pc = l3_test_peer_commit;
#else
namespace pc = l3_batch_peer_commit;
#endif
namespace relay = l3_batch_relay;
#ifdef L3_TEST_PACKED_COMPACT
namespace compact = l3_batch_compact_packed;
#else
namespace compact = l3_batch_compact;
#endif
constexpr int loans = 3;
constexpr std::uint64_t first_generation = (1ull << 40) + 1;
struct Gates {
    int allow_claim, claimed, allow_apply, applied, allow_publish, done, allow_ack;
    int producer_finished, helper_stop, sent, acked, full_stops, delay_checks, competitions;
};
struct RawJournal { int count, root, distance, claims; bc::record records[768]; };
struct Receipt { rc::stamp identity; int loan, acked; bc::seed items[32]; };
struct Side {
    Queue q;
    int begin, vertices, rounds, leaves, fan;
    int *rows, *columns, *weights, *distance, *expected, *seen;
    Stats *stats;
};
struct Source {
    Side side;
    bc::state<> *states;
    bc::donor_ledger *donor;
    bw::intent *intents;
    pc::packet *packets;
    bc::record *journals;
    int *claims;
    RawJournal *archive;
    rc::sender *sender;
    rc::ticket *tickets;
    Receipt *sent_archive;
    rc::channel *peer_channel;
    Gates *gates;
};
__device__ int sys_load(int *p) {
    return cuda::atomic_ref<int, cuda::thread_scope_system>(*p).load(cuda::memory_order_acquire);
}
__device__ void sys_store(int *p, int value) {
    cuda::atomic_ref<int, cuda::thread_scope_system>(*p).store(value, cuda::memory_order_release);
}
__device__ int uniform_load(int *p, int lane) {
    int value = !lane ? sys_load(p) : 0;
    return __shfl_sync(FULL_MASK, value, 0);
}
__global__ void remote_bootstrap(Side d, Source s, bool source) {
    __shared__ Item scratch[32];
    const int lane = threadIdx.x;
    if (!lane) d.q.device_init(0, 0, 0);
    __syncwarp();
    scratch[lane] = Item(d.begin + 1, 0);
    __syncwarp(); int count = 8;
    assert(d.q.write(scratch, count, 0, 0, lane, nullptr) == WRITE_SUCCESS);
    for (int b = 0; b < 4; ++b) d.q.manager_run(b, lane);
    d.q.update_local_info(lane); int n = 0;
    d.q.read(scratch, n, 0, 0, lane, nullptr); assert(n == 8);
    if (!lane) {
        assert(d.q.get_queue_size() == 8); d.stats->bootstrapped = 8;
        if (source) {
            *s.donor = {8, 0, false};
            for (int l = 0; l < loans; ++l) {
                bc::initialize(s.states[l]);
                s.states[l].generation = first_generation;
                s.packets[l].channel.control = relay::encode(first_generation, relay::free);
            }
        }
    }
    if (source) for (int l = 0; l < loans; ++l) bw::initialize(s.intents[l], lane);
}

__device__ void manager(Side d, int lane, unsigned long long start) {
    while (!load(&d.stats->stop)) {
        for (int b = 0; b < 4; ++b) d.q.manager_run(b, lane);
        deadline(start);
    }
}
__device__ void consumer(Side d, Item *input, Item *scratch, int lane, unsigned long long start) {
    if (!lane) d.q.device_init(2, 0, 0);
    __syncwarp();
    while (true) {
        d.q.update_local_info(lane); int count = 0;
        d.q.read(input, count, 2, 0, lane, nullptr);
        for (int i = 0; i < count; ++i) {
            const int v = input[i].id - 1 - d.begin;
            assert(v >= 0 && v < d.vertices);
            if (!lane) atomicAdd(d.seen + v, 1);
            const int distance = atomicAdd(d.distance + v, 0);
            assert(distance <= input[i].dist);
            for (int base = d.rows[v]; base < d.rows[v + 1]; base += 32) {
                const int e = base + lane; bool win = false; int target = 0, value = INT_MAX;
                if (e < d.rows[v + 1]) {
                    target = d.columns[e] - d.begin;
                    assert(target >= 0 && target < d.vertices); // ordinary CSR is local in this fixture
                    const int weight = d.weights[e];
                    if (distance < INT_MAX - weight) value = distance + weight;
                    win = value < atomicMin(d.distance + target, value);
                }
                const auto mask = __ballot_sync(FULL_MASK, win);
                if (win) {
                    const int pos = __popc(mask & (lane ? (1u << lane) - 1 : 0));
                    scratch[pos] = Item(d.begin + target + 1, value);
                    atomicAdd(d.expected + target, 1);
                }
                __syncwarp(); int outputs = __popc(mask);
                if (outputs) assert(d.q.write(scratch, outputs, 2, 0, lane, nullptr) == WRITE_SUCCESS);
                __syncwarp();
            }
        }
        if (!lane && count) d.q.update_done(count);
        __syncwarp();
        int stop = 0;
        if (!lane) {
            const int request = load(&d.stats->drain_request);
            if (request > load(&d.stats->drain_receipt) && d.q.get_queue_size() == 8)
                store(&d.stats->drain_receipt, request);
            stop = load(&d.stats->producer_done) && d.q.get_queue_size() == 0;
        }
        if (__shfl_sync(FULL_MASK, stop, 0)) { if (!lane) store(&d.stats->stop, 1); return; }
        deadline(start);
    }
}
__global__ void remote_helper(Source s, relay::graph_view graph) {
    const int lane = threadIdx.x;
    __shared__ compact::workspace scratch;
    const auto start = clock64();
    while (!uniform_load(&s.gates->helper_stop, lane)) {
        for (int l = 0; l < loans; ++l) {
            const auto token = pc::try_claim(s.packets + l, lane);
            if (token) {
                const int index = int(relay::generation(token) - first_generation) * loans + l;
                if (!lane) cuda::atomic_ref<int, cuda::thread_scope_system>(s.claims[index]).fetch_add(1);
                pc::execute_claimed(s.packets + l, token, graph, &scratch, lane);
            }
        }
        deadline(start);
    }
}

__device__ void advance(Source s, int l, Item *scratch, int lane) {
    auto &state = s.states[l]; auto &p = s.intents[l];
    if (p.status == bw::publication::empty) bw::prepare(state, state.generation, p, s.side.distance, lane);
    if (p.status == bw::publication::prepared && !p.remote) {
        if (lane < p.count) atomicAdd(s.side.expected + p.items[lane].vertex - s.side.begin, 1);
        assert(bw::publish_l2(state, state.generation, p, s.side.q, scratch, 0, 0, lane));
        assert(bw::publish_l2(state, state.generation, p, s.side.q, scratch, 0, 0, lane));
    }
    if (p.status == bw::publication::published) {
        if (!lane) { assert(bw::acknowledge(state, state.generation, p)); assert(!bw::acknowledge(state, state.generation, p)); }
        __syncwarp();
    }
}

__device__ void archive_send(Source s, int round, int l, int lane) {
    const auto &t = s.tickets[l]; auto &a = s.sent_archive[t.identity.epoch - 1];
    if (!lane) { a.identity = t.identity; a.loan = round * loans + l; }
    if (lane < t.identity.count) a.items[lane] = s.intents[l].items[lane];
    __syncwarp();
}

__global__ void remote_source(Source s) {
    const int lane = threadIdx.x; auto d = s.side;
    const auto start = clock64();
    __shared__ Item input[32], scratch[32];
    __shared__ bc::seed root;
    __shared__ rc::ticket bad_ticket;
    if (blockIdx.x == 1) { manager(d, lane, start); return; }
    if (blockIdx.x == 2) { consumer(d, input, scratch, lane, start); return; }
    auto &tx = *s.sender;
    for (int round = 0; round < d.rounds; ++round) {
        for (int l = 0; l < loans; ++l) {
            auto &state = s.states[l];
            const int v = 1 + (round * loans + l) * (d.leaves + 1);
            if (!lane) {
                root = {d.begin + v, atomicAdd(d.distance + v, 0)};
                assert(bc::reserve(state, state.generation, *s.donor, &root, 1,
                                  d.begin, d.begin + d.vertices,
                                  d.begin + d.vertices + d.rounds * loans * (d.fan + 1)));
            }
            __syncwarp();
            assert(pc::publish_request(state, s.packets + l, 1, lane)); // root's full row only
        }
        for (int l = 0; l < loans; ++l) {
            auto &state = s.states[l]; auto &p = s.intents[l];
            while (!pc::accept_return(state, s.packets + l, s.journals + l * 768, lane)) deadline(start);
            assert(state.stage == bc::phase::apply);
            auto &raw = s.archive[round * loans + l];
            if (!lane) {
                raw.count = state.count; raw.root = state.roots[0].vertex; raw.distance = state.roots[0].distance;
                raw.claims = sys_load(s.claims + round * loans + l);
            }
            for (int i = lane; i < state.count; i += 32) raw.records[i] = state.journal[i];
            __syncwarp();
            while (p.status != bw::publication::prepared || !p.remote) { advance(s, l, scratch, lane); deadline(start); }
        }
        // All three loans are live. Two READY slots fill before RX is allowed
        // to claim; the third real intent must remain pending, without loss.
        for (int l = 0; l < 2; ++l) {
            assert(rc::send(s.states[l], s.states[l].generation, s.intents[l], tx, s.tickets[l], s.peer_channel, lane));
            assert(rc::send(s.states[l], s.states[l].generation, s.intents[l], tx, s.tickets[l], s.peer_channel, lane));
            archive_send(s, round, l, lane);
        }
        assert(!rc::send(s.states[2], s.states[2].generation, s.intents[2], tx, s.tickets[2], s.peer_channel, lane));
        if (!lane) { ++s.gates->full_stops; sys_store(&s.gates->allow_claim, tx.last_epoch); }
        __syncwarp();
        while (true) {
            const int claimed = uniform_load(&s.gates->claimed, lane);
            const int applied = uniform_load(&s.gates->applied, lane);
            const int done = uniform_load(&s.gates->done, lane);
            const int allowed_ack = uniform_load(&s.gates->allow_ack, lane);
            if (done > allowed_ack) {
                int held = 0;
                for (int l = 0; l < loans; ++l) if (s.tickets[l].live && s.tickets[l].identity.epoch == done) {
                    assert(!rc::poll(s.states[l], s.states[l].generation, s.intents[l], tx, s.tickets[l], s.peer_channel, lane));
                    held = 1;
                }
                assert(held && s.donor->outstanding > 0);
                if (!lane) {
                    assert(!bc::retire_if_idle(*s.donor, true));
                    const int slot = bulk_inbox_slot(done);
                    assert(!bulk_inbox_try_acquire_write(s.peer_channel->state, s.peer_channel->generation,
                                                        s.peer_channel->ack, slot, done + 2));
                    ++s.gates->delay_checks;
                    sys_store(&s.gates->allow_ack, done);
                }
            }
            if (!lane) { sys_store(&s.gates->allow_apply, claimed); sys_store(&s.gates->allow_publish, applied); }
            __syncwarp();
            int finished = 0;
            for (int l = 0; l < loans; ++l) {
                auto &state = s.states[l]; auto &p = s.intents[l]; auto &t = s.tickets[l];
                if (state.stage == bc::phase::finished) { ++finished; continue; }
                advance(s, l, scratch, lane);
                if (p.status == bw::publication::prepared && p.remote) {
                    assert(!bw::publish_l2(state, state.generation, p, d.q, scratch, 0, 0, lane));
                    assert(!rc::send(state, state.generation + 1, p, tx, t, s.peer_channel, lane));
                    if (!lane) { assert(!bc::start_fallback(state, state.generation)); assert(!bw::acknowledge(state, state.generation, p)); }
                    __syncwarp();
                    const bool was_live = t.live;
                    if (rc::send(state, state.generation, p, tx, t, s.peer_channel, lane)) {
                        if (!was_live) archive_send(s, round, l, lane);
                        assert(!rc::poll(state, state.generation + 1, p, tx, t, s.peer_channel, lane));
                        // Reject another loan's ticket, even with equal generation/window shape.
                        assert(!rc::poll(state, state.generation, p, tx, s.tickets[(l + 1) % loans], s.peer_channel, lane));
                        if (!lane) { bad_ticket = t; bad_ticket.identity.epoch = -1; }
                        __syncwarp(); assert(!rc::poll(state, state.generation, p, tx, bad_ticket, s.peer_channel, lane));
                        if (!lane) { bad_ticket = t; ++bad_ticket.identity.start; }
                        __syncwarp(); assert(!rc::poll(state, state.generation, p, tx, bad_ticket, s.peer_channel, lane));
                        if (rc::poll(state, state.generation, p, tx, t, s.peer_channel, lane)) {
                            assert(!rc::poll(state, state.generation, p, tx, t, s.peer_channel, lane));
                            if (!lane) { s.sent_archive[t.identity.epoch - 1].acked = 1; ++s.gates->acked; assert(bw::acknowledge(state, state.generation, p)); }
                            __syncwarp();
                        }
                    }
                }
            }
            if (!lane) sys_store(&s.gates->allow_claim, tx.last_epoch);
            __syncwarp();
            if (finished == loans) break;
            deadline(start);
        }
        assert(!s.donor->outstanding && !tx.held[0] && !tx.held[1]);
        for (int l = 0; l < loans; ++l) assert(pc::recycle_committed(s.states[l], s.packets + l, s.intents[l], lane));
    }
    if (!lane) {
        const int credit = bc::retire_if_idle(*s.donor, true); assert(credit == 8);
        d.q.update_done(credit); d.stats->retired = credit;
        s.gates->sent = tx.last_epoch;
        sys_store(&s.gates->helper_stop, 1); sys_store(&s.gates->producer_finished, 1);
        store(&d.stats->producer_done, 1);
    }
}

__global__ void remote_receiver(Side d, rc::channel *channel, Gates *gates, rc::receiver *state, int *competed, Receipt *archive) {
    const int lane = threadIdx.x; const auto start = clock64();
    __shared__ Item input[32], scratch[32];
    if (blockIdx.x == 1) { manager(d, lane, start); return; }
    if (blockIdx.x == 2) { consumer(d, input, scratch, lane, start); return; }
    auto &rx = *state;
    while (true) {
        if (uniform_load(&gates->producer_finished, lane) && rx.phase == rc::rx_phase::empty) break;
        if (rx.last_epoch >= uniform_load(&gates->allow_claim, lane) ||
            !rc::claim(channel, rx, d.begin, d.begin + d.vertices, lane)) { deadline(start); continue; }
        const int epoch = rx.identity.epoch;
        if (!lane) { archive[epoch - 1].identity = rx.identity; archive[epoch - 1].loan = -1; }
        if (lane < rx.identity.count) archive[epoch - 1].items[lane] = rx.items[lane];
        __syncwarp();
        assert(!rc::claim(channel, rx, d.begin, d.begin + d.vertices, lane));
        assert(!rc::acknowledge(channel, rx, lane));
        if (!lane) sys_store(&gates->claimed, epoch);
        __syncwarp();
        while (uniform_load(&gates->allow_apply, lane) < epoch) deadline(start);
        assert(rc::apply(rx, d.distance, d.begin, lane));
        assert(!rc::apply(rx, d.distance, d.begin, lane));
        if (!lane) sys_store(&gates->applied, epoch);
        __syncwarp();
        // One real credited task per receiver group creates a shorter value
        // AFTER RX atomicMin, BEFORE its conservative outputs are enqueued.
        const int group = (rx.items[0].vertex - d.begin) / (d.fan + 1);
        const int competed_before = __shfl_sync(FULL_MASK, !lane ? competed[group] : 0, 0);
        if (d.leaves && !competed_before) {
            if (!lane) {
                competed[group] = 1; ++gates->competitions;
                const int vertex = group * (d.fan + 1) + d.fan;
                scratch[0] = Item(d.begin + vertex + 1, 0); atomicAdd(d.expected + vertex, 1);
            }
            __syncwarp(); int n = 1;
            assert(d.q.write(scratch, n, 0, 0, lane, nullptr) == WRITE_SUCCESS);
            if (!lane) store(&d.stats->drain_request, epoch * 2 - 1);
            __syncwarp();
            while (load(&d.stats->drain_receipt) < epoch * 2 - 1) deadline(start);
            __syncwarp();
            assert(atomicAdd(d.distance + group * (d.fan + 1), 0) == 0);
        }
        while (uniform_load(&gates->allow_publish, lane) < epoch) deadline(start);
        if (lane < rx.identity.count) atomicAdd(d.expected + rx.items[lane].vertex - d.begin, 1);
        assert(rc::publish_l2(rx, d.q, scratch, 0, 0, lane));
        assert(rc::publish_l2(rx, d.q, scratch, 0, 0, lane));
        assert(rc::mark_done(channel, rx, lane)); assert(!rc::mark_done(channel, rx, lane));
        if (!lane) store(&d.stats->drain_request, epoch * 2);
        __syncwarp();
        while (load(&d.stats->drain_receipt) < epoch * 2) deadline(start);
        __syncwarp();
        if (!lane) sys_store(&gates->done, epoch);
        __syncwarp();
        while (uniform_load(&gates->allow_ack, lane) < epoch) deadline(start);
        assert(rc::acknowledge(channel, rx, lane)); assert(!rc::acknowledge(channel, rx, lane));
        if (!lane) archive[epoch - 1].acked = 1;
        deadline(start);
    }
    if (!lane) { d.q.update_done(8); d.stats->retired = 8; store(&d.stats->producer_done, 1); }
}

// Metadata boundary unit, separate from the real-queue cases below. It never
// pretends its final pending packet owns L2 credit; no queue operation occurs.
__global__ void epoch_metadata_guard(rc::channel *channel) {
    const int lane = threadIdx.x;
    __shared__ bc::state<1> state;
    __shared__ bw::intent intent;
    __shared__ rc::sender sender;
    __shared__ rc::ticket ticket;
    __shared__ rc::receiver receiver;
    if (!lane) {
        bc::initialize(state); state.generation = first_generation; state.stage = bc::phase::remote;
        intent = {}; intent.generation = first_generation; intent.source_phase = bc::phase::remote;
        intent.end = intent.count = 1; intent.remote = true; intent.status = bw::publication::prepared;
        intent.items[0] = {0, 1}; *channel = {}; sender = {}; ticket = {}; receiver = {};
        sender.last_epoch = receiver.last_epoch = INT_MAX;
    }
    __syncwarp();
    assert(!rc::send(state, state.generation, intent, sender, ticket, channel, lane));
    assert(!rc::claim(channel, receiver, 0, 1, lane));
    if (!lane) sender.last_epoch = receiver.last_epoch = INT_MAX - 1;
    __syncwarp();
    assert(rc::send(state, state.generation, intent, sender, ticket, channel, lane));
    assert(ticket.identity.epoch == INT_MAX && ticket.identity.generation == first_generation);
    assert(rc::claim(channel, receiver, 0, 1, lane));
    assert(receiver.identity.generation == first_generation && receiver.identity.epoch == INT_MAX);
    assert(!rc::acknowledge(channel, receiver, lane));
}

struct Snapshot {
    std::vector<int> distance, expected, seen;
    int reserved[4], consumed[4], published[4], done, written, overflow;
    Stats stats;
};
static Snapshot download(Side d) {
    Snapshot s; s.distance.resize(d.vertices); s.expected.resize(d.vertices); s.seen.resize(d.vertices);
#define COPY(dst, src, bytes) CUDA(cudaMemcpy(dst, src, bytes, cudaMemcpyDeviceToHost))
    COPY(s.distance.data(), d.distance, d.vertices * 4); COPY(s.expected.data(), d.expected, d.vertices * 4); COPY(s.seen.data(), d.seen, d.vertices * 4);
    COPY(s.reserved, d.q.write_reserve, 16); COPY(s.consumed, d.q.bucket_read_done, 16); COPY(s.published, d.q.read_pos, 16);
    COPY(&s.done, d.q.read_done, 4); COPY(&s.written, d.q.debug_write_done, 4); COPY(&s.overflow, d.q.counter_overflow, 4); COPY(&s.stats, d.stats, sizeof(Stats));
#undef COPY
    return s;
}
static int verify_snapshot(const Snapshot &s) {
    CHECK(s.expected == s.seen && s.stats.bootstrapped == 8 && s.stats.retired == 8 && s.stats.stop == 1);
    int total = 0, expected = 8;
    for (int n : s.expected) expected += n;
    for (int b = 0; b < 4; ++b) { CHECK(s.reserved[b] == s.consumed[b] && s.reserved[b] == s.published[b]); total += s.reserved[b]; }
    CHECK(total == expected && total == s.done && total == s.written && !s.overflow);
    return total;
}
static void dump_side(std::ofstream &out, const char *label, const Snapshot &s, Side d,
                      const Graph &graph, const std::vector<int> &initial, const std::vector<int> &oracle) {
    out << "SIDE " << label << " begin " << d.begin << " vertices " << d.vertices << '\n';
    for (int v = 0; v < d.vertices; ++v) {
        out << "VERTEX " << d.begin + v << " initial " << initial[d.begin + v] << " distance " << s.distance[v]
            << " oracle " << oracle[d.begin + v] << " expected " << s.expected[v] << " seen " << s.seen[v] << '\n';
        for (auto edge : graph[d.begin + v]) out << "EDGE " << d.begin + v << ' ' << edge.first << ' ' << edge.second << '\n';
    }
    for (int b = 0; b < 4; ++b) out << "BUCKET " << b << " reserved " << s.reserved[b] << " consumed " << s.consumed[b] << " published " << s.published[b] << '\n';
    out << "QUEUE done " << s.done << " written " << s.written << " overflow " << s.overflow
        << " bootstrapped " << s.stats.bootstrapped << " retired " << s.stats.retired << " stop " << s.stats.stop << '\n';
}
static Side make_side(int begin, int vertices, int rounds, int leaves, int fan,
                      const Graph &graph, const std::vector<int> &initial, std::vector<void *> &allocation) {
    Side d{}; d.begin = begin; d.vertices = vertices; d.rounds = rounds; d.leaves = leaves; d.fan = fan;
    d.q = make_queue(allocation, begin ? 11 : 0);
    std::vector<int> rows{0}, columns, weights;
    for (int v = 0; v < vertices; ++v) {
        for (auto e : graph[begin + v]) { columns.push_back(e.first); weights.push_back(e.second); }
        rows.push_back(int(columns.size()));
    }
#define A(field, type, n) d.field = allocate<type>(n); allocation.push_back(d.field)
    A(rows, int, rows.size()); A(columns, int, std::max(size_t(1), columns.size())); A(weights, int, std::max(size_t(1), weights.size()));
    A(distance, int, vertices); A(expected, int, vertices); A(seen, int, vertices); A(stats, Stats, 1);
#undef A
    CUDA(cudaMemcpy(d.rows, rows.data(), rows.size() * 4, cudaMemcpyHostToDevice));
    if (!columns.empty()) { CUDA(cudaMemcpy(d.columns, columns.data(), columns.size() * 4, cudaMemcpyHostToDevice)); CUDA(cudaMemcpy(d.weights, weights.data(), weights.size() * 4, cudaMemcpyHostToDevice)); }
    CUDA(cudaMemcpy(d.distance, initial.data() + begin, vertices * 4, cudaMemcpyHostToDevice));
    return d;
}
static void run_remote_case(int owner, int begin, int fan, int leaves, int rounds, const std::string &directory) {
    const int peer = 1 - owner, groups = rounds * loans, local = 1 + groups * (leaves + 1), remote = groups * (fan + 1), split = begin + local;
    const int max_packets = groups * ((1 + leaves + fan + 31) / 32);
    Graph graph(split + remote); std::vector<int> initial(graph.size(), INT_MAX); initial[begin] = 0;
    for (int group = 0; group < groups; ++group) {
        const int root = begin + 1 + group * (leaves + 1), distance = 10 + group % 5;
        graph[begin].push_back({root, distance}); initial[root] = distance;
        for (int l = 1; l <= leaves; ++l) graph[root].push_back({root + l, l});
        for (int i = 0; i < fan; ++i) {
            graph[root].push_back({split + group * (fan + 1) + i, 20 + i % 11});
            graph[split + group * (fan + 1) + i].push_back({split + group * (fan + 1) + (i + 1) % fan, 0});
        }
        if (leaves) {
            const int competitor = split + group * (fan + 1) + fan;
            graph[begin].push_back({competitor, 0}); initial[competitor] = 0;
            graph[competitor].push_back({split + group * (fan + 1), 0});
        }
    }
    const auto oracle = dijkstra(graph, {{begin, 0}});
    std::vector<void *> own_alloc, peer_alloc;
    CUDA(cudaSetDevice(owner)); Source s{};
    s.side = make_side(begin, local, rounds, leaves, fan, graph, initial, own_alloc);
#define A(field, type, n) s.field = allocate<type>(n); own_alloc.push_back(s.field)
    A(states, bc::state<>, loans); A(donor, bc::donor_ledger, 1); A(intents, bw::intent, loans);
    A(packets, pc::packet, loans); A(journals, bc::record, loans * 768); A(claims, int, groups);
    A(archive, RawJournal, groups); A(sender, rc::sender, 1); A(tickets, rc::ticket, loans);
    A(sent_archive, Receipt, max_packets);
#undef A
    remote_bootstrap<<<1,32,s.side.q.get_shm_size()>>>(s.side, s, true); CUDA(cudaGetLastError()); CUDA(cudaDeviceSynchronize());
    cudaFuncAttributes attributes{}; CUDA(cudaFuncGetAttributes(&attributes, remote_source));
    CUDA(cudaSetDevice(peer));
    Side target = make_side(split, remote, rounds, leaves, fan, graph, initial, peer_alloc);
    auto channel = allocate<rc::channel>(1); peer_alloc.push_back(channel); s.peer_channel = channel;
    auto gates = allocate<Gates>(1); peer_alloc.push_back(gates); s.gates = gates;
    auto receiver = allocate<rc::receiver>(1); peer_alloc.push_back(receiver);
    auto competed = allocate<int>(groups); peer_alloc.push_back(competed);
    auto received_archive = allocate<Receipt>(max_packets); peer_alloc.push_back(received_archive);
    // Static helper replica contains source rows only, with global columns.
    auto helper_rows = allocate<int>(local + 1); peer_alloc.push_back(helper_rows);
    int edges = 0; CUDA(cudaMemcpy(&edges, s.side.rows + local, 4, cudaMemcpyDeviceToHost));
    auto helper_columns = allocate<int>(edges); peer_alloc.push_back(helper_columns);
    auto helper_weights = allocate<int>(edges); peer_alloc.push_back(helper_weights);
    CUDA(cudaMemcpyPeer(helper_rows, peer, s.side.rows, owner, (local + 1) * 4));
    CUDA(cudaMemcpyPeer(helper_columns, peer, s.side.columns, owner, edges * 4));
    CUDA(cudaMemcpyPeer(helper_weights, peer, s.side.weights, owner, edges * 4));
    remote_bootstrap<<<1,32,target.q.get_shm_size()>>>(target, s, false); CUDA(cudaGetLastError()); CUDA(cudaDeviceSynchronize());
    CUDA(cudaFuncGetAttributes(&attributes, remote_receiver)); CUDA(cudaFuncGetAttributes(&attributes, remote_helper));
    cudaDeviceProp prop{}; CUDA(cudaGetDeviceProperties(&prop, peer)); CHECK(prop.multiProcessorCount >= 5);
    cudaStream_t helpers, rx, source;
    CUDA(cudaStreamCreateWithFlags(&helpers, cudaStreamNonBlocking)); CUDA(cudaStreamCreateWithFlags(&rx, cudaStreamNonBlocking));
    // Both devices initialized and all persistent kernels loaded before launch.
    remote_helper<<<2,32,0,helpers>>>(s, {helper_rows, helper_columns, helper_weights, begin, local}); CUDA(cudaGetLastError());
    remote_receiver<<<3,32,target.q.get_shm_size(),rx>>>(target, channel, gates, receiver, competed, received_archive); CUDA(cudaGetLastError());
    CUDA(cudaSetDevice(owner)); CUDA(cudaStreamCreateWithFlags(&source, cudaStreamNonBlocking));
    remote_source<<<3,32,s.side.q.get_shm_size(),source>>>(s); CUDA(cudaGetLastError()); CUDA(cudaStreamSynchronize(source)); CUDA(cudaStreamDestroy(source));
    Snapshot a = download(s.side); std::vector<RawJournal> journals(groups);
    CUDA(cudaMemcpy(journals.data(), s.archive, groups * sizeof(RawJournal), cudaMemcpyDeviceToHost));
    std::vector<Receipt> sent(max_packets), received(max_packets);
    CUDA(cudaMemcpy(sent.data(), s.sent_archive, max_packets * sizeof(Receipt), cudaMemcpyDeviceToHost));
    bc::donor_ledger donor; CUDA(cudaMemcpy(&donor, s.donor, sizeof(donor), cudaMemcpyDeviceToHost));
    std::vector<relay::word> controls(loans);
    for (int l = 0; l < loans; ++l) CUDA(cudaMemcpy(&controls[l], &s.packets[l].channel.control, sizeof(relay::word), cudaMemcpyDeviceToHost));
    CUDA(cudaSetDevice(peer)); CUDA(cudaStreamSynchronize(rx)); CUDA(cudaStreamSynchronize(helpers)); CUDA(cudaStreamDestroy(rx)); CUDA(cudaStreamDestroy(helpers));
    Snapshot b = download(target); Gates result{}; rc::channel final_channel{}; rc::receiver final_rx{};
    CUDA(cudaMemcpy(&result, gates, sizeof(result), cudaMemcpyDeviceToHost)); CUDA(cudaMemcpy(&final_channel, channel, sizeof(final_channel), cudaMemcpyDeviceToHost));
    CUDA(cudaMemcpy(&final_rx, receiver, sizeof(final_rx), cudaMemcpyDeviceToHost));
    CUDA(cudaMemcpy(received.data(), received_archive, max_packets * sizeof(Receipt), cudaMemcpyDeviceToHost));
    const std::string stem = directory + "/owner" + std::to_string(owner) + "_begin" + std::to_string(begin) + "_fan" + std::to_string(fan) + "_leaves" + std::to_string(leaves);
    std::ofstream audit(stem + ".audit.txt"); CHECK(audit.good());
    dump_side(audit, "owner", a, s.side, graph, initial, oracle); dump_side(audit, "remote", b, target, graph, initial, oracle);
    audit << "TRANSPORT sent " << result.sent << " acked " << result.acked << " full_stops " << result.full_stops << " delay_checks " << result.delay_checks << " competitions " << result.competitions << '\n';
    for (int slot = 0; slot < 2; ++slot) audit << "SLOT " << slot << " state " << final_channel.state[slot] << " generation " << final_channel.generation[slot] << " epoch " << final_channel.epoch[slot] << " ack " << final_channel.ack[slot] << '\n';
    audit << "DONOR credits " << donor.ancestor_credits << " outstanding " << donor.outstanding << " released " << donor.released << '\n';
    for (int l = 0; l < loans; ++l) audit << "HELPER_SLOT " << l << " control " << controls[l] << '\n';
    for (int e = 0; e < std::max(0, std::min(max_packets, result.sent)); ++e) {
        for (int role = 0; role < 2; ++role) {
            const auto &r = role ? received[e] : sent[e];
            audit << "RECEIPT " << role << " epoch " << r.identity.epoch << " generation " << r.identity.generation
                  << " start " << r.identity.start << " end " << r.identity.end << " count " << r.identity.count
                  << " loan " << r.loan << " acked " << r.acked << '\n';
            for (int i = 0; i < std::max(0, std::min(32, r.identity.count)); ++i)
                audit << "PAYLOAD " << r.items[i].vertex << ' ' << r.items[i].distance << '\n';
        }
    }
    audit.close(); CHECK(audit.good());
    std::ofstream journal(stem + ".journal.txt"); CHECK(journal.good());
    for (int g = 0; g < groups; ++g) {
        const auto &j = journals[g]; journal << "LOAN " << g << " root " << j.root << " distance " << j.distance << " count " << j.count << " claims " << j.claims << '\n';
        for (int i = 0; i < std::max(0, std::min(768, j.count)); ++i) journal << "RECORD " << j.records[i].vertex << ' ' << j.records[i].distance << ' ' << j.records[i].certificate << '\n';
    }
    journal.close(); CHECK(journal.good());
    CHECK(std::equal(a.distance.begin(), a.distance.end(), oracle.begin() + begin));
    CHECK(std::equal(b.distance.begin(), b.distance.end(), oracle.begin() + split));
    int packets = 0, remote_records = 0;
    for (int g = 0; g < groups; ++g) {
        const auto &j = journals[g]; CHECK(j.count > 0 && j.count <= 768 && j.claims == 1);
        CHECK(j.root == begin + 1 + g * (leaves + 1) && j.distance == initial[j.root]);
        validate_journal(graph, {{j.root,j.distance}}, {j.records,j.records+j.count}, begin, split);
        for (int first = 0; first < j.count; first += 32) {
            int n = 0; for (int i = first; i < std::min(first + 32, j.count); ++i) n += j.records[i].vertex >= split;
            packets += n > 0; remote_records += n;
        }
    }
    const int source_writes = verify_snapshot(a), remote_writes = verify_snapshot(b);
    CHECK(result.sent == packets && result.acked == packets && result.delay_checks == packets && result.full_stops == rounds);
    CHECK(packets <= max_packets);
    for (int e = 0; e < packets; ++e) {
        const auto &t = sent[e]; const auto &r = received[e];
        CHECK(rc::same(t.identity, r.identity) && t.identity.epoch == e + 1 && t.acked && r.acked);
        CHECK(t.loan >= 0 && t.loan < groups && t.identity.generation == first_generation + t.loan / loans);
        const auto &j = journals[t.loan];
        CHECK(t.identity.start >= 0 && t.identity.end <= j.count && t.identity.end - t.identity.start <= 32);
        std::vector<std::pair<int,int>> expected, actual;
        for (int i = t.identity.start; i < t.identity.end; ++i) if (j.records[i].vertex >= split)
            expected.push_back({j.records[i].vertex,j.records[i].distance});
        for (int i = 0; i < t.identity.count; ++i) {
            CHECK(t.items[i].vertex == r.items[i].vertex && t.items[i].distance == r.items[i].distance);
            actual.push_back({t.items[i].vertex,t.items[i].distance});
        }
        CHECK(actual == expected);
    }
    CHECK(result.competitions == (leaves ? groups : 0));
    CHECK(final_rx.phase == rc::rx_phase::empty && final_rx.last_epoch == packets);
    for (int slot = 0; slot < 2; ++slot) CHECK(final_channel.state[slot] == BULK_SLOT_DONE && final_channel.ack[slot] == final_channel.generation[slot]);
    CHECK(donor.released && !donor.outstanding && donor.ancestor_credits == 8);
    for (auto control : controls) CHECK(control == relay::encode(first_generation + rounds, relay::free));
    CHECK(source_writes == 8 + groups * leaves && remote_records == groups * fan);
    std::cout << "BATCH_REMOTE_COMMIT_CASE owner=" << owner << " begin=" << begin << " fan=" << fan << " leaves=" << leaves
              << " rounds=" << rounds << " loans=" << groups << " packets=" << packets << " remote_records=" << remote_records
              << " full_stops=" << result.full_stops << " delay_checks=" << result.delay_checks << " competitions=" << result.competitions
              << " source_writes=" << source_writes << " remote_writes=" << remote_writes << " PASS\n" << std::flush;
    for (void *p : peer_alloc) CUDA(cudaFree(p));
    CUDA(cudaSetDevice(owner)); for (void *p : own_alloc) CUDA(cudaFree(p));
}
int main(int argc, char **argv) {
    try {
        CHECK(std::getenv("SLURM_JOB_ID") != nullptr);
        CHECK(argc == 2 || (argc == 3 && std::string(argv[2]) == "--quick"));
        const bool quick = argc == 3; int devices = 0; CUDA(cudaGetDeviceCount(&devices)); CHECK(devices == 2);
        for (int gpu = 0; gpu < 2; ++gpu) {
            CUDA(cudaSetDevice(gpu)); cudaDeviceProp prop{}; CUDA(cudaGetDeviceProperties(&prop, gpu)); CHECK(prop.major == 8 && prop.minor == 0);
            int peer = 0, atomics = 0; CUDA(cudaDeviceCanAccessPeer(&peer,gpu,1-gpu)); CUDA(cudaDeviceGetP2PAttribute(&atomics,cudaDevP2PAttrNativeAtomicSupported,gpu,1-gpu));
            CHECK(peer && atomics); CUDA(cudaDeviceEnablePeerAccess(1-gpu,0));
            auto metadata_channel = allocate<rc::channel>(1);
            epoch_metadata_guard<<<1,32>>>(metadata_channel); CUDA(cudaGetLastError()); CUDA(cudaDeviceSynchronize()); CUDA(cudaFree(metadata_channel));
            std::cout << "EPOCH_METADATA_GUARD_PASS gpu=" << gpu << " generation=" << first_generation << " no_queue=1\n" << std::flush;
        }
        int cases = 0;
        for (int owner : {0,1}) for (int begin : quick ? std::vector<int>{37} : std::vector<int>{0,37})
            for (int fan : quick ? std::vector<int>{33} : std::vector<int>{1,33,65})
                for (int leaves : quick ? std::vector<int>{7} : std::vector<int>{0,7}) {
                    run_remote_case(owner,begin,fan,leaves,quick?2:4,argv[1]); ++cases;
                }
        std::cout << "BATCH_REMOTE_COMMIT_PASS cases=" << cases << " actual_compact=1 actual_remote=1 actual_dq=1 no_l1=1 no_solver=1 not_performance=1\n" << std::flush;
        return 0;
    } catch (const std::exception &e) { std::cerr << "FAIL " << e.what() << '\n'; return 1; }
}
