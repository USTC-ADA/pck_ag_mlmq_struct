import unittest
from l3_gpu_telemetry import parse_windows,summarize_window


class TelemetryTests(unittest.TestCase):
    def raw(self):
        return '\n'.join(f'L3_TIMING gpu={g} repeat={q} warmup={int(q==0)} '
            'barrier_return_ms=0.01 manage_before_ms=0.02 manage_after_ms=0.03 work_before_ms=0.04 '
            'work_after_ms=0.05 sync_before_ms=0.06 sync_after_ms=70.05 finish_after_ms=70.06 '
            f'manage_stream_ms=70.00 work_stream_ms=70.00 origin_ms={1000+100*q:.6f}' for q in (0,1) for g in (0,1))

    def test_absolute_windows_and_identity(self):
        rows=parse_windows(self.raw(),2,1,900_000_000,1_300_000_000)
        self.assertEqual(len(rows),4)
        self.assertEqual(rows[0]['window_start_ns'],1_000_050_000)
        self.assertEqual(rows[3]['window_end_ns'],1_170_050_000)
        for raw in (self.raw().replace(' origin_ms=1000.000000',''),self.raw().replace('gpu=1','gpu=0'),
                    self.raw().replace('repeat=1','repeat=0'),self.raw().replace('origin_ms=1100.000000','origin_ms=9000.000000'),
                    self.raw().replace('origin_ms=1000.000000','origin_ms=1001.000000',1)):
            with self.assertRaises(ValueError):parse_windows(raw,2,1,900_000_000,1_300_000_000)

    def observation(self,ns,gpu=0):
        fields={'sm_mhz':1410,'memory_mhz':1512,'pstate':0,'event_reasons':0,'power_mw':190000,'temperature_c':40}
        return dict(gpu=gpu,start_ns=ns,end_ns=ns+500000,rc={f:0 for f in fields},**fields)

    def test_overlap_is_not_enough(self):
        window={'gpu':0,'repeat':1,'warmup':0,'window_start_ns':100_000_000,'window_end_ns':170_000_000}
        rows=[self.observation(t) for t in range(102_000_000,169_000_000,2_000_000)]
        good=summarize_window(window,rows)
        self.assertTrue(good['coverage_valid'])
        self.assertEqual(good['values']['sm_mhz'],[1410])
        rows+=[self.observation(99_900_000),self.observation(169_900_000),self.observation(105_000_000,1)]
        self.assertEqual(summarize_window(window,rows)['samples'],good['samples'])
        self.assertFalse(summarize_window(window,[])['coverage_valid'])
        self.assertFalse(summarize_window(window,rows[:3])['coverage_valid'])
        self.assertFalse(summarize_window(window,rows[:6]+rows[25:34])['coverage_valid'])
        rows[0]['rc']['sm_mhz']=3;rows[0]['sm_mhz']=None
        result=summarize_window(window,rows)
        self.assertFalse(result['coverage_valid']);self.assertEqual(result['return_codes']['sm_mhz'],[0,3])


if __name__=='__main__':unittest.main()
