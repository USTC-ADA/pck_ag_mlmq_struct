import copy
import unittest
from l3_bound_fixture import INF, cases, neighbor_cases, search_cases, selection_cases, audit_record, path_witnesses, sampled_neighbors
from run_l3_batch_runtime import parse_bound, parse_bound_publisher, parse_bound_neighbors, parse_bound_placement, parse_search, parse_select


class BoundAuditTests(unittest.TestCase):
    def test_selection_policy_and_wide_frontier_certificate(self):
        raw='L3_BATCH_SELECT_CONFIG gpu=0 enabled=1 stride=32\nL3_BATCH_SELECT_CONFIG gpu=1 enabled=1 stride=32'
        self.assertEqual(len(parse_select(raw,1)),2)
        for bad in (raw.replace('gpu=1','gpu=0'),raw.replace('stride=32','stride=16'),raw.replace('enabled=1','enabled=0'),raw+'\nL3_BATCH_SELECT_CONFIG bad'):
            with self.assertRaises(ValueError):parse_select(bad,1)
        c=selection_cases()[-1]
        labels=[0]+[2]*32+[1]*32+[3]*32
        for policy,rows in ((0,161),(1,97)):
            r=dict(owner=0,query=0,mode=0,status=0,rows=rows,counts=[0,0,0],tickets=[],publication='neighbors',
                   edge_limit=2,publisher_counts=[0,0],mirror_gpu=1,mirror=[INF]*97,selection=policy,
                   journal=[[v,d,d] for v,d in enumerate(labels)],
                   search=dict(loans=1,seeds=1,rows=rows,certified=97,records=97,remaining=0,capacity=0,empty=1,budget=0,failure=0))
            audit_record(c,r)
            r['selection']=1-policy
            with self.assertRaisesRegex(ValueError,'expected expansion order'):audit_record(c,r)

    def test_search_repeated_rows_are_not_unique_certificates(self):
        c = search_cases()[-2]
        r = dict(owner=0, query=0, mode=0, status=0, rows=7, counts=[0,0,0], tickets=[],
                 publication='neighbors', edge_limit=2, publisher_counts=[0,0], mirror_gpu=1, mirror=[INF]*6,
                 journal=[[v,d,d] for v,d in ((0,0),(1,3),(2,1),(3,4),(4,2))],
                 search=dict(loans=1,seeds=1,rows=7,certified=5,records=5,remaining=0,capacity=0,empty=1,budget=0,failure=0))
        audit_record(c, r)
        for key, value in [('certified',7),('remaining',1),('budget',1),('failure',1)]:
            bad = copy.deepcopy(r);bad['search'][key] = value
            with self.assertRaises(ValueError):audit_record(c,bad)
        r['rows'] = r['search']['rows'] = 5
        with self.assertRaisesRegex(ValueError,'vacuous repeated'):
            audit_record(c,r)

    def test_search_opposite_owner_and_stop_conservation(self):
        rt = [dict(gpu=g,loans=1,seeds=2,records=5,certificates=4) for g in (0,1)]
        hp = [dict(gpu=g,counts=[1,0]) for g in (0,1)]
        lines=[]
        for g in (0,1):
            for w in (0,1):
                values=[1,2,7,4,5,1,1,0,0,0] if w==0 else [0]*10
                lines.append(f'L3_BATCH_SEARCH gpu={g} warp={w} '+' '.join(f'{k}={v}' for k,v in zip(
                    'loans seeds rows certified records remaining capacity empty budget failure'.split(),values)))
        raw='\n'.join(lines)
        self.assertEqual(len(parse_search(raw,1,512,1,rt,hp)),4)
        for old,new in [('warp=1','warp=0'),('rows=7','rows=3'),('certified=4','certified=3'),
                        ('seeds=2','seeds=3'),('records=5','records=4'),('remaining=1','remaining=6'),
                        ('capacity=1','capacity=0'),('empty=0','empty=1'),('failure=0','failure=1')]:
            with self.assertRaises(ValueError):parse_search(raw.replace(old,new),1,512,1,rt,hp)
        with self.assertRaises(ValueError):parse_search(raw+'\nL3_BATCH_SEARCH bad',1,512,1,rt,hp)

    def test_helper_mirror_asymmetric_sizes_and_devices(self):
        configs = [dict(gpu=0, mirror_bytes=400), dict(gpu=1, mirror_bytes=280)]
        raw = ('L3_BATCH_BOUND_PLACEMENT gpu=0 owner_vertices=100 storage_vertices=70 publisher_target_gpu=1 helper_read_gpu=0 reset_gpu=0\n'
               'L3_BATCH_BOUND_PLACEMENT gpu=1 owner_vertices=70 storage_vertices=100 publisher_target_gpu=0 helper_read_gpu=1 reset_gpu=1')
        self.assertEqual(len(parse_bound_placement(raw, 1, configs)), 2)
        for old, new in [('gpu=1 owner', 'gpu=0 owner'), ('storage_vertices=70', 'storage_vertices=100'),
                         ('owner_vertices=100', 'owner_vertices=70'), ('publisher_target_gpu=1', 'publisher_target_gpu=0'),
                         ('helper_read_gpu=0', 'helper_read_gpu=1'), ('reset_gpu=0', 'reset_gpu=1')]:
            with self.assertRaises(ValueError):
                parse_bound_placement(raw.replace(old, new), 1, configs)
        with self.assertRaises(ValueError):
            parse_bound_placement(raw+'\nL3_BATCH_BOUND_PLACEMENT malformed', 1, configs)
        c = neighbor_cases(helper_local=True)[0]
        r = dict(owner=0, query=0, mode=0, status=0, rows=0, counts=[0,0,0], tickets=[],
                 publication='neighbors', edge_limit=2, publisher_counts=[0,0], mirror=[INF]*12,
                 mirror_gpu=1, journal=[[0,0,INF]])
        audit_record(c, r)
        r['mirror_gpu'] = 0
        with self.assertRaisesRegex(ValueError, 'physical mirror placement'):
            audit_record(c, r)

    def test_neighbor_selection_and_concurrent_witness(self):
        c = neighbor_cases()[-2]
        r = dict(owner=0, query=0, mode=2, status=0, rows=1, counts=[3, 2, 2], tickets=c['tickets'],
                 publication='neighbors', edge_limit=2, publisher_counts=[4, 4],
                 mirror=[INF, 1, 1, INF, INF], journal=[[0, 0, 0], [3, 1, INF]])
        self.assertEqual(audit_record(c, r)['pruned'], 2)
        for vertex, value in ((0, 0), (1, INF), (3, 1)):
            bad = copy.deepcopy(r);bad['mirror'][vertex] = value
            with self.assertRaisesRegex(ValueError, 'mirror/reset/publication'):
                audit_record(c, bad)
        for key, value in [('publisher_counts', [4, 3]), ('publication', 'scan'), ('edge_limit', 3)]:
            bad = copy.deepcopy(r);bad[key] = value
            with self.assertRaises(ValueError):
                audit_record(c, bad)
        r.update(mode=0, rows=0, counts=[0, 0, 0], publisher_counts=[0, 0], mirror=[INF]*5,
                 journal=[[0, 0, INF]])
        audit_record(c, r)
        r['publisher_counts'] = [4, 4]
        with self.assertRaisesRegex(ValueError, 'publisher counts'):
            audit_record(c, r)
        remote = neighbor_cases()[-1]
        self.assertEqual(sampled_neighbors(remote, remote['roots']), [])
        concurrent = neighbor_cases()[-3]
        self.assertEqual(sampled_neighbors(concurrent, concurrent['roots']), [64]*64)

    def test_neighbor_parser_conservation(self):
        runtime = [dict(gpu=g, seeds=3) for g in (0, 1)]
        for mode in range(4):
            for diag in (0, 1):
                reads, finite = ((0, 0) if mode == 0 else (4, 2)) if diag else (-1, -1)
                raw = '\n'.join(f'L3_BATCH_BOUND_NEIGHBORS_CONFIG gpu={g} edge_limit=2 scan_enabled=0\n'
                    f'L3_BATCH_BOUND_NEIGHBORS_AUDIT gpu={g} instrumented={diag} reads={reads} finite={finite}'
                    for g in (0, 1))
                self.assertEqual(len(parse_bound_neighbors(raw, 1, mode, 2, diag, runtime)['audit']), 2)
                for old, new in [('gpu=1', 'gpu=0'), ('scan_enabled=0', 'scan_enabled=1'),
                                 ('edge_limit=2', 'edge_limit=3'), ('reads='+str(reads), 'reads=7'),
                                 ('finite='+str(finite), 'finite=8')]:
                    with self.assertRaises(ValueError):
                        parse_bound_neighbors(raw.replace(old, new), 1, mode, 2, diag, runtime)
                with self.assertRaises(ValueError):
                    parse_bound_neighbors(raw+'\nL3_BATCH_BOUND_NEIGHBORS_AUDIT malformed', 1, mode, 2, diag, runtime)

    def test_publisher_cursor_and_work_conservation(self):
        config = [dict(gpu=g, mirror_bytes=4100) for g in (0, 1)]
        raw = '\n'.join(f'L3_BATCH_BOUND_PUBLISH gpu={g} warp={w} mode=2 vertices=1025 '
            f'loops=3 reads=3072 finite=17 cursor={704 if w == 0 else 32} wraps={5 if w == 0 else 6}'
            for g in (0, 1) for w in (0, 1))
        self.assertEqual(len(parse_bound_publisher(raw, 1, 2, 32, config)), 4)
        for a, z in [('gpu=1', 'gpu=0'), ('warp=1', 'warp=0'), ('cursor=704', 'cursor=768'),
                     ('reads=3072', 'reads=3000'), ('wraps=5', 'wraps=6'), ('finite=17', 'finite=3073'),
                     ('vertices=1025', 'vertices=1024')]:
            with self.assertRaises(ValueError):
                parse_bound_publisher(raw.replace(a, z), 1, 2, 32, config)
        with self.assertRaises(ValueError):
            parse_bound_publisher(raw+'\nL3_BATCH_BOUND_PUBLISH malformed', 1, 2, 32, config)

    def example(self):
        c = cases()[1]
        r = dict(owner=0, query=0, mode=2, status=0, rows=2, counts=[2, 1, 1], tickets=c['tickets'],
                 mirror=[0, INF, 2]+[INF]*9, journal=[[0, 0, 0], [1, 1, 1]])
        return c, r

    def test_witnessed_pruning_resumes(self):
        c, r = self.example()
        self.assertEqual(audit_record(c, r)['pruned'], 1)

    def test_original_roots_are_required(self):
        c, r = self.example()
        r['journal'] = r['journal'][1:]
        with self.assertRaisesRegex(ValueError, 'root removed'):
            audit_record(c, r)

    def test_missing_full_row_successor_rejected(self):
        c, r = self.example()
        r['journal'] = r['journal'][:1]
        with self.assertRaisesRegex(ValueError, 'full-row edge'):
            audit_record(c, r)

    def test_unwitnessed_bound_rejected(self):
        c, r = self.example()
        r['mirror'][1] = 1
        with self.assertRaisesRegex(ValueError, 'mirror/reset/publication'):
            audit_record(c, r)

    def test_external_ticket_cannot_disappear(self):
        c, r = self.example()
        r['tickets'] = []
        with self.assertRaisesRegex(ValueError, 'responsibilities lost'):
            audit_record(c, r)

    def test_external_work_cannot_hide_impossible_return_path(self):
        c, r = self.example()
        r['journal'].append([7, 8, INF])
        with self.assertRaisesRegex(ValueError, 'journal/certificate has no path witness'):
            audit_record(c, r)

    def test_certificate_must_have_its_own_path_witness(self):
        c, r = self.example()
        r['journal'][1][2] = 2
        with self.assertRaisesRegex(ValueError, 'journal/certificate has no path witness'):
            audit_record(c, r)

    def test_rows_cannot_omit_certified_expansions(self):
        c, r = self.example()
        r['rows'] = 0
        with self.assertRaisesRegex(ValueError, 'row count/budget inconsistent'):
            audit_record(c, r)

    def test_longer_actual_path_is_valid(self):
        c = cases()[2]
        self.assertTrue(path_witnesses(c, c['roots'], [(2, 2), (2, 9)]))
        self.assertFalse(path_witnesses(c, c['roots'], [(2, 8)]))

    def test_new_query_cannot_reuse_old_low_bound(self):
        c, r = self.example()
        r.update(query=1, tickets=[], journal=[[0, 100, 100], [1, 101, 101]])
        with self.assertRaisesRegex(ValueError, 'mirror/reset/publication'):
            audit_record(c, r)

    def test_read_only_mode_cannot_omit_successor(self):
        c, r = self.example()
        r.update(mode=1, counts=[2, 1, 0])
        with self.assertRaisesRegex(ValueError, 'full-row edge'):
            audit_record(c, r)

    def test_remote_edge_cannot_use_bound(self):
        c, r = self.example()
        c['edges'].append([0, 11, 1]);c['end']=10;r['mirror']=r['mirror'][:10]
        with self.assertRaisesRegex(ValueError, 'full-row edge'):
            audit_record(c, r)

    def test_counter_modes_and_malformed_records(self):
        for mode in range(4):
            for diag in (0, 1):
                count = (-1, -1, -1) if not diag else ((8, 3, 3 if mode == 2 else 0) if mode in (1, 2) else (0, 0, 0))
                raw = '\n'.join(f'L3_BATCH_BOUND_CONFIG gpu={g} mode={mode} steps=32 peer_bound=1 mirror_bytes=8192\n'
                    f'L3_BATCH_BOUND_AUDIT gpu={g} mode={mode} instrumented={diag} checks={count[0]} covered={count[1]} pruned={count[2]}' for g in (0, 1))
                self.assertEqual(len(parse_bound(raw, 1, mode, 32, diag)['audit']), 2)
                for bad in (raw.replace('gpu=1', 'gpu=0'), raw+'\nL3_BATCH_BOUND_AUDIT malformed',
                            raw.replace('peer_bound=1', 'peer_bound=0'), raw.replace('steps=32', 'steps=64'),
                            raw.replace('pruned='+str(count[2]), 'pruned=99'), raw.replace('mirror_bytes=8192', 'mirror_bytes=8193')):
                    with self.assertRaises(ValueError):
                        parse_bound(bad, 1, mode, 32, diag)


if __name__ == '__main__':
    unittest.main()
