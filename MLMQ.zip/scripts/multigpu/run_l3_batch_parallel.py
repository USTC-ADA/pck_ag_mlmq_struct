#!/usr/bin/env python3
"""Fail-stop differential, real-DQ/peer, remote and real-SLF checks of new owner."""
import argparse
from pathlib import Path
from run_l3_batch_runtime import verify_tree, execute
from run_l3_batch_peer_commit import parse_cases as parse_peer
from run_l3_batch_remote_commit import parse_cases as parse_remote
from run_l3_batch_l1_donor import parse_cases as parse_l1
from run_l3_compact_screen import sanitizer_passed
from run_usa_road_matrix import gpu_snapshot
from run_l3_upgrade_stage2 import clean_environment, slurm_preflight, write_json, sha256

PACKED_PASS = 'BATCH_PACKED_INDEX_PASS devices=2 warps_per_device=64 rounds=12 positions=768 decoded=1179648 old_workspace=16020 packed_workspace=15444'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('build', 'out', 'sanitizer'):
        parser.add_argument('--' + name, required=True, type=Path)
    args = parser.parse_args()
    build = args.build.resolve(strict=True)
    bm = verify_tree(build)
    if Path(__file__).resolve() != build / 'source/scripts/multigpu/run_l3_batch_parallel.py':
        parser.error('use frozen runner')
    args.out.mkdir(parents=True, exist_ok=False)
    out = args.out.resolve()
    sanitizer = args.sanitizer.resolve(strict=True)
    manifest = {'build': str(build), 'snapshot': bm, 'allocation': slurm_preflight(out),
                'sanitizer': str(sanitizer), 'sanitizer_sha256': sha256(sanitizer)}
    write_json(out / 'manifest.json', manifest)
    results = {}
    env = clean_environment()
    env['CUDA_MODULE_LOADING'] = 'EAGER'
    first = 'packed' if bm.get('packed_compact') else 'differential'
    for kind, parse in ((first, None), ('peer', parse_peer), ('remote', parse_remote), ('l1', parse_l1)):
        for tool in (None, 'memcheck', 'racecheck', 'synccheck'):
            name = kind + '_' + (tool or 'normal')
            command = [str(build / (kind + '_sm80'))]
            journals = out / (name + '_journals')
            if parse:
                journals.mkdir()
                command += [str(journals)] + (['--quick'] if tool else [])
            if tool:
                command = [str(sanitizer), '--tool', tool, '--error-exitcode', '9'] + command
            command = ['/usr/bin/stdbuf', '-oL', '-eL'] + command
            record = {'state': 'running', 'command': command, 'environment': env}
            results[name] = record
            write_json(out / 'status.json', {'complete': False, 'results': results})
            print('RUN', name, flush=True)
            try:
                snapshot, apps = gpu_snapshot()
                (out / (name + '.gpu_before.log')).write_text(snapshot)
                if apps:
                    raise ValueError('compute apps present')
                record['rc'] = execute(command, env, out / (name + '.log'), 300)
                raw = (out / (name + '.log')).read_text()
                if record['rc'] or not sanitizer_passed(raw, tool):
                    raise ValueError('fixture or sanitizer failed')
                if parse:
                    record['cases'] = parse(raw, bool(tool))
                    for suffix in ('journal', 'audit'):
                        paths = sorted(journals.glob('*.' + suffix + '.txt'))
                        if len(paths) != len(record['cases']) or any(not p.stat().st_size for p in paths):
                            raise ValueError('missing ' + suffix)
                    record['raw_artifacts'] = {p.name: sha256(p) for p in journals.iterdir()}
                elif kind == 'packed':
                    if raw.splitlines().count(PACKED_PASS) != 1:
                        raise ValueError('missing packed-index coverage')
                elif raw.splitlines().count('BATCH_PARALLEL_DIFFERENTIAL_PASS cases=384 valid=32 rejected=352 sticky_competitor=1 hash_collision=1') != 1:
                    raise ValueError('missing differential coverage')
                snapshot, apps = gpu_snapshot()
                (out / (name + '.gpu_after.log')).write_text(snapshot)
                if apps:
                    raise ValueError('compute apps remain')
                record['state'] = 'passed'
            except Exception as error:
                record.update(state='failed', error=str(error))
                write_json(out / 'status.json', {'complete': False, 'results': results})
                raise
            print('PASS', name, flush=True)
            write_json(out / 'status.json', {'complete': False, 'results': results})
    verify_tree(build)
    if sha256(sanitizer) != manifest['sanitizer_sha256']:
        raise ValueError('sanitizer changed')
    write_json(out / 'summary.json', {'valid': True, 'results': results, 'performance_evidence': False})
    write_json(out / 'status.json', {'complete': True, 'results': results})
    print('BATCH_PARALLEL_FIXTURES_PASS performance_evidence=0', flush=True)


if __name__ == '__main__':
    main()
