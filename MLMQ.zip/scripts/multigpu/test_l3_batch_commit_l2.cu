// Production delta queue write/manager/read/update_done, with one producer,
// one manager, one CSR consumer in separate blocks. No solver/peer integration.
#include <cuda_runtime.h>
#include <cuda/atomic>
#include <cassert>
#include <cstdio>
#include "adaptive.h"
#include "warp_primitive.h"
#ifndef L3_COMMIT_TEST_DQ_PREINCLUDED
#include "../../core/cu_delta_queue/cu_delta_queue.cuh"
#endif
#include "../../SSSP/l3/l3_batch_commit_warp.cuh"
#define L3_COMMIT_TEST_LIBRARY
#include "test_l3_batch_commit.cpp"

#if DQ_COUNTER_OVERFLOW_GUARD != true
#error "This fixture must preserve the production fail-stop capacity guard"
#endif
__device__ unsigned long long g_dq_clamp;
#ifdef L3_TEST_PARALLEL_OWNER
#include "test_l3_batch_parallel_adapter.cuh"
namespace bw = l3_test_commit_warp;
#else
namespace bw = l3_batch_commit_warp;
#endif
#define CUDA(call) do { auto rc = (call); if (rc != cudaSuccess) throw std::runtime_error(cudaGetErrorString(rc)); } while (0)
struct Item {
    int id, dist; // identical 8-byte layout and one-based IDs to node_struct
    __host__ __device__ Item() = default;
    __host__ __device__ Item(int v, int d) : id(v), dist(d) {}
    __device__ int get_data() { return dist; }
};
using Queue = l2_delta_queue<Item>;
struct Batch { int root, root_distance, seed_count, count, fallback; bc::record journal[768]; };
struct Stats {
    int bootstrapped, producer_done, stop, retired, generations;
    int held_prepared, consumed_before_ack, flushes, max_pack, remote_rejected;
    int drain_request, drain_receipt;
};
struct Device {
    int vertices, rounds;
    int *rows, *columns, *weights, *distance;
    int *expected, *seen; // test-only multiplicities, NOT algorithm state
    Batch *batches;
    bc::state<> *commit;
    bc::donor_ledger *donor;
    bw::intent *pending;
    Stats *stats;
};
template<class T> static T *allocate(int count) {
    T *p = nullptr; CUDA(cudaMalloc(&p, sizeof(T) * count)); CUDA(cudaMemset(p, 0, sizeof(T) * count)); return p;
}
__device__ int load(const int *p) {
    return cuda::atomic_ref<int, cuda::thread_scope_device>(*const_cast<int *>(p)).load(cuda::memory_order_acquire);
}
__device__ void store(int *p, int value) {
    cuda::atomic_ref<int, cuda::thread_scope_device>(*p).store(value, cuda::memory_order_release);
}
__device__ void deadline(unsigned long long start) { assert(clock64() - start < 180000000000ull); }

// Read exactly one whole 8-record claim. No abandoned speculative read claims
// are transferred from this bootstrap kernel to the subsequent consumer.
__global__ void bootstrap(Queue q, Device d) {
    const int lane = threadIdx.x;
    __shared__ Item items[32];
    if (!lane) q.device_init(0, 0, 0);
    __syncwarp();
    items[lane] = Item(1, 0);
    __syncwarp();
    int count = 8;
    assert(q.write(items, count, 0, 0, lane, nullptr) == WRITE_SUCCESS);
    for (int bucket = 0; bucket < q.bucketNum; ++bucket) q.manager_run(bucket, lane);
    q.update_local_info(lane);
    int read = 0;
    q.read(items, read, 0, 0, lane, nullptr);
    assert(read == 8);
    if (!lane) {
        assert(q.get_queue_size() == 8); // read but NOT completed
        bc::initialize(*d.commit);
        *d.donor = {8, 0, false};
        d.stats->bootstrapped = 8;
    }
    bw::initialize(*d.pending, lane);
}

__global__ void pipeline(Queue q, Device d) {
    const int lane = threadIdx.x;
    __shared__ Item scratch[32], input[32];
    __shared__ bc::seed roots[512];
    const auto start = clock64();
    if (blockIdx.x == 0) {
        auto &s = *d.commit; auto &intent = *d.pending; auto &donor = *d.donor;
        for (int round = 0; round < d.rounds; ++round) {
            const auto &batch = d.batches[round];
            const auto generation = s.generation;
            for (int i = lane; i < batch.seed_count; i += 32)
                roots[i] = {batch.root, atomicAdd(d.distance + batch.root, 0)};
            __syncwarp();
            if (!lane) {
                assert(bc::reserve(s, generation, donor, roots, batch.seed_count, 0, d.vertices, d.vertices));
                assert(bc::retire_if_idle(donor, true) == 0);
                if (batch.fallback) {
                    assert(!bc::accept_journal(s, generation, batch.journal, 0));
                    assert(donor.outstanding == 1);
                    assert(bc::start_fallback(s, generation));
                } else assert(bc::accept_journal(s, generation, batch.journal, batch.count));
            }
            __syncwarp();
            bool waited_for_consumer = false;
            while (s.stage != bc::phase::finished) {
                deadline(start);
                bw::prepare(s, generation, intent, d.distance, lane);
                if (intent.status != bw::publication::empty) {
                    assert(!intent.remote || intent.count == 0); // real remote adapter remains unimplemented
                    if (intent.status == bw::publication::prepared) {
                        // Frozen intent repeated before publication must not
                        // advance the state or release its ancestor obligation.
                        for (int retry = 0; retry < 3; ++retry) {
                            assert(bw::prepare(s, generation, intent, d.distance, lane) == bc::result::blocked);
                            if (!lane) { assert(bc::retire_if_idle(donor, true) == 0); ++d.stats->held_prepared; }
                            __syncwarp();
                        }
                        for (int i = lane; i < intent.count; i += 32) atomicAdd(d.expected + intent.items[i].vertex, 1);
                        if (!lane) { ++d.stats->flushes; d.stats->max_pack = max(d.stats->max_pack, intent.count); }
                        assert(!bw::publish_l2(s, generation + 1, intent, q, scratch, 0, 0, lane));
                        assert(bw::publish_l2(s, generation, intent, q, scratch, 0, 0, lane));
                        // Published receipt retry must NOT append the same output.
                        assert(bw::publish_l2(s, generation, intent, q, scratch, 0, 0, lane));
                        if (!waited_for_consumer) {
                            // All issued outputs and descendants are consumed,
                            // but the pending receipt must still retain 8 ancestors.
                            // A producer-side multi-counter snapshot is NOT a
                            // drain proof. Pause this writer and ask the sole
                            // consumer to check at its own quiescent row boundary.
                            if (!lane) store(&d.stats->drain_request, round + 1);
                            __syncwarp();
                            while (load(&d.stats->drain_receipt) < round + 1) deadline(start);
                            __syncwarp();
                            if (!lane) { assert(donor.outstanding == 1); assert(bc::retire_if_idle(donor, true) == 0); ++d.stats->consumed_before_ack; }
                            waited_for_consumer = true;
                        }
                    }
                    __syncwarp();
                    if (!lane) {
                        assert(!bw::acknowledge(s, generation + 1, intent));
                        assert(bw::acknowledge(s, generation, intent));
                        assert(!bw::acknowledge(s, generation, intent));
                    }
                    __syncwarp();
                }
            }
            if (!lane) {
                ++d.stats->generations;
                const int credit = bc::retire_if_idle(donor, round + 1 == d.rounds);
                if (round + 1 != d.rounds) assert(credit == 0); // unexported L1 roots remain
                else { assert(credit == 8); q.update_done(credit); d.stats->retired = credit; }
                assert(intent.status == bw::publication::empty);
                assert(bc::recycle(s, generation));
            }
            __syncwarp();
            assert(bw::prepare(s, generation, intent, d.distance, lane) == bc::result::stale);
        }
        if (!lane) store(&d.stats->producer_done, 1);
    } else if (blockIdx.x == 1) {
        while (!load(&d.stats->stop)) {
            for (int bucket = 0; bucket < q.bucketNum; ++bucket) q.manager_run(bucket, lane);
            deadline(start);
        }
    } else {
        if (!lane) q.device_init(2, 0, 0);
        __syncwarp();
        while (true) {
            q.update_local_info(lane);
            int count = 0;
            q.read(input, count, 2, 0, lane, nullptr);
            for (int i = 0; i < count; ++i) {
                const int vertex = input[i].id - 1;
                assert(vertex >= 0 && vertex < d.vertices);
                if (!lane) atomicAdd(d.seen + vertex, 1);
                const int distance = atomicAdd(d.distance + vertex, 0);
                assert(distance <= input[i].dist);
                for (int base = d.rows[vertex]; base < d.rows[vertex + 1]; base += 32) {
                    const int edge = base + lane;
                    int target = -1, candidate = INT_MAX;
                    bool win = false;
                    if (edge < d.rows[vertex + 1]) {
                        target = d.columns[edge]; const int weight = d.weights[edge];
                        if (distance < INT_MAX - weight) candidate = distance + weight;
                        win = candidate < atomicMin(d.distance + target, candidate);
                    }
                    const unsigned selected = __ballot_sync(FULL_MASK, win);
                    const int position = __popc(selected & (lane ? (1u << lane) - 1u : 0u));
                    if (win) { scratch[position] = Item(target + 1, candidate); atomicAdd(d.expected + target, 1); }
                    __syncwarp();
                    int output_count = __popc(selected);
                    if (output_count) assert(q.write(scratch, output_count, 2, 0, lane, nullptr) == WRITE_SUCCESS);
                    __syncwarp();
                }
            }
            __syncwarp();
            if (!lane && count) q.update_done(count); // only AFTER all CSR outputs are published
            __syncwarp();
            int done = 0;
            if (!lane) {
                const int request = load(&d.stats->drain_request);
                if (request > load(&d.stats->drain_receipt) && q.get_queue_size() == 8)
                    store(&d.stats->drain_receipt, request);
                done = load(&d.stats->producer_done) && q.get_queue_size() == 0;
            }
            done = __shfl_sync(FULL_MASK, done, 0);
            if (done) { if (!lane) store(&d.stats->stop, 1); break; }
            deadline(start);
        }
    }
}

// Nonempty remote windows must never be silently written to local L2 or acked.
__global__ void remote_guard(Queue q, Device d) {
    const int lane = threadIdx.x;
    __shared__ Item scratch[32];
    __shared__ bc::seed seed;
    __shared__ bc::record journal[2];
    if (!lane) {
        seed = {0, 0}; journal[0] = {0, 0, 0}; journal[1] = {1, 1, INT_MAX};
        bc::initialize(*d.commit); *d.donor = {8, 0, false};
        assert(bc::reserve(*d.commit, 1, *d.donor, &seed, 1, 0, 1, 2));
        assert(bc::accept_journal(*d.commit, 1, journal, 2));
    }
    __syncwarp(); bw::initialize(*d.pending, lane);
    for (int i = 0; i < 3; ++i) bw::prepare(*d.commit, 1, *d.pending, d.distance, lane);
    assert(d.pending->remote && d.pending->count == 1);
    assert(!bw::publish_l2(*d.commit, 1, *d.pending, q, scratch, 0, 0, lane));
    if (!lane) {
        assert(!bw::acknowledge(*d.commit, 1, *d.pending));
        assert(bc::retire_if_idle(*d.donor, true) == 0);
        d.stats->remote_rejected = 1;
    }
}

static Queue make_queue(std::vector<void *> &allocations, int first) {
    Queue q{}; q.bucketNum = 4; q.bucket_max = 4; q.batchSize = 8;
    q.total_size = 262144; q.total_block_size = q.total_size / MEM_BLOCK_SIZE; q.delta = 7; q.shmem_offset = 0;
    q.data = allocate<Item>(q.total_size * q.bucketNum); allocations.push_back(q.data);
    q.block_write_done = allocate<int>(q.total_block_size * q.bucketNum); allocations.push_back(q.block_write_done);
    for (auto ptr : {&q.read_pos, &q.read_ptr, &q.bucket_read_done, &q.write_reserve, &q.last_read_warp}) {
        *ptr = allocate<int>(q.bucketNum); allocations.push_back(*ptr);
    }
    for (auto ptr : {&q.debug_write_done, &q.counter_overflow, &q.read_done, &q.first_pos,
                     &q.read_size, &q.run_begin}) { *ptr = allocate<int>(1); allocations.push_back(*ptr); }
    CUDA(cudaMemcpy(q.first_pos, &first, sizeof(int), cudaMemcpyHostToDevice));
    return q;
}

__global__ void capacity_fill(Queue q, int batches) {
    __shared__ Item items[32];
    const int lane = threadIdx.x;
    items[lane] = Item(lane + 1, 0);
    __syncwarp();
    for (int b = 0; b < batches; ++b) {
        int count = 32;
        assert(q.write(items, count, 0, 0, lane, nullptr) == WRITE_SUCCESS);
    }
}

static void expected_overflow(int gpu) {
    CUDA(cudaSetDevice(gpu));
    std::vector<void *> allocations;
    auto q = make_queue(allocations, 0);
    q.total_size = 1024; q.total_block_size = 2;
    // Logical capacity is reduced; backing allocations remain larger. The
    // expected trap must come from the authoritative guard, not an OOB access.
    capacity_fill<<<1, 32>>>(q, 32); CUDA(cudaGetLastError()); CUDA(cudaDeviceSynchronize());
    int reserved = 0, published = 0, overflow = -1;
    CUDA(cudaMemcpy(&reserved, q.write_reserve, 4, cudaMemcpyDeviceToHost));
    CUDA(cudaMemcpy(&published, q.debug_write_done, 4, cudaMemcpyDeviceToHost));
    CUDA(cudaMemcpy(&overflow, q.counter_overflow, 4, cudaMemcpyDeviceToHost));
    CHECK(reserved == 1024 && published == 1024 && overflow == 0);
    std::cout << "DQ_CAPACITY_EXACT_PASS gpu=" << gpu << " records=1024\n" << std::flush;
    capacity_fill<<<1, 32>>>(q, 1); CUDA(cudaGetLastError());
    const auto result = cudaDeviceSynchronize();
    std::cout << "DQ_CAPACITY_OBSERVED gpu=" << gpu << " cuda_rc=" << int(result)
              << " error=" << cudaGetErrorString(result) << '\n' << std::flush;
    // PTX trap specifies kernel abort, not a single CUDA Runtime error code.
    // Accept only these fatal execution categories, not success/unknown/OOM.
    CHECK(result == cudaErrorIllegalInstruction || result == cudaErrorLaunchFailure);
    std::cout << "DQ_CAPACITY_EXPECTED_TRAP_PASS gpu=" << gpu << " attempted=1056 capacity=1024 cuda_rc="
              << int(result) << "\n" << std::flush;
    CUDA(cudaDeviceReset()); // dispose only this test process's poisoned context
}

static void run_case(int gpu, int group_size, int rounds, int first, bool fallback) {
    CUDA(cudaSetDevice(gpu));
    Graph graph(1 + group_size * rounds);
    std::vector<int> initial(graph.size(), INT_MAX); initial[0] = 0;
    std::vector<Batch> batches(rounds);
    std::mt19937 rng(4000u + group_size + first);
    for (int round = 0; round < rounds; ++round) {
        const int root = 1 + round * group_size;
        graph[0].push_back({root, round % 11}); initial[root] = round % 11;
        for (int v = 0; v < group_size; ++v) {
            for (int e = 0; e < 3; ++e) graph[root + v].push_back({root + int(rng() % group_size), int(rng() % 31)});
            graph[root + v].push_back({root + (v + 1) % group_size, 0});
        }
        // Dense source gives full/partial packs and a 768-record maximum case.
        for (int v = 1; v < group_size; ++v) graph[root].push_back({root + v, 20 + v % 80});
    }
    for (int round = 0; round < rounds; ++round) {
        auto &batch = batches[round]; batch.root = 1 + round * group_size; batch.root_distance = round % 11;
        batch.seed_count = round % 3 == 0 ? 1 : round % 3 == 1 ? 7 : 512;
        batch.fallback = fallback && round % 3 == 1;
        std::vector<bc::seed> roots(batch.seed_count, {batch.root, batch.root_distance});
        auto journal = helper(graph, roots, 0, int(graph.size()), round % 4 == 0 ? 0 : round % 4 == 1 ? 1 : 32);
        CHECK(journal.size() <= 768); batch.count = int(journal.size());
        std::copy(journal.begin(), journal.end(), batch.journal);
    }
    auto oracle = dijkstra(graph, {{0, 0}});
    std::vector<int> rows{0}, columns, weights;
    for (const auto &edges : graph) { for (auto edge : edges) { columns.push_back(edge.first); weights.push_back(edge.second); } rows.push_back(int(columns.size())); }
    std::vector<void *> allocations;
    auto q = make_queue(allocations, first);
    Device d{}; d.vertices = int(graph.size()); d.rounds = rounds;
    d.rows = allocate<int>(int(rows.size())); allocations.push_back(d.rows);
    d.columns = allocate<int>(int(columns.size())); allocations.push_back(d.columns);
    d.weights = allocate<int>(int(weights.size())); allocations.push_back(d.weights);
    d.distance = allocate<int>(d.vertices); allocations.push_back(d.distance);
    d.expected = allocate<int>(d.vertices); allocations.push_back(d.expected);
    d.seen = allocate<int>(d.vertices); allocations.push_back(d.seen);
    d.batches = allocate<Batch>(rounds); allocations.push_back(d.batches);
    d.commit = allocate<bc::state<>>(1); allocations.push_back(d.commit);
    d.donor = allocate<bc::donor_ledger>(1); allocations.push_back(d.donor);
    d.pending = allocate<bw::intent>(1); allocations.push_back(d.pending);
    d.stats = allocate<Stats>(1); allocations.push_back(d.stats);
    CUDA(cudaMemcpy(d.rows, rows.data(), rows.size() * sizeof(int), cudaMemcpyHostToDevice));
    CUDA(cudaMemcpy(d.columns, columns.data(), columns.size() * sizeof(int), cudaMemcpyHostToDevice));
    CUDA(cudaMemcpy(d.weights, weights.data(), weights.size() * sizeof(int), cudaMemcpyHostToDevice));
    CUDA(cudaMemcpy(d.distance, initial.data(), initial.size() * sizeof(int), cudaMemcpyHostToDevice));
    CUDA(cudaMemcpy(d.batches, batches.data(), rounds * sizeof(Batch), cudaMemcpyHostToDevice));
    bootstrap<<<1, 32, q.get_shm_size()>>>(q, d); CUDA(cudaGetLastError()); CUDA(cudaDeviceSynchronize());
    int resident = 0; CUDA(cudaOccupancyMaxActiveBlocksPerMultiprocessor(&resident, pipeline, 32, q.get_shm_size()));
    cudaDeviceProp prop{}; CUDA(cudaGetDeviceProperties(&prop, gpu));
    CHECK(prop.major == 8 && prop.minor == 0 && resident * prop.multiProcessorCount >= 3);
    pipeline<<<3, 32, q.get_shm_size()>>>(q, d); CUDA(cudaGetLastError()); CUDA(cudaDeviceSynchronize());
    std::vector<int> distance(d.vertices), expected(d.vertices), seen(d.vertices);
    CUDA(cudaMemcpy(distance.data(), d.distance, distance.size() * sizeof(int), cudaMemcpyDeviceToHost));
    CUDA(cudaMemcpy(expected.data(), d.expected, expected.size() * sizeof(int), cudaMemcpyDeviceToHost));
    CUDA(cudaMemcpy(seen.data(), d.seen, seen.size() * sizeof(int), cudaMemcpyDeviceToHost));
    CHECK(distance == oracle && expected == seen);
    Stats stats{}; CUDA(cudaMemcpy(&stats, d.stats, sizeof(stats), cudaMemcpyDeviceToHost));
    CHECK(stats.bootstrapped == 8 && stats.retired == 8 && stats.generations == rounds && stats.stop == 1);
    CHECK(stats.held_prepared > 0 && stats.consumed_before_ack > 0 && stats.max_pack <= 32);
    CHECK(stats.drain_request == rounds && stats.drain_receipt == rounds);
    int reserved[4], consumed[4], published[4], overflow, done, written;
    CUDA(cudaMemcpy(reserved, q.write_reserve, sizeof(reserved), cudaMemcpyDeviceToHost));
    CUDA(cudaMemcpy(consumed, q.bucket_read_done, sizeof(consumed), cudaMemcpyDeviceToHost));
    CUDA(cudaMemcpy(published, q.read_pos, sizeof(published), cudaMemcpyDeviceToHost));
    CUDA(cudaMemcpy(&overflow, q.counter_overflow, 4, cudaMemcpyDeviceToHost));
    CUDA(cudaMemcpy(&done, q.read_done, 4, cudaMemcpyDeviceToHost));
    CUDA(cudaMemcpy(&written, q.debug_write_done, 4, cudaMemcpyDeviceToHost));
    int total = 0; for (int b = 0; b < 4; ++b) { CHECK(reserved[b] == consumed[b] && reserved[b] == published[b]); total += reserved[b]; }
    int expected_total = 8; for (int count : expected) expected_total += count;
    CHECK(total == expected_total && total == done && total == written && !overflow);
    remote_guard<<<1, 32>>>(q, d); CUDA(cudaGetLastError()); CUDA(cudaDeviceSynchronize());
    CUDA(cudaMemcpy(&stats, d.stats, sizeof(stats), cudaMemcpyDeviceToHost)); CHECK(stats.remote_rejected == 1);
    std::cout << "BATCH_COMMIT_L2_CASE gpu=" << gpu << " group=" << group_size << " rounds=" << rounds
              << " first=" << first << " fallback=" << fallback << " total_writes=" << total
              << " flushes=" << stats.flushes << " max_pack=" << stats.max_pack
              << " consumed_before_ack=" << stats.consumed_before_ack << " PASS\n";
    for (auto ptr : allocations) CUDA(cudaFree(ptr));
}

#ifndef L3_COMMIT_L2_TEST_LIBRARY
int main(int argc, char **argv) {
    try {
        CHECK(std::getenv("SLURM_JOB_ID") != nullptr);
        bool quick = argc == 2 && std::string(argv[1]) == "--quick";
        int devices = 0; CUDA(cudaGetDeviceCount(&devices)); CHECK(devices == 2);
        if (argc == 2 && (std::string(argv[1]) == "--overflow0" || std::string(argv[1]) == "--overflow1")) {
            expected_overflow(std::string(argv[1]) == "--overflow0" ? 0 : 1);
            return 0;
        }
        int cases = 0;
        for (int gpu = 0; gpu < devices; ++gpu) {
            for (int group : quick ? std::vector<int>{33, 768} : std::vector<int>{33, 65, 257, 768})
                for (int first : quick ? std::vector<int>{11} : std::vector<int>{0, 11}) {
                    run_case(gpu, group, quick ? 4 : 32, first, true); ++cases;
                }
        }
        std::cout << "BATCH_COMMIT_L2_PASS cases=" << cases << " actual_dq=1 no_peer=1 no_solver=1 not_performance=1\n";
        return 0;
    } catch (const std::exception &e) { std::cerr << "FAIL " << e.what() << '\n'; return 1; }
}
#endif
