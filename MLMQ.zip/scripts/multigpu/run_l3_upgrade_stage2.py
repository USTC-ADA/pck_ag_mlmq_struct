#!/usr/bin/env python3
"""Run the frozen receiver-coalescer ablation inside one two-A100 allocation."""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import socket
import statistics
import struct
import subprocess
import sys

from run_l3_30h import (
    QUEUE_TYPE_IDS,
    parse_dual_contract,
    parse_l2_capacity_contract,
    parse_oracle_contract,
)
from run_usa_road_matrix import run_one


ROOT = Path(__file__).resolve().parents[2]
CONTRACT_PATH = (
    ROOT / "evidence/l3_algorithm_upgrade_20260924/stage2_contract.json"
)
QUEUE = "L1SLF_L2DQ"
BLOCKS = 107
SPEC_FIELDS = (
    "NAME", "GRAPH", "ORACLE", "SOURCE", "DELTA", "CUT_PERCENT",
    "GRAPH_SHA256", "ORACLE_SHA256",
)
COALESCE_FIELDS = (
    "gpu", "offers", "tokens", "queued_updates", "active_updates",
    "unindexed", "claims", "claim_misses", "completed", "requeues",
    "requeue_tokens", "no_work", "state_errors",
)
FINAL_FIELDS = (
    "gpu", "slots", "idle", "queued", "active", "invalid",
    "max_version", "version_step",
)


def now_utc():
    return datetime.now(timezone.utc).isoformat()


def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def write_json(path, value):
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")
    os.replace(temporary, path)


def read_gr_header(path):
    with path.open("rb") as stream:
        raw = stream.read(32)
    if len(raw) != 32:
        raise ValueError(f"short GR header: {path}")
    version, edge_bytes, vertices, edges = struct.unpack("<QQQQ", raw)
    if version != 1 or edge_bytes != 4 or not vertices or vertices >= (1 << 30):
        raise ValueError(f"unsupported tagged-ID GR header: {path}")
    return {"vertices": vertices, "edges": edges}


def load_contract():
    contract = json.loads(CONTRACT_PATH.read_text())
    if contract.get("status") != "frozen_before_stage2_gpu_run":
        raise ValueError("stage2 contract is not frozen")
    for mode, expected in (("screen", (2, 1, 3)), ("formal", (2, 1, 5))):
        row = contract["sampling"][mode]
        observed = (
            row["rounds"], row["warmups_per_process"],
            row["formal_samples_per_process"],
        )
        if observed != expected:
            raise ValueError(f"unsupported {mode} sampling contract: {observed}")
    return contract


def load_specs(raw_specs, contract):
    if not raw_specs or len(raw_specs) != 2:
        raise ValueError("exactly two --spec entries are required: USA then COL")
    specs = []
    for raw in raw_specs:
        name, graph_s, oracle_s, source_s, delta_s, cut_s, graph_sha, oracle_sha = raw
        if name not in contract["graphs"]:
            raise ValueError(f"unexpected graph name: {name}")
        graph = Path(graph_s).resolve(strict=True)
        oracle = Path(oracle_s).resolve(strict=True)
        source, delta, cut = map(int, (source_s, delta_s, cut_s))
        header = read_gr_header(graph)
        observed = {
            **header,
            "graph_sha256": sha256(graph),
            "oracle_sha256": sha256(oracle),
            "source": source,
            "delta": delta,
            "cut_percent": cut,
        }
        supplied = {
            **header,
            "graph_sha256": graph_sha,
            "oracle_sha256": oracle_sha,
            "source": source,
            "delta": delta,
            "cut_percent": cut,
        }
        expected = contract["graphs"][name]
        if observed != expected or supplied != expected:
            raise ValueError(
                f"{name} input differs from frozen contract: "
                f"observed={observed} supplied={supplied} expected={expected}")
        if oracle.stat().st_size != header["vertices"] * 4:
            raise ValueError(f"{name} oracle byte count mismatch")
        specs.append({
            "name": name,
            "graph": graph,
            "oracle": oracle,
            **observed,
        })
    if [row["name"] for row in specs] != ["USA", "COL"]:
        raise ValueError("frozen stage2 graph order is USA then COL")
    return specs


def validate_build(build_dir):
    build_dir = build_dir.resolve(strict=True)
    manifest_path = build_dir / "manifest.json"
    manifest = json.loads(manifest_path.read_text())
    head = subprocess.check_output(
        ["git", "-C", str(ROOT), "rev-parse", "HEAD"], text=True).strip()
    status = subprocess.check_output(
        ["git", "-C", str(ROOT), "status", "--porcelain=v1"], text=True)
    if status:
        raise ValueError("stage2 GPU run requires a clean committed worktree")
    if manifest.get("status") != "complete" or manifest.get("head") != head:
        raise ValueError("stage2 build manifest does not match current HEAD")
    if manifest.get("git_status"):
        raise ValueError("stage2 build was not produced from a clean worktree")
    if (manifest.get("architecture") != "sm_80" or
            manifest.get("worker_threads") != 512 or
            not manifest.get("command_contract", {}).get(
                "only_treatment_macro_differs")):
        raise ValueError("stage2 build configuration or attribution is invalid")
    resources = manifest.get("resources", {})
    for role in ("treatment", "diagnostic"):
        if resources.get(role, {}).get("registers", 10**9) > 96:
            raise ValueError(f"{role} worker resource gate failed")
    binaries = {}
    for role, relative in manifest["roles"].items():
        path = (build_dir / relative).resolve(strict=True)
        if sha256(path) != manifest["artifacts"][relative]["sha256"]:
            raise ValueError(f"changed build artifact: {relative}")
        binaries[role] = path
    for relative in (
            "command_contract.json", "source.tgz",
            "tools/test_rx_versioned_coalesce.log",
            "tools/rx_coalesce_model_result.json",
            "tools/cuda_fixture_command.json",
            "tools/cuda_fixture_build.log"):
        path = (build_dir / relative).resolve(strict=True)
        if sha256(path) != manifest["artifacts"][relative]["sha256"]:
            raise ValueError(f"changed build evidence: {relative}")
    return build_dir, manifest_path, manifest, binaries


def command_capture(output, name, command, timeout=60, environment=None):
    result = subprocess.run(
        command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        text=True, timeout=timeout, env=environment)
    (output / f"{name}.log").write_text(
        result.stdout + f"\nRUN_RC={result.returncode}\n")
    return result


def slurm_preflight(output):
    if not os.environ.get("SLURM_JOB_ID"):
        raise ValueError("stage2 must run inside Slurm")
    if os.environ.get("SLURM_JOB_PARTITION") != "a100":
        raise ValueError(
            f"expected a100 partition, got {os.environ.get('SLURM_JOB_PARTITION')!r}")
    query = command_capture(
        output, "gpu_query",
        ["nvidia-smi", "--query-gpu=index,uuid,name,compute_cap",
         "--format=csv,noheader,nounits"])
    rows = [line.strip() for line in query.stdout.splitlines() if line.strip()]
    if (query.returncode or len(rows) != 2 or
            any("A100" not in row or not row.endswith(", 8.0") for row in rows)):
        raise ValueError(f"expected exactly two allocated A100 GPUs, got {rows}")
    uuids = [row.split(",")[1].strip() for row in rows]
    if len(set(uuids)) != 2 or any(not value.startswith("GPU-") for value in uuids):
        raise ValueError(f"expected two distinct GPU UUIDs, got {uuids}")
    apps = command_capture(
        output, "gpu_apps_initial",
        ["nvidia-smi", "--query-compute-apps=pid", "--format=csv,noheader"])
    if apps.returncode or apps.stdout.strip():
        raise ValueError(f"GPU compute process present before run: {apps.stdout!r}")
    captured = {}
    for name, command in (
        ("nvidia_smi_initial", ["nvidia-smi"]),
        ("gpu_topology", ["nvidia-smi", "topo", "-m"]),
        ("slurm_job_running", [
            "scontrol", "show", "job", os.environ["SLURM_JOB_ID"]]),
    ):
        result = command_capture(output, name, command)
        if result.returncode:
            raise ValueError(f"preflight command failed: {name}")
        captured[name] = result.stdout
    if "NV" not in captured["gpu_topology"]:
        raise ValueError("allocated A100 pair does not report NVLink topology")
    return {"job_id": os.environ["SLURM_JOB_ID"], "gpus": rows}


def clean_environment():
    environment = {
        key: value for key, value in os.environ.items()
        if key.startswith("SLURM_") or key in (
            "CUDA_VISIBLE_DEVICES", "CUDA_DEVICE_ORDER", "TZ", "TMPDIR")
    }
    environment.update({
        "PATH": "/usr/local/cuda/bin:/usr/bin:/bin",
        "LANG": "C",
        "LC_ALL": "C",
        "MLMQ_BENCH": "1",
        "MLMQ_WORK_BLOCKS": str(BLOCKS),
        "BENCH_QUEUE": QUEUE,
        "MLMQ_FINAL_AUDIT": "failure",
    })
    environment.pop("CUDA_LAUNCH_BLOCKING", None)
    return environment


def parse_integer_lines(raw, prefix, fields, expected):
    rows = []
    for line in raw.splitlines():
        if not line.startswith(prefix + " "):
            continue
        pairs = re.findall(r"([a-zA-Z0-9_]+)=(-?\d+)", line)
        values = {key: int(value) for key, value in pairs}
        reconstructed = prefix + " " + " ".join(
            f"{key}={value}" for key, value in pairs)
        if tuple(values) != fields or reconstructed != line:
            raise ValueError(f"malformed {prefix} line: {line!r}")
        rows.append(values)
    if len(rows) != expected:
        raise ValueError(f"expected {expected} {prefix} rows, got {len(rows)}")
    if expected == 2 and sorted(row["gpu"] for row in rows) != [0, 1]:
        raise ValueError(f"expected one {prefix} row per GPU")
    return rows


def parse_setup(raw, expected):
    pattern = re.compile(
        r"^L3_RX_COALESCE_SETUP gpu=(\d+) vertices=(\d+) bytes=(\d+)$")
    rows = []
    for line in raw.splitlines():
        if line.startswith("L3_RX_COALESCE_SETUP "):
            match = pattern.fullmatch(line)
            if not match:
                raise ValueError(f"malformed setup line: {line!r}")
            gpu, vertices, byte_count = map(int, match.groups())
            rows.append({"gpu": gpu, "vertices": vertices, "bytes": byte_count})
    if len(rows) != expected:
        raise ValueError(f"expected {expected} setup rows, got {len(rows)}")
    if expected == 2:
        if sorted(row["gpu"] for row in rows) != [0, 1]:
            raise ValueError("setup GPU IDs are not 0 and 1")
        for row in rows:
            if row["vertices"] <= 0 or row["bytes"] != 12 * row["vertices"]:
                raise ValueError(f"invalid sparse setup geometry: {row}")
    return rows


def parse_diagnostics(raw):
    rows = parse_integer_lines(raw, "L3_RX_COALESCE", COALESCE_FIELDS, 2)
    finals = parse_integer_lines(
        raw, "L3_RX_COALESCE_FINAL", FINAL_FIELDS, 2)
    totals = {
        key: sum(row[key] for row in rows)
        for key in COALESCE_FIELDS if key != "gpu"
    }
    for row in rows:
        if (row["offers"] != row["tokens"] + row["queued_updates"] +
                row["active_updates"] + row["unindexed"] or
                row["claims"] != row["completed"] + row["requeues"] or
                row["requeues"] != row["requeue_tokens"] or
                row["claims"] != row["tokens"] + row["requeue_tokens"] or
                row["unindexed"] != 0 or row["claim_misses"] != 0 or
                row["state_errors"] != 0):
            raise ValueError(f"invalid coalescer accounting: {row}")
    for row in finals:
        if (row["slots"] <= 0 or row["idle"] != row["slots"] or
                row["queued"] or row["active"] or row["invalid"] or
                row["version_step"] != 4):
            raise ValueError(f"non-idle final responsibility state: {row}")
    # An ACTIVE update is only a temporary merge when commit emits a requeue
    # token.  Count durable queue records, not just initial IDLE transitions.
    totals["emitted_tokens"] = (
        totals["tokens"] + totals["requeue_tokens"])
    totals["net_suppressed_tokens"] = (
        totals["offers"] - totals["emitted_tokens"])
    totals["net_suppressed_share_of_offers"] = (
        totals["net_suppressed_tokens"] / totals["offers"]
        if totals["offers"] else 0.0)
    return {"per_gpu": rows, "final_per_gpu": finals, "totals": totals}


def run_configuration(*, output, spec, role, binary, gpu_count, round_id,
                      warmups, repeats, timeout, environment,
                      diagnostic, records, expected_worker_recovery=1):
    run_environment = dict(environment)
    run_environment.update({
        "BENCH_SOURCE": str(spec["source"]),
        "BENCH_WARMUPS": str(warmups),
        "BENCH_REPEATS": str(repeats),
        "MLMQ_CUT_PERCENT": str(spec["cut_percent"]),
        "L3_SUPPLEMENT_ORACLE": str(spec["oracle"]),
    })
    prefix = output / f"r{round_id}_{spec['name']}_{role}_s{spec['source']}"
    result = run_one(
        binary, spec["graph"], "MLMQ", gpu_count, prefix,
        run_environment, spec["source"], QUEUE, warmups, repeats,
        timeout, spec["delta"])
    raw = prefix.with_suffix(".log").read_text()
    expected_samples = warmups + repeats
    contracts = {
        "oracle": parse_oracle_contract(
            raw, expected_samples, spec["vertices"])
    }
    errors = list(contracts["oracle"]["errors"])
    if gpu_count == 2:
        contracts["dual"] = parse_dual_contract(
            raw, expected_samples, BLOCKS, spec["delta"],
            QUEUE_TYPE_IDS[QUEUE], expected_window_mode=2,
            expected_window_min=25000, expected_window_max=25000,
            expected_idle_backoff=0, require_l2_final=True,
            expected_worker_recovery=expected_worker_recovery)
        errors.extend(contracts["dual"]["errors"])
    else:
        contracts["single_l2_capacity"] = parse_l2_capacity_contract(
            raw, 1, require_frozen=True)
        errors.extend(contracts["single_l2_capacity"]["errors"])
    mechanism = role in ("C_coalescer", "diagnostic")
    try:
        setup = parse_setup(raw, 2 if mechanism else 0)
    except ValueError as error:
        setup = []
        errors.append(str(error))
    diagnostics = None
    if diagnostic:
        try:
            diagnostics = parse_diagnostics(raw)
        except ValueError as error:
            errors.append(str(error))
    elif "L3_RX_COALESCE gpu=" in raw or "L3_RX_COALESCE_FINAL " in raw:
        errors.append("timed binary emitted diagnostic counters")
    for marker in (
            "Error at node", "ORACLE_MISMATCH", "ORACLE_SIZE_ERROR",
            "FINAL_AUDIT_ERROR", "requirement failed"):
        if marker in raw:
            errors.append(f"solver reported {marker}")
    record = {
        "graph": spec["name"],
        "role": role,
        "round": round_id,
        "gpu_count": gpu_count,
        "warmups": warmups,
        "repeats": repeats,
        "performance_allowed": not diagnostic,
        "log": str(prefix.with_suffix(".log")),
        "setup": setup,
        "diagnostics": diagnostics,
        "contracts": contracts,
        "errors": errors,
        **result,
    }
    if errors:
        record["valid"] = False
        record["reason"] = record.get("reason", "unknown") + "; " + "; ".join(errors)
    records.append(record)
    write_json(output / "records.json", records)
    if not record["valid"] or record["rc"] != 0:
        raise RuntimeError(f"retained failed run {prefix}: {record['reason']}")
    print(json.dumps({
        "graph": spec["name"], "role": role, "round": round_id,
        "solve_ms": [row["solve_ms"] for row in result["samples"]],
        "query_wall_ms": [row["query_wall_ms"] for row in result["samples"]],
    }), flush=True)
    return record


def distribution(values):
    values = [float(value) for value in values]
    ordered = sorted(values)
    quartiles = statistics.quantiles(ordered, n=4, method="inclusive")
    center = statistics.median(ordered)
    return {
        "samples": values,
        "count": len(values),
        "median": center,
        "q1": quartiles[0],
        "q3": quartiles[2],
        "iqr": quartiles[2] - quartiles[0],
        "mad": statistics.median(abs(value - center) for value in ordered),
        "minimum": ordered[0],
        "maximum": ordered[-1],
    }


def summarize(records, specs, sampling, contract):
    result = {"sampling": sampling, "graphs": {}}
    roles = ("A_single", "B_control", "C_coalescer")
    for spec in specs:
        graph = spec["name"]
        graph_result = {"roles": {}}
        selected_by_role = {}
        for role in roles:
            selected = [
                record for record in records
                if record["graph"] == graph and record["role"] == role
                and record["performance_allowed"]
            ]
            if len(selected) != 2:
                raise RuntimeError(f"expected two timed processes for {graph}/{role}")
            selected_by_role[role] = sorted(selected, key=lambda row: row["round"])
            formal = [
                row for record in selected for row in record["samples"]
                if row.get("warmup") == "0"
            ]
            graph_result["roles"][role] = {
                metric: distribution(row[metric] for row in formal)
                for metric in ("solve_ms", "query_wall_ms")
            }
            for metric in ("solve_ms", "query_wall_ms"):
                graph_result["roles"][role][f"round_{metric}_medians"] = [
                    statistics.median(
                        float(row[metric]) for row in record["samples"]
                        if row.get("warmup") == "0")
                    for record in selected_by_role[role]
                ]
        ratios = {}
        for metric in ("solve_ms", "query_wall_ms"):
            values = {
                role: graph_result["roles"][role][metric]["median"]
                for role in roles
            }
            round_ratios = []
            for round_id in range(2):
                control = graph_result["roles"]["B_control"][
                    f"round_{metric}_medians"][round_id]
                treatment = graph_result["roles"]["C_coalescer"][
                    f"round_{metric}_medians"][round_id]
                round_ratios.append(control / treatment)
            ratios[metric] = {
                "matched_control_over_coalescer": (
                    values["B_control"] / values["C_coalescer"]),
                "single_over_coalescer": (
                    values["A_single"] / values["C_coalescer"]),
                "matched_round_ratios": round_ratios,
                "target_1_20_met": (
                    values["A_single"] / values["C_coalescer"] >= 1.20),
            }
        diagnostics = [
            record for record in records
            if record["graph"] == graph and record["role"] == "diagnostic"
        ]
        if len(diagnostics) != 1 or diagnostics[0]["diagnostics"] is None:
            raise RuntimeError(f"expected one diagnostic record for {graph}")
        graph_result["ratios"] = ratios
        graph_result["diagnostics"] = diagnostics[0]["diagnostics"]
        graph_result["setup"] = diagnostics[0]["setup"]
        result["graphs"][graph] = graph_result

    rule = contract["screen_advance_rule"]
    usa = result["graphs"]["USA"]["ratios"]["query_wall_ms"]
    col = result["graphs"]["COL"]["ratios"]["query_wall_ms"]
    result["screen_advance"] = (
        usa["matched_control_over_coalescer"] >=
            rule["USA_overall_matched_query_wall_ratio_min"] and
        all(value > rule["USA_each_round_matched_query_wall_ratio_strictly_above"]
            for value in usa["matched_round_ratios"]) and
        col["matched_control_over_coalescer"] >=
            rule["COL_overall_matched_query_wall_ratio_min"]
    )
    result["all_correct"] = all(record["valid"] for record in records)
    result["target_1_20_met_on_all_graphs"] = all(
        row["ratios"]["query_wall_ms"]["target_1_20_met"]
        for row in result["graphs"].values())
    return result


def parse_args(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--build-dir", required=True, type=Path)
    parser.add_argument("--spec", action="append", nargs=8, metavar=SPEC_FIELDS)
    parser.add_argument("--sampling", choices=("screen", "formal"), default="screen")
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("--timeout", type=int, default=900)
    args = parser.parse_args(argv)
    if args.timeout <= 0:
        parser.error("timeout must be positive")
    if args.out.exists() or args.out.is_symlink():
        parser.error(f"output already exists: {args.out}")
    try:
        args.contract = load_contract()
        args.specs = load_specs(args.spec, args.contract)
    except (OSError, ValueError) as error:
        parser.error(str(error))
    return args


def main(argv=None):
    args = parse_args(argv)
    build_dir, build_manifest_path, build_manifest, binaries = validate_build(
        args.build_dir)
    output = args.out.resolve(strict=False)
    output.mkdir(parents=True)
    allocation = slurm_preflight(output)
    environment = clean_environment()
    sampling_row = args.contract["sampling"][args.sampling]
    rounds = sampling_row["rounds"]
    warmups = sampling_row["warmups_per_process"]
    repeats = sampling_row["formal_samples_per_process"]
    manifest = {
        "schema": 1,
        "status": "running",
        "created_utc": now_utc(),
        "host": socket.gethostname(),
        "invocation": [sys.executable, str(Path(__file__).resolve()), *sys.argv[1:]],
        "allocation": allocation,
        "git_head": build_manifest["head"],
        "git_branch": build_manifest["branch"],
        "contract": {"path": str(CONTRACT_PATH), "sha256": sha256(CONTRACT_PATH)},
        "build_dir": str(build_dir),
        "build_manifest_sha256": sha256(build_manifest_path),
        "binaries": {
            role: {"path": str(path), "sha256": sha256(path)}
            for role, path in binaries.items()
        },
        "configuration": {
            "sampling": args.sampling,
            "rounds": rounds,
            "warmups_per_process": warmups,
            "formal_samples_per_process": repeats,
            "round_1_reversed": True,
            "blocks": BLOCKS,
            "queue": QUEUE,
            "worker_threads": 512,
            "timed_diagnostics": False,
            "primary_timing": args.contract["metrics"]["primary"],
        },
        "inputs": [{
            **{key: value for key, value in spec.items()
               if key not in ("graph", "oracle")},
            "graph": str(spec["graph"]),
            "oracle": str(spec["oracle"]),
        } for spec in args.specs],
    }
    write_json(output / "manifest.json", manifest)
    (output / "runner.py").write_bytes(Path(__file__).read_bytes())

    fixture = command_capture(
        output, "cuda_protocol_fixture", [str(binaries["cuda_fixture"])],
        timeout=120, environment=environment)
    if (fixture.returncode != 0 or
            "queued_active=PASS commit_offer_race=PASS release_acquire=PASS"
            not in fixture.stdout):
        raise RuntimeError("A100 receiver-coalescer protocol fixture failed")

    records = []
    for spec in args.specs:
        run_configuration(
            output=output, spec=spec, role="diagnostic",
            binary=binaries["diagnostic"], gpu_count=2, round_id=-1,
            warmups=0, repeats=1, timeout=args.timeout,
            environment=environment, diagnostic=True, records=records)

    configurations = (
        ("A_single", binaries["control"], 1),
        ("B_control", binaries["control"], 2),
        ("C_coalescer", binaries["treatment"], 2),
    )
    for round_id in range(rounds):
        graph_order = args.specs if round_id == 0 else list(reversed(args.specs))
        config_order = configurations if round_id == 0 else tuple(reversed(configurations))
        for spec in graph_order:
            for role, binary, gpu_count in config_order:
                run_configuration(
                    output=output, spec=spec, role=role, binary=binary,
                    gpu_count=gpu_count, round_id=round_id,
                    warmups=warmups, repeats=repeats, timeout=args.timeout,
                    environment=environment, diagnostic=False, records=records)

    summary = summarize(records, args.specs, args.sampling, args.contract)
    write_json(output / "summary.json", summary)
    apps = command_capture(
        output, "gpu_apps_final",
        ["nvidia-smi", "--query-compute-apps=pid", "--format=csv,noheader"])
    if apps.returncode or apps.stdout.strip():
        raise RuntimeError(f"GPU process remained after stage2: {apps.stdout!r}")
    command_capture(output, "nvidia_smi_final", ["nvidia-smi"])

    errors = []
    final_head = subprocess.check_output(
        ["git", "-C", str(ROOT), "rev-parse", "HEAD"], text=True).strip()
    final_status = subprocess.check_output(
        ["git", "-C", str(ROOT), "status", "--porcelain=v1"], text=True
    ).splitlines()
    if final_head != build_manifest["head"]:
        errors.append("repository HEAD changed during run")
    if final_status:
        errors.append(f"repository became dirty: {final_status}")
    if sha256(build_manifest_path) != manifest["build_manifest_sha256"]:
        errors.append("build manifest changed during run")
    if sha256(CONTRACT_PATH) != manifest["contract"]["sha256"]:
        errors.append("stage2 contract changed during run")
    for role, details in manifest["binaries"].items():
        if sha256(Path(details["path"])) != details["sha256"]:
            errors.append(f"binary changed during run: {role}")
    for spec in args.specs:
        if (sha256(spec["graph"]) != spec["graph_sha256"] or
                sha256(spec["oracle"]) != spec["oracle_sha256"]):
            errors.append(f"input changed during run: {spec['name']}")
    write_json(output / "final_integrity.json", {
        "valid": not errors,
        "git_head": final_head,
        "git_status": final_status,
        "errors": errors,
    })
    if errors:
        raise RuntimeError("final integrity gate failed: " + "; ".join(errors))

    manifest.update(
        status="complete", completed_utc=now_utc(),
        record_count=len(records),
        query_count=sum(len(record["samples"]) for record in records),
        all_correct=summary["all_correct"],
        screen_advance=summary["screen_advance"],
    )
    write_json(output / "manifest.json", manifest)
    write_json(output / "complete.json", {
        "status": "complete",
        "valid": summary["all_correct"],
        "screen_advance": summary["screen_advance"],
        "target_1_20_met_on_all_graphs": summary["target_1_20_met_on_all_graphs"],
    })
    print(
        "L3_UPGRADE_STAGE2_COMPLETE "
        f"sampling={args.sampling} records={len(records)} "
        f"queries={manifest['query_count']} "
        f"advance={int(summary['screen_advance'])}",
        flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
