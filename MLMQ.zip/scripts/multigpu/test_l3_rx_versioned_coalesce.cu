#include <cuda_runtime.h>

#include <cstdlib>
#include <cstdio>
#include <vector>

#define L3_RX_VERSIONED_COALESCE true
#define L3_RX_VERSIONED_COALESCE_DIAG false

#include "../../SSSP/l3/l3_sync.cuh"
#include "../../SSSP/l3/l3_rx_versioned_coalesce.cuh"

static constexpr int FIXTURES = 4096;

__device__ __forceinline__ unsigned long long fixture_state_load(
    unsigned long long *state)
{
    return l3_atomic_load_acquire<cuda::thread_scope_device>(state);
}

__global__ void queued_active_fixture(
    const int *vertices, unsigned long long *states, int *errors)
{
    const int lane = threadIdx.x;
    const int fixture = blockIdx.x;
    __shared__ int created_count;
    __shared__ unsigned long long claimed_version;
    if (lane == 0)
    {
        created_count = 0;
        claimed_version = 0;
    }
    __syncthreads();

    int slot = -1;
    if (l3_rx_coalesce_offer(vertices, states + fixture, 1, 1, slot))
        atomicAdd(&created_count, 1);
    if (slot != 0)
        atomicAdd(errors, 1);
    __syncthreads();

    if (lane == 0)
    {
        const unsigned long long word = fixture_state_load(states + fixture);
        if (created_count != 1 ||
            (word & L3_RX_RESP_STATE_MASK) != L3_RX_RESP_QUEUED ||
            (word & ~L3_RX_RESP_STATE_MASK) !=
                32ull * L3_RX_RESP_VERSION_STEP ||
            !l3_rx_coalesce_claim(
                states + fixture, 0, claimed_version))
            atomicAdd(errors, 1);
    }
    __syncthreads();

    if (lane != 0)
    {
        int active_slot = -1;
        if (l3_rx_coalesce_offer(
                vertices, states + fixture, 1, 1, active_slot))
            atomicAdd(errors, 1);
        if (active_slot != 0)
            atomicAdd(errors, 1);
    }
    __syncthreads();

    if (lane == 0)
    {
        const unsigned long long expected_version =
            63ull * L3_RX_RESP_VERSION_STEP;
        const unsigned long long active = fixture_state_load(states + fixture);
        if ((active & L3_RX_RESP_STATE_MASK) != L3_RX_RESP_ACTIVE ||
            (active & ~L3_RX_RESP_STATE_MASK) != expected_version ||
            !l3_rx_coalesce_commit(
                states + fixture, 0, claimed_version))
            atomicAdd(errors, 1);

        unsigned long long second_version = 0;
        if (!l3_rx_coalesce_claim(
                states + fixture, 0, second_version) ||
            second_version != expected_version ||
            l3_rx_coalesce_commit(states + fixture, 0, second_version) ||
            fixture_state_load(states + fixture) != expected_version)
            atomicAdd(errors, 1);
    }
}

// Two resident blocks race offer against commit.  Either linearization must
// leave exactly one QUEUED responsibility: created-token XOR worker-requeue.
__global__ void commit_offer_race_fixture(
    const int *vertices, unsigned long long *states,
    int *ready, int *go, int *outcomes, int *errors)
{
    if (threadIdx.x != 0)
        return;
    if (blockIdx.x == 0)
    {
        for (int fixture = 0; fixture < FIXTURES; ++fixture)
        {
            unsigned long long claimed_version = 0;
            if (!l3_rx_coalesce_claim(
                    states + fixture, 0, claimed_version))
            {
                atomicAdd(errors, 1);
                continue;
            }
            l3_atomic_store_release<cuda::thread_scope_device>(
                ready + fixture, 1);
            while (l3_atomic_load_acquire<cuda::thread_scope_device>(
                       go + fixture) == 0)
            {
            }
            if (l3_rx_coalesce_commit(
                    states + fixture, 0, claimed_version))
                atomicAdd(outcomes + fixture, 1);
        }
    }
    else
    {
        for (int fixture = 0; fixture < FIXTURES; ++fixture)
        {
            while (l3_atomic_load_acquire<cuda::thread_scope_device>(
                       ready + fixture) == 0)
            {
            }
            l3_atomic_store_release<cuda::thread_scope_device>(
                go + fixture, 1);
            int slot = -1;
            if (l3_rx_coalesce_offer(
                    vertices, states + fixture, 1, 1, slot))
                atomicAdd(outcomes + fixture, 1);
            if (slot != 0)
                atomicAdd(errors, 1);
        }
    }
}

__global__ void check_and_drain_race_fixture(
    unsigned long long *states, const int *outcomes, int *errors)
{
    const int fixture = blockIdx.x * blockDim.x + threadIdx.x;
    if (fixture >= FIXTURES)
        return;
    const unsigned long long queued = fixture_state_load(states + fixture);
    if (outcomes[fixture] != 1 ||
        (queued & L3_RX_RESP_STATE_MASK) != L3_RX_RESP_QUEUED)
    {
        atomicAdd(errors, 1);
        return;
    }
    unsigned long long version = 0;
    if (!l3_rx_coalesce_claim(states + fixture, 0, version) ||
        l3_rx_coalesce_commit(states + fixture, 0, version) ||
        (fixture_state_load(states + fixture) & L3_RX_RESP_STATE_MASK) !=
            L3_RX_RESP_IDLE)
        atomicAdd(errors, 1);
}

// The producer's distance write is sequenced before the responsibility's
// release CAS; a successful claim acquires that publication before reading.
__global__ void publication_fixture(
    const int *vertices, unsigned long long *states,
    int *distances, int *errors)
{
    if (threadIdx.x != 0)
        return;
    if (blockIdx.x == 0)
    {
        for (int fixture = 0; fixture < FIXTURES; ++fixture)
        {
            atomicExch(distances + fixture, fixture + 17);
            int slot = -1;
            if (!l3_rx_coalesce_offer(
                    vertices, states + fixture, 1, 1, slot) || slot != 0)
                atomicAdd(errors, 1);
        }
    }
    else
    {
        for (int fixture = 0; fixture < FIXTURES; ++fixture)
        {
            unsigned long long version = 0;
            while (!l3_rx_coalesce_claim(
                states + fixture, 0, version))
            {
            }
            const int observed = *((volatile int *)(distances + fixture));
            if (observed != fixture + 17 ||
                l3_rx_coalesce_commit(states + fixture, 0, version))
                atomicAdd(errors, 1);
        }
    }
}

static void check(cudaError_t status, const char *what)
{
    if (status != cudaSuccess)
    {
        std::fprintf(stderr, "%s: %s\n", what, cudaGetErrorString(status));
        std::exit(2);
    }
}

static int read_errors(int *errors)
{
    int host_errors = -1;
    check(cudaDeviceSynchronize(), "fixture synchronization");
    check(cudaMemcpy(&host_errors, errors, sizeof(host_errors),
                     cudaMemcpyDeviceToHost), "fixture error read");
    return host_errors;
}

int main()
{
    int *vertices = nullptr;
    int *errors = nullptr;
    int *ready = nullptr;
    int *go = nullptr;
    int *outcomes = nullptr;
    int *distances = nullptr;
    unsigned long long *states = nullptr;
    check(cudaMalloc(&vertices, sizeof(int)), "vertex allocation");
    check(cudaMalloc(&states, sizeof(unsigned long long) * FIXTURES),
          "state allocation");
    check(cudaMalloc(&errors, sizeof(int)), "error allocation");
    check(cudaMalloc(&ready, sizeof(int) * FIXTURES), "ready allocation");
    check(cudaMalloc(&go, sizeof(int) * FIXTURES), "go allocation");
    check(cudaMalloc(&outcomes, sizeof(int) * FIXTURES),
          "outcome allocation");
    check(cudaMalloc(&distances, sizeof(int) * FIXTURES),
          "distance allocation");
    const int vertex = 1;
    check(cudaMemcpy(vertices, &vertex, sizeof(vertex),
                     cudaMemcpyHostToDevice), "vertex upload");

    check(cudaMemset(states, 0, sizeof(unsigned long long) * FIXTURES),
          "queued fixture state reset");
    check(cudaMemset(errors, 0, sizeof(int)), "queued fixture error reset");
    queued_active_fixture<<<FIXTURES, 32>>>(vertices, states, errors);
    check(cudaGetLastError(), "queued/active fixture launch");
    if (read_errors(errors) != 0)
        return 1;

    std::vector<unsigned long long> initial(
        FIXTURES, L3_RX_RESP_VERSION_STEP | L3_RX_RESP_QUEUED);
    check(cudaMemcpy(states, initial.data(),
                     sizeof(unsigned long long) * FIXTURES,
                     cudaMemcpyHostToDevice), "race state initialization");
    check(cudaMemset(ready, 0, sizeof(int) * FIXTURES), "ready reset");
    check(cudaMemset(go, 0, sizeof(int) * FIXTURES), "go reset");
    check(cudaMemset(outcomes, 0, sizeof(int) * FIXTURES), "outcome reset");
    check(cudaMemset(errors, 0, sizeof(int)), "race fixture error reset");
    commit_offer_race_fixture<<<2, 1>>>(
        vertices, states, ready, go, outcomes, errors);
    check(cudaGetLastError(), "commit/offer race fixture launch");
    check_and_drain_race_fixture<<<16, 256>>>(states, outcomes, errors);
    check(cudaGetLastError(), "race drain fixture launch");
    if (read_errors(errors) != 0)
        return 1;

    check(cudaMemset(states, 0, sizeof(unsigned long long) * FIXTURES),
          "publication state reset");
    check(cudaMemset(distances, 0, sizeof(int) * FIXTURES),
          "publication distance reset");
    check(cudaMemset(errors, 0, sizeof(int)),
          "publication fixture error reset");
    publication_fixture<<<2, 1>>>(vertices, states, distances, errors);
    check(cudaGetLastError(), "publication fixture launch");
    if (read_errors(errors) != 0)
        return 1;

    std::printf(
        "L3_RX_COALESCE_CUDA fixtures=%d queued_active=PASS "
        "commit_offer_race=PASS release_acquire=PASS\n",
        FIXTURES);
    cudaFree(distances);
    cudaFree(outcomes);
    cudaFree(go);
    cudaFree(ready);
    cudaFree(errors);
    cudaFree(states);
    cudaFree(vertices);
    return 0;
}
