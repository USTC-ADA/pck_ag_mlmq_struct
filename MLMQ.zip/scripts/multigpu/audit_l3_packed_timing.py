"""Require every timing journal to match a fully audited diagnostic outcome."""
from pathlib import Path
from statistics import median
import collections,json,math,re
from audit_l3_packed_trace import require

def canonical(row):
    journal=sorted(tuple(x) for x in row['journal'])
    require(len({x[0] for x in journal})==len(journal),'duplicate journal vertex')
    return row['rows'],row['scans'],row['pending'],tuple(journal)

def references(path):
    result=collections.defaultdict(set)
    for line in Path(path).open():
        r=json.loads(line);result[r['batch'],r['policy']].add(canonical(r))
    return result

def audit_timing(path,log,batches,reference,limit=0):
    selected=sum(([i for i,b in enumerate(batches) if b['owner']==o][:limit or None] for o in (0,1)),[])
    expected={(i,r,t,p) for i in selected for r in (0,1) for t in range(-1,5) for p in (0,1,2)};seen=set()
    for line in Path(path).open():
        row=json.loads(line);key=row['batch'],row['round'],row['repeat'],row['policy'];require(key in expected and key not in seen,'unexpected timing journal');seen.add(key)
        batch=batches[key[0]]
        require(row['owner']==batch['owner'] and row['executor']==1-batch['owner'] and row['budget']==512,'timing journal metadata')
        require(canonical(row) in reference[key[0],key[3]],'untraced output differs from audited trace; not accepted as performance evidence')
    require(seen==expected,'missing timing journals')
    pattern=r'^PACKED_TIME owner=(\d+) executor=(\d+) round=(\d+) repeat=(-?\d+) policy=(\d+) batches=(\d+) ms=([\d.]+) helper_blocks=8 helper_warps=2 search=0 trace=0$'
    samples=[];keys=set();sizes=collections.Counter(batches[i]['owner'] for i in selected)
    raw=Path(log).read_text()
    for owner,gpu,r,t,p,n,ms in re.findall(pattern,raw,re.M):
        owner,gpu,r,t,p,n=map(int,(owner,gpu,r,t,p,n));ms=float(ms);key=owner,r,t,p
        require(key not in keys and gpu==1-owner and n==sizes[owner] and math.isfinite(ms) and ms>0,'invalid timing sample');keys.add(key)
        samples.append(dict(owner=owner,executor=gpu,round=r,repeat=t,policy=p,batches=n,ms=ms))
    require(keys=={(o,r,t,p) for o in (0,1) for r in (0,1) for t in range(-1,5) for p in (0,1,2)},'missing timing samples')
    require(sum(x.startswith('PACKED_TIME ') for x in raw.splitlines())==len(samples),'malformed timing sample')
    grouped={}
    for owner in (0,1):
        for policy in (0,1,2):
            rows=[r for r in samples if r['owner']==owner and r['policy']==policy and r['repeat']>=0]
            values=[x['ms'] for x in rows];require(len(values)==10,'sample count')
            grouped[f'owner{owner}_policy{policy}']=dict(samples_ms=values,median_ms=median(values),round_medians=[median([x['ms'] for x in rows if x['round']==r]) for r in (0,1)],batches=sizes[owner])
    return dict(valid=True,journals=len(seen),samples=samples,grouped=grouped,scope='CUDA event interval includes scratch reset, seed insertion, selection, full CSR rows and journal output; graph/packet H2D, D2H and host audit excluded; isolated payload, not solve')
