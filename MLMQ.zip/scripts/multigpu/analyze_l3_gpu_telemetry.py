#!/usr/bin/env python3
"""Independently verify original solver logs, clock windows and raw NVML rows."""
import argparse
import json
from pathlib import Path
from statistics import median
from l3_gpu_telemetry import parse_windows,summarize_window
from run_l3_batch_runtime import verify_tree,parse_runtime,parse_helpers,parse_admission,parse_services,parse_poll,parse_cache,parse_shared
from run_l3_30h import parse_dual_contract,parse_oracle_contract
from run_l3_upgrade_stage2 import sha256,write_json
from run_usa_road_matrix import parse_bench


def audit(run):
    m=json.loads((run/'manifest.json').read_text());s=json.loads((run/'summary.json').read_text());st=json.loads((run/'status.json').read_text())
    assert s['valid'] and st['complete'] and st['results']==s['results'] and len(s['results'])==20
    assert verify_tree(Path(m['build_path']))==m['build'] and verify_tree(Path(m['harness_path']))==m['harness']
    norm=lambda x:json.loads(json.dumps(x));query_rows=[]
    for key,r in s['results'].items():
        assert r['valid'] and r['rc']==0
        raw=(run/(key+'.log')).read_text();env=r['environment'];assert parse_bench(raw)==r['samples'] and len(r['samples'])==4
        assert parse_oracle_contract(raw,4,m['input_contract']['vertices'])==r['oracle'] and r['oracle']['valid']
        dual=parse_dual_contract(raw,4,int(env['MLMQ_WORK_BLOCKS']),m['input_contract']['delta'],19,
            expected_window_mode=2,expected_window_min=25000,expected_window_max=25000,expected_idle_backoff=0,
            require_l2_final=True,expected_worker_recovery=1,expected_ack_capacity=1712)
        assert dual==r['dual'] and dual['valid']
        windows=parse_windows(raw,4,1,r['start_ns'],r['end_ns']);assert windows==r['timing']
        if int(env['MLMQ_BATCH_ENABLED']):
            rt=parse_runtime(raw,4,512,0,False);assert rt==r['runtime'];assert parse_helpers(raw,4,8,rt)==r['helpers']
            assert norm(parse_admission(raw,4,int(env['MLMQ_BATCH_ADMIT']),rt))==r['admission']
            assert norm(parse_services(raw,4,int(env['MLMQ_BATCH_SERVICES']),int(env['MLMQ_BATCH_PROBE_CALLS'])))==r['services']
            assert parse_poll(raw,4,int(env['MLMQ_BATCH_SERVICE_POLL']))==r['poll']
            assert parse_cache(raw,4,-1)==r['cache'] and parse_shared(raw,4,0)==r['shared']
        if not r['observer_enabled']:continue
        p=run/(key+'.nvml.json');assert sha256(p)==r['telemetry_sha256'];data=json.loads(p.read_text())
        assert not data['errors'] and data['metadata']==m['nvml'] and data['metadata']['read_only']
        rows=data['rows'];assert len(rows)>0 and len(rows)%2==0
        for i,row in enumerate(rows):
            assert row['gpu']==i%2 and row['uuid']==m['nvml']['devices'][i%2]['uuid']
            assert r['start_ns'] <= row['start_ns'] <= row['end_ns'] <= r['end_ns']
            if i:assert rows[i-1]['end_ns'] <= row['start_ns']
        telemetry=[summarize_window(w,rows) for w in windows];assert telemetry==r['telemetry']
        assert all(x['coverage_valid'] for x in telemetry)==r['telemetry_coverage_valid']
        for q in range(4):
            samples=[t for t in telemetry if t['repeat']==q]
            query_rows.append({'record':key,'repeat':q,'warmup':int(q==0),'solve_ms':float(r['samples'][q]['solve_ms']),
                'work_stream_ms':[w['work_stream_ms'] for w in windows if w['repeat']==q],
                'gpu_samples':samples})
    assert len(query_rows)==40
    for label,g in s['grouped'].items():
        for enabled in (0,1):
            for field in ('solve_ms','query_wall_ms'):
                values=[float(v[field]) for i in range(2) for v in s['results'][f'r{i}_{label}_nvml{enabled}']['samples'] if v['warmup']=='0']
                assert values==g[str(enabled)][field]['samples_ms'] and median(values)==g[str(enabled)][field]['median_ms']
                assert g['1'][field]['median_ms']-g['0'][field]['median_ms']==g['nvml_on_minus_off_ms'][field]
    all_gpu=[x for r in query_rows for x in r['gpu_samples']]
    assert all(x['coverage_valid'] for x in all_gpu)==s['telemetry_coverage_valid']
    observed={str(g):{f:sorted({v for x in all_gpu if x['gpu']==g for v in x['values'][f]}) for f in ('sm_mhz','memory_mhz','pstate','event_reasons')} for g in (0,1)}
    return {'valid':True,'job_id':m['allocation']['job_id'],'queries':80,'observed_queries':40,'query_rows':query_rows,
            'telemetry_coverage_valid':s['telemetry_coverage_valid'],'observed_values':observed,'grouped':s['grouped'],
            'worst_observation_gap_ms':max(x['max_gap_ms'] for x in all_gpu),'minimum_observations_per_gpu_query':min(x['samples'] for x in all_gpu),
            'auditor_sha256':sha256(Path(__file__)),'performance_acceptance':False,
            'limitations':['NVML request frequency is not guaranteed hardware sensor refresh frequency','on/off comparison estimates observer perturbation only; timing macro enabled in both','current clock reads cannot exclude unobserved transient changes; event reasons may be unsupported','same-capability single absent; production racecheck failures preserved']}


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--run',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
    if a.out.exists():p.error('output exists')
    r=audit(a.run.resolve(strict=True));write_json(a.out,r)
    print('TELEMETRY_AUDIT_PASS',r['job_id'],r['telemetry_coverage_valid'],r['observed_values'],r['worst_observation_gap_ms'])


if __name__=='__main__':main()
