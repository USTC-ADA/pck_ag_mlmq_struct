#!/usr/bin/env python3
"""Build an isolated, frozen sm80 remote-commit fixture. Does not execute GPU code."""
import argparse
from pathlib import Path
import shutil
import subprocess
import tarfile

from run_l3_upgrade_stage2 import ROOT, sha256, write_json


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', required=True, type=Path)
    parser.add_argument('--allow-dirty', action='store_true')
    args = parser.parse_args()
    if not args.allow_dirty:
        parser.error('exploratory build requires --allow-dirty')
    if args.out.exists() or args.out.is_symlink():
        parser.error('output must not exist')
    args.out.mkdir(parents=True)
    out = args.out.resolve()
    source = out / 'source'
    names = [
        'SSSP/l3/l3_batch_commit.h', 'SSSP/l3/l3_batch_commit_warp.cuh',
        'SSSP/l3/l3_batch_relay.cuh', 'SSSP/l3/l3_batch_compact.cuh',
        'SSSP/l3/l3_batch_peer_commit.cuh', 'core/cu_delta_queue/cu_delta_queue.cuh',
        'core/include/warp_primitive.h', 'core/include/common.h', 'core/include/GPU_setup.h',
        'core/include/adaptive.h', 'core/include/graph_info.h',
        'scripts/multigpu/test_l3_batch_commit.cpp', 'scripts/multigpu/test_l3_batch_commit_l2.cu',
        'scripts/multigpu/test_l3_batch_peer_commit.cu',
        'scripts/multigpu/build_l3_batch_peer_commit.py', 'scripts/multigpu/run_l3_batch_peer_commit.py',
        'scripts/multigpu/test_l3_batch_peer_commit_runner.py',
        'scripts/multigpu/run_l3_upgrade_stage2.py', 'scripts/multigpu/run_l3_compact_screen.py',
        'scripts/multigpu/run_l3_batch_capture_replay.py', 'scripts/multigpu/run_l3_30h.py',
        'scripts/multigpu/run_usa_road_matrix.py',
    ]
    names += [
        'SSSP/l3/l3_batch_remote_commit.cuh', 'SSSP/l3/l3_transport.cuh', 'SSSP/l3/l3_sync.cuh',
        'scripts/multigpu/test_l3_batch_remote_commit.cu',
        'scripts/multigpu/build_l3_batch_remote_commit.py', 'scripts/multigpu/run_l3_batch_remote_commit.py',
        'scripts/multigpu/test_l3_batch_remote_commit_runner.py',
    ]
    before = {name: sha256(ROOT / name) for name in names}
    for name in names:
        dest = source / name
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(ROOT / name, dest)
        if sha256(dest) != before[name]:
            raise RuntimeError('source changed during freeze: ' + name)
    if any(sha256(ROOT / name) != digest for name, digest in before.items()):
        raise RuntimeError('source changed during freeze')
    for name, command in (
        ('worktree_status.txt', ['git', 'status', '--short']),
        ('worktree.diff', ['git', 'diff']),
        ('head.txt', ['git', 'rev-parse', 'HEAD']),
        ('nvcc_version.txt', ['/usr/local/cuda/bin/nvcc', '--version']),
    ):
        with (out / name).open('w') as log:
            subprocess.run(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, check=True)
    with tarfile.open(out / 'source.tgz', 'w:gz') as archive:
        for name in names:
            archive.add(source / name, arcname=name)
    command = ['/usr/local/cuda/bin/nvcc', '-std=c++14', '-O2', '-lineinfo', '-rdc=true',
               '-gencode=arch=compute_80,code=sm_80', '-DDQ_COUNTER_OVERFLOW_GUARD=true',
               '-Icore/include', '-Xptxas=-v', 'scripts/multigpu/test_l3_batch_remote_commit.cu',
               '-o', str(out / 'test_sm80')]
    write_json(out / 'build_command.json', command)
    with (out / 'build.log').open('w') as log:
        subprocess.run(command, cwd=source, stdout=log, stderr=subprocess.STDOUT, check=True)
    artifacts = ['source.tgz', 'test_sm80', 'build.log', 'build_command.json',
                 'worktree_status.txt', 'worktree.diff', 'head.txt', 'nvcc_version.txt']
    hashes = {name: sha256(out / name) for name in artifacts}
    hashes.update({'source/' + name: digest for name, digest in before.items()})
    write_json(out / 'manifest.json', {'valid_build': True, 'hashes': hashes,
        'evidence_class': 'dirty_frozen_remote_commit_fixture_not_solver',
        'architecture': 'sm_80', 'assertions_enabled': True, 'gpu_executed': False})
    print('REMOTE_COMMIT_BUILD_PASS', out, flush=True)


if __name__ == '__main__':
    main()
