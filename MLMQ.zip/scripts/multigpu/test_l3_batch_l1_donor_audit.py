import copy
import unittest
from audit_l3_batch_l1_donor import FIRST_GENERATION, verify_l1_snapshot, verify_receipts


def snapshot(n=7, duplicate=1):
    case=dict(seeds=n,duplicate=duplicate,prime=5,begin=37)
    u=(n+1)//2 if duplicate else n
    root=case['begin']+9
    j=dict(seeds=n,head=48,tail=(48+n)%64,head_after=(48+n)%64,
           parents=8,credit_before=8,credit_held=8,retired=8,
           credit_after=0,outstanding_after=0,empty_after=0,released_after=1,claims=1,rejected=5,
           roots=[(root+8+i%u,5+(i%u)%3,root+9+i%u,20) for i in range(n)])
    return j,case


def receipts():
    journals={0:{'records':[(100+i,10,2147483647) for i in range(33)]}}
    packets={}
    for epoch,(start,end) in enumerate(((0,32),(32,33)),1):
        for role in (0,1):
            packets[epoch,role]=dict(epoch=epoch,generation=FIRST_GENERATION,start=start,end=end,count=end-start,
                                    loan=0 if role==0 else -1,acked=1,payload=[(100+i,10) for i in range(start,end)])
    return journals,packets


class L1AuditTests(unittest.TestCase):
    def test_valid_real_shapes(self):
        for n in (1,7,32):
            for d in (0,1):
                j,c=snapshot(n,d);self.assertEqual(verify_l1_snapshot(j,c,0),(n+1)//2 if d else n)
        j,r=receipts();self.assertEqual(verify_receipts(j,r,100),(2,33))

    def test_credit_not_seed_count_or_early_retirement(self):
        for key in ('parents','credit_before','credit_held','retired'):
            j,c=snapshot();j[key]=7
            with self.subTest(key=key),self.assertRaises(ValueError):verify_l1_snapshot(j,c,0)
        j,c=snapshot();j['credit_after']=8
        with self.assertRaises(ValueError):verify_l1_snapshot(j,c,0)

    def test_ring_movement(self):
        for key in ('head','tail','head_after','empty_after'):
            j,c=snapshot();j[key]+=1
            with self.subTest(key=key),self.assertRaises(ValueError):verify_l1_snapshot(j,c,0)

    def test_stale_priority_not_authoritative_seed(self):
        j,c=snapshot();v,d,i,p=j['roots'][0];j['roots'][0]=(v,p,i,p)
        with self.assertRaises(ValueError):verify_l1_snapshot(j,c,0)
        j,c=snapshot();v,d,i,p=j['roots'][0];j['roots'][0]=(v,d,i,5)
        with self.assertRaises(ValueError):verify_l1_snapshot(j,c,0)

    def test_lost_duplicate_and_wrong_one_based_id(self):
        j,c=snapshot();j['roots'].pop()
        with self.assertRaises(ValueError):verify_l1_snapshot(j,c,0)
        j,c=snapshot();v,d,i,p=j['roots'][0];j['roots'][0]=(v,d,i-1,p)
        with self.assertRaises(ValueError):verify_l1_snapshot(j,c,0)

    def test_receipt_generation_ack_payload(self):
        for key,value in [('generation',FIRST_GENERATION+1),('acked',0),('payload',[(100,11)]*32)]:
            j,r=receipts()
            for role in (0,1):r[1,role][key]=value
            with self.subTest(key=key),self.assertRaises(ValueError):verify_receipts(j,r,100)

    def test_duplicate_window_hides_missing_window(self):
        j,r=receipts()
        for role in (0,1):
            r[2,role]=copy.deepcopy(r[1,role]);r[2,role]['epoch']=2
        with self.assertRaises(ValueError):verify_receipts(j,r,100)


if __name__=='__main__':unittest.main()
