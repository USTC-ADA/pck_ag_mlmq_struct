import unittest
from run_l3_batch_remote_commit import parse_cases


def fixture(quick):
    lines = [f'EPOCH_METADATA_GUARD_PASS gpu={g} generation=1099511627777 no_queue=1' for g in (0, 1)]
    rounds = 2 if quick else 4
    groups = rounds * 3
    cases = 0
    for owner in (0, 1):
        for begin in ((37,) if quick else (0, 37)):
            for fan in ((33,) if quick else (1, 33, 65)):
                for leaves in ((7,) if quick else (0, 7)):
                    packets = groups * ((1 + leaves + fan + 31) // 32)
                    competitions = groups if leaves else 0
                    lines.append(f'BATCH_REMOTE_COMMIT_CASE owner={owner} begin={begin} fan={fan} leaves={leaves} '
                                 f'rounds={rounds} loans={groups} packets={packets} remote_records={groups*fan} '
                                 f'full_stops={rounds} delay_checks={packets} competitions={competitions} '
                                 f'source_writes={8+groups*leaves} remote_writes={8+groups*fan+competitions} PASS')
                    cases += 1
    lines.append(f'BATCH_REMOTE_COMMIT_PASS cases={cases} actual_compact=1 actual_remote=1 actual_dq=1 '
                 'no_l1=1 no_solver=1 not_performance=1')
    return '\n'.join(lines) + '\n'


class RemoteRunnerTests(unittest.TestCase):
    def test_exact_cases(self):
        self.assertEqual(len(parse_cases(fixture(True), True)), 2)
        self.assertEqual(len(parse_cases(fixture(False), False)), 24)

    def test_missing_duplicate_and_wrong_direction(self):
        raw = fixture(True)
        for bad in ('\n'.join(raw.splitlines()[1:]), raw + raw.splitlines()[2] + '\n',
                    raw.replace('owner=1', 'owner=0'), raw.replace('begin=37', 'begin=0')):
            with self.assertRaises(ValueError):
                parse_cases(bad, True)

    def test_rejects_missing_responsibility_checks(self):
        raw = fixture(True)
        for a, b in [('loans=6', 'loans=5'), ('full_stops=2', 'full_stops=0'),
                     ('delay_checks=12', 'delay_checks=0'), ('competitions=6', 'competitions=0'),
                     ('remote_records=198', 'remote_records=197'), ('source_writes=50', 'source_writes=49'),
                     ('remote_writes=212', 'remote_writes=198'), ('packets=12', 'packets=13')]:
            with self.subTest(change=a), self.assertRaises(ValueError):
                parse_cases(raw.replace(a, b), True)

    def test_rejects_scope_upgrade(self):
        for a, b in [('actual_remote=1', 'actual_remote=0'), ('no_l1=1', 'no_l1=0'),
                     ('no_solver=1', 'no_solver=0'), ('not_performance=1', 'not_performance=0')]:
            with self.assertRaises(ValueError):
                parse_cases(fixture(True).replace(a, b), True)

    def test_boundary_and_marker(self):
        raw = fixture(True)
        for bad in (raw.replace('1099511627777', '1'), raw + raw.splitlines()[0] + '\n',
                    raw + raw.splitlines()[-1] + '\n', ''):
            with self.assertRaises(ValueError):
                parse_cases(bad, True)
        with self.assertRaises(ValueError):
            parse_cases(raw, False)


if __name__ == '__main__':
    unittest.main()
