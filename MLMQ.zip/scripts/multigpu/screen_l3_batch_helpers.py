#!/usr/bin/env python3
"""Matched helper-concurrency screen, preserving fast original controls."""
import argparse
import json
from pathlib import Path
import re
from statistics import median
from run_l3_batch_runtime import verify_tree, parse_runtime, parse_helpers, parse_admission, parse_services, parse_cache, parse_poll, parse_timing, parse_sleep, parse_loops, parse_shared, parse_manager_wait, parse_inject_wait, parse_completed_filter, parse_bound
from run_l3_upgrade_stage2 import clean_environment, sha256, slurm_preflight, write_json
from run_usa_road_matrix import run_one
from run_l3_30h import parse_dual_contract, parse_oracle_contract
from run_l3_batch_runtime import parse_bound_neighbors, parse_bound_placement, parse_select, parse_bound_returned


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('build', 'harness', 'contract', 'out'):
        parser.add_argument('--' + name, required=True, type=Path)
    parser.add_argument('--admission-screen', action='store_true', help='isolate installed-service cost from admitted loans')
    parser.add_argument('--service-screen', action='store_true', help='separate installed data, helper, RX and borrow probes')
    parser.add_argument('--cache-screen', action='store_true', help='compare default and requested shared-memory carveout preferences')
    parser.add_argument('--cache-preference', type=int, choices=range(1, 101), default=60)
    parser.add_argument('--reference-build', type=Path, help='matched old/new packed workspace screen')
    parser.add_argument('--poll-screen', action='store_true', help='compare resident sleeping services with their normal polling loops')
    parser.add_argument('--timing-diag', action='store_true', help='require and summarize existing host/event timings')
    parser.add_argument('--timing-reference-build', type=Path, help='untimed v15 control for timing perturbation; requires poll screen')
    parser.add_argument('--sleep-screen', action='store_true', help='vary exit-poll sleep request with queue scans disabled')
    parser.add_argument('--padding-screen', action='store_true', help='isolate service CTAs with dynamic shared allocation')
    parser.add_argument('--wait-manager-diag', action='store_true')
    parser.add_argument('--inject-wait-diag', action='store_true')
    parser.add_argument('--completed-filter-screen', action='store_true')
    parser.add_argument('--counter-factorial', action='store_true')
    parser.add_argument('--owner-bound-screen', action='store_true')
    parser.add_argument('--neighbors', action='store_true')
    parser.add_argument('--helper-mirror', action='store_true')
    parser.add_argument('--owner-mirror-build', type=Path)
    parser.add_argument('--reference-helper-mirror', action='store_true')
    parser.add_argument('--select-labels', action='store_true')
    parser.add_argument('--returned-bound', action='store_true')
    parser.add_argument('--neighbor-edge-limit', type=int, choices=range(1, 129), default=32)
    parser.add_argument('--filter-build', type=Path)
    parser.add_argument('--combined-build', type=Path)
    parser.add_argument('--scan-preempt-screen', action='store_true', help='matched scan-preemption treatment, including old and improved controls')
    parser.add_argument('--reference-helper-static', type=int, default=32040)
    args = parser.parse_args()
    if args.neighbors and not args.owner_bound_screen:
        parser.error('neighbor comparison requires owner-bound screen')
    if args.helper_mirror and not args.neighbors:
        parser.error('helper mirror requires neighbor screen')
    if args.owner_mirror_build and not args.helper_mirror:
        parser.error('owner mirror reference requires helper mirror screen')
    if (args.reference_helper_mirror or args.select_labels) and not args.owner_mirror_build:
        parser.error('selection comparison requires explicit prior mirror build')
    if args.owner_bound_screen:
        if not (args.reference_build and args.timing_diag):
            parser.error('owner-bound screen requires timed old/new builds')
        if any((args.counter_factorial, args.completed_filter_screen, args.wait_manager_diag,
                args.inject_wait_diag, args.scan_preempt_screen, args.timing_reference_build)):
            parser.error('owner-bound screen must be a separate uninstrumented comparison')
    if args.counter_factorial and not (args.reference_build and args.filter_build and args.combined_build and args.timing_diag):
        parser.error('counter factorial requires all four timed builds')
    if args.counter_factorial and (args.completed_filter_screen or args.wait_manager_diag or args.scan_preempt_screen):
        parser.error('counter factorial is a separate screen')
    if args.completed_filter_screen:
        args.scan_preempt_screen = True
    if (args.wait_manager_diag or args.scan_preempt_screen) and not (args.reference_build and args.timing_diag):
        parser.error('manager/preemption comparison requires timed reference build')
    if args.inject_wait_diag and not args.wait_manager_diag:
        parser.error('inject phase observations require manager wait diagnostic')
    if args.wait_manager_diag and args.scan_preempt_screen:
        parser.error('preemption performance screen requires uninstrumented managers')
    if sum((args.admission_screen, args.service_screen, args.cache_screen, bool(args.reference_build), args.poll_screen, args.sleep_screen, args.padding_screen)) > 1:
        parser.error('diagnostic modes are mutually exclusive')
    if args.padding_screen:
        args.cache_screen = True
    if args.sleep_screen:
        args.poll_screen = True
    if args.timing_reference_build and not (args.timing_diag and args.poll_screen):
        parser.error('untimed reference requires --poll-screen --timing-diag')
    build, harness = args.build.resolve(strict=True), args.harness.resolve(strict=True)
    bm, hm = verify_tree(build), verify_tree(harness)
    reference = args.reference_build.resolve(strict=True) if args.reference_build else None
    rm = verify_tree(reference) if reference else None
    owner_mirror = args.owner_mirror_build.resolve(strict=True) if args.owner_mirror_build else None
    om = verify_tree(owner_mirror) if owner_mirror else None
    filter_build = args.filter_build.resolve(strict=True) if args.filter_build else None
    combined_build = args.combined_build.resolve(strict=True) if args.combined_build else None
    fm = verify_tree(filter_build) if filter_build else None
    cm = verify_tree(combined_build) if combined_build else None
    if args.owner_bound_screen:
        bound_builds = [(reference, False, False), (build, True, args.helper_mirror)]
        if owner_mirror:
            bound_builds.append((owner_mirror, True, args.reference_helper_mirror))
        for path, candidate, helper_local in bound_builds:
            command = json.loads((path / 'batch_command.json').read_text())
            flags = dict(x[2:].split('=', 1) for x in command if x.startswith('-D') and '=' in x)
            for name, expected in (('L3_BATCH_OWNER_BOUND', candidate), ('L3_BATCH_BOUND_DIAG', False),
                                   ('L3_BATCH_BOUND_NEIGHBORS', candidate and args.neighbors),
                                   ('L3_BATCH_BOUND_HELPER_LOCAL', helper_local),
                                   ('L3_BATCH_LABEL_SELECT', args.select_labels and path==build),
                                   ('L3_BATCH_BOUND_RETURNED', args.returned_bound and path==build),
                                   ('L3_BATCH_SEARCH_DIAG', False),
                                   ('L3_BATCH_BOUND_PUBLISH_DIAG', False),
                                   ('L3_BATCH_COMPLETED_FILTER', False), ('L3_BATCH_CERT_COUNT_AGGREGATE', False),
                                   ('L3_TIMING_DIAG', True), ('L3_INJECT_SCAN_PREEMPT', True)):
                if flags.get(name, 'false') != str(expected).lower():
                    raise ValueError('bound screen build flag mismatch: '+name)
    if args.counter_factorial:
        for path, expected_filter, expected_aggregate in ((reference, False, False), (filter_build, True, False),
                                                       (build, False, True), (combined_build, True, True)):
            command = json.loads((path / 'batch_command.json').read_text())
            for name, expected in (('L3_BATCH_COMPLETED_FILTER', expected_filter), ('L3_BATCH_CERT_COUNT_AGGREGATE', expected_aggregate)):
                flag = next((x.split('=', 1)[1] for x in command if x.startswith('-D' + name + '=')), 'false')
                if flag != ('true' if expected else 'false'):
                    raise ValueError('factorial build flag mismatch: ' + name)
    untimed = args.timing_reference_build.resolve(strict=True) if args.timing_reference_build else None
    um = verify_tree(untimed) if untimed else None
    if Path(__file__).resolve() != harness / 'source/scripts/multigpu/screen_l3_batch_helpers.py':
        parser.error('execute frozen screen')
    contract = json.loads(args.contract.read_text())
    graph, oracle = Path(contract['graph_path']), Path(contract['oracle_path'])
    if sha256(graph) != contract['graph_sha256'] or sha256(oracle) != contract['oracle_sha256']:
        raise ValueError('input differs from frozen contract')
    args.out.mkdir(parents=True, exist_ok=False)
    out = args.out.resolve()
    allocation = slurm_preflight(out)
    # label, binary, GPUs, workers, runtime enabled, helper blocks, budget
    configs = [('C1_107', 'control', 1, 107, 0, 1, 64),
               ('C2_107', 'control', 2, 107, 0, 1, 64),
               ('C2_97', 'control', 2, 97, 0, 1, 64),
               ('T2_off97', 'batch', 2, 97, 0, 8, 64),
               ('T2_h1_b64', 'batch', 2, 97, 1, 1, 64),
               ('T2_h8_b64', 'batch', 2, 97, 1, 8, 64),
               ('T2_h8_b512', 'batch', 2, 97, 1, 8, 512)]
    configs = [(*config, 1) for config in configs]
    if args.admission_screen:
        configs = [('C1_107', 'control', 1, 107, 0, 1, 512, 0),
                   ('C2_107', 'control', 2, 107, 0, 1, 512, 0),
                   ('C2_97', 'control', 2, 97, 0, 1, 512, 0),
                   ('T2_off97', 'batch', 2, 97, 0, 8, 512, 0),
                   ('T2_h1_admit0', 'batch', 2, 97, 1, 1, 512, 0),
                   ('T2_h8_admit0', 'batch', 2, 97, 1, 8, 512, 0),
                   ('T2_h8_admit1', 'batch', 2, 97, 1, 8, 512, 1)]
    configs = [(*config, 1, 3) for config in configs]
    if args.service_screen:
        # Last two columns are probe_calls, services (bit0 helper, bit1 RX).
        configs = [('C1_107', 'control', 1, 107, 0, 8, 512, 0, 0, 0),
                   ('C2_107', 'control', 2, 107, 0, 8, 512, 0, 0, 0),
                   ('C2_97', 'control', 2, 97, 0, 8, 512, 0, 0, 0),
                   ('T2_off97', 'batch', 2, 97, 0, 8, 512, 0, 0, 0),
                   ('T2_s0p0', 'batch', 2, 97, 1, 8, 512, 0, 0, 0),
                   ('T2_s1p0', 'batch', 2, 97, 1, 8, 512, 0, 0, 1),
                   ('T2_s2p0', 'batch', 2, 97, 1, 8, 512, 0, 0, 2),
                   ('T2_s3p0', 'batch', 2, 97, 1, 8, 512, 0, 0, 3),
                   ('T2_s3p1', 'batch', 2, 97, 1, 8, 512, 0, 1, 3),
                   ('T2_loans', 'batch', 2, 97, 1, 8, 512, 1, 1, 3)]
    configs = [(*config, -1) for config in configs]
    if args.cache_screen:
        configs = [('C1_107', 'control', 1, 107, 0, 8, 512, 0, 0, 0, -1),
                   ('C2_107', 'control', 2, 107, 0, 8, 512, 0, 0, 0, -1),
                   ('C2_97', 'control', 2, 97, 0, 8, 512, 0, 0, 0, -1),
                   ('T2_off97', 'batch', 2, 97, 0, 8, 512, 0, 0, 0, -1),
                   ('T2_data', 'batch', 2, 97, 1, 8, 512, 0, 0, 0, -1),
                   ('T2_h_default', 'batch', 2, 97, 1, 8, 512, 0, 0, 1, -1),
                   ('T2_h_preferred', 'batch', 2, 97, 1, 8, 512, 0, 0, 1, args.cache_preference),
                   ('T2_rx_default', 'batch', 2, 97, 1, 8, 512, 0, 0, 2, -1),
                   ('T2_rx_preferred', 'batch', 2, 97, 1, 8, 512, 0, 0, 2, args.cache_preference),
                   ('T2_idle_preferred', 'batch', 2, 97, 1, 8, 512, 0, 0, 3, args.cache_preference),
                   ('T2_loans_default', 'batch', 2, 97, 1, 8, 512, 1, 1, 3, -1),
                   ('T2_loans_preferred', 'batch', 2, 97, 1, 8, 512, 1, 1, 3, args.cache_preference)]
    if args.padding_screen:
        configs = [(label.replace('_preferred', '_padded'), *values[:-1], -1) for label, *values in configs]
    service_padding = {label: 100496 if label.endswith('_padded') else 0 for label, *_ in configs} if args.padding_screen else {}
    if reference:
        configs = [('C1_107', 'control', 1, 107, 0, 8, 512, 0, 0, 0, -1),
                   ('C2_107', 'control', 2, 107, 0, 8, 512, 0, 0, 0, -1),
                   ('R2_off97', 'reference', 2, 97, 0, 8, 512, 0, 0, 0, -1),
                   ('T2_off97', 'batch', 2, 97, 0, 8, 512, 0, 0, 0, -1),
                   ('R2_helper', 'reference', 2, 97, 1, 8, 512, 0, 0, 1, -1),
                   ('T2_helper', 'batch', 2, 97, 1, 8, 512, 0, 0, 1, -1),
                   ('R2_loans', 'reference', 2, 97, 1, 8, 512, 1, 1, 3, -1),
                   ('T2_loans', 'batch', 2, 97, 1, 8, 512, 1, 1, 3, -1)]
    if args.wait_manager_diag or args.scan_preempt_screen:
        configs += [('R2_data', 'reference', 2, 97, 1, 8, 512, 0, 0, 0, -1),
                    ('T2_data', 'batch', 2, 97, 1, 8, 512, 0, 0, 0, -1)]
    if args.scan_preempt_screen:
        configs += [('R1_107', 'reference_control', 1, 107, 0, 8, 512, 0, 0, 0, -1),
                    ('R2_107', 'reference_control', 2, 107, 0, 8, 512, 0, 0, 0, -1)]
    service_poll = {}
    service_sleep = {}
    if args.poll_screen:
        configs = [('C1_107', 'control', 1, 107, 0, 8, 512, 0, 0, 0, -1),
                   ('C2_107', 'control', 2, 107, 0, 8, 512, 0, 0, 0, -1),
                   ('T2_off97', 'batch', 2, 97, 0, 8, 512, 0, 0, 0, -1),
                   ('T2_data', 'batch', 2, 97, 1, 8, 512, 0, 0, 0, -1),
                   ('T2_h_sleep', 'batch', 2, 97, 1, 8, 512, 0, 0, 1, -1),
                   ('T2_h_poll', 'batch', 2, 97, 1, 8, 512, 0, 0, 1, -1),
                   ('T2_rx_sleep', 'batch', 2, 97, 1, 8, 512, 0, 0, 2, -1),
                   ('T2_rx_poll', 'batch', 2, 97, 1, 8, 512, 0, 0, 2, -1),
                   ('T2_both_sleep', 'batch', 2, 97, 1, 8, 512, 0, 0, 3, -1),
                   ('T2_both_poll', 'batch', 2, 97, 1, 8, 512, 0, 0, 3, -1),
                   ('T2_loans', 'batch', 2, 97, 1, 8, 512, 1, 1, 3, -1)]
        service_poll = {label: int(label not in ('T2_h_sleep', 'T2_rx_sleep', 'T2_both_sleep'))
                        for label, *_ in configs}
    if args.sleep_screen:
        if untimed:
            parser.error('sleep diagnostic does not use an untimed reference')
        configs = [('C1_107', 'control', 1, 107, 0, 8, 512, 0, 0, 0, -1),
                   ('C2_107', 'control', 2, 107, 0, 8, 512, 0, 0, 0, -1),
                   ('T2_off97', 'batch', 2, 97, 0, 8, 512, 0, 0, 0, -1),
                   ('T2_data', 'batch', 2, 97, 1, 8, 512, 0, 0, 0, -1),
                   ('T2_h_sleep', 'batch', 2, 97, 1, 8, 512, 0, 0, 1, -1),
                   ('T2_h_slow', 'batch', 2, 97, 1, 8, 512, 0, 0, 1, -1),
                   ('T2_rx_sleep', 'batch', 2, 97, 1, 8, 512, 0, 0, 2, -1),
                   ('T2_rx_slow', 'batch', 2, 97, 1, 8, 512, 0, 0, 2, -1),
                   ('T2_both_sleep', 'batch', 2, 97, 1, 8, 512, 0, 0, 3, -1),
                   ('T2_both_slow', 'batch', 2, 97, 1, 8, 512, 0, 0, 3, -1),
                   ('T2_loans', 'batch', 2, 97, 1, 8, 512, 1, 1, 3, -1),
                   ('T2_loans_slow', 'batch', 2, 97, 1, 8, 512, 1, 1, 3, -1)]
        service_poll = {label: int(label in ('T2_loans', 'T2_loans_slow')) for label, *_ in configs}
        service_sleep = {label: 65536 if label.endswith('_slow') else 64 for label, *_ in configs}
    if untimed:
        configs += [('U2_data', 'untimed', 2, 97, 1, 8, 512, 0, 0, 0, -1),
                    ('U2_h_sleep', 'untimed', 2, 97, 1, 8, 512, 0, 0, 1, -1),
                    ('U2_loans', 'untimed', 2, 97, 1, 8, 512, 1, 1, 3, -1)]
        service_poll.update(U2_data=1, U2_h_sleep=0, U2_loans=1)
    if args.counter_factorial:
        configs = [('C1_107', 'control', 1, 107, 0, 8, 512, 0, 0, 0, -1),
                   ('C2_107', 'control', 2, 107, 0, 8, 512, 0, 0, 0, -1),
                   ('B2_off', 'reference', 2, 97, 0, 8, 512, 0, 0, 0, -1),
                   ('A2_off', 'batch', 2, 97, 0, 8, 512, 0, 0, 0, -1)]
        for mode in ('data', 'loans'):
            active = int(mode == 'loans')
            configs += [(prefix + '2_' + mode, kind, 2, 97, 1, 8, 512, active, active, 3 if active else 0, -1)
                        for prefix, kind in (('B', 'reference'), ('F', 'filter'), ('A', 'batch'), ('AF', 'combined'))]
    bound_modes = {}
    if args.owner_bound_screen:
        configs = [('C1_107', 'control', 1, 107, 0, 8, 512, 0, 0, 0, -1),
                   ('C2_107', 'control', 2, 107, 0, 8, 512, 0, 0, 0, -1),
                   ('B2_off', 'reference', 2, 97, 0, 8, 512, 0, 0, 0, -1),
                   ('T2_off', 'batch', 2, 97, 0, 8, 512, 0, 0, 0, -1),
                   ('B2_data', 'reference', 2, 97, 1, 8, 512, 0, 0, 0, -1),
                   ('T2_data', 'batch', 2, 97, 1, 8, 512, 0, 0, 0, -1),
                   ('B2_loans', 'reference', 2, 97, 1, 8, 512, 1, 1, 3, -1)]
        configs += [(f'T2_mode{mode}', 'batch', 2, 97, 1, 8, 512, 1, 1, 3, -1) for mode in (0, 3, 1, 2)]
        bound_modes = dict(T2_off=0, T2_data=0, **{f'T2_mode{mode}': mode for mode in range(4)})
        if owner_mirror:
            configs += [(f'O2_mode{mode}', 'owner_mirror', 2, 97, 1, 8, 512, 1, 1, 3, -1) for mode in (0, 3, 1, 2)]
            bound_modes.update({f'O2_mode{mode}': mode for mode in range(4)})
    write_json(out / 'manifest.json', {'build': bm, 'build_path': str(build), 'harness': hm,
        'owner_bound_screen': args.owner_bound_screen, 'bound_modes': bound_modes,
        'returned_bound': args.returned_bound, 'neighbors': args.neighbors, 'neighbor_edge_limit': args.neighbor_edge_limit,
        'helper_mirror': args.helper_mirror, 'owner_mirror_path': str(owner_mirror) if owner_mirror else None, 'owner_mirror_build': om,
        'reference_helper_mirror':args.reference_helper_mirror, 'select_labels':args.select_labels,
        'counter_factorial': args.counter_factorial, 'filter_build_path': str(filter_build) if filter_build else None, 'filter_build': fm,
        'combined_build_path': str(combined_build) if combined_build else None, 'combined_build': cm,
        'completed_filter_screen': args.completed_filter_screen, 'inject_wait_diag': args.inject_wait_diag, 'scan_preempt_screen': args.scan_preempt_screen, 'wait_manager_diag': args.wait_manager_diag, 'reference_helper_static': args.reference_helper_static,
        'reference_build': rm, 'reference_build_path': str(reference) if reference else None,
        'cache_preference': args.cache_preference if args.cache_screen and not args.padding_screen else None,
        'service_padding_by_label': service_padding,
        'timing_diag': args.timing_diag, 'untimed_reference': um,
        'untimed_reference_path': str(untimed) if untimed else None,
        'service_poll_by_label': service_poll,
        'service_sleep_by_label': service_sleep,
        'input_contract': contract, 'allocation': allocation, 'configs': configs,
        'rounds': 2, 'warmups': 1, 'repeats': 3, 'evidence_class': 'dirty_frozen_exploratory_not_formal',
        'mode': 'owner_bound_matched' if args.owner_bound_screen else 'certificate_counter_factorial' if args.counter_factorial else 'completed_filter_matched' if args.completed_filter_screen else 'scan_preempt_matched' if args.scan_preempt_screen else 'manager_wait_diagnostic' if args.wait_manager_diag else 'padding_diagnostic' if args.padding_screen else 'sleep_diagnostic' if args.sleep_screen else 'poll_diagnostic' if args.poll_screen else 'packed_workspace' if reference else 'cache_diagnostic' if args.cache_screen else 'service_diagnostic' if args.service_screen else 'admission_diagnostic' if args.admission_screen else 'helper_concurrency',
        'limitations': ['single lacks local compact service', 'production racecheck not cleared'],
        'acceptance': 'no formal same-capability scaling or target completion from this screen'})
    results = {}
    for round_index in range(2):
        for label, kind, n, workers, enabled, helpers, budget, admit, probe_calls, services, carveout in (configs if round_index == 0 else reversed(configs)):
            key = f'r{round_index}_{label}'
            env = clean_environment()
            env.update(MLMQ_WORK_BLOCKS=str(workers), MLMQ_CUT_PERCENT=str(contract['cut_percent']),
                BENCH_SOURCE=str(contract['source']), BENCH_WARMUPS='1', BENCH_REPEATS='3',
                CUDA_MODULE_LOADING='EAGER', L3_SUPPLEMENT_ORACLE=str(oracle),
                MLMQ_BATCH_ENABLED=str(enabled), MLMQ_BATCH_FORCE='0', MLMQ_BATCH_SLOTS='128',
                MLMQ_BATCH_BUDGET=str(budget), MLMQ_BATCH_MIN_SEEDS='1', MLMQ_BATCH_HELPER_BLOCKS=str(helpers))
            if args.admission_screen or args.service_screen or args.cache_screen or reference or args.poll_screen:
                env['MLMQ_BATCH_ADMIT'] = str(admit)
            if args.service_screen or args.cache_screen or reference or args.poll_screen:
                env.update(MLMQ_BATCH_PROBE_CALLS=str(probe_calls), MLMQ_BATCH_SERVICES=str(services))
            if args.cache_screen or reference or args.poll_screen:
                env['MLMQ_BATCH_SERVICE_CARVEOUT'] = str(carveout)
            if args.poll_screen:
                env['MLMQ_BATCH_SERVICE_POLL'] = str(service_poll[label])
            if args.padding_screen:
                env['MLMQ_BATCH_SERVICE_SHARED_BYTES'] = str(service_padding[label])
            if args.sleep_screen:
                env['MLMQ_BATCH_SLEEP_NS'] = str(service_sleep[label])
            if args.owner_bound_screen and kind in ('batch', 'owner_mirror'):
                env.update(MLMQ_BATCH_BOUND_MODE=str(bound_modes[label]), MLMQ_BATCH_BOUND_STEPS='32')
                if args.neighbors:
                    env['MLMQ_BATCH_BOUND_EDGE_LIMIT'] = str(args.neighbor_edge_limit)
            print('RUN', key, flush=True)
            binary = reference / 'mlmq_batch' if kind == 'reference' else build / ('mlmq_' + kind)
            if kind == 'reference_control' or (args.wait_manager_diag and kind == 'control'):
                binary = reference / 'mlmq_control'
            if kind == 'filter':
                binary = filter_build / 'mlmq_batch'
            if kind == 'combined':
                binary = combined_build / 'mlmq_batch'
            if kind == 'untimed':
                binary = untimed / 'mlmq_batch'
            if kind == 'owner_mirror':
                binary = owner_mirror / 'mlmq_batch'
            record = run_one(binary, graph, 'MLMQ', n, out / key, env,
                             contract['source'], 'L1SLF_L2DQ', 1, 3, 180, delta=contract['delta'])
            record['environment'] = env
            results[key] = record
            raw = (out / (key + '.log')).read_text()
            try:
                if not record['valid']:
                    raise ValueError(record['reason'])
                record['oracle'] = parse_oracle_contract(raw, 4, contract['vertices'])
                if not record['oracle']['valid']:
                    raise ValueError('oracle mismatch')
                if args.timing_diag and kind != 'untimed':
                    record['timing'] = parse_timing(raw, 4, n, 1)
                elif kind == 'untimed' and any(line.startswith('L3_TIMING ') for line in raw.splitlines()):
                    raise ValueError('untimed reference unexpectedly instrumented')
                if n == 2:
                    record['dual'] = parse_dual_contract(raw, 4, workers, contract['delta'], 19,
                        expected_window_mode=2, expected_window_min=25000, expected_window_max=25000,
                        expected_idle_backoff=0, require_l2_final=True, expected_worker_recovery=1,
                        expected_ack_capacity=1712)
                    if not record['dual']['valid']:
                        raise ValueError(record['dual']['errors'])
                if enabled:
                    record['runtime'] = parse_runtime(raw, 4, budget, 0, False)
                    if args.select_labels and kind=='batch':
                        record['selection']=parse_select(raw,4)
                    if args.owner_bound_screen and kind in ('batch', 'owner_mirror'):
                        record['bound'] = parse_bound(raw, 4, bound_modes[label], 32, 0)
                        if args.returned_bound and kind=='batch':
                            record['returned']=parse_bound_returned(raw,4,bound_modes[label],0,record['runtime'])
                        if args.neighbors:
                            record['neighbors'] = parse_bound_neighbors(raw, 4, bound_modes[label],
                                args.neighbor_edge_limit, 0, record['runtime'])
                        if (kind == 'batch' and args.helper_mirror) or (kind == 'owner_mirror' and args.reference_helper_mirror):
                            record['placement'] = parse_bound_placement(raw, 4, record['bound']['config'])
                    if args.counter_factorial and kind != 'reference':
                        record['completed_filter'] = parse_completed_filter(raw, 4, int(kind in ('filter', 'combined')), 0)
                    if args.completed_filter_screen and kind == 'batch':
                        record['completed_filter'] = parse_completed_filter(raw, 4, 1, 0)
                    record['helpers'] = parse_helpers(raw, 4, helpers, record['runtime'])
                    if args.admission_screen or args.service_screen or args.cache_screen or reference or args.poll_screen:
                        record['admission'] = parse_admission(raw, 4, admit, record['runtime'])
                    if args.service_screen or args.cache_screen or reference or args.poll_screen:
                        record['services'] = parse_services(raw, 4, services, probe_calls)
                    if args.cache_screen or reference or args.poll_screen:
                        record['cache'] = parse_cache(raw, 4, carveout)
                    if args.poll_screen:
                        record['poll'] = parse_poll(raw, 4, service_poll[label])
                    if args.padding_screen:
                        record['shared'] = parse_shared(raw, 4, service_padding[label])
                    if args.sleep_screen:
                        record['sleep'] = parse_sleep(raw, 4, service_sleep[label])
                        record['loops'] = parse_loops(raw, 4, helpers, services)
                    if reference:
                        expected = args.reference_helper_static if kind == 'reference' else 30888
                        if any(row['helper_static'] != expected for row in record['cache']['cache']):
                            raise ValueError('unexpected helper shared-memory footprint')
                    if admit and not sum(r['loans'] for r in record['runtime']):
                        raise ValueError('no loans in enabled treatment')
                    record['batch_install_ms'] = list(map(float, re.findall(r'^L3_BATCH_INSTALL slots=128 wall_ms=([0-9.]+)$', raw, re.M)))
                    if len(record['batch_install_ms']) != 1:
                        raise ValueError('missing replication/install cost')
                if args.scan_preempt_screen and ('L3_WAIT ' in raw or 'L3_WAIT_REASON ' in raw):
                    raise ValueError('performance screen unexpectedly has wait instrumentation')
                if args.wait_manager_diag:
                    if kind == 'batch':
                        record['manager_wait'] = parse_manager_wait(raw, 4)
                        if args.inject_wait_diag:
                            record['inject_wait'] = parse_inject_wait(raw, 4)
                    elif 'L3_WAIT ' in raw or 'L3_WAIT_REASON ' in raw:
                        raise ValueError('reference unexpectedly has wait instrumentation')
                record['setup'] = [dict(re.findall(r'(\w+)=([^ ]+)', line)) for line in raw.splitlines() if line.startswith('BENCH_SETUP ')]
                if len(record['setup']) != 1:
                    raise ValueError('missing setup cost')
            except Exception as error:
                record.update(valid=False, error=str(error))
                write_json(out / 'status.json', {'complete': False, 'results': results})
                raise
            write_json(out / 'status.json', {'complete': False, 'results': results})
            print('PASS', key, flush=True)
    grouped = {}
    for label, *_ in configs:
        records = [results[f'r{i}_{label}'] for i in range(2)]
        samples = [s for r in records for s in r['samples'] if s['warmup'] == '0']
        grouped[label] = {field: {'samples_ms': [float(s[field]) for s in samples],
                                 'median_ms': median(float(s[field]) for s in samples)}
                          for field in ('solve_ms', 'query_wall_ms')}
        grouped[label]['host_process_elapsed_seconds'] = [r['host_elapsed_seconds'] for r in records]
        grouped[label]['initialization_other_ms'] = [float(r['setup'][0]['initialization_other_ms']) for r in records]
        grouped[label]['batch_install_ms'] = [v for r in records for v in r.get('batch_install_ms', [])]
        grouped[label]['loans_including_warmup'] = sum(x['loans'] for r in records for x in r.get('runtime', []))
        if all('loops' in r for r in records):
            grouped[label]['loop_totals_max_gpu_per_query'] = {}
            for field in ('helper', 'rx'):
                values = [max(sum(row[field]) for row in r['loops'][2*sample:2*sample+2])
                          for r in records for sample in range(1, 4)]
                grouped[label]['loop_totals_max_gpu_per_query'][field] = {'samples': values, 'median': median(values)}
        if all('timing' in r for r in records):
            timing = {field: [] for field in ('launch_gap_ms', 'manage_launch_ms', 'work_launch_ms',
                       'sync_wait_ms', 'manage_stream_ms', 'work_stream_ms', 'barrier_return_ms')}
            for r in records:
                for sample in range(1, 4):
                    rows = [t for t in r['timing'] if t['repeat'] == sample]
                    for field, a, b in (('launch_gap_ms', 'work_before_ms', 'manage_after_ms'),
                                        ('manage_launch_ms', 'manage_after_ms', 'manage_before_ms'),
                                        ('work_launch_ms', 'work_after_ms', 'work_before_ms'),
                                        ('sync_wait_ms', 'sync_after_ms', 'sync_before_ms')):
                        timing[field].append(max(t[a]-t[b] for t in rows))
                    for field in ('manage_stream_ms', 'work_stream_ms', 'barrier_return_ms'):
                        timing[field].append(max(t[field] for t in rows))
            grouped[label]['timing_max_gpu_per_query'] = {
                field: {'samples_ms': values, 'median_ms': median(values)} for field, values in timing.items()}
    bases = ('C1_107', 'C2_107', 'C2_97', 'T2_off97', 'T2_h1_admit0' if args.admission_screen else 'T2_h1_b64')
    treatments = ('T2_h8_admit0', 'T2_h8_admit1') if args.admission_screen else ('T2_h8_b64', 'T2_h8_b512')
    if args.service_screen:
        bases = ('C1_107', 'C2_107', 'C2_97', 'T2_off97', 'T2_s0p0')
        treatments = ('T2_s1p0', 'T2_s2p0', 'T2_s3p0', 'T2_s3p1', 'T2_loans')
    if args.cache_screen:
        bases = ('C1_107', 'C2_107', 'C2_97', 'T2_off97', 'T2_data', 'T2_loans_default')
        treatments = ('T2_h_preferred', 'T2_rx_preferred', 'T2_idle_preferred', 'T2_loans_preferred')
    if reference:
        bases = ('C1_107', 'C2_107', 'R2_off97', 'T2_off97', 'R2_helper', 'R2_loans')
        treatments = ('T2_helper', 'T2_loans')
    if args.poll_screen:
        bases = ('C1_107', 'C2_107', 'T2_off97', 'T2_data')
        treatments = ('T2_h_sleep', 'T2_h_poll', 'T2_rx_sleep', 'T2_rx_poll',
                      'T2_both_sleep', 'T2_both_poll', 'T2_loans')
    if args.sleep_screen:
        bases = ('C1_107', 'C2_107', 'T2_off97', 'T2_data', 'T2_h_sleep', 'T2_rx_sleep', 'T2_both_sleep', 'T2_loans')
        treatments = ('T2_h_slow', 'T2_rx_slow', 'T2_both_slow', 'T2_loans_slow')
    if args.wait_manager_diag or args.scan_preempt_screen:
        bases += ('R2_data',)
        treatments += ('T2_data',)
    if args.padding_screen:
        treatments = tuple(x.replace('_preferred', '_padded') for x in treatments)
    if args.counter_factorial:
        bases = ('C1_107', 'C2_107', 'B2_off', 'B2_data', 'B2_loans', 'F2_loans')
        treatments = ('A2_off', 'A2_data', 'F2_data', 'AF2_data', 'A2_loans', 'F2_loans', 'AF2_loans')
    if args.owner_bound_screen:
        bases = ('C1_107', 'C2_107', 'B2_off', 'B2_data', 'B2_loans', 'T2_mode0', 'T2_mode3', 'T2_mode1')
        treatments = ('T2_off', 'T2_data', 'T2_mode0', 'T2_mode3', 'T2_mode1', 'T2_mode2')
        if owner_mirror:
            bases += tuple(f'O2_mode{mode}' for mode in (0, 3, 1, 2))
    ratios = {field: {f'{base}/{treatment}': grouped[base][field]['median_ms']/grouped[treatment][field]['median_ms']
                     for base in bases for treatment in treatments}
              for field in ('solve_ms', 'query_wall_ms')}
    verify_tree(build)
    verify_tree(harness)
    if filter_build:
        verify_tree(filter_build)
    if combined_build:
        verify_tree(combined_build)
    if reference:
        verify_tree(reference)
    if owner_mirror:
        verify_tree(owner_mirror)
    if untimed:
        verify_tree(untimed)
    decomposition = {}
    if args.service_screen:
        differences = [('installed_data', 'T2_s0p0', 'T2_off97'), ('helper_only', 'T2_s1p0', 'T2_s0p0'),
                       ('rx_only', 'T2_s2p0', 'T2_s0p0'), ('both_services', 'T2_s3p0', 'T2_s0p0'),
                       ('borrow_probes', 'T2_s3p1', 'T2_s3p0'), ('net_admitted_loans', 'T2_loans', 'T2_s3p1')]
        decomposition = {field: {label: grouped[a][field]['median_ms']-grouped[b][field]['median_ms']
                                 for label, a, b in differences} for field in ('solve_ms', 'query_wall_ms')}
    if args.cache_screen:
        differences = [('helper_preferred_minus_default', 'T2_h_preferred', 'T2_h_default'),
                       ('rx_preferred_minus_default', 'T2_rx_preferred', 'T2_rx_default'),
                       ('loans_preferred_minus_default', 'T2_loans_preferred', 'T2_loans_default'),
                       ('idle_preferred_minus_data', 'T2_idle_preferred', 'T2_data'),
                       ('loans_preferred_minus_idle_preferred', 'T2_loans_preferred', 'T2_idle_preferred')]
        if args.padding_screen:
            differences = [tuple(x.replace('preferred', 'padded') for x in row) for row in differences]
        decomposition = {field: {label: grouped[a][field]['median_ms']-grouped[b][field]['median_ms']
                                 for label, a, b in differences} for field in ('solve_ms', 'query_wall_ms')}
    if args.poll_screen and not args.sleep_screen:
        differences = [('helper_resident', 'T2_h_sleep', 'T2_data'), ('helper_poll', 'T2_h_poll', 'T2_h_sleep'),
                       ('rx_resident', 'T2_rx_sleep', 'T2_data'), ('rx_poll', 'T2_rx_poll', 'T2_rx_sleep'),
                       ('both_resident', 'T2_both_sleep', 'T2_data'), ('both_poll', 'T2_both_poll', 'T2_both_sleep'),
                       ('probes_and_loans', 'T2_loans', 'T2_both_poll')]
        decomposition = {field: {label: grouped[a][field]['median_ms']-grouped[b][field]['median_ms']
                                 for label, a, b in differences} for field in ('solve_ms', 'query_wall_ms')}
    if args.sleep_screen:
        differences = [('helper_longer_sleep', 'T2_h_slow', 'T2_h_sleep'), ('rx_longer_sleep', 'T2_rx_slow', 'T2_rx_sleep'),
                       ('both_longer_sleep', 'T2_both_slow', 'T2_both_sleep'), ('loans_longer_sleep', 'T2_loans_slow', 'T2_loans')]
        decomposition = {field: {label: grouped[a][field]['median_ms']-grouped[b][field]['median_ms']
                                 for label, a, b in differences} for field in ('solve_ms', 'query_wall_ms')}
    if args.owner_bound_screen:
        differences = [('mirror_publication', 'T2_mode3', 'T2_mode0'),
                       ('peer_reads_without_pruning', 'T2_mode1', 'T2_mode3'),
                       ('pruning_effect', 'T2_mode2', 'T2_mode1'),
                       ('net_vs_previous_loans', 'T2_mode2', 'B2_loans')]
        decomposition = {field: {label: grouped[a][field]['median_ms']-grouped[b][field]['median_ms']
                                 for label, a, b in differences} for field in ('solve_ms', 'query_wall_ms')}
    write_json(out / 'summary.json', {'valid': True, 'formal_acceptance': False, 'same_capability_single': False,
        'grouped': grouped, 'ratios': ratios, 'results': results,
        'conditional_median_differences_ms': decomposition,
        'timing_scope': 'stream events include dispatch gaps; diagnostic instrumentation may perturb scheduling',
        'timing_perturbation_ms': {field: {label: grouped['T2_'+label][field]['median_ms']-grouped['U2_'+label][field]['median_ms']
                                         for label in ('data', 'h_sleep', 'loans')}
                                    for field in ('solve_ms', 'query_wall_ms')} if untimed else {},
        'setup_scope': 'replication/install excluded from solve; include setup for amortized claims'})
    write_json(out / 'status.json', {'complete': True, 'results': results})
    print(json.dumps(ratios, indent=2), flush=True)


if __name__ == '__main__':
    main()
