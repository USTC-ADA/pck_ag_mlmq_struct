#!/usr/bin/env python3
"""Exact causal wave audit for diagnostic packed replay; not solver acceptance."""
from pathlib import Path
import argparse, collections, hashlib, json, mmap, struct
INF=2**31-1
NAMES='loans seeds rows certified records remaining capacity empty budget failure'.split()
def require(ok, why):
    if not ok: raise ValueError(why)
def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda:f.read(1<<20),b''):h.update(chunk)
    return h.hexdigest()
class Graph:
    def __init__(self,path):
        self.file=Path(path).open('rb');self.map=mmap.mmap(self.file.fileno(),0,access=mmap.ACCESS_READ)
        version,width,self.n,self.m=struct.unpack_from('<4Q',self.map)
        require(version==1 and width==4,'GR layout')
        at=32;self.ends=memoryview(self.map)[at:at+8*self.n].cast('Q');at+=8*self.n
        self.cols=memoryview(self.map)[at:at+4*self.m].cast('i');at+=4*self.m+4*(self.m%2)
        require(at+4*self.m==len(self.map),'GR length')
        self.weights=memoryview(self.map)[at:].cast('i')
        require(self.ends[-1]==self.m,'CSR final offset')
    def edges(self,v):
        require(0<=v<self.n,'vertex out of graph')
        first=0 if v==0 else self.ends[v-1];last=self.ends[v]
        require(0<=first<=last<=self.m,'CSR row offset')
        for e in range(first,last):
            u,w=self.cols[e],self.weights[e]
            require(0<=u<self.n and w>=0,'invalid edge')
            yield u,w
    def degree(self,v):return self.ends[v]-(0 if v==0 else self.ends[v-1])
def load_batches(path,g):
    tokens=iter(Path(path).read_text().split());require(next(tokens)=='L3_REAL_BATCH_V1','batch magic')
    require(int(next(tokens))==g.n and int(next(tokens))==g.m,'batch graph dimensions')
    count=int(next(tokens));require(0<count<=2048,'batch count');batches=[]
    for _ in range(count):
        a=[int(next(tokens)) for _ in range(11)]
        owner,bin_id,slot,warp,begin,end,local,peer,available,inflight,n=a
        require(owner in (0,1) and 0<=begin<end<=g.n and 0<n<=32,'batch partition')
        seeds=[]
        for _ in range(n):
            v,queued,label,processed,degree=[int(next(tokens)) for _ in range(5)]
            require(begin<=v<end and 0<=label<=queued<processed<=INF and degree==g.degree(v),'seed metadata')
            seeds.append((v,label))
        batches.append(dict(owner=owner,begin=begin,end=end,seeds=seeds,quiet=local==0 and peer in (1,2)))
    require(next(tokens,None) is None,'trailing batch tokens')
    return batches

def audit_record(g,b,r,wave_width=32,allowed_policies=(0,1)):
    require(1<=wave_width<=32,'wave width')
    require(r['owner']==b['owner'] and r['executor']==1-b['owner'] and r['budget']==512,'execution metadata')
    require(r['round'] in (0,1) and r['policy'] in allowed_policies,'policy/round')
    own=lambda v:b['begin']<=v<b['end']
    labels={}
    for v,d in b['seeds']:labels[v]=min(labels.get(v,INF),d)
    cert={};pending=set(labels);rows=scans=0;capacity=False;edges=0
    for index,wave in enumerate(r['waves']):
        require(not capacity and rows<512 and pending,'trace continues after stop')
        require(len(wave)==min(wave_width,len(pending),512-rows),'wave take')
        vertices=[x[0] for x in wave]
        require(len(set(vertices))==len(vertices) and set(vertices)<=pending,'wave is not distinct pending work')
        additions=0
        for v,d,expand in wave:
            require(d==labels[v] and expand in (0,1) and expand==int(d<cert.get(v,INF)),'snapshot lacks exact prior relaxation witness')
            additions+=g.degree(v) if expand else 0
        if additions>768-len(labels):
            capacity=True;require(index==len(r['waves'])-1,'capacity stop not final');continue
        pending.difference_update(vertices)
        for v,d,expand in wave:
            if not expand:continue
            # The snapshot was checked against labels BEFORE this whole wave.
            # Every new label is therefore an actual seed-path extension.
            for dest,w in g.edges(v):
                edges+=1;candidate=d+w
                if candidate<INF and candidate<labels.get(dest,INF):
                    labels[dest]=candidate
                    if own(dest):pending.add(dest)
        for v,d,expand in wave:
            if expand:cert[v]=min(cert.get(v,INF),d)
        rows+=sum(x[2] for x in wave);scans+=1
        require(len(labels)<=768,'capacity overrun')
    require(capacity or not pending or rows==512,'trace omitted unfinished wave')
    expected={v:(d,cert.get(v,INF)) for v,d in labels.items()}
    journal={v:(d,c) for v,d,c in r['journal']}
    require(len(journal)==len(r['journal']) and journal==expected,'journal differs from exact traced labels/certificates')
    require(pending=={v for v in labels if own(v) and labels[v]<cert.get(v,INF)},'pending responsibility mismatch')
    # Independently check every full-row certificate even after later updates.
    for v,d in cert.items():
        for dest,w in g.edges(v):
            require(d+w>=INF or labels.get(dest,INF)<=d+w,'missing certified-row output')
    require(r['rows']==rows and r['scans']==scans and r['pending']==len(pending),'workspace counters')
    counters=[1,len(b['seeds']),rows,len(cert),len(labels),len(pending),int(capacity),int(not capacity and not pending),int(not capacity and bool(pending)),0]
    require(r['counts']==counters,'search counters')
    return dict(zip(NAMES,counters))|dict(repeated=rows-len(cert),edges=edges,remote=sum(not own(v) for v in labels))

def audit(path,batches,g,limit=0):
    selected=[i for owner in (0,1) for i,b in enumerate(batches) if b['owner']==owner]
    if limit:selected=sum(([i for i,b in enumerate(batches) if b['owner']==o][:limit] for o in (0,1)),[])
    expected={(i,r,p) for i in selected for r in range(2) for p in range(2)};seen=set();totals=collections.defaultdict(collections.Counter);pairs={}
    for line in Path(path).open():
        row=json.loads(line);key=(row['batch'],row['round'],row['policy'])
        require(key in expected and key not in seen,'unexpected/duplicate record');seen.add(key)
        value=audit_record(g,batches[key[0]],row)
        totals[str(key[2])].update(value);pairs[key]=value
    require(seen==expected,'missing records')
    comparisons=[]
    for i in selected:
        for r in range(2):
            a,z=pairs[i,r,0],pairs[i,r,1]
            comparisons.append(dict(batch=i,round=r,rows_delta=z['rows']-a['rows'],certified_delta=z['certified']-a['certified'],records_delta=z['records']-a['records'],repeat_delta=z['repeated']-a['repeated'],quiet=batches[i]['quiet']))
    return dict(valid=True,journals=len(seen),batches=len(selected),totals=dict(totals),paired=comparisons,limits=['historical eligible seed observations, not actual live loans','unbound instrumented helper replay; no full solve or transport timing','GPU insertion order remains nondeterministic; repeat samples retained','exact causal waves and complete-row residual obligations, not new full-graph Dijkstra'])
def main():
    p=argparse.ArgumentParser();p.add_argument('--capture',required=True,type=Path);p.add_argument('--input',required=True,type=Path);p.add_argument('--output',required=True,type=Path);p.add_argument('--limit',type=int,default=0);a=p.parse_args()
    require(not a.output.exists(),'output exists')
    capture=json.loads((a.capture/'capture.json').read_text());m=capture['manifest']
    require(sha(m['graph'])==m['graph_sha256'] and sha(m['oracle'])==m['oracle_sha256'],'capture graph/oracle hash')
    require(sha(a.capture/'batches.txt')==capture['batches_sha256'],'capture batch hash')
    g=Graph(m['graph']);b=load_batches(a.capture/'batches.txt',g)
    result=audit(a.input,b,g,a.limit);result['input_sha256']=sha(a.input)
    a.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='paired'}))
if __name__=='__main__':main()
