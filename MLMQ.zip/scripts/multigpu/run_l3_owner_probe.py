#!/usr/bin/env python3
"""Read-only owner-state diagnostic and dual-GPU oracle; not a performance run."""
import argparse
import json
from pathlib import Path
import subprocess
import sys

from analyze_l3_owner_probe import analyze_run
from run_l3_compact_screen import sanitizer_passed
from run_l3_upgrade_stage2 import ROOT, clean_environment, sha256, slurm_preflight, write_json


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('build', 'sanitizer', 'out'):
        parser.add_argument('--' + name, type=Path, required=True)
    args = parser.parse_args()
    if args.out.exists() or args.out.is_symlink():
        parser.error('output exists')
    args.out.mkdir(parents=True)
    out = args.out.resolve()
    allocation = slurm_preflight(out)
    build = args.build.resolve(strict=True)
    inputs = [build / n for n in ('mlmq_capture', 'mlmq_control', 'test_capture_sm80', 'source.tgz')]
    inputs += [ROOT / 'scripts/multigpu' / n for n in ('run_l3_owner_probe.py', 'analyze_l3_owner_probe.py',
        'prepare_l3_batch_replay.py', 'run_l3_balance_diag.py', 'run_l3_upgrade_stage2.py', 'run_l3_30h.py',
        'run_usa_road_matrix.py', 'run_l3_compact_screen.py')]
    hashes = {str(p): sha256(p) for p in inputs}
    write_json(out / 'manifest.json', {'allocation': allocation, 'hashes': hashes,
        'evidence_class': 'exploratory_live_owner_observation_not_migration_or_performance'})
    environment = clean_environment()
    status = {}

    def run(name, command, tool=None):
        if tool:
            command = [str(args.sanitizer), '--tool', tool, '--error-exitcode', '9'] + command
        print('RUN', name, flush=True)
        with (out / (name + '.log')).open('w') as log:
            result = subprocess.run(command, cwd=ROOT, env=environment, stdout=log,
                                    stderr=subprocess.STDOUT, timeout=360)
        raw = (out / (name + '.log')).read_text()
        status[name] = {'rc': result.returncode, 'sanitizer': tool}
        write_json(out / 'status.json', {'stage': name, 'complete': False, 'results': status})
        print('RC', name, result.returncode, flush=True)
        if result.returncode or not sanitizer_passed(raw, tool):
            raise RuntimeError('retained failed stage ' + name)
        apps = subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid', '--format=csv,noheader'], text=True)
        if apps.strip():
            raise RuntimeError('GPU processes remain; no cleanup attempted')
        return raw

    for tool in (None, 'memcheck', 'racecheck', 'synccheck'):
        raw = run('fixture_' + (tool or 'normal'), [str(build / 'test_capture_sm80')], tool)
        if 'OWNER_PROBE_CUDA_PASS ' not in raw or 'L1_CAPTURE_CUDA_PASS ' not in raw:
            raise RuntimeError('missing fixture pass')
    analyses = []
    for repeat in (0, 1):
        directory = out / ('capture' + str(repeat))
        run('capture_driver' + str(repeat), [sys.executable, str(ROOT / 'scripts/multigpu/run_l3_balance_diag.py'),
            '--binary', str(build / 'mlmq_capture'), '--out', str(directory),
            '--progress-only', '--require-q2-tail', '--require-l1-supply'])
        print('ANALYZE', repeat, flush=True)
        analysis = analyze_run(directory)
        write_json(out / ('analysis' + str(repeat) + '.json'), analysis)
        analyses.append(analysis)
    run('control_oracle', [sys.executable, str(ROOT / 'scripts/multigpu/run_l3_balance_diag.py'),
        '--binary', str(build / 'mlmq_control'), '--out', str(out / 'control'), '--oracle-only'])
    if any(sha256(Path(p)) != expected for p, expected in hashes.items()):
        raise RuntimeError('binary/source changed during run')
    write_json(out / 'summary.json', {'valid': True, 'analyses': analyses, 'not_solve_speedup': True,
        'default_off_control_correct': json.loads((out / 'control/summary.json').read_text())['valid']})
    write_json(out / 'status.json', {'complete': True, 'stage': 'complete', 'results': status})
    print('OWNER_PROBE_PIPELINE_PASS not_migration_not_performance=1', flush=True)


if __name__ == '__main__':
    main()
