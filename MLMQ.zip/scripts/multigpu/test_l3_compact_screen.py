import unittest
from run_l3_compact_screen import sanitizer_passed


class SanitizerTests(unittest.TestCase):
    def test_racecheck_uses_own_summary(self):
        raw = '========= RACECHECK SUMMARY: 0 hazards displayed (0 errors, 0 warnings)\n'
        self.assertTrue(sanitizer_passed(raw, 'racecheck'))
        self.assertFalse(sanitizer_passed(raw, 'memcheck'))
        for bad in (raw.replace('0 warnings', '1 warnings'), raw.replace('0 errors', '1 errors'),
                    raw.replace('0 hazards', '1 hazards'), raw + raw, ''):
            self.assertFalse(sanitizer_passed(bad, 'racecheck'))

    def test_error_summaries(self):
        raw = '========= ERROR SUMMARY: 0 errors\n'
        for tool in ('memcheck', 'synccheck'):
            self.assertTrue(sanitizer_passed(raw, tool))
            for bad in ('', raw.replace('0 errors', '1 errors'), raw + raw):
                self.assertFalse(sanitizer_passed(bad, tool))
        self.assertFalse(sanitizer_passed(raw, 'racecheck'))

    def test_unknown_tool_rejected(self):
        with self.assertRaises(ValueError):
            sanitizer_passed('', 'typo')


if __name__ == '__main__':
    unittest.main()
