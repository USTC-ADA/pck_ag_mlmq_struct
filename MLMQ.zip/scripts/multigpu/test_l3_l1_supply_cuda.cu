// Compile locally; execute only inside a Slurm GPU allocation.
#define L3_PROGRESS_DIAG true
#define L3_Q2_TAIL_DIAG true
#define L3_L1_SUPPLY_DIAG true
#define L3_L1_CAPTURE_DIAG true
#define L3_TERM_ONLY_WORKER true
#define L3_DIRECT_RX true
#include "../../SSSP/sssp.cuh"
#include "../../SSSP/l3/l3_sync.cuh"
#include "../../SSSP/l3/l3_progress.cuh"

// Supply observation only needs the ordinary queued distance accessor.
__host__ __device__ node_struct::node_struct() : id(0), dist(INT_MAX) {}
__device__ VALUE_TYPE node_struct::get_data() { return dist; }
#include "../../SSSP/l3/l3_l1_supply_diag.cuh"

#include <cstdio>
#include <cstdlib>

__global__ static void supply_fixture()
{
    extern __shared__ int s[];
    auto &queue = reinterpret_cast<l1_SLF_queue<NODE_TYPE> *>(s)[0];
    ml_queue<NODE_TYPE, l1_SLF_queue<NODE_TYPE>, l2_delta_queue<NODE_TYPE>> mlmq;
    const int lane = threadIdx.x;
    const int rows[5] = {0, 2, 5, 6, 10};
    const VALUE_TYPE processed[5] = {INT_MAX, 10, 10, 10, 10};
    const VALUE_TYPE authoritative[5] = {INT_MAX, 3, 11, 10, 1};
    const int columns[10] = {101, 104, 100, 102, 103, 103, 100, 101, 102, 104};
    const VALUE_TYPE weights[10] = {1, 1, 1, 1, 1, 1, 1, 1, 1, 1};
    if (!lane) {
        g_l3_l1_capture_warps = 8;
        queue.l = 62;
        queue.r = 2;
        queue.data_size = 4;
        for (int i = 0; i < 4; ++i) {
            queue.data[(62 + i) % 64].id = 101 + i;
            queue.data[(62 + i) % 64].dist = i == 0 ? 4 : i == 1 ? 12 : i == 2 ? 10 : 2;
        }
        l3_atomic_store_release<cuda::thread_scope_device>(&g_l3_l1_supply_epoch, 1);
    }
    __syncwarp();
    l3_l1_supply_observe(mlmq, 0, 0, lane, rows, processed, 100, 104, authoritative, 17, columns, weights);
    if (!lane) {
        assert(queue.l == 62 && queue.r == 2 && queue.data_size == 4);
        assert(queue.data[62].id == 101 && queue.data[62].dist == 4);
        // Same epoch must not overwrite the first snapshot.
        queue.data[62].id = 0;
    }
    __syncwarp();
    l3_l1_supply_observe(mlmq, 0, 0, lane, rows, processed, 100, 104);
    if (!lane)
        l3_atomic_store_release<cuda::thread_scope_device>(&g_l3_l1_supply_epoch, 2);
    __syncwarp();
    l3_l1_supply_observe(mlmq, 0, 0, lane, rows, processed, 100, 104);
    if (!lane) {
        queue.data_size = 0;
        l3_atomic_store_release<cuda::thread_scope_device>(&g_l3_l1_supply_epoch, 3);
    }
    __syncwarp();
    l3_l1_supply_observe(mlmq, 0, 0, lane, rows, processed, 100, 104);
    if (!lane) {
        queue.l = 63;
        queue.r = 31;
        queue.data_size = 32;
        for (int i = 0; i < 32; ++i) {
            queue.data[(63 + i) % 64].id = 101;
            queue.data[(63 + i) % 64].dist = 20;
        }
        l3_atomic_store_release<cuda::thread_scope_device>(&g_l3_l1_supply_epoch, 4);
    }
    __syncwarp();
    // Null filter admits all 32 duplicate records, NOT 32 distinct vertices.
    l3_l1_supply_observe(mlmq, 0, 0, lane, rows, nullptr, 100, 104);
    if (!lane) {
        assert(queue.l == 63 && queue.r == 31 && queue.data_size == 32);
        l3_atomic_store_release<cuda::thread_scope_device>(&g_l3_l1_supply_epoch, 0);
    }
    __syncwarp();
    l3_l1_supply_observe(mlmq, 0, 0, lane, rows, processed, 100, 104);
}

static void require_cuda(cudaError_t status)
{
    if (status == cudaSuccess) return;
    std::fprintf(stderr, "L1_SUPPLY_CUDA_FAIL %s\n", cudaGetErrorString(status));
    std::exit(2);
}

int main()
{
    if (!std::getenv("SLURM_JOB_ID")) {
        std::fputs("L1 supply CUDA test requires a Slurm allocation\n", stderr);
        return 2;
    }
    supply_fixture<<<1, 32, sizeof(l1_SLF_queue<NODE_TYPE>)>>>();
    require_cuda(cudaGetLastError());
    require_cuda(cudaDeviceSynchronize());
    const l3_l1_supply_sample expected[] = {
        {6, 5, 2, 0, 4}, {4, 5, 1, 1, 4},
        {0, 1, 0, 0, 0}, {64, 33, 32, 0, 2}, {0, 0, 0, 0, 0},
    };
    for (int bin = 0; bin < 5; ++bin) {
        l3_l1_supply_sample actual = {};
        require_cuda(cudaMemcpyFromSymbol(&actual, g_l3_l1_supply, sizeof(actual),
            bin * L3_L1_SUPPLY_WARPS * sizeof(actual)));
        const auto &want = expected[bin];
        if (actual.edges != want.edges || actual.raw_plus_one != want.raw_plus_one ||
                actual.eligible != want.eligible || actual.invalid != want.invalid ||
                actual.max_degree != want.max_degree) {
            std::fprintf(stderr, "L1_SUPPLY_CUDA_FAIL bin=%d\n", bin);
            return 1;
        }
    }
    l3_l1_capture_batch capture = {};
    require_cuda(cudaMemcpyFromSymbol(&capture, g_l3_l1_capture, sizeof(capture)));
    if (capture.warp_plus_one != 1 || capture.begin != 100 || capture.end != 104 ||
        capture.raw != 4 || capture.eligible != 2 || capture.inflight != 17 ||
        capture.items[0].vertex != 100 || capture.items[0].queued != 4 ||
        capture.items[0].authoritative != 3 || capture.items[0].processed != 10 ||
        capture.items[0].degree != 2 || capture.items[0].eligible != 1 ||
        capture.items[1].eligible != 0 || capture.items[2].eligible != 0 ||
        capture.items[3].vertex != 103 || capture.items[3].authoritative != 1 ||
        capture.items[3].eligible != 1) {
        std::fputs("L1_CAPTURE_CUDA_FAIL initial immutable capture\n", stderr);
        return 1;
    }
    for (int bin = 0; bin < 128; ++bin) {
        int count = 0;
        for (int warp = 0; warp < 1712; ++warp) count += l3_l1_capture_slot(bin, warp, 1712) >= 0;
        if (count != L3_L1_CAPTURE_SLOTS) return 1;
    }
#if (L3_OWNER_PROBE_DIAG == true)
    l3_owner_probe::sample probe{};
    require_cuda(cudaMemcpyFromSymbol(&probe, g_l3_owner_probe, sizeof(probe)));
    if (probe.done != 1 || probe.seeds != 2 || probe.status != 0 || probe.count != 5 ||
        probe.rows > 64 || probe.epoch_end != 1 || !probe.cycles) return 1;
    bool seen[5] = {};
    const int labels[5] = {2, 2, 2, 1, 2};
    const int owner[4] = {3, 11, 10, 1};
    for (int i = 0; i < probe.count; ++i) {
        const auto &r = probe.records[i];
        const int vertex = r.vertex - 100;
        if (vertex < 0 || vertex >= 5 || seen[vertex] || r.distance != labels[vertex]) return 1;
        seen[vertex] = true;
        if (vertex < 4) {
            if (r.certificate != labels[vertex] || r.owner_before != owner[vertex] ||
                r.owner_after != owner[vertex] || r.processed != 10) return 1;
        } else if (r.certificate != INT_MAX || r.owner_before != -1 || r.owner_after != -1 || r.processed != -1) return 1;
    }
    std::puts("OWNER_PROBE_CUDA_PASS actual_owner_reads local_remote certificates original_queue_unchanged");
#endif
    std::puts("L1_CAPTURE_CUDA_PASS selected_warp original_credit labels zero_based no_overwrite");
    std::puts("L1_SUPPLY_CUDA_PASS wrap filter invalid empty duplicates epoch disabled");
}
