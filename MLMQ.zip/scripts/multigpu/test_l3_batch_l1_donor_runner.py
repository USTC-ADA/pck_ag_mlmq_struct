import unittest
from run_l3_batch_l1_donor import parse_cases


def fixture(quick):
    rounds = 2 if quick else 3
    lines = []
    for o in (0,1):
        for b in ((37,) if quick else (0,37)):
            for n in ((7,32) if quick else (1,7,32)):
                for d in ((1,) if quick else (0,1)):
                    for p in ((5,) if quick else (0,5)):
                        u = (n+1)//2 if d else n
                        wrap = sum((8*p+(8+n)*g+8)%64+n >= 64 for g in range(rounds))
                        ancestors = 8*(p+rounds)
                        lines.append(f'BATCH_L1_DONOR_CASE owner={o} begin={b} seeds={n} duplicate={d} prime={p} '
                                     f'rounds={rounds} loans={rounds} ancestors={ancestors} exported={rounds*n} '
                                     f'remote_records={rounds*u} packets={rounds} remote_delays={rounds} '
                                     f'local_delays={rounds} wrapped={wrap} source_writes={ancestors+rounds*u} '
                                     f'remote_writes={8+2*rounds*u} PASS')
    lines.append(f'BATCH_L1_DONOR_PASS cases={len(lines)} real_ml_read=1 real_slf=1 actual_remote=1 no_worker_ack=1 no_solver=1 no_performance=1')
    return '\n'.join(lines)+'\n'


class L1RunnerTests(unittest.TestCase):
    def test_exact_case_sets(self):
        self.assertEqual(len(parse_cases(fixture(False),False)),48)
        self.assertEqual(len(parse_cases(fixture(True),True)),4)

    def test_missing_duplicate_cases(self):
        raw=fixture(True)
        for bad in ('\n'.join(raw.splitlines()[1:]),raw+raw.splitlines()[0]+'\n',raw.replace('owner=1','owner=0')):
            with self.assertRaises(ValueError):parse_cases(bad,True)

    def test_credits_not_seed_count(self):
        for a,b in [('ancestors=56','ancestors=14'),('exported=14','exported=56'),('source_writes=64','source_writes=63'),('remote_writes=24','remote_writes=23')]:
            with self.subTest(change=a),self.assertRaises(ValueError):parse_cases(fixture(True).replace(a,b),True)

    def test_responsibility_and_ring_coverage(self):
        for a,b in [('remote_delays=2','remote_delays=0'),('local_delays=2','local_delays=0'),('wrapped=1','wrapped=0'),('remote_records=8','remote_records=7')]:
            with self.subTest(change=a),self.assertRaises(ValueError):parse_cases(fixture(True).replace(a,b),True)

    def test_scope_and_final_marker(self):
        raw=fixture(True)
        for a,b in [('real_ml_read=1','real_ml_read=0'),('real_slf=1','real_slf=0'),('no_worker_ack=1','no_worker_ack=0'),('no_solver=1','no_solver=0')]:
            with self.subTest(change=a),self.assertRaises(ValueError):parse_cases(raw.replace(a,b),True)
        with self.assertRaises(ValueError):parse_cases(raw+raw.splitlines()[-1]+'\n',True)


if __name__=='__main__':unittest.main()
