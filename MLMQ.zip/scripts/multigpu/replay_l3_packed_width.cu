// Diagnostic replay of historical eligible L1 seeds, not live transfer/solve.
// Build script inserts a read-only trace call into a frozen copy of packed.
#include <cuda_runtime.h>
#include <cassert>
#include <climits>
struct trace_item {int vertex,distance,expand,take;};
constexpr int trace_waves=1024;
__device__ trace_item *trace_data;
__device__ int *trace_count;
__device__ void packed_trace_wave(int wave,int lane,int vertex,int distance,int expand,int take) {
    assert(wave>=0 && wave<trace_waves);
    if(!lane) trace_count[blockIdx.x]=wave+1;
    if(lane<take) trace_data[(blockIdx.x*trace_waves+wave)*32+lane]={vertex,distance,expand,take};
}
#include "../../SSSP/l3/l3_batch_compact_packed.cuh"
#include "l3_replay_graph_loader.h"
namespace packed=l3_batch_compact_packed;
namespace search=l3_batch_search_diag;
struct stats {int rows,scans;unsigned pending;};
__global__ void run_packed(relay::slot *slots,int *certs,stats *output,
    search::counters *counts,relay::graph_view graph,int policy,int budget) {
    __shared__ packed::workspace work;
    const int i=blockIdx.x,lane=threadIdx.x;
    if(policy==2) packed::expand_payload<false,true,true,8>(slots+i,graph,&work,certs+i*relay::result_capacity,budget,lane,{},nullptr,counts+i);
    else if(policy==1) packed::expand_payload<false,true,true>(slots+i,graph,&work,certs+i*relay::result_capacity,budget,lane,{},nullptr,counts+i);
    else packed::expand_payload<false,true,false>(slots+i,graph,&work,certs+i*relay::result_capacity,budget,lane,{},nullptr,counts+i);
    if(!lane) output[i]={work.rows,work.scans,work.tail-work.head};
}
template<class T> static T *alloc(size_t n) {T *p=nullptr;cu(cudaMalloc(&p,n*sizeof(T)));return p;}
struct selection_input {unsigned head;int pending,take,tie,seed,width;};
__global__ void width_selection(const selection_input *inputs,int *output) {
    __shared__ packed::workspace work;const int lane=threadIdx.x;const auto m=inputs[blockIdx.x];
    for(int i=lane;i<1024;i+=32) {work.fifo[i]=65535;work.distances[i]=m.tie?9:(i*37+m.seed)%97;}
    __syncwarp();
    for(int i=lane;i<m.pending;i+=32)work.fifo[(m.head+unsigned(i))&1023]=static_cast<unsigned short>((i*17+3)&1023);
    __syncwarp();
    if(lane<m.take)packed::select_front(&work,m.head,m.pending,lane,m.width);
    __syncwarp();
    for(int i=lane;i<1024;i+=32)output[blockIdx.x*1024+i]=work.fifo[i];
}
static void run_selection_units(const std::string &path) {
    FILE *out=fopen(path.c_str(),"wx");need(out,"selection output exists");
    std::vector<selection_input> input;
    for(int width:{8,32})for(int n:{1,7,8,9,31,32,33,65,127,768})
        for(unsigned head:{0u,3u,1001u,0xffffffefu})
            for(int take:{std::min(n,width),std::min(n,7),1})for(int tie:{0,1})
                input.push_back({head,n,take,tie,int(input.size()),width});
    for(int gpu=0;gpu<2;++gpu) {
        cu(cudaSetDevice(gpu));auto data=alloc<selection_input>(input.size());auto output=alloc<int>(input.size()*1024);
        cu(cudaMemcpy(data,input.data(),input.size()*sizeof(selection_input),cudaMemcpyHostToDevice));
        width_selection<<<input.size(),32>>>(data,output);cu(cudaGetLastError());cu(cudaDeviceSynchronize());
        std::vector<int> host(input.size()*1024);cu(cudaMemcpy(host.data(),output,host.size()*sizeof(int),cudaMemcpyDeviceToHost));
        for(size_t i=0;i<input.size();++i) {
            const auto &m=input[i];
            fprintf(out,"{\"gpu\":%d,\"case\":%zu,\"head\":%u,\"pending\":%d,\"take\":%d,\"tie\":%d,\"seed\":%d,\"width\":%d,\"fifo\":[",gpu,i,m.head,m.pending,m.take,m.tie,m.seed,m.width);
            for(int j=0;j<1024;++j)fprintf(out,"%s%d",j?",":"",host[i*1024+j]);fprintf(out,"]}\n");
        }
        cu(cudaFree(data));cu(cudaFree(output));printf("WIDTH_SELECT_PASS gpu=%d cases=%zu\n",gpu,input.size());
    }
    need(fclose(out)==0,"selection output close");
}
static void run_owner(const graph &g,const std::vector<batch> &all,device_graph *devices,
                      int owner,int limit,FILE *out) {
    std::vector<int> ids;
    for(size_t i=0;i<all.size();++i)if(all[i].gpu==owner && (!limit || int(ids.size())<limit))ids.push_back(int(i));
    const int n=int(ids.size());need(n>0,"no owner seeds");
    // CSR, packet and trace are local on the opposite GPU. No transport cost.
    const int gpu=1-owner;cu(cudaSetDevice(gpu));
    auto slots=alloc<relay::slot>(n);auto certs=alloc<int>(n*relay::result_capacity);
    auto stat=alloc<stats>(n);auto counts=alloc<search::counters>(n);
    auto traces=alloc<trace_item>(size_t(n)*trace_waves*32);auto lengths=alloc<int>(n);
    cu(cudaMemcpyToSymbol(trace_data,&traces,sizeof(traces)));cu(cudaMemcpyToSymbol(trace_count,&lengths,sizeof(lengths)));
    std::vector<relay::slot> input(n),output(n);std::vector<int> certificate(n*relay::result_capacity),length(n);
    std::vector<stats> observed(n);std::vector<search::counters> search_out(n);
    std::vector<trace_item> waves(trace_waves*32);
    for(int i=0;i<n;++i) {input[i].seeds=all[ids[i]].seeds.size();std::copy(all[ids[i]].seeds.begin(),all[ids[i]].seeds.end(),input[i].input);}
    const auto &first=all[ids[0]];
    relay::graph_view view{devices[gpu].rows+first.begin,devices[gpu].columns,devices[gpu].weights,first.begin,first.end-first.begin};
    for(int round=0;round<2;++round)for(int pos=0;pos<3;++pos) {
        const int policy=round?2-pos:pos;
        cu(cudaMemcpy(slots,input.data(),n*sizeof(relay::slot),cudaMemcpyHostToDevice));
        cu(cudaMemset(counts,0,n*sizeof(search::counters)));cu(cudaMemset(lengths,0,n*sizeof(int)));
        run_packed<<<n,32>>>(slots,certs,stat,counts,view,policy,512);
        cu(cudaGetLastError());cu(cudaDeviceSynchronize());
        cu(cudaMemcpy(output.data(),slots,n*sizeof(relay::slot),cudaMemcpyDeviceToHost));
        cu(cudaMemcpy(certificate.data(),certs,certificate.size()*sizeof(int),cudaMemcpyDeviceToHost));
        cu(cudaMemcpy(observed.data(),stat,n*sizeof(stats),cudaMemcpyDeviceToHost));
        cu(cudaMemcpy(search_out.data(),counts,n*sizeof(search::counters),cudaMemcpyDeviceToHost));
        cu(cudaMemcpy(length.data(),lengths,n*sizeof(int),cudaMemcpyDeviceToHost));
        for(int i=0;i<n;++i) {
            const auto &s=output[i];const auto &q=search_out[i];const auto &m=observed[i];
            need(s.result_status==relay::ok && s.seeds==input[i].seeds && s.results>0 && s.results<=packed::capacity,"invalid journal");
            for(int j=0;j<s.seeds;++j)need(s.input[j].vertex==input[i].input[j].vertex && s.input[j].distance==input[i].input[j].distance,"seed changed");
            need(length[i]>0 && length[i]<=trace_waves,"invalid trace length");
            cu(cudaMemcpy(waves.data(),traces+size_t(i)*trace_waves*32,length[i]*32*sizeof(trace_item),cudaMemcpyDeviceToHost));
            fprintf(out,"{\"owner\":%d,\"executor\":%d,\"batch\":%d,\"round\":%d,\"policy\":%d,\"budget\":512,\"rows\":%d,\"scans\":%d,\"pending\":%u,\"counts\":[%llu,%llu,%llu,%llu,%llu,%llu,%llu,%llu,%llu,%llu],\"journal\":[",owner,gpu,ids[i],round,policy,m.rows,m.scans,m.pending,q.loans,q.seeds,q.rows,q.certified,q.records,q.remaining,q.capacity,q.empty,q.budget,q.failure);
            for(int j=0;j<s.results;++j)fprintf(out,"%s[%d,%d,%d]",j?",":"",s.output[j].vertex,s.output[j].distance,certificate[i*relay::result_capacity+j]);
            fprintf(out,"],\"waves\":[");
            for(int w=0;w<length[i];++w) {
                const int take=waves[w*32].take;need(take>0 && take<=32,"invalid wave take");
                fprintf(out,"%s[",w?",":"");
                for(int lane=0;lane<take;++lane) {const auto &t=waves[w*32+lane];need(t.take==take,"inconsistent wave take");fprintf(out,"%s[%d,%d,%d]",lane?",":"",t.vertex,t.distance,t.expand);}
                fprintf(out,"]");
            }
            fprintf(out,"]}\n");
        }
        fflush(out);printf("PACKED_WIDTH_GROUP owner=%d executor=%d round=%d policy=%d batches=%d diagnostic_only=1\n",owner,gpu,round,policy,n);fflush(stdout);
    }
    cu(cudaFree(slots));cu(cudaFree(certs));cu(cudaFree(stat));cu(cudaFree(counts));cu(cudaFree(traces));cu(cudaFree(lengths));
}
int main(int argc,char **argv) {
    try {
        need(argc==6,"usage: trace GRAPH BATCHES ORACLE OUTPUT LIMIT_PER_OWNER");
        need(std::getenv("SLURM_JOB_ID"),"Slurm required");
        const int limit=std::stoi(argv[5]);need(limit>=0 && limit<=2048,"invalid limit");
        const auto g=load_graph(argv[1],argv[3]);const auto batches=load_batches(argv[2],g);
        int count=0;cu(cudaGetDeviceCount(&count));need(count==2,"exactly two GPUs required");
        device_graph devices[2];
        for(int gpu=0;gpu<2;++gpu) {
            cu(cudaSetDevice(gpu));int access=0,native=0;cu(cudaDeviceCanAccessPeer(&access,gpu,1-gpu));
            cu(cudaDeviceGetP2PAttribute(&native,cudaDevP2PAttrNativeAtomicSupported,gpu,1-gpu));need(access&&native,"P2P/native atomics required");
            devices[gpu].upload(g);
        }
        FILE *out=fopen(argv[4],"wx");need(out,"output exists or cannot open");
        for(int owner=0;owner<2;++owner)run_owner(g,batches,devices,owner,limit,out);
        need(fclose(out)==0,"output close");
        for(int gpu=0;gpu<2;++gpu) {cu(cudaSetDevice(gpu));devices[gpu].release();}
        run_selection_units(std::string(argv[4])+".selection.jsonl");
        printf("PACKED_WIDTH_PASS captured=%zu limit=%d payload_only_not_solve=1\n",batches.size(),limit);
        return 0;
    }catch(const std::exception &e) {fprintf(stderr,"PACKED_WIDTH_FAIL %s\n",e.what());return 2;}
}
