import unittest
from run_l3_batch_runtime import parse_runtime, parse_final_state, parse_helpers, parse_admission, parse_services, parse_cache, parse_poll, parse_timing, parse_sleep, parse_loops, parse_shared, parse_manager_wait


class RuntimeAuditTests(unittest.TestCase):
    def test_manager_only_wait_records(self):
        raw = '\n'.join('\n'.join(f'L3_WAIT gpu={g} slot={slot} span=100 last_work=0 c0=80 c1=15 c2=5 c3=0 c4=0 c5=0' for slot in (256,257))+'\n'+
            '\n'.join(f'L3_WAIT_REASON gpu={g} reason={i} count=0' for i in range(18)) for g in (0,1))
        result=parse_manager_wait(raw,1)
        self.assertEqual(len(result['manager']),2)
        self.assertEqual(len(result['tx']),2)
        self.assertEqual(result['uninstrumented_reason_ids'],list(range(14))+[17])
        for old,new in (('slot=256','slot=0'),('c1=15','c1=16'),('gpu=1','gpu=0'),
                        ('reason=17','reason=16'),('last_work=0','last_work=1'),('c2=5 c3=0','c2=0 c3=5')):
            with self.subTest(new=new),self.assertRaises(ValueError):
                parse_manager_wait(raw.replace(old,new),1)
        with self.assertRaises(ValueError):parse_manager_wait(raw+'\nL3_WAIT malformed',1)

    def test_shared_allocation_requires_isolation(self):
        raw = '\n'.join(f'L3_BATCH_SHARED_CONFIG gpu={g} requested=100496 helper_static=30888 helper_dynamic=69608 '
            'rx_static=512 rx_dynamic=99984 worker_total=68624 manager_total=100496 sm_capacity=167936 block_capacity=166912 sm_count=108'
            for g in (0, 1))
        self.assertEqual(len(parse_shared(raw, 1, 100496)), 2)
        for invalid in (raw.replace('gpu=1','gpu=0'), raw.replace('helper_dynamic=69608','helper_dynamic=0'),
                        raw.replace('rx_dynamic=99984','rx_dynamic=99983'), raw.replace('worker_total=68624','worker_total=64000'),
                        raw.replace('manager_total=100496','manager_total=64000'), raw.replace('block_capacity=166912','block_capacity=99000'),
                        raw+'\nL3_BATCH_SHARED_CONFIG malformed', raw.splitlines()[0]):
            with self.assertRaises(ValueError):
                parse_shared(invalid, 1, 100496)
        disabled = raw.replace('requested=100496','requested=0').replace('helper_dynamic=69608','helper_dynamic=0').replace('rx_dynamic=99984','rx_dynamic=0')
        self.assertEqual(len(parse_shared(disabled, 1, 0)), 2)
        with self.assertRaises(ValueError):
            parse_shared(disabled.replace('rx_dynamic=0','rx_dynamic=1'), 1, 0)

    def test_service_loop_participation(self):
        for services in range(4):
            helper = ','.join(str(10 if services & 1 and i < 4 else 0) for i in range(16))
            rx = '5,9' if services & 2 else '0,0'
            raw = '\n'.join(f'L3_BATCH_LOOP_AUDIT gpu={g} helper={helper} rx={rx}' for g in (0, 1))
            self.assertEqual(len(parse_loops(raw, 1, 2, services)), 2)
            for invalid in (raw.replace('gpu=1','gpu=0'), raw.replace('helper='+helper, 'helper=1'),
                            raw+'\nL3_BATCH_LOOP_AUDIT malformed', raw.splitlines()[0]):
                with self.assertRaises(ValueError):
                    parse_loops(invalid, 1, 2, services)
            with self.assertRaises(ValueError):
                parse_loops(raw, 1, 2, services ^ 1)

    def test_sleep_request_configuration(self):
        for requested in (64, 8192, 65536):
            raw = '\n'.join(f'L3_BATCH_SLEEP_CONFIG gpu={g} requested_ns={requested}' for g in (1, 0))
            self.assertEqual(len(parse_sleep(raw, 1, requested)), 2)
            for invalid in (raw.replace('gpu=1', 'gpu=0'), raw.splitlines()[0],
                            raw+'\nL3_BATCH_SLEEP_CONFIG malformed'):
                with self.assertRaises(ValueError):
                    parse_sleep(invalid, 1, requested)
            with self.assertRaises(ValueError):
                parse_sleep(raw, 1, 128)

    def test_timing_identity_and_boundaries(self):
        raw = '\n'.join(f'L3_TIMING gpu={g} repeat={i} warmup={int(i==0)} '
            'barrier_return_ms=0.01 manage_before_ms=0.02 manage_after_ms=0.03 '
            'work_before_ms=0.04 work_after_ms=0.05 sync_before_ms=0.06 '
            'sync_after_ms=1.01 finish_after_ms=1.02 manage_stream_ms=0.99 work_stream_ms=0.98'
            for i in range(2) for g in (0, 1))
        self.assertEqual(len(parse_timing(raw, 2, 2, 1)), 4)
        for invalid in (raw.replace('gpu=1', 'gpu=0'), raw.replace('repeat=1', 'repeat=0'),
                        raw.replace('warmup=1', 'warmup=0'), raw.replace('work_before_ms=0.04', 'work_before_ms=0.00'),
                        raw.replace('work_stream_ms=0.98', 'work_stream_ms=0.00'),
                        raw.replace('sync_after_ms=1.01', 'sync_after_ms=nan'),
                        raw+'\nL3_TIMING malformed', '\n'.join(raw.splitlines()[:-1])):
            with self.assertRaises(ValueError):
                parse_timing(invalid, 2, 2, 1)

    def test_service_poll_configuration(self):
        for enabled in (0, 1):
            raw = '\n'.join(f'L3_BATCH_POLL_CONFIG gpu={g} enabled={enabled}' for g in (1, 0))
            self.assertEqual(len(parse_poll(raw, 1, enabled)), 2)
            for invalid in (raw.replace('gpu=1', 'gpu=0'), raw.splitlines()[0],
                            raw+'\nL3_BATCH_POLL_CONFIG malformed'):
                with self.assertRaises(ValueError):
                    parse_poll(invalid, 1, enabled)
            with self.assertRaises(ValueError):
                parse_poll(raw, 1, 1-enabled)

    def test_cache_request_and_worker_geometry(self):
        raw = '\n'.join(f'L3_BATCH_CACHE_CONFIG gpu={g} requested=0 helper_preferred=0 rx_preferred=0 helper_static=32040 rx_static=0\n'
                         f'L3_BATCH_WORKER_CONFIG gpu={g} threads=544 dynamic_shared=32768 static_shared=1 registers=96 preferred=-1' for g in (0, 1))
        self.assertEqual(len(parse_cache(raw, 1, 0)['worker']), 2)
        for old, new in (('gpu=1', 'gpu=0'), ('requested=0', 'requested=-1'),
                         ('helper_preferred=0', 'helper_preferred=100'), ('rx_preferred=0', 'rx_preferred=-1'),
                         ('threads=544', 'threads=512'), ('dynamic_shared=32768', 'dynamic_shared=0'),
                         ('registers=96', 'registers=0')):
            with self.subTest(new=new), self.assertRaises(ValueError):
                parse_cache(raw.replace(old, new), 1, 0)
        with self.assertRaises(ValueError):
            parse_cache(raw+'\nL3_BATCH_CACHE_CONFIG malformed', 1, 0)

    def test_service_modes_are_explicit(self):
        for services in range(4):
            for probes in (0, 1):
                raw = '\n'.join(f'L3_BATCH_SERVICE_CONFIG gpu={g} helper={int(bool(services&1))} rx={int(bool(services&2))} probe_calls={probes}' for g in (1, 0))
                self.assertEqual(len(parse_services(raw, 1, services, probes)), 2)
                for invalid in (raw.replace('gpu=1', 'gpu=0'), raw.splitlines()[0],
                                raw+'\nL3_BATCH_SERVICE_CONFIG malformed'):
                    with self.assertRaises(ValueError):
                        parse_services(invalid, 1, services, probes)
                with self.assertRaises(ValueError):
                    parse_services(raw, 1, services ^ 1, probes)
                with self.assertRaises(ValueError):
                    parse_services(raw, 1, services, 1-probes)

    def test_zero_admission_requires_zero_work(self):
        runtime = parse_runtime(self.fixture(), 1, 64, 1, True)
        fields = ('loans', 'seeds', 'records', 'local', 'remote', 'certificates', 'helpers', 'receipts', 'active')
        for row in runtime:
            for field in fields:
                row[field] = 0
        raw = '\n'.join(f'L3_BATCH_ADMISSION_CONFIG gpu={g} allowed=0' for g in (1, 0))
        self.assertEqual(parse_admission(raw, 1, 0, runtime), [(1, 0), (0, 0)])
        for field in fields:
            runtime[0][field] = 1
            with self.subTest(field=field), self.assertRaises(ValueError):
                parse_admission(raw, 1, 0, runtime)
            runtime[0][field] = 0
        for invalid in (raw.replace('gpu=1', 'gpu=0'), raw.replace('allowed=0', 'allowed=1'),
                        raw+'\nL3_BATCH_ADMISSION_CONFIG malformed', raw.splitlines()[0]):
            with self.assertRaises(ValueError):
                parse_admission(invalid, 1, 0, runtime)

    def test_active_admission_is_audited(self):
        runtime = parse_runtime(self.fixture(), 1, 64, 1, True)
        raw = '\n'.join(f'L3_BATCH_ADMISSION_CONFIG gpu={g} allowed=1' for g in (0, 1))
        self.assertEqual(len(parse_admission(raw, 1, 1, runtime)), 2)

    def helper_fixture(self):
        return '\n'.join(f'L3_BATCH_HELPER_CONFIG gpu={gpu} blocks=2 warps=4\n'
                         f'L3_BATCH_HELPER_AUDIT gpu={gpu} blocks=2 active_warps=2 counts=1,0,1,0'
                         for gpu in (0, 1))

    def test_helper_audit(self):
        runtime = parse_runtime(self.fixture(), 1, 64, 1, True)
        self.assertEqual(len(parse_helpers(self.helper_fixture(), 1, 2, runtime)), 2)

    def test_helper_audit_mutations(self):
        runtime = parse_runtime(self.fixture(), 1, 64, 1, True)
        for a, b in (('gpu=1', 'gpu=0'), ('blocks=2', 'blocks=1'), ('warps=4', 'warps=2'),
                     ('active_warps=2', 'active_warps=1'), ('counts=1,0,1,0', 'counts=1,1'),
                     ('counts=1,0,1,0', 'counts=1,1,1,0')):
            with self.subTest(b=b), self.assertRaises(ValueError):
                parse_helpers(self.helper_fixture().replace(a, b), 1, 2, runtime)
        with self.assertRaises(ValueError):
            parse_helpers(self.helper_fixture()+'\nL3_BATCH_HELPER_CONFIG malformed', 1, 2, runtime)

    def test_final_audit_pending_and_certificates(self):
        raw = '\n'.join(f'FINAL_STATE gpu={gpu} term=2 request=1 exit=1 pending_local=0 marked_words=0 stranded=0 cache_ahead=0\nFINAL_BATCH_COMPLETED gpu={gpu} entries=5 raw_pending=3' for gpu in (0, 1))
        raw += '\nFINAL_AUDIT mismatches=0 residual_edges=0 cross_residual_edges=0'
        self.assertEqual(len(parse_final_state(raw, 1, 2, True)['states']), 2)
        for a, b in (('pending_local=0', 'pending_local=1'), ('request=1', 'request=0'),
                     ('entries=5', 'entries=2'), ('gpu=1', 'gpu=0'), ('exit=1', 'exit=0'),
                     ('residual_edges=0', 'residual_edges=1')):
            with self.subTest(b=b), self.assertRaises(ValueError):
                parse_final_state(raw.replace(a, b), 1, 2, True)

    def test_small_work_grid_retains_allocated_ack_capacity(self):
        from test_l3_30h_runner import _dual_log
        from run_l3_30h import parse_dual_contract
        raw = _dual_log().replace('work_blocks=107', 'work_blocks=4').replace('active_slots=1712', 'active_slots=64')
        def check(text, capacity=None):
            return parse_dual_contract(text, 1, 4, 400000, 19, expected_ack_capacity=capacity)['valid']
        self.assertFalse(check(raw))  # existing formal default is still strict
        self.assertTrue(check(raw, 1712))
        self.assertFalse(check(raw.replace('capacity=1712', 'capacity=1711'), 1712))
        self.assertFalse(check(raw.replace('capacity=1712', 'capacity=63'), 63))

    def test_inject_wait_observation_identity(self):
        from run_l3_batch_runtime import parse_inject_wait
        raw = '\n'.join(f'L3_INJECT_WAIT gpu={gpu} inject={i} phase={p} count={i+p}'
                        for repeat in range(2) for gpu in (0, 1)
                        for i in range(6) for p in range(6))
        self.assertEqual(len(parse_inject_wait(raw, 2)['rows']), 144)
        for broken in (raw.replace('gpu=1', 'gpu=0'), raw.replace('inject=5', 'inject=4'),
                       raw.replace('phase=0', 'phase=6'), raw + '\nL3_INJECT_WAIT malformed',
                       '\n'.join(raw.splitlines()[1:])):
            with self.assertRaises(ValueError):
                parse_inject_wait(broken, 2)

    def test_completed_filter_count_and_config(self):
        from run_l3_batch_runtime import parse_completed_filter
        raw = '\n'.join(f'L3_BATCH_COMPLETED_FILTER gpu={g} enabled=1 instrumented=1 checks=19 skipped=5' for g in (0, 1))
        self.assertEqual(len(parse_completed_filter(raw, 1, 1, 1)), 2)
        for a, b in (('gpu=1', 'gpu=0'), ('enabled=1', 'enabled=0'), ('checks=19', 'checks=4'),
                     ('skipped=5', 'skipped=-1'), ('instrumented=1', 'instrumented=0')):
            with self.assertRaises(ValueError):
                parse_completed_filter(raw.replace(a, b), 1, 1, 1)
        raw = raw.replace('instrumented=1', 'instrumented=0').replace('checks=19', 'checks=-1').replace('skipped=5', 'skipped=-1')
        self.assertEqual(len(parse_completed_filter(raw, 1, 1, 0)), 2)
        with self.assertRaises(ValueError):
            parse_completed_filter(raw.replace('skipped=-1', 'skipped=0'), 1, 1, 0)

    def fixture(self):
        return '\n'.join(f'L3_BATCH_RUNTIME_AUDIT gpu={gpu} slots=128 budget=64 force=1 loans=2 seeds=8 records=40 local=5 remote=6 certificates=9 helpers=2 receipts=1 active=0 PASS' for gpu in (0, 1))

    def test_pass(self):
        self.assertEqual(len(parse_runtime(self.fixture(), 1, 64, 1, True)), 2)

    def test_truncation_and_missing_samples(self):
        for raw in (self.fixture().splitlines()[0], self.fixture()):
            with self.assertRaises(ValueError):
                parse_runtime(raw, 2, 64, 1, True)

    def test_vacuous(self):
        with self.assertRaises(ValueError):
            parse_runtime(self.fixture().replace('remote=6', 'remote=0'), 1, 64, 1, True)

    def test_mutations(self):
        for a, b in (('gpu=1', 'gpu=0'), ('helpers=2', 'helpers=3'), ('active=0', 'active=1'),
                     ('seeds=8', 'seeds=65'), ('slots=128', 'slots=32'), ('local=5', 'local=50'),
                     ('certificates=9', 'certificates=41'), ('force=1', 'force=0'), ('budget=64', 'budget=8')):
            with self.subTest(b=b), self.assertRaises(ValueError):
                parse_runtime(self.fixture().replace(a, b), 1, 64, 1, True)


if __name__ == '__main__':
    unittest.main()
