#!/usr/bin/env python3
"""Deterministic sequential model for the RX responsibility protocol.

The model checks the IDLE/QUEUED/ACTIVE ownership and version rules used by
the CUDA implementation.  It deliberately does not claim to model CUDA
memory ordering, queue capacity, termination, or performance.
"""

from __future__ import annotations

import argparse
import json
import random
from dataclasses import dataclass
from pathlib import Path


INF = 1 << 60
SEED = 0x5258434F


@dataclass
class Responsibility:
    authoritative: int = INF
    propagated: int = INF
    version: int = 0
    state: str = "IDLE"
    tokens: int = 0
    claimed_version: int | None = None
    claimed_value: int = INF
    offers: int = 0
    tokens_created: int = 0
    queued_updates: int = 0
    active_updates: int = 0
    claims: int = 0
    requeues: int = 0

    def check(self) -> None:
        assert self.state in {"IDLE", "QUEUED", "ACTIVE"}
        assert self.tokens == (self.state == "QUEUED")
        assert (self.claimed_version is not None) == (self.state == "ACTIVE")
        assert self.version >= 0
        assert self.propagated >= self.authoritative

    def offer(self, value: int) -> bool:
        """Apply an authoritative winner and return whether it creates a token."""
        assert value < self.authoritative
        self.authoritative = value
        self.version += 1
        self.offers += 1
        created = self.state == "IDLE"
        if self.state == "IDLE":
            self.state = "QUEUED"
            self.tokens = 1
            self.tokens_created += 1
        elif self.state == "QUEUED":
            self.queued_updates += 1
        else:
            self.active_updates += 1
        self.check()
        return created

    def claim(self) -> None:
        assert self.state == "QUEUED" and self.tokens == 1
        self.tokens = 0
        self.state = "ACTIVE"
        self.claimed_version = self.version
        self.claimed_value = self.authoritative
        self.claims += 1
        self.check()

    def process(self) -> None:
        assert self.state == "ACTIVE"
        self.propagated = min(self.propagated, self.claimed_value)
        self.check()

    def commit(self) -> bool:
        assert self.state == "ACTIVE"
        assert self.claimed_version is not None
        changed = self.version != self.claimed_version
        self.claimed_version = None
        self.claimed_value = INF
        if changed:
            self.state = "QUEUED"
            self.tokens = 1
            self.requeues += 1
        else:
            self.state = "IDLE"
        self.check()
        return changed

    def service(self) -> None:
        self.claim()
        self.process()
        self.commit()

    def drain(self) -> None:
        while self.state != "IDLE":
            if self.state == "QUEUED":
                self.claim()
            self.process()
            self.commit()
        self.check()
        assert self.propagated == self.authoritative


def explicit_cases() -> dict[str, str]:
    queued = Responsibility()
    assert queued.offer(100)
    assert not queued.offer(70)
    assert not queued.offer(40)
    assert queued.tokens == 1 and queued.queued_updates == 2
    queued.drain()
    assert queued.propagated == 40 and queued.claims == 1

    active = Responsibility()
    assert active.offer(100)
    active.claim()
    active.process()
    assert not active.offer(60)
    assert not active.offer(20)
    assert active.commit()
    assert active.state == "QUEUED" and active.tokens == 1
    active.drain()
    assert active.propagated == 20 and active.requeues == 1

    # The two atomic linearizations of commit racing with a new offer both
    # retain exactly one responsibility for the new distance.
    commit_first = Responsibility()
    assert commit_first.offer(100)
    commit_first.claim()
    commit_first.process()
    assert not commit_first.commit()
    assert commit_first.offer(50)
    assert commit_first.state == "QUEUED" and commit_first.tokens == 1
    commit_first.drain()

    offer_first = Responsibility()
    assert offer_first.offer(100)
    offer_first.claim()
    offer_first.process()
    assert not offer_first.offer(50)
    assert offer_first.commit()
    assert offer_first.state == "QUEUED" and offer_first.tokens == 1
    offer_first.drain()
    assert commit_first.propagated == offer_first.propagated == 50

    return {
        "queued_merge": "PASS",
        "active_rearm": "PASS",
        "commit_offer_both_linearizations": "PASS",
    }


def randomized_trials(trials: int, steps: int) -> dict[str, int]:
    rng = random.Random(SEED)
    totals = {
        "offers": 0,
        "tokens_created": 0,
        "queued_updates": 0,
        "active_updates": 0,
        "claims": 0,
        "requeues": 0,
    }
    for _ in range(trials):
        responsibility = Responsibility()
        next_value = rng.randint(steps * 8, steps * 16)
        for _ in range(steps):
            action = rng.randrange(5)
            if action <= 2:
                next_value -= rng.randint(1, 7)
                responsibility.offer(next_value)
            elif responsibility.state == "QUEUED":
                responsibility.claim()
            elif responsibility.state == "ACTIVE":
                responsibility.process()
                responsibility.commit()
            responsibility.check()
        responsibility.drain()
        assert (
            responsibility.offers
            == responsibility.tokens_created
            + responsibility.queued_updates
            + responsibility.active_updates
        )
        assert responsibility.claims == responsibility.tokens_created + responsibility.requeues
        for field in totals:
            totals[field] += getattr(responsibility, field)
    return totals


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--trials", type=int, default=2000)
    parser.add_argument("--steps", type=int, default=200)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    if args.trials <= 0 or args.steps <= 0:
        parser.error("counts must be positive")

    payload = {
        "schema": 1,
        "status": "PASS",
        "seed": SEED,
        "trials": args.trials,
        "steps_per_trial": args.steps,
        "explicit": explicit_cases(),
        "randomized": randomized_trials(args.trials, args.steps),
        "scope": (
            "sequential state-machine model only; no CUDA memory ordering, "
            "queue capacity, termination, or performance claim"
        ),
    }
    text = json.dumps(payload, indent=2, sort_keys=True) + "\n"
    if args.output:
        args.output.write_text(text)
    print(text, end="")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
