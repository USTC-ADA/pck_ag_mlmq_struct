#!/usr/bin/env python3
"""Validate read-only live-owner probes. Observed opportunities, NOT saved work."""
import argparse
from collections import Counter, defaultdict
import heapq
import json
import mmap
from pathlib import Path
import re
import struct
import sys

from prepare_l3_batch_replay import parse_capture, INT_MAX
from run_l3_balance_diag import parse_l1_supply
from run_l3_upgrade_stage2 import sha256, write_json


def need(condition, message):
    if not condition:
        raise ValueError(message)


def records(raw, prefix, fields):
    rows = []
    for line in raw.splitlines():
        if not line.startswith(prefix + ' '):
            continue
        pairs = re.findall(r'\b(\w+)=(-?\d+)\b', line)
        row = {key: int(value) for key, value in pairs}
        need(len(pairs) == len(row) and set(row) == set(fields.split()), 'malformed ' + prefix)
        rows.append(row)
    return rows


def parse_probes(raw, batches, vertices):
    config = records(raw, 'L3_OWNER_PROBE_CONFIG', 'gpu budget slot observational coherent peer_execution owner_writes')
    need(len(config) == 2 and {r['gpu'] for r in config} == {0, 1}, 'missing/duplicate owner probe config')
    for r in config:
        need((r['budget'], r['slot'], r['observational'], r['coherent'], r['peer_execution'], r['owner_writes']) ==
             (64, 0, 1, 0, 0, 0), 'unsupported owner probe config')
    selected = {(b['gpu'], b['bin']): b for b in batches if b['slot'] == 0 and b['seeds']}
    headers = records(raw, 'L3_OWNER_PROBE', 'gpu bin seeds status records rows waves epoch_end cycles')
    items = records(raw, 'L3_OWNER_PROBE_ITEM',
                    'gpu bin index vertex distance certificate owner_before processed owner_after')
    probes = {}
    for r in headers:
        key = r['gpu'], r['bin']
        need(key in selected and key not in probes, 'duplicate/unmatched probe')
        need(r['seeds'] == len(selected[key]['seeds']) and r['status'] == 0 and 1 <= r['records'] <= 768 and
             0 <= r['rows'] <= 64 and 0 <= r['waves'] <= 64 and 0 <= r['epoch_end'] <= 128 and r['cycles'] > 0,
             'invalid probe header')
        need(r['epoch_end'] == 0 or r['epoch_end'] >= r['bin'] + 1, 'epoch moved backwards')
        probes[key] = {**r, 'batch': selected[key], 'items': {}}
    need(set(probes) == set(selected) and {p['gpu'] for p in probes.values()} == {0, 1},
         'missing selected probe or owner')
    for r in items:
        p = probes.get((r['gpu'], r['bin']))
        need(p is not None and 0 <= r['index'] < p['records'] and r['index'] not in p['items'],
             'duplicate/unmatched probe item')
        need(0 <= r['vertex'] < vertices and 0 <= r['distance'] <= r['certificate'] <= INT_MAX,
             'invalid journal label/certificate')
        b = p['batch']
        local = b['begin'] <= r['vertex'] < b['end']
        if local:
            need(0 <= r['owner_after'] <= r['owner_before'] <= INT_MAX and 0 <= r['processed'] <= INT_MAX,
                 'invalid owner observation')
        else:
            need((r['owner_before'], r['processed'], r['owner_after'], r['certificate']) ==
                 (-1, -1, -1, INT_MAX), 'remote record must not read owner-local arrays or be expanded')
        p['items'][r['index']] = r
    for p in probes.values():
        need(len(p['items']) == p['records'], 'missing probe item')
        p['items'] = [p['items'][i] for i in range(p['records'])]
        need(len({r['vertex'] for r in p['items']}) == p['records'], 'duplicate journal vertex')
        need(sum(r['certificate'] < INT_MAX for r in p['items']) <= p['rows'], 'more certificates than expansions')
    return list(probes.values())


def verify_probe(p, graph):
    b = p['batch']
    journal = {r['vertex']: r for r in p['items']}
    distance, queue = {}, []
    for seed in b['seeds']:
        vertex, value = seed['vertex'], seed['authoritative']
        need(vertex in journal and journal[vertex]['distance'] <= value, 'lost seed')
        need(len(list(graph.edges(vertex))) == seed['degree'], 'captured CSR degree mismatch')
        if value < distance.get(vertex, INT_MAX):
            distance[vertex] = value
            heapq.heappush(queue, (value, vertex))
    while queue:
        value, vertex = heapq.heappop(queue)
        if distance[vertex] != value:
            continue
        for dst, weight in graph.edges(vertex):
            need(weight >= 0, 'negative CSR weight')
            candidate = min(INT_MAX, value + weight)
            if dst in journal and candidate < distance.get(dst, INT_MAX):
                distance[dst] = candidate
                heapq.heappush(queue, (candidate, dst))
    for vertex, r in journal.items():
        need(r['distance'] >= graph.oracle(vertex) and r['distance'] >= distance.get(vertex, INT_MAX),
             'journal has no valid seed path or violates oracle')
        if r['owner_after'] >= 0:
            need(min(r['owner_before'], r['owner_after'], r['processed']) >= graph.oracle(vertex),
                 'owner observation below oracle')
        if r['certificate'] == INT_MAX:
            continue
        for dst, weight in graph.edges(vertex):
            candidate = min(INT_MAX, r['certificate'] + weight)
            need(candidate == INT_MAX or (dst in journal and journal[dst]['distance'] <= candidate),
                 'incomplete certified row')


def metrics(p):
    result = Counter(batches=1, seeds=p['seeds'], rows=p['rows'], records=p['records'])
    result['same_epoch_at_end'] = int(p['epoch_end'] == p['bin'] + 1)
    for r in p['items']:
        if r['owner_after'] < 0:
            result['remote_records'] += 1
            continue
        result['local_records'] += 1
        winner = r['distance'] < r['owner_after']
        post = min(r['distance'], r['owner_after'])
        debt = post < r['certificate']
        result['observed_candidate_winners'] += winner
        result['helper_local_debt'] += r['distance'] < r['certificate']
        result['conservative_local_debt'] += debt
        result['debt_without_candidate_win'] += debt and not winner
        result['debt_with_processed_le_post'] += debt and r['processed'] <= post
        result['owner_changed_during_reads'] += r['owner_before'] != r['owner_after']
        if r['certificate'] < INT_MAX:
            result['local_certificates'] += 1
            result['cert_with_processed_le_certificate'] += r['processed'] <= r['certificate']
            result['cert_with_processed_gt_certificate'] += r['processed'] > r['certificate']
    return result


class MappedGraph:
    def __init__(self, graph, oracle):
        need(sys.byteorder == 'little', 'little-endian reader required')
        self.files = [Path(graph).open('rb'), Path(oracle).open('rb')]
        self.maps = [mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ) for f in self.files]
        version, width, self.vertices, self.edge_count = struct.unpack_from('<4Q', self.maps[0])
        need(version == 1 and width == 4, 'unsupported GR')
        column_start = 32 + 8 * self.vertices
        weight_start = column_start + 4 * (self.edge_count + self.edge_count % 2)
        need(len(self.maps[0]) == weight_start + 4 * self.edge_count and len(self.maps[1]) == 4 * self.vertices,
             'graph/oracle size')
        self.ends = memoryview(self.maps[0])[32:column_start].cast('Q')
        self.columns = memoryview(self.maps[0])[column_start:column_start + 4 * self.edge_count].cast('i')
        self.weights = memoryview(self.maps[0])[weight_start:].cast('i')
        self.reference = memoryview(self.maps[1]).cast('i')

    def edges(self, vertex):
        start, end = self.ends[vertex - 1] if vertex else 0, self.ends[vertex]
        need(0 <= start <= end <= self.edge_count, 'CSR offsets')
        for edge in range(start, end):
            dst, weight = self.columns[edge], self.weights[edge]
            need(0 <= dst < self.vertices and weight >= 0, 'CSR edge')
            yield dst, weight

    def oracle(self, vertex):
        return self.reference[vertex]


def analyze_run(run):
    manifest = json.loads((run / 'manifest.json').read_text())
    status = json.loads((run / 'summary.json').read_text())
    need(status.get('valid') is True and status.get('rc') == 0 and
         not status.get('oracle_errors') and not status.get('dual_errors'), 'full dual-GPU run failed')
    graph_path, oracle_path = Path(manifest['graph']), Path(manifest['oracle'])
    need(sha256(graph_path) == manifest['graph_sha256'] and sha256(oracle_path) == manifest['oracle_sha256'],
         'input hash mismatch')
    graph = MappedGraph(graph_path, oracle_path)
    raw = (run / 'diagnostic.log').read_text()
    need(not parse_l1_supply(raw)['errors'], 'supply contract failed')
    batches = parse_capture(raw, graph.vertices, graph.vertices * manifest['cut_percent'] // 100)
    probes = parse_probes(raw, batches, graph.vertices)
    last_bin = {gpu: max(b['bin'] for b in batches if b['gpu'] == gpu) for gpu in (0, 1)}
    groups = defaultdict(Counter)
    detail = []
    for p in probes:
        verify_probe(p, graph)
        counts = metrics(p)
        b = p['batch']
        key = p['gpu'], b['quiet_observation'], p['bin'] >= last_bin[p['gpu']] // 2
        groups[key].update(counts)
        detail.append({'gpu': p['gpu'], 'bin': p['bin'], 'quiet_at_capture': key[1], 'late_half': key[2],
                       'metrics': dict(counts), 'epoch_end': p['epoch_end'], 'diagnostic_cycles': p['cycles']})
    return {'valid': True, 'not_solve_speedup': True, 'probe_batches': len(probes),
            'diagnostic_sha256': sha256(run / 'diagnostic.log'),
            'groups': [{'gpu': k[0], 'quiet_at_capture': k[1], 'late_half': k[2], **dict(v)} for k, v in sorted(groups.items())],
            'batches': detail,
            'limits': 'Read-only donor-local shadow, original L1 credit held. Noncoherent per-record owner reads; processed is admission, NOT completion. Prospective winners/debt are not actual atomic winners, saved expansions or net performance. Remote owner state not observed.'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    need(not args.out.exists(), 'output exists')
    write_json(args.out, analyze_run(args.run))
    print('OWNER_PROBE_ANALYSIS_PASS observational_not_saved_work=1')


if __name__ == '__main__':
    main()
