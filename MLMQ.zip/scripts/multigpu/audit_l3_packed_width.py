"""Explicit diagnostic contract: FIFO32, lane-min32, lane-min8."""
from pathlib import Path
import json,collections
from audit_l3_packed_trace import audit_record,require

def audit_width(path,batches,g,limit=0):
    selected=sum(([i for i,b in enumerate(batches) if b['owner']==o][:limit or None] for o in (0,1)),[])
    expected={(i,r,p) for i in selected for r in (0,1) for p in (0,1,2)};seen=set();totals=collections.defaultdict(collections.Counter);pairs={}
    for line in Path(path).open():
        row=json.loads(line);key=row['batch'],row['round'],row['policy'];require(key in expected and key not in seen,'unexpected width record');seen.add(key)
        value=audit_record(g,batches[key[0]],row,wave_width=8 if key[2]==2 else 32,allowed_policies=(0,1,2));value['waves']=row['scans']
        totals[str(key[2])].update(value);pairs[key]=value
    require(seen==expected,'missing width record')
    differences=[]
    for i in selected:
        for r in (0,1):
            z=pairs[i,r,2]
            for p in (0,1):
                v=pairs[i,r,p];differences.append(dict(batch=i,round=r,reference=p,**{k+'_delta':z[k]-v[k] for k in ('rows','certified','repeated','records','waves')}))
    return dict(valid=True,journals=len(seen),batches=len(selected),totals=dict(totals),paired=differences,limits=['isolated frozen prototype only; production unchanged','lane-min8 is not global min8','trace/Search enabled: not performance data','historical eligible snapshots, not real loans; no production credit/ACK'])

def audit_selection(path):
    cases=[]
    for width in (8,32):
        for n in (1,7,8,9,31,32,33,65,127,768):
            for head in (0,3,1001,0xffffffef):
                for take in (min(n,width),min(n,7),1):
                    for tie in (0,1):cases.append(dict(head=head,pending=n,take=take,tie=tie,seed=len(cases),width=width))
    expected={(g,i) for g in (0,1) for i in range(len(cases))};seen=set()
    for line in Path(path).open():
        row=json.loads(line);key=(row['gpu'],row['case']);require(key in expected and key not in seen,'unexpected selection record');seen.add(key);m=cases[key[1]]
        require(all(row[k]==v for k,v in m.items()),'selection metadata')
        queue=[65535]*1024
        for i in range(m['pending']):queue[(m['head']+i)&1023]=(i*17+3)&1023
        distance=lambda slot:9 if m['tie'] else (slot*37+m['seed'])%97
        for lane in range(m['take']):
            group=[((m['head']+offset)&1023,offset) for offset in range(lane,m['pending'],m['width'])]
            chosen=sorted(group,key=lambda x:(distance(queue[x[0]]),x[1]))[0][0];front=(m['head']+lane)&1023
            queue[front],queue[chosen]=queue[chosen],queue[front]
        require(row['fifo']==queue,'selection permutation/minimum/tie/canary')
    require(seen==expected,'missing selection record')
    return dict(valid=True,records=len(seen),physical_slots_checked=len(seen)*1024)
