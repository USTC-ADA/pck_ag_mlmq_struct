import copy
import unittest
from audit_l3_packed_trace import INF,audit_record
class Graph:
    n=5;m=5
    def edges(self,v):return iter({0:[(1,10),(2,1)],1:[(3,1)],2:[(1,1)],3:[(4,2)]}.get(v,[]))
    def degree(self,v):return len(list(self.edges(v)))
class TestTrace(unittest.TestCase):
    def setUp(self):
        self.g=Graph();self.b=dict(owner=0,begin=0,end=4,seeds=[(0,0)])
        self.r=dict(owner=0,executor=1,batch=0,round=0,policy=0,budget=512,rows=6,scans=4,pending=0,
            counts=[1,1,6,4,5,0,0,1,0,0],journal=[[0,0,0],[1,2,2],[2,1,1],[3,3,3],[4,5,INF]],
            waves=[[[0,0,1]],[[1,10,1],[2,1,1]],[[3,11,1],[1,2,1]],[[3,3,1]]])
    def test_exact_causal_paths(self):self.assertEqual(audit_record(self.g,self.b,self.r)['repeated'],2)
    def test_impossible_snapshot(self):
        self.r['waves'][1][0][1]=9
        with self.assertRaisesRegex(ValueError,'exact prior'):audit_record(self.g,self.b,self.r)
    def test_unwitnessed_longer_label(self):
        self.r['journal'][-1][1]=6
        with self.assertRaisesRegex(ValueError,'journal'):audit_record(self.g,self.b,self.r)
    def test_false_certificate(self):
        self.r['journal'][-1][2]=5
        with self.assertRaisesRegex(ValueError,'journal'):audit_record(self.g,self.b,self.r)
    def test_lost_root(self):
        self.r['journal'].pop(0)
        with self.assertRaisesRegex(ValueError,'journal'):audit_record(self.g,self.b,self.r)
    def test_lost_wave(self):
        self.r['waves'].pop()
        with self.assertRaisesRegex(ValueError,'unfinished'):audit_record(self.g,self.b,self.r)
    def test_wrong_counter(self):
        self.r['counts'][3]=5
        with self.assertRaisesRegex(ValueError,'search counters'):audit_record(self.g,self.b,self.r)
    def test_duplicate_wave_vertex(self):
        self.r['waves'][1][1]=copy.deepcopy(self.r['waves'][1][0])
        with self.assertRaisesRegex(ValueError,'distinct pending'):audit_record(self.g,self.b,self.r)
    def test_remote_expansion(self):
        self.r['waves'][3]=[[4,13,1]]
        with self.assertRaisesRegex(ValueError,'distinct pending'):audit_record(self.g,self.b,self.r)
    def test_narrow_model_requires_explicit_width(self):
        r=dict(self.r,rows=4,scans=4,pending=0,counts=[1,1,4,4,5,0,0,1,0,0],
            waves=[[[0,0,1]],[[2,1,1]],[[1,2,1]],[[3,3,1]]])
        self.assertEqual(audit_record(self.g,self.b,r,wave_width=1)['repeated'],0)
        with self.assertRaisesRegex(ValueError,'wave take'):audit_record(self.g,self.b,r)
    def test_capacity_preserves_seed_debt(self):
        class Large(Graph):
            def degree(self,v):return 769
        r=dict(self.r,rows=0,scans=0,pending=1,counts=[1,1,0,0,1,1,1,0,0,0],journal=[[0,0,INF]],waves=[[[0,0,1]]])
        self.assertEqual(audit_record(Large(),self.b,r)['capacity'],1)
if __name__=='__main__':unittest.main()
