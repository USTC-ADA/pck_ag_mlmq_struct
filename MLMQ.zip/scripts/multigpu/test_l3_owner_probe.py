import copy
import unittest
from test_l3_batch_capture import fixture
from prepare_l3_batch_replay import parse_capture
from analyze_l3_owner_probe import parse_probes, verify_probe, metrics, INT_MAX


def probe_fixture():
    lines = [fixture()]
    for gpu, vertex in ((0, 0), (1, 60)):
        lines += [f'L3_OWNER_PROBE_CONFIG gpu={gpu} budget=64 slot=0 observational=1 coherent=0 peer_execution=0 owner_writes=0',
                  f'L3_OWNER_PROBE gpu={gpu} bin=1 seeds=2 status=0 records=2 rows=1 waves=1 epoch_end=2 cycles=100',
                  f'L3_OWNER_PROBE_ITEM gpu={gpu} bin=1 index=0 vertex={vertex} distance=5 certificate=5 owner_before=4 processed=3 owner_after=3',
                  f'L3_OWNER_PROBE_ITEM gpu={gpu} bin=1 index=1 vertex={vertex+1} distance=6 certificate={INT_MAX} owner_before=9 processed={INT_MAX} owner_after=9']
    return '\n'.join(lines)


class TinyGraph:
    def edges(self, vertex):
        return [(vertex, 0), (vertex + 1, 1)] if vertex in (0, 60) else []

    def oracle(self, vertex):
        return 0


def parse(raw):
    return parse_probes(raw, parse_capture(raw, 100, 60), 100)


class OwnerProbeTests(unittest.TestCase):
    def test_valid_path_and_nonwinner_debt(self):
        for probe in parse(probe_fixture()):
            verify_probe(probe, TinyGraph())
            m = metrics(probe)
            self.assertEqual(m['conservative_local_debt'], 2)
            self.assertEqual(m['observed_candidate_winners'], 1)
            self.assertEqual(m['debt_without_candidate_win'], 1)
            self.assertEqual(m['debt_with_processed_le_post'], 1)
            self.assertEqual(m['owner_changed_during_reads'], 1)

    def test_missing_and_duplicate_evidence(self):
        raw = probe_fixture()
        for bad in ('\n'.join(raw.splitlines()[:-1]), raw + '\n' + raw.splitlines()[-1],
                    '\n'.join(x for x in raw.splitlines() if not x.startswith('L3_OWNER_PROBE gpu=0'))):
            with self.assertRaises(ValueError):
                parse(bad)

    def test_invalid_contract(self):
        for old, new in (('owner_writes=0', 'owner_writes=1'), ('coherent=0', 'coherent=1'),
                         ('peer_execution=0', 'peer_execution=1'), ('budget=64', 'budget=256'),
                         ('rows=1', 'rows=65'), ('owner_after=3', 'owner_after=8'),
                         ('epoch_end=2', 'epoch_end=1'), ('status=0', 'status=1'),
                         ('records=2', 'records=3'), ('seeds=2', 'seeds=1')):
            with self.subTest(old=old), self.assertRaises(ValueError):
                parse(probe_fixture().replace(old, new, 1))

    def test_remote_has_no_owner_observations(self):
        raw = probe_fixture().replace('vertex=1 distance=6', 'vertex=61 distance=6', 1)
        with self.assertRaises(ValueError):
            parse(raw)
        raw = raw.replace(f'owner_before=9 processed={INT_MAX} owner_after=9',
                          'owner_before=-1 processed=-1 owner_after=-1', 1)
        self.assertEqual(metrics(parse(raw)[0])['remote_records'], 1)

    def test_fabricated_path_and_missing_row_effect(self):
        p = parse(probe_fixture())[0]
        forged = copy.deepcopy(p)
        forged['items'][1]['distance'] = 1
        with self.assertRaisesRegex(ValueError, 'seed path'):
            verify_probe(forged, TinyGraph())
        incomplete = copy.deepcopy(p)
        incomplete['items'][1]['distance'] = 7
        with self.assertRaisesRegex(ValueError, 'incomplete'):
            verify_probe(incomplete, TinyGraph())

    def test_owner_below_oracle(self):
        class HigherOracle(TinyGraph):
            def oracle(self, vertex):
                return 4
        with self.assertRaisesRegex(ValueError, 'owner observation'):
            verify_probe(parse(probe_fixture())[0], HigherOracle())


if __name__ == '__main__':
    unittest.main()
