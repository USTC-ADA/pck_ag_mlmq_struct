import tempfile
from pathlib import Path
import unittest

from audit_l3_batch_peer_commit import INF, audit_case, dijkstra


GRAPH = '''BEGIN 37 VERTICES 4 ROUNDS 1
VERTEX 37 initial 0 distance 0 oracle 0 expected 0 seen 0
EDGE 37 38 80
VERTEX 38 initial 80 distance 80 oracle 80 expected 1 seen 1
EDGE 38 39 1
VERTEX 39 initial 2147483647 distance 81 oracle 81 expected 1 seen 1
VERTEX 40 initial 2147483647 distance 2147483647 oracle 2147483647 expected 0 seen 0
'''
JOURNAL = '''GEN 1 mode 0 budget 0 root 38 competitor 40 seeds 1 count 1 status 0 fallback 0 claims 1
SEED 38 80
RECORD 38 80 2147483647
'''
CASE = dict(begin=37, rounds=1, group=2, total_writes=10, fallbacks=0,
            capacity_stops=0, distinct512=0)


class PeerEvidenceAuditTests(unittest.TestCase):
    def check(self, graph=GRAPH, journal=JOURNAL, case=None):
        with tempfile.TemporaryDirectory() as directory:
            audit, saved = Path(directory) / 'audit.txt', Path(directory) / 'journal.txt'
            audit.write_text(graph)
            saved.write_text(journal)
            return audit_case(audit, saved, CASE if case is None else case)

    def test_nonzero_begin_unreachable_and_ancestor_credit(self):
        self.assertEqual(self.check()['total_writes'], 10)
        with self.assertRaisesRegex(ValueError, 'ancestor credit'):
            self.check(case={**CASE, 'total_writes': 2})

    def test_oracle_recomputed_even_when_saved_answers_agree(self):
        with self.assertRaisesRegex(ValueError, 'Dijkstra'):
            self.check(graph=GRAPH.replace('distance 81 oracle 81', 'distance 82 oracle 82'))

    def test_publication_multiplicity(self):
        with self.assertRaisesRegex(ValueError, 'multiplicity'):
            self.check(graph=GRAPH.replace('expected 1 seen 1', 'expected 1 seen 2', 1))

    def test_seed_snapshot(self):
        with self.assertRaisesRegex(ValueError, 'seed snapshot'):
            self.check(journal=JOURNAL.replace('SEED 38 80', 'SEED 38 81'))

    def test_seed_must_survive_return(self):
        with self.assertRaisesRegex(ValueError, 'seed missing'):
            self.check(journal=JOURNAL.replace('RECORD 38 80', 'RECORD 39 81'))

    def test_reachable_bound(self):
        with self.assertRaisesRegex(ValueError, 'reachable lower bound'):
            self.check(journal=JOURNAL.replace('RECORD 38 80', 'RECORD 38 79'))

    def test_complete_row_certificate(self):
        with self.assertRaisesRegex(ValueError, 'incomplete row certificate'):
            self.check(journal=JOURNAL.replace('RECORD 38 80 2147483647', 'RECORD 38 80 80'))
        complete = JOURNAL.replace('count 1', 'count 2').replace(
            'RECORD 38 80 2147483647', 'RECORD 38 80 80\nRECORD 39 81 2147483647')
        self.assertEqual(self.check(journal=complete)['certificates'], 1)

    def test_duplicate_generation_and_claim(self):
        for bad in (JOURNAL + JOURNAL, JOURNAL.replace('claims 1', 'claims 2')):
            with self.assertRaises(ValueError):
                self.check(journal=bad)

    def test_duplicate_journal_and_bad_count(self):
        for bad in (JOURNAL.replace('count 1', 'count 2'),
                    JOURNAL.replace('count 1', 'count 2') + 'RECORD 38 80 2147483647\n'):
            with self.assertRaises(ValueError):
                self.check(journal=bad)

    def test_graph_requires_nonnegative_owner_edges_and_all_vertices(self):
        for bad in (GRAPH.replace('EDGE 38 39 1', 'EDGE 38 39 -1'),
                    GRAPH.replace('EDGE 38 39 1', 'EDGE 38 41 1'),
                    '\n'.join(GRAPH.splitlines()[:-1])):
            with self.assertRaises(ValueError):
                self.check(graph=bad)

    def test_saturating_dijkstra_zero_cycle_parallel_edges(self):
        graph = {0: [(1, 5), (1, 0), (2, INF - 1)], 1: [(0, 0)], 2: [(3, 2)], 3: []}
        self.assertEqual(dijkstra(graph, [(0, 0), (0, 7)]), {0: 0, 1: 0, 2: INF - 1})


if __name__ == '__main__':
    unittest.main()
