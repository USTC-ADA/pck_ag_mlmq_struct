#!/usr/bin/env python3
"""Frozen-input dual-A100 compact/sweep component screen; never solve timing."""
import argparse
import json
from pathlib import Path
import re
import subprocess

from run_l3_upgrade_stage2 import ROOT, clean_environment, sha256, slurm_preflight, write_json
from run_l3_batch_capture_replay import summarize_replay


def sanitizer_passed(raw, tool):
    if tool is None:
        return True
    if tool == 'racecheck':
        return re.findall(r'^========= RACECHECK SUMMARY: (\d+) hazards displayed \((\d+) errors, (\d+) warnings\)$',
                          raw, re.MULTILINE) == [('0', '0', '0')]
    if tool in ('memcheck', 'synccheck'):
        return re.findall(r'^========= ERROR SUMMARY: (\d+) errors$', raw, re.MULTILINE) == ['0']
    raise ValueError('unsupported sanitizer')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("sweep", "compact", "fixture", "capture", "source_archive", "sanitizer", "out"):
        parser.add_argument("--" + name.replace("_", "-"), type=Path, required=True)
    args = parser.parse_args()
    if args.out.exists() or args.out.is_symlink():
        parser.error("output must not exist")
    args.out.mkdir(parents=True)
    out = args.out.resolve()
    allocation = slurm_preflight(out)
    prepared = json.loads((args.capture / 'prepared/capture.json').read_text())
    if json.loads((args.capture / 'capture/summary.json').read_text()).get('valid') is not True:
        raise ValueError('original full SSSP capture did not pass')
    contract = prepared['manifest']
    graph, oracle = Path(contract['graph']), Path(contract['oracle'])
    batches = args.capture / 'prepared/batches.txt'
    for path, expected in [(graph, contract['graph_sha256']), (oracle, contract['oracle_sha256']),
                           (batches, prepared['batches_sha256'])]:
        if sha256(path) != expected:
            raise ValueError('changed capture input: ' + str(path))
    paths = [args.sweep, args.compact, args.fixture, args.source_archive, args.sanitizer,
             graph, oracle, batches, Path(__file__)]
    paths += [ROOT / 'scripts/multigpu' / name for name in
              ('run_l3_upgrade_stage2.py', 'run_l3_batch_capture_replay.py', 'run_l3_30h.py')]
    hashes = {str(path.resolve()): sha256(path) for path in paths}
    write_json(out / 'manifest.json', {'allocation': allocation, 'hashes': hashes,
        'evidence_class': 'exploratory_compact_vs_sweep_not_sssp', 'original_batches': prepared['nonempty_batches']})
    environment = clean_environment()
    results = {}

    def run(name, command, tool=None):
        if tool:
            command = [str(args.sanitizer), '--tool', tool, '--error-exitcode', '9'] + command
        print('RUN', name, flush=True)
        with (out / (name + '.log')).open('w') as log:
            process = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT,
                                     env=environment, cwd=ROOT, timeout=300)
        raw = (out / (name + '.log')).read_text()
        results[name] = {'rc': process.returncode, 'sanitizer': tool, 'timing_usable': tool is None}
        write_json(out / 'status.json', {'stage': name, 'complete': False, 'results': results})
        print('RC', name, process.returncode, flush=True)
        if process.returncode or not sanitizer_passed(raw, tool):
            raise RuntimeError('failed retained stage ' + name)
        apps = subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid', '--format=csv,noheader'], text=True)
        if apps.strip():
            raise RuntimeError('remaining GPU processes; no cleanup attempted')
        return raw

    for name, option, tool, count in [('fixture', [], None, 2176),
                                      ('fixture_memcheck', ['--quick'], 'memcheck', 736),
                                      ('fixture_racecheck', ['--quick'], 'racecheck', 736),
                                      ('fixture_synccheck', ['--quick'], 'synccheck', 736)]:
        raw = run(name, [str(args.fixture)] + option, tool)
        if (f'BATCH_WORKSET_PASS cases={count} protocol_and_oracle_not_integrated_sssp' not in raw or
                'WORKSET_LAYOUT compact_active=1 ' not in raw or
                len(re.findall(r'^COMPACT_REACTIVATION_WRAP .*correct=1$', raw, re.MULTILINE)) != 8):
            raise RuntimeError('incomplete component/queue-wrap evidence')
        results[name]['cases'] = count
    for name, binary, compact, tool in [('sweep0', args.sweep, False, None),
                                        ('compact0', args.compact, True, None),
                                        ('compact1', args.compact, True, None),
                                        ('sweep1', args.sweep, False, None),
                                        ('replay_memcheck', args.compact, True, 'memcheck'),
                                        ('replay_synccheck', args.compact, True, 'synccheck')]:
        raw = run(name, [str(binary), str(graph), str(batches), str(oracle), '--cost-breakdown'], tool)
        summary = summarize_replay(raw, zero_budget=True)
        if summary['compact_active'] != compact or summary['workspace_bytes'] is None:
            raise RuntimeError('wrong replay layout')
        prefix, field = ('REAL_REPLAY_WAVES', 'waves') if compact else ('REAL_REPLAY_SCANS', 'tiles')
        activity = [dict((k, int(v)) for k, v in re.findall(r'(\w+)=(\d+)', line))
                    for line in raw.splitlines() if line.startswith(prefix + ' ')]
        expected = sorted((g['owner'], int(g['quiet_observation']), g['mode'], g['budget'], s['repeat'])
                          for g in summary['groups'] for s in g['samples'])
        actual = sorted((r['owner'], r['quiet'], r['mode'], r['budget'], r['repeat']) for r in activity)
        if actual != expected or any(r[field] for r in activity if r['mode'] == 0 or r['budget'] == 0):
            raise RuntimeError('missing or invalid activity counters')
        results[name].update(summary=summary, activity=activity, activity_unit=field)
    if any(sha256(Path(path)) != digest for path, digest in hashes.items()):
        raise RuntimeError('provenance changed during screen')
    write_json(out / 'summary.json', {'valid': True, 'results': results, 'not_sssp': True,
        'limitation': 'FIFO changes bounded work order; compare work/debt as well as kernel time. No owner destination snapshot or GPU commit.'})
    write_json(out / 'status.json', {'stage': 'complete', 'complete': True, 'job': allocation['job_id']})
    print('COMPACT_SCREEN_PASS not_sssp=1', flush=True)


if __name__ == '__main__':
    main()
