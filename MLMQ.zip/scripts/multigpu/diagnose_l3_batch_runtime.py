#!/usr/bin/env python3
"""Independent diagnostic probes; all failures retained, never perf evidence."""
import argparse
import json
from pathlib import Path

from run_l3_batch_runtime import execute, verify_tree, parse_runtime
from run_l3_upgrade_stage2 import clean_environment, sha256, slurm_preflight, write_json
from run_usa_road_matrix import parse_bench, validate, gpu_snapshot
from run_l3_30h import parse_oracle_contract, parse_dual_contract
from run_l3_compact_screen import sanitizer_passed


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('build', 'harness', 'sanitizer', 'out'):
        parser.add_argument('--' + name, required=True, type=Path)
    args = parser.parse_args()
    build, harness = args.build.resolve(strict=True), args.harness.resolve(strict=True)
    bm, hm = verify_tree(build), verify_tree(harness)
    if Path(__file__).resolve() != harness / 'source/scripts/multigpu/diagnose_l3_batch_runtime.py':
        parser.error('execute frozen harness')
    args.out.mkdir(parents=True, exist_ok=False)
    out = args.out.resolve()
    allocation = slurm_preflight(out)
    write_json(out / 'manifest.json', {'build': bm, 'harness': hm, 'allocation': allocation,
               'sanitizer_sha256': sha256(args.sanitizer), 'performance_evidence': False})
    results = {}
    for label, kind, graph, tool, repeats in (
            ('control_racecheck', 'control', 'ring', 'racecheck', 1),
            ('batch_racecheck', 'batch', 'ring', 'racecheck', 1),
            ('batch_synccheck', 'batch', 'ring', 'synccheck', 1),
            ('branch_batch_stress', 'batch', 'branch', None, 30),
            ('branch_control_stress', 'control', 'branch', None, 30)):
        env = clean_environment()
        env.update(MLMQ_WORK_BLOCKS='4', MLMQ_CUT_PERCENT='50', MLMQ_FINAL_AUDIT='all',
                   BENCH_SOURCE='0', BENCH_WARMUPS='0', BENCH_REPEATS=str(repeats),
                   MLMQ_BATCH_ENABLED='1', MLMQ_BATCH_FORCE='1', MLMQ_BATCH_SLOTS='128',
                   MLMQ_BATCH_BUDGET='64', MLMQ_BATCH_MIN_SEEDS='1', CUDA_MODULE_LOADING='EAGER',
                   L3_SUPPLEMENT_ORACLE=str(harness / 'data' / f'{graph}_s0.oracle'))
        command = [str(build / ('mlmq_' + kind)), '-i', str(harness / 'data' / (graph + '.gr')), '-n', '2', '-d', '400000']
        if tool:
            command = [str(args.sanitizer), '--tool', tool, '--error-exitcode', '9'] + command
        command = ['/usr/bin/stdbuf', '-oL', '-eL'] + command
        record = {'command': command, 'environment': env, 'state': 'running'}
        results[label] = record
        write_json(out / 'status.json', {'complete': False, 'results': results})
        print('RUN', label, flush=True)
        before, apps = gpu_snapshot()
        (out / (label + '.gpu_before.log')).write_text(before)
        if apps:
            raise RuntimeError('existing compute process; no cleanup attempted')
        record['rc'] = execute(command, env, out / (label + '.log'), 180 if tool else 45)
        raw = (out / (label + '.log')).read_text()
        record['samples'] = parse_bench(raw)
        ok, reason = validate(record['samples'], 'MLMQ', 2, 0, 'L1SLF_L2DQ', 0, repeats)
        record['oracle'] = parse_oracle_contract(raw, repeats, 4096)
        record['dual'] = parse_dual_contract(raw, repeats, 4, 400000, 19,
            require_l2_final=True, expected_worker_recovery=1, expected_ack_capacity=1712)
        record['sanitizer_passed'] = sanitizer_passed(raw, tool)
        record['valid'] = (record['rc'] == 0 and ok and record['oracle']['valid'] and
                           record['dual']['valid'] and record['sanitizer_passed'])
        record['bench_reason'] = reason
        if kind == 'batch':
            try:
                record['runtime'] = parse_runtime(raw, repeats, 64, 1, True)
            except ValueError as error:
                record['runtime_error'] = str(error)
                record['valid'] = False
        after, apps = gpu_snapshot()
        (out / (label + '.gpu_after.log')).write_text(after)
        if apps:
            raise RuntimeError('compute process remains; no cleanup attempted')
        record['state'] = 'passed' if record['valid'] else 'failed'
        write_json(out / 'status.json', {'complete': False, 'results': results})
        print(record['state'].upper(), label, 'rc', record['rc'], flush=True)
    verify_tree(build)
    verify_tree(harness)
    valid = all(r['valid'] for r in results.values())
    write_json(out / 'status.json', {'complete': True, 'valid': valid, 'results': results})
    print('DIAGNOSTICS_COMPLETE valid=' + str(valid), flush=True)
    return 0 if valid else 1


if __name__ == '__main__':
    raise SystemExit(main())
