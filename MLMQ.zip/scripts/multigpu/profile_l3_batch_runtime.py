#!/usr/bin/env python3
"""Read CUDA activity from frozen v15; no kernel replay or performance acceptance."""
import argparse
import json
from pathlib import Path
import sqlite3
import subprocess
from run_l3_batch_runtime import verify_tree, execute, parse_runtime, parse_helpers, parse_admission, parse_services, parse_poll, parse_cache, parse_shared
from run_l3_30h import parse_dual_contract, parse_oracle_contract
from run_usa_road_matrix import gpu_snapshot, parse_bench, validate
from run_l3_upgrade_stage2 import clean_environment, slurm_preflight, sha256, write_json


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('build', 'harness', 'contract', 'out', 'nsys'):
        parser.add_argument('--'+name, type=Path, required=True)
    parser.add_argument('--carveout', type=int, choices=range(-1, 101), default=-1)
    parser.add_argument('--service-shared-bytes', type=int)
    args = parser.parse_args()
    build, harness, nsys = (p.resolve(strict=True) for p in (args.build, args.harness, args.nsys))
    bm, hm = verify_tree(build), verify_tree(harness)
    if Path(__file__).resolve() != harness / 'source/scripts/multigpu/profile_l3_batch_runtime.py':
        parser.error('use frozen runner')
    contract = json.loads(args.contract.read_text())
    graph, oracle = Path(contract['graph_path']), Path(contract['oracle_path'])
    if sha256(graph) != contract['graph_sha256'] or sha256(oracle) != contract['oracle_sha256']:
        raise ValueError('input changed')
    args.out.mkdir(parents=True, exist_ok=False)
    out = args.out.resolve()
    manifest = {'build_path': str(build), 'build': bm, 'harness': hm, 'contract': contract,
                'allocation': slurm_preflight(out), 'nsys': str(nsys), 'nsys_sha256': sha256(nsys),
                'nsys_version': subprocess.check_output([str(nsys), '--version'], text=True),
                'scope': 'CUDA API/kernel activity only; no replay; no performance acceptance'}
    write_json(out/'manifest.json', manifest)
    results = {}
    for label, services, poll, admit in (('data', 0, 1, 0), ('helper_sleep', 1, 0, 0),
                                          ('rx_sleep', 2, 0, 0), ('loans', 3, 1, 1)):
        env = clean_environment()
        env.update(MLMQ_WORK_BLOCKS='97', MLMQ_CUT_PERCENT=str(contract['cut_percent']),
                   BENCH_SOURCE=str(contract['source']), BENCH_WARMUPS='1', BENCH_REPEATS='3',
                   CUDA_MODULE_LOADING='EAGER', L3_SUPPLEMENT_ORACLE=str(oracle),
                   MLMQ_BATCH_ENABLED='1', MLMQ_BATCH_FORCE='0', MLMQ_BATCH_SLOTS='128',
                   MLMQ_BATCH_BUDGET='512', MLMQ_BATCH_MIN_SEEDS='1', MLMQ_BATCH_HELPER_BLOCKS='8',
                   MLMQ_BATCH_ADMIT=str(admit), MLMQ_BATCH_PROBE_CALLS=str(admit),
                   MLMQ_BATCH_SERVICES=str(services), MLMQ_BATCH_SERVICE_POLL=str(poll),
                   MLMQ_BATCH_SERVICE_CARVEOUT=str(args.carveout))
        if args.service_shared_bytes is not None:
            env['MLMQ_BATCH_SERVICE_SHARED_BYTES'] = str(args.service_shared_bytes)
        # Same queue selector used by the matched run_one harness.
        env['BENCH_QUEUE'] = 'L1SLF_L2DQ'
        command = [str(nsys), 'profile', '--trace=cuda', '--sample=none', '--cpuctxsw=none',
                   '--export=sqlite', '--force-overwrite=false', '--output', str(out/label),
                   str(build/'mlmq_batch'), '-i', str(graph), '-n', '2', '-d', str(contract['delta'])]
        record = {'state': 'running', 'command': command, 'environment': env}
        results[label] = record
        write_json(out/'status.json', {'complete': False, 'results': results})
        print('RUN', label, flush=True)
        try:
            snapshot, apps = gpu_snapshot(); (out/(label+'.gpu_before.log')).write_text(snapshot)
            if apps:
                raise ValueError('compute process already present')
            record['rc'] = execute(command, env, out/(label+'.log'), 300)
            raw = (out/(label+'.log')).read_text()
            record['samples'] = parse_bench(raw)
            ok, why = validate(record['samples'], 'MLMQ', 2, contract['source'], 'L1SLF_L2DQ', 1, 3)
            if record['rc'] or not ok or 'Error at node' in raw:
                raise ValueError(f'profile rc={record["rc"]}, {why}')
            record['oracle'] = parse_oracle_contract(raw, 4, contract['vertices'])
            record['dual'] = parse_dual_contract(raw, 4, 97, contract['delta'], 19,
                expected_window_mode=2, expected_window_min=25000, expected_window_max=25000,
                expected_idle_backoff=0, require_l2_final=True, expected_worker_recovery=1, expected_ack_capacity=1712)
            if not record['oracle']['valid'] or not record['dual']['valid']:
                raise ValueError('oracle or dual contract failed')
            rt = parse_runtime(raw, 4, 512, 0, False); record['runtime'] = rt
            record['helpers'] = parse_helpers(raw, 4, 8, rt)
            record['admission'] = parse_admission(raw, 4, admit, rt)
            record['services'] = parse_services(raw, 4, services, admit)
            record['poll'] = parse_poll(raw, 4, poll)
            record['cache'] = parse_cache(raw, 4, args.carveout)
            if args.service_shared_bytes is not None:
                record['shared'] = parse_shared(raw, 4, args.service_shared_bytes)
            if admit and not sum(x['loans'] for x in rt):
                raise ValueError('vacuous loan profile')
            database = out/(label+'.sqlite')
            with sqlite3.connect('file:'+str(database)+'?mode=ro', uri=True) as db:
                if db.execute('PRAGMA quick_check').fetchone() != ('ok',):
                    raise ValueError('invalid SQLite export')
                record['kernel_schema'] = db.execute('PRAGMA table_info(CUPTI_ACTIVITY_KIND_KERNEL)').fetchall()
                record['kernel_rows'] = db.execute('SELECT count(*) FROM CUPTI_ACTIVITY_KIND_KERNEL').fetchone()[0]
                if not record['kernel_schema'] or record['kernel_rows'] == 0:
                    raise ValueError('CUDA kernel activity missing')
            files = [database, out/(label+'.nsys-rep')]
            if any(not p.is_file() or not p.stat().st_size for p in files):
                raise ValueError('missing profile artifact')
            record['artifacts'] = {p.name: sha256(p) for p in files}
            snapshot, apps = gpu_snapshot(); (out/(label+'.gpu_after.log')).write_text(snapshot)
            if apps:
                raise ValueError('compute process remains')
            record['state'] = 'passed'
        except Exception as error:
            record.update(state='failed', error=str(error))
            snapshot, _ = gpu_snapshot(); (out/(label+'.gpu_after.log')).write_text(snapshot)
            write_json(out/'status.json', {'complete': False, 'results': results})
            raise
        write_json(out/'status.json', {'complete': False, 'results': results})
        print('PASS', label, flush=True)
    verify_tree(build); verify_tree(harness)
    write_json(out/'summary.json', {'valid': True, 'results': results, 'performance_acceptance': False})
    write_json(out/'status.json', {'complete': True, 'results': results})
    print('BATCH_CUDA_ACTIVITY_CAPTURE_PASS', flush=True)


if __name__ == '__main__':
    main()
