#!/usr/bin/env python3
"""Matched exploratory USA screen; retain every sample and charge setup separately."""
import argparse
import json
from pathlib import Path
import re
from statistics import median

from run_l3_batch_runtime import verify_tree, parse_runtime
from run_l3_upgrade_stage2 import clean_environment, sha256, slurm_preflight, write_json
from run_usa_road_matrix import run_one
from run_l3_30h import parse_dual_contract, parse_oracle_contract


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('build', 'harness', 'contract', 'out'):
        parser.add_argument('--' + name, required=True, type=Path)
    parser.add_argument('--reference-build', type=Path, help='optional frozen predecessor, interleaved in the same allocation')
    args = parser.parse_args()
    build, harness = args.build.resolve(strict=True), args.harness.resolve(strict=True)
    bm, hm = verify_tree(build), verify_tree(harness)
    reference = args.reference_build.resolve(strict=True) if args.reference_build else None
    rm = verify_tree(reference) if reference else None
    if Path(__file__).resolve() != harness / 'source/scripts/multigpu/screen_l3_batch_runtime.py':
        parser.error('use frozen screen runner')
    contract = json.loads(args.contract.read_text())
    graph, oracle = Path(contract['graph_path']), Path(contract['oracle_path'])
    if sha256(graph) != contract['graph_sha256'] or sha256(oracle) != contract['oracle_sha256']:
        raise ValueError('input differs from frozen contract')
    args.out.mkdir(parents=True, exist_ok=False)
    out = args.out.resolve()
    allocation = slurm_preflight(out)
    configs = [('C1_107', 'control', 1, 107, 0), ('C2_107', 'control', 2, 107, 0),
               ('C2_104', 'control', 2, 104, 0), ('T2_off104', 'batch', 2, 104, 0),
               ('T2_b64_104', 'batch', 2, 104, 1)]
    if reference:
        configs += [('R2_off104', 'batch', 2, 104, 0), ('R2_b64_104', 'batch', 2, 104, 1)]
    write_json(out / 'manifest.json', {'build': bm, 'harness': hm, 'input_contract': contract,
        'reference_build': str(reference) if reference else None, 'reference_manifest': rm,
        'allocation': allocation, 'configs': configs, 'rounds': 2, 'warmups': 1, 'repeats': 3,
        'evidence_class': 'dirty_frozen_exploratory_not_formal',
        'limitations': ['single has no local compact closure service',
                       'baseline and candidate production racecheck report shared memory hazards'],
        'acceptance': 'cannot establish formal same-capability scaling; no target completion from this screen'})
    results = {}
    for round_index in range(2):
        for label, kind, n, blocks, enabled in (configs if round_index == 0 else list(reversed(configs))):
            key = f'r{round_index}_{label}'
            env = clean_environment()
            env.update(MLMQ_WORK_BLOCKS=str(blocks), MLMQ_CUT_PERCENT=str(contract['cut_percent']),
                BENCH_SOURCE=str(contract['source']), BENCH_WARMUPS='1', BENCH_REPEATS='3',
                CUDA_MODULE_LOADING='EAGER', L3_SUPPLEMENT_ORACLE=str(oracle),
                MLMQ_BATCH_ENABLED=str(enabled), MLMQ_BATCH_FORCE='0', MLMQ_BATCH_SLOTS='128',
                MLMQ_BATCH_BUDGET='64', MLMQ_BATCH_MIN_SEEDS='1')
            print('RUN', key, flush=True)
            binary_build = reference if label.startswith('R2_') else build
            record = run_one(binary_build / ('mlmq_' + kind), graph, 'MLMQ', n, out / key, env,
                             contract['source'], 'L1SLF_L2DQ', 1, 3, 180, delta=contract['delta'])
            record['environment'] = env
            record['binary_build'] = str(binary_build)
            results[key] = record
            raw = (out / (key + '.log')).read_text()
            try:
                if not record['valid']:
                    raise ValueError(record['reason'])
                record['oracle'] = parse_oracle_contract(raw, 4, contract['vertices'])
                if not record['oracle']['valid']:
                    raise ValueError(record['oracle'])
                if n == 2:
                    record['dual'] = parse_dual_contract(raw, 4, blocks, contract['delta'], 19,
                        expected_window_mode=2, expected_window_min=25000, expected_window_max=25000,
                        expected_idle_backoff=0, require_l2_final=True, expected_worker_recovery=1,
                        expected_ack_capacity=1712)
                    if not record['dual']['valid']:
                        raise ValueError(record['dual']['errors'])
                if enabled:
                    record['runtime'] = parse_runtime(raw, 4, 64, 0, False)
                    record['batch_install_ms'] = list(map(float, re.findall(r'^L3_BATCH_INSTALL slots=128 wall_ms=([0-9.]+)$', raw, re.M)))
                    if len(record['batch_install_ms']) != 1:
                        raise ValueError('missing batch replication/install cost')
                record['setup'] = [dict(re.findall(r'(\w+)=([^ ]+)', line)) for line in raw.splitlines() if line.startswith('BENCH_SETUP ')]
                if len(record['setup']) != 1:
                    raise ValueError('missing setup cost')
            except Exception as error:
                record.update(valid=False, error=str(error))
                write_json(out / 'status.json', {'complete': False, 'results': results})
                raise
            write_json(out / 'status.json', {'complete': False, 'results': results})
            print('PASS', key, flush=True)
    grouped = {}
    for label, *_ in configs:
        records = [results[f'r{i}_{label}'] for i in range(2)]
        samples = [s for r in records for s in r['samples'] if s['warmup'] == '0']
        grouped[label] = {field: {'samples_ms': [float(s[field]) for s in samples],
                                 'median_ms': median(float(s[field]) for s in samples)}
                          for field in ('solve_ms', 'query_wall_ms')}
        grouped[label]['host_process_elapsed_seconds'] = [r['host_elapsed_seconds'] for r in records]
        grouped[label]['initialization_other_ms'] = [float(r['setup'][0]['initialization_other_ms']) for r in records]
        grouped[label]['batch_install_ms'] = [v for r in records for v in r.get('batch_install_ms', [])]
        grouped[label]['loans_including_warmup'] = sum(x['loans'] for r in records for x in r.get('runtime', []))
    ratios = {}
    for field in ('solve_ms', 'query_wall_ms'):
        ratios[field] = {f'{base}/T2_b64_104': grouped[base][field]['median_ms']/grouped['T2_b64_104'][field]['median_ms']
                         for base in ('C1_107', 'C2_107', 'C2_104', 'T2_off104')}
        if reference:
            ratios[field].update({f'R2_{mode}/T2_{mode}': grouped['R2_' + mode][field]['median_ms']/grouped['T2_' + mode][field]['median_ms']
                                  for mode in ('off104', 'b64_104')})
    verify_tree(build)
    verify_tree(harness)
    if reference:
        verify_tree(reference)
    write_json(out / 'summary.json', {'valid': True, 'formal_acceptance': False, 'same_capability_single': False,
        'grouped': grouped, 'ratios': ratios, 'results': results,
        'setup_scope': 'replication/install excluded from solve, retained above; include setup for amortized claims'})
    write_json(out / 'status.json', {'complete': True, 'results': results})
    print(json.dumps(ratios, indent=2), flush=True)


if __name__ == '__main__':
    main()
