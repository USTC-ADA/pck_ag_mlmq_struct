#!/usr/bin/env python3
"""Isolated owner-commit fixture on both allocated A100s; no peer/SSSP timing."""
import argparse
from pathlib import Path
import subprocess

from run_l3_compact_screen import sanitizer_passed
from run_l3_upgrade_stage2 import ROOT, clean_environment, sha256, slurm_preflight, write_json


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('binary', 'sanitizer', 'out', 'snapshot'):
        parser.add_argument('--' + name, required=True, type=Path)
    args = parser.parse_args()
    if args.out.exists() or args.out.is_symlink():
        parser.error('output exists')
    args.out.mkdir(parents=True)
    out = args.out.resolve()
    allocation = slurm_preflight(out)
    binary = args.binary.resolve(strict=True)
    files = [binary, args.snapshot.resolve(strict=True), ROOT / 'SSSP/l3/l3_batch_commit.h']
    files += [ROOT / 'scripts/multigpu' / name for name in (
        'test_l3_batch_commit.cpp', 'test_l3_batch_commit_cuda.cu', 'run_l3_batch_commit.py',
        'run_l3_compact_screen.py', 'run_l3_upgrade_stage2.py', 'run_l3_30h.py', 'run_usa_road_matrix.py')]
    hashes = {str(path): sha256(path) for path in files}
    write_json(out / 'manifest.json', {'allocation': allocation, 'hashes': hashes,
        'evidence_class': 'exploratory_owner_only_fixture_no_peer_no_solver_no_performance'})
    status = {}
    for tool in (None, 'memcheck', 'racecheck', 'synccheck'):
        name = tool or 'normal'
        command = [str(binary)]
        if tool:
            command = [str(args.sanitizer.resolve(strict=True)), '--tool', tool,
                       '--error-exitcode', '9'] + command + ['--quick']
        print('RUN', name, flush=True)
        with (out / (name + '.log')).open('w') as log:
            result = subprocess.run(command, cwd=ROOT, env=clean_environment(),
                                    stdout=log, stderr=subprocess.STDOUT, timeout=360)
        text = (out / (name + '.log')).read_text()
        status[name] = {'rc': result.returncode, 'sanitizer': tool}
        write_json(out / 'status.json', {'complete': False, 'stage': name, 'results': status})
        print('RC', name, result.returncode, flush=True)
        if result.returncode or not sanitizer_passed(text, tool) or 'BATCH_COMMIT_CUDA_PASS ' not in text:
            raise RuntimeError('retained failed stage ' + name)
        for device in (0, 1):
            if f'BATCH_COMMIT_DEVICE_PASS device={device} ' not in text:
                raise RuntimeError('missing allocated device fixture')
        apps = subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid', '--format=csv,noheader'], text=True)
        if apps.strip():
            raise RuntimeError('GPU processes remain; no cleanup attempted')
    if any(sha256(Path(path)) != expected for path, expected in hashes.items()):
        raise RuntimeError('binary/source changed during run')
    write_json(out / 'summary.json', {'valid': True, 'results': status, 'devices_tested': [0, 1],
        'normal_cases': 4096, 'quick_cases_each_sanitizer': 256,
        'peer_relay': False, 'solver_integration': False, 'performance_evidence': False})
    write_json(out / 'status.json', {'complete': True, 'stage': 'complete', 'results': status})
    print('BATCH_COMMIT_PIPELINE_PASS owner_only=1 no_peer_no_solver_no_performance=1', flush=True)


if __name__ == '__main__':
    main()
