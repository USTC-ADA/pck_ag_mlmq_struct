// Bounded workset/certificate oracle, NOT integrated SSSP or a speedup claim.
#include "../../SSSP/l3/l3_batch_workset.cuh"
#include "../../SSSP/l3/l3_batch_compact.cuh"
#ifndef L3_WORKSET_COMPACT
#define L3_WORKSET_COMPACT 0
#endif
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <functional>
#include <queue>
#include <string>
#include <utility>
#include <vector>

namespace relay = l3_batch_relay;
#if L3_WORKSET_COMPACT
namespace workset = l3_batch_compact;
#else
namespace workset = l3_batch_workset;
#endif
static void require(bool condition, const char *message) {
    if (condition) return;
    std::fprintf(stderr, "WORKSET_FAIL %s\n", message);
    std::exit(3);
}
static void check(cudaError_t result, const char *operation) {
    if (result == cudaSuccess) return;
    std::fprintf(stderr, "WORKSET_CUDA_FAIL %s: %s\n", operation, cudaGetErrorString(result));
    std::exit(2);
}
struct host_graph {
    std::vector<int> rows, columns, weights;
    int vertices() const { return int(rows.size()) - 1; }
};
struct device_graph {
    int *rows, *columns, *weights;
    void upload(const host_graph &host) {
        check(cudaMalloc(&rows, host.rows.size() * sizeof(int)), "allocate rows");
        check(cudaMalloc(&columns, host.columns.size() * sizeof(int)), "allocate columns");
        check(cudaMalloc(&weights, host.weights.size() * sizeof(int)), "allocate weights");
        check(cudaMemcpy(rows, host.rows.data(), host.rows.size() * sizeof(int), cudaMemcpyHostToDevice), "upload rows");
        check(cudaMemcpy(columns, host.columns.data(), host.columns.size() * sizeof(int), cudaMemcpyHostToDevice), "upload columns");
        check(cudaMemcpy(weights, host.weights.data(), host.weights.size() * sizeof(int), cudaMemcpyHostToDevice), "upload weights");
    }
    void release() {
        check(cudaFree(rows), "free rows");
        check(cudaFree(columns), "free columns");
        check(cudaFree(weights), "free weights");
    }
};
struct test_case {
    int begin, end, budget, expected_status;
    std::vector<relay::item> seeds;
    bool require_queue_wrap = false;
};
struct device_case { int begin, end, budget; };

__global__ static void execute_cases(relay::slot *channels, int *certificates,
    workset::workspace *workspaces, const device_case *cases,
    device_graph graph, int count, bool direct, bool onchip) {
    extern __shared__ workset::workspace private_work[];
    const int lane = threadIdx.x % 32;
    const int warp = (blockIdx.x * blockDim.x + threadIdx.x) / 32;
    // Competing warps share a workspace ONLY after a successful unique claim.
    const int index = direct ? warp : warp / 2;
    if (index >= count) return;
    auto *slot = channels + index;
    auto token = relay::encode(index + 17, relay::ready);
    int claimed = direct;
    if (!direct && !lane) claimed = relay::move(slot, token, relay::active);
    if (!__shfl_sync(relay::mask, claimed, 0)) return;
    auto *work = onchip ? private_work + threadIdx.x / 32 : workspaces + index;
    const auto config = cases[index];
    relay::graph_view view{graph.rows + config.begin, graph.columns, graph.weights,
                           config.begin, config.end - config.begin};
    if (direct)
        workset::expand_payload(slot, view, work,
            certificates + index * relay::result_capacity, config.budget, lane);
    else
        workset::execute(slot, relay::encode(index + 17, relay::active), view,
            work, certificates + index * relay::result_capacity,
            config.budget, lane);
    // One-shot oracle only: host waits for the entire kernel, no concurrent
    // recycling. Persistent cost kernels do NOT copy scratch after RETURNED.
    if (onchip) {
        for (int cell = lane; cell < workset::table_size; cell += 32) {
            workspaces[index].vertices[cell] = work->vertices[cell];
            workspaces[index].distances[cell] = work->distances[cell];
            workspaces[index].expanded[cell] = work->expanded[cell];
        }
        if (!lane) {
            workspaces[index].count = work->count;
            workspaces[index].rows = work->rows;
            workspaces[index].scans = work->scans;
        }
#if L3_WORKSET_COMPACT
        workspaces[index].queued[lane] = work->queued[lane];
        for (int cell = lane; cell < work->count; cell += 32)
            workspaces[index].touched[cell] = work->touched[cell];
        for (unsigned cell = work->head + lane; cell < work->tail; cell += 32)
            workspaces[index].fifo[cell & (workset::table_size - 1)] = work->fifo[cell & (workset::table_size - 1)];
        if (!lane) { workspaces[index].head = work->head; workspaces[index].tail = work->tail; }
#endif
    }
}

static host_graph make_graph(int type) {
    host_graph graph;
    const int vertices = type == 2 ? 4096 : type == 3 ? 1024 : 512;
    for (int vertex = 0; vertex < vertices; ++vertex) {
        graph.rows.push_back(int(graph.columns.size()));
        const int degree = type == 5 ? 1 : type == 4 ? (vertex == 0 ? 1 : 0) : type == 3 ? 100 : 5;
        for (int edge = 0; edge < degree; ++edge) {
            int next, weight;
            if (type == 5) {
                next = (vertex + 1) % vertices; weight = 0;
            } else if (type == 4) {
                next = 1; weight = 0;
            } else if (type == 2) {
                // Keys 0/1024/2048/3072 collide, with cycles and zero edges.
                next = (vertex + (edge < 3 ? (edge + 1) * 1024 : 1)) % vertices;
                weight = edge % 3;
            } else if (type == 3) {
                next = (vertex + edge * 7 + 1) % vertices;
                weight = 1 + edge % 11;
            } else {
                const int steps[] = {0, 1, 7, 37, 1};
                const int costs[] = {0, 1, 4, 11, 3};
                next = (vertex + steps[edge]) % vertices;
                weight = costs[edge];
            }
            graph.columns.push_back(next);
            graph.weights.push_back(weight);
        }
    }
    graph.rows.push_back(int(graph.columns.size()));
    return graph;
}
static int add_distance(int a, int b) {
    require(a >= 0 && b >= 0, "invalid oracle weight/distance");
    const long long sum = static_cast<long long>(a) + b;
    return sum >= INT_MAX ? INT_MAX : int(sum);
}
using queue_type = std::priority_queue<std::pair<int, int>,
    std::vector<std::pair<int, int>>, std::greater<std::pair<int, int>>>;
static void finish(const host_graph &graph, std::vector<int> &distance, queue_type queue) {
    while (!queue.empty()) {
        const auto top = queue.top(); queue.pop();
        if (top.first != distance[top.second]) continue;
        for (int edge = graph.rows[top.second]; edge < graph.rows[top.second + 1]; ++edge) {
            const int candidate = add_distance(top.first, graph.weights[edge]);
            const int next = graph.columns[edge];
            if (candidate < distance[next]) {
                distance[next] = candidate;
                queue.emplace(candidate, next);
            }
        }
    }
}
static std::vector<int> oracle(const host_graph &graph, const std::vector<relay::item> &seeds) {
    std::vector<int> distance(graph.vertices(), INT_MAX);
    queue_type queue;
    for (auto seed : seeds) {
        require(seed.vertex >= 0 && seed.vertex < graph.vertices(), "oracle seed range");
        if (seed.distance < distance[seed.vertex]) {
            distance[seed.vertex] = seed.distance;
            queue.emplace(seed.distance, seed.vertex);
        }
    }
    finish(graph, distance, queue);
    return distance;
}
static void verify(const host_graph &graph, const test_case &config,
    const relay::slot &result, const int *certificates, const workset::workspace &work,
    int index, bool direct) {
    if (!direct) require(result.control == relay::encode(index + 17, relay::returned), "returned generation");
    require(result.result_status == config.expected_status, "result status");
    require(result.seeds == int(config.seeds.size()), "immutable seed count");
    for (int i = 0; i < result.seeds; ++i)
        require(result.input[i].vertex == config.seeds[i].vertex &&
                result.input[i].distance == config.seeds[i].distance, "immutable input for replay");
    if (result.result_status != relay::ok) {
        require(result.results == 0, "fallback discards all partial outputs");
        return;
    }
    require(result.results >= 1 && result.results <= workset::capacity, "journal capacity");
    require(result.results == work.count, "journal count");
    require(work.rows >= 0 && work.rows <= config.budget, "bounded row count");
#if L3_WORKSET_COMPACT
    require(work.tail - work.head <= unsigned(work.count), "one queued index per touched slot");
    std::vector<bool> queued(workset::table_size, false), touched(workset::table_size, false);
    for (unsigned ticket = work.head; ticket != work.tail; ++ticket) {
        const int cell = work.fifo[ticket & (workset::table_size - 1)];
        require(cell < workset::table_size && !queued[cell], "valid unique pending FIFO index");
        queued[cell] = true;
    }
    for (int i = 0; i < work.count; ++i) {
        const int cell = work.touched[i];
        require(cell < workset::table_size && !touched[cell], "valid unique touched index");
        touched[cell] = true;
        require(result.output[i].vertex == work.vertices[cell] && result.output[i].distance == work.distances[cell] &&
                certificates[i] == work.expanded[cell], "touched journal matches scratch");
    }
    for (int cell = 0; cell < workset::table_size; ++cell) {
        require(queued[cell] == bool(work.queued[cell / 32] & (1u << (cell % 32))), "FIFO and membership bitmap agree");
        require(touched[cell] == (work.vertices[cell] >= 0), "every occupied slot touched exactly once");
        const int vertex = work.vertices[cell];
        if (vertex >= config.begin && vertex < config.end && work.distances[cell] < work.expanded[cell])
            require(queued[cell], "every local improvement retains active responsibility");
    }
    if (config.require_queue_wrap) {
        require(work.tail > workset::table_size, "test really wraps the ring");
        require(work.head == work.tail && work.rows < config.budget, "reactivation ring drains before budget");
        std::printf("COMPACT_REACTIVATION_WRAP enqueued=%u rows=%d correct=1\n", work.tail, work.rows);
    }
#endif
    const auto reference = oracle(graph, config.seeds);
    std::vector<int> labels(graph.vertices(), INT_MAX), cert(graph.vertices(), INT_MAX);
    std::vector<bool> seen(graph.vertices(), false);
    for (int i = 0; i < result.results; ++i) {
        const auto record = result.output[i];
        require(record.vertex >= 0 && record.vertex < graph.vertices(), "journal vertex range");
        require(!seen[record.vertex], "unique journal vertex");
        seen[record.vertex] = true;
        labels[record.vertex] = record.distance;
        cert[record.vertex] = certificates[i];
        require(record.distance >= reference[record.vertex], "no fabricated short path");
        require(record.distance <= certificates[i], "certificate cannot improve label");
        if (record.vertex < config.begin || record.vertex >= config.end)
            require(certificates[i] == INT_MAX, "remote vertex never expanded");
    }
    for (auto seed : config.seeds)
        require(seen[seed.vertex] && labels[seed.vertex] <= seed.distance, "seed responsibility retained");
    for (int vertex = 0; vertex < graph.vertices(); ++vertex) {
        if (cert[vertex] == INT_MAX) continue;
        for (int edge = graph.rows[vertex]; edge < graph.rows[vertex + 1]; ++edge) {
            const int candidate = add_distance(cert[vertex], graph.weights[edge]);
            require(labels[graph.columns[edge]] <= candidate, "certificate requires every edge output");
        }
    }
    // CPU model of two-pass OWNER commit; this is not a GPU termination proof.
    // Mode 1/2 model an owner decrease during helper execution. Mode 3 has all
    // returned labels already installed but NOT expanded: atomicMin wins none.
    for (int mode = 0; mode < 4; ++mode) {
        auto sources = config.seeds;
        std::vector<int> distance(graph.vertices(), INT_MAX);
        queue_type pending;
        for (auto seed : sources) distance[seed.vertex] = std::min(distance[seed.vertex], seed.distance);
        if (mode == 1 || mode == 2) {
            const int vertex = mode == 1 ? config.seeds.front().vertex : (config.end + 13) % graph.vertices();
            sources.push_back({vertex, 0});
            distance[vertex] = 0;
            // A concurrent ordinary update keeps its own queue responsibility.
            if (!seen[vertex]) pending.emplace(0, vertex);
        }
        if (mode == 3) distance = labels;
        // Pass 1: ALL returned candidates become authoritative, including
        // remote destinations, before ANY complete-row certificate is used.
        for (int vertex = 0; vertex < graph.vertices(); ++vertex)
            distance[vertex] = std::min(distance[vertex], labels[vertex]);
        // Pass 2: enqueue debt even if this commit did not win atomicMin.
        for (int vertex = 0; vertex < graph.vertices(); ++vertex)
            if (seen[vertex] && distance[vertex] < cert[vertex])
                pending.emplace(distance[vertex], vertex);
        finish(graph, distance, pending);
        require(distance == oracle(graph, sources), "resume from certificates matches Dijkstra");
    }
}

static std::vector<test_case> make_cases(const host_graph &graph, int type, bool quick) {
    std::vector<test_case> cases;
    const int begin = type == 1 ? 64 : 0;
    const int end = type == 1 ? 320 : graph.vertices();
    const std::vector<int> budgets = quick ? std::vector<int>{0, 64, 2048} :
                                          std::vector<int>{0, 1, 8, 64, 256, 2048};
    const std::vector<int> counts = quick ? std::vector<int>{1, 128} :
                                         std::vector<int>{1, 8, 32, 128, 256, 512};
    for (int count : counts) for (int budget : budgets) {
        test_case config{begin, end, budget, relay::ok, {}};
        for (int i = 0; i < count; ++i)
            config.seeds.push_back({begin + ((i % 43) * 17) % (end - begin), 100 + (i * 71) % 101});
        cases.push_back(config);
    }
    // Saturation and INT_MAX seed, plus all-zero duplicates.
    cases.push_back({begin, end, 2048, relay::ok, {{begin, INT_MAX - 1}, {begin + 1, INT_MAX}}});
    cases.push_back({begin, end, 2048, relay::ok, {{begin, 0}, {begin, 50}, {begin, 0}}});
    // Fill the entire input with DISTINCT vertices when the partition allows.
    for (int budget : {0, 64}) {
        test_case dense{begin, end, budget, relay::ok, {}};
        for (int i = 0; i < relay::seed_capacity; ++i)
            dense.seeds.push_back({begin + i % (end - begin), 100 + i % 13});
        cases.push_back(dense);
    }
    cases.push_back({begin, end, 64, relay::bad_seed, {{-1, 0}}});
    cases.push_back({begin, end, 64, relay::bad_seed, {{end, 0}}});
    cases.push_back({begin, end, -1, relay::bad_seed, {{begin, 0}}});
    cases.push_back({begin, end, 64, relay::bad_seed, {{begin, -1}}});
    cases.push_back({begin, end, 64, relay::bad_seed, {}});
    if (type == 5) {
        test_case wrap{begin, end, 65536, relay::ok, {}, true};
        for (int i = begin; i < end; ++i)
            wrap.seeds.push_back({i, i == end - 1 ? 0 : 1000 + i});
        cases.push_back(wrap);
    }
    return cases;
}
static void run(const host_graph &graph, const std::vector<test_case> &cases,
    int owner, bool direct, bool onchip, const char *name) {
    const int count = int(cases.size());
    const int executor = direct ? owner : 1 - owner;
    std::vector<relay::slot> input(count), output(count);
    std::vector<device_case> configs;
    for (int i = 0; i < count; ++i) {
        input[i].control = relay::encode(i + 17, relay::ready);
        input[i].seeds = int(cases[i].seeds.size());
        std::copy(cases[i].seeds.begin(), cases[i].seeds.end(), input[i].input);
        configs.push_back({cases[i].begin, cases[i].end, cases[i].budget});
    }
    relay::slot *channels;
    int *certificates;
    check(cudaSetDevice(owner), "select owner");
    check(cudaMalloc(&channels, count * sizeof(relay::slot)), "allocate slots");
    check(cudaMalloc(&certificates, count * relay::result_capacity * sizeof(int)), "allocate certificates");
    check(cudaMemcpy(channels, input.data(), count * sizeof(relay::slot), cudaMemcpyHostToDevice), "upload slots");
    check(cudaMemset(certificates, 0x7f, count * relay::result_capacity * sizeof(int)), "poison certificates");
    check(cudaStreamSynchronize(0), "owner preparation before peer launch");
    check(cudaSetDevice(executor), "select executor");
    device_graph device;
    device.upload(graph);
    workset::workspace *workspaces;
    device_case *device_cases;
    check(cudaMalloc(&workspaces, count * sizeof(workset::workspace)), "allocate workspace");
    check(cudaMalloc(&device_cases, count * sizeof(device_case)), "allocate cases");
    check(cudaMemcpy(device_cases, configs.data(), count * sizeof(device_case), cudaMemcpyHostToDevice), "upload cases");
    const int threads = count * 32 * (direct ? 1 : 2);
    const int shared_bytes = 4 * sizeof(workset::workspace);
    check(cudaFuncSetAttribute(execute_cases, cudaFuncAttributeMaxDynamicSharedMemorySize, shared_bytes), "oracle opt-in shared memory");
    execute_cases<<<(threads + 127) / 128, 128, onchip ? shared_bytes : 0>>>(channels, certificates, workspaces, device_cases, device, count, direct, onchip);
    check(cudaGetLastError(), "launch worksets");
    check(cudaDeviceSynchronize(), "finish worksets");
    std::vector<workset::workspace> host_work(count);
    check(cudaMemcpy(host_work.data(), workspaces, count * sizeof(workset::workspace), cudaMemcpyDeviceToHost), "read workspaces");
    device.release();
    check(cudaFree(workspaces), "free workspaces");
    check(cudaFree(device_cases), "free cases");
    check(cudaSetDevice(owner), "select owner readback");
    std::vector<int> host_cert(count * relay::result_capacity);
    check(cudaMemcpy(output.data(), channels, count * sizeof(relay::slot), cudaMemcpyDeviceToHost), "read journals");
    check(cudaMemcpy(host_cert.data(), certificates, host_cert.size() * sizeof(int), cudaMemcpyDeviceToHost), "read certificates");
    long long rows = 0, records = 0;
    for (int i = 0; i < count; ++i) {
        verify(graph, cases[i], output[i], host_cert.data() + i * relay::result_capacity, host_work[i], i, direct);
        rows += host_work[i].rows;
        records += output[i].results;
    }
    check(cudaFree(channels), "free channels");
    check(cudaFree(certificates), "free certificates");
    std::printf("WORKSET_CASE graph=%s owner=%d mode=%s storage=%s cases=%d rows=%lld records=%lld correct=1\n",
        name, owner, direct ? "local_direct" : "peer_replica", onchip ? "shared" : "global", count, rows, records);
}

// Identical bounded local work vs migration, with a real concurrent GPU
// consumer of labels AND certificates. Synthetic, cache-hot cost screen only.
constexpr int cost_slots = 32;
__device__ static relay::word warp_token(relay::slot *slot, int lane) {
    relay::word token = lane ? 0 : relay::load(slot);
    return __shfl_sync(relay::mask, token, 0);
}
__global__ static void cost_owner(relay::slot *channels, int *certificates,
    workset::workspace *workspaces, relay::graph_view graph,
    int rounds, int budget, bool direct, bool onchip, unsigned long long *sums, int *error) {
    extern __shared__ workset::workspace private_work[];
    const int lane = threadIdx.x % 32;
    const int index = (blockIdx.x * blockDim.x + threadIdx.x) / 32;
    if (index >= cost_slots) return;
    auto *slot = channels + index;
    auto *work = onchip ? private_work + threadIdx.x / 32 : workspaces + index;
    unsigned long long sum = 0;
    for (int round = 0; round < rounds; ++round) {
        if (lane < 16)
            slot->input[lane] = {(index * 13 + round * 7 + lane * 17) % graph.vertices,
                                 100 + ((lane + round) * 31) % 101};
        if (!lane) slot->seeds = 16;
        __syncwarp(relay::mask);
        if (direct) {
            workset::expand_payload(slot, graph, work,
                certificates + index * relay::result_capacity, budget, lane);
        } else {
            relay::publish_exclusive(slot, relay::encode(round, relay::ready), lane);
            const auto started = clock64();
            while (warp_token(slot, lane) != relay::encode(round, relay::returned)) {
                int expired = lane ? 0 : clock64() - started > 10000000000ull;
                if (__shfl_sync(relay::mask, expired, 0)) {
                    if (!lane) atomicCAS(error, 0, 1);
                    return;
                }
                __nanosleep(64);
            }
            // Each payload-reading lane acquires the published generation.
            assert(relay::load(slot) == relay::encode(round, relay::returned));
        }
        if (!lane && slot->result_status != relay::ok) atomicCAS(error, 0, 2);
        for (int position = lane; position < slot->results; position += 32) {
            const auto item = slot->output[position];
            const unsigned long long certificate = unsigned(certificates[index * relay::result_capacity + position]);
            sum += (static_cast<unsigned long long>(unsigned(item.vertex)) << 32) ^
                   (unsigned(item.distance) * 2654435761ull) ^ (certificate * 40503ull);
        }
        // Real owner commit/queue publication is NOT modeled by this checksum.
        __syncwarp(relay::mask);
    }
    if (!direct) relay::publish_exclusive(slot, relay::encode(rounds, relay::free), lane);
    for (int offset = 16; offset; offset >>= 1) sum += __shfl_down_sync(relay::mask, sum, offset);
    if (!lane) sums[index] = sum;
}
__global__ static void cost_helper(relay::slot *channels, int *certificates,
    workset::workspace *workspaces, relay::graph_view graph, int budget, bool onchip, int *stop) {
    extern __shared__ workset::workspace private_work[];
    const int lane = threadIdx.x % 32;
    const int index = ((blockIdx.x * blockDim.x + threadIdx.x) / 32) % cost_slots;
    auto *slot = channels + index;
    auto *work = onchip ? private_work + threadIdx.x / 32 : workspaces + index;
    while (true) {
        int done = lane ? 0 : cuda::atomic_ref<int, cuda::thread_scope_system>(*stop)
                                 .load(cuda::memory_order_acquire);
        if (__shfl_sync(relay::mask, done, 0)) return;
        const auto token = warp_token(slot, lane);
        int claimed = 0;
        if (!lane && relay::state(token) == relay::ready)
            claimed = relay::move(slot, token, relay::active);
        if (__shfl_sync(relay::mask, claimed, 0))
            workset::execute(slot, relay::encode(relay::generation(token), relay::active), graph,
                work, certificates + index * relay::result_capacity, budget, lane);
        else __nanosleep(64);
    }
}
__global__ static void cost_stop(int *stop) {
    cuda::atomic_ref<int, cuda::thread_scope_system>(*stop).store(1, cuda::memory_order_release);
}
static void cost_screen(bool quick) {
    const auto graph = make_graph(0);
    device_graph device[2];
    workset::workspace *workspaces[2];
    cudaStream_t streams[2];
    for (int gpu = 0; gpu < 2; ++gpu) {
        check(cudaSetDevice(gpu), "cost select device");
        device[gpu].upload(graph);
        check(cudaMalloc(&workspaces[gpu], cost_slots * sizeof(workset::workspace)), "cost workspace");
        check(cudaStreamCreateWithFlags(&streams[gpu], cudaStreamNonBlocking), "cost stream");
        // Avoid lazy loading a module while a persistent kernel is resident.
        cudaFuncAttributes attributes;
        check(cudaFuncGetAttributes(&attributes, cost_owner), "preload cost owner");
        check(cudaFuncGetAttributes(&attributes, cost_helper), "preload cost helper");
        check(cudaFuncGetAttributes(&attributes, cost_stop), "preload cost stop");
        check(cudaFuncSetAttribute(cost_owner, cudaFuncAttributeMaxDynamicSharedMemorySize,
            4 * sizeof(workset::workspace)), "cost owner opt-in shared memory");
        check(cudaFuncSetAttribute(cost_helper, cudaFuncAttributeMaxDynamicSharedMemorySize,
            4 * sizeof(workset::workspace)), "cost helper opt-in shared memory");
    }
    int *stop;
    check(cudaMalloc(&stop, sizeof(int)), "cost stop flag on helper");
    check(cudaSetDevice(0), "cost select owner");
    relay::slot *channels;
    int *certificates, *error;
    unsigned long long *sums;
    check(cudaMalloc(&channels, cost_slots * sizeof(relay::slot)), "cost slots");
    check(cudaMalloc(&certificates, cost_slots * relay::result_capacity * sizeof(int)), "cost certificates");
    check(cudaMalloc(&error, sizeof(int)), "cost errors");
    check(cudaMalloc(&sums, cost_slots * sizeof(unsigned long long)), "cost checksums");
    cudaEvent_t start, end;
    check(cudaEventCreate(&start), "cost start event");
    check(cudaEventCreate(&end), "cost end event");
    const int rounds = quick ? 3 : 64;
    for (int budget : {8, 64, 256, 2048}) {
        std::vector<unsigned long long> reference;
        const int repeats = quick ? 1 : 3;
        for (int repeat = quick ? 0 : -1; repeat < repeats; ++repeat) for (int mode : {0, 1, 2, 3, 3, 2, 1, 0}) {
            const bool direct = mode % 2 == 0;
            const bool onchip = mode >= 2;
            const int shared_bytes = onchip ? 4 * sizeof(workset::workspace) : 0;
            check(cudaSetDevice(0), "cost reset owner");
            check(cudaMemset(channels, 0, cost_slots * sizeof(relay::slot)), "cost reset channels");
            check(cudaMemset(error, 0, sizeof(int)), "cost reset error");
            if (!direct) {
                check(cudaSetDevice(1), "cost start helper");
                check(cudaMemset(stop, 0, sizeof(int)), "cost reset stop");
                relay::graph_view view{device[1].rows, device[1].columns, device[1].weights, 0, graph.vertices()};
                cost_helper<<<16, 128, shared_bytes, streams[1]>>>(channels, certificates, workspaces[1], view, budget, onchip, stop);
                check(cudaGetLastError(), "cost helper launch");
            }
            check(cudaSetDevice(0), "cost start owner");
            check(cudaEventRecord(start, streams[0]), "cost start timing");
            relay::graph_view view{device[0].rows, device[0].columns, device[0].weights, 0, graph.vertices()};
            cost_owner<<<8, 128, direct ? shared_bytes : 0, streams[0]>>>(channels, certificates, workspaces[0], view,
                rounds, budget, direct, onchip, sums, error);
            check(cudaGetLastError(), "cost owner launch");
            check(cudaEventRecord(end, streams[0]), "cost end timing");
            check(cudaEventSynchronize(end), "cost finish owner");
            float ms = 0;
            check(cudaEventElapsedTime(&ms, start, end), "cost time");
            int host_error = 0;
            std::vector<unsigned long long> result(cost_slots);
            check(cudaMemcpy(&host_error, error, sizeof(int), cudaMemcpyDeviceToHost), "cost read error");
            check(cudaMemcpy(result.data(), sums, cost_slots * sizeof(unsigned long long), cudaMemcpyDeviceToHost), "cost read checksum");
            if (!direct) {
                check(cudaSetDevice(1), "cost stop helper");
                cost_stop<<<1, 1>>>(stop);
                check(cudaGetLastError(), "cost stop launch");
                check(cudaDeviceSynchronize(), "cost finish helper");
            }
            require(host_error == 0, "cost owner timeout or invalid output");
            if (reference.empty()) reference = result;
            require(result == reference, "cost local/peer every-round journal and certificate checksum");
            if (repeat >= 0)
                std::printf("WORKSET_COST mode=%s storage=%s budget=%d seeds=16 rounds=%d slots=%d repeat=%d ms=%.6f correct=1\n",
                    direct ? "local_direct" : "peer_replica", onchip ? "shared" : "global", budget, rounds, cost_slots, repeat, ms);
        }
    }
    check(cudaSetDevice(1), "cost free stop select");
    check(cudaFree(stop), "cost free stop");
    check(cudaSetDevice(0), "cost free owner select");
    check(cudaFree(channels), "cost free slots");
    check(cudaFree(certificates), "cost free certificates");
    check(cudaFree(error), "cost free error");
    check(cudaFree(sums), "cost free checksum");
    check(cudaEventDestroy(start), "cost free start");
    check(cudaEventDestroy(end), "cost free end");
    for (int gpu = 0; gpu < 2; ++gpu) {
        check(cudaSetDevice(gpu), "cost release select");
        device[gpu].release();
        check(cudaFree(workspaces[gpu]), "cost free workspace");
        check(cudaStreamDestroy(streams[gpu]), "cost free stream");
    }
    std::puts("BATCH_WORKSET_COST_PASS identical_payload_not_sssp_speedup");
}

int main(int argc, char **argv) {
    const bool quick = argc == 2 && std::strcmp(argv[1], "--quick") == 0;
    const bool cost = argc == 2 && std::strcmp(argv[1], "--cost") == 0;
    const bool cost_quick = argc == 2 && std::strcmp(argv[1], "--cost-quick") == 0;
    require(argc == 1 || quick || cost || cost_quick, "usage: test_l3_batch_workset_cuda [--quick|--cost|--cost-quick]");
    // FIFO's parallel insertion order may change bounded output. The old
    // persistent checksum screen assumes deterministic journals, so it is NOT
    // an admissible compact-workset oracle. Use independent per-case checks.
    require(!L3_WORKSET_COMPACT || (!cost && !cost_quick), "compact persistent cost screen not implemented");
    std::printf("WORKSET_LAYOUT compact_active=%d workspace_bytes=%zu\n", L3_WORKSET_COMPACT, sizeof(workset::workspace));
    require(std::getenv("SLURM_JOB_ID"), "Slurm allocation required");
    int devices = 0;
    check(cudaGetDeviceCount(&devices), "device count");
    require(devices == 2, "exactly two allocated GPUs required");
    for (int gpu = 0; gpu < 2; ++gpu) {
        check(cudaSetDevice(gpu), "select GPU");
        int access = 0, atomics = 0;
        check(cudaDeviceCanAccessPeer(&access, gpu, 1 - gpu), "P2P capability");
        check(cudaDeviceGetP2PAttribute(&atomics, cudaDevP2PAttrNativeAtomicSupported, gpu, 1 - gpu), "P2P atomics");
        require(access && atomics, "P2P reads/writes and native atomics required");
        check(cudaDeviceEnablePeerAccess(1 - gpu, 0), "enable peer");
    }
    if (cost || cost_quick) { cost_screen(cost_quick); return 0; }
    int total = 0;
    const char *names[] = {"cyclic", "partition", "hash_collisions", "capacity", "deadends", "reactivation_ring"};
    for (int type = 0; type < 6; ++type) {
        const auto graph = make_graph(type);
        const auto cases = make_cases(graph, type, quick);
        for (int owner = 0; owner < 2; ++owner) for (bool direct : {true, false}) for (bool onchip : {false, true}) {
            run(graph, cases, owner, direct, onchip, names[type]);
            total += int(cases.size());
        }
    }
    auto negative = make_graph(0);
    negative.weights[negative.rows[0] + 1] = -1;
    std::vector<test_case> negative_cases{{0, negative.vertices(), 64, relay::bad_weight, {{0, 0}}}};
    for (int owner = 0; owner < 2; ++owner) for (bool direct : {true, false}) for (bool onchip : {false, true}) {
        run(negative, negative_cases, owner, direct, onchip, "negative_weight");
        ++total;
    }
    std::printf("BATCH_WORKSET_PASS cases=%d protocol_and_oracle_not_integrated_sssp\n", total);
}
