#!/usr/bin/env python3
"""CPU-only reconstruction of graphs, queue counters and all remote receipts."""
import argparse
from collections import Counter
import json
from pathlib import Path

from audit_l3_batch_peer_commit import INF, dijkstra, fields, require, sha256
from run_l3_batch_remote_commit import parse_cases, verify_build
from run_l3_compact_screen import sanitizer_passed

FIRST_GENERATION = (1 << 40) + 1


def verify_receipts(journals, receipts, split):
    expected = {}
    for loan, journal in journals.items():
        records = journal['records']
        for start in range(0, len(records), 32):
            end = min(start + 32, len(records))
            payload = [(v, d) for v, d, _ in records[start:end] if v >= split]
            if payload:
                expected[loan, start, end] = payload
    require(set(receipts) == {(epoch, role) for epoch in range(1, len(expected) + 1) for role in (0, 1)},
            'missing/duplicate receipt identities')
    seen = set()
    for epoch in range(1, len(expected) + 1):
        sent, received = receipts[epoch, 0], receipts[epoch, 1]
        key = sent['loan'], sent['start'], sent['end']
        require(key in expected and key not in seen, 'duplicate/unknown journal window')
        seen.add(key)
        require(all(sent[k] == received[k] for k in ('epoch', 'generation', 'start', 'end', 'count')),
                'sender/receiver identity mismatch')
        require(sent['generation'] == FIRST_GENERATION + sent['loan'] // 3 and
                sent['acked'] == received['acked'] == 1 and received['loan'] == -1, 'bad generation/ACK')
        require(sent['payload'] == received['payload'] == expected[key] and
                len(sent['payload']) == sent['count'], 'receipt payload mismatch')
    require(seen == set(expected), 'missing journal windows')
    return len(expected), sum(len(payload) for payload in expected.values())


def audit_case(audit_path, journal_path, case):
    sides, graph, vertices, receipts, slots, helpers = {}, {}, {}, {}, {}, {}
    current = receipt = None
    for line in audit_path.read_text().splitlines():
        parts = line.split()
        if parts[0] == 'SIDE':
            require(parts[1] not in sides, 'duplicate side')
            current = fields(' '.join(parts[2:]), ['begin', 'vertices'])
            current.update(ids=[], buckets={})
            sides[parts[1]] = current
        elif parts[0] == 'VERTEX':
            row = fields(line, ['VERTEX', 'initial', 'distance', 'oracle', 'expected', 'seen'])
            v = row['VERTEX']; require(v not in vertices and current is not None, 'duplicate/outside vertex')
            require(all(0 <= row[k] <= INF for k in ('initial', 'distance', 'oracle')), 'bad distance')
            require(row['expected'] == row['seen'] >= 0, 'multiplicity mismatch')
            vertices[v] = row; graph[v] = []; current['ids'].append(v)
        elif parts[0] == 'EDGE':
            source, target, weight = map(int, parts[1:])
            require(source in graph and 0 <= weight <= INF, 'bad edge')
            graph[source].append((target, weight))
        elif parts[0] == 'BUCKET':
            row = fields(line, ['BUCKET', 'reserved', 'consumed', 'published'])
            require(row['BUCKET'] not in current['buckets'], 'duplicate queue bucket')
            current['buckets'][row['BUCKET']] = row
        elif parts[0] == 'QUEUE':
            require('queue' not in current, 'duplicate queue totals')
            current['queue'] = fields(' '.join(parts[1:]), ['done', 'written', 'overflow', 'bootstrapped', 'retired', 'stop'])
        elif parts[0] == 'TRANSPORT':
            transport = fields(' '.join(parts[1:]), ['sent', 'acked', 'full_stops', 'delay_checks', 'competitions'])
        elif parts[0] == 'SLOT':
            row = fields(line, ['SLOT', 'state', 'generation', 'epoch', 'ack'])
            require(row['SLOT'] not in slots, 'duplicate slot')
            slots[row['SLOT']] = row
        elif parts[0] == 'DONOR':
            donor = fields(' '.join(parts[1:]), ['credits', 'outstanding', 'released'])
        elif parts[0] == 'HELPER_SLOT':
            row = fields(line, ['HELPER_SLOT', 'control'])
            require(row['HELPER_SLOT'] not in helpers, 'duplicate helper slot')
            helpers[row['HELPER_SLOT']] = row['control']
        elif parts[0] == 'RECEIPT':
            receipt = fields(line, ['RECEIPT', 'epoch', 'generation', 'start', 'end', 'count', 'loan', 'acked'])
            key = receipt['epoch'], receipt['RECEIPT']
            require(key not in receipts, 'duplicate receipt')
            receipts[key] = receipt; receipt['payload'] = []
        elif parts[0] == 'PAYLOAD':
            require(receipt is not None and len(parts) == 3, 'orphan payload')
            receipt['payload'].append(tuple(map(int, parts[1:])))
        else:
            raise ValueError('unknown audit row')
    require(set(sides) == {'owner', 'remote'}, 'missing partition')
    begin, split = sides['owner']['begin'], sides['remote']['begin']
    require(begin == case['begin'] and split == begin + sides['owner']['vertices'], 'wrong partition begin')
    for label, side in sides.items():
        require(side['ids'] == list(range(side['begin'], side['begin'] + side['vertices'])), 'missing/outside vertices')
        require(set(side['buckets']) == set(range(4)), 'missing queue buckets')
        total = 0
        for row in side['buckets'].values():
            require(row['reserved'] == row['published'] == row['consumed'] >= 0, 'per-bucket conservation failed')
            total += row['reserved']
        q = side['queue']
        require(q['overflow'] == 0 and q['bootstrapped'] == q['retired'] == 8 and q['stop'] == 1,
                'queue overflow/ancestor/stop failure')
        require(total == q['done'] == q['written'] == 8 + sum(vertices[v]['seen'] for v in side['ids']) ==
                case['source_writes' if label == 'owner' else 'remote_writes'], 'queue total mismatch')
    require(all(t in graph for row in graph.values() for t, _ in row), 'edge outside partitions')
    oracle = dijkstra(graph, [(begin, 0)])
    for v, row in vertices.items():
        require(row['distance'] == row['oracle'] == oracle.get(v, INF), 'independent Dijkstra mismatch')
        require(row['initial'] >= oracle.get(v, INF), 'invalid initial label')
    journals = {}; journal = None
    for line in journal_path.read_text().splitlines():
        if line.startswith('LOAN '):
            journal = fields(line, ['LOAN', 'root', 'distance', 'count', 'claims'])
            require(journal['LOAN'] not in journals, 'duplicate loan')
            journals[journal['LOAN']] = journal; journal['records'] = []
        else:
            parts = line.split()
            require(journal is not None and len(parts) == 4 and parts[0] == 'RECORD', 'bad journal row')
            journal['records'].append(tuple(map(int, parts[1:])))
    require(set(journals) == set(range(case['loans'])), 'missing loan')
    # Expand only the donor's rows, exactly the helper's domain; remote rows
    # are not authorized by helper certificates.
    helper_graph = {v: row if v < split else [] for v, row in graph.items()}
    for loan, j in journals.items():
        require(j['root'] == begin + 1 + loan * (case['leaves'] + 1) and j['claims'] == 1 and
                j['distance'] == vertices[j['root']]['initial'] and 0 < j['count'] == len(j['records']) <= 768,
                'wrong root/claim/count')
        reachable = dijkstra(helper_graph, [(j['root'], j['distance'])]); labels = {}
        for v, d, certificate in j['records']:
            require(v in graph and v not in labels and 0 <= d < INF and d <= certificate <= INF and
                    reachable.get(v, INF) <= d, 'invalid helper journal label')
            require(v < split or certificate == INF, 'remote certificate is forbidden')
            labels[v] = d
        require(labels.get(j['root'], INF) <= j['distance'], 'lost root seed')
        for v, _, certificate in j['records']:
            if certificate < INF:
                require(all(labels.get(t, INF) <= min(INF, certificate + w) for t, w in graph[v]),
                        'incomplete helper row certificate')
    packets, records = verify_receipts(journals, receipts, split)
    require(packets == transport['sent'] == transport['acked'] == transport['delay_checks'] == case['packets'], 'packet/ACK totals')
    require(records == case['remote_records'] and transport['full_stops'] == case['rounds'] and
            transport['competitions'] == case['competitions'], 'coverage counts')
    require(set(slots) == {0, 1} and all(r['state'] == 4 and r['generation'] == r['epoch'] == r['ack'] > 0 for r in slots.values()), 'live transport at exit')
    require(donor == {'credits': 8, 'outstanding': 0, 'released': 1}, 'loan leak/early retirement')
    require(helpers == {l: (FIRST_GENERATION + case['rounds']) << 3 for l in range(3)}, 'helper generation/recycle mismatch')
    return dict(loans=len(journals), packets=packets, remote_records=records,
                source_writes=case['source_writes'], remote_writes=case['remote_writes'])


def audit_run(run):
    manifest = json.loads((run / 'manifest.json').read_text())
    build = Path(manifest['build']).resolve(strict=True)
    require(verify_build(build) == manifest['snapshot'] and sha256(build / 'manifest.json') == manifest['build_manifest_sha256'], 'build provenance mismatch')
    summary = json.loads((run / 'summary.json').read_text()); status = json.loads((run / 'status.json').read_text())
    require(summary['valid'] is True and status['complete'] is True and summary['results'] == status['results'], 'incomplete run')
    require(set(status['results']) == {'smoke', 'normal', 'memcheck', 'racecheck', 'synccheck'}, 'wrong stage set')
    totals = {}
    for stage, result in status['results'].items():
        raw = (run / (stage + '.log')).read_text()
        tool = stage if stage in ('memcheck', 'racecheck', 'synccheck') else None
        require(result['rc'] == 0 and result['state'] == 'passed' and sanitizer_passed(raw, tool), 'failed stage')
        cases = parse_cases(raw, stage != 'normal'); require(cases == result['cases'], 'changed case summaries')
        directory = run / (stage + '_journals'); expected_files = set(); rows = []
        for case in cases:
            stem = f"owner{case['owner']}_begin{case['begin']}_fan{case['fan']}_leaves{case['leaves']}"
            names = [stem + suffix for suffix in ('.audit.txt', '.journal.txt')]; expected_files.update(names)
            for name in names: require(sha256(directory / name) == result['raw_artifacts'][name], 'changed raw artifact')
            rows.append(audit_case(directory / names[0], directory / names[1], case))
        require(expected_files == set(result['raw_artifacts']) == {p.name for p in directory.iterdir()}, 'wrong artifact set')
        totals[stage] = {'cases': len(cases), **{k: sum(r[k] for r in rows) for k in rows[0]}}
    return {'valid': True, 'run': str(run), 'job_id': manifest['allocation']['job_id'], 'stages': totals,
            'build_manifest_sha256': manifest['build_manifest_sha256'],
            'auditor_sha256': sha256(Path(__file__)), 'auditor_dependency_sha256': sha256(Path(__file__).with_name('audit_l3_batch_peer_commit.py')),
            'run_hashes': {str(p.relative_to(run)): sha256(p) for p in sorted(run.rglob('*')) if p.is_file()},
            'gpu_rerun': False, 'solver_integration': False, 'performance_evidence': False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', required=True, type=Path); parser.add_argument('--out', required=True, type=Path)
    args = parser.parse_args(); run = args.run.resolve(strict=True); output = args.out.resolve()
    require(not output.exists() and not args.out.is_symlink() and run not in output.parents, 'output must be new and outside original run')
    report = audit_run(run); output.parent.mkdir(parents=True, exist_ok=True)
    with output.open('x') as stream: json.dump(report, stream, indent=2, sort_keys=True); stream.write('\n')
    print('REMOTE_COMMIT_OFFLINE_AUDIT_PASS', json.dumps(report['stages'], sort_keys=True))


if __name__ == '__main__':
    main()
