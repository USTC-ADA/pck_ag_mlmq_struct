#!/usr/bin/env python3
"""Offline reconstruction of real SLF exports, L2 credits and remote receipts."""
import argparse
import json
from pathlib import Path
from audit_l3_batch_peer_commit import INF, dijkstra, fields, require, sha256
from run_l3_batch_l1_donor import parse_cases, verify_build
from run_l3_compact_screen import sanitizer_passed
FIRST_GENERATION = (1 << 40) + 1


def verify_l1_snapshot(j, case, round_index):
    n = case['seeds']; unique = (n+1)//2 if case['duplicate'] else n
    head = (8*case['prime']+(8+n)*round_index+8)%64
    root = case['begin']+9+round_index*(8+2*unique)
    require(j['seeds'] == n and j['head'] == head and
            j['tail'] == j['head_after'] == (head+n)%64, 'incorrect L1 ring removal')
    require(j['parents'] == j['credit_before'] == j['credit_held'] == j['retired'] == 8,
            'ancestor credit replaced by seed count or prematurely released')
    require(j['credit_after'] == j['outstanding_after'] == j['empty_after'] == 0 and
            j['released_after'] == j['claims'] == 1 and j['rejected'] == 5,
            'removal/reserve/recycle/retirement failure')
    expected = [(root+8+i%unique,5+(i%unique)%3,root+9+i%unique,20) for i in range(n)]
    require(j['roots'] == expected, 'seed snapshot differs from authoritative distance or actual queued IDs')
    return unique


def verify_receipts(journals, receipts, split):
    expected = {}
    for loan,j in journals.items():
        for start in range(0,len(j['records']),32):
            end = min(start+32,len(j['records']))
            values = [(v,d) for v,d,_ in j['records'][start:end] if v >= split]
            if values: expected[loan,start,end] = values
    require(set(receipts) == {(e,r) for e in range(1,len(expected)+1) for r in (0,1)}, 'receipt identities')
    seen = set()
    for epoch in range(1,len(expected)+1):
        sent,rx = receipts[epoch,0],receipts[epoch,1]
        key = sent['loan'],sent['start'],sent['end']
        require(key in expected and key not in seen, 'missing/duplicate journal windows'); seen.add(key)
        require(all(sent[k] == rx[k] for k in ('epoch','generation','start','end','count')), 'receipt identity mismatch')
        require(sent['generation'] == FIRST_GENERATION+sent['loan'] and
                sent['acked'] == rx['acked'] == 1 and rx['loan'] == -1, 'bad generation/ACK')
        require(sent['payload'] == rx['payload'] == expected[key] and len(sent['payload']) == sent['count'], 'forged/lost payload')
    require(seen == set(expected), 'missing windows')
    return len(expected),sum(map(len,expected.values()))


def audit_case(audit_path,journal_path,case):
    sides, graph, vertices, receipts, slots, helpers = {}, {}, {}, {}, {}, {}
    current = receipt = None
    for line in audit_path.read_text().splitlines():
        parts = line.split()
        if parts[0] == 'SIDE':
            require(parts[1] not in sides, 'duplicate side')
            current = fields(' '.join(parts[2:]), ['begin', 'vertices'])
            current.update(ids=[], buckets={})
            sides[parts[1]] = current
        elif parts[0] == 'VERTEX':
            row = fields(line, ['VERTEX', 'initial', 'distance', 'oracle', 'expected', 'seen'])
            v = row['VERTEX']; require(v not in vertices and current is not None, 'duplicate/outside vertex')
            require(all(0 <= row[k] <= INF for k in ('initial', 'distance', 'oracle')), 'bad distance')
            require(row['expected'] == row['seen'] >= 0, 'multiplicity mismatch')
            vertices[v] = row; graph[v] = []; current['ids'].append(v)
        elif parts[0] == 'EDGE':
            source, target, weight = map(int, parts[1:])
            require(source in graph and 0 <= weight <= INF, 'bad edge')
            graph[source].append((target, weight))
        elif parts[0] == 'BUCKET':
            row = fields(line, ['BUCKET', 'reserved', 'consumed', 'published'])
            require(row['BUCKET'] not in current['buckets'], 'duplicate queue bucket')
            current['buckets'][row['BUCKET']] = row
        elif parts[0] == 'QUEUE':
            require('queue' not in current, 'duplicate queue totals')
            current['queue'] = fields(' '.join(parts[1:]), ['done', 'written', 'overflow', 'bootstrapped', 'retired', 'stop'])
        elif parts[0] == 'TRANSPORT':
            transport = fields(' '.join(parts[1:]), ['sent', 'acked', 'delay_checks'])
        elif parts[0] == 'SLOT':
            row = fields(line, ['SLOT', 'state', 'generation', 'ack'])
            require(row['SLOT'] not in slots, 'duplicate slot')
            slots[row['SLOT']] = row
        elif parts[0] == 'HELPER_CONTROL':
            helpers['control'] = int(parts[1])
        elif parts[0] == 'RECEIPT':
            receipt = fields(line, ['RECEIPT', 'epoch', 'generation', 'start', 'end', 'count', 'loan', 'acked'])
            key = receipt['epoch'], receipt['RECEIPT']
            require(key not in receipts, 'duplicate receipt')
            receipts[key] = receipt; receipt['payload'] = []
        elif parts[0] == 'PAYLOAD':
            require(receipt is not None and len(parts) == 3, 'orphan payload')
            receipt['payload'].append(tuple(map(int, parts[1:])))
        else:
            raise ValueError('unknown audit row')
    require(set(sides) == {'owner', 'remote'}, 'missing partition')
    begin, split = sides['owner']['begin'], sides['remote']['begin']
    require(begin == case['begin'] and split == begin + sides['owner']['vertices'], 'wrong partition begin')
    for label, side in sides.items():
        require(side['ids'] == list(range(side['begin'], side['begin'] + side['vertices'])), 'missing/outside vertices')
        require(set(side['buckets']) == set(range(4)), 'missing queue buckets')
        total = 0
        for row in side['buckets'].values():
            require(row['reserved'] == row['published'] == row['consumed'] >= 0, 'per-bucket conservation failed')
            total += row['reserved']
        q = side['queue']
        require(q['overflow'] == 0 and q['bootstrapped'] == q['retired'] == (case['ancestors'] if label == 'owner' else 8) and q['stop'] == 1,
                'queue overflow/ancestor/stop failure')
        require(total == q['done'] == q['written'] == q['bootstrapped'] + sum(vertices[v]['seen'] for v in side['ids']) ==
                case['source_writes' if label == 'owner' else 'remote_writes'], 'queue total mismatch')
    require(all(t in graph for row in graph.values() for t, _ in row), 'edge outside partitions')
    oracle = dijkstra(graph, [(begin, 0)])
    for v, row in vertices.items():
        require(row['distance'] == row['oracle'] == oracle.get(v, INF), 'independent Dijkstra mismatch')
        require(row['initial'] >= oracle.get(v, INF), 'invalid initial label')
    journals = {}; journal = None
    names = ['LOAN','count','seeds','head','tail','head_after','parents','credit_before','credit_held','retired',
             'empty_after','credit_after','outstanding_after','released_after','rejected','remote_delays','local_delays','claims']
    for line in journal_path.read_text().splitlines():
        p = line.split()
        if p[0] == 'LOAN':
            journal = fields(line,names); require(journal['LOAN'] not in journals,'duplicate loan')
            journals[journal['LOAN']] = journal; journal['records'] = []; journal['roots'] = []
        elif p[0] == 'SEED':
            require(journal is not None and len(p) == 7 and p[3] == 'id' and p[5] == 'priority','bad seed row')
            journal['roots'].append(tuple(map(int,(p[1],p[2],p[4],p[6]))))
        elif p[0] == 'RECORD':
            require(journal is not None and len(p) == 4,'bad record');journal['records'].append(tuple(map(int,p[1:])))
        else:raise ValueError('unknown journal row')
    require(set(journals) == set(range(case['rounds'])),'missing loans')
    helper_graph = {v:row if v < split else [] for v,row in graph.items()}
    leaves = set(); remote_delays = local_delays = 0
    for r,j in journals.items():
        unique = verify_l1_snapshot(j,case,r)
        root = begin+9+r*(8+2*unique)
        local_leaves = set(range(root+8+unique,root+8+2*unique));leaves.update(local_leaves)
        require(j['count'] == len(j['records']) == 3*unique,'wrong journal count')
        seeds = [(v,d) for v,d,_,_ in j['roots']]
        reachable = dijkstra(helper_graph,seeds);labels = {}
        for v,d,cert in j['records']:
            require(v in graph and v not in labels and 0 <= d < INF and d <= cert <= INF and
                    reachable.get(v,INF) <= d,'invalid journal label')
            require(v < split or cert == INF,'remote certificate');labels[v] = d
        require(all(labels.get(v,INF) <= d for v,d in seeds),'missing original seed')
        for v,d,cert in j['records']:
            if cert < INF:require(all(labels.get(t,INF) <= min(INF,cert+w) for t,w in graph[v]),'incomplete row certificate')
        local_windows = remote_windows = 0
        for start in range(0,j['count'],32):
            chunk = j['records'][start:start+32]
            local_windows += any(v in local_leaves for v,_,_ in chunk)
            remote_windows += any(v >= split for v,_,_ in chunk)
        require(j['local_delays'] == local_windows > 0 and j['remote_delays'] == remote_windows > 0,'missing delayed receipt coverage')
        remote_delays += remote_windows;local_delays += local_windows
    for v in sides['owner']['ids']:
        require(vertices[v]['expected'] == int(v in leaves),'wrong source activation set')
    for v in sides['remote']['ids']:
        require(vertices[v]['expected'] == 1,'wrong remote activation set')
    packets,records = verify_receipts(journals,receipts,split)
    require(packets == case['packets'] == remote_delays == case['remote_delays'] == transport['sent'] == transport['acked'] == transport['delay_checks'],'packet/credit count')
    require(records == case['remote_records'] and local_delays == case['local_delays'],'lost local/remote output')
    require(set(slots) == {0,1} and all(s['state'] == 4 and s['generation'] == s['ack'] > 0 for s in slots.values()),'live slots')
    require(helpers == {'control':(FIRST_GENERATION+case['rounds']) << 3},'unrecycled helper')
    return {k:case[k] for k in ('loans','ancestors','exported','remote_records','packets','remote_delays','local_delays','wrapped','source_writes','remote_writes')}


def audit_run(run):
    manifest = json.loads((run / 'manifest.json').read_text())
    build = Path(manifest['build']).resolve(strict=True)
    require(verify_build(build) == manifest['snapshot'] and sha256(build / 'manifest.json') == manifest['build_manifest_sha256'], 'build provenance mismatch')
    summary = json.loads((run / 'summary.json').read_text()); status = json.loads((run / 'status.json').read_text())
    require(summary['valid'] is True and status['complete'] is True and summary['results'] == status['results'], 'incomplete run')
    require(set(status['results']) == {'smoke', 'normal', 'memcheck', 'racecheck', 'synccheck'}, 'wrong stage set')
    totals = {}
    for stage, result in status['results'].items():
        raw = (run / (stage + '.log')).read_text()
        tool = stage if stage in ('memcheck', 'racecheck', 'synccheck') else None
        require(result['rc'] == 0 and result['state'] == 'passed' and sanitizer_passed(raw, tool), 'failed stage')
        cases = parse_cases(raw, stage != 'normal'); require(cases == result['cases'], 'changed case summaries')
        directory = run / (stage + '_journals'); expected_files = set(); rows = []
        for case in cases:
            stem = f"owner{case['owner']}_begin{case['begin']}_seeds{case['seeds']}_dup{case['duplicate']}_prime{case['prime']}"
            names = [stem + suffix for suffix in ('.audit.txt', '.journal.txt')]; expected_files.update(names)
            for name in names: require(sha256(directory / name) == result['raw_artifacts'][name], 'changed raw artifact')
            rows.append(audit_case(directory / names[0], directory / names[1], case))
        require(expected_files == set(result['raw_artifacts']) == {p.name for p in directory.iterdir()}, 'wrong artifact set')
        totals[stage] = {'cases': len(cases), **{k: sum(r[k] for r in rows) for k in rows[0]}}
    return {'valid': True, 'run': str(run), 'job_id': manifest['allocation']['job_id'], 'stages': totals,
            'build_manifest_sha256': manifest['build_manifest_sha256'],
            'auditor_sha256': sha256(Path(__file__)), 'auditor_dependency_sha256': sha256(Path(__file__).with_name('audit_l3_batch_peer_commit.py')),
            'run_hashes': {str(p.relative_to(run)): sha256(p) for p in sorted(run.rglob('*')) if p.is_file()},
            'gpu_rerun': False, 'solver_integration': False, 'performance_evidence': False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', required=True, type=Path); parser.add_argument('--out', required=True, type=Path)
    args = parser.parse_args(); run = args.run.resolve(strict=True); output = args.out.resolve()
    require(not output.exists() and not args.out.is_symlink() and run not in output.parents, 'output must be new and outside original run')
    report = audit_run(run); output.parent.mkdir(parents=True, exist_ok=True)
    with output.open('x') as stream: json.dump(report, stream, indent=2, sort_keys=True); stream.write('\n')
    print('L1_DONOR_OFFLINE_AUDIT_PASS', json.dumps(report['stages'], sort_keys=True))


if __name__ == '__main__':
    main()
