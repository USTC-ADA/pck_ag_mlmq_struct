"""Read-only NVML observations aligned to the solver's CLOCK_MONOTONIC window."""
import ctypes as C
import hashlib
import json
import math
import os
from pathlib import Path
import re
import threading
import time
from run_l3_batch_runtime import parse_timing


def parse_windows(raw, repeats, warmups, start_ns, end_ns):
    lines = [s for s in raw.splitlines() if s.startswith('L3_TIMING ')]
    origins = []
    for line in lines:
        match = re.search(r' origin_ms=(\d+\.\d+)$', line)
        if not match or not math.isfinite(float(match[1])) or float(match[1]) <= 0:
            raise ValueError('missing absolute monotonic timing origin')
        origins.append(float(match[1]))
    stripped = re.sub(r'^(L3_TIMING .*) origin_ms=\d+\.\d+$', r'\1', raw, flags=re.M)
    rows = parse_timing(stripped, repeats, 2, warmups)
    for row, origin in zip(rows, origins):
        row['origin_ms'] = origin
        row['window_start_ns'] = round((origin+row['work_after_ms'])*1e6)
        row['window_end_ns'] = round((origin+row['sync_after_ms'])*1e6)
        if not start_ns <= row['window_start_ns'] < row['window_end_ns'] <= end_ns:
            raise ValueError('solver and observer monotonic clocks do not align')
    for q in range(repeats):
        origins = [r['origin_ms'] for r in rows if r['repeat']==q]
        if abs(origins[0]-origins[1]) > 0.00001:
            raise ValueError('GPU timing origins differ')
    return rows


def summarize_window(window, observations):
    start, end = window['window_start_ns'], window['window_end_ns']
    rows = [r for r in observations if r['gpu']==window['gpu'] and start <= r['start_ns'] <= r['end_ns'] <= end]
    points = [(r['start_ns']+r['end_ns'])//2 for r in rows]
    gaps = [b-a for a,b in zip([start]+points,points+[end])]
    good = len(rows)>=5 and max(gaps)<=20_000_000 and all(r['rc'][f]==0 and r[f]>0 for r in rows for f in ('sm_mhz','memory_mhz'))
    return {'gpu':window['gpu'],'repeat':window['repeat'],'warmup':window['warmup'],
            'window_start_ns':start,'window_end_ns':end,'samples':len(rows),
            'coverage_valid':good,'max_gap_ms':max(gaps)/1e6,
            'values':{f:sorted({r[f] for r in rows if r['rc'][f]==0}) for f in ('sm_mhz','memory_mhz','pstate','event_reasons','power_mw','temperature_c')},
            'return_codes':{f:sorted({r['rc'][f] for r in rows}) for f in ('sm_mhz','memory_mhz','pstate','event_reasons','power_mw','temperature_c')}}


class NvmlObserver:
    """Uses no NVML setters. API reads are sequential, not an atomic snapshot."""
    def __init__(self, devices, period_ms=2):
        if not os.environ.get('SLURM_JOB_ID'):
            raise RuntimeError('NVML observations require this task Slurm allocation')
        self.lib = C.CDLL('libnvidia-ml.so.1')
        self.functions = {}
        self.bind('nvmlInit_v2', [])
        self.bind('nvmlShutdown', [])
        self.bind('nvmlDeviceGetHandleByUUID', [C.c_char_p,C.POINTER(C.c_void_p)])
        self.bind('nvmlSystemGetNVMLVersion', [C.c_char_p,C.c_uint])
        self.bind('nvmlSystemGetDriverVersion', [C.c_char_p,C.c_uint])
        self.bind('nvmlDeviceGetClockInfo', [C.c_void_p,C.c_int,C.POINTER(C.c_uint)])
        self.bind('nvmlDeviceGetPerformanceState', [C.c_void_p,C.POINTER(C.c_uint)])
        self.bind('nvmlDeviceGetPowerUsage', [C.c_void_p,C.POINTER(C.c_uint)])
        self.bind('nvmlDeviceGetTemperature', [C.c_void_p,C.c_int,C.POINTER(C.c_uint)])
        self.reason_api = 'nvmlDeviceGetCurrentClocksEventReasons' if hasattr(self.lib,'nvmlDeviceGetCurrentClocksEventReasons') else 'nvmlDeviceGetCurrentClocksThrottleReasons'
        self.bind(self.reason_api,[C.c_void_p,C.POINTER(C.c_ulonglong)])
        self.checked('nvmlInit_v2')
        self.devices=[]
        for gpu,uuid in devices:
            handle=C.c_void_p();self.checked('nvmlDeviceGetHandleByUUID',uuid.encode(),C.byref(handle))
            self.devices.append((gpu,uuid,handle))
        self.metadata={'requested_period_ms':period_ms,'devices':[{'gpu':g,'uuid':u} for g,u,_ in self.devices],
            'read_only':True,'reason_api':self.reason_api,'clock':time.get_clock_info('monotonic').implementation,
            'limitations':['current NVML values may be internally cached; request period is not guaranteed hardware update period','sequential field reads, not an atomic device snapshot','no power or clock settings are changed']}
        for name,key in [('nvmlSystemGetNVMLVersion','nvml_version'),('nvmlSystemGetDriverVersion','driver_version')]:
            value=C.create_string_buffer(128);self.checked(name,value,128);self.metadata[key]=value.value.decode()
        libraries={line.split()[-1] for line in Path('/proc/self/maps').read_text().splitlines() if '/libnvidia-ml.so' in line}
        self.metadata['libraries']={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in libraries}
        self.period=period_ms/1000;self.thread=None

    def bind(self,name,args):
        fn=getattr(self.lib,name);fn.argtypes=args;fn.restype=C.c_int;self.functions[name]=fn

    def checked(self,name,*args):
        rc=self.functions[name](*args)
        if rc:raise RuntimeError(f'{name}: NVML rc={rc}')

    def sample(self,gpu,uuid,handle):
        row={'gpu':gpu,'uuid':uuid,'start_ns':time.monotonic_ns(),'rc':{}}
        fields=[('sm_mhz','nvmlDeviceGetClockInfo',[handle,1],C.c_uint),
                ('memory_mhz','nvmlDeviceGetClockInfo',[handle,2],C.c_uint),
                ('pstate','nvmlDeviceGetPerformanceState',[handle],C.c_uint),
                ('event_reasons',self.reason_api,[handle],C.c_ulonglong),
                ('power_mw','nvmlDeviceGetPowerUsage',[handle],C.c_uint),
                ('temperature_c','nvmlDeviceGetTemperature',[handle,0],C.c_uint)]
        for field,name,args,kind in fields:
            value=kind();rc=self.functions[name](*args,C.byref(value))
            row['rc'][field]=rc;row[field]=value.value if rc==0 else None
        row['end_ns']=time.monotonic_ns();return row

    def start(self):
        if self.thread is not None:raise RuntimeError('observer already running')
        self.rows=[];self.errors=[];self.stop_event=threading.Event()
        def poll():
            try:
                while not self.stop_event.is_set():
                    begin=time.monotonic()
                    for device in self.devices:self.rows.append(self.sample(*device))
                    self.stop_event.wait(max(0,self.period-(time.monotonic()-begin)))
            except Exception as error:self.errors.append(repr(error))
        self.thread=threading.Thread(target=poll,name='readonly-nvml',daemon=True);self.thread.start()

    def stop(self,path):
        self.stop_event.set();self.thread.join(timeout=5)
        if self.thread.is_alive():raise RuntimeError('NVML observer did not stop')
        self.thread=None
        result={'metadata':self.metadata,'errors':self.errors,'rows':self.rows}
        path.write_text(json.dumps(result,separators=(',',':'))+'\n')
        if self.errors:raise RuntimeError(str(self.errors))
        return result

    def close(self):
        if self.thread is not None:raise RuntimeError('cannot close running observer')
        self.checked('nvmlShutdown')
