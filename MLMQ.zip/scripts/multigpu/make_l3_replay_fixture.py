#!/usr/bin/env python3
"""Emit a clearly labeled synthetic fixture, NEVER a real capture substitute."""
import argparse
import heapq
from pathlib import Path
import struct


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("out", type=Path)
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=False)
    vertices = 512
    adjacency = [[((vertex + 1) % vertices, 1), ((vertex - 1) % vertices, 2),
                  ((vertex + 7) % vertices, 3)] for vertex in range(vertices)]
    distance = [(1 << 31) - 1] * vertices
    distance[0] = 0
    queue = [(0, 0)]
    while queue:
        value, vertex = heapq.heappop(queue)
        if value != distance[vertex]:
            continue
        for dest, weight in adjacency[vertex]:
            if value + weight < distance[dest]:
                distance[dest] = value + weight
                heapq.heappush(queue, (distance[dest], dest))
    edges = vertices * 3
    with (args.out / "fixture.gr").open("wb") as stream:
        stream.write(struct.pack("<4Q", 1, 4, vertices, edges))
        stream.write(struct.pack(f"<{vertices}Q", *(3 * (i + 1) for i in range(vertices))))
        stream.write(struct.pack(f"<{edges}I", *(dest for row in adjacency for dest, _ in row)))
        stream.write(struct.pack(f"<{edges}i", *(weight for row in adjacency for _, weight in row)))
    (args.out / "fixture.oracle").write_bytes(struct.pack(f"<{vertices}i", *distance))
    lines = [f"L3_REAL_BATCH_V1 {vertices} {edges} 4"]
    for gpu in (0, 1):
        for quiet in (0, 1):
            begin, end, bin_id = gpu * 256, (gpu + 1) * 256, 2 + quiet
            lines.append(f"{gpu} {bin_id} 0 {bin_id * 37} {begin} {end} 0 {2 * quiet} {0 if quiet else 64} 32 16")
            for i in range(16):
                vertex = begin + (i % 8) * 7
                value = distance[vertex] + 100
                lines.append(f"{vertex} {value + 3} {value} {value + 6} 3")
    (args.out / "fixture.batches").write_text("\n".join(lines) + "\n")
    (args.out / "FIXTURE_ONLY.txt").write_text("Synthetic parser/kernel correctness fixture. Not real L1 supply or performance evidence.\n")
    print(f"SYNTHETIC_REPLAY_FIXTURE {args.out}")


if __name__ == "__main__":
    main()
