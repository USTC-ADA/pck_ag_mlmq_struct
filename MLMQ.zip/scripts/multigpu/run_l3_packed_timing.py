#!/usr/bin/env python3
import argparse,json,subprocess
from pathlib import Path
from run_l3_batch_runtime import verify_tree
from run_l3_upgrade_stage2 import slurm_preflight,write_json
from run_l3_compact_screen import sanitizer_passed
from audit_l3_packed_trace import Graph,load_batches,sha,require
from audit_l3_packed_width import audit_width
from audit_l3_packed_timing import references,audit_timing

def main():
 p=argparse.ArgumentParser()
 for k in ('fixture','harness','capture','reference','sanitizer','out'):p.add_argument('--'+k,type=Path,required=True)
 a=p.parse_args();f,h,c,ref=a.fixture.resolve(),a.harness.resolve(),a.capture.resolve(),a.reference.resolve()
 fm,hm=verify_tree(f),verify_tree(h);require(Path(__file__).resolve()==h/'source/scripts/multigpu/run_l3_packed_timing.py','execute frozen runner')
 meta=json.loads((c/'capture.json').read_text());m=meta['manifest']
 require(sha(m['graph'])==m['graph_sha256'] and sha(m['oracle'])==m['oracle_sha256'] and sha(c/'batches.txt')==meta['batches_sha256'],'capture changed')
 g=Graph(m['graph']);batches=load_batches(c/'batches.txt',g)
 checked=audit_width(ref,batches,g);require(checked['valid'] and checked['journals']==2958,'reference trace invalid');reference=references(ref)
 a.out.mkdir(parents=True,exist_ok=False);allocation=slurm_preflight(a.out)
 write_json(a.out/'manifest.json',dict(fixture=fm,harness=hm,allocation=allocation,capture=meta,reference_sha256=sha(ref),reference_auditor=sha(Path(__file__).parent/'audit_l3_packed_width.py')))
 results={}
 for label in ('normal','memcheck','racecheck','synccheck'):
  limit=0 if label=='normal' else 4;output=a.out/(label+'.jsonl');log=a.out/(label+'.log')
  cmd=[str(f/'fixture'),m['graph'],str(c/'batches.txt'),m['oracle'],str(output),str(limit)]
  if label!='normal':cmd=[str(a.sanitizer.resolve()),'--tool',label,'--error-exitcode','9']+cmd
  with log.open('w') as stream:rc=subprocess.run(cmd,stdout=stream,stderr=subprocess.STDOUT,timeout=300).returncode
  raw=log.read_text();ok=rc==0 and raw.count(f'PACKED_TIMING_PASS captured={len(batches)} limit={limit} payload_only_not_solve=1')==1 and sanitizer_passed(raw,None if label=='normal' else label)
  results[label]=dict(valid=ok,rc=rc,command=cmd,limit=limit);write_json(a.out/'status.json',dict(complete=False,results=results));require(ok,'timing stage failed: '+label)
  result=audit_timing(output,log,batches,reference,limit);result['input_sha256']=sha(output);write_json(a.out/(label+'_audit.json'),result)
  results[label]['journals']=result['journals'];print('PASS',label,result['journals'],flush=True)
 verify_tree(f);verify_tree(h)
 summary=dict(valid=True,complete=True,results=results,scope='only normal stage is timing data; sanitizer times excluded; no complete solve')
 write_json(a.out/'summary.json',summary);write_json(a.out/'status.json',summary)
if __name__=='__main__':main()
