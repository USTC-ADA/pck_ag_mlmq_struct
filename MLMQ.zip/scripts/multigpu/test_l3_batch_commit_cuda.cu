// Two independent owner committers compete on atomic distances. Bounded sinks
// are fixture queues, NOT MLMQ L2/inbox and NOT cross-GPU termination/relay.
#include <cuda_runtime.h>
#include <cassert>
#define L3_COMMIT_TEST_LIBRARY
#include "test_l3_batch_commit.cpp"

#define CUDA(call) do { auto rc = (call); if (rc != cudaSuccess) throw std::runtime_error(cudaGetErrorString(rc)); } while (0)
constexpr int vertex_count = 32, queue_capacity = 128;
struct Input {
    bc::record journal[2][64];
    bc::seed roots[2][4];
    int count[2], seeds[2], begin, end, competitor_vertex, competitor_distance;
    int distance[vertex_count];
};
struct Output {
    int distance[vertex_count];
    bc::seed local[queue_capacity], remote[queue_capacity], delayed;
    int local_valid[queue_capacity], remote_valid[queue_capacity];
    int local_count, remote_count, local_credits, remote_credits, delayed_credit;
    int local_quota, remote_quota, blocks, retired[2], finished[2], wins[2];
    int required[2][64];
};
struct DeviceBackend {
    Output *out;
    __device__ int local_min(int v, int d) { return atomicMin(out->distance + v, d); }
    __device__ bool publish(int v, int d, bool remote) {
        int *count = remote ? &out->remote_count : &out->local_count;
        const int quota = remote ? out->remote_quota : out->local_quota;
        int ticket = atomicAdd(count, 0);
        for (;;) {
            if (ticket >= quota) { atomicAdd(&out->blocks, 1); return false; }
            int old = atomicCAS(count, ticket, ticket + 1);
            if (old == ticket) break;
            ticket = old;
        }
        assert(ticket < queue_capacity);
        (remote ? out->remote : out->local)[ticket] = {v, d};
        atomicAdd(remote ? &out->remote_credits : &out->local_credits, 1);
        __threadfence();
        atomicExch((remote ? out->remote_valid : out->local_valid) + ticket, 1);
        return true;
    }
    __device__ bool publish_local(int v, int d) {
        assert(atomicAdd(out->distance + v, 0) <= d);
        return publish(v, d, false);
    }
    __device__ bool publish_remote(int v, int d) { return publish(v, d, true); }
};

__global__ void exercise(const Input *inputs, Output *outputs) {
    const auto &input = inputs[blockIdx.x];
    auto &out = outputs[blockIdx.x];
    __shared__ bc::state<64> states[2];
    __shared__ bc::donor_ledger donors[2];
    const int lane = threadIdx.x;
    out.distance[lane] = input.distance[lane];
    __syncthreads();
    DeviceBackend backend{&out};
    if (lane < 2) {
        bc::initialize(states[lane]);
        donors[lane] = {7 + lane * 4, 0, false};
        assert(bc::reserve(states[lane], 1, donors[lane], input.roots[lane], input.seeds[lane],
                           input.begin, input.end, vertex_count));
        assert(bc::step(states[lane], 1, backend) == bc::result::blocked);
        assert(bc::retire_if_idle(donors[lane], true) == 0);
        assert(bc::accept_journal(states[lane], 1, input.journal[lane], input.count[lane]));
    }
    __syncthreads();
    for (int tick = 0; tick < 256; ++tick) {
        if (lane == 0) {
            out.remote_quota = tick < 20 ? 0 : tick < 40 ? 1 : queue_capacity;
            out.local_quota = tick < 60 ? 0 : tick < 100 ? 1 : queue_capacity;
        }
        __syncthreads();
        // This writer can race the two journals' atomicMin. It retains its own
        // producer credit outside the queue throughout the entire commit test.
        if (lane == 2 && tick == int(blockIdx.x % 100)) {
            const int prior = atomicMin(out.distance + input.competitor_vertex, input.competitor_distance);
            if (input.competitor_distance < prior) {
                out.delayed = {input.competitor_vertex, input.competitor_distance};
                out.delayed_credit = 1;
            }
        }
        if (lane < 2) {
            const auto result = bc::step(states[lane], 1, backend);
            const int credit = bc::retire_if_idle(donors[lane], true);
            if (result != bc::result::complete) assert(credit == 0 && donors[lane].outstanding == 1);
            else if (credit) { assert(credit == 7 + lane * 4); out.retired[lane] += credit; }
        }
        __syncthreads();
    }
    if (lane < 2) {
        const auto &s = states[lane];
        assert(s.stage == bc::phase::finished && donors[lane].outstanding == 0);
        out.finished[lane] = 1;
        out.wins[lane] = s.wins;
        for (int i = 0; i < input.count[lane]; ++i) out.required[lane][i] = s.required[i];
        assert(bc::step(states[lane], 1, backend) == bc::result::complete);
        assert(bc::recycle(states[lane], 1));
        assert(bc::step(states[lane], 1, backend) == bc::result::stale);
    }
}

static void verify(const Graph &g, const Input &input, const Output &out) {
    CHECK(out.finished[0] && out.finished[1] && out.retired[0] == 7 && out.retired[1] == 11);
    CHECK(out.local_count == out.local_credits && out.remote_count == out.remote_credits);
    World world(g);
    world.distance.assign(out.distance, out.distance + vertex_count);
    std::vector<bc::seed> roots;
    for (int loan = 0; loan < 2; ++loan) {
        roots.insert(roots.end(), input.roots[loan], input.roots[loan] + input.seeds[loan]);
        for (int i = 0; i < input.count[loan]; ++i) {
            auto record = input.journal[loan][i];
            world.completed[record.vertex] = std::min(world.completed[record.vertex], record.certificate);
        }
    }
    roots.push_back({input.competitor_vertex, input.competitor_distance});
    if (out.delayed_credit) world.delayed.push_back(out.delayed);
    for (int i = 0; i < out.local_count; ++i) { CHECK(out.local_valid[i] == 1); world.local.push_back(out.local[i]); }
    for (int i = 0; i < out.remote_count; ++i) { CHECK(out.remote_valid[i] == 1); world.remote.push_back(out.remote[i]); }
    CHECK(world.invariant()); // independently witness every finite live distance
    while (world.work()) CHECK(world.invariant());
    CHECK(world.distance == dijkstra(g, roots));
    // Every required publication appears, with exact multiplicity. No relying
    // merely on a coincidentally successful final-distance comparison.
    std::vector<std::pair<int, int>> expected_local, expected_remote, actual_local, actual_remote;
    for (int loan = 0; loan < 2; ++loan) for (int i = 0; i < input.count[loan]; ++i) {
        auto r = input.journal[loan][i];
        if (r.vertex < input.begin || r.vertex >= input.end) expected_remote.push_back({r.vertex, r.distance});
        else if (out.required[loan][i] < r.certificate) expected_local.push_back({r.vertex, out.required[loan][i]});
    }
    for (int i = 0; i < out.local_count; ++i) actual_local.push_back({out.local[i].vertex, out.local[i].distance});
    for (int i = 0; i < out.remote_count; ++i) actual_remote.push_back({out.remote[i].vertex, out.remote[i].distance});
    for (auto *v : {&expected_local, &expected_remote, &actual_local, &actual_remote}) std::sort(v->begin(), v->end());
    CHECK(expected_local == actual_local && expected_remote == actual_remote);
}

int main(int argc, char **argv) {
    try {
        const int cases = argc == 2 && std::string(argv[1]) == "--quick" ? 128 : 2048;
        int devices = 0; CUDA(cudaGetDeviceCount(&devices)); CHECK(devices == 2);
        std::vector<Graph> graphs;
        std::vector<Input> inputs(cases);
        for (int test = 0; test < cases; ++test) {
            std::mt19937 rng(20260925u + test);
            Graph g(vertex_count);
            for (int v = 0; v < vertex_count; ++v) {
                for (int edge = 0; edge < 4; ++edge) g[v].push_back({int(rng() % vertex_count), int(rng() % 30)});
                g[v].push_back({(v + 1) % vertex_count, 0});
                g[v].push_back({v, INT_MAX});
            }
            auto &in = inputs[test];
            in.begin = test % 2 ? 16 : 0; in.end = in.begin + 16;
            std::fill(in.distance, in.distance + vertex_count, INT_MAX);
            for (int loan = 0; loan < 2; ++loan) {
                in.seeds[loan] = 4;
                for (int k = 0; k < 4; ++k) {
                    const int v = in.begin + int(rng() % 4);
                    in.roots[loan][k] = {v, 100 + v};
                    in.distance[v] = 100 + v;
                }
                std::vector<bc::seed> roots(in.roots[loan], in.roots[loan] + 4);
                auto journal = helper(g, roots, in.begin, in.end, (test + loan) % 25);
                in.count[loan] = int(journal.size());
                std::copy(journal.begin(), journal.end(), in.journal[loan]);
            }
            in.competitor_vertex = in.begin + int(rng() % 16);
            in.competitor_distance = 1 + rng() % 10;
            graphs.push_back(std::move(g));
        }
        unsigned long long blocked = 0;
        // Serial on each allocated A100. Both devices really run the owner
        // fixture; this is NOT peer execution or a dual-GPU SSSP query.
        for (int device = 0; device < devices; ++device) {
            CUDA(cudaSetDevice(device));
            cudaDeviceProp prop{}; CUDA(cudaGetDeviceProperties(&prop, device));
            CHECK(prop.major == 8 && prop.minor == 0);
            Input *device_in = nullptr; Output *device_out = nullptr;
            CUDA(cudaMalloc(&device_in, cases * sizeof(Input)));
            CUDA(cudaMalloc(&device_out, cases * sizeof(Output)));
            CUDA(cudaMemcpy(device_in, inputs.data(), cases * sizeof(Input), cudaMemcpyHostToDevice));
            CUDA(cudaMemset(device_out, 0, cases * sizeof(Output)));
            exercise<<<cases, 32>>>(device_in, device_out);
            CUDA(cudaGetLastError()); CUDA(cudaDeviceSynchronize());
            std::vector<Output> outputs(cases);
            CUDA(cudaMemcpy(outputs.data(), device_out, cases * sizeof(Output), cudaMemcpyDeviceToHost));
            CUDA(cudaFree(device_in)); CUDA(cudaFree(device_out));
            for (int test = 0; test < cases; ++test) { verify(graphs[test], inputs[test], outputs[test]); blocked += outputs[test].blocks; }
            std::cout << "BATCH_COMMIT_DEVICE_PASS device=" << device << " cases=" << cases << '\n';
        }
        CHECK(blocked > unsigned(cases));
        std::cout << "BATCH_COMMIT_CUDA_PASS cases=" << cases * devices << " blocked_retries=" << blocked
                  << " owner_only=1 no_peer_relay=1 not_solver_integration=1 not_performance=1\n";
        return 0;
    } catch (const std::exception &e) { std::cerr << "FAIL " << e.what() << '\n'; return 1; }
}
