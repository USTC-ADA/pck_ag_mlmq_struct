#!/usr/bin/env python3
"""One true dual-A100 capture, then bounded real-CSR replay (not solve timing)."""
from __future__ import annotations
import argparse
from collections import defaultdict
import json
import os
from pathlib import Path
import re
import statistics
import subprocess
import sys

from run_l3_upgrade_stage2 import ROOT, clean_environment, command_capture, sha256, slurm_preflight, write_json


def summarize_replay(raw, *, zero_budget=False):
    budgets = (0, 8, 64, 256) if zero_budget else (8, 64, 256)
    layouts = re.findall(r"^REAL_REPLAY_LAYOUT compact_active=(\d+) workspace_bytes=(\d+)$", raw, re.MULTILINE)
    if raw.count("REAL_REPLAY_LAYOUT") != len(layouts) or len(layouts) > 1:
        raise ValueError("malformed/duplicate replay layout")
    if layouts and (layouts[0][0] not in ("0", "1") or int(layouts[0][1]) <= 0):
        raise ValueError("invalid replay layout")
    passes = re.findall(r"^REAL_REPLAY_PASS fixture_local=(\d+) original_batches=(\d+) payload_only_not_solve=(\d+)$", raw, re.MULTILINE)
    if len(passes) != 1 or passes[0][0] != "0" or passes[0][2] != "1" or int(passes[0][1]) <= 0:
        raise ValueError("missing real dual-GPU replay pass; fixture is not admissible")
    fields = set("owner quiet mode budget batches repeat ms rows records certified unique_certified debt remote optimal_labels optimal_certificates correct".split())
    groups = defaultdict(list)
    for line in raw.splitlines():
        if not line.startswith("REAL_REPLAY_COST "):
            continue
        pairs = re.findall(r"\b(\w+)=(-?[\d.]+)\b", line)
        row = {key: float(value) if key == "ms" else int(value) for key, value in pairs}
        if len(pairs) != len(row) or set(row) != fields:
            raise ValueError("malformed replay cost row")
        if (row["owner"] not in (0, 1) or row["quiet"] not in (0, 1) or row["mode"] not in (0, 1, 2) or
                row["budget"] not in budgets or row["repeat"] not in (0, 1, 2) or
                row["correct"] != 1 or not 1 <= row["batches"] <= 64 or
                any(value < 0 for value in row.values()) or not 0 < row["ms"] < 600000 or
                row["certified"] > row["records"] or row["unique_certified"] > row["certified"] or
                row["debt"] > row["records"] or row["remote"] > row["records"] or
                row["optimal_labels"] > row["records"] or row["optimal_certificates"] > row["certified"]):
            raise ValueError("invalid replay values")
        if row["mode"] != 0 and (row["rows"] > row["budget"] * row["batches"] or
                                 row["certified"] > row["rows"]):
            raise ValueError("workset exceeded its row budget")
        groups[(row["owner"], row["quiet"], row["budget"], row["mode"])].append(row)
    if {key[0] for key in groups} != {0, 1}:
        raise ValueError("missing replay owner")
    expected = {(owner, quiet, budget, mode) for owner, quiet, _, _ in groups
                for budget in budgets for mode in (0, 1, 2)}
    if set(groups) != expected:
        raise ValueError("missing ablation group")
    summary = []
    for key, rows in sorted(groups.items()):
        if len(rows) != 6 or any(sum(row["repeat"] == repeat for row in rows) != 2 for repeat in (0, 1, 2)):
            raise ValueError("expected forward/reverse three-repeat sampling")
        if len({row["batches"] for row in rows}) != 1:
            raise ValueError("batch count changed between repeats")
        summary.append({"owner": key[0], "quiet_observation": bool(key[1]), "budget": key[2], "mode": key[3],
                        "samples": rows, "median_ms": statistics.median(row["ms"] for row in rows)})
    return {"groups": summary, "includes_zero_budget": zero_budget,
            "compact_active": bool(layouts and layouts[0][0] == "1"),
            "workspace_bytes": int(layouts[0][1]) if layouts else None,
            "timing_boundary": "executor kernel only; excludes input publication, owner commit, persistent resource reservation, uploads, and CPU checks",
            "mode_0": "direct one-hop payload, less work than bounded closure; not normal MLMQ solve",
            "mode_1": "same bounded workset local shared memory",
            "mode_2": "helper-local CSR/shared workset; native peer claim and owner-resident output",
            "limits": "No coherent destination state; complete rows/optimal labels/overlap are not actual saved work. Nondeterministic hash placement may change bounded work across modes."}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--capture", required=True, type=Path)
    parser.add_argument("--replay", required=True, type=Path)
    parser.add_argument("--fixture", required=True, type=Path)
    parser.add_argument("--out", required=True, type=Path)
    args = parser.parse_args()
    if args.out.exists() or args.out.is_symlink():
        parser.error("output already exists")
    args.out.mkdir(parents=True)
    args.out = args.out.resolve()
    binaries = [args.capture.resolve(strict=True), args.replay.resolve(strict=True), args.fixture.resolve(strict=True)]
    hashes = {str(path): sha256(path) for path in binaries}
    allocation = slurm_preflight(args.out)
    write_json(args.out / "pipeline_manifest.json", {"evidence_class": "exploratory_real_capture_and_offline_payload", "allocation": allocation, "binaries": hashes})
    environment = clean_environment()
    stage = "fixture"
    try:
        def run(name, command, timeout):
            print(f"CAPTURE_REPLAY_STAGE {name}", flush=True)
            with (args.out / (name + ".log")).open("w") as stream:
                result = subprocess.run(command, cwd=ROOT, env=environment, stdout=stream, stderr=subprocess.STDOUT, timeout=timeout)
            if result.returncode:
                raise RuntimeError(f"{name} rc={result.returncode}")
        run("fixture", [str(binaries[2])], 60)
        stage = "capture"
        run("capture_driver", [sys.executable, str(ROOT / "scripts/multigpu/run_l3_balance_diag.py"),
            "--binary", str(binaries[0]), "--out", str(args.out / "capture"),
            "--progress-only", "--require-q2-tail", "--require-l1-supply"], 1000)
        stage = "prepare"
        run("prepare", [sys.executable, str(ROOT / "scripts/multigpu/prepare_l3_batch_replay.py"),
            "--run", str(args.out / "capture"), "--out", str(args.out / "prepared")], 120)
        capture = json.loads((args.out / "prepared/capture.json").read_text())
        stage = "replay"
        run("replay", [str(binaries[1]), capture["manifest"]["graph"],
            str(args.out / "prepared/batches.txt"), capture["manifest"]["oracle"]], 600)
        stage = "verify"
        summary = summarize_replay((args.out / "replay.log").read_text())
        if any(sha256(Path(path)) != value for path, value in hashes.items()):
            raise RuntimeError("binary changed during pipeline")
        apps = command_capture(args.out, "gpu_apps_final", ["nvidia-smi", "--query-compute-apps=pid", "--format=csv,noheader"])
        if apps.returncode or apps.stdout.strip():
            raise RuntimeError("unexpected remaining GPU processes; no cleanup attempted")
        write_json(args.out / "summary.json", {"valid": True, "rc": 0, "capture_batches": capture["nonempty_batches"],
            "quiet_batches": capture["quiet_nonempty_batches"], "replay": summary, "not_solve_speedup": True})
        stage = "complete"
        print("REAL_CAPTURE_REPLAY_PIPELINE_PASS not_integrated_sssp=1", flush=True)
    finally:
        write_json(args.out / "status.json", {"stage": stage, "complete": stage == "complete", "slurm_job_id": os.environ.get("SLURM_JOB_ID")})


if __name__ == "__main__":
    main()
