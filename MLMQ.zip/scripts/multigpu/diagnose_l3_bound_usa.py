#!/usr/bin/env python3
"""Count owner-bound opportunities on USA; diagnostic timings are not acceptance."""
import argparse
import json
from pathlib import Path
from run_l3_batch_runtime import (verify_tree, parse_bound, parse_bound_publisher, parse_bound_neighbors, parse_runtime, parse_helpers,
    parse_timing, parse_admission, parse_services, parse_cache)
from run_l3_upgrade_stage2 import clean_environment, sha256, slurm_preflight, write_json
from run_l3_30h import parse_dual_contract, parse_oracle_contract
from run_usa_road_matrix import run_one
from run_l3_batch_runtime import parse_bound_placement, parse_search, parse_select, parse_bound_returned


def main():
    p = argparse.ArgumentParser(description=__doc__)
    for key in ('build', 'harness', 'contract', 'out'):
        p.add_argument('--'+key, type=Path, required=True)
    p.add_argument('--publisher-diag', action='store_true')
    p.add_argument('--neighbors', action='store_true')
    p.add_argument('--helper-mirror', action='store_true')
    p.add_argument('--search-diag', action='store_true')
    p.add_argument('--with-unbound', action='store_true')
    p.add_argument('--select-labels', action='store_true')
    p.add_argument('--returned-bound', action='store_true')
    p.add_argument('--unbound-binary', choices=('batch','unbound_diag'), default='batch')
    p.add_argument('--neighbor-edge-limit', type=int, choices=range(1, 129), default=32)
    args = p.parse_args()
    build, harness = args.build.resolve(), args.harness.resolve()
    bm, hm = verify_tree(build), verify_tree(harness)
    if Path(__file__).resolve() != harness/'source/scripts/multigpu/diagnose_l3_bound_usa.py':
        p.error('execute frozen diagnostic')
    flags = json.loads((build/'diag_command.json').read_text())
    if '-DL3_BATCH_BOUND_DIAG=true' not in flags or '-DL3_BATCH_OWNER_BOUND=true' not in flags:
        p.error('requires instrumented bound binary')
    if args.publisher_diag and '-DL3_BATCH_BOUND_PUBLISH_DIAG=true' not in flags:
        p.error('requires instrumented publisher binary')
    if args.neighbors and ('-DL3_BATCH_BOUND_NEIGHBORS=true' not in flags or args.publisher_diag):
        p.error('requires neighbor build with scan publisher disabled')
    if args.helper_mirror and (not args.neighbors or '-DL3_BATCH_BOUND_HELPER_LOCAL=true' not in flags):
        p.error('requires helper-local neighbor build')
    if args.search_diag and '-DL3_BATCH_SEARCH_DIAG=true' not in flags:
        p.error('requires search diagnostic build')
    if args.returned_bound and (not args.neighbors or '-DL3_BATCH_BOUND_RETURNED=true' not in flags):
        p.error('requires returned publisher build')
    if args.select_labels and '-DL3_BATCH_LABEL_SELECT=true' not in flags:
        p.error('requires selection build')
    if args.with_unbound:
        baseline_flags = json.loads((build/(args.unbound_binary+'_command.json')).read_text())
        if (not args.search_diag or '-DL3_BATCH_SEARCH_DIAG=true' not in baseline_flags or
            '-DL3_BATCH_OWNER_BOUND=false' not in baseline_flags):
            p.error('unbound comparison requires instrumented unbound mlmq_batch')
        if args.select_labels and '-DL3_BATCH_LABEL_SELECT=true' not in baseline_flags:
            p.error('requires unbound selection build')
    c = json.loads(args.contract.read_text())
    graph, oracle = Path(c['graph_path']), Path(c['oracle_path'])
    if sha256(graph) != c['graph_sha256'] or sha256(oracle) != c['oracle_sha256']:
        raise ValueError('input differs from frozen contract')
    args.out.mkdir(parents=True, exist_ok=False)
    allocation = slurm_preflight(args.out)
    write_json(args.out/'manifest.json', dict(build=bm, harness=hm, allocation=allocation, input_contract=c,
        rounds=2, repeats=2, warmups=1, returned_bound=args.returned_bound, publisher_diag=args.publisher_diag, neighbors=args.neighbors, helper_mirror=args.helper_mirror,
        neighbor_edge_limit=args.neighbor_edge_limit, search_diag=args.search_diag, with_unbound=args.with_unbound,
        select_labels=args.select_labels, unbound_binary=args.unbound_binary,
        scope='counting diagnostic only; no speedup acceptance'))
    results = {}
    configurations = (None,0,1,2) if args.with_unbound else (1,2)
    for order, modes in enumerate((configurations, tuple(reversed(configurations)))):
        for mode in modes:
            key = f'r{order}_'+('base' if mode is None else f'mode{mode}')
            env = clean_environment()
            env.update(MLMQ_WORK_BLOCKS='97', MLMQ_CUT_PERCENT=str(c['cut_percent']),
                BENCH_SOURCE=str(c['source']), BENCH_WARMUPS='1', BENCH_REPEATS='2',
                CUDA_MODULE_LOADING='EAGER', L3_SUPPLEMENT_ORACLE=str(oracle),
                MLMQ_BATCH_ENABLED='1', MLMQ_BATCH_FORCE='0', MLMQ_BATCH_SLOTS='128',
                MLMQ_BATCH_BUDGET='512', MLMQ_BATCH_MIN_SEEDS='1', MLMQ_BATCH_HELPER_BLOCKS='8',
                MLMQ_BATCH_ADMIT='1', MLMQ_BATCH_PROBE_CALLS='1', MLMQ_BATCH_SERVICES='3',
                MLMQ_BATCH_SERVICE_CARVEOUT='-1', MLMQ_BATCH_BOUND_MODE=str(0 if mode is None else mode), MLMQ_BATCH_BOUND_STEPS='32')
            if args.neighbors:
                env['MLMQ_BATCH_BOUND_EDGE_LIMIT'] = str(args.neighbor_edge_limit)
            print('RUN', key, flush=True)
            r = run_one(build/('mlmq_'+args.unbound_binary if mode is None else 'mlmq_diag'), graph, 'MLMQ', 2, args.out/key, env,
                        c['source'], 'L1SLF_L2DQ', 1, 2, 180, delta=c['delta'])
            r['environment'] = env
            results[key] = r
            raw = (args.out/(key+'.log')).read_text()
            try:
                if not r['valid']:
                    raise ValueError(r['reason'])
                r['oracle'] = parse_oracle_contract(raw, 3, c['vertices'])
                r['dual'] = parse_dual_contract(raw, 3, 97, c['delta'], 19, expected_window_mode=2,
                    expected_window_min=25000, expected_window_max=25000, expected_idle_backoff=0,
                    require_l2_final=True, expected_worker_recovery=1, expected_ack_capacity=1712)
                if not r['oracle']['valid'] or not r['dual']['valid']:
                    raise ValueError('oracle or dual contract failure')
                r['runtime'] = parse_runtime(raw, 3, 512, 0, False)
                if args.select_labels:
                    r['selection']=parse_select(raw,3)
                r['helpers'] = parse_helpers(raw, 3, 8, r['runtime'])
                r['admission'] = parse_admission(raw, 3, 1, r['runtime'])
                r['services'] = parse_services(raw, 3, 3, 1)
                r['cache'] = parse_cache(raw, 3, -1)
                if mode is not None:
                    r['bound'] = parse_bound(raw, 3, mode, 32, 1)
                elif 'L3_BATCH_BOUND_AUDIT ' in raw:
                    raise ValueError('unbound baseline unexpectedly enabled mirror')
                if args.publisher_diag and mode is not None:
                    r['publisher'] = parse_bound_publisher(raw, 3, mode, 32, r['bound']['config'])
                if args.neighbors and mode is not None:
                    r['neighbors'] = parse_bound_neighbors(raw, 3, mode, args.neighbor_edge_limit, 1, r['runtime'])
                if args.helper_mirror and mode is not None:
                    r['placement'] = parse_bound_placement(raw, 3, r['bound']['config'])
                if args.returned_bound and mode is not None:
                    r['returned']=parse_bound_returned(raw,3,mode,1,r['runtime'])
                r['timing'] = parse_timing(raw, 3, 2, 1)
                if args.search_diag:
                    r['search'] = parse_search(raw, 3, 512, 8, r['runtime'], r['helpers'])
                if mode in (1,2) and not sum(x['checks'] for x in r['bound']['audit']):
                    raise ValueError('no bound observations')
            except Exception as error:
                r.update(valid=False, error=str(error))
                write_json(args.out/'status.json', dict(complete=False, results=results))
                raise
            write_json(args.out/'status.json', dict(complete=False, results=results))
            print('PASS', key, flush=True)
    verify_tree(build);verify_tree(harness)
    summary = dict(valid=True, complete=True, results=results, performance_acceptance=False,
                   scope='diagnostic counters; do not compare timings against uninstrumented performance')
    write_json(args.out/'summary.json', summary)
    write_json(args.out/'status.json', summary)


if __name__ == '__main__':
    main()
