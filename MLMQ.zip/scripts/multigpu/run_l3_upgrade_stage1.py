#!/usr/bin/env python3
"""Collect bounded, non-performance L3 upgrade diagnostics on two A100s."""

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import socket
import struct
import subprocess
import sys

from run_l3_30h import QUEUE_TYPE_IDS, parse_dual_contract, parse_oracle_contract
from run_usa_road_matrix import run_one


ROOT = Path(__file__).resolve().parents[2]
CONTRACT = ROOT / "evidence/l3_algorithm_upgrade_20260924/stage1_contract.json"
QUEUE = "L1SLF_L2DQ"
BLOCKS = 107
SPEC_FIELDS = (
    "NAME", "GRAPH", "ORACLE", "SOURCE", "DELTA", "CUT_PERCENT",
    "GRAPH_SHA256", "ORACLE_SHA256",
)
EXPECTED_SHAPES = {
    "USA": {"vertices": 23947347, "edges": 57708624},
    "COL": {"vertices": 435666, "edges": 1057066},
}

LINE_SCHEMAS = {
    "L3_UPGRADE_RX": (
        "gpu", "winners", "before_first", "before_first_vertices",
        "replacements_before_first", "after_first", "behind", "in_window",
        "ahead",
    ),
    "L3_UPGRADE_DELAY": ("gpu", "samples", "unresolved", "sum_ns", "max_ns"),
    "L3_UPGRADE_FILTER": ("gpu", "filtered", "filtered_edges", "invalid"),
    "L3_UPGRADE_WORK": (
        "gpu", "expanded", "edges", "unique", "repeated", "repeated_edges"),
}


def now_utc():
    return datetime.now(timezone.utc).isoformat()


def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def write_json(path, value):
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")
    os.replace(temporary, path)


def read_gr_header(path):
    with path.open("rb") as stream:
        raw = stream.read(32)
    if len(raw) != 32:
        raise ValueError(f"short GR header: {path}")
    version, edge_bytes, vertices, edges = struct.unpack("<QQQQ", raw)
    if version != 1 or edge_bytes != 4 or not vertices or vertices >= (1 << 31):
        raise ValueError(f"unsupported GR header: {path}")
    return {"vertices": vertices, "edges": edges}


def load_specs(raw_specs, contract):
    if not raw_specs or len(raw_specs) != 2:
        raise ValueError("exactly two --spec entries are required: USA then COL")
    specs = []
    for raw in raw_specs:
        name, graph_s, oracle_s, source_s, delta_s, cut_s, graph_sha, oracle_sha = raw
        if name not in contract["graphs"]:
            raise ValueError(f"unexpected graph name: {name}")
        graph = Path(graph_s).resolve(strict=True)
        oracle = Path(oracle_s).resolve(strict=True)
        source, delta, cut = map(int, (source_s, delta_s, cut_s))
        header = read_gr_header(graph)
        actual_graph_sha = sha256(graph)
        actual_oracle_sha = sha256(oracle)
        observed = {
            "graph_sha256": actual_graph_sha,
            "oracle_sha256": actual_oracle_sha,
            "source": source,
            "delta": delta,
            "cut_percent": cut,
        }
        expected = contract["graphs"][name]
        supplied = {
            "graph_sha256": graph_sha,
            "oracle_sha256": oracle_sha,
            "source": source,
            "delta": delta,
            "cut_percent": cut,
        }
        if supplied != expected or observed != expected:
            raise ValueError(
                f"{name} input differs from frozen contract: "
                f"supplied={supplied} observed={observed} expected={expected}")
        if header != EXPECTED_SHAPES[name]:
            raise ValueError(f"{name} graph shape mismatch: {header}")
        if oracle.stat().st_size != header["vertices"] * 4:
            raise ValueError(f"{name} oracle byte count mismatch")
        specs.append({
            "name": name,
            "graph": graph,
            "oracle": oracle,
            "source": source,
            "delta": delta,
            "cut_percent": cut,
            "graph_sha256": actual_graph_sha,
            "oracle_sha256": actual_oracle_sha,
            **header,
        })
    if [row["name"] for row in specs] != ["USA", "COL"]:
        raise ValueError("frozen diagnostic order is USA then COL")
    return specs


def validate_build(build_dir):
    build_dir = build_dir.resolve(strict=True)
    manifest_path = build_dir / "manifest.json"
    manifest = json.loads(manifest_path.read_text())
    head = subprocess.check_output(
        ["git", "-C", str(ROOT), "rev-parse", "HEAD"], text=True).strip()
    status = subprocess.check_output(
        ["git", "-C", str(ROOT), "status", "--porcelain=v1"], text=True)
    if status:
        raise ValueError("stage1 GPU run requires a clean committed worktree")
    if manifest.get("status") != "complete" or manifest.get("head") != head:
        raise ValueError("build manifest does not match current HEAD")
    if manifest.get("git_status"):
        raise ValueError("build was not produced from a clean worktree")
    if (manifest.get("architecture") != "sm_80" or
            manifest.get("worker_threads") != 512):
        raise ValueError("build is not the frozen A100/W512 configuration")
    resources = manifest.get("resources", {}).get("stage1_diagnostic", {})
    if resources.get("registers", 10**9) > 96:
        raise ValueError(f"diagnostic worker resource gate failed: {resources}")
    verified = {}
    for role, relative in manifest["roles"].items():
        path = (build_dir / relative).resolve(strict=True)
        expected = manifest["artifacts"][relative]["sha256"]
        if sha256(path) != expected:
            raise ValueError(f"changed build artifact: {relative}")
        verified[role] = path
    for relative in (
            "tools/chain_envelope_model_result.json",
            "tools/test_chain_envelope.log",
            "tools/test_l3_chain_partition",
            "tools/test_l3_chain_partition.log"):
        path = (build_dir / relative).resolve(strict=True)
        if sha256(path) != manifest["artifacts"][relative]["sha256"]:
            raise ValueError(f"changed build evidence: {relative}")
    return build_dir, manifest_path, manifest, verified


def command_capture(output, name, command, timeout=60):
    result = subprocess.run(
        command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        text=True, timeout=timeout)
    (output / f"{name}.log").write_text(
        result.stdout + f"\nRUN_RC={result.returncode}\n")
    return result


def slurm_preflight(output):
    if not os.environ.get("SLURM_JOB_ID"):
        raise ValueError("stage1 diagnostics must run inside Slurm")
    if os.environ.get("SLURM_JOB_PARTITION") != "a100":
        raise ValueError(
            f"expected a100 partition, got {os.environ.get('SLURM_JOB_PARTITION')!r}")
    query = command_capture(
        output, "gpu_query",
        ["nvidia-smi", "--query-gpu=index,uuid,name,compute_cap",
         "--format=csv,noheader,nounits"])
    rows = [line.strip() for line in query.stdout.splitlines() if line.strip()]
    if (query.returncode or len(rows) != 2 or
            any("A100" not in row or not row.endswith(", 8.0") for row in rows)):
        raise ValueError(f"expected exactly two allocated A100 GPUs, got {rows}")
    uuids = [row.split(",")[1].strip() for row in rows]
    if len(set(uuids)) != 2 or any(not value.startswith("GPU-") for value in uuids):
        raise ValueError(f"expected two distinct GPU UUIDs, got {uuids}")
    apps = command_capture(
        output, "gpu_apps_initial",
        ["nvidia-smi", "--query-compute-apps=pid", "--format=csv,noheader"])
    if apps.returncode or apps.stdout.strip():
        raise ValueError(f"GPU compute process present before run: {apps.stdout!r}")
    captured = {}
    for name, command in (
        ("nvidia_smi_initial", ["nvidia-smi"]),
        ("gpu_topology", ["nvidia-smi", "topo", "-m"]),
        ("slurm_job_running", ["scontrol", "show", "job", os.environ["SLURM_JOB_ID"]]),
    ):
        result = command_capture(output, name, command)
        if result.returncode:
            raise ValueError(f"preflight command failed: {name}")
        captured[name] = result.stdout
    if "NV" not in captured["gpu_topology"]:
        raise ValueError("allocated A100 pair does not report an NVLink topology")
    return {"job_id": os.environ["SLURM_JOB_ID"], "gpus": rows}


def clean_environment():
    environment = {
        key: value for key, value in os.environ.items()
        if key.startswith("SLURM_") or key in (
            "CUDA_VISIBLE_DEVICES", "CUDA_DEVICE_ORDER", "TZ", "TMPDIR")
    }
    environment.update({
        "PATH": "/usr/local/cuda/bin:/usr/bin:/bin",
        "LANG": "C",
        "LC_ALL": "C",
        "MLMQ_BENCH": "1",
        "MLMQ_WORK_BLOCKS": str(BLOCKS),
        "BENCH_QUEUE": QUEUE,
        "MLMQ_FINAL_AUDIT": "failure",
    })
    environment.pop("CUDA_LAUNCH_BLOCKING", None)
    return environment


def parse_integer_lines(raw, prefix, fields):
    rows = []
    pattern = re.compile(rf"^{re.escape(prefix)}(?:\s+([a-zA-Z0-9_]+)=(-?\d+))+$")
    for line in raw.splitlines():
        if not line.startswith(prefix + " "):
            continue
        if not pattern.fullmatch(line):
            raise ValueError(f"malformed {prefix} line: {line!r}")
        values = {key: int(value) for key, value in re.findall(r"([a-zA-Z0-9_]+)=(-?\d+)", line)}
        if tuple(values) != fields:
            raise ValueError(
                f"{prefix} field mismatch: {tuple(values)} != {fields}")
        rows.append(values)
    if len(rows) != 2 or sorted(row["gpu"] for row in rows) != [0, 1]:
        raise ValueError(f"expected one {prefix} row per GPU, got {rows}")
    return rows


def parse_histogram(raw, prefix, bin_field):
    rows = []
    expected = ("gpu", bin_field, "count")
    for line in raw.splitlines():
        if not line.startswith(prefix + " "):
            continue
        values = {key: int(value) for key, value in re.findall(r"([a-zA-Z0-9_]+)=(-?\d+)", line)}
        if tuple(values) != expected or values["gpu"] not in (0, 1):
            raise ValueError(f"malformed {prefix} line: {line!r}")
        rows.append(values)
    return rows


def aggregate_diagnostics(raw):
    rows = {
        prefix: parse_integer_lines(raw, prefix, fields)
        for prefix, fields in LINE_SCHEMAS.items()
    }
    rx = rows["L3_UPGRADE_RX"]
    delay = rows["L3_UPGRADE_DELAY"]
    filt = rows["L3_UPGRADE_FILTER"]
    work = rows["L3_UPGRADE_WORK"]
    totals = {}
    for name, group in (("rx", rx), ("delay", delay),
                        ("filter", filt), ("work", work)):
        totals[name] = {
            key: sum(row[key] for row in group)
            for key in group[0] if key != "gpu" and key != "max_ns"
        }
    totals["delay"]["max_ns"] = max(row["max_ns"] for row in delay)
    winners = totals["rx"]["winners"]
    before = totals["rx"]["before_first"]
    first_vertices = totals["rx"]["before_first_vertices"]
    replacements = totals["rx"]["replacements_before_first"]
    totals["derived"] = {
        "replacement_share_of_rx_winners": replacements / winners if winners else 0.0,
        "replacement_share_of_preexpand_winners": replacements / before if before else 0.0,
        "mean_preexpand_winners_per_vertex": before / first_vertices if first_vertices else 0.0,
        "after_first_share_of_rx_winners": (
            totals["rx"]["after_first"] / winners if winners else 0.0),
        "behind_share_of_rx_winners": (
            totals["rx"]["behind"] / winners if winners else 0.0),
        "existing_filter_edges_per_token": (
            totals["filter"]["filtered_edges"] / totals["filter"]["filtered"]
            if totals["filter"]["filtered"] else 0.0),
    }
    return {
        "per_gpu": rows,
        "totals": totals,
        "lag_histogram": parse_histogram(raw, "L3_UPGRADE_LAG_BIN", "log2_bucket"),
        "delay_histogram": parse_histogram(raw, "L3_UPGRADE_DELAY_BIN", "log2_ns"),
    }


def run_graph(output, binary, spec, environment, timeout):
    run_env = dict(environment)
    run_env.update({
        "BENCH_SOURCE": str(spec["source"]),
        "BENCH_WARMUPS": "0",
        "BENCH_REPEATS": "1",
        "MLMQ_CUT_PERCENT": str(spec["cut_percent"]),
        "L3_SUPPLEMENT_ORACLE": str(spec["oracle"]),
    })
    prefix = output / f"diagnostic_{spec['name']}_s{spec['source']}"
    result = run_one(
        binary, spec["graph"], "MLMQ", 2, prefix, run_env,
        spec["source"], QUEUE, 0, 1, timeout, spec["delta"])
    raw = prefix.with_suffix(".log").read_text()
    oracle = parse_oracle_contract(raw, 1, spec["vertices"])
    dual = parse_dual_contract(
        raw, 1, BLOCKS, spec["delta"], QUEUE_TYPE_IDS[QUEUE],
        expected_window_mode=2, expected_window_min=25000,
        expected_window_max=25000, expected_idle_backoff=0,
        require_l2_final=True)
    errors = [*oracle["errors"], *dual["errors"]]
    for marker in ("Error at node", "ORACLE_MISMATCH", "ORACLE_SIZE_ERROR",
                   "FINAL_AUDIT_ERROR"):
        if marker in raw:
            errors.append(f"solver reported {marker}")
    try:
        diagnostics = aggregate_diagnostics(raw)
    except ValueError as error:
        diagnostics = None
        errors.append(str(error))
    record = {
        "graph": spec["name"],
        "performance_allowed": False,
        "timing_interpretation": "diagnostic build; timings excluded",
        "run": result,
        "contracts": {"oracle": oracle, "dual": dual},
        "diagnostics": diagnostics,
        "errors": errors,
        "valid": result["valid"] and not errors,
        "log": str(prefix.with_suffix(".log")),
    }
    write_json(prefix.with_suffix(".parsed.json"), record)
    if not record["valid"]:
        raise RuntimeError(f"retained failed diagnostic {spec['name']}: {errors or result['reason']}")
    return record


def parse_args(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--build-dir", required=True, type=Path)
    parser.add_argument("--spec", action="append", nargs=8, metavar=SPEC_FIELDS)
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("--timeout", type=int, default=900)
    args = parser.parse_args(argv)
    if args.timeout <= 0:
        parser.error("timeout must be positive")
    if args.out.exists() or args.out.is_symlink():
        parser.error(f"output already exists: {args.out}")
    contract = json.loads(CONTRACT.read_text())
    if contract.get("status") != "frozen_before_stage1_gpu_run":
        parser.error("stage1 contract is not frozen")
    try:
        args.specs = load_specs(args.spec, contract)
    except (OSError, ValueError) as error:
        parser.error(str(error))
    args.contract = contract
    return args


def main(argv=None):
    args = parse_args(argv)
    build_dir, build_manifest_path, build_manifest, binaries = validate_build(args.build_dir)
    output = args.out.resolve(strict=False)
    output.mkdir(parents=True)
    allocation = slurm_preflight(output)
    manifest = {
        "schema": 1,
        "status": "running",
        "created_utc": now_utc(),
        "host": socket.gethostname(),
        "invocation": [sys.executable, str(Path(__file__).resolve()), *sys.argv[1:]],
        "allocation": allocation,
        "git_head": build_manifest["head"],
        "git_branch": build_manifest["branch"],
        "contract": {"path": str(CONTRACT), "sha256": sha256(CONTRACT)},
        "build": {
            "directory": str(build_dir),
            "manifest_sha256": sha256(build_manifest_path),
            "diagnostic_binary_sha256": sha256(binaries["diagnostic"]),
            "resources": build_manifest["resources"]["stage1_diagnostic"],
        },
        "configuration": {
            "gpu_count": 2,
            "blocks": BLOCKS,
            "queue": QUEUE,
            "worker_threads": 512,
            "warmups": 0,
            "queries_per_graph": 1,
            "performance_allowed": False,
        },
        "inputs": [{
            key: str(value) if isinstance(value, Path) else value
            for key, value in spec.items()
        } for spec in args.specs],
    }
    write_json(output / "manifest.json", manifest)
    (output / "runner.py").write_bytes(Path(__file__).read_bytes())

    environment = clean_environment()
    records = []
    for spec in args.specs:
        record = run_graph(
            output, binaries["diagnostic"], spec, environment, args.timeout)
        records.append(record)
        write_json(output / "records.json", records)

    command_capture(output, "nvidia_smi_final", ["nvidia-smi"])
    apps = command_capture(
        output, "gpu_apps_final",
        ["nvidia-smi", "--query-compute-apps=pid", "--format=csv,noheader"])
    if apps.returncode or apps.stdout.strip():
        raise RuntimeError(f"GPU process remained after diagnostics: {apps.stdout!r}")

    decision = {}
    for record in records:
        totals = record["diagnostics"]["totals"]
        decision[record["graph"]] = {
            "rx_winners": totals["rx"]["winners"],
            "preexpand_replacements": totals["rx"]["replacements_before_first"],
            "replacement_share_of_rx_winners":
                totals["derived"]["replacement_share_of_rx_winners"],
            "existing_filtered_tokens": totals["filter"]["filtered"],
            "existing_filtered_edges": totals["filter"]["filtered_edges"],
        }
    manifest.update({
        "status": "complete",
        "completed_utc": now_utc(),
        "all_correct": all(record["valid"] for record in records),
        "decision_inputs": decision,
        "decision_boundary": (
            "Only observed online counts are reported. This stage neither times nor "
            "implements a receiver coalescer."),
    })
    write_json(output / "manifest.json", manifest)
    write_json(output / "summary.json", {
        "status": "complete", "all_correct": True,
        "performance_allowed": False, "decision_inputs": decision,
    })
    checksums = []
    for path in sorted(output.iterdir()):
        if path.is_file() and path.name != "SHA256SUMS":
            checksums.append(f"{sha256(path)}  {path.name}")
    (output / "SHA256SUMS").write_text("\n".join(checksums) + "\n")
    print(json.dumps({"status": "complete", "output": str(output),
                      "decision_inputs": decision}, sort_keys=True))


if __name__ == "__main__":
    main()
