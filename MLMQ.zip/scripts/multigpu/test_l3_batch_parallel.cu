// Differential intake/APPLY/publication contract against the scalar adapter.
// Real queue/peer effects are checked separately by the opted-in fixtures.
#include "../../SSSP/l3/l3_batch_commit_parallel.cuh"
#include <cstdio>
#include <cstdlib>
#include <vector>
#ifdef NDEBUG
#error "Contract tests require assertions"
#endif
namespace bc=l3_batch_commit;
namespace bw=l3_batch_commit_warp;
namespace bp=l3_batch_commit_parallel;
constexpr int local_vertices=1024;
struct data {
    bc::state<> scalar,parallel;
    bc::donor_ledger donors[2];
    bw::intent intents[2];
    bp::workspace table;
    bc::record journal[768];
    bc::seed roots[512];
    int distance[2][local_vertices];
    int count,seeds,begin,vertices,expect,accepted;
};
__device__ void equal_state(const data &d,int lane) {
    const auto &a=d.scalar; const auto &b=d.parallel;
    assert(a.stage==b.stage && a.cursor==b.cursor && a.count==b.count && a.wins==b.wins);
    assert(a.local_published==b.local_published && a.remote_published==b.remote_published);
    assert(d.donors[0].outstanding==d.donors[1].outstanding);
    for(int i=lane;i<a.count;i+=32)assert(a.required[i]==b.required[i]);
    for(int i=lane;i<local_vertices;i+=32)assert(d.distance[0][i]==d.distance[1][i]);
    __syncwarp();
}
__global__ void differential(data *ptr) {
    auto &d=*ptr;const int lane=threadIdx.x;
    if(!lane) {
        bc::initialize(d.scalar);bc::initialize(d.parallel);
        d.donors[0]=d.donors[1]={8,0,false};
        assert(bc::reserve(d.scalar,1,d.donors[0],d.roots,d.seeds,d.begin,d.begin+local_vertices,d.vertices));
        assert(bc::reserve(d.parallel,1,d.donors[1],d.roots,d.seeds,d.begin,d.begin+local_vertices,d.vertices));
        d.accepted=bc::accept_journal(d.scalar,1,d.journal,d.count);
    }
    __syncwarp();
    assert(!bp::accept_journal(d.parallel,2,d.journal,d.count,d.table,lane));
    const bool accepted=bp::accept_journal(d.parallel,1,d.journal,d.count,d.table,lane);
    assert(accepted==bool(d.accepted) && d.accepted==d.expect);
    if(!lane && !accepted) {
        assert(bc::start_fallback(d.scalar,1));assert(bc::start_fallback(d.parallel,1));
    }
    __syncwarp();
    bw::initialize(d.intents[0],lane);bw::initialize(d.intents[1],lane);
    equal_state(d,lane);
    int steps=0;
    while(d.scalar.stage!=bc::phase::finished) {
        assert(++steps<200);
        const auto a=bw::prepare(d.scalar,1,d.intents[0],d.distance[0],lane);
        const auto b=bp::prepare(d.parallel,1,d.intents[1],d.distance[1],lane);
        assert(a==b);equal_state(d,lane);
        auto &x=d.intents[0];auto &y=d.intents[1];
        assert(x.status==y.status);
        if(x.status!=bw::publication::empty) {
            assert(x.source_phase==y.source_phase && x.start==y.start && x.end==y.end &&
                   x.count==y.count && x.remote==y.remote);
            if(lane<x.count)assert(x.items[lane].vertex==y.items[lane].vertex && x.items[lane].distance==y.items[lane].distance);
            __syncwarp();
            assert(bw::prepare(d.scalar,1,x,d.distance[0],lane)==bc::result::blocked);
            assert(bp::prepare(d.parallel,1,y,d.distance[1],lane)==bc::result::blocked);
            assert(bp::prepare(d.parallel,2,y,d.distance[1],lane)==bc::result::stale);
            if(!lane) {
                if(x.status==bw::publication::prepared) {
                    assert(!bw::acknowledge(d.scalar,1,x));assert(!bw::acknowledge(d.parallel,1,y));
                    x.status=y.status=bw::publication::published;
                }
                assert(bw::acknowledge(d.scalar,1,x));assert(bw::acknowledge(d.parallel,1,y));
                assert(!bw::acknowledge(d.scalar,1,x));assert(!bw::acknowledge(d.parallel,1,y));
            }
            __syncwarp();
        }
        // Simulate independently responsible competitors after our APPLY.
        // Sticky required values and emitted outputs must still agree.
        if(d.scalar.stage==bc::phase::remote)
            for(int i=lane;i<local_vertices;i+=32) d.distance[0][i]=d.distance[1][i]=0;
        __syncwarp();equal_state(d,lane);
    }
    if(!lane) {
        assert(!d.donors[0].outstanding && !d.donors[1].outstanding);
        assert(bc::retire_if_idle(d.donors[0],true)==8 && bc::retire_if_idle(d.donors[1],true)==8);
    }
}
static void check(cudaError_t e) { if(e!=cudaSuccess){fprintf(stderr,"CUDA: %s\n",cudaGetErrorString(e));exit(2);} }
int main() {
    data *gpu;check(cudaMalloc(&gpu,sizeof(data)));
    int cases=0,valid=0,rejected=0;
    for(int begin: {0,37})for(int count: {1,7,31,32,33,511,512,768})for(int collision: {0,1})for(int fault=0;fault<12;++fault) {
        data d{};d.begin=begin;d.vertices=begin+1024*769;d.count=count;d.seeds=count==1?1:512;d.expect=fault==0;
        for(int j=0;j<count;++j) {
            const int v=begin+(collision?j*1024:j);
            d.journal[j]={v,10+(j%7),v<begin+1024 && j%3==0?10+(j%7):INT_MAX};
        }
        for(int i=0;i<d.seeds;++i) {
            int j=collision?0:i%count;
            d.roots[i]={d.journal[j].vertex,d.journal[j].distance+(i%5)};
        }
        for(int i=0;i<local_vertices;++i) d.distance[0][i]=d.distance[1][i]=(i%3==0?INT_MAX:i%3==1?0:10+i%7);
        switch(fault) {
            case 1:d.journal[0].vertex=-1;break;
            case 2:d.journal[0].vertex=d.vertices;break;
            case 3:d.journal[0].distance=-1;break;
            case 4:d.journal[0].distance=INT_MAX;break;
            case 5:d.journal[0].certificate=9;break;
            case 6:d.journal[0]={begin+2048,10,10};break;
            case 7:if(count>1)d.journal[count-1]=d.journal[0];else d.count=0;break;
            case 8:d.roots[0]={begin+1023,1};break;
            case 9:d.journal[0].distance=30;d.journal[0].certificate=INT_MAX;break;
            case 10:d.count=769;break;
            case 11:d.count=-1;break;
        }
        check(cudaMemcpy(gpu,&d,sizeof(d),cudaMemcpyHostToDevice));
        differential<<<1,32>>>(gpu);check(cudaGetLastError());check(cudaDeviceSynchronize());
        ++cases;valid+=d.expect;rejected+=!d.expect;
    }
    check(cudaFree(gpu));
    printf("BATCH_PARALLEL_DIFFERENTIAL_PASS cases=%d valid=%d rejected=%d sticky_competitor=1 hash_collision=1\n",cases,valid,rejected);
}
