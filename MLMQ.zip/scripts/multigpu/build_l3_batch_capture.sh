#!/usr/bin/env bash
# Local compilation only; outputs are EXPLORATORY, never formal clean-SHA proof.
set -euo pipefail
capture_out=${1:?Unique nonexisting output directory required}
[[ "${2:-}" == --allow-dirty ]] || { echo 'Requires --allow-dirty exploratory acknowledgement' >&2; exit 2; }
[[ -z "${3:-}" || "${3:-}" == --owner-probe ]] || { echo 'Unknown diagnostic option' >&2; exit 2; }
capture_owner_probe=false
[[ "${3:-}" != --owner-probe ]] || capture_owner_probe=true
[[ ! -e "$capture_out" && ! -L "$capture_out" ]]
capture_root=$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd -P)
mkdir -p "$(dirname "$capture_out")"
mkdir "$capture_out"
capture_out=$(cd "$capture_out" && pwd -P)
cd "$capture_root"
git status --short > "$capture_out/worktree_status.txt"
git diff > "$capture_out/worktree.diff"
tar -czf "$capture_out/source.tgz" SSSP core scripts/multigpu
capture_command=(nvcc SSSP/main.cu SSSP/csr_graph.cu SSSP/sssp_run.cu
    -DWORK_COUNT=false -DMLMQ_WORKER_THREADS=512 -DBNUM=8 -DBUCKET_MAX=4 -Dl2_batch_size=8
    -DL3_COOPERATIVE_COLLECT=true -DL3_DIRECT_RX=true -DL3_RETAIN_TX=true
    -DL3_WINDOW_MODE=2 -DL3_WINDOW_MIN_CYCLES=25000ull -DL3_WINDOW_MAX_CYCLES=25000ull
    -DL3_IDLE_BACKOFF=false -DL3_WORKER_RECOVERY=true -DL3_TERM_WAIT_ACK=true
    -DL3_ACK_SCAN=true -DL3_ACK_WIDE_SCAN=true -DL3_BOUNDARY_INDEX=true
    -DL3_L2_FINAL_COUNTS=true -DDQ_COUNTER_OVERFLOW_GUARD=true
    -DL3_CHAIN_SHORTCUTS=false -DL3_CHAIN_PARTITION=false -DL3_CHAIN_V2=false
    -DL3_IDLE_TOKEN_PROBE=true -DL3_TERM_ONLY_WORKER=true
    -DL3_PROGRESS_DIAG=true -DL3_Q2_TAIL_DIAG=true -DL3_L1_SUPPLY_DIAG=true -DL3_L1_CAPTURE_DIAG=true
    "-DL3_OWNER_PROBE_DIAG=$capture_owner_probe"
    -O3 -m64 -gencode=arch=compute_80,code=sm_80 -rdc=true -maxrregcount=96 -Xptxas=-v
    -lcuda -lcudart -w -Icore/include -I/a100-data/wyh/boost_1_87_0 -lcusparse
    -o "$capture_out/mlmq_capture")
printf '%q ' "${capture_command[@]}" > "$capture_out/command.sh"
printf '\n' >> "$capture_out/command.sh"
"${capture_command[@]}" > "$capture_out/build.log" 2>&1
capture_control=()
for capture_arg in "${capture_command[@]}"; do
    case "$capture_arg" in
        -DL3_PROGRESS_DIAG=true|-DL3_Q2_TAIL_DIAG=true|-DL3_L1_SUPPLY_DIAG=true|-DL3_L1_CAPTURE_DIAG=true|-DL3_OWNER_PROBE_DIAG=true)
            capture_control+=("${capture_arg%=true}=false") ;;
        "$capture_out/mlmq_capture") capture_control+=("$capture_out/mlmq_control") ;;
        *) capture_control+=("$capture_arg") ;;
    esac
done
printf '%q ' "${capture_control[@]}" > "$capture_out/control_command.sh"
printf '\n' >> "$capture_out/control_command.sh"
"${capture_control[@]}" > "$capture_out/control_build.log" 2>&1
nvcc scripts/multigpu/test_l3_l1_supply_cuda.cu -O3 -lineinfo -Icore/include \
    "-DL3_OWNER_PROBE_DIAG=$capture_owner_probe" \
    -gencode=arch=compute_80,code=sm_80 -o "$capture_out/test_capture_sm80" > "$capture_out/fixture_build.log" 2>&1
nvcc scripts/multigpu/replay_l3_real_batches.cu -O3 -lineinfo \
    -gencode=arch=compute_80,code=sm_80 -o "$capture_out/replay_sm80" > "$capture_out/replay_build.log" 2>&1
sha256sum "$capture_out/mlmq_capture" "$capture_out/mlmq_control" "$capture_out/test_capture_sm80" "$capture_out/replay_sm80" "$capture_out/source.tgz" > "$capture_out/SHA256SUMS"
printf 'CAPTURE_BUILD_PASS exploratory=1 out=%s\n' "$capture_out"
