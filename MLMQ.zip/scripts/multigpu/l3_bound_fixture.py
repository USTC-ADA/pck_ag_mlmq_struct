"""Inputs and independent responsibility audit for the owner-bound component."""
import heapq
import json
from pathlib import Path

INF = 2**31 - 1


def cases():
    def case(name, n=12, begin=0, end=None, roots=None, tickets=None, edges=None, budget=512, prune=False):
        return dict(name=name, n=n, begin=begin, end=n if end is None else end, roots=roots or [[begin, 0]],
                    tickets=tickets or [], edges=edges if edges is not None else [[v, v+1, 1] for v in range(n-1)],
                    budget=budget, expect_prune=prune)
    return [
        case('all_inf_successors'),
        case('equal_queued_bound', tickets=[[2, 2]], prune=True),
        case('higher_bound', tickets=[[2, 9]], edges=[[0, 2, 9], [0, 1, 1], [1, 2, 1], [2, 3, 1]], prune=True),
        case('lower_bound', tickets=[[2, 1]], edges=[[0, 2, 1], [0, 1, 5], [1, 2, 5], [2, 3, 1]], prune=True),
        case('root_lower_backedge', roots=[[0, 10], [3, 0]], edges=[[3, 0, 1], [0, 1, 1], [1, 2, 1]]),
        case('zero_cycle', tickets=[[1, 0]], edges=[[0, 1, 0], [1, 0, 0], [0, 2, 1], [2, 0, 0]], prune=True),
        case('remote_both_sides', n=31, begin=17, end=29, tickets=[[19, 2]],
             edges=[[17, 18, 1], [18, 19, 1], [17, 0, 4], [17, 30, 5], [19, 20, 1]], prune=True),
        case('capacity_stop', n=800, tickets=[[1, 1]], edges=[[0, v, 1] for v in range(1, 770)]),
        case('budget_zero', tickets=[[2, 2]], budget=0),
        case('overflow', roots=[[0, INF-4]], edges=[[0, 1, 5], [0, 2, 3], [2, 3, 1]]),
        case('duplicate_roots', roots=[[0, 0], [0, 5]], tickets=[[3, 3]], prune=True),
        case('mirror_tail_65', n=65, tickets=[[64, 64]], prune=True),
        case('mirror_tail_129', n=129, begin=7, end=127, tickets=[[126, 119]], prune=True),
    ]


def inputs_for_query(case, query):
    # Reuse allocations; a later query with larger roots catches stale low
    # mirrors that would be harmless if every query had identical distances.
    offset = 0 if query == 0 or case['name'] == 'overflow' else 100
    roots = [[v, d+offset] for v, d in case['roots']]
    tickets = case['tickets'] if query == 0 else []
    return roots, tickets


def dijkstra(case, starts):
    adjacency = [[] for _ in range(case['n'])]
    for u, v, w in case['edges']:
        if w < 0:
            raise ValueError('negative fixture edge')
        adjacency[u].append((v, w))
    distance = [INF] * case['n']
    todo = []
    for v, d in starts:
        if d < distance[v]:
            distance[v] = d
            heapq.heappush(todo, (d, v))
    while todo:
        d, v = heapq.heappop(todo)
        if d != distance[v]:
            continue
        for dest, weight in adjacency[v]:
            nd = min(INF, d + weight)
            if nd < distance[dest]:
                distance[dest] = nd
                heapq.heappush(todo, (nd, dest))
    return distance


def neighbor_cases(helper_local=False):
    data = cases()
    # Two-hop-only finite labels are deliberately NOT in the sampled mirror.
    for c in data:
        c['expect_prune'] = c['name'] in ('higher_bound', 'lower_bound', 'zero_cycle')
    data.extend([
        dict(name='concurrent_same_slot', n=66, begin=0, end=66,
             roots=[[v, 0] for v in range(64)], tickets=[[64, 1]],
             edges=[[v, 64, 1] for v in range(64)]+[[64, 65, 1]], budget=512, expect_prune=True),
        dict(name='neighbor_edge_limit', n=5, begin=0, end=5, roots=[[0, 0]],
             tickets=[[1, 1], [2, 1], [3, 1]], edges=[[0, v, 1] for v in (1, 2, 3)]+[[3, 4, 1]],
             budget=512, expect_prune=True),
        dict(name='remote_consumes_sample_limit', n=31, begin=17, end=29, roots=[[17, 0]],
             tickets=[[18, 1]], edges=[[17, 0, 1], [17, 30, 1], [17, 18, 1], [18, 19, 1]],
             budget=512, expect_prune=False),
    ])
    for c in data:
        c.update(publication='neighbors', edge_limit=2, publisher_warps=2)
        if helper_local:
            c['helper_local'] = True
    return data


def sampled_neighbors(c, roots):
    adjacency = [[] for _ in range(c['n'])]
    for u, v, _ in c['edges']:
        adjacency[u].append(v)
    return [v for u, _ in roots for v in adjacency[u][:c['edge_limit']]
            if c['begin'] <= v < c['end']]


def search_cases():
    data = neighbor_cases(helper_local=True)
    data.extend([
        dict(name='repeat_improvement', n=6, begin=0, end=6, roots=[[0,0]], tickets=[],
             edges=[[0,1,10],[0,2,1],[1,3,1],[2,4,1],[4,1,1]], budget=512, expect_prune=False,
             publication='neighbors', edge_limit=2, publisher_warps=2, helper_local=True, expect_repeated=True),
        dict(name='budget_one', n=4, begin=0, end=4, roots=[[0,0]], tickets=[],
             edges=[[0,1,1],[1,2,1],[2,3,1]], budget=1, expect_prune=False,
             publication='neighbors', edge_limit=2, publisher_warps=2, helper_local=True),
    ])
    for c in data:
        c['search_diag'] = True
    return data


def selection_cases():
    data=search_cases()
    edges=[[0,i,100] for i in range(1,33)]+[[0,i,1] for i in range(33,65)]
    edges += [[i,i-32,1] for i in range(33,65)]+[[i,i+64,1] for i in range(1,33)]
    data.append(dict(name='wide_label_order',n=97,begin=0,end=97,roots=[[0,0]],tickets=[],edges=edges,
        budget=512,expect_prune=False,publication='neighbors',edge_limit=2,publisher_warps=2,
        helper_local=True,search_diag=True,selection_rows={'0':161,'1':97}))
    for c in data:
        c['selection_comparison']=True
    return data


def returned_cases():
    data=search_cases()
    for c in data:
        c.update(publication='returned',helper_local=True,publisher_warps=2)
        c['expect_prune']=bool(c['tickets']) and c['name'] not in ('capacity_stop','budget_zero')
    return data


def write_inputs(directory, neighbors=False, helper_local=False, search_diag=False, selection=False, returned=False):
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=False)
    if helper_local and not neighbors:
        raise ValueError('helper-local inputs require neighbors')
    data = returned_cases() if returned else selection_cases() if selection else search_cases() if search_diag else neighbor_cases(helper_local) if neighbors else cases()
    (directory / 'cases.json').write_text(json.dumps(data, indent=2)+'\n')
    lines = [str(len(data))]
    for c in data:
        lines.append(' '.join(map(str, [c['n'], c['begin'], c['end'], c['budget'], len(c['roots']), len(c['tickets']), len(c['edges'])])))
        for key in ('roots', 'tickets', 'edges'):
            lines.extend(' '.join(map(str, row)) for row in c[key])
    (directory / 'cases.txt').write_text('\n'.join(lines)+'\n')


def path_witnesses(c, roots, targets, owner_only=False):
    """Exact-length walks for small fixtures, independent of the GPU workset."""
    targets = set(targets)
    if not targets:
        return True
    limit = max(d for _, d in targets)
    adjacency = [[] for _ in range(c['n'])]
    for u, v, w in c['edges']:
        if w < 0:
            raise ValueError('negative witness edge')
        if not owner_only or c['begin'] <= u < c['end']:
            adjacency[u].append((v, w))
    todo = list({(v, d) for v, d in roots if d <= limit})
    reached = set(todo)
    missing = targets - reached
    for v, d in todo:
        if not missing:
            return True
        for dest, weight in adjacency[v]:
            item = (dest, d + weight)
            if item[1] <= limit and item not in reached:
                reached.add(item)
                missing.discard(item)
                todo.append(item)
                if len(todo) > 1000000:
                    raise ValueError('exact path witness search exceeds fixture limit')
    return not missing


def audit_record(c, result):
    def require(ok, why):
        if not ok:
            raise ValueError(c['name']+': '+why)
    query, mode = result['query'], result['mode']
    if c.get('selection_comparison'):
        require(result.get('selection') in (0,1), 'selection policy')
    require(query in (0, 1) and mode in (0, 1, 2) and result['owner'] in (0, 1), 'identity')
    roots, tickets = inputs_for_query(c, query)
    require(result['tickets'] == tickets, 'external queued responsibilities lost')
    expected = dijkstra(c, roots)
    # All finite fixture bounds have actual pending tickets or preserved roots.
    # Tickets in these cases have an explicit reachable walk with this length;
    # below-shortest values are always rejected.
    require(all(expected[v] <= d < INF for v, d in tickets), 'ticket shorter than a possible path')
    require(path_witnesses(c, roots, map(tuple, tickets)), 'ticket has no path witness')
    bounds = [INF] * (c['end'] - c['begin'])
    for v, d in roots + tickets:
        require(c['begin'] <= v < c['end'], 'bound witness outside owner')
        bounds[v-c['begin']] = min(bounds[v-c['begin']], d)
    if c.get('publication') == 'neighbors':
        if c.get('helper_local'):
            require(result.get('mirror_gpu') == 1-result['owner'], 'helper-local physical mirror placement')
        require(result.get('publication') == 'neighbors' and result.get('edge_limit') == c['edge_limit'],
                'neighbor publication configuration')
        samples = sampled_neighbors(c, roots) if mode else []
        finite = sum(bounds[v-c['begin']] < INF for v in samples)
        require(result.get('publisher_counts') == [c['publisher_warps']*len(samples), c['publisher_warps']*finite],
                'neighbor publisher counts')
        selected = set(samples)
        bounds = [value if i+c['begin'] in selected else INF for i, value in enumerate(bounds)]
    if c.get('publication')=='returned':
        require(result.get('publication')=='returned' and result.get('mirror_gpu')==1-result['owner'], 'returned mirror configuration')
        require(result.get('returned_guard_checks')==16, 'returned phase/fallback/off gates missing')
        foreign=int(c['begin']>0)+int(c['end']<c['n'])
        require(result.get('publisher_counts')==([2*(len(tickets)+foreign),2*len(tickets)] if mode else [0,0]), 'returned publisher counts')
        bounds=[INF]*(c['end']-c['begin'])
        if mode:
            for v,d in tickets:bounds[v-c['begin']]=min(bounds[v-c['begin']],d)
    require(result['mirror'] == bounds, 'mirror/reset/publication differs from witnesses')
    require(result['status'] == 0 and 0 < len(result['journal']) <= 768, 'invalid journal')
    labels, certs = {}, {}
    for v, d, cert in result['journal']:
        require(0 <= v < c['n'] and v not in labels, 'invalid/duplicate vertex')
        require(expected[v] <= d < INF and d <= cert <= INF, 'invalid distance/certificate')
        require(c['begin'] <= v < c['end'] or cert == INF, 'remote vertex was certified')
        labels[v], certs[v] = d, cert
    require(all(labels.get(v, INF) <= d for v, d in roots), 'root removed')
    paths = list(labels.items()) + [(v, d) for v, d in certs.items() if d < INF]
    require(path_witnesses(c, roots, paths, owner_only=True), 'journal/certificate has no path witness')
    edges_covered = 0
    for u, v, w in c['edges']:
        cert = certs.get(u, INF)
        if cert >= INF or cert+w >= INF:
            continue
        candidate = cert+w
        in_owner = c['begin'] <= v < c['end']
        covered = mode == 2 and in_owner and bounds[v-c['begin']] <= candidate
        require(labels.get(v, INF) <= candidate or covered, 'full-row edge has no journal or witnessed bound')
        edges_covered += 1
    require(sum(d < INF for d in certs.values()) <= result['rows'] <= c['budget'], 'row count/budget inconsistent')
    checks, covered, pruned = result['counts']
    require(0 <= pruned <= covered <= checks, 'counter order')
    require((mode == 2 and pruned == covered) or (mode != 2 and pruned == 0), 'mode/counters')
    require(mode != 0 or checks == 0, 'off mode read mirror')
    if mode == 2 and query == 0 and c['expect_prune']:
        require(pruned > 0, 'vacuous pruning case')
    if c['name'] in ('capacity_stop', 'budget_zero'):
        require(result['rows'] == 0 and all(x == INF for x in certs.values()), 'capacity/budget stop changed')
    # Independent completion from remaining responsibilities. Certified rows do
    # not seed the queue, but their labels remain in the final distance state.
    debts = tickets + [[v, d] for v, d in labels.items() if d < certs[v]]
    resumed = dijkstra(c, debts)
    for v, d in labels.items():
        resumed[v] = min(resumed[v], d)
    require(resumed == expected, 'remaining work does not recover full shortest paths')
    if c.get('search_diag'):
        s = result['search']
        fields = 'loans seeds rows certified records remaining capacity empty budget failure'.split()
        require(set(s) == set(fields) and all(type(s[k]) is int and s[k] >= 0 for k in fields), 'search fields')
        pending = sum(c['begin'] <= v < c['end'] and d < certs[v] for v, d in labels.items())
        require(s['loans'] == 1 and s['seeds'] == len(roots) and s['rows'] == result['rows'] and
                s['certified'] == sum(d < INF for d in certs.values()) and s['records'] == len(labels) and
                s['remaining'] == pending and s['failure'] == 0, 'search journal conservation')
        require(s['capacity']+s['empty']+s['budget'] == 1, 'search stop exclusivity')
        if s['capacity']:
            require(pending > 0 and s['rows'] < c['budget'], 'capacity stop boundary')
        elif s['empty']:
            require(pending == 0, 'empty stop boundary')
        else:
            require(pending > 0 and s['rows'] == c['budget'], 'budget stop boundary')
        if c['name'] == 'capacity_stop':
            require(s['capacity'] == 1, 'missing capacity observation')
        if c['name'] in ('budget_zero', 'budget_one'):
            require(s['budget'] == 1, 'missing budget observation')
        if c.get('expect_repeated'):
            require(s['rows'] > s['certified'], 'vacuous repeated expansion')
        if 'selection_rows' in c:
            require(s['rows'] == c['selection_rows'][str(result['selection'])], 'selection did not change expected expansion order')
    return dict(rows=result['rows'], edges_audited=edges_covered, checks=checks, pruned=pruned)


def audit_file(inputs, path):
    data = json.loads(Path(inputs).read_text())
    rows = [json.loads(line) for line in Path(path).read_text().splitlines()]
    expected_keys = {(i, owner, query, mode,selection) for i,c in enumerate(data) for owner in (0, 1) for query in (0, 1) for mode in (0, 1, 2)
                     for selection in ((0,1) if c.get('selection_comparison') else (0,))}
    found, details = set(), []
    for r in rows:
        key = (r['case'], r['owner'], r['query'], r['mode'],r.get('selection',0))
        if key not in expected_keys or key in found:
            raise ValueError('duplicate/unexpected fixture record')
        found.add(key)
        details.append(audit_record(data[r['case']], r))
    if found != expected_keys:
        raise ValueError('missing fixture records')
    return dict(valid=True, records=len(rows), details=details,
                scope='packed P2P executor and dedicated mirror; pending fixture tickets, not production DQ/ACK')


def audit_selection_file(path):
    inputs=[]
    for n in (1,7,31,32,33,64,65,127,512,768):
        for head in (0,3,1001,0xffffffef):
            for take in (min(n,32),min(n,7),1):
                for tie in (0,1):inputs.append(dict(head=head,pending=n,take=take,tie=tie,seed=len(inputs)))
    found=set()
    for line in Path(path).read_text().splitlines():
        r=json.loads(line);identity=(r['gpu'],r['case'])
        if identity in found or r['gpu'] not in (0,1) or not 0<=r['case']<len(inputs):
            raise ValueError('selection fixture identity')
        found.add(identity);m=inputs[r['case']]
        if any(r[k]!=v for k,v in m.items()):raise ValueError('selection fixture input')
        logical=[(i*17+3)&1023 for i in range(m['pending'])]
        original=logical.copy()
        distance=lambda slot:9 if m['tie'] else (slot*37+m['seed'])%97
        # Sort each disjoint logical lane list by (label, original position).
        # GPU uses an in-place scan on physical circular slots instead.
        for lane in range(m['take']):
            choices=sorted(range(lane,m['pending'],32),key=lambda i:(distance(original[i]),i))
            chosen=choices[0];logical[lane],logical[chosen]=original[chosen],original[lane]
        expected=[65535]*1024
        for i,value in enumerate(logical):expected[(m['head']+i)&1023]=value
        if r['fifo']!=expected:raise ValueError('selection minimum/tie/permutation/canary mismatch')
    if found!={(g,i) for g in (0,1) for i in range(len(inputs))}:raise ValueError('missing selection fixture records')
    return dict(valid=True,records=len(found),physical_slots_checked=1024*len(found))
