import unittest
from prepare_l3_batch_replay import parse_capture
from run_l3_batch_capture_replay import summarize_replay


def fixture():
    lines = []
    for gpu, begin, end in ((0, 0, 60), (1, 60, 100)):
        lines += [f"L3_L1_CAPTURE_CONFIG gpu={gpu} warps=1712 slots=8 max_batch=32 ids_zero_based=1 observational=1",
                  f"L3_Q2_TAIL gpu={gpu} bin=1 since=2097153 total=7 available=0 local_term=0 peer_term=2",
                  f"L3_L1_CAPTURE gpu={gpu} bin=1 slot=0 warp=37 begin={begin} end={end} raw=2 eligible=2 inflight=7"]
        for index in (0, 1):
            lines.append(f"L3_L1_CAPTURE_ITEM gpu={gpu} bin=1 slot=0 index={index} vertex={begin} queued=7 authoritative=5 processed=9 degree=2 eligible=1")
    return "\n".join(lines)


class CaptureTests(unittest.TestCase):
    def test_valid_preserves_duplicates_and_credit(self):
        batches = parse_capture(fixture(), 100, 60)
        self.assertEqual(len(batches), 2)
        self.assertEqual(len(batches[0]["seeds"]), 2)
        self.assertEqual(batches[0]["inflight"], 7)
        self.assertTrue(batches[0]["quiet_observation"])

    def test_missing_item(self):
        with self.assertRaises(ValueError):
            parse_capture("\n".join(fixture().splitlines()[:-1]), 100, 60)

    def test_duplicate_item(self):
        with self.assertRaises(ValueError):
            parse_capture(fixture() + "\n" + fixture().splitlines()[-1], 100, 60)

    def test_invalid_fields(self):
        for old, new in (("authoritative=5", "authoritative=8"),
                         ("processed=9", "processed=6"), ("warp=37", "warp=38"),
                         ("end=60", "end=61"), ("index=1", "index=2"),
                         ("inflight=7", "inflight=-1"), ("degree=2", "degree=-1"),
                         ("ids_zero_based=1", "ids_zero_based=0"),
                         ("since=2097153", "since=1"), ("peer_term=2", "peer_term=3")):
            with self.subTest(old=old), self.assertRaises(ValueError):
                parse_capture(fixture().replace(old, new, 1), 100, 60)

    def test_missing_gpu(self):
        with self.assertRaises(ValueError):
            parse_capture("\n".join(line for line in fixture().splitlines() if "gpu=1" not in line), 100, 60)

    def test_raw_ineligible_preserved(self):
        raw = fixture().replace("raw=2 eligible=2", "raw=2 eligible=0").replace("processed=9", "processed=7").replace("degree=2 eligible=1", "degree=2 eligible=0")
        with self.assertRaisesRegex(ValueError, "no nonempty"):
            parse_capture(raw, 100, 60)


def replay_fixture(zero_budget=False):
    lines = []
    for owner in (0, 1):
        for budget in ((0, 8, 64, 256) if zero_budget else (8, 64, 256)):
            for mode in (0, 1, 2):
                for repeat in (0, 1, 2):
                    for _ in range(2):
                        if budget == 0 and mode != 0:
                            counts = "rows=0 records=8 certified=0 unique_certified=0 debt=8 remote=0 optimal_labels=7 optimal_certificates=0"
                        else:
                            counts = "rows=8 records=16 certified=8 unique_certified=7 debt=8 remote=1 optimal_labels=7 optimal_certificates=3"
                        lines.append(f"REAL_REPLAY_COST owner={owner} quiet=1 mode={mode} budget={budget} batches=1 repeat={repeat} ms=0.1 {counts} correct=1")
    return "\n".join(lines + ["REAL_REPLAY_PASS fixture_local=0 original_batches=2 payload_only_not_solve=1"])


class ReplaySummaryTests(unittest.TestCase):
    def test_layout_provenance(self):
        raw = "REAL_REPLAY_LAYOUT compact_active=1 workspace_bytes=16020\n" + replay_fixture()
        self.assertTrue(summarize_replay(raw)["compact_active"])
        self.assertFalse(summarize_replay(replay_fixture())["compact_active"])
        for bad in (raw + "\nREAL_REPLAY_LAYOUT compact_active=1 workspace_bytes=16020",
                    raw.replace("compact_active=1", "compact_active=2"),
                    raw.replace("workspace_bytes=16020", "workspace_bytes=0"),
                    raw.replace("workspace_bytes=16020", "workspace_bytes=BAD")):
            with self.assertRaises(ValueError):
                summarize_replay(bad)

    def test_zero_budget_requires_explicit_complete_screen(self):
        value = summarize_replay(replay_fixture(True), zero_budget=True)
        self.assertTrue(value["includes_zero_budget"])
        self.assertEqual(len(value["groups"]), 24)
        with self.assertRaises(ValueError):
            summarize_replay(replay_fixture(True))
        with self.assertRaises(ValueError):
            summarize_replay(replay_fixture(), zero_budget=True)

    def test_zero_budget_cannot_claim_expansion(self):
        for old, new in (("rows=0", "rows=1"), ("certified=0", "certified=1")):
            with self.subTest(old=old), self.assertRaises(ValueError):
                summarize_replay(replay_fixture(True).replace(old, new, 1), zero_budget=True)

    def test_valid(self):
        value = summarize_replay(replay_fixture())
        self.assertEqual(len(value["groups"]), 18)
        self.assertEqual(value["groups"][0]["median_ms"], 0.1)

    def test_missing_or_duplicate_sample(self):
        raw = replay_fixture()
        for bad in ("\n".join(raw.splitlines()[1:]), raw + "\n" + raw.splitlines()[0]):
            with self.assertRaises(ValueError):
                summarize_replay(bad)

    def test_reject_fixture_and_bad_values(self):
        for old, new in (("fixture_local=0", "fixture_local=1"), ("correct=1", "correct=0"),
                         ("ms=0.1", "ms=0.0"), ("unique_certified=7", "unique_certified=9"),
                         ("budget=8", "budget=9"), ("batches=1", "batches=2"),
                         ("optimal_labels=7", "optimal_labels=17")):
            with self.subTest(old=old), self.assertRaises(ValueError):
                summarize_replay(replay_fixture().replace(old, new, 1))

    def test_missing_owner_or_mode(self):
        for pattern in ("owner=1", "mode=2"):
            with self.assertRaises(ValueError):
                summarize_replay("\n".join(line for line in replay_fixture().splitlines() if pattern not in line))


if __name__ == "__main__":
    unittest.main()
