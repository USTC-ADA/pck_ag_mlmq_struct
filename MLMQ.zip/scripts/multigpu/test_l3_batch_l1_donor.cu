// Real ml_queue read/SLF write+destructive read -> compact -> remote/local DQ.
// Controlled independent fixture, not work_block_kernel or its ACK protocol.
#include <cstdio>
#include "../../core/include/ml_queue.cuh"
#define L3_COMMIT_TEST_DQ_PREINCLUDED
#define main previous_remote_fixture_main
#include "test_l3_batch_remote_commit.cu"
#undef main
#include "../../SSSP/l3/l3_batch_l1_donor.cuh"
namespace ld = l3_batch_l1_donor;
using SLF = l1_SLF_queue<Item>;
using ML = ml_queue<Item, SLF, Queue>;
struct L1Raw {
    ld::snapshot borrowed;
    int parent_count, credit_before, credit_held, credit_retired, empty_after;
    int rejected, remote_delays, local_delays, claims, journal_count;
    int head_after, outstanding_after, released_after, credit_after;
    bc::record journal[768];
};
struct L1Data { Source source; ML ml; L1Raw *raw; int seeds, unique, prime, *claim_counts; };

__device__ void fetch_parents(L1Data d, Item *input, Item *scratch, int root, int &fly, int lane,
                             unsigned long long start) {
    scratch[lane] = Item(root + (lane % 8) + 1, 0);
    __syncwarp(); int count = 8;
    assert(d.source.side.q.write(scratch, count, 0, 0, lane, nullptr) == WRITE_SUCCESS);
    int n = 0;
    while (n < 8) {
        int part = 0;
        d.ml.update_local_info(lane);
        d.ml.read(input + n, part, fly, 0, 0, lane, nullptr);
        n += part;
        assert(n <= 8);
        deadline(start);
    }
    assert(n == 8 && fly == 8 && d.ml.get_local_queue_size(0) == 0);
    for (int i = lane; i < n; i += 32) assert(input[i].id == root + i + 1);
    __syncwarp();
    if (!lane) d.source.side.stats->bootstrapped += n;
    __syncwarp();
}

__device__ void drain_local(L1Data d, Item *input, int lane, unsigned long long start) {
    auto side = d.source.side;
    while (true) {
        side.q.update_local_info(lane); int n = 0;
        side.q.read(input, n, 0, 0, lane, nullptr);
        for (int i = lane; i < n; i += 32) {
            const int v = input[i].id - 1 - side.begin;
            assert(v >= 0 && v < side.vertices && side.rows[v] == side.rows[v+1]);
            assert(atomicAdd(side.distance + v, 0) <= input[i].dist);
            atomicAdd(side.seen + v, 1); // genuine CSR full-row boundary (sink)
        }
        __syncwarp();
        if (!lane && n) side.q.update_done(n);
        __syncwarp();
        const int left = __shfl_sync(FULL_MASK, !lane ? side.q.get_queue_size() : 0, 0);
        if (left == 8) return; // sole writer/reader, only retained ancestors remain
        deadline(start);
    }
}

__global__ void l1_helper(L1Data d, relay::graph_view graph) {
    const int lane = threadIdx.x; const auto start = clock64();
    __shared__ compact::workspace scratch;
    while (!uniform_load(&d.source.gates->helper_stop, lane)) {
        const auto token = pc::try_claim(d.source.packets, lane);
        if (token) {
            const int round = int(relay::generation(token) - first_generation);
            if (!lane) cuda::atomic_ref<int, cuda::thread_scope_system>(d.claim_counts[round]).fetch_add(1);
            pc::execute_claimed(d.source.packets, token, graph, &scratch, lane);
        }
        deadline(start);
    }
}

__global__ void l1_source(L1Data d) {
    const int lane = threadIdx.x; const auto start = clock64();
    auto s = d.source; auto side = s.side;
    if (blockIdx.x == 1) { manager(side, lane, start); return; }
    extern __shared__ int memory[];
    SLF &q1 = *reinterpret_cast<SLF *>(memory);
    __shared__ Item scratch[64], input[64], removed[32];
    __shared__ ld::snapshot snap;
    if (!lane) {
        // Test initialization of the same SLF fields; do not invoke the old
        // init routine's identical multi-lane metadata writes or change core.
        q1.data_size = q1.l = q1.r = 0; q1.batchSize = 64; q1.init_limits = Item(0, INT_MAX);
        side.q.device_init(0, 0, 0);
        *s.donor = {0,0,true}; bc::initialize(s.states[0]);
        s.states[0].generation = first_generation;
    }
    for (int i = lane; i < 64; i += 32) { q1.buffer[i] = Item(0,INT_MAX); scratch[i] = input[i] = Item(0,INT_MAX); }
    __syncwarp(); bw::initialize(s.intents[0], lane);
    int fly = 0;
    for (int p = 0; p < d.prime; ++p) {
        // Real L2 reads + SLF write/read rotate the ring; sink-only ancestors.
        fetch_parents(d,input,scratch,side.begin+1,fly,lane,start);
        if (!lane) { side.q.update_done(fly); side.stats->retired += fly; }
        fly = 0; __syncwarp();
    }
    for (int round = 0; round < side.rounds; ++round) {
        const int root = side.begin + 9 + round * (8 + 2*d.unique);
        fetch_parents(d,input,scratch,root,fly,lane,start);
        if (!lane) assert(ld::attach(*s.donor,fly));
        __syncwarp();
        const int row = side.rows[root-side.begin];
        assert(side.rows[root-side.begin+1]-row == d.seeds+d.unique);
        // Credited CSR producer retains all eight parent credits. Enqueue
        // first path labels, then process shorter parallel edges while the
        // corresponding task is still pending in this exclusive private L1.
        if (lane < d.seeds) {
            const int e = row+lane, v = side.columns[e];
            atomicMin(side.distance+v-side.begin,side.weights[e]);
            scratch[lane] = Item(v+1,side.weights[e]);
        }
        __syncwarp(); int outputs = d.seeds;
        assert(d.ml.write(scratch,outputs,0,0,lane,nullptr) == WRITE_SUCCESS);
        assert(q1.data_size == d.seeds);
        if (lane < d.unique) {
            const int e = row+d.seeds+lane;
            atomicMin(side.distance+side.columns[e]-side.begin,side.weights[e]);
        }
        __syncwarp();
        auto &state=s.states[0]; auto &intent=s.intents[0]; auto &ticket=s.tickets[0];
        auto &raw=d.raw[round];
        const int head=q1.l, tail=q1.r, size=q1.data_size;
        // Rejected exports preserve actual queue metadata and all item bytes.
        for (int fault=0; fault<5; ++fault) {
            assert(!ld::borrow(q1,state,state.generation+(fault==0),*s.donor,
                fly+(fault==1),fault==2,fault==3,side.distance,
                side.begin, fault==4?side.begin:side.begin+side.vertices,
                side.begin+side.vertices+side.rounds*d.unique*2,snap,removed,lane));
            assert(q1.l==head && q1.r==tail && q1.data_size==size);
            if (lane<size) { const auto item=q1.data[(head+lane)%64]; assert(item.id==scratch[lane].id && item.dist==scratch[lane].dist); }
            __syncwarp();
            if (!lane) ++raw.rejected;
            __syncwarp();
        }
        assert(ld::borrow(q1,state,state.generation,*s.donor,fly,0,0,side.distance,
            side.begin,side.begin+side.vertices,side.begin+side.vertices+side.rounds*d.unique*2,snap,removed,lane));
        assert(!q1.data_size && s.donor->outstanding==1);
        assert(!ld::retire(q1,*s.donor,fly,0,0,true,lane));
        assert(fly==8);
        if (!lane) { raw.borrowed=snap; raw.parent_count=8; raw.credit_before=raw.credit_held=fly; raw.empty_after=q1.data_size; raw.head_after=q1.l; }
        __syncwarp();
        assert(pc::publish_request(state,s.packets,d.unique,lane));
        while (!pc::accept_return(state,s.packets,s.journals,lane)) deadline(start);
        assert(state.stage==bc::phase::apply);
        if (!lane) { raw.journal_count=state.count; raw.claims=sys_load(d.claim_counts+round); }
        for (int i=lane;i<state.count;i+=32) raw.journal[i]=state.journal[i];
        __syncwarp();
        while (state.stage!=bc::phase::finished) {
            if (intent.status==bw::publication::empty) bw::prepare(state,state.generation,intent,side.distance,lane);
            if (intent.status==bw::publication::prepared && intent.remote) {
                assert(rc::send(state,state.generation,intent,*s.sender,ticket,s.peer_channel,lane));
                archive_send(s,round,0,lane); // loan index is round*3 in this shared receipt format
                const int epoch=ticket.identity.epoch;
                if (!lane) sys_store(&s.gates->allow_claim,epoch);
                __syncwarp();
                while (uniform_load(&s.gates->done,lane)<epoch) {
                    if (!lane) {
                        sys_store(&s.gates->allow_apply,sys_load(&s.gates->claimed));
                        sys_store(&s.gates->allow_publish,sys_load(&s.gates->applied));
                    }
                    __syncwarp(); deadline(start);
                }
                assert(!rc::poll(state,state.generation,intent,*s.sender,ticket,s.peer_channel,lane));
                assert(!ld::retire(q1,*s.donor,fly,0,0,true,lane));
                assert(fly==8 && !q1.data_size && s.donor->outstanding==1);
                if (!lane) { ++raw.remote_delays; ++s.gates->delay_checks; sys_store(&s.gates->allow_ack,epoch); }
                __syncwarp();
                while (!rc::poll(state,state.generation,intent,*s.sender,ticket,s.peer_channel,lane)) deadline(start);
                if (!lane) { s.sent_archive[epoch-1].acked=1; ++s.gates->acked; }
                __syncwarp();
            } else if (intent.status==bw::publication::prepared) {
                if (lane<intent.count) atomicAdd(side.expected+intent.items[lane].vertex-side.begin,1);
                assert(bw::publish_l2(state,state.generation,intent,side.q,scratch,0,0,lane));
                drain_local(d,input,lane,start);
                assert(!ld::retire(q1,*s.donor,fly,0,0,false,lane));
                assert(fly==8 && s.donor->outstanding==1);
                if (!lane) ++raw.local_delays;
                __syncwarp();
            }
            if (intent.status==bw::publication::published) {
                if (!lane) assert(bw::acknowledge(state,state.generation,intent));
                __syncwarp();
            }
            deadline(start);
        }
        assert(!ld::retire(q1,*s.donor,fly,1,0,true,lane));
        assert(!ld::retire(q1,*s.donor,fly,0,1,true,lane));
        assert(!ld::retire(q1,*s.donor,fly,0,0,false,lane));
        const int retired=ld::retire(q1,*s.donor,fly,0,0,intent.status==bw::publication::empty,lane);
        assert(retired==8 && fly==0);
        if (!lane) {
            side.q.update_done(retired); side.stats->retired+=retired;
            raw.credit_retired=retired; raw.credit_after=fly;
            raw.outstanding_after=s.donor->outstanding; raw.released_after=s.donor->released;
        }
        __syncwarp(); assert(!ld::retire(q1,*s.donor,fly,0,0,true,lane));
        assert(pc::recycle_committed(state,s.packets,intent,lane));
    }
    if (!lane) {
        assert(side.q.get_queue_size()==0); s.gates->sent=s.sender->last_epoch;
        sys_store(&s.gates->helper_stop,1);sys_store(&s.gates->producer_finished,1);
        store(&side.stats->producer_done,1);store(&side.stats->stop,1);
    }
}

static void run_l1_case(int owner,int begin,int seeds,int duplicate,int prime,int rounds,const std::string &directory) {
    const int peer=1-owner, unique=duplicate?(seeds+1)/2:seeds;
    const int local=9+rounds*(8+2*unique), remote=rounds*2*unique, split=begin+local, max_packets=rounds*4;
    Graph graph(split+remote); std::vector<int> initial(graph.size(),INT_MAX); initial[begin]=0;
    for(int v=begin+1;v<begin+9;++v) { graph[begin].push_back({v,0});initial[v]=0; }
    for(int g=0;g<rounds;++g) {
        const int root=begin+9+g*(8+2*unique);
        for(int i=0;i<8;++i) { graph[begin].push_back({root+i,0});initial[root+i]=0; }
        for(int i=0;i<seeds;++i) graph[root].push_back({root+8+i%unique,20});
        for(int i=0;i<unique;++i) {
            graph[root].push_back({root+8+i,5+i%3});
            graph[root+8+i].push_back({root+8+unique+i,1});
            graph[root+8+i].push_back({split+g*2*unique+i,2});
            graph[split+g*2*unique+i].push_back({split+g*2*unique+unique+i,1});
        }
    }
    const auto oracle=dijkstra(graph,{{begin,0}});
    std::vector<void*> own,other; CUDA(cudaSetDevice(owner));L1Data d{};auto &s=d.source;
    d.seeds=seeds;d.unique=unique;d.prime=prime;
    s.side=make_side(begin,local,rounds,0,1,graph,initial,own);
    s.side.q.shmem_offset=sizeof(SLF)/sizeof(int);
    d.ml.q2=s.side.q;d.ml.min_read_gra=1;
#define A(field,type,n) s.field=allocate<type>(n);own.push_back(s.field)
    A(states,bc::state<>,1);A(donor,bc::donor_ledger,1);A(intents,bw::intent,1);
    A(packets,pc::packet,1);A(journals,bc::record,768);A(sender,rc::sender,1);A(tickets,rc::ticket,1);
    A(sent_archive,Receipt,max_packets);
#undef A
    d.raw=allocate<L1Raw>(rounds);own.push_back(d.raw);
    d.claim_counts=allocate<int>(rounds);own.push_back(d.claim_counts);
    const auto control=relay::encode(first_generation,relay::free);
    CUDA(cudaMemcpy(&s.packets[0].channel.control,&control,sizeof(control),cudaMemcpyHostToDevice));
    cudaFuncAttributes attr{};CUDA(cudaFuncGetAttributes(&attr,l1_source));CUDA(cudaDeviceSynchronize());
    CUDA(cudaSetDevice(peer));auto target=make_side(split,remote,rounds,0,1,graph,initial,other);
#define P(name,type,n) auto name=allocate<type>(n);other.push_back(name)
    P(channel,rc::channel,1);P(gates,Gates,1);P(receiver,rc::receiver,1);P(competed,int,remote);
    P(received_archive,Receipt,max_packets);P(hrows,int,local+1);
    int edges=0;CUDA(cudaMemcpy(&edges,s.side.rows+local,4,cudaMemcpyDeviceToHost));
    P(hcols,int,edges);P(hweights,int,edges);
#undef P
    s.peer_channel=channel;s.gates=gates;
    CUDA(cudaMemcpyPeer(hrows,peer,s.side.rows,owner,(local+1)*4));
    CUDA(cudaMemcpyPeer(hcols,peer,s.side.columns,owner,edges*4));CUDA(cudaMemcpyPeer(hweights,peer,s.side.weights,owner,edges*4));
    remote_bootstrap<<<1,32,target.q.get_shm_size()>>>(target,s,false);CUDA(cudaGetLastError());CUDA(cudaDeviceSynchronize());
    CUDA(cudaFuncGetAttributes(&attr,l1_helper));CUDA(cudaFuncGetAttributes(&attr,remote_receiver));
    cudaStream_t helper,rx,producer;CUDA(cudaStreamCreateWithFlags(&helper,cudaStreamNonBlocking));CUDA(cudaStreamCreateWithFlags(&rx,cudaStreamNonBlocking));
    l1_helper<<<2,32,0,helper>>>(d,{hrows,hcols,hweights,begin,local});CUDA(cudaGetLastError());
    remote_receiver<<<3,32,target.q.get_shm_size(),rx>>>(target,channel,gates,receiver,competed,received_archive);CUDA(cudaGetLastError());
    CUDA(cudaSetDevice(owner));CUDA(cudaStreamCreateWithFlags(&producer,cudaStreamNonBlocking));
    l1_source<<<2,32,sizeof(SLF)+s.side.q.get_shm_size(),producer>>>(d);CUDA(cudaGetLastError());CUDA(cudaStreamSynchronize(producer));CUDA(cudaStreamDestroy(producer));
    auto a=download(s.side);std::vector<L1Raw> raw(rounds);std::vector<Receipt> sent(max_packets),received(max_packets);
    CUDA(cudaMemcpy(raw.data(),d.raw,rounds*sizeof(L1Raw),cudaMemcpyDeviceToHost));
    CUDA(cudaMemcpy(sent.data(),s.sent_archive,max_packets*sizeof(Receipt),cudaMemcpyDeviceToHost));
    relay::word final_control;CUDA(cudaMemcpy(&final_control,&s.packets[0].channel.control,sizeof(final_control),cudaMemcpyDeviceToHost));
    CUDA(cudaSetDevice(peer));CUDA(cudaStreamSynchronize(rx));CUDA(cudaStreamSynchronize(helper));CUDA(cudaStreamDestroy(rx));CUDA(cudaStreamDestroy(helper));
    auto b=download(target);Gates g{};rc::channel final_channel{};
    CUDA(cudaMemcpy(&g,gates,sizeof(g),cudaMemcpyDeviceToHost));CUDA(cudaMemcpy(&final_channel,channel,sizeof(final_channel),cudaMemcpyDeviceToHost));
    CUDA(cudaMemcpy(received.data(),received_archive,max_packets*sizeof(Receipt),cudaMemcpyDeviceToHost));
    const std::string stem=directory+"/owner"+std::to_string(owner)+"_begin"+std::to_string(begin)+"_seeds"+std::to_string(seeds)+"_dup"+std::to_string(duplicate)+"_prime"+std::to_string(prime);
    std::ofstream audit(stem+".audit.txt");CHECK(audit.good());
    dump_side(audit,"owner",a,s.side,graph,initial,oracle);dump_side(audit,"remote",b,target,graph,initial,oracle);
    audit<<"TRANSPORT sent "<<g.sent<<" acked "<<g.acked<<" delay_checks "<<g.delay_checks<<'\n';
    audit<<"HELPER_CONTROL "<<final_control<<'\n';
    for(int slot=0;slot<2;++slot) audit<<"SLOT "<<slot<<" state "<<final_channel.state[slot]<<" generation "<<final_channel.generation[slot]<<" ack "<<final_channel.ack[slot]<<'\n';
    for(int e=0;e<std::max(0,std::min(max_packets,g.sent));++e) for(int role=0;role<2;++role) {
        const auto &r=role?received[e]:sent[e];
        audit<<"RECEIPT "<<role<<" epoch "<<r.identity.epoch<<" generation "<<r.identity.generation<<" start "<<r.identity.start<<" end "<<r.identity.end<<" count "<<r.identity.count<<" loan "<<(role?-1:r.loan/3)<<" acked "<<r.acked<<'\n';
        for(int i=0;i<std::max(0,std::min(32,r.identity.count));++i) audit<<"PAYLOAD "<<r.items[i].vertex<<' '<<r.items[i].distance<<'\n';
    }
    audit.close();CHECK(audit.good());
    std::ofstream journal(stem+".journal.txt");CHECK(journal.good());
    for(int r=0;r<rounds;++r) {
        const auto &t=raw[r];const auto &q=t.borrowed;
        journal<<"LOAN "<<r<<" count "<<t.journal_count<<" seeds "<<q.count<<" head "<<q.head<<" tail "<<q.tail<<" head_after "<<t.head_after
               <<" parents "<<t.parent_count<<" credit_before "<<t.credit_before<<" credit_held "<<t.credit_held<<" retired "<<t.credit_retired
               <<" empty_after "<<t.empty_after<<" credit_after "<<t.credit_after<<" outstanding_after "<<t.outstanding_after<<" released_after "<<t.released_after
               <<" rejected "<<t.rejected<<" remote_delays "<<t.remote_delays<<" local_delays "<<t.local_delays<<" claims "<<t.claims<<'\n';
        for(int i=0;i<std::max(0,std::min(32,q.count));++i) journal<<"SEED "<<q.seeds[i].vertex<<' '<<q.seeds[i].distance<<" id "<<q.ids[i]<<" priority "<<q.priorities[i]<<'\n';
        for(int i=0;i<std::max(0,std::min(768,t.journal_count));++i) journal<<"RECORD "<<t.journal[i].vertex<<' '<<t.journal[i].distance<<' '<<t.journal[i].certificate<<'\n';
    }
    journal.close();CHECK(journal.good());
    CHECK(std::equal(a.distance.begin(),a.distance.end(),oracle.begin()+begin));CHECK(std::equal(b.distance.begin(),b.distance.end(),oracle.begin()+split));
    CHECK(a.expected==a.seen && a.stats.bootstrapped==8*(prime+rounds) && a.stats.retired==a.stats.bootstrapped && a.stats.stop==1 && !a.overflow);
    int total=0;for(int k=0;k<4;++k) { CHECK(a.reserved[k]==a.published[k] && a.reserved[k]==a.consumed[k]);total+=a.reserved[k]; }
    CHECK(total==a.written && total==a.done && total==8*(prime+rounds)+rounds*unique);verify_snapshot(b);
    int packets=0,remote_records=0,local_windows=0,wrapped=0;
    for(int r=0;r<rounds;++r) {
        const auto &t=raw[r];const auto &q=t.borrowed;
        CHECK(q.count==seeds && q.head==(8*prime+(8+seeds)*r+8)%64 && q.tail==(q.head+seeds)%64 && t.head_after==q.tail);
        wrapped+=q.head+seeds>=64;
        CHECK(t.parent_count==8 && t.credit_before==8 && t.credit_held==8 && t.credit_retired==8 && !t.credit_after && !t.empty_after && !t.outstanding_after && t.released_after==1 && t.rejected==5 && t.claims==1 && t.local_delays>0);
        std::vector<bc::seed> roots;for(int i=0;i<seeds;++i) {
            CHECK(q.ids[i]==q.seeds[i].vertex+1 && q.priorities[i]==20 && q.seeds[i].distance==5+(i%unique)%3);
            roots.push_back(q.seeds[i]);
        }
        CHECK(t.journal_count>0 && t.journal_count<=768);
        validate_journal(graph,roots,{t.journal,t.journal+t.journal_count},begin,split);
        int rp=0;for(int first=0;first<t.journal_count;first+=32) {
            int count=0;for(int i=first;i<std::min(first+32,t.journal_count);++i)count+=t.journal[i].vertex>=split;
            rp+=count>0;remote_records+=count;
        }
        CHECK(t.remote_delays==rp);packets+=rp;local_windows+=t.local_delays;
    }
    CHECK(g.sent==packets && g.acked==packets && g.delay_checks==packets && remote_records==rounds*unique);
    for(int e=0;e<packets;++e) {
        const auto &t=sent[e];const auto &r=received[e];CHECK(rc::same(t.identity,r.identity) && t.identity.epoch==e+1 && t.acked && r.acked);
        CHECK(t.loan%3==0 && t.loan/3<rounds && t.identity.generation==first_generation+t.loan/3);
        const auto &j=raw[t.loan/3];std::vector<std::pair<int,int>> expected,actual;
        CHECK(t.identity.start>=0 && t.identity.end<=j.journal_count && t.identity.end-t.identity.start<=32);
        for(int i=t.identity.start;i<t.identity.end;++i)if(j.journal[i].vertex>=split)expected.push_back({j.journal[i].vertex,j.journal[i].distance});
        for(int i=0;i<t.identity.count;++i){CHECK(t.items[i].vertex==r.items[i].vertex && t.items[i].distance==r.items[i].distance);actual.push_back({t.items[i].vertex,t.items[i].distance});}
        CHECK(expected==actual);
    }
    CHECK(final_control==relay::encode(first_generation+rounds,relay::free));
    std::cout<<"BATCH_L1_DONOR_CASE owner="<<owner<<" begin="<<begin<<" seeds="<<seeds<<" duplicate="<<duplicate<<" prime="<<prime<<" rounds="<<rounds
             <<" loans="<<rounds<<" ancestors="<<a.stats.bootstrapped<<" exported="<<rounds*seeds<<" remote_records="<<remote_records<<" packets="<<packets
             <<" remote_delays="<<g.delay_checks<<" local_delays="<<local_windows<<" wrapped="<<wrapped<<" source_writes="<<a.written<<" remote_writes="<<b.written<<" PASS\n"<<std::flush;
    for(void *p:other)CUDA(cudaFree(p));CUDA(cudaSetDevice(owner));for(void *p:own)CUDA(cudaFree(p));
}
int main(int argc,char **argv) {
    try {
        CHECK(std::getenv("SLURM_JOB_ID")!=nullptr);CHECK(argc==2 || (argc==3 && std::string(argv[2])=="--quick"));
        const bool quick=argc==3;int devices=0;CUDA(cudaGetDeviceCount(&devices));CHECK(devices==2);
        for(int gpu=0;gpu<2;++gpu) {
            CUDA(cudaSetDevice(gpu));cudaDeviceProp prop{};CUDA(cudaGetDeviceProperties(&prop,gpu));CHECK(prop.major==8 && prop.minor==0);
            int access=0,atomics=0;CUDA(cudaDeviceCanAccessPeer(&access,gpu,1-gpu));CUDA(cudaDeviceGetP2PAttribute(&atomics,cudaDevP2PAttrNativeAtomicSupported,gpu,1-gpu));CHECK(access && atomics);CUDA(cudaDeviceEnablePeerAccess(1-gpu,0));
        }
        int cases=0;
        for(int owner:{0,1})for(int begin:quick?std::vector<int>{37}:std::vector<int>{0,37})
            for(int seeds:quick?std::vector<int>{7,32}:std::vector<int>{1,7,32})
                for(int duplicate:quick?std::vector<int>{1}:std::vector<int>{0,1})
                    for(int prime:quick?std::vector<int>{5}:std::vector<int>{0,5}) {
                        run_l1_case(owner,begin,seeds,duplicate,prime,quick?2:3,argv[1]);++cases;
                    }
        std::cout<<"BATCH_L1_DONOR_PASS cases="<<cases<<" real_ml_read=1 real_slf=1 actual_remote=1 no_worker_ack=1 no_solver=1 no_performance=1\n"<<std::flush;
        return 0;
    }catch(const std::exception &e){std::cerr<<"FAIL "<<e.what()<<'\n';return 1;}
}
