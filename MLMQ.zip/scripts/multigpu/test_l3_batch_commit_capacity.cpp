// Maximum 512 original seeds / 768 journal records, using the exact same
// commit header as GPU job 38603. CPU boundary test, not a GPU capacity claim.
#define L3_COMMIT_TEST_LIBRARY
#include "test_l3_batch_commit.cpp"

int main() {
    try {
        for (int owner_end : {512, 768}) {
            Graph graph(768);
            for (int v = 1; v < 768; ++v) graph[0].push_back({v, v});
            std::vector<bc::seed> roots;
            World world(graph);
            for (int v = 0; v < 512; ++v) { roots.push_back({v, v}); world.offer(v, v); }
            auto journal = helper(graph, roots, 0, owner_end, 1);
            CHECK(journal.size() == 768);
            bc::state<> commit; bc::initialize(commit);
            bc::donor_ledger donor{3, 0, false};
            CHECK(!bc::reserve(commit, 1, donor, roots.data(), 513, 0, owner_end, 768));
            CHECK(bc::reserve(commit, 1, donor, roots.data(), 512, 0, owner_end, 768));
            world.local.clear(); // export only AFTER loan credit was reserved
            CHECK(!bc::accept_journal(commit, 1, journal.data(), 769));
            CHECK(donor.outstanding == 1 && commit.stage == bc::phase::borrowed);
            CHECK(bc::accept_journal(commit, 1, journal.data(), 768));
            unsigned attempts = 0;
            while (bc::step(commit, 1, world) != bc::result::complete) {
                CHECK(bc::retire_if_idle(donor, true) == 0);
                CHECK(++attempts < 20000);
                // Small sinks guarantee partial publication and repeated retry.
                if (attempts % 3 == 0) world.work();
            }
            CHECK(world.blocks > 0);
            CHECK(commit.local_published == unsigned(owner_end - 1));
            CHECK(commit.remote_published == unsigned(768 - owner_end));
            CHECK(commit.wins == unsigned(owner_end - 512));
            CHECK(bc::retire_if_idle(donor, true) == 3);
            world.completed[0] = 0; // complete-row certificate, all effects durable
            CHECK(world.invariant());
            while (world.work()) CHECK(world.invariant());
            CHECK(world.distance == dijkstra(graph, {{0, 0}}));
        }
        std::cout << "BATCH_COMMIT_CAPACITY_CPU_PASS cases=2 seeds=512 records=768 overflow_rejected=1\n";
        return 0;
    } catch (const std::exception &e) { std::cerr << "FAIL " << e.what() << '\n'; return 1; }
}
