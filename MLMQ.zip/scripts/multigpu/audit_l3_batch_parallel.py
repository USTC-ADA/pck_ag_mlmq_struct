#!/usr/bin/env python3
"""Independently recompute the new parallel-owner fixture journals on CPU."""
import argparse
import hashlib
import json
from pathlib import Path
import tarfile
from run_l3_batch_runtime import verify_tree
from run_l3_upgrade_stage2 import sha256, write_json
from run_l3_compact_screen import sanitizer_passed
from audit_l3_batch_peer_commit import audit_case as audit_peer, require
from audit_l3_batch_remote_commit import audit_case as audit_remote
from audit_l3_batch_l1_donor import audit_case as audit_l1
from run_l3_batch_peer_commit import parse_cases as parse_peer
from run_l3_batch_remote_commit import parse_cases as parse_remote
from run_l3_batch_l1_donor import parse_cases as parse_l1
from run_l3_batch_parallel import PACKED_PASS


def audit(run):
    manifest = json.loads((run / 'manifest.json').read_text())
    build = Path(manifest['build']).resolve(strict=True)
    bm = verify_tree(build)
    require(bm == manifest['snapshot'], 'changed build manifest')
    with tarfile.open(build / 'source.tgz') as archive:
        members = [m for m in archive.getmembers() if m.isfile()]
        expected = {k[7:]: v for k, v in bm['hashes'].items() if k.startswith('source/')}
        require(len(members) == len(expected) and {m.name for m in members} == set(expected), 'archive members')
        for member in members:
            require(hashlib.sha256(archive.extractfile(member).read()).hexdigest() == expected[member.name], 'archive content')
    status = json.loads((run / 'status.json').read_text())
    summary = json.loads((run / 'summary.json').read_text())
    require(status['complete'] and summary['valid'] and status['results'] == summary['results'], 'incomplete run')
    results = status['results']
    first = 'packed' if bm.get('packed_compact') else 'differential'
    require(set(results) == {k + '_' + t for k in (first, 'peer', 'remote', 'l1')
                             for t in ('normal', 'memcheck', 'racecheck', 'synccheck')}, 'missing stage')
    totals = {}
    for label, result in results.items():
        kind, stage = label.split('_')
        raw = (run / (label + '.log')).read_text()
        require(result['rc'] == 0 and result['state'] == 'passed' and
                sanitizer_passed(raw, None if stage == 'normal' else stage), 'failed stage')
        if kind == 'differential':
            require(raw.splitlines().count('BATCH_PARALLEL_DIFFERENTIAL_PASS cases=384 valid=32 rejected=352 sticky_competitor=1 hash_collision=1') == 1,
                    'differential count')
            totals[label] = {'cases': 384, 'valid_journals': 32, 'rejected_journals': 352}
            continue
        if kind == 'packed':
            require(raw.splitlines().count(PACKED_PASS) == 1, 'packed index count')
            totals[label] = {'devices': 2, 'decoded_positions': 1179648, 'workspace_bytes': 15444}
            continue
        parse, check = {'peer': (parse_peer, audit_peer), 'remote': (parse_remote, audit_remote), 'l1': (parse_l1, audit_l1)}[kind]
        cases = parse(raw, stage != 'normal')
        require(cases == result['cases'], 'changed case summaries')
        directory = run / (label + '_journals')
        names, rows = set(), []
        for case in cases:
            stem = f"owner{case['owner']}_begin{case['begin']}"
            if kind == 'peer':
                stem += f"_group{case['group']}"
            elif kind == 'remote':
                stem += f"_fan{case['fan']}_leaves{case['leaves']}"
            else:
                stem += f"_seeds{case['seeds']}_dup{case['duplicate']}_prime{case['prime']}"
            paths = [directory / (stem + suffix) for suffix in ('.audit.txt', '.journal.txt')]
            for p in paths:
                require(sha256(p) == result['raw_artifacts'][p.name], 'changed raw artifact')
                names.add(p.name)
            rows.append(check(*paths, case))
        require(names == set(result['raw_artifacts']) == {p.name for p in directory.iterdir()}, 'wrong artifacts')
        totals[label] = {'cases': len(cases), **{k: sum(r[k] for r in rows) for k in rows[0]}}
    return {'valid': True, 'job_id': manifest['allocation']['job_id'], 'stages': totals,
            'gpu_rerun': False, 'performance_evidence': False,
            'auditors': {p.name: sha256(p) for p in Path(__file__).parent.glob('audit_l3_batch_*.py')},
            'run_hashes': {str(p.relative_to(run)): sha256(p) for p in sorted(run.rglob('*')) if p.is_file()}}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    if args.out.exists():
        parser.error('output exists')
    result = audit(args.run.resolve(strict=True))
    write_json(args.out, result)
    print('BATCH_PARALLEL_OFFLINE_AUDIT_PASS', result['job_id'])


if __name__ == '__main__':
    main()
