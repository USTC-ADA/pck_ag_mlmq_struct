#!/usr/bin/env python3
"""Real delta-queue commit/consume fixture; not cross-GPU relay or solver timing."""
import argparse
from pathlib import Path
import subprocess

from run_l3_compact_screen import sanitizer_passed
from run_l3_upgrade_stage2 import ROOT, clean_environment, sha256, slurm_preflight, write_json


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('binary', 'sanitizer', 'out', 'snapshot'):
        parser.add_argument('--' + name, required=True, type=Path)
    parser.add_argument('--boundary-only', action='store_true', help='only exact-capacity/expected-trap checks; no normal or sanitizer claim')
    args = parser.parse_args()
    if args.out.exists() or args.out.is_symlink():
        parser.error('output exists')
    args.out.mkdir(parents=True)
    out = args.out.resolve()
    allocation = slurm_preflight(out)
    binary = args.binary.resolve(strict=True)
    files = [binary, args.snapshot.resolve(strict=True)]
    files += [ROOT / name for name in (
        'SSSP/l3/l3_batch_commit.h', 'SSSP/l3/l3_batch_commit_warp.cuh',
        'core/cu_delta_queue/cu_delta_queue.cuh', 'core/include/warp_primitive.h',
        'core/include/common.h', 'core/include/GPU_setup.h', 'core/include/adaptive.h', 'core/include/graph_info.h',
        'scripts/multigpu/test_l3_batch_commit.cpp', 'scripts/multigpu/test_l3_batch_commit_l2.cu',
        'scripts/multigpu/run_l3_batch_commit_l2.py', 'scripts/multigpu/run_l3_compact_screen.py',
        'scripts/multigpu/run_l3_upgrade_stage2.py', 'scripts/multigpu/run_l3_30h.py', 'scripts/multigpu/run_usa_road_matrix.py')]
    hashes = {str(path): sha256(path) for path in files}
    write_json(out / 'manifest.json', {'allocation': allocation, 'hashes': hashes,
        'evidence_class': 'exploratory_real_dq_owner_fixture_no_peer_no_solver_no_performance'})
    status = {}
    stages = (('smoke', None, True), ('normal', None, False),
                              ('memcheck', 'memcheck', True), ('racecheck', 'racecheck', True),
                              ('synccheck', 'synccheck', True),
                              ('overflow0', None, False), ('overflow1', None, False))
    if args.boundary_only:
        stages = stages[-2:]
    for name, tool, quick in stages:
        overflow = name.startswith('overflow')
        command = [str(binary)] + (['--' + name] if overflow else ['--quick'] if quick else [])
        if tool:
            command = [str(args.sanitizer.resolve(strict=True)), '--tool', tool,
                       '--error-exitcode', '9'] + command
        print('RUN', name, flush=True)
        with (out / (name + '.log')).open('w') as log:
            result = subprocess.run(command, cwd=ROOT, env=clean_environment(),
                                    stdout=log, stderr=subprocess.STDOUT, timeout=600)
        raw = (out / (name + '.log')).read_text()
        status[name] = {'rc': result.returncode, 'sanitizer': tool, 'quick': quick}
        write_json(out / 'status.json', {'complete': False, 'stage': name, 'results': status})
        print('RC', name, result.returncode, flush=True)
        marker = 'DQ_CAPACITY_EXPECTED_TRAP_PASS ' if overflow else 'BATCH_COMMIT_L2_PASS '
        if result.returncode or not sanitizer_passed(raw, tool) or marker not in raw:
            raise RuntimeError('retained failed stage ' + name)
        if not overflow:
            for device in (0, 1):
                if f'BATCH_COMMIT_L2_CASE gpu={device} ' not in raw:
                    raise RuntimeError('missing allocated device fixture')
        elif f'DQ_CAPACITY_EXACT_PASS gpu={name[-1]} ' not in raw or f'DQ_CAPACITY_EXPECTED_TRAP_PASS gpu={name[-1]} ' not in raw:
            raise RuntimeError('missing capacity boundary on selected GPU')
        apps = subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid', '--format=csv,noheader'], text=True)
        if apps.strip():
            raise RuntimeError('GPU processes remain; no cleanup attempted')
    if any(sha256(Path(path)) != expected for path, expected in hashes.items()):
        raise RuntimeError('binary/source changed during run')
    write_json(out / 'summary.json', {'valid': True, 'results': status, 'devices_tested': [0, 1],
        'boundary_only': args.boundary_only,
        'normal_cases': 0 if args.boundary_only else 16, 'normal_generations': 0 if args.boundary_only else 512,
        'quick_cases_each_sanitizer': 0 if args.boundary_only else 4,
        'quick_generations_each_sanitizer': 0 if args.boundary_only else 16, 'actual_dq': True,
        'consumer_drain_receipt_tested': not args.boundary_only, 'capacity_exact_and_expected_trap_devices': [0, 1],
        'peer_relay': False, 'solver_integration': False, 'performance_evidence': False})
    write_json(out / 'status.json', {'complete': True, 'stage': 'complete', 'results': status})
    print('BATCH_COMMIT_L2_PIPELINE_PASS actual_dq=1 no_peer_no_solver_no_performance=1', flush=True)


if __name__ == '__main__':
    main()
