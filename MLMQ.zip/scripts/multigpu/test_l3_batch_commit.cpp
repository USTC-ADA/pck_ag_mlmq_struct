// CPU reference/fault scheduler for the isolated responsibility contract.
// Build: g++ -std=c++14 -O2 -Wall -Wextra -Werror this_file.cpp -o test_commit
#include "../../SSSP/l3/l3_batch_commit.h"
#include <algorithm>
#include <deque>
#include <iostream>
#include <memory>
#include <queue>
#include <random>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

namespace bc = l3_batch_commit;
using Graph = std::vector<std::vector<std::pair<int, int>>>;
#define CHECK(x) do { if (!(x)) throw std::runtime_error(std::string(#x) + " line=" + std::to_string(__LINE__)); } while (0)
static int add(int a, int b) { return a < INT_MAX - b ? a + b : INT_MAX; }

static std::vector<int> dijkstra(const Graph &g, const std::vector<bc::seed> &roots,
                                int begin = 0, int end = INT_MAX) {
    std::vector<int> d(g.size(), INT_MAX);
    using Pair = std::pair<int, int>;
    std::priority_queue<Pair, std::vector<Pair>, std::greater<Pair>> q;
    for (auto r : roots) if (r.distance < d[r.vertex]) { d[r.vertex] = r.distance; q.push({r.distance, r.vertex}); }
    while (!q.empty()) {
        auto entry = q.top(); q.pop();
        const int v = entry.second;
        if (entry.first != d[v] || v < begin || v >= end) continue;
        for (auto edge : g[v]) {
            int candidate = add(entry.first, edge.second);
            if (candidate < d[edge.first]) { d[edge.first] = candidate; q.push({candidate, edge.first}); }
        }
    }
    return d;
}

static void validate_journal(const Graph &g, const std::vector<bc::seed> &roots,
                             const std::vector<bc::record> &journal, int begin, int end) {
    // Independent priority-queue oracle, not the bounded FIFO producer below.
    const auto reachable = dijkstra(g, roots, begin, end);
    std::vector<int> label(g.size(), INT_MAX);
    for (auto r : journal) {
        CHECK(label[r.vertex] == INT_MAX);
        CHECK(reachable[r.vertex] != INT_MAX && reachable[r.vertex] <= r.distance);
        CHECK(r.distance <= r.certificate);
        CHECK((r.vertex >= begin && r.vertex < end) || r.certificate == INT_MAX);
        label[r.vertex] = r.distance;
    }
    for (auto r : roots) CHECK(label[r.vertex] <= r.distance);
    for (auto r : journal) if (r.certificate != INT_MAX)
        for (auto e : g[r.vertex]) CHECK(label[e.first] <= add(r.certificate, e.second));
}

static std::vector<bc::record> helper(const Graph &g, const std::vector<bc::seed> &roots,
                                     int begin, int end, int budget) {
    std::vector<int> d(g.size(), INT_MAX), cert(g.size(), INT_MAX);
    std::deque<int> active;
    for (auto r : roots) if (r.distance < d[r.vertex]) { d[r.vertex] = r.distance; active.push_back(r.vertex); }
    int expanded = 0;
    while (!active.empty() && expanded < budget) {
        const int v = active.front(); active.pop_front();
        const int snapshot = d[v];
        if (snapshot >= cert[v]) continue;
        for (auto e : g[v]) if (add(snapshot, e.second) < d[e.first]) {
            d[e.first] = add(snapshot, e.second);
            if (e.first >= begin && e.first < end) active.push_back(e.first);
        }
        cert[v] = snapshot;
        ++expanded;
    }
    std::vector<bc::record> journal;
    for (unsigned v = 0; v < g.size(); ++v) if (d[v] != INT_MAX) journal.push_back({int(v), d[v], cert[v]});
    validate_journal(g, roots, journal, begin, end);
    return journal;
}

struct Loan {
    bc::state<64> commit;
    std::vector<bc::record> journal;
    bool witnessed = false;
    Loan() { bc::initialize(commit); }
};

struct World {
    Graph graph;
    std::vector<int> distance, completed;
    std::deque<bc::seed> local, remote, delayed;
    std::vector<std::unique_ptr<Loan>> loans;
    bc::donor_ledger donor{7, 0, false}; // intentionally unlike the seed count
    unsigned local_limit = 2, remote_limit = 1;
    bool refuse_local = false, refuse_remote = false;
    unsigned calls_min = 0, blocks = 0, accepted_local = 0, accepted_remote = 0;
    explicit World(Graph g) : graph(std::move(g)), distance(graph.size(), INT_MAX), completed(graph.size(), INT_MAX) {}
    int local_min(int v, int d) { ++calls_min; int old = distance[v]; distance[v] = std::min(old, d); return old; }
    bool publish_local(int v, int d) {
        CHECK(distance[v] <= d);
        if (refuse_local || local.size() >= local_limit) { ++blocks; return false; }
        local.push_back({v, d}); // this token owns independent queue credit
        ++accepted_local;
        return true;
    }
    bool publish_remote(int v, int d) {
        if (refuse_remote || remote.size() >= remote_limit) { ++blocks; return false; }
        remote.push_back({v, d}); // credited inbox, not a peer distance write
        ++accepted_remote;
        return true;
    }
    void offer(int v, int d, bool defer = false) {
        if (d < distance[v]) {
            distance[v] = d;
            (defer ? delayed : local).push_back({v, d});
        }
    }
    bool work() {
        if (!local.empty()) {
            auto task = local.front(); local.pop_front();
            const int d = distance[task.vertex];
            CHECK(d <= task.distance);
            if (d < completed[task.vertex]) {
                for (auto edge : graph[task.vertex]) offer(edge.first, add(d, edge.second));
                completed[task.vertex] = d; // only AFTER all row outputs accepted
            }
            return true;
        }
        if (!remote.empty()) {
            auto task = remote.front(); remote.pop_front();
            offer(task.vertex, task.distance, true);
            return true;
        }
        if (!delayed.empty()) { local.push_back(delayed.front()); delayed.pop_front(); return true; }
        return false;
    }
#ifndef L3_COMMIT_TEST_LIBRARY
    Loan &borrow(std::vector<bc::seed> roots, int begin, int end, int budget, bool accept = true) {
        auto ptr = std::unique_ptr<Loan>(new Loan);
        auto &loan = *ptr;
        CHECK(bc::reserve(loan.commit, 1, donor, roots.data(), int(roots.size()), begin, end, int(graph.size())));
        // Model the export of existing tasks, after reserve protected credit.
        for (auto root : roots) {
            CHECK(distance[root.vertex] == root.distance);
            auto it = std::find_if(local.begin(), local.end(), [&](bc::seed task) { return task.vertex == root.vertex; });
            CHECK(it != local.end());
            local.erase(it);
        }
        loan.journal = helper(graph, roots, begin, end, budget);
        // Modifying the caller's buffer must not change immutable exported roots.
        roots[0].distance = INT_MAX;
        if (accept) CHECK(bc::accept_journal(loan.commit, 1, loan.journal.data(), int(loan.journal.size())));
        loans.push_back(std::move(ptr));
        return loan;
    }
    bc::result step(Loan &loan) {
        const auto status = bc::step(loan.commit, loan.commit.generation, *this);
        if (status == bc::result::complete && !loan.witnessed) {
            // Ghost completion evidence only: not a full-graph implementation
            // array and never used to decide which commit records to publish.
            if (loan.commit.journal)
                for (auto r : loan.journal) completed[r.vertex] = std::min(completed[r.vertex], r.certificate);
            loan.witnessed = true;
        }
        return status;
    }
#endif
    bool invariant() const {
        unsigned outstanding = 0;
        for (const auto &loan : loans) outstanding += loan->commit.stage != bc::phase::finished;
        if (outstanding != donor.outstanding || (donor.released && outstanding)) return false;
        for (unsigned v = 0; v < graph.size(); ++v) if (distance[v] < completed[v]) {
            bool owned = false;
            for (const auto *q : {&local, &remote, &delayed})
                for (auto task : *q) owned |= task.vertex == int(v) && task.distance <= distance[v];
            for (const auto &loan : loans) {
                const auto &s = loan->commit;
                if (s.stage == bc::phase::finished) continue;
                for (int i = 0; i < s.seed_count; ++i)
                    owned |= s.roots[i].vertex == int(v) && s.roots[i].distance <= distance[v];
                if (s.journal) for (int i = 0; i < s.count; ++i)
                    owned |= s.journal[i].vertex == int(v) && s.required[i] <= distance[v];
            }
            if (!owned) return false;
        }
        return true;
    }
#ifndef L3_COMMIT_TEST_LIBRARY
    void finish() {
        refuse_local = refuse_remote = false;
        for (unsigned iteration = 0; iteration < 100000; ++iteration) {
            for (auto &loan : loans) { step(*loan); CHECK(invariant()); }
            const bool did_work = work();
            CHECK(invariant());
            if (!donor.outstanding && !did_work) {
                // L1 empty does not mean all work globally done; queues own
                // their own credits. Here they happen to be drained as well.
                CHECK(bc::retire_if_idle(donor, true) == 7);
                CHECK(bc::retire_if_idle(donor, true) == 0);
                return;
            }
        }
        throw std::runtime_error("scheduler failed to drain");
    }
#endif
};

#ifndef L3_COMMIT_TEST_LIBRARY
static void advance(World &w, Loan &loan, bc::phase phase) {
    for (int i = 0; i < 1000 && loan.commit.stage != phase; ++i) { w.step(loan); CHECK(w.invariant()); }
    CHECK(loan.commit.stage == phase);
}

static void deterministic_tests() {
    // Distance installation followed by full queue, retry, and a lower update
    // whose producer has not yet published its activation into the queue.
    for (bool competitor : {false, true}) {
        Graph g(4); g[0] = {{1, 10}, {3, 0}}; g[1] = {{2, 1}}; g[3] = {{1, 1}};
        World w(g); w.offer(0, 0);
        auto &loan = w.borrow({{0, 0}}, 0, 4, 1);
        advance(w, loan, bc::phase::local);
        CHECK(w.distance[1] == 10 && loan.commit.wins == 2);
        // Reapplying a journal would see ZERO winners: an unsafe implementation
        // that erased the sticky state on retry would drop vertex 1's work.
        for (auto r : loan.journal) CHECK(w.local_min(r.vertex, r.distance) == r.distance);
        if (competitor) w.offer(1, 1, true); // valid path 0->3->1; held producer responsibility
        w.refuse_local = true;
        const auto min_calls = w.calls_min;
        for (int k = 0; k < 20; ++k) { w.step(loan); CHECK(w.invariant()); CHECK(bc::retire_if_idle(w.donor, true) == 0); }
        CHECK(w.blocks > 0 && w.calls_min == min_calls && loan.commit.required[1] == 10);
        w.finish();
        CHECK(w.distance == dijkstra(g, {{0, 0}}));
    }
    // Original seed is NOT an atomic winner, but still owes work. Duplicates
    // share one journal obligation, and 3 exported tasks still hold 7 ancestors.
    {
        Graph g(3); g[0] = {{1, 1}}; g[1] = {{2, 1}};
        World w(g); w.offer(0, 0); w.local.push_back({0, 0}); w.local.push_back({0, 0});
        auto &loan = w.borrow({{0, 0}, {0, 0}, {0, 0}}, 0, 3, 0);
        CHECK(w.donor.outstanding == 1 && w.donor.ancestor_credits == 7);
        CHECK(bc::retire_if_idle(w.donor, true) == 0);
        w.finish();
        CHECK(loan.commit.wins == 0 && loan.commit.local_published == 1);
        CHECK(w.distance == dijkstra(g, {{0, 0}}));
    }
    // A fully certified root need not absorb a subsequent shorter update that
    // another live task already owns. Test that external task before/after all
    // 16 possible cooperative positions, including after commit completion.
    for (int position = 0; position < 16; ++position) {
        Graph g(3); g[0] = {{1, 2}}; g[2] = {{0, 9}, {1, 11}};
        World w(g); w.offer(0, 9);
        auto &loan = w.borrow({{0, 9}}, 0, 2, 1);
        for (int k = 0; k < position; ++k) { w.step(loan); CHECK(w.invariant()); }
        // An additional source at distance 1 models an independently owned
        // relaxation. The oracle explicitly includes that source; no cheating.
        w.offer(0, 1, true);
        w.finish();
        CHECK(w.distance == dijkstra(g, {{0, 9}, {0, 1}}));
    }
    // Partial remote publication, repeated rejection, then completion. A queued
    // remote output remains independently credited when donor credit retires.
    {
        Graph g(4); g[0] = {{2, 1}, {3, 2}}; g[2] = {{1, 1}};
        World w(g); w.offer(0, 0);
        auto &loan = w.borrow({{0, 0}}, 0, 2, 1);
        advance(w, loan, bc::phase::remote);
        for (int k = 0; k < 10; ++k) w.step(loan);
        CHECK(loan.commit.remote_published == 1 && w.remote.size() == 1 && w.blocks > 0);
        CHECK(bc::retire_if_idle(w.donor, true) == 0);
        w.remote_limit = 2;
        advance(w, loan, bc::phase::finished);
        CHECK(w.invariant() && w.remote.size() == 2 && w.donor.outstanding == 0);
        CHECK(bc::retire_if_idle(w.donor, false) == 0);
        CHECK(bc::retire_if_idle(w.donor, true) == 7);
        while (w.work()) CHECK(w.invariant());
        CHECK(w.distance == dijkstra(g, {{0, 0}}));
        CHECK(w.accepted_remote == 2);
        CHECK(w.step(loan) == bc::result::complete && w.donor.outstanding == 0);
    }
    // Invalid returned journal cannot drop the loan. Fallback restores original
    // tasks; reusing the slot changes generation and rejects all old messages.
    {
        Graph g(2); g[0] = {{1, 0}};
        World w(g); w.offer(0, 0);
        auto &loan = w.borrow({{0, 0}}, 0, 2, 0, false);
        bc::record missing{1, 0, INT_MAX};
        CHECK(!bc::accept_journal(loan.commit, 1, &missing, 1));
        CHECK(w.step(loan) == bc::result::blocked && w.donor.outstanding == 1);
        CHECK(!bc::recycle(loan.commit, 1));
        CHECK(bc::start_fallback(loan.commit, 1));
        w.refuse_local = true;
        CHECK(w.step(loan) == bc::result::blocked);
        w.finish();
        CHECK(w.distance == dijkstra(g, {{0, 0}}));
        CHECK(bc::recycle(loan.commit, 1));
        CHECK(bc::step(loan.commit, 1, w) == bc::result::stale);
        CHECK(!bc::start_fallback(loan.commit, 1));
        CHECK(!bc::accept_journal(loan.commit, 1, loan.journal.data(), 1));
        bc::donor_ledger next{3, 0, false}; bc::seed root{0, 0};
        CHECK(!bc::reserve(loan.commit, 1, next, &root, 1, 0, 2, 2));
        CHECK(bc::reserve(loan.commit, 2, next, &root, 1, 0, 2, 2));
        CHECK(!bc::reserve(loan.commit, 2, next, &root, 1, 0, 2, 2));
        CHECK(bc::accept_journal(loan.commit, 2, loan.journal.data(), 1));
        while (bc::step(loan.commit, 2, w) != bc::result::complete) {}
        CHECK(next.outstanding == 0);
        loan.commit.generation = UINT64_MAX;
        CHECK(!bc::recycle(loan.commit, UINT64_MAX));
    }
    // A bare preinstalled distance without an active/completed responsibility
    // is INVALID input, not a case winner-only filtering can safely accept.
    {
        Graph g(3); g[0] = {{1, 1}}; g[1] = {{2, 1}};
        World w(g); w.offer(0, 0);
        w.borrow({{0, 0}}, 0, 3, 1);
        w.distance[1] = 1; // deliberately violate the backend precondition
        CHECK(!w.invariant());
    }
    // Malformed metadata is rejected without releasing or advancing the loan.
    {
        bc::state<4> s; bc::initialize(s); bc::donor_ledger d{7, 0, false};
        bc::seed seed{0, 0};
        CHECK(!bc::reserve(s, 0, d, &seed, 1, 0, 2, 3));
        CHECK(bc::reserve(s, 1, d, &seed, 1, 0, 2, 3));
        bc::record valid{0, 0, INT_MAX};
        bc::record duplicates[]{{0, 0, INT_MAX}, {0, 0, INT_MAX}};
        bc::record remote_cert[]{{0, 0, INT_MAX}, {2, 1, 1}};
        bc::record negative{0, -1, 0};
        CHECK(!bc::accept_journal(s, 1, duplicates, 2));
        CHECK(!bc::accept_journal(s, 1, remote_cert, 2));
        CHECK(!bc::accept_journal(s, 1, &negative, 1));
        CHECK(!bc::accept_journal(s, 2, &valid, 1));
        CHECK(d.outstanding == 1 && s.stage == bc::phase::borrowed);
        CHECK(bc::accept_journal(s, 1, &valid, 1));
    }
}

static unsigned randomized_tests(unsigned rounds) {
    unsigned total_blocks = 0;
    for (unsigned trial = 0; trial < rounds; ++trial) {
        std::mt19937 rng(0x12340000u + trial);
        const int vertices = 12 + rng() % 20, source = vertices - 1, cut = vertices / 2;
        Graph g(vertices);
        for (int v = 0; v < source; ++v) g[source].push_back({v, int(10 + rng() % 100)});
        for (int v = 0; v < source; ++v) {
            for (int e = 0; e < 5; ++e) g[v].push_back({int(rng() % vertices), int(rng() % 20)});
            g[v].push_back({(v + 1) % source, 0}); // zero-weight cycles, repeated improvements
            g[v].push_back({v, INT_MAX}); // saturating overflow path
        }
        World w(g);
        w.distance[source] = w.completed[source] = 0;
        for (auto edge : g[source]) w.offer(edge.first, edge.second);
        for (int owner = 0; owner < 2; ++owner) {
            const int begin = owner ? cut : 0, end = owner ? source : cut;
            for (int loan_id = 0; loan_id < 2; ++loan_id) {
                std::vector<bc::seed> roots;
                for (int k = 0; k < 3; ++k) {
                    const int v = begin + rng() % (end - begin);
                    // Legitimate duplicate/overlapping tasks already in L1.
                    w.local.push_back({v, w.distance[v]});
                    roots.push_back({v, w.distance[v]});
                }
                w.borrow(roots, begin, owner ? vertices : cut, rng() % 25);
            }
        }
        CHECK(w.invariant());
        for (int tick = 0; tick < 1500; ++tick) {
            w.refuse_local = rng() % 5 == 0;
            w.refuse_remote = rng() % 4 == 0;
            if (rng() % 3 == 0) w.work();
            else w.step(*w.loans[rng() % w.loans.size()]);
            CHECK(w.invariant());
            if (w.donor.outstanding) CHECK(bc::retire_if_idle(w.donor, true) == 0);
        }
        w.finish();
        CHECK(w.distance == dijkstra(g, {{source, 0}}));
        total_blocks += w.blocks;
    }
    CHECK(total_blocks > rounds);
    return total_blocks;
}

int main(int argc, char **argv) {
    try {
        const unsigned rounds = argc == 2 ? unsigned(std::stoul(argv[1])) : 2000;
        CHECK(rounds > 0);
        deterministic_tests();
        const auto blocks = randomized_tests(rounds);
        std::cout << "BATCH_COMMIT_CPU_PASS deterministic_schedules=23 randomized=" << rounds
                  << " blocked_retries=" << blocks << " state_bytes=" << sizeof(bc::state<>)
                  << " not_solver_integration=1 not_performance=1\n";
        return 0;
    } catch (const std::exception &e) { std::cerr << "FAIL " << e.what() << '\n'; return 1; }
}
#endif
