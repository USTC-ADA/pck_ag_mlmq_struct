#!/usr/bin/env python3
"""Small bidirectional production-CSR fixtures with independent int Dijkstra."""
import argparse
import heapq
import json
from pathlib import Path
import struct


def make(out):
    out.mkdir(parents=True, exist_ok=False)
    n = 4096
    metadata = {}
    for name in ('ring', 'branch'):
        graph = []
        for u in range(n):
            edges = {(u+1) % n: 1, (u-1) % n: 2, (u+17) % n: 5}
            if name == 'branch':
                for step in (5, 31, 67, 129):
                    edges[(u+step) % n] = 3 + step//7
                    edges[(u-step) % n] = 4 + step//7
            if u % 32 == 0:
                edges[(u+n//2) % n] = 21
            graph.append(sorted(edges.items()))
        ends, columns, weights = [], [], []
        for row in graph:
            columns.extend(v for v, _ in row)
            weights.extend(w for _, w in row)
            ends.append(len(columns))
        m = len(columns)
        with (out / (name + '.gr')).open('wb') as stream:
            stream.write(struct.pack('<4Q', 1, 4, n, m))
            stream.write(struct.pack(f'<{n}Q', *ends))
            stream.write(struct.pack(f'<{m}I', *columns))
            if m % 2:
                stream.write(bytes(4))
            stream.write(struct.pack(f'<{m}i', *weights))
        metadata[name] = {'vertices': n, 'edges': m, 'sources': {}}
        for source in (0, 2055):
            distances = [2**31-1] * n
            distances[source] = 0
            heap = [(0, source)]
            while heap:
                distance, u = heapq.heappop(heap)
                if distance != distances[u]:
                    continue
                for v, weight in graph[u]:
                    candidate = distance + weight
                    if candidate < distances[v]:
                        distances[v] = candidate
                        heapq.heappush(heap, (candidate, v))
            assert all(d < 2**31-1 for d in distances)
            (out / f'{name}_s{source}.oracle').write_bytes(struct.pack(f'<{n}i', *distances))
            metadata[name]['sources'][source] = {'maximum_distance': max(distances)}
    (out / 'graphs.json').write_text(json.dumps(metadata, indent=2) + '\n')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('out', type=Path)
    make(parser.parse_args().out)
