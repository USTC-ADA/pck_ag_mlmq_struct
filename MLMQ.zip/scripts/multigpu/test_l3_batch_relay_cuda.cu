// Protocol/cost screen only. NOT SSSP solve time or a scaling result.
#include "../../SSSP/l3/l3_batch_relay.cuh"
#include <algorithm>
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <vector>

namespace relay = l3_batch_relay;
constexpr int slots = 32;
constexpr int vertices = 65536;
constexpr unsigned long long timeout_cycles = 10000000000ull;

static void check_cuda(cudaError_t result, const char *operation) {
    if (result == cudaSuccess) return;
    std::fprintf(stderr, "RELAY_CUDA_FAIL %s: %s\n", operation, cudaGetErrorString(result));
    std::exit(2);
}
__host__ __device__ static int seed_vertex(int owner, int round, int index) {
    return (owner * 1543 + round * 101 + index * 17) % vertices;
}
__host__ __device__ static int seed_distance(int owner, int round, int index) {
    return (owner + round + index) % 31 == 0 ? INT_MAX - 1 : 100 + round + index;
}
__host__ __device__ static unsigned long long fingerprint(relay::item value) {
    return (static_cast<unsigned long long>(unsigned(value.vertex)) << 32) ^ unsigned(value.distance);
}
__device__ static relay::word warp_load(relay::slot *slot, int lane) {
    relay::word token = 0;
    if (!lane) token = relay::load(slot);
    return __shfl_sync(relay::mask, token, 0);
}
__device__ static bool claim(relay::slot *slot, relay::word token, relay::phase next, int lane) {
    int taken = 0;
    if (!lane) taken = relay::move(slot, token, next);
    return __shfl_sync(relay::mask, taken, 0) != 0;
}

// Exactly one producer/committer per slot; helpers can race to claim it.
__global__ static void owner_kernel(relay::slot *channel, relay::graph_view graph,
    int seeds, int rounds, int mode, int scenario,
    unsigned long long *checksums, int *error) {
    const int lane = threadIdx.x % 32;
    const int owner = (blockIdx.x * blockDim.x + threadIdx.x) / 32;
    if (owner >= slots) return;
    auto *slot = channel + owner;
    unsigned long long checksum = 0;
    for (int round = 0; round < rounds; ++round) {
        const relay::word empty = relay::encode(round, relay::free);
        if (mode < 3 && !claim(slot, empty, relay::filling, lane)) {
            if (!lane) atomicCAS(error, 0, 1);
            return;
        }
        for (int index = lane; index < seeds; index += 32) {
            int vertex = seed_vertex(owner, round, index);
            if (scenario == 1 && index == 0) vertex = -1;
            slot->input[index] = {vertex, seed_distance(owner, round, index)};
        }
        if (!lane) slot->seeds = seeds;
        if (mode == 3) {
            __syncwarp(relay::mask);
            relay::expand_payload(slot, graph, lane);
        } else {
            if (mode >= 4)
                relay::publish_exclusive(slot, relay::encode(round, relay::ready), lane);
            else
                relay::publish(slot, relay::encode(round, relay::filling), relay::ready, lane);
            if (mode == 0 || mode == 6) {
                const auto token = relay::encode(round, relay::ready);
                if (!claim(slot, token, relay::active, lane)) {
                    if (!lane) atomicCAS(error, 0, 2);
                    return;
                }
                relay::execute(slot, relay::encode(round, relay::active), graph, lane, mode >= 4);
            }
            unsigned long long started = clock64();
            auto token = warp_load(slot, lane);
            while (token != relay::encode(round, relay::returned)) {
                int expired = 0;
                if (!lane) expired = clock64() - started > timeout_cycles;
                if (__shfl_sync(relay::mask, expired, 0)) {
                    if (!lane) atomicCAS(error, 0, 3);
                    return;
                }
                __nanosleep(64);
                token = warp_load(slot, lane);
            }
            if (mode < 4 && !claim(slot, token, relay::committing, lane)) {
                if (!lane) atomicCAS(error, 0, 4);
                return;
            }
            const auto acquired = relay::load(slot);
            assert(acquired == relay::encode(round, mode >= 4 ? relay::returned : relay::committing));
        }
        const int expected_status = scenario == 1 ? relay::bad_seed :
                                    scenario == 2 ? relay::full : relay::ok;
        if (slot->result_status != expected_status) {
            if (!lane) atomicCAS(error, 0, 5);
        }
        for (int index = lane; index < slot->results; index += 32)
            checksum += fingerprint(slot->output[index]);
        // In the solver, this point MUST follow durable owner atomicMin and
        // queue/TX publication, not merely a checksum. No solver credit here.
        if (mode == 3) {
            __syncwarp(relay::mask);
            if (!lane) slot->control = relay::encode(round + 1, relay::free);
        } else if (mode < 4) {
            relay::recycle(slot, relay::encode(round, relay::committing), lane);
        } else {
            // No public intermediate states needed: this warp is the only
            // consumer and producer. Finish reading results before overwriting.
            __syncwarp(relay::mask);
        }
    }
    if (mode >= 4)
        relay::publish_exclusive(slot, relay::encode(rounds, relay::free), lane);
    for (int offset = 16; offset; offset >>= 1)
        checksum += __shfl_down_sync(relay::mask, checksum, offset);
    if (!lane) checksums[owner] = checksum;
}

__global__ static void helper_kernel(relay::slot *channel, relay::graph_view graph,
                                      int *stop, bool exclusive_return) {
    const int lane = threadIdx.x % 32;
    // TWO helpers contend per slot: successful versioned CAS is the sole owner.
    const int index = ((blockIdx.x * blockDim.x + threadIdx.x) / 32) % slots;
    auto *slot = channel + index;
    while (true) {
        int done = 0;
        if (!lane) done = cuda::atomic_ref<int, cuda::thread_scope_system>(*stop)
            .load(cuda::memory_order_acquire);
        if (__shfl_sync(relay::mask, done, 0)) return;
        const auto token = warp_load(slot, lane);
        if (relay::state(token) == relay::ready && claim(slot, token, relay::active, lane))
            relay::execute(slot, relay::encode(relay::generation(token), relay::active), graph, lane, exclusive_return);
        else
            __nanosleep(64);
    }
}
__global__ static void stop_kernel(int *stop) {
    cuda::atomic_ref<int, cuda::thread_scope_system>(*stop).store(1, cuda::memory_order_release);
}

struct device_graph {
    int *rows = nullptr, *columns = nullptr, *weights = nullptr;
    relay::graph_view view() const { return {rows, columns, weights, 0, vertices}; }
};
static std::vector<int> make_rows(int degree) {
    std::vector<int> rows(vertices + 1);
    for (int i = 0; i <= vertices; ++i) rows[i] = i * degree;
    return rows;
}
static void upload(device_graph &graph, int gpu, int degree) {
    check_cuda(cudaSetDevice(gpu), "set device upload");
    auto rows = make_rows(degree);
    std::vector<int> columns(vertices * degree), weights(vertices * degree);
    for (int vertex = 0; vertex < vertices; ++vertex)
        for (int edge = 0; edge < degree; ++edge) {
            columns[vertex * degree + edge] = (vertex + edge * 257 + 1) % vertices;
            weights[vertex * degree + edge] = 1 + (vertex + edge) % 13;
        }
    check_cuda(cudaMalloc(&graph.rows, rows.size() * sizeof(int)), "allocate rows");
    check_cuda(cudaMalloc(&graph.columns, columns.size() * sizeof(int)), "allocate columns");
    check_cuda(cudaMalloc(&graph.weights, weights.size() * sizeof(int)), "allocate weights");
    check_cuda(cudaMemcpy(graph.rows, rows.data(), rows.size() * sizeof(int), cudaMemcpyHostToDevice), "upload rows");
    check_cuda(cudaMemcpy(graph.columns, columns.data(), columns.size() * sizeof(int), cudaMemcpyHostToDevice), "upload columns");
    check_cuda(cudaMemcpy(graph.weights, weights.data(), weights.size() * sizeof(int), cudaMemcpyHostToDevice), "upload weights");
}
static void release(device_graph &graph, int gpu) {
    check_cuda(cudaSetDevice(gpu), "set device release");
    check_cuda(cudaFree(graph.rows), "free rows");
    check_cuda(cudaFree(graph.columns), "free columns");
    check_cuda(cudaFree(graph.weights), "free weights");
}
static relay::item reference(int vertex, int distance, int edge) {
    const int weight = 1 + (vertex + edge) % 13;
    const long long sum = static_cast<long long>(distance) + weight;
    return {(vertex + edge * 257 + 1) % vertices, sum >= INT_MAX ? INT_MAX : int(sum)};
}

static void run_case(int mode, int degree, int seeds, int rounds, int scenario,
                     device_graph graphs[2], relay::slot *channel, int *stop,
                     int *error, unsigned long long *checksums,
                     cudaStream_t owner_stream, cudaStream_t peer_stream) {
    check_cuda(cudaSetDevice(0), "set owner");
    check_cuda(cudaMemset(channel, 0, slots * sizeof(relay::slot)), "reset slots");
    check_cuda(cudaMemset(stop, 0, sizeof(int)), "reset stop");
    check_cuda(cudaMemset(error, 0, sizeof(int)), "reset error");
    check_cuda(cudaMemset(checksums, 0, slots * sizeof(unsigned long long)), "reset checksums");
    const bool peer = mode == 1 || mode == 2 || mode == 4 || mode == 5;
    if (peer) {
        check_cuda(cudaSetDevice(1), "set helper");
        helper_kernel<<<8, 256, 0, peer_stream>>>(channel,
            graphs[mode == 2 || mode == 5 ? 1 : 0].view(), stop, mode >= 4);
        check_cuda(cudaGetLastError(), "helper launch");
    }
    check_cuda(cudaSetDevice(0), "set owner launch");
    cudaEvent_t start, end;
    check_cuda(cudaEventCreate(&start), "create start");
    check_cuda(cudaEventCreate(&end), "create end");
    check_cuda(cudaEventRecord(start, owner_stream), "record start");
    owner_kernel<<<4, 256, 0, owner_stream>>>(channel, graphs[0].view(), seeds,
        rounds, mode, scenario, checksums, error);
    check_cuda(cudaGetLastError(), "owner launch");
    check_cuda(cudaEventRecord(end, owner_stream), "record end");
    // Preloaded stop kernel; cannot trigger a lazy module-load deadlock.
    stop_kernel<<<1, 1, 0, owner_stream>>>(stop);
    check_cuda(cudaGetLastError(), "stop launch");
    check_cuda(cudaStreamSynchronize(owner_stream), "owner completion");
    if (peer) {
        check_cuda(cudaSetDevice(1), "set helper join");
        check_cuda(cudaStreamSynchronize(peer_stream), "helper completion");
        check_cuda(cudaSetDevice(0), "restore owner");
    }
    float elapsed = 0;
    check_cuda(cudaEventElapsedTime(&elapsed, start, end), "elapsed");
    int device_error = 0;
    std::vector<relay::slot> result(slots);
    std::vector<unsigned long long> sums(slots);
    check_cuda(cudaMemcpy(&device_error, error, sizeof(int), cudaMemcpyDeviceToHost), "read error");
    check_cuda(cudaMemcpy(result.data(), channel, slots * sizeof(relay::slot), cudaMemcpyDeviceToHost), "read results");
    check_cuda(cudaMemcpy(sums.data(), checksums, slots * sizeof(unsigned long long), cudaMemcpyDeviceToHost), "read checksums");
    if (device_error) {
        std::fprintf(stderr, "RELAY_FAIL device_error=%d mode=%d\n", device_error, mode);
        std::exit(1);
    }
    for (int owner = 0; owner < slots; ++owner) {
        const auto &slot = result[owner];
        unsigned long long expected_sum = 0;
        const int expected_status = scenario == 1 ? relay::bad_seed :
                                    scenario == 2 ? relay::full : relay::ok;
        bool correct = slot.control == relay::encode(rounds, relay::free) &&
            slot.result_status == expected_status &&
            slot.results == (scenario ? 0 : seeds * degree);
        if (!scenario) {
            for (int round = 0; round < rounds; ++round)
                for (int seed = 0; seed < seeds; ++seed)
                    for (int edge = 0; edge < degree; ++edge) {
                        const auto wanted = reference(seed_vertex(owner, round, seed),
                            seed_distance(owner, round, seed), edge);
                        expected_sum += fingerprint(wanted);
                        if (round == rounds - 1) {
                            const auto actual = slot.output[seed * degree + edge];
                            correct &= actual.vertex == wanted.vertex && actual.distance == wanted.distance;
                        }
                    }
        }
        if (!correct || sums[owner] != expected_sum) {
            std::fprintf(stderr, "RELAY_FAIL owner=%d mode=%d scenario=%d\n", owner, mode, scenario);
            std::exit(1);
        }
    }
    std::printf("RELAY_CASE mode=%d degree=%d seeds=%d rounds=%d slots=%d scenario=%d ms=%.6f correct=1\n",
        mode, degree, seeds, rounds, slots, scenario, elapsed);
    check_cuda(cudaEventDestroy(start), "destroy start");
    check_cuda(cudaEventDestroy(end), "destroy end");
}

int main(int argc, char **argv) {
    if (!std::getenv("SLURM_JOB_ID")) {
        std::fputs("Batch relay test requires a Slurm allocation\n", stderr);
        return 2;
    }
    const bool quick = argc == 2 && std::strcmp(argv[1], "--quick") == 0;
    if (argc > 1 && !quick) return 2;
    int devices = 0;
    check_cuda(cudaGetDeviceCount(&devices), "device count");
    if (devices != 2) { std::fputs("Exactly two allocated GPUs required\n", stderr); return 2; }
    for (int gpu = 0; gpu < 2; ++gpu) {
        int access = 0, native = 0;
        check_cuda(cudaDeviceCanAccessPeer(&access, gpu, 1 - gpu), "peer access");
        check_cuda(cudaDeviceGetP2PAttribute(&native, cudaDevP2PAttrNativeAtomicSupported, gpu, 1 - gpu), "native peer atomics");
        if (!access || !native) { std::fputs("Native P2P atomics required; no fallback\n", stderr); return 2; }
        check_cuda(cudaSetDevice(gpu), "set peer device");
        check_cuda(cudaDeviceEnablePeerAccess(1 - gpu, 0), "enable peer access");
        cudaFuncAttributes attributes;
        check_cuda(cudaFuncGetAttributes(&attributes, helper_kernel), "preload helper");
        check_cuda(cudaFuncGetAttributes(&attributes, owner_kernel), "preload owner");
        check_cuda(cudaFuncGetAttributes(&attributes, stop_kernel), "preload stop");
    }
    check_cuda(cudaSetDevice(0), "owner allocation");
    relay::slot *channel = nullptr;
    int *stop = nullptr, *error = nullptr;
    unsigned long long *checksums = nullptr;
    check_cuda(cudaMalloc(&channel, slots * sizeof(relay::slot)), "allocate slots");
    check_cuda(cudaMalloc(&stop, sizeof(int)), "allocate stop");
    check_cuda(cudaMalloc(&error, sizeof(int)), "allocate error");
    check_cuda(cudaMalloc(&checksums, slots * sizeof(unsigned long long)), "allocate checksums");
    cudaStream_t owner_stream, peer_stream;
    check_cuda(cudaStreamCreateWithFlags(&owner_stream, cudaStreamNonBlocking), "owner stream");
    check_cuda(cudaSetDevice(1), "helper stream device");
    check_cuda(cudaStreamCreateWithFlags(&peer_stream, cudaStreamNonBlocking), "helper stream");
    for (int degree : {3, 12}) {
        device_graph graphs[2];
        upload(graphs[0], 0, degree);
        upload(graphs[1], 1, degree);
        for (int mode : {0, 1, 2, 3, 4, 5, 6}) {
            run_case(mode, degree, 32, 3, 1, graphs, channel, stop, error,
                     checksums, owner_stream, peer_stream);
            if (degree == 12)
                run_case(mode, degree, 512, 3, 2, graphs, channel, stop, error,
                         checksums, owner_stream, peer_stream);
        }
        for (int seeds : {16, 128, 256})
            for (int repeat = 0; repeat < (quick ? 1 : 3); ++repeat)
                for (int mode : {3, 0, 1, 2, 6, 4, 5, 5, 4, 6, 2, 1, 0, 3})
                    run_case(mode, degree, seeds, quick ? 3 : 128, 0, graphs,
                        channel, stop, error, checksums, owner_stream, peer_stream);
        release(graphs[0], 0);
        release(graphs[1], 1);
    }
    check_cuda(cudaSetDevice(1), "helper cleanup");
    check_cuda(cudaStreamDestroy(peer_stream), "destroy helper stream");
    check_cuda(cudaSetDevice(0), "owner cleanup");
    check_cuda(cudaStreamDestroy(owner_stream), "destroy owner stream");
    check_cuda(cudaFree(channel), "free slots");
    check_cuda(cudaFree(stop), "free stop");
    check_cuda(cudaFree(error), "free error");
    check_cuda(cudaFree(checksums), "free checksums");
    std::puts("BATCH_RELAY_PASS protocol_and_cost_screen_not_sssp");
}
