#include "../../SSSP/l3/l3_chain_v2_math.h"
#include "../../SSSP/l3/l3_chain_v2_state.cuh"

#include <cuda_runtime.h>
#include <climits>
#include <cstdio>
#include <cstdlib>

static void require_cuda(cudaError_t status, const char *operation)
{
    if (status == cudaSuccess) return;
    std::fprintf(stderr, "%s: %s\n", operation, cudaGetErrorString(status));
    std::exit(2);
}

__global__ static void first_offers(
    int *pending, const int *completed,
    l3_chain_v2_segment_state *state, int *result)
{
    const int lane = threadIdx.x;
    if (lane < 4)
        result[lane] = l3_chain_v2_offer(
            pending, completed, state, 0, lane, 100 - 25 * lane);
}

__global__ static void offer_one(
    int *pending, const int *completed,
    l3_chain_v2_segment_state *state,
    int index, int value, int *result)
{
    *result = l3_chain_v2_offer(
        pending, completed, state, 0, index, value);
}

__global__ static void claim_snapshot(
    const l3_chain_partition_node *nodes, int *pending,
    l3_chain_v2_segment_state *state, int *snapshot, int *closed,
    unsigned long long *claimed_epoch, int *claimed)
{
    if (threadIdx.x != 0) return;
    unsigned long long epoch = 0;
    *claimed = l3_chain_v2_claim(state, 0, epoch) ? 1 : 0;
    if (!*claimed) return;
    *claimed_epoch = epoch;
    for (int index = 0; index < 5; ++index)
        snapshot[index] = l3_chain_v2_take_pending(pending, index);
    l3_chain_v2_closure(nodes, 0, snapshot, closed);
}

__global__ static void publish_complete_commit(
    int *completed, const int *closed, int *published,
    l3_chain_v2_segment_state *state,
    const unsigned long long *claimed_epoch, int *result)
{
    if (threadIdx.x != 0) return;
    // This tiny fixture stands in for the solver's materialized distances
    // and durable endpoint activations.  The real integration must meet the
    // same precondition before l3_chain_v2_complete is allowed to run.
    for (int index = 0; index < 5; ++index)
        published[index] = closed[index];
    __threadfence();
    l3_chain_v2_complete(
        completed, closed, 0, 5, state, 0, *claimed_epoch);
    *result = l3_chain_v2_commit(state, 0, *claimed_epoch);
}

static void check(bool condition, const char *stage)
{
    if (condition) return;
    std::fprintf(stderr, "CHAIN_V2_STATE_FAIL stage=%s\n", stage);
    std::exit(1);
}

int main()
{
    const l3_chain_partition_node nodes[5] = {
        {1, 0, 0, 5}, {2, 1, 1, 0}, {3, 2, 2, 0},
        {4, 3, 3, 0}, {5, 4, 4, 0},
    };
    const int empty[5] = {INT_MAX, INT_MAX, INT_MAX, INT_MAX, INT_MAX};
    l3_chain_partition_node *device_nodes = nullptr;
    int *pending = nullptr, *completed = nullptr, *snapshot = nullptr;
    int *closed = nullptr, *published = nullptr, *result = nullptr;
    unsigned long long *claimed_epoch = nullptr;
    l3_chain_v2_segment_state *state = nullptr;
    require_cuda(cudaMalloc(&device_nodes, sizeof(nodes)), "nodes alloc");
    require_cuda(cudaMalloc(&pending, sizeof(empty)), "pending alloc");
    require_cuda(cudaMalloc(&completed, sizeof(empty)), "completed alloc");
    require_cuda(cudaMalloc(&snapshot, sizeof(empty)), "snapshot alloc");
    require_cuda(cudaMalloc(&closed, sizeof(empty)), "closed alloc");
    require_cuda(cudaMalloc(&published, sizeof(empty)), "published alloc");
    require_cuda(cudaMalloc(&result, 4 * sizeof(int)), "result alloc");
    require_cuda(cudaMalloc(&claimed_epoch, sizeof(unsigned long long)),
                 "claimed epoch alloc");
    require_cuda(cudaMalloc(&state, sizeof(*state)), "state alloc");
    require_cuda(cudaMemcpy(device_nodes, nodes, sizeof(nodes),
                           cudaMemcpyHostToDevice), "nodes upload");
    require_cuda(cudaMemcpy(pending, empty, sizeof(empty),
                           cudaMemcpyHostToDevice), "pending reset");
    require_cuda(cudaMemcpy(completed, empty, sizeof(empty),
                           cudaMemcpyHostToDevice), "completed reset");
    require_cuda(cudaMemset(state, 0, sizeof(*state)), "state reset");

    first_offers<<<1, 4>>>(pending, completed, state, result);
    require_cuda(cudaDeviceSynchronize(), "first offers");
    int offered[4] = {};
    require_cuda(cudaMemcpy(offered, result, sizeof(offered),
                           cudaMemcpyDeviceToHost), "first offers read");
    int tokens = 0;
    for (int value : offered)
    {
        check(value == L3_CHAIN_V2_NEW_TOKEN ||
              value == L3_CHAIN_V2_MERGED, "first offer result");
        tokens += value == L3_CHAIN_V2_NEW_TOKEN;
    }
    check(tokens == 1, "one token for four offers");

    claim_snapshot<<<1, 1>>>(device_nodes, pending, state,
                             snapshot, closed, claimed_epoch, result);
    require_cuda(cudaDeviceSynchronize(), "first claim");
    int claimed = 0;
    require_cuda(cudaMemcpy(&claimed, result, sizeof(claimed),
                           cudaMemcpyDeviceToHost), "first claim read");
    check(claimed == 1, "first claim accepted");
    int first_snapshot[5] = {};
    require_cuda(cudaMemcpy(first_snapshot, snapshot,
                           sizeof(first_snapshot), cudaMemcpyDeviceToHost),
                 "first snapshot read");
    for (int index = 0; index < 5; ++index)
        check(first_snapshot[index] == (index < 4 ? 100 - 25 * index :
                                        INT_MAX), "four-entry batch snapshot");

    // Interleave a newer offer after the first pending snapshot but before
    // completing it; old-version commit must rearm exactly one token.
    offer_one<<<1, 1>>>(pending, completed, state, 2, 5, result);
    require_cuda(cudaDeviceSynchronize(), "active offer");
    int observed = -1;
    require_cuda(cudaMemcpy(&observed, result, sizeof(observed),
                           cudaMemcpyDeviceToHost), "active offer read");
    check(observed == L3_CHAIN_V2_MERGED, "active offer retained");
    publish_complete_commit<<<1, 1>>>(
        completed, closed, published, state, claimed_epoch, result);
    require_cuda(cudaDeviceSynchronize(), "first commit");
    require_cuda(cudaMemcpy(&observed, result, sizeof(observed),
                           cudaMemcpyDeviceToHost), "first commit read");
    check(observed == L3_CHAIN_V2_REQUEUE, "new version requeued");

    l3_chain_v2_segment_state host_state = {};
    require_cuda(cudaMemcpy(&host_state, state, sizeof(host_state),
                           cudaMemcpyDeviceToHost), "queued state read");
    check((host_state.ownership & L3_CHAIN_V2_STATE_MASK) ==
              L3_CHAIN_V2_QUEUED &&
          host_state.completed_epoch == 16ull, "queued epoch preserved");
    int first_envelope[5] = {};
    require_cuda(cudaMemcpy(first_envelope, completed,
                           sizeof(first_envelope), cudaMemcpyDeviceToHost),
                 "first envelope read");
    const int first_expected[5] = {28, 27, 26, 25, 26};
    for (int index = 0; index < 5; ++index)
        check(first_envelope[index] == first_expected[index],
              "four-entry closure committed");

    claim_snapshot<<<1, 1>>>(device_nodes, pending, state,
                             snapshot, closed, claimed_epoch, result);
    require_cuda(cudaDeviceSynchronize(), "second claim");
    require_cuda(cudaMemcpy(&claimed, result, sizeof(claimed),
                           cudaMemcpyDeviceToHost), "second claim read");
    check(claimed == 1, "second claim accepted");
    int second_snapshot[5] = {};
    require_cuda(cudaMemcpy(second_snapshot, snapshot,
                           sizeof(second_snapshot), cudaMemcpyDeviceToHost),
                 "second snapshot read");
    for (int index = 0; index < 5; ++index)
        check(second_snapshot[index] == (index == 2 ? 5 : INT_MAX),
              "new pending survived first commit");
    publish_complete_commit<<<1, 1>>>(
        completed, closed, published, state, claimed_epoch, result);
    require_cuda(cudaDeviceSynchronize(), "second commit");
    require_cuda(cudaMemcpy(&observed, result, sizeof(observed),
                           cudaMemcpyDeviceToHost), "second commit read");
    check(observed == L3_CHAIN_V2_COMMIT_IDLE, "second commit idle");
    require_cuda(cudaMemcpy(&host_state, state, sizeof(host_state),
                           cudaMemcpyDeviceToHost), "idle state read");
    check((host_state.ownership & L3_CHAIN_V2_STATE_MASK) ==
              L3_CHAIN_V2_IDLE && host_state.completed_epoch == 20ull,
          "completed epoch released");
    int envelope[5] = {};
    require_cuda(cudaMemcpy(envelope, completed, sizeof(envelope),
                           cudaMemcpyDeviceToHost), "envelope read");
    const int expected[5] = {7, 6, 5, 6, 7};
    for (int index = 0; index < 5; ++index)
        check(envelope[index] == expected[index], "exact envelope");

    offer_one<<<1, 1>>>(pending, completed, state, 2, 5, result);
    require_cuda(cudaDeviceSynchronize(), "dominated offer");
    require_cuda(cudaMemcpy(&observed, result, sizeof(observed),
                           cudaMemcpyDeviceToHost), "dominated offer read");
    check(observed == L3_CHAIN_V2_DOMINATED,
          "completed certificate dominates equal entry");
    offer_one<<<1, 1>>>(pending, completed, state, 4, 0, result);
    require_cuda(cudaDeviceSynchronize(), "new idle offer");
    require_cuda(cudaMemcpy(&observed, result, sizeof(observed),
                           cudaMemcpyDeviceToHost), "new idle offer read");
    check(observed == L3_CHAIN_V2_NEW_TOKEN,
          "new decrease after idle creates token");
    require_cuda(cudaMemcpy(&host_state, state, sizeof(host_state),
                           cudaMemcpyDeviceToHost), "final state read");
    check((host_state.ownership & L3_CHAIN_V2_STATE_MASK) ==
              L3_CHAIN_V2_QUEUED && host_state.completed_epoch == 20ull,
          "new token remains durable");

    require_cuda(cudaFree(device_nodes), "nodes free");
    require_cuda(cudaFree(pending), "pending free");
    require_cuda(cudaFree(completed), "completed free");
    require_cuda(cudaFree(snapshot), "snapshot free");
    require_cuda(cudaFree(closed), "closed free");
    require_cuda(cudaFree(published), "published free");
    require_cuda(cudaFree(result), "result free");
    require_cuda(cudaFree(claimed_epoch), "epoch free");
    require_cuda(cudaFree(state), "state free");
    std::puts("CHAIN_V2_STATE_CUDA_PASS offers=4 active_rearm=1 dominated=1 new_idle_token=1");
    return 0;
}
