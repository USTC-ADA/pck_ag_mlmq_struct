#!/usr/bin/env python3
"""Recompute saved peer-commit evidence on CPU; never runs CUDA or Slurm."""
import argparse
from datetime import datetime, timezone
import hashlib
import heapq
import json
from pathlib import Path
import tarfile

from run_l3_batch_peer_commit import parse_cases, verify_build
from run_l3_compact_screen import sanitizer_passed

INF = 2147483647


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def fields(line, keys):
    parts = line.split()
    require(parts[::2] == keys and len(parts) == 2 * len(keys), 'malformed row: ' + line[:120])
    return dict(zip(keys, map(int, parts[1::2])))


def dijkstra(graph, roots):
    distance, heap = {}, []
    for vertex, value in roots:
        if value < distance.get(vertex, INF):
            distance[vertex] = value
            heapq.heappush(heap, (value, vertex))
    while heap:
        value, vertex = heapq.heappop(heap)
        if distance[vertex] != value:
            continue
        for target, weight in graph[vertex]:
            candidate = min(INF, value + weight)
            if candidate < distance.get(target, INF):
                distance[target] = candidate
                heapq.heappush(heap, (candidate, target))
    return distance


def audit_case(audit_path, journal_path, case):
    """Independent graph/oracle/seed/certificate check of one saved GPU case."""
    with audit_path.open() as stream:
        header = fields(next(stream), ['BEGIN', 'VERTICES', 'ROUNDS'])
        begin, vertices, rounds = header['BEGIN'], header['VERTICES'], header['ROUNDS']
        end = begin + vertices
        require(begin == case['begin'] and rounds == case['rounds'] and
                vertices == 1 + rounds * (case['group'] + 1), 'wrong graph dimensions')
        graph, records = {v: [] for v in range(begin, end)}, {}
        for line in stream:
            if line.startswith('VERTEX '):
                record = fields(line, ['VERTEX', 'initial', 'distance', 'oracle', 'expected', 'seen'])
                vertex = record['VERTEX']
                require(vertex in graph and vertex not in records, 'duplicate/outside vertex')
                require(all(0 <= record[k] <= INF for k in ('initial', 'distance', 'oracle')),
                        'invalid distance')
                require(record['expected'] == record['seen'] and record['seen'] >= 0,
                        'publication/consumption multiplicity mismatch')
                records[vertex] = record
            else:
                parts = line.split()
                require(len(parts) == 4 and parts[0] == 'EDGE', 'invalid edge row')
                source, target, weight = map(int, parts[1:])
                require(source in graph and target in graph and 0 <= weight <= INF,
                        'invalid owner graph edge')
                graph[source].append((target, weight))
    require(set(records) == set(graph), 'missing vertices')
    oracle = dijkstra(graph, [(begin, 0)])
    for vertex, record in records.items():
        require(record['distance'] == record['oracle'] == oracle.get(vertex, INF),
                'independent Dijkstra mismatch at ' + str(vertex))
        require(record['initial'] >= oracle.get(vertex, INF), 'initial distance below reachable bound')
    require(8 + sum(r['seen'] for r in records.values()) == case['total_writes'],
            'queue total differs from saved multiplicities plus ancestor credit')
    generations = []
    for line in journal_path.read_text().splitlines():
        if line.startswith('GEN '):
            generation = fields(line, ['GEN', 'mode', 'budget', 'root', 'competitor',
                                      'seeds', 'count', 'status', 'fallback', 'claims'])
            generation.update(roots=[], journal=[])
            generations.append(generation)
        else:
            parts = line.split()
            require(bool(generations) and bool(parts), 'payload before generation')
            require((parts[0] == 'SEED' and len(parts) == 3) or
                    (parts[0] == 'RECORD' and len(parts) == 4), 'invalid journal row')
            generations[-1]['roots' if parts[0] == 'SEED' else 'journal'].append(tuple(map(int, parts[1:])))
    require(len(generations) == rounds, 'missing/duplicate generations')
    fallbacks = capacity_stops = distinct512 = certificates = journal_records = 0
    for index, generation in enumerate(generations):
        roots, journal = generation['roots'], generation['journal']
        mode, group = index % 5, case['group']
        seed_count = (1, 7, 512)[index % 3]
        budget = 64 if mode >= 3 else (0, 1, 64, 64)[index % 4]
        root = begin + 1 + index * (group + 1)
        require(generation['GEN'] == index + 1 and generation['claims'] == 1 and
                generation['mode'] == mode and generation['budget'] == budget and
                generation['root'] == root and generation['competitor'] == root + group,
                'invalid generation/claim/plan')
        require(generation['seeds'] == len(roots) == seed_count and
                generation['count'] == len(journal) <= 768, 'invalid payload counts')
        expected_roots = [(root + i % min(group, seed_count),
                           records[root + i % min(group, seed_count)]['initial']) for i in range(seed_count)]
        require(roots == expected_roots, 'immutable seed snapshot mismatch')
        require(all(0 <= value < INF for _, value in roots), 'invalid seed distance')
        distinct512 += len(set(v for v, _ in roots)) == 512
        fault = mode >= 3
        require(generation['fallback'] == int(fault) and
                generation['status'] == (3 if mode == 3 else 0), 'wrong fault/fallback result')
        if fault:
            require(not journal, 'invalid helper return was accepted')
            fallbacks += 1
            continue
        require(bool(journal), 'empty successful journal')
        labels = {}
        reachable = dijkstra(graph, roots)
        for vertex, distance, certificate in journal:
            require(vertex in graph and vertex not in labels, 'duplicate/outside journal vertex')
            require(0 <= distance < INF and distance <= certificate <= INF,
                    'invalid journal distance/certificate')
            require(reachable.get(vertex, INF) <= distance, 'journal below reachable lower bound')
            labels[vertex] = distance
        for vertex, distance in roots:
            require(labels.get(vertex, INF) <= distance, 'original seed missing from journal')
        certified = 0
        for vertex, distance, certificate in journal:
            if certificate < INF:
                certified += 1
                for target, weight in graph[vertex]:
                    require(labels.get(target, INF) <= min(INF, certificate + weight),
                            'incomplete row certificate')
        capacity_stops += budget > 0 and certified == 0
        certificates += certified
        journal_records += len(journal)
    require((fallbacks, capacity_stops, distinct512) ==
            (case['fallbacks'], case['capacity_stops'], case['distinct512']), 'coverage totals mismatch')
    return dict(generations=rounds, vertices=vertices, edges=sum(map(len, graph.values())),
                certificates=certificates, journal_records=journal_records,
                total_writes=case['total_writes'], fallbacks=fallbacks)


def audit_run(run):
    metadata = json.loads((run / 'manifest.json').read_text())
    build = Path(metadata['build']).resolve(strict=True)
    snapshot = verify_build(build)
    require(snapshot == metadata['snapshot'] and
            sha256(build / 'manifest.json') == metadata['build_manifest_sha256'], 'build provenance mismatch')
    # Check source archive content without extracting or executing anything.
    with tarfile.open(build / 'source.tgz') as archive:
        names = {name[7:] for name in snapshot['hashes'] if name.startswith('source/')}
        members = archive.getmembers()
        require(len(members) == len(names) and {m.name for m in members} == names and
                all(m.isfile() for m in members), 'source archive member mismatch')
        for member in members:
            require(hashlib.sha256(archive.extractfile(member).read()).hexdigest() ==
                    snapshot['hashes']['source/' + member.name], 'source archive content mismatch')
    status = json.loads((run / 'status.json').read_text())
    summary = json.loads((run / 'summary.json').read_text())
    require(status.get('complete') is True and summary.get('valid') is True and
            status['results'] == summary['results'], 'incomplete/inconsistent run')
    require(all(summary.get(k) is False for k in ('remote_publication', 'real_l1_loan',
                                                'solver_integration', 'performance_evidence')),
            'evidence scope changed')
    require(all(summary.get(k) is True for k in ('actual_peer', 'actual_dq',
                'both_owner_helper_directions', 'nonzero_partition_begin',
                'gpu_journals_cpu_validated', 'two_contending_helpers',
                'active_and_post_apply_competition', 'invalid_return_fallback')),
            'missing peer fixture coverage')
    job = (run / 'slurm_job_running.log').read_text()
    require('JobId=' + str(metadata['allocation']['job_id']) + ' ' in job and
            'Partition=a100 ' in job and 'TresPerNode=gres/gpu:a100:2' in job and
            job.endswith('RUN_RC=0\n'), 'missing historical dual-A100 allocation')
    require('NV12' in (run / 'gpu_topology.log').read_text(), 'missing recorded NVLink topology')
    require((run / 'gpu_apps_initial.log').read_text().strip() == 'RUN_RC=0',
            'initial GPU process check failed')
    expected_stages = {'smoke', 'normal', 'memcheck', 'racecheck', 'synccheck'}
    require(set(summary['results']) == expected_stages, 'wrong stage set')
    stages = {}
    for stage in ('smoke', 'normal', 'memcheck', 'racecheck', 'synccheck'):
        result = summary['results'][stage]
        raw = (run / (stage + '.log')).read_text()
        quick = stage != 'normal'
        tool = stage if stage in ('memcheck', 'racecheck', 'synccheck') else None
        require(result['rc'] == 0 and result['state'] == 'passed' and
                result['quick'] is quick and result['sanitizer'] == tool and
                sanitizer_passed(raw, tool), 'failed stage: ' + stage)
        cases = parse_cases(raw, quick)
        require(cases == result['cases'], 'saved cases differ from raw log')
        directory = run / (stage + '_journals')
        artifacts = result['raw_artifacts']
        expected_names = {f"owner{c['owner']}_begin{c['begin']}_group{c['group']}.{suffix}.txt"
                          for c in cases for suffix in ('audit', 'journal')}
        require(set(artifacts) == expected_names == {p.name for p in directory.iterdir()},
                'wrong raw artifact set')
        for name, digest in artifacts.items():
            require(sha256(directory / name) == digest, 'changed raw artifact: ' + name)
        results = []
        for case in cases:
            stem = f"owner{case['owner']}_begin{case['begin']}_group{case['group']}"
            results.append(audit_case(directory / (stem + '.audit.txt'), directory / (stem + '.journal.txt'), case))
        stages[stage] = {'cases': len(cases), **{k: sum(r[k] for r in results) for k in results[0]}}
    require(summary.get('normal_cases') == stages['normal']['cases'] and
            summary.get('normal_generations') == stages['normal']['generations'] and
            all(summary.get('quick_cases_each_sanitizer') == stages[t]['cases'] and
                summary.get('quick_generations_each_sanitizer') == stages[t]['generations']
                for t in ('memcheck', 'racecheck', 'synccheck')), 'summary totals mismatch')
    return {'valid': True, 'reviewed_at_utc': datetime.now(timezone.utc).isoformat(),
            'run': str(run), 'allocation': metadata['allocation'], 'stages': stages,
            'build_manifest_sha256': sha256(build / 'manifest.json'),
            'build_artifacts_verified': len(snapshot['hashes']),
            'run_file_hashes': {str(p.relative_to(run)): sha256(p) for p in sorted(run.rglob('*')) if p.is_file()},
            'auditor_sha256': sha256(Path(__file__)),
            'evidence_class': 'offline_review_of_exploratory_peer_fixture',
            'gpu_rerun': False, 'solver_integration': False, 'performance_evidence': False,
            'limits': ['Queue bucket counters are checked by the frozen executable; raw per-bucket values were not archived.',
                       'Journal values are checked against reachable lower bounds and complete-row certificates, not exact path witnesses.',
                       'Historical Slurm terminal state is not established by this offline review.']}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', required=True, type=Path)
    parser.add_argument('--out', required=True, type=Path)
    args = parser.parse_args()
    require(not args.out.exists() and not args.out.is_symlink(), 'output must not exist')
    run = args.run.resolve(strict=True)
    output = args.out.resolve()
    require(run not in output.parents, 'write the review outside the original evidence directory')
    report = audit_run(run)
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open('x') as stream:
        json.dump(report, stream, indent=2, sort_keys=True)
        stream.write('\n')
    print('PEER_COMMIT_OFFLINE_AUDIT_PASS', json.dumps(report['stages'], sort_keys=True))


if __name__ == '__main__':
    main()
