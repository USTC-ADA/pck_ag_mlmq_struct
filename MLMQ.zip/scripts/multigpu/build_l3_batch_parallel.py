#!/usr/bin/env python3
"""Freeze and compile the parallel owner differential and real-queue fixtures."""
import argparse
import concurrent.futures
import json
from pathlib import Path
import shutil
import subprocess
import tarfile
from run_l3_upgrade_stage2 import ROOT, sha256, write_json


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--allow-dirty', action='store_true')
    parser.add_argument('--packed-compact', action='store_true')
    args = parser.parse_args()
    if not args.allow_dirty:
        parser.error('exploratory build requires --allow-dirty')
    args.out.mkdir(parents=True, exist_ok=False)
    out = args.out.resolve()
    src = out / 'source'
    for name in ('SSSP', 'core', 'scripts/multigpu'):
        shutil.copytree(ROOT / name, src / name, ignore=shutil.ignore_patterns('__pycache__'))
    for name, command in (('worktree.diff', ['git', 'diff']), ('head.txt', ['git', 'rev-parse', 'HEAD']),
                          ('worktree_status.txt', ['git', 'status', '--short'])):
        (out / name).write_bytes(subprocess.check_output(command, cwd=ROOT))
    with tarfile.open(out / 'source.tgz', 'w:gz') as archive:
        for name in ('SSSP', 'core', 'scripts'):
            archive.add(src / name, arcname=name)
    variants = {'differential': 'parallel', 'peer': 'peer_commit', 'remote': 'remote_commit', 'l1': 'l1_donor'}
    if args.packed_compact:
        variants = {'packed': 'packed', 'peer': 'peer_commit', 'remote': 'remote_commit', 'l1': 'l1_donor'}

    def build(item):
        kind, suffix = item
        cmd = ['/usr/local/cuda/bin/nvcc', '-std=c++14', '-O2', '-lineinfo', '-rdc=true',
               '-gencode=arch=compute_80,code=sm_80', '-DDQ_COUNTER_OVERFLOW_GUARD=true',
               '-DL3_TEST_PARALLEL_OWNER=1', '-Icore/include', '-Xptxas=-v',
               f'scripts/multigpu/test_l3_batch_{suffix}.cu', '-o', str(out / (kind + '_sm80'))]
        write_json(out / (kind + '_command.json'), cmd)
        if args.packed_compact:
            cmd.insert(1, '-DL3_TEST_PACKED_COMPACT=1')
            write_json(out / (kind + '_command.json'), cmd)
        with (out / (kind + '_build.log')).open('w') as log:
            rc = subprocess.run(cmd, cwd=src, stdout=log, stderr=subprocess.STDOUT).returncode
        (out / (kind + '_rc.txt')).write_text(str(rc) + '\n')
        print(kind, 'BUILD_RC', rc, flush=True)
        return rc

    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        results = list(pool.map(build, variants.items()))
    if any(results):
        raise SystemExit(1)
    hashes = {str(p.relative_to(out)): sha256(p) for p in sorted(out.rglob('*')) if p.is_file()}
    write_json(out / 'manifest.json', {'valid_build': True, 'architecture': 'sm_80', 'assertions_enabled': True,
               'hashes': hashes, 'gpu_executed': False, 'packed_compact': args.packed_compact,
               'evidence_class': 'dirty_frozen_parallel_owner_fixtures'})
    print('BATCH_PARALLEL_BUILD_PASS', out, flush=True)


if __name__ == '__main__':
    main()
