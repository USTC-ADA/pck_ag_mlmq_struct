#!/usr/bin/env python3
"""Same-allocation NVML-on/off diagnostic; no clock setters or target acceptance."""
import argparse
import json
import os
from pathlib import Path
from statistics import median
import time
from l3_gpu_telemetry import NvmlObserver,parse_windows,summarize_window
from run_l3_batch_runtime import verify_tree,parse_runtime,parse_helpers,parse_admission,parse_services,parse_poll,parse_cache,parse_shared
from run_l3_30h import parse_dual_contract,parse_oracle_contract
from run_l3_upgrade_stage2 import slurm_preflight,clean_environment,sha256,write_json
from run_usa_road_matrix import run_one


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ('build','harness','contract','out'):parser.add_argument('--'+name,type=Path,required=True)
    args=parser.parse_args();build=args.build.resolve(strict=True);harness=args.harness.resolve(strict=True)
    bm,hm=verify_tree(build),verify_tree(harness)
    if Path(__file__).resolve()!=harness/'source/scripts/multigpu/telemetry_l3_batch_runtime.py':parser.error('use frozen runner')
    contract=json.loads(args.contract.read_text());graph=Path(contract['graph_path']);oracle=Path(contract['oracle_path'])
    if sha256(graph)!=contract['graph_sha256'] or sha256(oracle)!=contract['oracle_sha256']:raise ValueError('input hash mismatch')
    args.out.mkdir(parents=True,exist_ok=False);out=args.out.resolve();allocation=slurm_preflight(out)
    devices=[(int(row.split(',')[0]),row.split(',')[1].strip()) for row in allocation['gpus']]
    if [x[0] for x in devices]!=[0,1] or os.environ.get('CUDA_VISIBLE_DEVICES') not in ('0,1',','.join(x[1] for x in devices)):
        raise ValueError('cannot prove CUDA ordinal to NVML UUID mapping')
    observer=NvmlObserver(devices)
    configs=[('C2_107','control',107,0,1,0),('data','batch',97,0,1,0),
             ('helper_sleep','batch',97,1,0,0),('rx_sleep','batch',97,2,0,0),('loans','batch',97,3,1,1)]
    cases=[(*case,enabled) for case in configs for enabled in (0,1)]
    write_json(out/'manifest.json',{'build_path':str(build),'build':bm,'harness_path':str(harness),'harness':hm,'input_contract':contract,
        'allocation':allocation,'nvml':observer.metadata,'cases':cases,'rounds':2,'warmups':1,'repeats':3,
        'scope':'dirty frozen diagnostic; same-capability single absent; production racecheck failures remain'})
    results={}
    try:
        for order in range(2):
            for label,kind,workers,services,poll,admit,enabled in (cases if order==0 else reversed(cases)):
                key=f'r{order}_{label}_nvml{enabled}';runtime=int(kind=='batch')
                env=clean_environment();env.update(MLMQ_WORK_BLOCKS=str(workers),MLMQ_CUT_PERCENT=str(contract['cut_percent']),
                    BENCH_SOURCE=str(contract['source']),BENCH_WARMUPS='1',BENCH_REPEATS='3',CUDA_MODULE_LOADING='EAGER',L3_SUPPLEMENT_ORACLE=str(oracle),
                    MLMQ_BATCH_ENABLED=str(runtime),MLMQ_BATCH_FORCE='0',MLMQ_BATCH_SLOTS='128',MLMQ_BATCH_BUDGET='512',MLMQ_BATCH_MIN_SEEDS='1',
                    MLMQ_BATCH_HELPER_BLOCKS='8',MLMQ_BATCH_ADMIT=str(admit),MLMQ_BATCH_PROBE_CALLS=str(admit),MLMQ_BATCH_SERVICES=str(services),
                    MLMQ_BATCH_SERVICE_POLL=str(poll),MLMQ_BATCH_SERVICE_CARVEOUT='-1',MLMQ_BATCH_SERVICE_SHARED_BYTES='0')
                print('RUN',key,flush=True);started=time.monotonic_ns();observations=None
                if enabled:observer.start()
                try:r=run_one(build/('mlmq_'+kind),graph,'MLMQ',2,out/key,env,contract['source'],'L1SLF_L2DQ',1,3,180,delta=contract['delta'])
                finally:
                    if enabled:observations=observer.stop(out/(key+'.nvml.json'))
                finished=time.monotonic_ns();r.update(environment=env,observer_enabled=enabled,start_ns=started,end_ns=finished);results[key]=r
                write_json(out/'status.json',{'complete':False,'results':results})
                try:
                    if not r['valid']:raise ValueError(r['reason'])
                    raw=(out/(key+'.log')).read_text();r['oracle']=parse_oracle_contract(raw,4,contract['vertices'])
                    r['dual']=parse_dual_contract(raw,4,workers,contract['delta'],19,expected_window_mode=2,expected_window_min=25000,
                        expected_window_max=25000,expected_idle_backoff=0,require_l2_final=True,expected_worker_recovery=1,expected_ack_capacity=1712)
                    if not r['oracle']['valid'] or not r['dual']['valid']:raise ValueError('oracle/dual contract failed')
                    r['timing']=parse_windows(raw,4,1,started,finished)
                    if runtime:
                        rt=parse_runtime(raw,4,512,0,False);r['runtime']=rt;r['helpers']=parse_helpers(raw,4,8,rt)
                        r['admission']=parse_admission(raw,4,admit,rt);r['services']=parse_services(raw,4,services,admit)
                        r['poll']=parse_poll(raw,4,poll);r['cache']=parse_cache(raw,4,-1);r['shared']=parse_shared(raw,4,0)
                        if admit and not sum(x['loans'] for x in rt):raise ValueError('no admitted loans')
                    if enabled:
                        r['telemetry']=[summarize_window(w,observations['rows']) for w in r['timing']]
                        r['telemetry_coverage_valid']=all(x['coverage_valid'] for x in r['telemetry'])
                        r['telemetry_sha256']=sha256(out/(key+'.nvml.json'))
                except Exception as error:
                    r.update(valid=False,error=str(error));write_json(out/'status.json',{'complete':False,'results':results});raise
                write_json(out/'status.json',{'complete':False,'results':results});print('PASS',key,flush=True)
    finally:observer.close()
    grouped={}
    for label,*_ in configs:
        grouped[label]={}
        for enabled in (0,1):
            samples=[s for order in range(2) for s in results[f'r{order}_{label}_nvml{enabled}']['samples'] if s['warmup']=='0']
            grouped[label][str(enabled)]={f:{'samples_ms':[float(s[f]) for s in samples],'median_ms':median(float(s[f]) for s in samples)} for f in ('solve_ms','query_wall_ms')}
        grouped[label]['nvml_on_minus_off_ms']={f:grouped[label]['1'][f]['median_ms']-grouped[label]['0'][f]['median_ms'] for f in ('solve_ms','query_wall_ms')}
    verify_tree(build);verify_tree(harness)
    summary={'valid':True,'results':results,'grouped':grouped,'telemetry_coverage_valid':all(r.get('telemetry_coverage_valid',True) for r in results.values()),'performance_acceptance':False,'queries':80}
    write_json(out/'summary.json',summary);write_json(out/'status.json',{'complete':True,'results':results})
    print('READONLY_TELEMETRY_SCREEN_PASS',summary['telemetry_coverage_valid'],flush=True)


if __name__=='__main__':main()
