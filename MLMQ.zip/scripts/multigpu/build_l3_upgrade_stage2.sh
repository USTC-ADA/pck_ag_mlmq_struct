#!/usr/bin/env bash
set -euo pipefail

ROOT=$(cd -P "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd -P)
if [[ $# -ne 1 ]]; then
    echo "usage: $0 NEW_OUTPUT_DIRECTORY" >&2
    exit 2
fi
REQUESTED_OUT=$1
if [[ -e "$REQUESTED_OUT" || -L "$REQUESTED_OUT" ]]; then
    echo "output already exists: $REQUESTED_OUT" >&2
    exit 2
fi
if [[ -n "$(git -C "$ROOT" status --porcelain=v1)" ]]; then
    echo "stage2 build requires a clean committed worktree" >&2
    git -C "$ROOT" status --short >&2
    exit 2
fi

BLOCKED_BUILD_ENV=(
    NVCC_PREPEND_FLAGS NVCC_APPEND_FLAGS CPATH C_INCLUDE_PATH
    CPLUS_INCLUDE_PATH OBJC_INCLUDE_PATH LIBRARY_PATH LD_PRELOAD
    LD_LIBRARY_PATH CUDAFLAGS CFLAGS CXXFLAGS CPPFLAGS LDFLAGS LIBS
    COMPILER_PATH GCC_EXEC_PREFIX CUDA_HOME CUDA_PATH CUDAHOSTCXX NVCC_CCBIN
)
for variable in "${BLOCKED_BUILD_ENV[@]}"; do
    if [[ -v "$variable" ]]; then
        echo "compiler-influencing environment variable is forbidden: $variable" >&2
        exit 2
    fi
done

NVCC=${NVCC:-nvcc}
BOOST_INCLUDE_DIR=${BOOST_INCLUDE_DIR:-/a100-data/wyh/boost_1_87_0}
NVCC=$(readlink -f "$(command -v "$NVCC")")
if [[ ! -d "$BOOST_INCLUDE_DIR" ]]; then
    echo "Boost include directory not found: $BOOST_INCLUDE_DIR" >&2
    exit 2
fi

mkdir -p "$(dirname "$REQUESTED_OUT")"
mkdir "$REQUESTED_OUT"
OUT=$(cd -P "$REQUESTED_OUT" && pwd -P)
mkdir "$OUT/tools"

python3 "$ROOT/scripts/multigpu/test_rx_versioned_coalesce.py" \
    --output "$OUT/tools/rx_coalesce_model_result.json" \
    > "$OUT/tools/test_rx_versioned_coalesce.log"

FIXTURE_COMMAND=(
    "$NVCC" "$ROOT/scripts/multigpu/test_l3_rx_versioned_coalesce.cu"
    -std=c++17 -O3 -m64 -gencode=arch=compute_80,code=sm_80
    -o "$OUT/tools/test_l3_rx_versioned_coalesce"
)
python3 - "$OUT/tools/cuda_fixture_command.json" \
    "${FIXTURE_COMMAND[@]}" <<'PY'
import json
import pathlib
import sys
pathlib.Path(sys.argv[1]).write_text(json.dumps(sys.argv[2:], indent=2) + "\n")
PY
"${FIXTURE_COMMAND[@]}" > "$OUT/tools/cuda_fixture_build.log" 2>&1

COMMON=(
    "$ROOT/SSSP/main.cu"
    "$ROOT/SSSP/csr_graph.cu"
    "$ROOT/SSSP/sssp_run.cu"
    -DWORK_COUNT=false
    -DMLMQ_WORKER_THREADS=512
    -DBNUM=8
    -DBUCKET_MAX=4
    -Dl2_batch_size=8
    -DL3_COOPERATIVE_COLLECT=true
    -DL3_DIRECT_RX=true
    -DL3_RETAIN_TX=true
    -DL3_WINDOW_MODE=2
    -DL3_WINDOW_MIN_CYCLES=25000ull
    -DL3_WINDOW_MAX_CYCLES=25000ull
    -DL3_IDLE_BACKOFF=false
    -DL3_WORKER_RECOVERY=true
    -DL3_TERM_WAIT_ACK=true
    -DL3_ACK_SCAN=true
    -DL3_ACK_WIDE_SCAN=true
    -DL3_BOUNDARY_INDEX=true
    -DL3_L2_FINAL_COUNTS=true
    -DDQ_COUNTER_OVERFLOW_GUARD=true
    -DL3_CHAIN_SHORTCUTS=false
    -DL3_CHAIN_PARTITION=false
    -DL3_IDLE_TOKEN_PROBE=true
    -DL3_TERM_ONLY_WORKER=true
    -O3 -m64 -gencode=arch=compute_80,code=sm_80 -rdc=true
    -Xptxas -v
    -lcuda -lcudart -w
    "-I$ROOT/core/include" "-I$BOOST_INCLUDE_DIR" -lcusparse
)

build_variant() {
    local name=$1
    shift
    local directory="$OUT/$name"
    mkdir "$directory"
    local command=("$NVCC" "${COMMON[@]}" "$@" -o "$directory/mlmq")
    python3 - "$directory/command.json" "${command[@]}" <<'PY'
import json
import pathlib
import sys
pathlib.Path(sys.argv[1]).write_text(json.dumps(sys.argv[2:], indent=2) + "\n")
PY
    set +e
    "${command[@]}" > "$directory/build.log" 2>&1
    local rc=$?
    set -e
    printf '{"rc":%d}\n' "$rc" > "$directory/status.json"
    if [[ $rc -ne 0 ]]; then
        cat "$directory/build.log" >&2
        return "$rc"
    fi
    cuobjdump --dump-resource-usage "$directory/mlmq" \
        > "$directory/resource_usage.txt" 2>&1
    sha256sum "$directory/mlmq" "$directory/command.json" \
        "$directory/build.log" "$directory/resource_usage.txt" \
        "$directory/status.json" > "$directory/SHA256SUMS"
}

build_variant control
build_variant treatment -DL3_RX_VERSIONED_COALESCE=true
build_variant diagnostic \
    -DL3_RX_VERSIONED_COALESCE=true \
    -DL3_RX_VERSIONED_COALESCE_DIAG=true

tar -czf "$OUT/source.tgz" -C "$ROOT" \
    SSSP core \
    scripts/multigpu/test_rx_versioned_coalesce.py \
    scripts/multigpu/test_l3_rx_versioned_coalesce.cu \
    scripts/multigpu/build_l3_upgrade_stage2.sh \
    scripts/multigpu/run_l3_upgrade_stage2.py \
    evidence/l3_algorithm_upgrade_20260924/stage2_contract.json

python3 - "$OUT" "$ROOT" "$NVCC" "$BOOST_INCLUDE_DIR" <<'PY'
import datetime
import hashlib
import json
import pathlib
import re
import subprocess
import sys

out, root, nvcc, boost = map(pathlib.Path, sys.argv[1:])

def sha(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()

def target_resources(path):
    text = path.read_text()
    pattern = re.compile(
        r"Function (?P<name>[^\n]*work_block_kernel[^\n]*12l1_SLF_queue"
        r"[^\n]*14l2_delta_queue[^\n]*):\n"
        r"\s+REG:(?P<registers>\d+) STACK:(?P<stack>\d+) "
        r"SHARED:(?P<shared>\d+)")
    matches = list(pattern.finditer(text))
    if len(matches) != 1:
        raise SystemExit(f"expected one L1SLF/L2DQ worker resource row in {path}")
    row = matches[0].groupdict()
    return {key: int(value) for key, value in row.items() if key != "name"}

commands = {
    role: json.loads((out / role / "command.json").read_text())
    for role in ("control", "treatment", "diagnostic")
}

def normalized(command, removed_macros=()):
    command = list(command)
    output_index = command.index("-o")
    del command[output_index:output_index + 2]
    for macro in removed_macros:
        command.remove(macro)
    return command

mechanism = "-DL3_RX_VERSIONED_COALESCE=true"
diagnostic = "-DL3_RX_VERSIONED_COALESCE_DIAG=true"
only_treatment_macro_differs = (
    mechanism not in commands["control"] and
    diagnostic not in commands["control"] and
    mechanism in commands["treatment"] and
    diagnostic not in commands["treatment"] and
    normalized(commands["control"]) ==
        normalized(commands["treatment"], (mechanism,)) and
    normalized(commands["control"]) ==
        normalized(commands["diagnostic"], (mechanism, diagnostic))
)
if not only_treatment_macro_differs:
    raise SystemExit("control/treatment compiler attribution check failed")

command_contract = {
    "valid": True,
    "only_treatment_macro_differs": True,
    "treatment_only_macro": mechanism,
    "diagnostic_only_macro": diagnostic,
}
(out / "command_contract.json").write_text(
    json.dumps(command_contract, indent=2, sort_keys=True) + "\n")

resources = {
    name: target_resources(out / name / "resource_usage.txt")
    for name in ("control", "treatment", "diagnostic")
}
for name in ("treatment", "diagnostic"):
    if resources[name]["registers"] > 96:
        raise SystemExit(f"W512 {name} register gate failed: {resources}")

artifact_relatives = [
    "control/mlmq", "treatment/mlmq", "diagnostic/mlmq",
    "control/command.json", "treatment/command.json",
    "diagnostic/command.json", "command_contract.json", "source.tgz",
    "tools/test_l3_rx_versioned_coalesce",
    "tools/cuda_fixture_command.json", "tools/cuda_fixture_build.log",
    "tools/test_rx_versioned_coalesce.log",
    "tools/rx_coalesce_model_result.json",
]
artifacts = {}
for relative in artifact_relatives:
    path = out / relative
    artifacts[relative] = {"bytes": path.stat().st_size, "sha256": sha(path)}

payload = {
    "schema": 1,
    "status": "complete",
    "created_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "root": str(root),
    "head": subprocess.check_output(
        ["git", "-C", str(root), "rev-parse", "HEAD"], text=True).strip(),
    "branch": subprocess.check_output(
        ["git", "-C", str(root), "branch", "--show-current"], text=True).strip(),
    "git_status": subprocess.check_output(
        ["git", "-C", str(root), "status", "--porcelain=v1"], text=True
    ).splitlines(),
    "nvcc": str(nvcc),
    "nvcc_version": subprocess.check_output([str(nvcc), "--version"], text=True),
    "boost_include_dir": str(boost),
    "architecture": "sm_80",
    "worker_threads": 512,
    "resources": resources,
    "command_contract": command_contract,
    "artifacts": artifacts,
    "roles": {
        "control": "control/mlmq",
        "treatment": "treatment/mlmq",
        "diagnostic": "diagnostic/mlmq",
        "cuda_fixture": "tools/test_l3_rx_versioned_coalesce"
    }
}
(out / "manifest.json").write_text(
    json.dumps(payload, indent=2, sort_keys=True) + "\n")
PY
sha256sum "$OUT/manifest.json" > "$OUT/manifest.sha256"
printf 'L3_UPGRADE_STAGE2_BUILD_PASS out=%s head=%s\n' \
    "$OUT" "$(git -C "$ROOT" rev-parse HEAD)"
