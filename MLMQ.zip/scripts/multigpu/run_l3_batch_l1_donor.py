#!/usr/bin/env python3
"""Run a frozen compact + nonempty remote RX + two real-L2 fixture, never solver/performance evidence."""
import argparse
import json
from pathlib import Path
import re
import subprocess

from run_l3_compact_screen import sanitizer_passed
from run_l3_batch_peer_commit import verify_build as verify_peer_build
from run_l3_upgrade_stage2 import ROOT, clean_environment, sha256, slurm_preflight, write_json


def parse_cases(raw, quick):
    fields = ('owner', 'begin', 'seeds', 'duplicate', 'prime', 'rounds', 'loans',
              'ancestors', 'exported', 'remote_records', 'packets', 'remote_delays',
              'local_delays', 'wrapped', 'source_writes', 'remote_writes')
    pattern = '^BATCH_L1_DONOR_CASE ' + ' '.join(k + r'=(\d+)' for k in fields) + ' PASS$'
    rows = [dict(zip(fields, map(int, values))) for values in re.findall(pattern, raw, re.MULTILINE)]
    expected = sorted((o,b,n,d,p) for o in (0,1) for b in ((37,) if quick else (0,37))
                      for n in ((7,32) if quick else (1,7,32))
                      for d in ((1,) if quick else (0,1)) for p in ((5,) if quick else (0,5)))
    if sorted((r['owner'],r['begin'],r['seeds'],r['duplicate'],r['prime']) for r in rows) != expected:
        raise ValueError('missing/duplicate/wrong L1 cases')
    rounds = 2 if quick else 3
    for r in rows:
        unique = (r['seeds']+1)//2 if r['duplicate'] else r['seeds']
        wrapped = sum((8*r['prime']+(8+r['seeds'])*g+8)%64+r['seeds'] >= 64 for g in range(rounds))
        if (r['rounds'] != rounds or r['loans'] != rounds or
                r['ancestors'] != 8*(r['prime']+rounds) or r['exported'] != rounds*r['seeds'] or
                r['remote_records'] != rounds*unique or
                not rounds <= r['packets'] <= rounds*3 or r['remote_delays'] != r['packets'] or
                not rounds <= r['local_delays'] <= rounds*3 or r['wrapped'] != wrapped or
                r['source_writes'] != r['ancestors']+rounds*unique or r['remote_writes'] != 8+2*rounds*unique):
            raise ValueError('incomplete L1 responsibility/queue coverage')
    marker = (f'BATCH_L1_DONOR_PASS cases={len(expected)} real_ml_read=1 real_slf=1 actual_remote=1 '
              'no_worker_ack=1 no_solver=1 no_performance=1')
    if raw.splitlines().count(marker) != 1:
        raise ValueError('missing/duplicate scope marker')
    return rows


def verify_build(build):
    manifest = verify_peer_build(build)
    required = {'source/SSSP/l3/l3_batch_l1_donor.cuh', 'source/core/src/ml_queue.cu',
                'source/core/src/l1_queue.cu', 'source/core/include/ml_queue.cuh',
                'source/scripts/multigpu/run_l3_batch_l1_donor.py',
                'source/scripts/multigpu/test_l3_batch_l1_donor.cu'}
    if not required.issubset(manifest['hashes']):
        raise ValueError('missing remote build dependencies')
    return manifest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for arg in ('build', 'sanitizer', 'out'):
        parser.add_argument('--' + arg, required=True, type=Path)
    args = parser.parse_args()
    build = args.build.resolve(strict=True)
    manifest = verify_build(build)  # validates the submit-time snapshot, not live worktree
    if Path(__file__).resolve() != build / 'source/scripts/multigpu/run_l3_batch_l1_donor.py':
        parser.error('execute the frozen runner under BUILD/source, not the live worktree')
    if args.out.exists() or args.out.is_symlink():
        parser.error('output must not exist')
    args.out.mkdir(parents=True)
    out = args.out.resolve()
    allocation = slurm_preflight(out)
    sanitizer = args.sanitizer.resolve(strict=True)
    sanitizer_hash = sha256(sanitizer)
    write_json(out / 'manifest.json', {'allocation': allocation, 'build': str(build),
        'build_manifest_sha256': sha256(build / 'manifest.json'), 'snapshot': manifest,
        'sanitizer': str(sanitizer), 'sanitizer_sha256': sanitizer_hash,
        'evidence_class': 'exploratory_real_ml_read_slf_remote_no_worker_ack_no_solver_no_performance'})
    status = {}
    environment = clean_environment()
    environment['CUDA_MODULE_LOADING'] = 'EAGER'
    for stage, tool, quick in (('smoke', None, True), ('normal', None, False),
                               ('memcheck', 'memcheck', True), ('racecheck', 'racecheck', True),
                               ('synccheck', 'synccheck', True)):
        journal_dir = out / (stage + '_journals')
        journal_dir.mkdir()
        command = [str(build / 'test_sm80'), str(journal_dir)] + (['--quick'] if quick else [])
        if tool:
            command = [str(sanitizer), '--tool', tool, '--error-exitcode', '9'] + command
        print('RUN', stage, flush=True)
        status[stage] = {'command': command, 'quick': quick, 'sanitizer': tool, 'state': 'running'}
        write_json(out / 'status.json', {'complete': False, 'results': status})
        try:
            with (out / (stage + '.log')).open('w') as log:
                process = subprocess.run(command, cwd=ROOT, env=environment,
                                         stdout=log, stderr=subprocess.STDOUT, timeout=300)
            raw = (out / (stage + '.log')).read_text()
            status[stage]['rc'] = process.returncode
            if process.returncode or not sanitizer_passed(raw, tool):
                raise RuntimeError('failed fixture or sanitizer')
            status[stage]['cases'] = parse_cases(raw, quick)
            paths = sorted(journal_dir.glob('*.journal.txt'))
            if len(paths) != len(status[stage]['cases']) or any(not p.stat().st_size for p in paths):
                raise RuntimeError('missing raw journals')
            audits = sorted(journal_dir.glob('*.audit.txt'))
            if len(audits) != len(paths) or any(not p.stat().st_size for p in audits):
                raise RuntimeError('missing raw graph/distance/multiplicity audits')
            status[stage]['raw_artifacts'] = {p.name: sha256(p) for p in paths + audits}
            apps = subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid', '--format=csv,noheader'], text=True)
            if apps.strip():
                raise RuntimeError('GPU process remains; no cleanup attempted')
            status[stage]['state'] = 'passed'
        except Exception as error:
            status[stage].update(state='failed', error=str(error))
            write_json(out / 'status.json', {'complete': False, 'results': status})
            raise
        write_json(out / 'status.json', {'complete': False, 'results': status})
        print('PASS', stage, flush=True)
    if verify_build(build) != manifest or sha256(sanitizer) != sanitizer_hash:
        raise RuntimeError('provenance changed during run')
    write_json(out / 'summary.json', {'valid': True, 'results': status,
        'normal_cases': 48, 'normal_loans': 144, 'quick_cases': 4, 'quick_loans': 8,
        'actual_compact': True, 'actual_remote': True, 'actual_dq': True,
        'real_ml_read': True, 'real_slf_write_read': True, 'authoritative_seed_snapshot': True,
        'reserve_before_removal': True, 'blocked_refill_during_loan': True,
        'real_worker_ack': False, 'solver_integration': False, 'performance_evidence': False})
    write_json(out / 'status.json', {'complete': True, 'results': status})
    print('BATCH_L1_DONOR_PIPELINE_PASS no_solver_no_performance=1', flush=True)


if __name__ == '__main__':
    main()
