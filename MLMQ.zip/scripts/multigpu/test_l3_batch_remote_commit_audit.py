import copy
import unittest
from audit_l3_batch_remote_commit import FIRST_GENERATION, verify_receipts


def fixture():
    journals = {0: {'records': [(v, v + 1, 2147483647) for v in range(64)]}}
    receipts = {}
    for epoch in (1, 2):
        start, end = (epoch - 1) * 32, epoch * 32
        for role in (0, 1):
            receipts[epoch, role] = dict(epoch=epoch, generation=FIRST_GENERATION, start=start, end=end,
                count=32, loan=0 if role == 0 else -1, acked=1,
                payload=[(v, v + 1) for v in range(start, end)])
    return journals, receipts


class ReceiptAuditTests(unittest.TestCase):
    def test_complete_distinct_windows(self):
        j, r = fixture(); self.assertEqual(verify_receipts(j, r, 0), (2, 64))

    def test_duplicate_window_cannot_hide_missing_window(self):
        j, r = fixture()
        for role in (0, 1):
            r[2, role] = {**copy.deepcopy(r[1, role]), 'epoch': 2}
        with self.assertRaisesRegex(ValueError, 'duplicate/unknown'):
            verify_receipts(j, r, 0)

    def test_missing_receipt(self):
        j, r = fixture(); del r[2, 1]
        with self.assertRaises(ValueError): verify_receipts(j, r, 0)

    def test_ack_generation_and_window_corruption(self):
        for key, value in [('acked', 0), ('generation', 1), ('start', 1)]:
            j, r = fixture(); r[1, 1][key] = value
            with self.subTest(key=key), self.assertRaises(ValueError): verify_receipts(j, r, 0)

    def test_forged_matching_payload_still_checked_against_journal(self):
        j, r = fixture()
        for role in (0, 1): r[1, role]['payload'][0] = (0, 0)
        with self.assertRaisesRegex(ValueError, 'payload'): verify_receipts(j, r, 0)


if __name__ == '__main__': unittest.main()
