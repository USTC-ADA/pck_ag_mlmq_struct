#!/usr/bin/env python3
"""Run a frozen real-peer + real-L2 fixture, never solver/performance evidence."""
import argparse
import json
from pathlib import Path
import re
import subprocess

from run_l3_compact_screen import sanitizer_passed
from run_l3_upgrade_stage2 import ROOT, clean_environment, sha256, slurm_preflight, write_json


def parse_cases(raw, quick):
    pattern = (r'^BATCH_PEER_COMMIT_CASE owner=(\d+) helper=(\d+) begin=(\d+) group=(\d+) '
               r'rounds=(\d+) fallbacks=(\d+) distinct512=(\d+) capacity_stops=(\d+) '
               r'total_writes=(\d+) flushes=(\d+) consumed_before_ack=(\d+) PASS$')
    fields = ('owner', 'helper', 'begin', 'group', 'rounds', 'fallbacks', 'distinct512',
              'capacity_stops', 'total_writes', 'flushes', 'consumed_before_ack')
    rows = [dict(zip(fields, map(int, values))) for values in re.findall(pattern, raw, re.MULTILINE)]
    expected = sorted((o, 1 - o, b, g) for o in (0, 1)
                      for b in ((37,) if quick else (0, 37))
                      for g in ((33, 1024) if quick else (33, 768, 1024)))
    keys = [(r['owner'], r['helper'], r['begin'], r['group']) for r in rows]
    if sorted(keys) != expected:
        raise ValueError('missing/duplicate/wrong peer fixture cases')
    rounds = 5 if quick else 20
    for row in rows:
        if (row['rounds'] != rounds or row['fallbacks'] != rounds // 5 * 2 or
                row['total_writes'] <= 8 or row['flushes'] < 1 or row['consumed_before_ack'] < 1 or
                row['consumed_before_ack'] > rounds or
                (row['group'] >= 512 and row['distinct512'] < 1) or
                (row['group'] == 1024 and row['capacity_stops'] < 1)):
            raise ValueError('incomplete correctness coverage')
    marker = (f'BATCH_PEER_COMMIT_PASS cases={len(expected)} actual_peer=1 actual_dq=1 '
              'no_remote_sink=1 no_l1=1 no_solver=1 not_performance=1')
    if raw.splitlines().count(marker) != 1:
        raise ValueError('missing/duplicate final pass marker')
    return rows


def verify_build(build):
    manifest = json.loads((build / 'manifest.json').read_text())
    if (manifest.get('valid_build') is not True or manifest.get('architecture') != 'sm_80' or
            manifest.get('assertions_enabled') is not True or not manifest.get('hashes')):
        raise ValueError('invalid build manifest')
    hashes = manifest['hashes']
    required = {'test_sm80', 'source.tgz', 'build_command.json',
                'source/scripts/multigpu/run_l3_batch_peer_commit.py',
                'source/scripts/multigpu/test_l3_batch_peer_commit.cu',
                'source/SSSP/l3/l3_batch_peer_commit.cuh'}
    if not required.issubset(hashes):
        raise ValueError('incomplete build manifest')
    for name, expected in hashes.items():
        path = (build / name).resolve(strict=True)
        if build not in path.parents or sha256(path) != expected:
            raise ValueError('changed or outside build artifact: ' + name)
    return manifest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for arg in ('build', 'sanitizer', 'out'):
        parser.add_argument('--' + arg, required=True, type=Path)
    args = parser.parse_args()
    build = args.build.resolve(strict=True)
    manifest = verify_build(build)  # validates the submit-time snapshot, not live worktree
    if Path(__file__).resolve() != build / 'source/scripts/multigpu/run_l3_batch_peer_commit.py':
        parser.error('execute the frozen runner under BUILD/source, not the live worktree')
    if args.out.exists() or args.out.is_symlink():
        parser.error('output must not exist')
    args.out.mkdir(parents=True)
    out = args.out.resolve()
    allocation = slurm_preflight(out)
    sanitizer = args.sanitizer.resolve(strict=True)
    sanitizer_hash = sha256(sanitizer)
    write_json(out / 'manifest.json', {'allocation': allocation, 'build': str(build),
        'build_manifest_sha256': sha256(build / 'manifest.json'), 'snapshot': manifest,
        'sanitizer': str(sanitizer), 'sanitizer_sha256': sanitizer_hash,
        'evidence_class': 'exploratory_real_peer_real_dq_no_solver_no_performance'})
    status = {}
    environment = clean_environment()
    environment['CUDA_MODULE_LOADING'] = 'EAGER'
    for stage, tool, quick in (('smoke', None, True), ('normal', None, False),
                               ('memcheck', 'memcheck', True), ('racecheck', 'racecheck', True),
                               ('synccheck', 'synccheck', True)):
        journal_dir = out / (stage + '_journals')
        journal_dir.mkdir()
        command = [str(build / 'test_sm80'), str(journal_dir)] + (['--quick'] if quick else [])
        if tool:
            command = [str(sanitizer), '--tool', tool, '--error-exitcode', '9'] + command
        print('RUN', stage, flush=True)
        status[stage] = {'command': command, 'quick': quick, 'sanitizer': tool, 'state': 'running'}
        write_json(out / 'status.json', {'complete': False, 'results': status})
        try:
            with (out / (stage + '.log')).open('w') as log:
                process = subprocess.run(command, cwd=ROOT, env=environment,
                                         stdout=log, stderr=subprocess.STDOUT, timeout=300)
            raw = (out / (stage + '.log')).read_text()
            status[stage]['rc'] = process.returncode
            if process.returncode or not sanitizer_passed(raw, tool):
                raise RuntimeError('failed fixture or sanitizer')
            status[stage]['cases'] = parse_cases(raw, quick)
            paths = sorted(journal_dir.glob('*.journal.txt'))
            if len(paths) != len(status[stage]['cases']) or any(not p.stat().st_size for p in paths):
                raise RuntimeError('missing raw journals')
            audits = sorted(journal_dir.glob('*.audit.txt'))
            if len(audits) != len(paths) or any(not p.stat().st_size for p in audits):
                raise RuntimeError('missing raw graph/distance/multiplicity audits')
            status[stage]['raw_artifacts'] = {p.name: sha256(p) for p in paths + audits}
            apps = subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid', '--format=csv,noheader'], text=True)
            if apps.strip():
                raise RuntimeError('GPU process remains; no cleanup attempted')
            status[stage]['state'] = 'passed'
        except Exception as error:
            status[stage].update(state='failed', error=str(error))
            write_json(out / 'status.json', {'complete': False, 'results': status})
            raise
        write_json(out / 'status.json', {'complete': False, 'results': status})
        print('PASS', stage, flush=True)
    if verify_build(build) != manifest or sha256(sanitizer) != sanitizer_hash:
        raise RuntimeError('provenance changed during run')
    write_json(out / 'summary.json', {'valid': True, 'results': status,
        'normal_cases': 12, 'normal_generations': 240, 'quick_cases_each_sanitizer': 4,
        'quick_generations_each_sanitizer': 20, 'actual_peer': True, 'actual_dq': True,
        'two_contending_helpers': True, 'both_owner_helper_directions': True,
        'nonzero_partition_begin': True, 'gpu_journals_cpu_validated': True,
        'active_and_post_apply_competition': True, 'invalid_return_fallback': True,
        'remote_publication': False, 'real_l1_loan': False, 'solver_integration': False,
        'performance_evidence': False})
    write_json(out / 'status.json', {'complete': True, 'results': status})
    print('BATCH_PEER_COMMIT_PIPELINE_PASS no_solver_no_performance=1', flush=True)


if __name__ == '__main__':
    main()
