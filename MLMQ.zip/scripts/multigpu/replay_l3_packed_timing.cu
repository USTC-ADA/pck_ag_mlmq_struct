// Diagnostic replay of historical eligible L1 seeds, not live transfer/solve.
// Build script inserts a read-only trace call into a frozen copy of packed.
#include <cuda_runtime.h>
#include <cassert>
#include <climits>
#include "../../SSSP/l3/l3_batch_compact_packed.cuh"
#include "l3_replay_graph_loader.h"
namespace packed=l3_batch_compact_packed;
namespace search=l3_batch_search_diag;
struct stats {int rows,scans;unsigned pending;};
template<int Policy>
__global__ void time_packed(relay::slot *slots,int *certs,stats *output,relay::graph_view graph,int graph_count) {
    __shared__ packed::workspace scratch[2];
    const int lane=threadIdx.x%32,warp=threadIdx.x/32;
    auto *work=scratch+warp;
    for(int i=blockIdx.x*2+warp;i<graph_count;i+=gridDim.x*2) {
        packed::expand_payload<false,false,Policy!=0,Policy==2?8:32>(slots+i,graph,work,certs+i*relay::result_capacity,512,lane);
        if(!lane)output[i]={work->rows,work->scans,work->tail-work->head};
    }
}
template<class T> static T *alloc(size_t n) {T *p=nullptr;cu(cudaMalloc(&p,n*sizeof(T)));return p;}
static void run_owner(const graph &g,const std::vector<batch> &all,device_graph *devices,
                      int owner,int limit,FILE *out) {
    std::vector<int> ids;
    for(size_t i=0;i<all.size();++i)if(all[i].gpu==owner && (!limit || int(ids.size())<limit))ids.push_back(int(i));
    const int n=int(ids.size());need(n>0,"no owner seeds");const int gpu=1-owner;cu(cudaSetDevice(gpu));
    auto slots=alloc<relay::slot>(n);auto certs=alloc<int>(n*relay::result_capacity);auto stat=alloc<stats>(n);
    std::vector<relay::slot> input(n),output(n);std::vector<int> certificate(n*relay::result_capacity);std::vector<stats> observed(n);
    for(int i=0;i<n;++i) {input[i].seeds=all[ids[i]].seeds.size();std::copy(all[ids[i]].seeds.begin(),all[ids[i]].seeds.end(),input[i].input);}
    const auto &first=all[ids[0]];
    relay::graph_view view{devices[gpu].rows+first.begin,devices[gpu].columns,devices[gpu].weights,first.begin,first.end-first.begin};
    cudaEvent_t start,stop;cu(cudaEventCreate(&start));cu(cudaEventCreate(&stop));
    for(int round=0;round<2;++round)for(int repeat=-1;repeat<5;++repeat)for(int pos=0;pos<3;++pos) {
        const int policy=round?2-pos:pos;
        cu(cudaMemcpy(slots,input.data(),n*sizeof(relay::slot),cudaMemcpyHostToDevice));cu(cudaStreamSynchronize(0));
        cu(cudaEventRecord(start));
        if(policy==0)time_packed<0><<<8,64>>>(slots,certs,stat,view,n);
        else if(policy==1)time_packed<1><<<8,64>>>(slots,certs,stat,view,n);
        else time_packed<2><<<8,64>>>(slots,certs,stat,view,n);
        cu(cudaGetLastError());cu(cudaEventRecord(stop));cu(cudaEventSynchronize(stop));
        float ms=0;cu(cudaEventElapsedTime(&ms,start,stop));
        cu(cudaMemcpy(output.data(),slots,n*sizeof(relay::slot),cudaMemcpyDeviceToHost));
        cu(cudaMemcpy(certificate.data(),certs,certificate.size()*sizeof(int),cudaMemcpyDeviceToHost));
        cu(cudaMemcpy(observed.data(),stat,n*sizeof(stats),cudaMemcpyDeviceToHost));
        for(int i=0;i<n;++i) {
            const auto &s=output[i];const auto &m=observed[i];
            need(s.result_status==relay::ok && s.seeds==input[i].seeds && s.results>0 && s.results<=packed::capacity,"invalid journal");
            for(int j=0;j<s.seeds;++j)need(s.input[j].vertex==input[i].input[j].vertex && s.input[j].distance==input[i].input[j].distance,"seed changed");
            fprintf(out,"{\"owner\":%d,\"executor\":%d,\"batch\":%d,\"round\":%d,\"repeat\":%d,\"policy\":%d,\"budget\":512,\"rows\":%d,\"scans\":%d,\"pending\":%u,\"journal\":[",owner,gpu,ids[i],round,repeat,policy,m.rows,m.scans,m.pending);
            for(int j=0;j<s.results;++j)fprintf(out,"%s[%d,%d,%d]",j?",":"",s.output[j].vertex,s.output[j].distance,certificate[i*relay::result_capacity+j]);
            fprintf(out,"]}\n");
        }
        fflush(out);printf("PACKED_TIME owner=%d executor=%d round=%d repeat=%d policy=%d batches=%d ms=%.9f helper_blocks=8 helper_warps=2 search=0 trace=0\n",owner,gpu,round,repeat,policy,n,ms);fflush(stdout);
    }
    cu(cudaEventDestroy(start));cu(cudaEventDestroy(stop));cu(cudaFree(slots));cu(cudaFree(certs));cu(cudaFree(stat));
}
int main(int argc,char **argv) {
    try {
        need(argc==6,"usage: trace GRAPH BATCHES ORACLE OUTPUT LIMIT_PER_OWNER");
        need(std::getenv("SLURM_JOB_ID"),"Slurm required");
        const int limit=std::stoi(argv[5]);need(limit>=0 && limit<=2048,"invalid limit");
        const auto g=load_graph(argv[1],argv[3]);const auto batches=load_batches(argv[2],g);
        int count=0;cu(cudaGetDeviceCount(&count));need(count==2,"exactly two GPUs required");
        device_graph devices[2];
        for(int gpu=0;gpu<2;++gpu) {
            cu(cudaSetDevice(gpu));int access=0,native=0;cu(cudaDeviceCanAccessPeer(&access,gpu,1-gpu));
            cu(cudaDeviceGetP2PAttribute(&native,cudaDevP2PAttrNativeAtomicSupported,gpu,1-gpu));need(access&&native,"P2P/native atomics required");
            devices[gpu].upload(g);
        }
        FILE *out=fopen(argv[4],"wx");need(out,"output exists or cannot open");
        for(int owner=0;owner<2;++owner)run_owner(g,batches,devices,owner,limit,out);
        need(fclose(out)==0,"output close");
        for(int gpu=0;gpu<2;++gpu) {cu(cudaSetDevice(gpu));devices[gpu].release();}
        printf("PACKED_TIMING_PASS captured=%zu limit=%d payload_only_not_solve=1\n",batches.size(),limit);
        return 0;
    }catch(const std::exception &e) {fprintf(stderr,"PACKED_TIMING_FAIL %s\n",e.what());return 2;}
}
