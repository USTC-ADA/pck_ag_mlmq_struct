#!/usr/bin/env python3
"""Validate a completed real L1 capture and emit deterministic offline batches.

No GPU work or synthetic fallback. Graph/oracle remain validation-only; the
replay algorithm receives captured authoritative seed labels, NOT oracle labels.
"""
from __future__ import annotations
import argparse
from collections import Counter
import json
from pathlib import Path
import re

from run_l3_balance_diag import parse_l1_supply
from run_l3_upgrade_stage2 import read_gr_header, sha256, write_json

INT_MAX = (1 << 31) - 1


def parse_capture(raw, vertices, cut):
    def records(prefix, fields):
        result = []
        for line in raw.splitlines():
            if not line.startswith(prefix + " "):
                continue
            pairs = re.findall(r"\b(\w+)=(-?\d+)\b", line)
            row = {key: int(value) for key, value in pairs}
            if len(pairs) != len(row) or set(row) != set(fields.split()):
                raise ValueError(f"malformed {prefix}")
            result.append(row)
        return result

    configs = records("L3_L1_CAPTURE_CONFIG", "gpu warps slots max_batch ids_zero_based observational")
    config = {row["gpu"]: row for row in configs}
    if len(configs) != 2 or set(config) != {0, 1}:
        raise ValueError("capture requires exactly two GPU configurations")
    for row in configs:
        if (not 8 <= row["warps"] <= 4096 or row["slots"] != 8 or row["max_batch"] != 32 or
                row["ids_zero_based"] != 1 or row["observational"] != 1):
            raise ValueError("unsupported capture configuration")
    batches = records("L3_L1_CAPTURE", "gpu bin slot warp begin end raw eligible inflight")
    items = records("L3_L1_CAPTURE_ITEM", "gpu bin slot index vertex queued authoritative processed degree eligible")
    tails = records("L3_Q2_TAIL", "gpu bin since total available local_term peer_term")
    tail_by_key = {(row["gpu"], row["bin"]): row for row in tails}
    if len(tail_by_key) != len(tails):
        raise ValueError("duplicate tail")
    by_key = {}
    for batch in batches:
        key = batch["gpu"], batch["bin"], batch["slot"]
        gpu, bin_id, slot = key
        if key in by_key or gpu not in config or not 0 <= bin_id < 128 or not 0 <= slot < 8:
            raise ValueError("duplicate or invalid batch key")
        warp = (bin_id * 37 + slot * 211) % config[gpu]["warps"]
        first_slot = next(i for i in range(8) if (bin_id * 37 + i * 211) % config[gpu]["warps"] == warp)
        if batch["warp"] != warp or first_slot != slot:
            raise ValueError("capture warp differs from deterministic selection")
        if (batch["begin"], batch["end"]) != ((0, cut) if gpu == 0 else (cut, vertices)):
            raise ValueError("capture partition mismatch")
        if not 0 <= batch["eligible"] <= batch["raw"] <= 32 or batch["inflight"] < 0:
            raise ValueError("capture count or responsibility mismatch")
        tail = tail_by_key.get((gpu, bin_id))
        if (tail is None or tail["since"] >> 21 != bin_id or tail["since"] <= 0 or
                tail["local_term"] not in (0, 1, 2) or tail["peer_term"] not in (0, 1, 2)):
            raise ValueError("unmatched or invalid tail metadata")
        by_key[key] = {**batch, "tail": tail, "items": {}}
    for item in items:
        key = item["gpu"], item["bin"], item["slot"]
        batch = by_key.get(key)
        index = item["index"]
        if batch is None or index in batch["items"] or not 0 <= index < batch["raw"]:
            raise ValueError("duplicate or unmatched captured item")
        if (not batch["begin"] <= item["vertex"] < batch["end"] or
                not 0 <= item["authoritative"] <= item["queued"] < INT_MAX or
                not 0 <= item["processed"] <= INT_MAX or item["degree"] < 0 or
                item["eligible"] != int(item["queued"] < item["processed"])):
            raise ValueError("invalid captured vertex/label/filter")
        batch["items"][index] = item
    result = []
    for key, batch in sorted(by_key.items()):
        ordered = [batch["items"][index] for index in sorted(batch["items"])]
        if len(ordered) != batch["raw"] or sum(row["eligible"] for row in ordered) != batch["eligible"]:
            raise ValueError("missing items or inconsistent eligibility")
        batch["items"] = ordered
        batch["seeds"] = [row for row in ordered if row["eligible"]]
        batch["quiet_observation"] = batch["tail"]["local_term"] == 0 and batch["tail"]["peer_term"] in (1, 2)
        result.append(batch)
    if {batch["gpu"] for batch in result if batch["seeds"]} != {0, 1}:
        raise ValueError("no nonempty captured batch on one or both GPUs")
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run", required=True, type=Path, help="completed run_l3_balance_diag output")
    parser.add_argument("--out", required=True, type=Path)
    args = parser.parse_args()
    if args.out.exists() or args.out.is_symlink():
        parser.error("output already exists")
    manifest = json.loads((args.run / "manifest.json").read_text())
    summary = json.loads((args.run / "summary.json").read_text())
    if (summary.get("valid") is not True or summary.get("rc") != 0 or
            summary.get("oracle_errors") or summary.get("dual_errors")):
        raise ValueError("capture run did not pass real dual-GPU oracle")
    graph, oracle = Path(manifest["graph"]), Path(manifest["oracle"])
    if sha256(graph) != manifest["graph_sha256"] or sha256(oracle) != manifest["oracle_sha256"]:
        raise ValueError("graph/oracle no longer matches capture manifest")
    header = read_gr_header(graph)
    if oracle.stat().st_size != header["vertices"] * 4:
        raise ValueError("oracle length mismatch")
    # Matches runtime integer partitioning, no source-driven recut.
    cut = header["vertices"] * manifest["cut_percent"] // 100
    raw = (args.run / "diagnostic.log").read_text()
    supply = parse_l1_supply(raw)
    if supply["errors"]:
        raise ValueError(f"supply evidence failed: {supply['errors']}")
    batches = parse_capture(raw, header["vertices"], cut)
    capture_warps = {int(gpu): int(warps) for gpu, warps in re.findall(
        r"^L3_L1_CAPTURE_CONFIG gpu=(\d+) warps=(\d+)", raw, re.MULTILINE)}
    if capture_warps != {row["gpu"]: row["warps"] for row in supply["configs"]}:
        raise ValueError("capture/supply warp geometry mismatch")
    supply_by_key = {(row["gpu"], row["bin"]): row for row in supply["samples"]}
    observed = Counter()
    for batch in batches:
        key = batch["gpu"], batch["bin"]
        observed[(key, "raw")] += batch["raw"]
        observed[(key, "eligible")] += batch["eligible"]
        observed[(key, "edges")] += sum(seed["degree"] for seed in batch["seeds"])
    if any(value > supply_by_key[key][field] for (key, field), value in observed.items()):
        raise ValueError("captured subset exceeds observed supply")
    # Never merge distinct asynchronous warps/bins into a fictitious big batch.
    selected = [batch for batch in batches if batch["seeds"]]
    last_bin = {gpu: max(row["bin"] for row in supply["samples"] if row["gpu"] == gpu) for gpu in (0, 1)}
    lines = [f"L3_REAL_BATCH_V1 {header['vertices']} {header['edges']} {len(selected)}"]
    for batch in selected:
        tail = batch["tail"]
        lines.append(" ".join(map(str, [batch["gpu"], batch["bin"], batch["slot"], batch["warp"],
            batch["begin"], batch["end"], tail["local_term"], tail["peer_term"], tail["available"],
            batch["inflight"], len(batch["seeds"])])))
        for seed in batch["seeds"]:
            lines.append(" ".join(str(seed[key]) for key in ("vertex", "queued", "authoritative", "processed", "degree")))
    args.out.mkdir(parents=True)
    (args.out / "batches.txt").write_text("\n".join(lines) + "\n")
    write_json(args.out / "capture.json", {
        "evidence_class": "asynchronous_real_capture_not_transfer_or_timing", "manifest": manifest,
        "diagnostic_sha256": sha256(args.run / "diagnostic.log"),
        "batches_sha256": sha256(args.out / "batches.txt"), "batches": batches,
        "nonempty_batches": len(selected),
        "quiet_nonempty_batches": sum(batch["quiet_observation"] for batch in selected),
        "late_half_quiet_nonempty_batches": sum(batch["quiet_observation"] and batch["bin"] * 2 >= last_bin[batch["gpu"]] for batch in selected),
        "last_observed_bin_by_gpu": last_bin,
        "zero_inflight_nonempty_batches": sum(batch["inflight"] == 0 for batch in selected),
        "seed_count_histogram": dict(sorted(Counter(len(batch["seeds"]) for batch in selected).items())),
        "duplicate_seed_entries": sum(len(batch["seeds"]) - len({seed["vertex"] for seed in batch["seeds"]}) for batch in selected),
        "limits": "No coherent destination-label snapshot; cannot infer actual winners, transferable unique work, or solve speedup.",
    })
    print(json.dumps({"valid": True, "nonempty_batches": len(selected), "out": str(args.out)}))


if __name__ == "__main__":
    main()
