#!/usr/bin/env python3
"""Run actual mirror/packed executor and independently audit every journal."""
import argparse
import json
import re
from pathlib import Path
import subprocess
from run_l3_batch_runtime import verify_tree
from run_l3_upgrade_stage2 import slurm_preflight, write_json
from run_l3_compact_screen import sanitizer_passed
from l3_bound_fixture import audit_file, audit_selection_file


def main():
    p = argparse.ArgumentParser(description=__doc__)
    for key in ('fixture', 'harness', 'sanitizer', 'out'):
        p.add_argument('--'+key, type=Path, required=True)
    args = p.parse_args()
    fixture, harness = args.fixture.resolve(), args.harness.resolve()
    fm, hm = verify_tree(fixture), verify_tree(harness)
    if Path(__file__).resolve() != harness/'source/scripts/multigpu/run_l3_bound.py':
        p.error('execute frozen runner')
    args.out.mkdir(parents=True, exist_ok=False)
    allocation = slurm_preflight(args.out)
    write_json(args.out/'manifest.json', dict(fixture=fm, harness=hm, allocation=allocation))
    results = {}
    inputs = json.loads((fixture/'inputs/cases.json').read_text())
    case_count = len(inputs)
    selection=any(c.get('selection_comparison') for c in inputs)
    expected_records=sum(24 if c.get('selection_comparison') else 12 for c in inputs)
    for label in ('normal', 'memcheck', 'racecheck', 'synccheck'):
        output = args.out/(label+'.jsonl')
        cmd = [str(fixture/'fixture'), str(fixture/'inputs/cases.txt'), str(output)]
        if label != 'normal':
            cmd = [str(args.sanitizer.resolve()), '--tool', label, '--error-exitcode', '9']+cmd
        with (args.out/(label+'.log')).open('w') as log:
            rc = subprocess.run(cmd, stdout=log, stderr=subprocess.STDOUT, timeout=240).returncode
        raw = (args.out/(label+'.log')).read_text()
        ok = rc == 0 and raw.count(f'BOUND_COMPONENT_PASS devices=2 cases={case_count} records={expected_records}') == 1
        ok = ok and sanitizer_passed(raw, None if label == 'normal' else label)
        if any(c.get('search_diag') for c in inputs):
            records = [tuple(map(int,r)) for r in re.findall(r'^SEARCH_FAILURE_CASE gpu=(\d+) kind=(\d+) status=(\d+) loans=(\d+) failure=(\d+) records=(\d+)$',raw,re.M)]
            ok = ok and sorted(records) == [(g,k,3 if k else 1,1,1,0) for g in (0,1) for k in (0,1)]
            ok = ok and sum(x.startswith('SEARCH_FAILURE_CASE ') for x in raw.splitlines()) == 4
        results[label] = dict(valid=ok, rc=rc, command=cmd)
        write_json(args.out/'status.json', dict(complete=False, results=results))
        if not ok:
            raise RuntimeError('bound component failed: '+label)
        audited = audit_file(fixture/'inputs/cases.json', output)
        write_json(args.out/(label+'_audit.json'), audited)
        results[label]['audit'] = audited
        if selection:
            rows=[tuple(map(int,r)) for r in re.findall(r'^SELECT_QUEUE_PASS gpu=(\d+) cases=(\d+)$',raw,re.M)]
            if sorted(rows)!=[(0,240),(1,240)] or sum(x.startswith('SELECT_QUEUE_PASS ') for x in raw.splitlines())!=2:
                raise ValueError('missing selection queue tests')
            selected=audit_selection_file(str(output)+'.selection.jsonl')
            results[label]['selection_audit']=selected
            write_json(args.out/(label+'_selection_audit.json'),selected)
        print('PASS', label, flush=True)
    verify_tree(fixture);verify_tree(harness)
    summary = dict(valid=True, complete=True, results=results,
        scope='two-way P2P mirror/packed executor; fixture pending tickets; production DQ/ACK validation separate')
    write_json(args.out/'summary.json', summary)
    write_json(args.out/'status.json', summary)


if __name__ == '__main__':
    main()
