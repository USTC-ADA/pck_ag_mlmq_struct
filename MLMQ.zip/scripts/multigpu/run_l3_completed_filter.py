#!/usr/bin/env python3
"""Validate the frozen production collectors on both allocated GPUs."""
import argparse
import json
from pathlib import Path
import subprocess
from run_l3_batch_runtime import verify_tree
from run_l3_upgrade_stage2 import slurm_preflight, write_json
from run_l3_compact_screen import sanitizer_passed


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('fixture', 'harness', 'sanitizer', 'out'):
        parser.add_argument('--' + name, type=Path, required=True)
    args = parser.parse_args()
    fixture, harness = args.fixture.resolve(), args.harness.resolve()
    fm, hm = verify_tree(fixture), verify_tree(harness)
    if Path(__file__).resolve() != harness / 'source/scripts/multigpu/run_l3_completed_filter.py':
        parser.error('execute the frozen runner')
    args.out.mkdir(parents=True, exist_ok=False)
    allocation = slurm_preflight(args.out)
    write_json(args.out / 'manifest.json', dict(fixture=fm, harness=hm, allocation=allocation))
    results = {}
    for label in ('normal', 'memcheck', 'racecheck', 'synccheck'):
        cmd = [str(fixture / 'fixture')]
        if label != 'normal':
            cmd = [str(args.sanitizer.resolve()), '--tool', label, '--error-exitcode', '9'] + cmd
        with (args.out / (label + '.log')).open('w') as log:
            rc = subprocess.run(cmd, stdout=log, stderr=subprocess.STDOUT, timeout=120).returncode
        raw = (args.out / (label + '.log')).read_text()
        ok = rc == 0 and raw.count('COMPLETED_FILTER_PASS cases=1042 epochs=512 devices=2') == 1
        ok = ok and sanitizer_passed(raw, None if label == 'normal' else label)
        results[label] = dict(valid=ok, rc=rc, command=cmd, cases=1042)
        write_json(args.out / 'status.json', dict(complete=False, results=results))
        if not ok:
            raise RuntimeError('completed filter validation failed: ' + label)
        print('PASS', label, flush=True)
    verify_tree(fixture)
    verify_tree(harness)
    summary = dict(valid=True, complete=True, results=results,
                   scope='real predicate on each GPU; publication witness test; real queue ownership verified separately')
    write_json(args.out / 'summary.json', summary)
    write_json(args.out / 'status.json', summary)


if __name__ == '__main__':
    main()
