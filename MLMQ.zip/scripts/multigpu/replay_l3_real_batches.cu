// Offline real-CSR payload gate. NOT a live migration or integrated solve.
#include "../../SSSP/l3/l3_batch_workset.cuh"
#include "../../SSSP/l3/l3_batch_compact.cuh"
#ifndef L3_WORKSET_COMPACT
#define L3_WORKSET_COMPACT 0
#endif
#include <algorithm>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <functional>
#include <map>
#include <queue>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <vector>
namespace relay = l3_batch_relay;
#if L3_WORKSET_COMPACT
namespace workset = l3_batch_compact;
#else
namespace workset = l3_batch_workset;
#endif
static void need(bool ok, const char *why) { if (!ok) throw std::runtime_error(why); }
static void cu(cudaError_t result) { if (result != cudaSuccess) throw std::runtime_error(cudaGetErrorString(result)); }
struct graph {
    std::vector<int> rows, columns, weights, oracle;
    int vertices() const { return int(rows.size()) - 1; }
};
template <class T> static void read(std::ifstream &stream, T *out, size_t count) {
    stream.read(reinterpret_cast<char *>(out), count * sizeof(T));
    need(bool(stream), "truncated binary input");
}
static graph load_graph(const char *path, const char *oracle) {
    std::ifstream stream(path, std::ios::binary), reference(oracle, std::ios::binary);
    uint64_t header[4]; read(stream, header, 4);
    need(header[0] == 1 && header[1] == 4 && header[2] > 0 && header[2] < (1u << 30) && header[3] <= INT_MAX, "unsupported GR header");
    graph g;
    g.rows.resize(header[2] + 1); g.columns.resize(header[3]); g.weights.resize(header[3]); g.oracle.resize(header[2]);
    std::vector<uint64_t> ends(header[2]); read(stream, ends.data(), ends.size());
    for (size_t i = 0; i < ends.size(); ++i) {
        need(ends[i] <= header[3] && (i == 0 || ends[i] >= ends[i - 1]), "invalid CSR offset");
        g.rows[i + 1] = int(ends[i]);
    }
    need(g.rows.back() == int(header[3]), "CSR edge count mismatch");
    read(stream, g.columns.data(), g.columns.size());
    if (header[3] % 2) { int padding; read(stream, &padding, 1); }
    read(stream, g.weights.data(), g.weights.size());
    read(reference, g.oracle.data(), g.oracle.size());
    need(stream.peek() == EOF && reference.peek() == EOF, "trailing graph/oracle data");
    for (size_t e = 0; e < g.columns.size(); ++e)
        need(g.columns[e] >= 0 && g.columns[e] < g.vertices() && g.weights[e] >= 0, "invalid graph edge");
    for (int distance : g.oracle) need(distance >= 0, "negative oracle distance");
    return g;
}
struct batch {
    int gpu, bin, slot, warp, begin, end, local, peer, available, inflight;
    std::vector<relay::item> seeds;
    bool quiet() const { return local == 0 && (peer == 1 || peer == 2); }
};
static std::vector<batch> load_batches(const char *path, const graph &g) {
    std::ifstream stream(path);
    std::string magic; long long vertices, edges; int count;
    stream >> magic >> vertices >> edges >> count;
    need(bool(stream) && magic == "L3_REAL_BATCH_V1" && vertices == g.vertices() && edges == int(g.columns.size()) && count > 0 && count <= 2048, "invalid replay header");
    std::vector<batch> result;
    for (int i = 0; i < count; ++i) {
        batch b{}; int seeds;
        stream >> b.gpu >> b.bin >> b.slot >> b.warp >> b.begin >> b.end >> b.local >> b.peer >> b.available >> b.inflight >> seeds;
        need(bool(stream) && (b.gpu == 0 || b.gpu == 1) && b.bin >= 0 && b.bin < 128 &&
             b.slot >= 0 && b.slot < 8 && b.warp >= 0 && b.warp < 4096 && b.begin >= 0 && b.begin < b.end && b.end <= vertices &&
             b.local >= 0 && b.local <= 2 && b.peer >= 0 && b.peer <= 2 && b.available >= 0 && b.inflight >= 0 && seeds > 0 && seeds <= 32, "invalid replay batch");
        for (int j = 0; j < seeds; ++j) {
            int vertex, queued, authoritative, processed, degree;
            stream >> vertex >> queued >> authoritative >> processed >> degree;
            need(bool(stream) && vertex >= b.begin && vertex < b.end && authoritative >= 0 && authoritative <= queued &&
                 queued < processed && processed <= INT_MAX && degree == g.rows[vertex + 1] - g.rows[vertex], "invalid replay seed/CSR degree");
            need(authoritative >= g.oracle[vertex], "captured seed shorter than oracle");
            b.seeds.push_back({vertex, authoritative});
        }
        result.push_back(std::move(b));
    }
    stream >> std::ws;
    need(stream.eof(), "trailing replay tokens");
    return result;
}
struct device_graph {
    int *rows = nullptr, *columns = nullptr, *weights = nullptr;
    void upload(const graph &g) {
        cu(cudaMalloc(&rows, g.rows.size() * sizeof(int)));
        cu(cudaMalloc(&columns, g.columns.size() * sizeof(int)));
        cu(cudaMalloc(&weights, g.weights.size() * sizeof(int)));
        cu(cudaMemcpy(rows, g.rows.data(), g.rows.size() * sizeof(int), cudaMemcpyHostToDevice));
        cu(cudaMemcpy(columns, g.columns.data(), g.columns.size() * sizeof(int), cudaMemcpyHostToDevice));
        cu(cudaMemcpy(weights, g.weights.data(), g.weights.size() * sizeof(int), cudaMemcpyHostToDevice));
    }
    void release() { cu(cudaFree(rows)); cu(cudaFree(columns)); cu(cudaFree(weights)); }
};
struct counters { int rows, scans; };
__global__ static void replay(relay::slot *slots, int *certificates, counters *stats,
    relay::graph_view view, int count, int mode, int budget) {
    extern __shared__ workset::workspace scratch[];
    const int lane = threadIdx.x % 32;
    const int index = (blockIdx.x * blockDim.x + threadIdx.x) / 32;
    if (index >= count) return;
    auto *slot = slots + index;
    if (mode == 0) {
        relay::expand_payload(slot, view, lane);
        if (!lane) stats[index] = {slot->seeds, 0};
        return;
    }
    auto *work = scratch + threadIdx.x / 32;
    if (mode == 2) {
        int taken = lane ? 0 : relay::move(slot, relay::encode(index + 1, relay::ready), relay::active);
        assert(__shfl_sync(relay::mask, taken, 0));
        assert(relay::load(slot) == relay::encode(index + 1, relay::active));
    }
    workset::expand_payload(slot, view, work, certificates + index * relay::result_capacity, budget, lane);
    if (!lane) stats[index] = {work->rows, work->scans};
    if (mode == 2) relay::publish_exclusive(slot, relay::encode(index + 1, relay::returned), lane);
}
static int plus(int a, int b) { return static_cast<long long>(a) + b >= INT_MAX ? INT_MAX : a + b; }
struct metrics { long long rows=0, scans=0, records=0, certified=0, debt=0, remote=0, optimal_labels=0, optimal_certificates=0; };
static metrics verify(const graph &g, const batch &b, const relay::slot &slot,
                      const int *cert, counters stats, int mode, int budget, int index) {
    need(slot.result_status == relay::ok, "replay payload failed (no silent fallback)");
    need(slot.seeds == int(b.seeds.size()), "seed count changed");
    for (int i = 0; i < slot.seeds; ++i)
        need(slot.input[i].vertex == b.seeds[i].vertex && slot.input[i].distance == b.seeds[i].distance, "seed mutated");
    if (mode == 2) need(slot.control == relay::encode(index + 1, relay::returned), "wrong returned generation");
    metrics m; m.rows = stats.rows; m.scans = stats.scans; m.records = slot.results;
    if (mode == 0) {
        int position = 0;
        for (auto seed : b.seeds) for (int e = g.rows[seed.vertex]; e < g.rows[seed.vertex + 1]; ++e) {
            need(position < slot.results && slot.output[position].vertex == g.columns[e] &&
                slot.output[position].distance == plus(seed.distance, g.weights[e]), "one-hop CSR mismatch");
            ++position;
        }
        need(position == slot.results, "one-hop count mismatch");
        return m;
    }
    need(slot.results > 0 && slot.results <= workset::capacity && stats.rows >= 0 && stats.rows <= budget, "invalid bounded workset");
    std::unordered_map<int, int> at;
    for (int i = 0; i < slot.results; ++i) {
        const auto record = slot.output[i];
        need(record.vertex >= 0 && record.vertex < g.vertices() && at.emplace(record.vertex, i).second, "invalid/duplicate journal vertex");
        need(record.distance >= g.oracle[record.vertex] && record.distance <= cert[i], "invalid distance/certificate");
        const bool remote = record.vertex < b.begin || record.vertex >= b.end;
        need(!remote || cert[i] == INT_MAX, "expanded another owner's vertex");
        m.remote += remote; m.certified += cert[i] != INT_MAX;
        m.debt += record.distance < cert[i];
        m.optimal_labels += record.distance == g.oracle[record.vertex];
        m.optimal_certificates += cert[i] != INT_MAX && cert[i] == g.oracle[record.vertex];
    }
    using entry = std::pair<int,int>;
    std::priority_queue<entry, std::vector<entry>, std::greater<entry>> queue;
    std::vector<int> distance(slot.results, INT_MAX);
    for (auto seed : b.seeds) {
        auto found = at.find(seed.vertex);
        need(found != at.end() && slot.output[found->second].distance <= seed.distance, "lost seed");
        const int i = found->second;
        if (seed.distance < distance[i]) { distance[i] = seed.distance; queue.emplace(seed.distance, i); }
    }
    // Independent path witness within the returned induced subgraph: every
    // finite label must upper-bound a real seed path, not merely the oracle.
    while (!queue.empty()) {
        auto current = queue.top(); queue.pop();
        if (current.first != distance[current.second]) continue;
        const int vertex = slot.output[current.second].vertex;
        for (int e = g.rows[vertex]; e < g.rows[vertex + 1]; ++e) {
            auto found = at.find(g.columns[e]);
            if (found == at.end()) continue;
            const int candidate = plus(current.first, g.weights[e]);
            if (candidate < distance[found->second]) {
                distance[found->second] = candidate;
                queue.emplace(candidate, found->second);
            }
        }
    }
    for (int i = 0; i < slot.results; ++i) {
        need(slot.output[i].distance >= distance[i], "journal label has no real seed path");
        if (cert[i] == INT_MAX) continue;
        const int vertex = slot.output[i].vertex;
        for (int e = g.rows[vertex]; e < g.rows[vertex + 1]; ++e) {
            const int candidate = plus(cert[i], g.weights[e]);
            if (candidate == INT_MAX) continue;
            auto found = at.find(g.columns[e]);
            need(found != at.end() && slot.output[found->second].distance <= candidate, "incomplete certified row");
        }
    }
    return m;
}

static void run_group(const graph &g, const std::vector<batch> &all,
    device_graph *device, int owner, bool quiet, bool local_only, bool cost_breakdown) {
    std::vector<batch> candidates, chosen;
    for (const auto &b : all) if (b.gpu == owner && b.quiet() == quiet) candidates.push_back(b);
    if (candidates.empty()) return;
    // At most 64 ORIGINAL batches per (owner, quiet state), evenly spaced in
    // sorted capture order. No concatenation, oracle-driven selection or padding.
    const int count = std::min(64, int(candidates.size()));
    for (int i = 0; i < count; ++i)
        chosen.push_back(candidates[count == 1 ? 0 : i * (candidates.size() - 1) / (count - 1)]);
    const int memory_gpu = local_only ? 0 : owner;
    cu(cudaSetDevice(memory_gpu));
    relay::slot *slots; int *certificates; counters *stats;
    cu(cudaMalloc(&slots, count * sizeof(relay::slot)));
    cu(cudaMalloc(&certificates, count * relay::result_capacity * sizeof(int)));
    cu(cudaMalloc(&stats, count * sizeof(counters)));
    std::vector<relay::slot> input(count), output(count);
    std::vector<int> host_cert(count * relay::result_capacity);
    std::vector<counters> host_stats(count);
    for (int i = 0; i < count; ++i) {
        need(chosen[i].begin == chosen[0].begin && chosen[i].end == chosen[0].end, "mixed owner partition");
        input[i].control = relay::encode(i + 1, relay::ready);
        input[i].seeds = chosen[i].seeds.size();
        std::copy(chosen[i].seeds.begin(), chosen[i].seeds.end(), input[i].input);
        std::printf("REPLAY_SELECTED owner=%d quiet=%d index=%d bin=%d slot=%d warp=%d seeds=%d inflight=%d\n",
            owner, int(quiet), i, chosen[i].bin, chosen[i].slot, chosen[i].warp, input[i].seeds, chosen[i].inflight);
    }
    // Zero-budget measures initialization, seed insertion and journal return,
    // not a complete useful-work baseline. Existing default samples unchanged.
    const std::vector<int> budgets = cost_breakdown ? std::vector<int>{0, 8, 64, 256} : std::vector<int>{8, 64, 256};
    for (int budget : budgets) {
        for (int repeat = -1; repeat < 3; ++repeat) for (int mode : {0, 1, 2, 2, 1, 0}) {
            if (local_only && mode == 2) continue;
            cu(cudaSetDevice(memory_gpu));
            cu(cudaMemcpy(slots, input.data(), count * sizeof(relay::slot), cudaMemcpyHostToDevice));
            cu(cudaMemset(certificates, 0x7f, host_cert.size() * sizeof(int)));
            // Pageable H2D may return before DMA completes; cudaMemset is also
            // host-asynchronous. A peer GPU's stream does NOT inherit this
            // owner's default-stream ordering. Join preparation before switching
            // devices (outside the payload timing boundary in every mode).
            cu(cudaStreamSynchronize(0));
            const int executor = mode == 2 ? 1 - owner : memory_gpu;
            cu(cudaSetDevice(executor));
            cudaEvent_t start, end; cu(cudaEventCreate(&start)); cu(cudaEventCreate(&end));
            relay::graph_view view{device[executor].rows + chosen[0].begin, device[executor].columns,
                device[executor].weights, chosen[0].begin, chosen[0].end - chosen[0].begin};
            cu(cudaEventRecord(start));
            replay<<<(count + 3) / 4, 128, mode ? 4 * sizeof(workset::workspace) : 0>>>(slots, certificates, stats, view, count, mode, budget);
            cu(cudaGetLastError()); cu(cudaEventRecord(end)); cu(cudaEventSynchronize(end));
            float ms = 0; cu(cudaEventElapsedTime(&ms, start, end));
            cu(cudaEventDestroy(start)); cu(cudaEventDestroy(end));
            cu(cudaSetDevice(memory_gpu));
            cu(cudaMemcpy(output.data(), slots, count * sizeof(relay::slot), cudaMemcpyDeviceToHost));
            cu(cudaMemcpy(host_cert.data(), certificates, host_cert.size() * sizeof(int), cudaMemcpyDeviceToHost));
            cu(cudaMemcpy(host_stats.data(), stats, count * sizeof(counters), cudaMemcpyDeviceToHost));
            metrics sum;
            std::map<int, int> unique_certified;
            for (int i = 0; i < count; ++i) {
                auto m = verify(g, chosen[i], output[i], host_cert.data() + i * relay::result_capacity, host_stats[i], mode, budget, i);
                sum.rows += m.rows; sum.scans += m.scans; sum.records += m.records; sum.certified += m.certified; sum.debt += m.debt;
                sum.remote += m.remote; sum.optimal_labels += m.optimal_labels; sum.optimal_certificates += m.optimal_certificates;
                if (mode) for (int j = 0; j < output[i].results; ++j)
                    if (host_cert[i * relay::result_capacity + j] != INT_MAX) ++unique_certified[output[i].output[j].vertex];
            }
            if (repeat >= 0) {
                std::printf("REAL_REPLAY_COST owner=%d quiet=%d mode=%d budget=%d batches=%d repeat=%d ms=%.6f rows=%lld records=%lld certified=%lld unique_certified=%zu debt=%lld remote=%lld optimal_labels=%lld optimal_certificates=%lld correct=1\n",
                    owner, int(quiet), mode, budget, count, repeat, ms, sum.rows, sum.records, sum.certified, unique_certified.size(),
                    sum.debt, sum.remote, sum.optimal_labels, sum.optimal_certificates);
                if (cost_breakdown)
                    std::printf(L3_WORKSET_COMPACT ?
                        "REAL_REPLAY_WAVES owner=%d quiet=%d mode=%d budget=%d repeat=%d waves=%lld\n" :
                        "REAL_REPLAY_SCANS owner=%d quiet=%d mode=%d budget=%d repeat=%d tiles=%lld\n",
                        owner, int(quiet), mode, budget, repeat, sum.scans);
            }
        }
    }
    cu(cudaFree(slots)); cu(cudaFree(certificates)); cu(cudaFree(stats));
}
int main(int argc, char **argv) {
    try {
        const bool local_only = argc == 5 && std::string(argv[4]) == "--fixture-local";
        const bool cost_breakdown = argc == 5 && std::string(argv[4]) == "--cost-breakdown";
        need(argc == 4 || local_only || cost_breakdown, "usage: replay_l3_real_batches GRAPH BATCHES ORACLE [--fixture-local|--cost-breakdown]");
        need(std::getenv("SLURM_JOB_ID"), "Slurm required; no local GPU execution");
        std::printf("REAL_REPLAY_LAYOUT compact_active=%d workspace_bytes=%zu\n", L3_WORKSET_COMPACT, sizeof(workset::workspace));
        const auto g = load_graph(argv[1], argv[3]);
        const auto batches = load_batches(argv[2], g);
        int devices = 0; cu(cudaGetDeviceCount(&devices));
        need(devices == (local_only ? 1 : 2), "wrong allocated GPU count");
        device_graph device[2];
        for (int gpu = 0; gpu < devices; ++gpu) {
            cu(cudaSetDevice(gpu));
            if (!local_only) {
                int access = 0, native = 0;
                cu(cudaDeviceCanAccessPeer(&access, gpu, 1 - gpu));
                cu(cudaDeviceGetP2PAttribute(&native, cudaDevP2PAttrNativeAtomicSupported, gpu, 1 - gpu));
                need(access && native, "P2P native atomic support required");
                cu(cudaDeviceEnablePeerAccess(1 - gpu, 0));
            }
            const auto start = std::chrono::steady_clock::now();
            device[gpu].upload(g);
            const double ms = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - start).count();
            std::printf("REPLAY_UPLOAD gpu=%d ms=%.6f bytes=%zu excluded_from_payload=1\n", gpu, ms,
                (g.rows.size() + g.columns.size() + g.weights.size()) * sizeof(int));
            cu(cudaFuncSetAttribute(replay, cudaFuncAttributeMaxDynamicSharedMemorySize, 4 * sizeof(workset::workspace)));
        }
        for (int owner = 0; owner < 2; ++owner) for (bool quiet : {false, true})
            run_group(g, batches, device, owner, quiet, local_only, cost_breakdown);
        for (int gpu = 0; gpu < devices; ++gpu) { cu(cudaSetDevice(gpu)); device[gpu].release(); }
        std::printf("REAL_REPLAY_PASS fixture_local=%d original_batches=%zu payload_only_not_solve=1\n", int(local_only), batches.size());
        return 0;
    } catch (const std::exception &error) {
        std::fprintf(stderr, "REAL_REPLAY_FAIL %s\n", error.what()); return 2;
    }
}
