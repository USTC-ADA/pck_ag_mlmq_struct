#!/usr/bin/env python3
import argparse,json,subprocess,sys
from pathlib import Path
from run_l3_batch_runtime import verify_tree
from run_l3_upgrade_stage2 import slurm_preflight,write_json
from run_l3_compact_screen import sanitizer_passed
from audit_l3_packed_trace import Graph,load_batches,audit,sha,require

def main():
 p=argparse.ArgumentParser()
 for key in ('fixture','harness','capture','sanitizer','out'):p.add_argument('--'+key,type=Path,required=True)
 a=p.parse_args();f,h,c=a.fixture.resolve(),a.harness.resolve(),a.capture.resolve()
 fm,hm=verify_tree(f),verify_tree(h);require(Path(__file__).resolve()==h/'source/scripts/multigpu/run_l3_packed_trace.py','execute frozen runner')
 meta=json.loads((c/'capture.json').read_text());m=meta['manifest']
 require(sha(m['graph'])==m['graph_sha256'] and sha(m['oracle'])==m['oracle_sha256'],'graph/oracle changed')
 require(sha(c/'batches.txt')==meta['batches_sha256'],'batches changed')
 a.out.mkdir(parents=True,exist_ok=False);allocation=slurm_preflight(a.out)
 write_json(a.out/'manifest.json',dict(fixture=fm,harness=hm,allocation=allocation,capture=meta,input_sha256=sha(c/'batches.txt')))
 g=Graph(m['graph']);batches=load_batches(c/'batches.txt',g);results={}
 for label in ('normal','memcheck','racecheck','synccheck'):
  limit=0 if label=='normal' else 4;output=a.out/(label+'.jsonl')
  cmd=[str(f/'fixture'),m['graph'],str(c/'batches.txt'),m['oracle'],str(output),str(limit)]
  if label!='normal':cmd=[str(a.sanitizer.resolve()),'--tool',label,'--error-exitcode','9']+cmd
  with (a.out/(label+'.log')).open('w') as log:rc=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=240).returncode
  raw=(a.out/(label+'.log')).read_text();ok=rc==0 and raw.count(f'PACKED_TRACE_PASS captured={len(batches)} limit={limit} payload_only_not_solve=1')==1 and sanitizer_passed(raw,None if label=='normal' else label)
  results[label]=dict(valid=ok,rc=rc,command=cmd,limit=limit)
  write_json(a.out/'status.json',dict(complete=False,results=results))
  require(ok,'packed trace stage failed: '+label)
  result=audit(output,batches,g,limit);result['input_sha256']=sha(output)
  write_json(a.out/(label+'_audit.json'),result);results[label]['journals']=result['journals'];print('PASS',label,result['journals'],flush=True)
 verify_tree(f);verify_tree(h)
 summary=dict(valid=True,complete=True,results=results,scope='historical eligible seed diagnostic; no live loan or timing')
 write_json(a.out/'summary.json',summary);write_json(a.out/'status.json',summary)
if __name__=='__main__':main()
