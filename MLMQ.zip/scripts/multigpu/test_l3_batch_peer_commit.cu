// Real two-GPU compact producer -> owner commit -> unchanged delta queue.
// Reuse only the prior fixture's queue allocation/types and CPU oracle; its
// CPU-journal pipeline is NOT launched. This is not private-L1/SSSP integration.
#define L3_COMMIT_L2_TEST_LIBRARY
#include "test_l3_batch_commit_l2.cu"
#include "../../SSSP/l3/l3_batch_peer_commit.cuh"
#include <fstream>
#ifdef NDEBUG
#error "The assertion-driven fixture requires assertions enabled"
#endif
#ifdef L3_TEST_PARALLEL_OWNER
namespace pc = l3_test_peer_commit;
#else
namespace pc = l3_batch_peer_commit;
#endif
namespace relay = l3_batch_relay;
#ifdef L3_TEST_PACKED_COMPACT
namespace compact = l3_batch_compact_packed;
#else
namespace compact = l3_batch_compact;
#endif
struct Plan { int root, seeds, distinct, competitor, mode, budget; };
struct Archive {
    int seeds, count, status, fallback;
    bc::seed roots[512];
    bc::record journal[768];
};
struct Control { int stop, claimed, release; };
struct PeerDevice {
    Device base;
    int begin;
    Plan *plans;
    pc::packet *packet;
    Control *control;
    int *claims;
    Archive *archive;
    bc::record *journal;
};
__device__ int system_load(int *p) {
    return cuda::atomic_ref<int, cuda::thread_scope_system>(*p).load(cuda::memory_order_acquire);
}
__device__ void system_store(int *p, int v) {
    cuda::atomic_ref<int, cuda::thread_scope_system>(*p).store(v, cuda::memory_order_release);
}
__global__ void peer_bootstrap(Queue q, PeerDevice p) {
    auto d = p.base;
    const int lane = threadIdx.x;
    __shared__ Item items[32];
    if (!lane) q.device_init(0, 0, 0);
    __syncwarp();
    items[lane] = Item(p.begin + 1, 0);
    __syncwarp();
    int count = 8;
    assert(q.write(items, count, 0, 0, lane, nullptr) == WRITE_SUCCESS);
    for (int bucket = 0; bucket < q.bucketNum; ++bucket) q.manager_run(bucket, lane);
    q.update_local_info(lane);
    int read = 0; q.read(items, read, 0, 0, lane, nullptr); assert(read == 8);
    if (!lane) {
        assert(q.get_queue_size() == 8);
        bc::initialize(*d.commit); *d.donor = {8, 0, false}; d.stats->bootstrapped = 8;
        p.packet->channel.control = relay::encode(1, relay::free);
    }
    bw::initialize(*d.pending, lane);
}
__global__ void peer_helper(pc::packet *packet, Control *control, int *claims,
                            const Plan *plans, relay::graph_view graph, relay::graph_view fault) {
    const int lane = threadIdx.x;
    __shared__ compact::workspace scratch;
    const auto start = clock64();
    while (true) {
        int stop = 0;
        if (!lane) stop = system_load(&control->stop);
        if (__shfl_sync(FULL_MASK, stop, 0)) return;
        const auto token = pc::try_claim(packet, lane);
        if (token) {
            const int generation = int(relay::generation(token));
            if (!lane) {
                cuda::atomic_ref<int, cuda::thread_scope_system>(claims[generation - 1])
                    .fetch_add(1, cuda::memory_order_relaxed);
                system_store(&control->claimed, generation);
            }
            __syncwarp();
            while (system_load(&control->release) < generation) deadline(start);
            const int mode = plans[generation - 1].mode;
            if (mode == 4) {
                // Explicit short-package fault BEFORE return publication.
                // No lane modifies packet payload after RETURNED.
                compact::expand_payload(&packet->channel, graph, &scratch,
                    packet->certificates, packet->budget, lane);
                if (!lane) packet->channel.results = 0;
                relay::publish(&packet->channel, token, relay::returned, lane);
            } else pc::execute_claimed(packet, token, mode == 3 ? fault : graph, &scratch, lane);
        }
        deadline(start);
    }
}
// Pause the only producer and obtain a full-row-boundary receipt from the
// sole CSR consumer. Eight original ancestors remain held throughout.
__device__ void drain(PeerDevice p, int request, unsigned long long start, int lane) {
    if (!lane) store(&p.base.stats->drain_request, request);
    __syncwarp();
    while (load(&p.base.stats->drain_receipt) < request) deadline(start);
    __syncwarp();
}
__device__ void offer_competitor(Queue &q, PeerDevice p, const Plan &plan,
                               Item *scratch, int request, unsigned long long start, int lane) {
    if (!lane) {
        scratch[0] = Item(p.begin + plan.competitor + 1, 0);
        atomicAdd(p.base.expected + plan.competitor, 1);
    }
    __syncwarp();
    int count = 1;
    assert(q.write(scratch, count, 0, 0, lane, nullptr) == WRITE_SUCCESS);
    drain(p, request, start, lane);
    // A queued task, not a bare distance write, produced the shorter root.
    assert(atomicAdd(p.base.distance + plan.root, 0) == 0);
}
__global__ void peer_pipeline(Queue q, PeerDevice p) {
    auto d = p.base;
    const int lane = threadIdx.x;
    __shared__ Item scratch[32], input[32];
    __shared__ bc::seed roots[512];
    const auto start = clock64();
    if (blockIdx.x == 0) {
        auto &s = *d.commit; auto &intent = *d.pending; auto &donor = *d.donor;
        for (int round = 0; round < d.rounds; ++round) {
            const Plan plan = p.plans[round];
            const auto generation = s.generation;
            for (int i = lane; i < plan.seeds; i += 32) {
                const int v = plan.root + i % plan.distinct;
                roots[i] = {p.begin + v, atomicAdd(d.distance + v, 0)};
            }
            __syncwarp();
            if (!lane) {
                assert(bc::reserve(s, generation, donor, roots, plan.seeds,
                    p.begin, p.begin + d.vertices, p.begin + d.vertices));
                assert(bc::retire_if_idle(donor, true) == 0);
            }
            __syncwarp();
            assert(pc::publish_request(s, p.packet, plan.budget, lane));
            assert(!pc::publish_request(s, p.packet, plan.budget, lane));
            while (system_load(&p.control->claimed) < int(generation)) deadline(start);
            if (plan.mode == 1) offer_competitor(q, p, plan, scratch, round * 3 + 1, start, lane);
            if (!lane) system_store(&p.control->release, int(generation));
            __syncwarp();
            while (!pc::accept_return(s, p.packet, p.journal, lane)) deadline(start);
            assert(!pc::accept_return(s, p.packet, p.journal, lane));
            auto &archive = p.archive[round];
            if (!lane) {
                archive.seeds = s.seed_count; archive.count = p.packet->channel.results;
                archive.status = p.packet->channel.result_status;
                archive.fallback = s.stage == bc::phase::fallback;
                assert(donor.outstanding == 1);
            }
            for (int i = lane; i < s.seed_count; i += 32) archive.roots[i] = s.roots[i];
            for (int i = lane; i < p.packet->channel.results; i += 32)
                archive.journal[i] = {p.packet->channel.output[i].vertex,
                    p.packet->channel.output[i].distance, p.packet->certificates[i]};
            __syncwarp();
            bool competitor_sent = plan.mode != 2, waited = false;
            while (s.stage != bc::phase::finished) {
                deadline(start);
                bw::prepare(s, generation, intent, d.distance, lane);
                if (!competitor_sent && s.stage != bc::phase::apply) {
                    offer_competitor(q, p, plan, scratch, round * 3 + 1, start, lane);
                    competitor_sent = true;
                }
                if (intent.status != bw::publication::empty) {
                    assert(!intent.remote || intent.count == 0);
                    if (intent.status == bw::publication::prepared) {
                        for (int retry = 0; retry < 3; ++retry) {
                            assert(bw::prepare(s, generation, intent, d.distance, lane) == bc::result::blocked);
                            if (!lane) { assert(!bc::retire_if_idle(donor, true)); ++d.stats->held_prepared; }
                            __syncwarp();
                        }
                        if (lane < intent.count) atomicAdd(d.expected + intent.items[lane].vertex - p.begin, 1);
                        if (!lane) { ++d.stats->flushes; d.stats->max_pack = max(d.stats->max_pack, intent.count); }
                        assert(!bw::publish_l2(s, generation + 1, intent, q, scratch, 0, 0, lane));
                        assert(bw::publish_l2(s, generation, intent, q, scratch, 0, 0, lane));
                        assert(bw::publish_l2(s, generation, intent, q, scratch, 0, 0, lane));
                        if (!waited) {
                            drain(p, round * 3 + 2, start, lane);
                            if (!lane) {
                                assert(donor.outstanding == 1 && !bc::retire_if_idle(donor, true));
                                ++d.stats->consumed_before_ack;
                            }
                            waited = true;
                        }
                    }
                    __syncwarp();
                    if (!lane) {
                        assert(!bw::acknowledge(s, generation + 1, intent));
                        assert(bw::acknowledge(s, generation, intent));
                        assert(!bw::acknowledge(s, generation, intent));
                    }
                    __syncwarp();
                }
            }
            // Even generations needing no L2 output have a consumer receipt.
            drain(p, round * 3 + 3, start, lane);
            if (!lane) {
                ++d.stats->generations;
                const int credit = bc::retire_if_idle(donor, round + 1 == d.rounds);
                if (round + 1 != d.rounds) assert(credit == 0);
                else { assert(credit == 8); q.update_done(credit); d.stats->retired = credit; }
            }
            __syncwarp();
            assert(pc::recycle_committed(s, p.packet, intent, lane));
            assert(!pc::recycle_committed(s, p.packet, intent, lane));
            if (!lane) assert(!relay::move(&p.packet->channel, relay::encode(generation, relay::ready), relay::active));
            __syncwarp();
            assert(bw::prepare(s, generation, intent, d.distance, lane) == bc::result::stale);
        }
        if (!lane) { system_store(&p.control->stop, 1); store(&d.stats->producer_done, 1); }
    } else if (blockIdx.x == 1) {
        while (!load(&d.stats->stop)) {
            for (int bucket = 0; bucket < q.bucketNum; ++bucket) q.manager_run(bucket, lane);
            deadline(start);
        }
    } else {
        if (!lane) q.device_init(2, 0, 0);
        __syncwarp();
        while (true) {
            q.update_local_info(lane);
            int count = 0; q.read(input, count, 2, 0, lane, nullptr);
            for (int i = 0; i < count; ++i) {
                const int v = input[i].id - 1 - p.begin;
                assert(v >= 0 && v < d.vertices);
                if (!lane) atomicAdd(d.seen + v, 1);
                const int distance = atomicAdd(d.distance + v, 0);
                assert(distance <= input[i].dist);
                for (int base = d.rows[v]; base < d.rows[v + 1]; base += 32) {
                    const int edge = base + lane;
                    int target = -1, candidate = INT_MAX; bool win = false;
                    if (edge < d.rows[v + 1]) {
                        target = d.columns[edge] - p.begin;
                        const int weight = d.weights[edge];
                        if (distance < INT_MAX - weight) candidate = distance + weight;
                        win = candidate < atomicMin(d.distance + target, candidate);
                    }
                    const unsigned selected = __ballot_sync(FULL_MASK, win);
                    const int index = __popc(selected & (lane ? (1u << lane) - 1u : 0u));
                    if (win) { scratch[index] = Item(p.begin + target + 1, candidate); atomicAdd(d.expected + target, 1); }
                    __syncwarp(); int outputs = __popc(selected);
                    if (outputs) assert(q.write(scratch, outputs, 2, 0, lane, nullptr) == WRITE_SUCCESS);
                    __syncwarp();
                }
            }
            __syncwarp(); if (!lane && count) q.update_done(count); __syncwarp();
            int done = 0;
            if (!lane) {
                const int request = load(&d.stats->drain_request);
                if (request > load(&d.stats->drain_receipt) && q.get_queue_size() == 8)
                    store(&d.stats->drain_receipt, request);
                done = load(&d.stats->producer_done) && q.get_queue_size() == 0;
            }
            if (__shfl_sync(FULL_MASK, done, 0)) { if (!lane) store(&d.stats->stop, 1); break; }
            deadline(start);
        }
    }
}

static void run_peer_case(int owner, int begin, int group, int rounds, const std::string &archive_dir) {
    const int helper_gpu = 1 - owner, vertices = 1 + rounds * (group + 1);
    Graph graph(begin + vertices);
    std::vector<int> initial(vertices, INT_MAX); initial[0] = 0;
    std::vector<Plan> plans(rounds);
    std::mt19937 rng(9217u + group + begin);
    for (int round = 0; round < rounds; ++round) {
        auto &p = plans[round]; p.root = 1 + round * (group + 1); p.competitor = p.root + group;
        p.seeds = round % 3 == 0 ? 1 : round % 3 == 1 ? 7 : 512;
        p.distinct = std::min(group, p.seeds); p.mode = round % 5;
        p.budget = p.mode >= 3 ? 64 : round % 4 == 0 ? 0 : round % 4 == 1 ? 1 : 64;
        for (int i = 0; i < p.distinct; ++i) {
            initial[p.root + i] = 80 + i % 7;
            graph[begin].push_back({begin + p.root + i, initial[p.root + i]});
        }
        for (int i = 0; i < group; ++i) {
            auto &row = graph[begin + p.root + i];
            row.push_back({begin + p.root + (i + 1) % group, 0});
            for (int e = 0; e < 3; ++e) row.push_back({begin + p.root + int(rng() % group), int(rng() % 31)});
        }
        for (int i = 1; i < group; ++i) graph[begin + p.root].push_back({begin + p.root + i, 20 + i % 80});
        if (p.mode == 1 || p.mode == 2) {
            initial[p.competitor] = 0; graph[begin].push_back({begin + p.competitor, 0});
            graph[begin + p.competitor].push_back({begin + p.root, 0});
        }
    }
    const auto oracle = dijkstra(graph, {{begin, 0}});
    std::vector<int> rows{0}, columns, weights, fault_rows{0}, fault_columns, fault_weights;
    for (int v = 0; v < vertices; ++v) {
        for (auto edge : graph[begin + v]) { columns.push_back(edge.first); weights.push_back(edge.second); }
        rows.push_back(int(columns.size()));
        // Deliberately invalid helper-only CSR; owner graph always remains valid.
        fault_columns.push_back(begin + v); fault_weights.push_back(-1); fault_rows.push_back(v + 1);
    }
    CUDA(cudaSetDevice(owner));
    std::vector<void *> allocations;
    auto q = make_queue(allocations, begin ? 11 : 0);
    PeerDevice p{}; auto &d = p.base; p.begin = begin; d.vertices = vertices; d.rounds = rounds;
#define ALLOC(field, type, count) field = allocate<type>(count); allocations.push_back(field)
    ALLOC(d.rows, int, rows.size()); ALLOC(d.columns, int, columns.size()); ALLOC(d.weights, int, weights.size());
    ALLOC(d.distance, int, vertices); ALLOC(d.expected, int, vertices); ALLOC(d.seen, int, vertices);
    ALLOC(d.commit, bc::state<>, 1); ALLOC(d.donor, bc::donor_ledger, 1); ALLOC(d.pending, bw::intent, 1);
    ALLOC(d.stats, Stats, 1); ALLOC(p.plans, Plan, rounds); ALLOC(p.packet, pc::packet, 1);
    ALLOC(p.control, Control, 1); ALLOC(p.claims, int, rounds); ALLOC(p.archive, Archive, rounds);
    ALLOC(p.journal, bc::record, 768);
#undef ALLOC
#define UPLOAD(dst, vec) CUDA(cudaMemcpy(dst, vec.data(), vec.size() * sizeof(vec[0]), cudaMemcpyHostToDevice))
    UPLOAD(d.rows, rows); UPLOAD(d.columns, columns); UPLOAD(d.weights, weights);
    UPLOAD(d.distance, initial); UPLOAD(p.plans, plans);
    peer_bootstrap<<<1, 32, q.get_shm_size()>>>(q, p); CUDA(cudaGetLastError()); CUDA(cudaDeviceSynchronize());
    cudaFuncAttributes attr{}; CUDA(cudaFuncGetAttributes(&attr, peer_pipeline));
    int resident = 0; CUDA(cudaOccupancyMaxActiveBlocksPerMultiprocessor(&resident, peer_pipeline, 32, q.get_shm_size()));
    cudaDeviceProp prop{}; CUDA(cudaGetDeviceProperties(&prop, owner));
    CHECK(resident * prop.multiProcessorCount >= 3);
    cudaStream_t owner_stream; CUDA(cudaStreamCreateWithFlags(&owner_stream, cudaStreamNonBlocking));
    CUDA(cudaSetDevice(helper_gpu));
    auto hr = allocate<int>(rows.size()), hc = allocate<int>(columns.size()), hw = allocate<int>(weights.size());
    auto fr = allocate<int>(fault_rows.size()), fc = allocate<int>(fault_columns.size()), fw = allocate<int>(fault_weights.size());
    auto hp = allocate<Plan>(rounds);
    UPLOAD(hr, rows); UPLOAD(hc, columns); UPLOAD(hw, weights);
    UPLOAD(fr, fault_rows); UPLOAD(fc, fault_columns); UPLOAD(fw, fault_weights); UPLOAD(hp, plans);
#undef UPLOAD
    CUDA(cudaFuncGetAttributes(&attr, peer_helper));
    CUDA(cudaOccupancyMaxActiveBlocksPerMultiprocessor(&resident, peer_helper, 32, 0));
    CUDA(cudaGetDeviceProperties(&prop, helper_gpu)); CHECK(resident * prop.multiProcessorCount >= 2);
    CUDA(cudaDeviceSynchronize()); // ALL initialization finished before persistent launch
    cudaStream_t helper_stream; CUDA(cudaStreamCreateWithFlags(&helper_stream, cudaStreamNonBlocking));
    peer_helper<<<2, 32, 0, helper_stream>>>(p.packet, p.control, p.claims, hp,
        {hr, hc, hw, begin, vertices}, {fr, fc, fw, begin, vertices}); CUDA(cudaGetLastError());
    CUDA(cudaSetDevice(owner));
    peer_pipeline<<<3, 32, q.get_shm_size(), owner_stream>>>(q, p); CUDA(cudaGetLastError());
    CUDA(cudaStreamSynchronize(owner_stream));
    CUDA(cudaSetDevice(helper_gpu)); CUDA(cudaStreamSynchronize(helper_stream));
    CUDA(cudaStreamDestroy(helper_stream));
    for (auto ptr : {hr, hc, hw, fr, fc, fw}) CUDA(cudaFree(ptr)); CUDA(cudaFree(hp));
    CUDA(cudaSetDevice(owner)); CUDA(cudaStreamDestroy(owner_stream));
    std::vector<int> distance(vertices), expected(vertices), seen(vertices), claims(rounds);
    std::vector<Archive> archives(rounds);
#define DOWNLOAD(vec, src) CUDA(cudaMemcpy(vec.data(), src, vec.size() * sizeof(vec[0]), cudaMemcpyDeviceToHost))
    DOWNLOAD(distance, d.distance); DOWNLOAD(expected, d.expected); DOWNLOAD(seen, d.seen);
    DOWNLOAD(claims, p.claims); DOWNLOAD(archives, p.archive);
#undef DOWNLOAD
    const std::string prefix = archive_dir + "/owner" + std::to_string(owner) + "_begin" + std::to_string(begin)
        + "_group" + std::to_string(group);
    // Preserve raw inputs/results BEFORE any correctness assertion on them.
    // Bounded dump loops also retain malformed count/status fields safely.
    std::ofstream log(prefix + ".journal.txt");
    CHECK(log.good());
    for (int round = 0; round < rounds; ++round) {
        const auto &a = archives[round]; const auto plan = plans[round];
        log << "GEN " << round + 1 << " mode " << plan.mode << " budget " << plan.budget
            << " root " << begin + plan.root << " competitor " << begin + plan.competitor
            << " seeds " << a.seeds << " count " << a.count << " status " << a.status
            << " fallback " << a.fallback << " claims " << claims[round] << '\n';
        for (int i = 0; i < std::min(512, a.seeds); ++i)
            log << "SEED " << a.roots[i].vertex << ' ' << a.roots[i].distance << '\n';
        for (int i = 0; i < std::min(768, a.count); ++i)
            log << "RECORD " << a.journal[i].vertex << ' ' << a.journal[i].distance << ' ' << a.journal[i].certificate << '\n';
    }
    log.close(); CHECK(log.good());
    std::ofstream audit(prefix + ".audit.txt"); CHECK(audit.good());
    audit << "BEGIN " << begin << " VERTICES " << vertices << " ROUNDS " << rounds << '\n';
    for (int v = 0; v < vertices; ++v) {
        audit << "VERTEX " << begin + v << " initial " << initial[v] << " distance " << distance[v]
              << " oracle " << oracle[begin + v] << " expected " << expected[v] << " seen " << seen[v] << '\n';
        for (auto edge : graph[begin + v]) audit << "EDGE " << begin + v << ' ' << edge.first << ' ' << edge.second << '\n';
    }
    audit.close(); CHECK(audit.good());
    CHECK(std::equal(distance.begin(), distance.end(), oracle.begin() + begin) && expected == seen);
    int fallbacks = 0, capacity_stops = 0, distinct512 = 0;
    for (int round = 0; round < rounds; ++round) {
        const auto &a = archives[round]; const auto plan = plans[round]; CHECK(claims[round] == 1);
        CHECK(a.seeds == plan.seeds && a.count >= 0 && a.count <= 768);
        const bool fault = plan.mode >= 3; CHECK(bool(a.fallback) == fault);
        CHECK(a.status == (plan.mode == 3 ? relay::bad_weight : relay::ok));
        if (fault) CHECK(a.count == 0);
        for (int i = 0; i < a.seeds; ++i)
            CHECK(a.roots[i].vertex == begin + plan.root + i % plan.distinct &&
                  a.roots[i].distance == initial[plan.root + i % plan.distinct]);
        if (!fault) validate_journal(graph, {a.roots, a.roots + a.seeds},
                                    {a.journal, a.journal + a.count}, begin, begin + vertices);
        int certified = 0; for (int i = 0; i < a.count; ++i) certified += a.journal[i].certificate < INT_MAX;
        if (!fault && plan.budget > 0 && !certified) ++capacity_stops;
        distinct512 += plan.distinct == 512; fallbacks += fault;
    }
    CHECK(fallbacks == rounds / 5 * 2 && (group < 512 || distinct512 > 0));
    CHECK(group < 1024 || capacity_stops > 0);
    Stats stats{}; CUDA(cudaMemcpy(&stats, d.stats, sizeof(stats), cudaMemcpyDeviceToHost));
    CHECK(stats.bootstrapped == 8 && stats.retired == 8 && stats.generations == rounds && stats.stop == 1);
    CHECK(stats.held_prepared > 0 && stats.consumed_before_ack > 0 && stats.max_pack <= 32);
    CHECK(stats.drain_request == rounds * 3 && stats.drain_receipt == rounds * 3);
    relay::word control; CUDA(cudaMemcpy(&control, &p.packet->channel.control, sizeof(control), cudaMemcpyDeviceToHost));
    CHECK(control == relay::encode(rounds + 1, relay::free));
    int reserved[4], consumed[4], published[4], overflow, done, written;
    CUDA(cudaMemcpy(reserved, q.write_reserve, sizeof(reserved), cudaMemcpyDeviceToHost));
    CUDA(cudaMemcpy(consumed, q.bucket_read_done, sizeof(consumed), cudaMemcpyDeviceToHost));
    CUDA(cudaMemcpy(published, q.read_pos, sizeof(published), cudaMemcpyDeviceToHost));
    CUDA(cudaMemcpy(&overflow, q.counter_overflow, 4, cudaMemcpyDeviceToHost));
    CUDA(cudaMemcpy(&done, q.read_done, 4, cudaMemcpyDeviceToHost));
    CUDA(cudaMemcpy(&written, q.debug_write_done, 4, cudaMemcpyDeviceToHost));
    int total = 0; for (int b = 0; b < 4; ++b) { CHECK(reserved[b] == consumed[b] && reserved[b] == published[b]); total += reserved[b]; }
    int expected_total = 8; for (int n : expected) expected_total += n;
    CHECK(total == expected_total && total == done && total == written && !overflow);
    std::cout << "BATCH_PEER_COMMIT_CASE owner=" << owner << " helper=" << helper_gpu << " begin=" << begin
              << " group=" << group << " rounds=" << rounds << " fallbacks=" << fallbacks
              << " distinct512=" << distinct512 << " capacity_stops=" << capacity_stops
              << " total_writes=" << total << " flushes=" << stats.flushes
              << " consumed_before_ack=" << stats.consumed_before_ack << " PASS\n" << std::flush;
    for (auto ptr : allocations) CUDA(cudaFree(ptr));
}
int main(int argc, char **argv) {
    try {
        CHECK(std::getenv("SLURM_JOB_ID") != nullptr);
        CHECK(argc == 2 || (argc == 3 && std::string(argv[2]) == "--quick"));
        const bool quick = argc == 3;
        int devices = 0; CUDA(cudaGetDeviceCount(&devices)); CHECK(devices == 2);
        for (int gpu = 0; gpu < 2; ++gpu) {
            CUDA(cudaSetDevice(gpu)); cudaDeviceProp prop{}; CUDA(cudaGetDeviceProperties(&prop, gpu));
            CHECK(prop.major == 8 && prop.minor == 0);
            int peer = 0, atomics = 0;
            CUDA(cudaDeviceCanAccessPeer(&peer, gpu, 1 - gpu));
            CUDA(cudaDeviceGetP2PAttribute(&atomics, cudaDevP2PAttrNativeAtomicSupported, gpu, 1 - gpu));
            CHECK(peer && atomics); CUDA(cudaDeviceEnablePeerAccess(1 - gpu, 0));
        }
        int cases = 0;
        for (int owner : {0, 1}) for (int begin : quick ? std::vector<int>{37} : std::vector<int>{0, 37})
            for (int group : quick ? std::vector<int>{33, 1024} : std::vector<int>{33, 768, 1024}) {
                run_peer_case(owner, begin, group, quick ? 5 : 20, argv[1]); ++cases;
            }
        std::cout << "BATCH_PEER_COMMIT_PASS cases=" << cases
                  << " actual_peer=1 actual_dq=1 no_remote_sink=1 no_l1=1 no_solver=1 not_performance=1\n";
        return 0;
    } catch (const std::exception &e) { std::cerr << "FAIL " << e.what() << '\n'; return 1; }
}
