// Concurrent packed-index stress, independent CPU per-position oracle.
// No solver/fallback can mask corrupted indices. Run only in Slurm allocation.
#include "../../SSSP/l3/l3_batch_compact.cuh"
#include "../../SSSP/l3/l3_batch_compact_packed.cuh"
#include <cstdio>
#include <cstdlib>
#include <vector>
#ifdef NDEBUG
#error "Packed-index fixture requires assertions"
#endif
namespace packed = l3_batch_compact_packed;
constexpr int warps = 64, rounds = 12, positions = 768;
constexpr unsigned guard_value = 0xdea17abeu;
struct Guarded { unsigned before, words[packed::touched_words], after; };
static_assert(sizeof(l3_batch_compact::workspace) == 16020, "reference footprint");
static_assert(sizeof(packed::workspace) == 15444, "candidate footprint");

__global__ void exercise(unsigned *decoded, unsigned *raw, unsigned *guards) {
    __shared__ Guarded shared[2];
    const int lane = threadIdx.x % 32, local = threadIdx.x / 32;
    const int warp = blockIdx.x * 2 + local;
    Guarded &s = shared[local];
    if (!lane) s.before = s.after = guard_value;
    for (int round = 0; round < rounds; ++round) {
        for (int i = lane; i < packed::touched_words; i += 32) s.words[i] = 0;
        __syncwarp();
        // Different bijections permute writers on every reset. Neighbouring
        // fields intentionally land in the same atomic word concurrently.
        for (int i = lane; i < positions; i += 32) {
            const int p = (i * 37 + round * 53 + warp * 19) % positions;
            const unsigned value = round % 3 == 0 ? 0u : round % 3 == 1 ? 1023u :
                                   unsigned(p * 733 + round * 97 + warp * 41) % 1024;
            packed::touched_write(s.words, p, value);
        }
        __syncwarp();
        const int sample = warp * rounds + round;
        for (int p = lane; p < positions; p += 32)
            decoded[sample * positions + p] = packed::touched_read(s.words, p);
        for (int w = lane; w < packed::touched_words; w += 32)
            raw[sample * packed::touched_words + w] = s.words[w];
        if (!lane) guards[sample] = unsigned(s.before == guard_value && s.after == guard_value);
        __syncwarp();
    }
}

void check(cudaError_t rc) {
    if (rc != cudaSuccess) { std::fprintf(stderr, "CUDA: %s\n", cudaGetErrorString(rc)); std::exit(1); }
}
int main() {
    int devices = 0; check(cudaGetDeviceCount(&devices));
    if (devices != 2) { std::fprintf(stderr, "requires exactly two allocated GPUs\n"); return 1; }
    const int samples = warps * rounds;
    std::vector<unsigned> decoded(samples * positions), raw(samples * packed::touched_words), guards(samples);
    for (int gpu = 0; gpu < devices; ++gpu) {
        check(cudaSetDevice(gpu));
        unsigned *d_decoded, *d_raw, *d_guards;
        check(cudaMalloc(&d_decoded, decoded.size() * sizeof(unsigned)));
        check(cudaMalloc(&d_raw, raw.size() * sizeof(unsigned)));
        check(cudaMalloc(&d_guards, guards.size() * sizeof(unsigned)));
        exercise<<<warps / 2, 64>>>(d_decoded, d_raw, d_guards);
        check(cudaGetLastError()); check(cudaDeviceSynchronize());
        check(cudaMemcpy(decoded.data(), d_decoded, decoded.size() * sizeof(unsigned), cudaMemcpyDeviceToHost));
        check(cudaMemcpy(raw.data(), d_raw, raw.size() * sizeof(unsigned), cudaMemcpyDeviceToHost));
        check(cudaMemcpy(guards.data(), d_guards, guards.size() * sizeof(unsigned), cudaMemcpyDeviceToHost));
        for (int sample = 0; sample < samples; ++sample) {
            const int warp = sample / rounds, round = sample % rounds;
            if (guards[sample] != 1) { std::fprintf(stderr, "canary corrupted\n"); return 1; }
            std::vector<unsigned> expected_words(packed::touched_words, 0);
            for (int p = 0; p < positions; ++p) {
                const unsigned expected = round % 3 == 0 ? 0u : round % 3 == 1 ? 1023u :
                                          unsigned(p * 733 + round * 97 + warp * 41) % 1024;
                if (decoded[sample * positions + p] != expected) {
                    std::fprintf(stderr, "decode mismatch GPU%d sample%d position%d\n", gpu, sample, p); return 1;
                }
                // Independent bit-at-a-time host encoding, no split-word
                // shift algorithm shared with the device implementation.
                for (int bit = 0; bit < 10; ++bit)
                    if ((expected >> bit) & 1u) {
                        const int position = p * 10 + bit;
                        expected_words[position / 32] |= 1u << (position % 32);
                    }
            }
            for (int w = 0; w < packed::touched_words; ++w)
                if (raw[sample * packed::touched_words + w] != expected_words[w]) {
                    std::fprintf(stderr, "raw word mismatch\n"); return 1;
                }
        }
        check(cudaFree(d_decoded)); check(cudaFree(d_raw)); check(cudaFree(d_guards));
    }
    std::puts("BATCH_PACKED_INDEX_PASS devices=2 warps_per_device=64 rounds=12 positions=768 decoded=1179648 old_workspace=16020 packed_workspace=15444");
}
