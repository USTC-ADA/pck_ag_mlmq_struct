#include "../../SSSP/l3/l3_chain_v2_math.h"

#include <cuda_runtime.h>
#include <climits>
#include <cstdio>
#include <cstdlib>
#include <random>
#include <vector>

static void require_cuda(cudaError_t status, const char *operation)
{
    if (status == cudaSuccess) return;
    std::fprintf(stderr, "%s: %s\n", operation, cudaGetErrorString(status));
    std::exit(2);
}

__global__ static void closure_kernel(
    const l3_chain_partition_node *nodes, const int *bases,
    const int *pending, int *out, int segments)
{
    const int segment = blockIdx.x * blockDim.x + threadIdx.x;
    if (segment < segments)
        l3_chain_v2_closure(nodes, bases[segment], pending, out);
}

static int reference_at(
    const std::vector<l3_chain_partition_node> &nodes,
    const std::vector<int> &pending, int base, int target)
{
    long long best = LLONG_MAX;
    const int length = nodes[base].length;
    for (int source = 0; source < length; ++source)
    {
        const int candidate = pending[base + source];
        if (candidate == INT_MAX) continue;
        const long long path = source <= target ?
            static_cast<long long>(nodes[base + target].forward) -
                nodes[base + source].forward :
            static_cast<long long>(nodes[base + source].reverse) -
                nodes[base + target].reverse;
        const long long distance = static_cast<long long>(candidate) + path;
        if (distance < best) best = distance;
    }
    return best >= INT_MAX ? INT_MAX : static_cast<int>(best);
}

int main()
{
    constexpr int segments = 1024;
    std::mt19937 random(0x4c335632u);
    std::vector<l3_chain_partition_node> nodes;
    std::vector<int> bases;
    std::vector<int> pending;
    bases.reserve(segments);
    for (int segment = 0; segment < segments; ++segment)
    {
        const int base = static_cast<int>(nodes.size());
        const int length = 3 + static_cast<int>(random() % 126);
        bases.push_back(base);
        int forward = 0, reverse = 0;
        for (int offset = 0; offset < length; ++offset)
        {
            if (offset)
            {
                forward += static_cast<int>(random() % 10001);
                reverse += static_cast<int>(random() % 10001);
            }
            nodes.push_back({base + offset + 1, forward, reverse,
                             offset == 0 ? length : 0});
            int candidate = INT_MAX;
            if (segment % 13 != 0 && random() % 3 == 0)
                candidate = random() % 5 == 0 ?
                    INT_MAX - 1 - static_cast<int>(random() % 100) :
                    static_cast<int>(random() % 2000000);
            pending.push_back(candidate);
        }
        // Explicitly cover an arbitrary interior source, including when the
        // random stream produced no other finite candidate in this segment.
        if (segment % 13 == 1)
            pending[base + length / 2] = 0;
    }

    std::vector<int> expected(nodes.size()), host_out(nodes.size());
    for (int segment = 0; segment < segments; ++segment)
    {
        const int base = bases[segment];
        l3_chain_v2_closure(nodes.data(), base, pending.data(),
                            host_out.data());
        for (int target = 0; target < nodes[base].length; ++target)
        {
            const int index = base + target;
            expected[index] = reference_at(nodes, pending, base, target);
            if (host_out[index] != expected[index])
            {
                std::fprintf(stderr,
                    "CHAIN_V2_HOST_MISMATCH segment=%d target=%d got=%d expected=%d\n",
                    segment, target, host_out[index], expected[index]);
                return 1;
            }
        }
    }

    l3_chain_partition_node *device_nodes = nullptr;
    int *device_bases = nullptr, *device_pending = nullptr, *device_out = nullptr;
    require_cuda(cudaMalloc(&device_nodes, nodes.size() * sizeof(nodes[0])),
                 "nodes allocation");
    require_cuda(cudaMalloc(&device_bases, bases.size() * sizeof(bases[0])),
                 "bases allocation");
    require_cuda(cudaMalloc(&device_pending, pending.size() * sizeof(pending[0])),
                 "pending allocation");
    require_cuda(cudaMalloc(&device_out, nodes.size() * sizeof(int)),
                 "output allocation");
    require_cuda(cudaMemcpy(device_nodes, nodes.data(),
                 nodes.size() * sizeof(nodes[0]), cudaMemcpyHostToDevice),
                 "nodes upload");
    require_cuda(cudaMemcpy(device_bases, bases.data(),
                 bases.size() * sizeof(bases[0]), cudaMemcpyHostToDevice),
                 "bases upload");
    require_cuda(cudaMemcpy(device_pending, pending.data(),
                 pending.size() * sizeof(pending[0]), cudaMemcpyHostToDevice),
                 "pending upload");
    closure_kernel<<<(segments + 127) / 128, 128>>>(
        device_nodes, device_bases, device_pending, device_out, segments);
    require_cuda(cudaGetLastError(), "closure launch");
    require_cuda(cudaDeviceSynchronize(), "closure sync");
    std::vector<int> actual(nodes.size());
    require_cuda(cudaMemcpy(actual.data(), device_out,
                 actual.size() * sizeof(int), cudaMemcpyDeviceToHost),
                 "output download");
    for (size_t index = 0; index < actual.size(); ++index)
    {
        if (actual[index] != expected[index])
        {
            std::fprintf(stderr,
                "CHAIN_V2_DEVICE_MISMATCH index=%zu got=%d expected=%d\n",
                index, actual[index], expected[index]);
            return 1;
        }
    }
    require_cuda(cudaFree(device_nodes), "nodes free");
    require_cuda(cudaFree(device_bases), "bases free");
    require_cuda(cudaFree(device_pending), "pending free");
    require_cuda(cudaFree(device_out), "output free");
    std::printf("CHAIN_V2_CUDA_PASS segments=%d nodes=%zu host=device=reference\n",
                segments, nodes.size());
    return 0;
}
