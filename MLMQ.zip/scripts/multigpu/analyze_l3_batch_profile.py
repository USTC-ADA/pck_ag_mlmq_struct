#!/usr/bin/env python3
"""Recheck solver evidence and inspect immutable Nsight SQLite activity exports."""
import argparse
from collections import defaultdict
import json
from pathlib import Path
import sqlite3
from statistics import median
from run_l3_batch_runtime import verify_tree, parse_runtime, parse_helpers, parse_admission, parse_services, parse_poll, parse_cache, parse_shared
from run_l3_30h import parse_dual_contract, parse_oracle_contract
from run_l3_upgrade_stage2 import sha256, write_json
from run_usa_road_matrix import parse_bench


def audit(run):
    manifest = json.loads((run/'manifest.json').read_text())
    status = json.loads((run/'status.json').read_text())
    summary = json.loads((run/'summary.json').read_text())
    assert status['complete'] and summary['valid'] and status['results'] == summary['results']
    assert verify_tree(Path(manifest['build_path'])) == manifest['build']
    assert set(status['results']) == {'data', 'helper_sleep', 'rx_sleep', 'loans'}
    normalized = lambda x: json.loads(json.dumps(x))
    output = {}
    for label, record in status['results'].items():
        raw = (run/(label+'.log')).read_text(); env = record['environment']
        services, poll, admit = (int(env[k]) for k in ('MLMQ_BATCH_SERVICES', 'MLMQ_BATCH_SERVICE_POLL', 'MLMQ_BATCH_ADMIT'))
        assert record['state'] == 'passed' and record['rc'] == 0
        assert parse_bench(raw) == record['samples'] and len(record['samples']) == 4
        assert parse_oracle_contract(raw, 4, manifest['contract']['vertices']) == record['oracle'] and record['oracle']['valid']
        dual = parse_dual_contract(raw, 4, 97, manifest['contract']['delta'], 19,
            expected_window_mode=2, expected_window_min=25000, expected_window_max=25000,
            expected_idle_backoff=0, require_l2_final=True, expected_worker_recovery=1, expected_ack_capacity=1712)
        assert dual == record['dual'] and dual['valid']
        rt = parse_runtime(raw, 4, 512, 0, False); assert rt == record['runtime']
        assert parse_helpers(raw, 4, 8, rt) == record['helpers']
        assert normalized(parse_admission(raw, 4, admit, rt)) == record['admission']
        assert normalized(parse_services(raw, 4, services, admit)) == record['services']
        assert parse_poll(raw, 4, poll) == record['poll']
        assert parse_cache(raw, 4, int(env['MLMQ_BATCH_SERVICE_CARVEOUT'])) == record['cache']
        if 'MLMQ_BATCH_SERVICE_SHARED_BYTES' in env:
            assert parse_shared(raw, 4, int(env['MLMQ_BATCH_SERVICE_SHARED_BYTES'])) == record['shared']
        for filename, digest in record['artifacts'].items():
            assert sha256(run/filename) == digest
        with sqlite3.connect('file:'+str(run/(label+'.sqlite'))+'?mode=ro', uri=True) as db:
            db.row_factory = sqlite3.Row
            kernels = [dict(r) for r in db.execute('SELECT s.value name,k.* FROM CUPTI_ACTIVITY_KIND_KERNEL k JOIN StringIds s ON s.id=k.demangledName ORDER BY k.start')]
            api = defaultdict(list)
            for r in db.execute('SELECT s.value name,r.* FROM CUPTI_ACTIVITY_KIND_RUNTIME r JOIN StringIds s ON s.id=r.nameId'):
                api[r['correlationId']].append(dict(r))
        grouped = defaultdict(list)
        tokens = {'manager': 'manage_block_kernel', 'worker': 'work_block_kernel', 'helper': 'helper_kernel', 'rx': 'rx_kernel'}
        for kernel in kernels:
            role = next((r for r, token in tokens.items() if token in kernel['name']), None)
            if role is None:
                continue
            calls = api[kernel['correlationId']]
            assert len(calls) == 1 and 'cudaLaunchKernel' in calls[0]['name'] and calls[0]['returnValue'] == 0
            call = calls[0]
            assert kernel['end'] > kernel['start'] and kernel['sharedMemoryExecuted'] > 0
            kernel.update(role=role, api_start_ns=call['start'], api_end_ns=call['end'],
                          api_ms=(call['end']-call['start'])/1e6,
                          queue_ms=max(0, kernel['start']-call['end'])/1e6,
                          kernel_ms=(kernel['end']-kernel['start'])/1e6)
            grouped[role].append(kernel)
        expected_roles = {'manager', 'worker'} | ({'helper'} if services & 1 else set()) | ({'rx'} if services & 2 else set())
        assert set(grouped) == expected_roles
        for role, rows in grouped.items():
            assert len(rows) == 8
            for gpu in (0, 1):
                part = sorted((r for r in rows if r['deviceId'] == gpu), key=lambda r:r['start'])
                assert len(part) == 4
                for repeat, r in enumerate(part):
                    r.update(repeat=repeat, warmup=int(repeat == 0))
                    assert r['gridX'] == (97 if role == 'worker' else 8 if role == 'helper' else 1)
                    assert r['blockX'] == (544 if role == 'worker' else 512 if role == 'manager' else 64)
        if 'shared' in record:
            for role, rows in grouped.items():
                if role not in ('helper', 'rx'):
                    continue
                for row in rows:
                    shared = next(x for x in record['shared'][row['repeat']*2:row['repeat']*2+2] if x['gpu']==row['deviceId'])
                    assert row['staticSharedMemory']==shared[role+'_static'] and row['dynamicSharedMemory']==shared[role+'_dynamic']
        overlaps = []
        for repeat in range(4):
            for gpu in (0, 1):
                rows = [r for part in grouped.values() for r in part if r['deviceId'] == gpu and r['repeat'] == repeat]
                overlap = min(r['end'] for r in rows)-max(r['start'] for r in rows)
                assert overlap > 0
                overlaps.append({'gpu': gpu, 'repeat': repeat, 'all_persistent_kernels_overlap_ns': overlap})
        stats = {}
        for role, rows in grouped.items():
            measured = [r for r in rows if not r['warmup']]
            stats[role] = {'shared_memory_executed_bytes': sorted({r['sharedMemoryExecuted'] for r in rows}),
                           'static_shared_bytes': sorted({r['staticSharedMemory'] for r in rows}),
                           'dynamic_shared_bytes': sorted({r['dynamicSharedMemory'] for r in rows}),
                           'per_gpu_samples_ms': {f: [r[f] for r in measured] for f in ('api_ms', 'queue_ms', 'kernel_ms')},
                           'median_max_gpu_per_query_ms': {f: median(max(r[f] for r in measured if r['repeat'] == q) for q in (1,2,3))
                                                           for f in ('api_ms', 'queue_ms', 'kernel_ms')}}
        output[label] = {'kernels': dict(grouped), 'stats': stats, 'overlaps': overlaps,
                         'solve_samples_ms': [float(r['solve_ms']) for r in record['samples'] if r['warmup'] == '0']}
    return {'valid': True, 'job_id': manifest['allocation']['job_id'], 'queries': 16,
            'auditor_sha256': sha256(Path(__file__)),
            'captures': output, 'performance_acceptance': False,
            'limitations': ['profiler changes timing distribution', 'sharedMemoryExecuted is per-kernel driver metadata, not per-SM cache residency measurement']}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    if args.out.exists():
        parser.error('output exists')
    result = audit(args.run.resolve(strict=True))
    write_json(args.out, result)
    print('BATCH_CUDA_ACTIVITY_AUDIT_PASS', result['job_id'])


if __name__ == '__main__':
    main()
