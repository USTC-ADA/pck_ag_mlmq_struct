#!/usr/bin/env python3
"""Exploratory matched A100 screen for one opt-in L3 mechanism."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import shutil
import statistics
import subprocess

from run_l3_upgrade_stage2 import (
    ROOT, SPEC_FIELDS, clean_environment, command_capture, load_contract,
    load_specs, read_gr_header, run_configuration, sha256, slurm_preflight,
    write_json,
)


def load_gplus_spec(raw_specs):
    if raw_specs is None or len(raw_specs) != 1:
        raise ValueError("USA G+ screen requires exactly one --spec")
    name, graph_s, oracle_s, source_s, delta_s, cut_s, graph_hash, oracle_hash = raw_specs[0]
    if name != "USA_Gplus":
        raise ValueError("USA G+ screen name must be USA_Gplus")
    contract = json.loads((ROOT / "evidence/l3_30h_20260923/final/formal_input_contract.json").read_text())
    graph = Path(graph_s).resolve(strict=True)
    oracle = Path(oracle_s).resolve(strict=True)
    source, delta, cut = map(int, (source_s, delta_s, cut_s))
    header = read_gr_header(graph)
    expected = {
        "vertices": contract["vertices"], "edges": contract["edges"],
        "graph_sha256": contract["graph_sha256"],
        "oracle_sha256": contract["oracle_sha256"],
        "source": contract["source"], "delta": contract["delta"],
        "cut_percent": contract["cut_percent"],
    }
    observed = {
        **header, "graph_sha256": sha256(graph),
        "oracle_sha256": sha256(oracle), "source": source,
        "delta": delta, "cut_percent": cut,
    }
    if observed != expected or graph_hash != contract["graph_sha256"] or \
            oracle_hash != contract["oracle_sha256"] or \
            oracle.stat().st_size != header["vertices"] * 4:
        raise ValueError(f"USA G+ differs from frozen input contract: {observed}")
    return [{"name": name, "graph": graph, "oracle": oracle, **observed}]


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--control", required=True, type=Path)
    parser.add_argument("--treatment", "--priority", required=True, type=Path)
    parser.add_argument("--treatment-role", choices=("C_priority", "C_follower",
                                                     "C_loan"),
                        default="C_priority")
    parser.add_argument("--expected-worker-recovery", type=int,
                        choices=(0, 1), default=1)
    parser.add_argument("--spec", action="append", nargs=8, metavar=SPEC_FIELDS)
    parser.add_argument("--gplus", action="store_true")
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("--timeout", type=int, default=900)
    args = parser.parse_args()
    if args.out.exists() or args.out.is_symlink():
        parser.error(f"output already exists: {args.out}")
    if args.timeout <= 0:
        parser.error("timeout must be positive")
    args.control = args.control.resolve(strict=True)
    args.treatment = args.treatment.resolve(strict=True)
    args.specs = (load_gplus_spec(args.spec) if args.gplus else
                  load_specs(args.spec, load_contract()))
    return args


def median(record, metric):
    samples = [float(sample[metric]) for sample in record["samples"]
               if sample["warmup"] == "0"]
    if len(samples) != 3:
        raise ValueError(f"expected three timed {metric} samples")
    return statistics.median(samples), samples


def summarize(records, specs, treatment_role):
    result = {"graphs": {}, "all_valid": all(row["valid"] for row in records)}
    for spec in specs:
        graph = spec["name"]
        rows = {}
        for role in ("B_control", treatment_role):
            selected = sorted((row for row in records
                               if row["graph"] == graph and row["role"] == role),
                              key=lambda row: row["round"])
            if len(selected) != 2 or [row["round"] for row in selected] != [0, 1]:
                raise ValueError(f"missing paired rounds: {graph}/{role}")
            rows[role] = {}
            for metric in ("solve_ms", "query_wall_ms"):
                by_round = [median(row, metric) for row in selected]
                values = [value for _, group in by_round for value in group]
                rows[role][metric] = {
                    "samples": values,
                    "median": statistics.median(values),
                    "round_medians": [item[0] for item in by_round],
                }
        ratios = {}
        for metric in ("solve_ms", "query_wall_ms"):
            control = rows["B_control"][metric]
            priority = rows[treatment_role][metric]
            ratios[metric] = {
                "control_over_priority": control["median"] / priority["median"],
                "round_ratios": [a / b for a, b in zip(
                    control["round_medians"], priority["round_medians"])],
            }
        result["graphs"][graph] = {"roles": rows, "ratios": ratios}
    return result


def main():
    args = parse_args()
    output = args.out.resolve(strict=False)
    output.mkdir(parents=True)
    allocation = slurm_preflight(output)
    binaries = {"B_control": args.control,
                args.treatment_role: args.treatment}
    initial_hashes = {role: sha256(path) for role, path in binaries.items()}
    repo_head = subprocess.check_output(
        ["git", "-C", str(ROOT), "rev-parse", "HEAD"], text=True).strip()
    repo_status = subprocess.check_output(
        ["git", "-C", str(ROOT), "status", "--porcelain=v1"],
        text=True).splitlines()
    manifest = {
        "status": "running", "evidence_class": "exploratory",
        "source_head": repo_head, "source_status": repo_status,
        "treatment_role": args.treatment_role,
        "expected_worker_recovery": args.expected_worker_recovery,
        "allocation": allocation, "binaries": {
            role: {"path": str(path), "sha256": initial_hashes[role]}
            for role, path in binaries.items()},
        "samples_per_role_graph": {"rounds": 2, "warmups": 1, "timed": 6},
        "inputs": [{key: str(value) if isinstance(value, Path) else value
                    for key, value in spec.items()} for spec in args.specs],
    }
    write_json(output / "manifest.json", manifest)
    shutil.copy2(__file__, output / "runner.py")
    environment = clean_environment()
    records = []
    for round_id in range(2):
        specs = args.specs if round_id == 0 else list(reversed(args.specs))
        roles = ("B_control", args.treatment_role)
        if round_id:
            roles = tuple(reversed(roles))
        for spec in specs:
            for role in roles:
                run_configuration(
                    output=output, spec=spec, role=role,
                    binary=binaries[role], gpu_count=2, round_id=round_id,
                    warmups=1, repeats=3, timeout=args.timeout,
                    environment=environment, diagnostic=False,
                    records=records,
                    expected_worker_recovery=args.expected_worker_recovery)
    summary = summarize(records, args.specs, args.treatment_role)
    write_json(output / "summary.json", summary)
    apps = command_capture(output, "gpu_apps_final", [
        "nvidia-smi", "--query-compute-apps=pid", "--format=csv,noheader"])
    if apps.returncode or apps.stdout.strip():
        raise RuntimeError("GPU process remained after screen")
    command_capture(output, "nvidia_smi_final", ["nvidia-smi"])
    changed = [role for role, path in binaries.items()
               if sha256(path) != initial_hashes[role]]
    changed_inputs = [spec["name"] for spec in args.specs
                      if sha256(spec["graph"]) != spec["graph_sha256"] or
                      sha256(spec["oracle"]) != spec["oracle_sha256"]]
    final_head = subprocess.check_output(
        ["git", "-C", str(ROOT), "rev-parse", "HEAD"], text=True).strip()
    integrity = {
        "valid": not changed and not changed_inputs and
                 final_head == repo_head and summary["all_valid"],
        "changed_binaries": changed, "changed_inputs": changed_inputs,
        "initial_head": repo_head, "final_head": final_head,
    }
    write_json(output / "final_integrity.json", integrity)
    if not integrity["valid"]:
        raise RuntimeError(f"invalid screen: {integrity}")
    manifest.update(status="complete", record_count=len(records))
    write_json(output / "manifest.json", manifest)
    print(json.dumps(summary, sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
