#!/usr/bin/env python3
"""One W512 A100 diagnostic query for L3 work imbalance and idle tail."""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
import shutil

from run_l3_upgrade_stage2 import (
    ROOT, clean_environment, command_capture, read_gr_header, sha256,
    slurm_preflight, write_json,
)
from run_l3_30h import QUEUE_TYPE_IDS, parse_dual_contract, parse_oracle_contract
from run_usa_road_matrix import run_one


def parse_l1_supply(raw):
    """Validate observational snapshots, without treating them as unique work."""
    errors = []

    def rows(prefix, fields):
        result = []
        for line in raw.splitlines():
            if not line.startswith(prefix + " "):
                continue
            pairs = re.findall(r"\b(\w+)=(-?\d+)\b", line)
            entry = {key: int(value) for key, value in pairs}
            if len(pairs) != len(entry) or set(entry) != set(fields.split()):
                errors.append(f"malformed {prefix}")
                continue
            result.append(entry)
        return result

    configs = rows("L3_L1_SUPPLY_CONFIG",
                   "gpu warps bins bin_shift max_batch observational")
    samples = rows("L3_L1_SUPPLY", "gpu bin sampled nonempty raw eligible edges "
                   "invalid max_raw max_eligible max_edges max_degree ge8 ge16")
    tails = rows("L3_Q2_TAIL", "gpu bin since total available local_term peer_term")
    config_by_gpu = {row["gpu"]: row for row in configs}
    if len(configs) != 2 or set(config_by_gpu) != {0, 1}:
        errors.append("expected one supply configuration for each of two GPUs")
    for config in configs:
        if (not 0 < config["warps"] <= 4096 or config["bins"] != 128 or
                config["bin_shift"] != 21 or config["max_batch"] != 32 or
                config["observational"] != 1):
            errors.append("unsupported supply configuration")
    tail_by_key = {(row["gpu"], row["bin"]): row for row in tails}
    if len(tail_by_key) != len(tails):
        errors.append("duplicate Q2 tail bin")
    seen = set()
    quiet = []
    for sample in samples:
        key = sample["gpu"], sample["bin"]
        config = config_by_gpu.get(sample["gpu"])
        tail = tail_by_key.get(key)
        if key in seen or config is None or tail is None:
            errors.append("duplicate or unmatched supply bin")
            continue
        seen.add(key)
        if (any(value < 0 for value in sample.values()) or
                sample["bin"] >= config["bins"] or
                not sample["ge16"] <= sample["ge8"] <= sample["nonempty"] <=
                sample["sampled"] <= config["warps"] or
                not sample["eligible"] <= sample["raw"] <=
                sample["nonempty"] * config["max_batch"] or
                not sample["max_eligible"] <= sample["max_raw"] <=
                min(config["max_batch"], sample["raw"]) or
                sample["max_eligible"] > sample["eligible"] or
                sample["max_edges"] > sample["edges"] or
                sample["max_degree"] > sample["max_edges"] or
                sample["ge8"] * 8 > sample["eligible"] or
                sample["ge16"] * 16 > sample["eligible"] or
                sample["invalid"] != 0):
            errors.append(f"inconsistent supply counts at {key}")
        if (tail["since"] <= 0 or tail["since"] >> 21 != sample["bin"] or
                tail["local_term"] not in (0, 1, 2) or
                tail["peer_term"] not in (0, 1, 2)):
            errors.append(f"invalid Q2 tail metadata at {key}")
        if tail["local_term"] == 0 and tail["peer_term"] in (1, 2):
            quiet.append({**tail, **sample})
    if (seen != set(tail_by_key) or
            {sample["gpu"] for sample in samples} != {0, 1}):
        errors.append("missing supply bins or GPU")
    if any(not any(row["gpu"] == gpu and row["sampled"] > 0
                   for row in samples) for gpu in (0, 1)):
        errors.append("no observed worker samples on one or both GPUs")
    return {"errors": errors, "configs": configs, "samples": samples,
            "peer_quiescing_or_ready_bins": quiet,
            "interpretation": "asynchronous observations, not unique work; "
                              "peer termination request is not proof of idle"}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", required=True, type=Path)
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("--require-wait", action="store_true")
    parser.add_argument("--require-progress", action="store_true")
    parser.add_argument("--require-q2-tail", action="store_true")
    parser.add_argument("--require-l1-supply", action="store_true")
    parser.add_argument("--progress-only", action="store_true",
                        help="require two progress rows without work counters")
    parser.add_argument("--oracle-only", action="store_true",
                        help="validate an opt-in binary without diagnostic rows")
    parser.add_argument("--expected-worker-recovery", type=int,
                        choices=(0, 1), default=1)
    args = parser.parse_args()
    if args.progress_only and args.oracle_only:
        parser.error("--progress-only and --oracle-only are exclusive")
    if args.out.exists() or args.out.is_symlink():
        parser.error(f"output already exists: {args.out}")

    contract = json.loads((ROOT / "evidence/l3_30h_20260923/final/formal_input_contract.json").read_text())
    graph = Path(contract["graph_path"]).resolve(strict=True)
    oracle = Path(contract["oracle_path"]).resolve(strict=True)
    binary = args.binary.resolve(strict=True)
    header = read_gr_header(graph)
    if (header != {"vertices": contract["vertices"],
                   "edges": contract["edges"]} or
            sha256(graph) != contract["graph_sha256"] or
            sha256(oracle) != contract["oracle_sha256"] or
            oracle.stat().st_size != header["vertices"] * 4):
        raise ValueError("USA G+ input differs from frozen formal contract")

    output = args.out.resolve(strict=False)
    output.mkdir(parents=True)
    allocation = slurm_preflight(output)
    binary_hash = sha256(binary)
    write_json(output / "manifest.json", {
        "evidence_class": "diagnostic_only", "allocation": allocation,
        "binary": str(binary), "binary_sha256": binary_hash,
        "graph": str(graph), "graph_sha256": contract["graph_sha256"],
        "oracle": str(oracle), "oracle_sha256": contract["oracle_sha256"],
        "source": contract["source"], "delta": contract["delta"],
        "cut_percent": contract["cut_percent"],
    })
    shutil.copy2(__file__, output / "runner.py")
    environment = clean_environment()
    environment.update({
        "BENCH_SOURCE": str(contract["source"]),
        "BENCH_WARMUPS": "0", "BENCH_REPEATS": "1",
        "MLMQ_CUT_PERCENT": str(contract["cut_percent"]),
        "L3_SUPPLEMENT_ORACLE": str(oracle),
    })
    record = run_one(binary, graph, "MLMQ", 2, output / "diagnostic",
                     environment, contract["source"], "L1SLF_L2DQ",
                     0, 1, 900, contract["delta"])
    raw = (output / "diagnostic.log").read_text()
    oracle_check = parse_oracle_contract(raw, 1, contract["vertices"])
    dual = parse_dual_contract(
        raw, 1, 107, contract["delta"], QUEUE_TYPE_IDS["L1SLF_L2DQ"],
        expected_window_mode=2, expected_window_min=25000,
        expected_window_max=25000, expected_idle_backoff=0,
        require_l2_final=True,
        expected_worker_recovery=args.expected_worker_recovery)
    work = re.findall(r"^L3_WORK gpu=.*$", raw, re.MULTILINE)
    wait = re.findall(r"^L3_WAIT gpu=.*$", raw, re.MULTILINE)
    progress = re.findall(r"^L3_PROGRESS gpu=.*$", raw, re.MULTILINE)
    q2_tail = re.findall(r"^L3_Q2_TAIL gpu=.*$", raw, re.MULTILINE)
    q2_tail_gpus = {int(match.group(1)) for line in q2_tail
                    if (match := re.search(r"\bgpu=(\d+)\b", line))}
    supply = parse_l1_supply(raw) if args.require_l1_supply else None
    valid = (record["rc"] == 0 and record["valid"] and
             not oracle_check["errors"] and not dual["errors"] and
             (args.progress_only or args.oracle_only or len(work) == 2) and
             (not args.require_wait or len(wait) >= 2) and
             (not (args.require_progress or args.progress_only) or
              len(progress) == 2) and
             (not args.require_q2_tail or
              (len(q2_tail) >= 4 and q2_tail_gpus == {0, 1})) and
             (supply is None or not supply["errors"]) and
             sha256(binary) == binary_hash)
    summary = {"valid": valid, "rc": record["rc"],
               "run_reason": record["reason"],
               "oracle_errors": oracle_check["errors"],
               "dual_errors": dual["errors"], "work": work,
               "wait": wait, "progress": progress,
               "q2_tail": q2_tail, "l1_supply": supply}
    write_json(output / "summary.json", summary)
    apps = command_capture(output, "gpu_apps_final", [
        "nvidia-smi", "--query-compute-apps=pid", "--format=csv,noheader"])
    if apps.returncode or apps.stdout.strip():
        raise RuntimeError("GPU process remained after diagnostic")
    command_capture(output, "nvidia_smi_final", ["nvidia-smi"])
    if not valid:
        raise RuntimeError("diagnostic correctness or evidence gate failed")
    print(json.dumps({"valid": valid, "work": work, "progress": progress}),
          flush=True)


if __name__ == "__main__":
    main()
