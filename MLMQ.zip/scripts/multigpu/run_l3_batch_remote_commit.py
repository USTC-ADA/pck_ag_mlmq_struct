#!/usr/bin/env python3
"""Run a frozen compact + nonempty remote RX + two real-L2 fixture, never solver/performance evidence."""
import argparse
import json
from pathlib import Path
import re
import subprocess

from run_l3_compact_screen import sanitizer_passed
from run_l3_batch_peer_commit import verify_build as verify_peer_build
from run_l3_upgrade_stage2 import ROOT, clean_environment, sha256, slurm_preflight, write_json


def parse_cases(raw, quick):
    fields = ('owner', 'begin', 'fan', 'leaves', 'rounds', 'loans', 'packets',
              'remote_records', 'full_stops', 'delay_checks', 'competitions',
              'source_writes', 'remote_writes')
    pattern = '^BATCH_REMOTE_COMMIT_CASE ' + ' '.join(k + r'=(\d+)' for k in fields) + ' PASS$'
    rows = [dict(zip(fields, map(int, values))) for values in re.findall(pattern, raw, re.MULTILINE)]
    expected = sorted((o, b, f, l) for o in (0, 1)
                      for b in ((37,) if quick else (0, 37))
                      for f in ((33,) if quick else (1, 33, 65))
                      for l in ((7,) if quick else (0, 7)))
    if sorted((r['owner'], r['begin'], r['fan'], r['leaves']) for r in rows) != expected:
        raise ValueError('missing/duplicate/wrong remote fixture cases')
    rounds = 2 if quick else 4
    for r in rows:
        groups = rounds * 3
        bound = groups * ((1 + r['leaves'] + r['fan'] + 31) // 32)
        if (r['rounds'] != rounds or r['loans'] != groups or
                not groups <= r['packets'] <= bound or
                r['remote_records'] != groups * r['fan'] or
                r['full_stops'] != rounds or r['delay_checks'] != r['packets'] or
                r['competitions'] != (groups if r['leaves'] else 0) or
                r['source_writes'] != 8 + groups * r['leaves'] or
                r['remote_writes'] < 8 + r['remote_records'] + r['competitions']):
            raise ValueError('incomplete remote correctness coverage')
    for gpu in (0, 1):
        if raw.splitlines().count(f'EPOCH_METADATA_GUARD_PASS gpu={gpu} generation=1099511627777 no_queue=1') != 1:
            raise ValueError('missing/duplicate epoch boundary unit')
    marker = (f'BATCH_REMOTE_COMMIT_PASS cases={len(expected)} actual_compact=1 actual_remote=1 '
              'actual_dq=1 no_l1=1 no_solver=1 not_performance=1')
    if raw.splitlines().count(marker) != 1:
        raise ValueError('missing/duplicate final pass marker')
    return rows


def verify_build(build):
    manifest = verify_peer_build(build)
    required = {'source/SSSP/l3/l3_batch_remote_commit.cuh', 'source/SSSP/l3/l3_transport.cuh',
                'source/SSSP/l3/l3_sync.cuh',
                'source/scripts/multigpu/run_l3_batch_remote_commit.py',
                'source/scripts/multigpu/test_l3_batch_remote_commit.cu'}
    if not required.issubset(manifest['hashes']):
        raise ValueError('missing remote build dependencies')
    return manifest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for arg in ('build', 'sanitizer', 'out'):
        parser.add_argument('--' + arg, required=True, type=Path)
    args = parser.parse_args()
    build = args.build.resolve(strict=True)
    manifest = verify_build(build)  # validates the submit-time snapshot, not live worktree
    if Path(__file__).resolve() != build / 'source/scripts/multigpu/run_l3_batch_remote_commit.py':
        parser.error('execute the frozen runner under BUILD/source, not the live worktree')
    if args.out.exists() or args.out.is_symlink():
        parser.error('output must not exist')
    args.out.mkdir(parents=True)
    out = args.out.resolve()
    allocation = slurm_preflight(out)
    sanitizer = args.sanitizer.resolve(strict=True)
    sanitizer_hash = sha256(sanitizer)
    write_json(out / 'manifest.json', {'allocation': allocation, 'build': str(build),
        'build_manifest_sha256': sha256(build / 'manifest.json'), 'snapshot': manifest,
        'sanitizer': str(sanitizer), 'sanitizer_sha256': sanitizer_hash,
        'evidence_class': 'exploratory_compact_real_remote_real_dq_no_solver_no_performance'})
    status = {}
    environment = clean_environment()
    environment['CUDA_MODULE_LOADING'] = 'EAGER'
    for stage, tool, quick in (('smoke', None, True), ('normal', None, False),
                               ('memcheck', 'memcheck', True), ('racecheck', 'racecheck', True),
                               ('synccheck', 'synccheck', True)):
        journal_dir = out / (stage + '_journals')
        journal_dir.mkdir()
        command = [str(build / 'test_sm80'), str(journal_dir)] + (['--quick'] if quick else [])
        if tool:
            command = [str(sanitizer), '--tool', tool, '--error-exitcode', '9'] + command
        print('RUN', stage, flush=True)
        status[stage] = {'command': command, 'quick': quick, 'sanitizer': tool, 'state': 'running'}
        write_json(out / 'status.json', {'complete': False, 'results': status})
        try:
            with (out / (stage + '.log')).open('w') as log:
                process = subprocess.run(command, cwd=ROOT, env=environment,
                                         stdout=log, stderr=subprocess.STDOUT, timeout=300)
            raw = (out / (stage + '.log')).read_text()
            status[stage]['rc'] = process.returncode
            if process.returncode or not sanitizer_passed(raw, tool):
                raise RuntimeError('failed fixture or sanitizer')
            status[stage]['cases'] = parse_cases(raw, quick)
            paths = sorted(journal_dir.glob('*.journal.txt'))
            if len(paths) != len(status[stage]['cases']) or any(not p.stat().st_size for p in paths):
                raise RuntimeError('missing raw journals')
            audits = sorted(journal_dir.glob('*.audit.txt'))
            if len(audits) != len(paths) or any(not p.stat().st_size for p in audits):
                raise RuntimeError('missing raw graph/distance/multiplicity audits')
            status[stage]['raw_artifacts'] = {p.name: sha256(p) for p in paths + audits}
            apps = subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid', '--format=csv,noheader'], text=True)
            if apps.strip():
                raise RuntimeError('GPU process remains; no cleanup attempted')
            status[stage]['state'] = 'passed'
        except Exception as error:
            status[stage].update(state='failed', error=str(error))
            write_json(out / 'status.json', {'complete': False, 'results': status})
            raise
        write_json(out / 'status.json', {'complete': False, 'results': status})
        print('PASS', stage, flush=True)
    if verify_build(build) != manifest or sha256(sanitizer) != sanitizer_hash:
        raise RuntimeError('provenance changed during run')
    write_json(out / 'summary.json', {'valid': True, 'results': status,
        'normal_cases': 24, 'normal_loans': 288, 'quick_cases_each_sanitizer': 2,
        'quick_loans_each_sanitizer': 12, 'actual_compact': True, 'actual_remote': True, 'actual_dq': True,
        'both_owner_helper_directions': True, 'nonzero_partition_begin': True,
        'cpu_oracle_and_receipt_multisets': True, 'two_slot_backpressure': True,
        'consumed_before_system_ack': True, 'rx_post_apply_competition': True,
        'conservative_all_record_rx': True, 'loan_generation_above_int32': True,
        'epoch_exhaustion_metadata_unit': True,
        'new_bad_helper_fallback_cases': False, 'reverse_csr_edges': False,
        'real_l1_loan': False, 'solver_integration': False, 'performance_evidence': False})
    write_json(out / 'status.json', {'complete': True, 'results': status})
    print('BATCH_REMOTE_COMMIT_PIPELINE_PASS no_solver_no_performance=1', flush=True)


if __name__ == '__main__':
    main()
