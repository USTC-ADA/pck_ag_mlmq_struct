#!/usr/bin/env python3
"""Fail-stop full-solver integration screen, not a performance acceptance run."""
import argparse
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import time

from run_l3_upgrade_stage2 import clean_environment, sha256, slurm_preflight, write_json
from run_l3_30h import parse_dual_contract, parse_oracle_contract, QUEUE_TYPE_IDS
from run_usa_road_matrix import parse_bench, validate, gpu_snapshot
from run_l3_compact_screen import sanitizer_passed


def parse_runtime(raw, repeats, budget, force, require_work):
    fields = 'gpu slots budget force loans seeds records local remote certificates helpers receipts active'.split()
    pattern = '^L3_BATCH_RUNTIME_AUDIT ' + ' '.join(k + r'=(\d+)' for k in fields) + ' PASS$'
    rows = [dict(zip(fields, map(int, values))) for values in re.findall(pattern, raw, re.MULTILINE)]
    if len(rows) != 2 * repeats or sum(line.startswith('L3_BATCH_RUNTIME_AUDIT ') for line in raw.splitlines()) != len(rows):
        raise ValueError('missing or malformed runtime audit')
    for index in range(repeats):
        pair = rows[2*index:2*index+2]
        if sorted(r['gpu'] for r in pair) != [0, 1]:
            raise ValueError('wrong runtime GPUs')
        for row in pair:
            if (row['slots'] != 128 or row['budget'] != budget or row['force'] != force or row['active'] or
                    not row['loans'] <= row['seeds'] <= 32*row['loans'] or
                    row['local'] + row['remote'] > row['records'] or row['certificates'] > row['records']):
                raise ValueError('invalid runtime counts/configuration')
        a, b = pair
        if a['loans'] != b['helpers'] or b['loans'] != a['helpers']:
            raise ValueError('helper claims differ from opposite owner loans')
        if require_work and (sum(r['loans'] for r in pair) == 0 or sum(r['remote'] for r in pair) == 0):
            raise ValueError('vacuous integration case: no loans or no remote records')
    return rows


def parse_bound(raw, repeats, mode, steps, instrumented):
    config_fields = 'gpu mode steps peer_bound mirror_bytes'.split()
    audit_fields = 'gpu mode instrumented checks covered pruned'.split()
    config_pattern = '^L3_BATCH_BOUND_CONFIG ' + ' '.join(k+r'=(\d+)' for k in config_fields) + '$'
    audit_pattern = '^L3_BATCH_BOUND_AUDIT ' + ' '.join(k+r'=(-?\d+)' for k in audit_fields) + '$'
    configs = [dict(zip(config_fields, map(int, r))) for r in re.findall(config_pattern, raw, re.M)]
    audits = [dict(zip(audit_fields, map(int, r))) for r in re.findall(audit_pattern, raw, re.M)]
    for prefix, rows in (('L3_BATCH_BOUND_CONFIG ', configs), ('L3_BATCH_BOUND_AUDIT ', audits)):
        if len(rows) != 2*repeats or sum(line.startswith(prefix) for line in raw.splitlines()) != len(rows):
            raise ValueError('missing/malformed bound records')
        for index in range(repeats):
            if sorted(r['gpu'] for r in rows[2*index:2*index+2]) != [0, 1]:
                raise ValueError('wrong bound GPUs')
    if mode not in range(4) or not 1 <= steps <= 1024 or instrumented not in (0, 1):
        raise ValueError('invalid expected bound configuration')
    for r in configs:
        if r['mode'] != mode or r['steps'] != steps or r['peer_bound'] != 1 or r['mirror_bytes'] <= 0 or r['mirror_bytes'] % 4:
            raise ValueError('bound configuration mismatch')
    for r in audits:
        if r['mode'] != mode or r['instrumented'] != instrumented:
            raise ValueError('bound diagnostic mismatch')
        c, cover, skip = (r[k] for k in ('checks', 'covered', 'pruned'))
        if not instrumented:
            if (c, cover, skip) != (-1, -1, -1):
                raise ValueError('performance counts must be NOT_MEASURED')
        elif (not 0 <= skip <= cover <= c or (mode != 2 and skip) or
              (mode == 2 and skip != cover) or (mode in (0, 3) and c)):
            raise ValueError('bound counter conservation failed')
    return dict(config=configs, audit=audits)


def parse_bound_publisher(raw, repeats, mode, steps, bound_config):
    fields = 'gpu warp mode vertices loops reads finite cursor wraps'.split()
    pattern = '^L3_BATCH_BOUND_PUBLISH ' + ' '.join(k+r'=(\d+)' for k in fields) + '$'
    rows = [dict(zip(fields, map(int, r))) for r in re.findall(pattern, raw, re.M)]
    if len(rows) != 4*repeats or sum(x.startswith('L3_BATCH_BOUND_PUBLISH ') for x in raw.splitlines()) != len(rows):
        raise ValueError('missing/malformed publisher observations')
    if len(bound_config) != 2*repeats or mode not in range(4) or not 1 <= steps <= 1024:
        raise ValueError('publisher configuration shape')
    for sample in range(repeats):
        group = rows[4*sample:4*sample+4]
        if sorted((r['gpu'], r['warp']) for r in group) != [(0, 0), (0, 1), (1, 0), (1, 1)]:
            raise ValueError('publisher GPU/warp identity')
        sizes = {r['gpu']: r['mirror_bytes']//4 for r in bound_config[2*sample:2*sample+2]}
        for r in group:
            n, lane = r['vertices'], 32*r['warp']
            lane_reads = r['loops']*steps if n > lane else 0
            positions = (n-1-lane)//64+1 if n > lane else 0
            cursor = lane + 64*(lane_reads % positions) if positions else lane
            wraps = lane_reads//positions if positions else 0
            if (r['mode'] != mode or n != sizes[r['gpu']] or n <= 0 or
                r['reads'] != r['loops']*steps*max(0, min(32, n-lane)) or
                r['finite'] > r['reads'] or r['cursor'] != cursor or r['wraps'] != wraps or
                (mode == 0 and (r['loops'] or r['reads'] or r['finite']))):
                raise ValueError('publisher counts/cursor inconsistent')
    return rows


def parse_bound_neighbors(raw, repeats, mode, edge_limit, instrumented, runtime):
    configs, audits = [], []
    for suffix, fields, dest in (
            ('CONFIG', 'gpu edge_limit scan_enabled', configs),
            ('AUDIT', 'gpu instrumented reads finite', audits)):
        fields = fields.split()
        prefix = 'L3_BATCH_BOUND_NEIGHBORS_'+suffix+' '
        pattern = '^'+prefix+' '.join(k+r'=(-?\d+)' for k in fields)+'$'
        dest.extend(dict(zip(fields, map(int, values))) for values in re.findall(pattern, raw, re.M))
        if len(dest) != 2*repeats or sum(x.startswith(prefix) for x in raw.splitlines()) != len(dest):
            raise ValueError('missing/malformed neighbor publisher records')
        for i in range(repeats):
            if sorted(r['gpu'] for r in dest[2*i:2*i+2]) != [0, 1]:
                raise ValueError('neighbor publisher GPU identity')
    if mode not in range(4) or not 1 <= edge_limit <= 128 or instrumented not in (0, 1) or len(runtime) != 2*repeats:
        raise ValueError('neighbor publisher expected configuration')
    for r in configs:
        if r['edge_limit'] != edge_limit or r['scan_enabled'] != 0:
            raise ValueError('neighbor publisher configuration mismatch')
    for i in range(repeats):
        seeds = {r['gpu']: r['seeds'] for r in runtime[2*i:2*i+2]}
        if sorted(seeds) != [0, 1]:
            raise ValueError('neighbor publisher runtime identity')
        for r in audits[2*i:2*i+2]:
            if r['instrumented'] != instrumented:
                raise ValueError('neighbor publisher instrumentation mismatch')
            if not instrumented:
                if (r['reads'], r['finite']) != (-1, -1):
                    raise ValueError('neighbor performance counts must be NOT_MEASURED')
            elif (not 0 <= r['finite'] <= r['reads'] <= seeds[r['gpu']]*edge_limit or
                  (mode == 0 and r['reads'])):
                raise ValueError('neighbor publisher count conservation')
    return dict(config=configs, audit=audits)


def parse_bound_returned(raw,repeats,mode,instrumented,runtime):
    configs=[];audits=[]
    for suffix,fields,dest in (('CONFIG','gpu after_finished',configs),('AUDIT','gpu instrumented loans records published',audits)):
        fields=fields.split();prefix='L3_BATCH_BOUND_RETURNED_'+suffix+' '
        pattern='^'+prefix+' '.join(k+r'=(-?\d+)' for k in fields)+'$'
        dest.extend(dict(zip(fields,map(int,values))) for values in re.findall(pattern,raw,re.M))
        if len(dest)!=2*repeats or sum(x.startswith(prefix) for x in raw.splitlines())!=len(dest):raise ValueError('missing/malformed returned publisher')
        for i in range(repeats):
            if sorted(r['gpu'] for r in dest[2*i:2*i+2])!=[0,1]:raise ValueError('returned publisher GPU identity')
    if mode not in range(4) or instrumented not in (0,1) or len(runtime)!=2*repeats:raise ValueError('returned expected configuration')
    if any(r['after_finished']!=1 for r in configs):raise ValueError('returned phase gate disabled')
    for i in range(repeats):
        rt={r['gpu']:r for r in runtime[2*i:2*i+2]}
        if sorted(rt)!=[0,1]:raise ValueError('returned runtime identity')
        for r in audits[2*i:2*i+2]:
            if r['instrumented']!=instrumented:raise ValueError('returned instrumentation')
            values=(r['loans'],r['records'],r['published'])
            if not instrumented:
                if values!=(-1,-1,-1):raise ValueError('returned performance counters must be NOT_MEASURED')
            elif mode==0:
                if values!=(0,0,0):raise ValueError('returned off mode published')
            elif not (r['loans']==rt[r['gpu']]['loans'] and r['records']==rt[r['gpu']]['records'] and r['loans']<=r['published']<=r['records']):
                raise ValueError('returned finished journal conservation')
    return dict(config=configs,audit=audits)


def parse_bound_placement(raw, repeats, bound_config):
    fields = 'gpu owner_vertices storage_vertices publisher_target_gpu helper_read_gpu reset_gpu'.split()
    prefix = 'L3_BATCH_BOUND_PLACEMENT '
    pattern = '^'+prefix+' '.join(k+r'=(\d+)' for k in fields)+'$'
    rows = [dict(zip(fields, map(int, values))) for values in re.findall(pattern, raw, re.M)]
    if len(rows) != 2*repeats or len(bound_config) != 2*repeats or sum(x.startswith(prefix) for x in raw.splitlines()) != len(rows):
        raise ValueError('missing/malformed bound placement records')
    for i in range(repeats):
        pair = rows[2*i:2*i+2]
        sizes = {r['gpu']: r['mirror_bytes']//4 for r in bound_config[2*i:2*i+2]}
        if sorted(sizes) != [0, 1] or sorted(r['gpu'] for r in pair) != [0, 1]:
            raise ValueError('bound placement GPU identity')
        for r in pair:
            g = r['gpu']
            if (r['owner_vertices'] != sizes[g] or r['storage_vertices'] != sizes[1-g] or
                r['publisher_target_gpu'] != 1-g or r['helper_read_gpu'] != g or r['reset_gpu'] != g):
                raise ValueError('bound placement or asymmetric size mismatch')
    return rows


def parse_search(raw, repeats, budget, blocks, runtime, helpers):
    fields = 'gpu warp loans seeds rows certified records remaining capacity empty budget failure'.split()
    prefix = 'L3_BATCH_SEARCH '
    pattern = '^'+prefix+' '.join(k+r'=(\d+)' for k in fields)+'$'
    rows = [dict(zip(fields, map(int, values))) for values in re.findall(pattern, raw, re.M)]
    per_query = 4*blocks
    if (blocks not in range(1,9) or len(rows) != per_query*repeats or
        len(runtime) != 2*repeats or len(helpers) != 2*repeats or
        sum(x.startswith(prefix) for x in raw.splitlines()) != len(rows)):
        raise ValueError('missing/malformed search records')
    for q in range(repeats):
        group = rows[per_query*q:per_query*(q+1)]
        rt = {r['gpu']:r for r in runtime[2*q:2*q+2]}
        hp = {r['gpu']:r for r in helpers[2*q:2*q+2]}
        if sorted((r['gpu'],r['warp']) for r in group) != [(g,w) for g in (0,1) for w in range(2*blocks)]:
            raise ValueError('search warp identity')
        for r in group:
            if (r['loans'] != hp[r['gpu']]['counts'][r['warp']] or r['failure'] or
                r['loans'] != r['capacity']+r['empty']+r['budget']+r['failure'] or
                not r['loans'] <= r['seeds'] <= 32*r['loans'] or
                not 0 <= r['certified'] <= r['rows'] <= budget*r['loans'] or
                not r['certified'] <= r['records'] <= 768*r['loans'] or r['remaining'] > r['records']):
                raise ValueError('search work conservation')
        for g in (0,1):
            for key, reference in (('loans','loans'),('seeds','seeds'),('records','records'),('certified','certificates')):
                if sum(r[key] for r in group if r['gpu']==g) != rt[1-g][reference]:
                    raise ValueError('search/opposite owner conservation')
    return rows


def parse_select(raw,repeats):
    rows=[tuple(map(int,r)) for r in re.findall(r'^L3_BATCH_SELECT_CONFIG gpu=(\d+) enabled=(\d+) stride=(\d+)$',raw,re.M)]
    if len(rows)!=2*repeats or sum(x.startswith('L3_BATCH_SELECT_CONFIG ') for x in raw.splitlines())!=len(rows):
        raise ValueError('missing/malformed selection configuration')
    for q in range(repeats):
        if sorted(rows[2*q:2*q+2])!=[(0,1,32),(1,1,32)]:raise ValueError('selection configuration mismatch')
    return rows


def verify_tree(root):
    manifest = json.loads((root / 'manifest.json').read_text())
    for name, digest in manifest['hashes'].items():
        path = (root / name).resolve(strict=True)
        if not path.is_relative_to(root) or sha256(path) != digest:
            raise ValueError('snapshot mismatch: ' + name)
    return manifest


def parse_helpers(raw, repeats, blocks, runtime):
    config = [tuple(map(int, row)) for row in re.findall(
        r'^L3_BATCH_HELPER_CONFIG gpu=(\d+) blocks=(\d+) warps=(\d+)$', raw, re.M)]
    audit = [dict(gpu=int(g), blocks=int(b), active_warps=int(a), counts=list(map(int, c.split(','))))
             for g, b, a, c in re.findall(r'^L3_BATCH_HELPER_AUDIT gpu=(\d+) blocks=(\d+) active_warps=(\d+) counts=([0-9,]+)$', raw, re.M)]
    if (not 1 <= blocks <= 8 or len(config) != 2*repeats or len(audit) != 2*repeats or
            sum(line.startswith('L3_BATCH_HELPER_CONFIG ') for line in raw.splitlines()) != len(config) or
            sum(line.startswith('L3_BATCH_HELPER_AUDIT ') for line in raw.splitlines()) != len(audit)):
        raise ValueError('missing helper launch/audit rows')
    for index in range(repeats):
        if sorted(config[2*index:2*index+2]) != [(0, blocks, 2*blocks), (1, blocks, 2*blocks)]:
            raise ValueError('wrong helper launch configuration')
        pair = audit[2*index:2*index+2]
        if sorted(r['gpu'] for r in pair) != [0, 1]:
            raise ValueError('wrong helper audit GPUs')
        work = {r['gpu']: r['helpers'] for r in runtime[2*index:2*index+2]}
        for row in pair:
            if (row['blocks'] != blocks or len(row['counts']) != 2*blocks or
                    sum(row['counts']) != work[row['gpu']] or
                    row['active_warps'] != sum(c > 0 for c in row['counts'])):
                raise ValueError('helper count/configuration mismatch')
    return audit


def parse_admission(raw, repeats, allowed, runtime):
    rows = [tuple(map(int, r)) for r in re.findall(
        r'^L3_BATCH_ADMISSION_CONFIG gpu=(\d+) allowed=(\d+)$', raw, re.M)]
    if (allowed not in (0, 1) or len(rows) != 2*repeats or len(runtime) != 2*repeats or
            sum(line.startswith('L3_BATCH_ADMISSION_CONFIG ') for line in raw.splitlines()) != len(rows)):
        raise ValueError('missing admission configuration')
    for index in range(repeats):
        if sorted(rows[2*index:2*index+2]) != [(0, allowed), (1, allowed)]:
            raise ValueError('wrong admission configuration')
    if not allowed and any(r[k] for r in runtime for k in
                           ('loans', 'seeds', 'records', 'local', 'remote', 'certificates', 'helpers', 'receipts', 'active')):
        raise ValueError('disabled admission performed work')
    return rows


def parse_services(raw, repeats, services, probe_calls):
    rows = [tuple(map(int, r)) for r in re.findall(
        r'^L3_BATCH_SERVICE_CONFIG gpu=(\d+) helper=(\d+) rx=(\d+) probe_calls=(\d+)$', raw, re.M)]
    if (services not in range(4) or probe_calls not in (0, 1) or len(rows) != 2*repeats or
            sum(line.startswith('L3_BATCH_SERVICE_CONFIG ') for line in raw.splitlines()) != len(rows)):
        raise ValueError('missing service configuration')
    for index in range(repeats):
        expected = [(g, int(bool(services & 1)), int(bool(services & 2)), probe_calls) for g in (0, 1)]
        if sorted(rows[2*index:2*index+2]) != expected:
            raise ValueError('wrong service configuration')
    return rows


def parse_loops(raw, repeats, blocks, services):
    prefix = 'L3_BATCH_LOOP_AUDIT '
    rows = [{'gpu': int(g), 'helper': list(map(int, h.split(','))), 'rx': list(map(int, r.split(',')))}
            for g, h, r in re.findall(r'^L3_BATCH_LOOP_AUDIT gpu=(\d+) helper=([0-9,]+) rx=([0-9,]+)$', raw, re.M)]
    if len(rows) != 2*repeats or sum(line.startswith(prefix) for line in raw.splitlines()) != len(rows):
        raise ValueError('missing service loop audits')
    for i in range(repeats):
        if sorted(r['gpu'] for r in rows[2*i:2*i+2]) != [0, 1]:
            raise ValueError('wrong loop audit GPUs')
    for row in rows:
        if len(row['helper']) != 16 or len(row['rx']) != 2:
            raise ValueError('wrong loop counter shape')
        for i, value in enumerate(row['helper']):
            if (value > 0) != (bool(services & 1) and i < 2*blocks):
                raise ValueError('wrong helper loop participation')
        if any((value > 0) != bool(services & 2) for value in row['rx']):
            raise ValueError('wrong RX loop participation')
    return rows


def parse_sleep(raw, repeats, requested):
    prefix = 'L3_BATCH_SLEEP_CONFIG '
    rows = [dict(zip(('gpu', 'requested_ns'), map(int, r))) for r in re.findall(
        r'^L3_BATCH_SLEEP_CONFIG gpu=(\d+) requested_ns=(\d+)$', raw, re.M)]
    if (not 64 <= requested <= 65536 or len(rows) != 2*repeats or
            sum(line.startswith(prefix) for line in raw.splitlines()) != len(rows)):
        raise ValueError('missing service sleep configuration')
    for i in range(repeats):
        pair = rows[2*i:2*i+2]
        if sorted(r['gpu'] for r in pair) != [0, 1] or any(r['requested_ns'] != requested for r in pair):
            raise ValueError('wrong service sleep configuration')
    return rows


def parse_timing(raw, repeats, gpus, warmups=0):
    import math
    integer_keys = ('gpu', 'repeat', 'warmup')
    host_keys = ('barrier_return_ms', 'manage_before_ms', 'manage_after_ms', 'work_before_ms',
                 'work_after_ms', 'sync_before_ms', 'sync_after_ms', 'finish_after_ms')
    time_keys = host_keys + ('manage_stream_ms', 'work_stream_ms')
    prefix = 'L3_TIMING '
    pattern = '^' + prefix + ' '.join(k + r'=(\d+)' for k in integer_keys)
    pattern += ' ' + ' '.join(k + r'=([0-9]+\.[0-9]+)' for k in time_keys) + r'(?: origin_ms=([0-9]+\.[0-9]+))?$'
    rows = []
    for values in re.findall(pattern, raw, re.M):
        row = dict(zip(integer_keys, map(int, values[:3])))
        row.update(zip(time_keys, map(float, values[3:3+len(time_keys)])))
        if values[-1]:
            row['origin_ms'] = float(values[-1])
            if not math.isfinite(row['origin_ms']) or row['origin_ms'] <= 0:
                raise ValueError('invalid timing origin')
        rows.append(row)
    if len(rows) != repeats*gpus or sum(line.startswith(prefix) for line in raw.splitlines()) != len(rows):
        raise ValueError('missing timing rows')
    for sample in range(repeats):
        pair = [r for r in rows if r['repeat'] == sample]
        if (sorted(r['gpu'] for r in pair) != list(range(gpus)) or
                any(r['warmup'] != int(sample < warmups) for r in pair)):
            raise ValueError('wrong timing sample/GPU identity')
    for row in rows:
        if any(not math.isfinite(row[k]) or row[k] < 0 for k in time_keys):
            raise ValueError('invalid timing value')
        if any(row[b]+0.000001 < row[a] for a, b in zip(host_keys, host_keys[1:])):
            raise ValueError('non-monotone host timing')
        if not row['manage_stream_ms'] > 0 or not row['work_stream_ms'] > 0:
            raise ValueError('missing CUDA event interval')
    return rows


def parse_poll(raw, repeats, enabled):
    prefix = 'L3_BATCH_POLL_CONFIG '
    rows = [dict(zip(('gpu', 'enabled'), map(int, r))) for r in re.findall(
        r'^L3_BATCH_POLL_CONFIG gpu=(\d+) enabled=(\d+)$', raw, re.M)]
    if (enabled not in (0, 1) or len(rows) != 2*repeats or
            sum(line.startswith(prefix) for line in raw.splitlines()) != len(rows)):
        raise ValueError('missing service polling configuration')
    for i in range(repeats):
        pair = rows[2*i:2*i+2]
        if sorted(r['gpu'] for r in pair) != [0, 1] or any(r['enabled'] != enabled for r in pair):
            raise ValueError('wrong service polling configuration')
    return rows


def parse_cache(raw, repeats, requested):
    cache_keys = ('gpu', 'requested', 'helper_preferred', 'rx_preferred', 'helper_static', 'rx_static')
    worker_keys = ('gpu', 'threads', 'dynamic_shared', 'static_shared', 'registers', 'preferred')
    parsed = {}
    for name, keys in (('CACHE', cache_keys), ('WORKER', worker_keys)):
        prefix = 'L3_BATCH_' + name + '_CONFIG '
        pattern = '^' + prefix + ' '.join(k + r'=(-?\d+)' for k in keys) + '$'
        rows = [dict(zip(keys, map(int, row))) for row in re.findall(pattern, raw, re.M)]
        if len(rows) != 2*repeats or sum(line.startswith(prefix) for line in raw.splitlines()) != len(rows):
            raise ValueError('missing cache/worker configuration')
        for i in range(repeats):
            if sorted(r['gpu'] for r in rows[2*i:2*i+2]) != [0, 1]:
                raise ValueError('wrong cache/worker GPUs')
        parsed[name.lower()] = rows
    for row in parsed['cache']:
        if (not -1 <= requested <= 100 or row['requested'] != requested or row['helper_static'] <= 0 or row['rx_static'] < 0 or
                any(not -1 <= row[k] <= 100 for k in ('helper_preferred', 'rx_preferred')) or
                (requested >= 0 and any(row[k] != requested for k in ('helper_preferred', 'rx_preferred')))):
            raise ValueError('cache preference mismatch')
    for row in parsed['worker']:
        if (row['threads'] != 544 or row['dynamic_shared'] <= 0 or row['static_shared'] < 0 or
                not 1 <= row['registers'] <= 255 or not -1 <= row['preferred'] <= 100):
            raise ValueError('worker geometry mismatch')
    return parsed


def parse_shared(raw, repeats, requested):
    keys = ('gpu', 'requested', 'helper_static', 'helper_dynamic', 'rx_static', 'rx_dynamic',
            'worker_total', 'manager_total', 'sm_capacity', 'block_capacity', 'sm_count')
    prefix = 'L3_BATCH_SHARED_CONFIG '
    pattern = '^' + prefix + ' '.join(k + r'=(\d+)' for k in keys) + '$'
    rows = [dict(zip(keys, map(int, row))) for row in re.findall(pattern, raw, re.M)]
    if len(rows) != 2*repeats or sum(line.startswith(prefix) for line in raw.splitlines()) != len(rows):
        raise ValueError('missing service shared allocation')
    for i in range(repeats):
        if sorted(r['gpu'] for r in rows[2*i:2*i+2]) != [0, 1]:
            raise ValueError('wrong service shared GPUs')
    for row in rows:
        if row['requested'] != requested or min(row[k] for k in ('helper_static','worker_total','manager_total','sm_capacity','block_capacity','sm_count')) <= 0:
            raise ValueError('invalid shared allocation metadata')
        if requested:
            if (any(row[r+'_static']+row[r+'_dynamic'] != requested for r in ('helper','rx')) or
                    requested > row['block_capacity'] or row['block_capacity'] > row['sm_capacity'] or
                    requested+min(requested,row['worker_total'],row['manager_total']) <= row['sm_capacity']):
                raise ValueError('service shared allocation fails isolation inequality')
        elif row['helper_dynamic'] or row['rx_dynamic']:
            raise ValueError('unexpected dynamic shared allocation')
    return rows


def parse_completed_filter(raw, repeats, enabled, instrumented):
    rows = []
    for line in raw.splitlines():
        if not line.startswith('L3_BATCH_COMPLETED_FILTER '):
            continue
        match = re.fullmatch(r'L3_BATCH_COMPLETED_FILTER gpu=(\d+) enabled=(\d+) instrumented=(\d+) checks=(-?\d+) skipped=(-?\d+)', line)
        if not match:
            raise ValueError('malformed completed filter observation')
        rows.append(dict(zip(('gpu', 'enabled', 'instrumented', 'checks', 'skipped'), map(int, match.groups()))))
    if len(rows) != repeats * 2:
        raise ValueError('missing completed filter observations')
    for q in range(repeats):
        if {r['gpu'] for r in rows[q*2:q*2+2]} != {0, 1}:
            raise ValueError('completed filter GPU identity')
    for r in rows:
        if r['enabled'] != enabled or r['instrumented'] != instrumented:
            raise ValueError('completed filter configuration')
        if instrumented:
            if not 0 <= r['skipped'] <= r['checks']:
                raise ValueError('completed filter count conservation')
        elif (r['checks'], r['skipped']) != (-1, -1):
            raise ValueError('uninstrumented filter must report NOT_MEASURED')
    return rows


def parse_inject_wait(raw, repeats, injectors=6):
    rows = []
    for line in raw.splitlines():
        if not line.startswith('L3_INJECT_WAIT '):
            continue
        match = re.fullmatch(r'L3_INJECT_WAIT gpu=(\d+) inject=(\d+) phase=(\d+) count=(\d+)', line)
        if not match:
            raise ValueError('malformed injection wait observation')
        rows.append(dict(zip(('gpu', 'inject', 'phase', 'count'), map(int, match.groups()))))
    if len(rows) != repeats * 2 * injectors * 6:
        raise ValueError('missing injection wait observations')
    if {row['gpu'] for row in rows} != {0, 1}:
        raise ValueError('injection wait GPU identity')
    expected = [(i, p) for i in range(injectors) for p in range(6)] * repeats
    for gpu in (0, 1):
        if [(r['inject'], r['phase']) for r in rows if r['gpu'] == gpu] != expected:
            raise ValueError('injection wait warp/phase identity or order')
    return {'rows': rows, 'phase_names': ['other', 'hint_collect', 'nohint_collect',
                                        'publish_l2', 'backstop', 'ack_hold'],
            'scope': 'snapshots while ACK absent; observation counts, not cycles'}


def parse_manager_wait(raw, repeats):
    keys = ('gpu','slot','span','last_work','c0','c1','c2','c3','c4','c5')
    prefix = 'L3_WAIT '
    pattern = '^'+prefix+' '.join(k+r'=(\d+)' for k in keys)+'$'
    rows = [dict(zip(keys,map(int,values))) for values in re.findall(pattern,raw,re.M)]
    if len(rows)!=4*repeats or sum(line.startswith(prefix) for line in raw.splitlines())!=len(rows):
        raise ValueError('missing manager phase records or worker instrumentation present')
    for q in range(repeats):
        if sorted((r['gpu'],r['slot']) for r in rows[q*4:q*4+4]) != [(0,256),(0,257),(1,256),(1,257)]:
            raise ValueError('wrong manager phase GPUs')
    for row in rows:
        if (row['slot'] not in (256,257) or row['span']<=0 or row['last_work'] or
                row['span']!=sum(row[f'c{i}'] for i in range(6)) or any(row[f'c{i}'] for i in (3,4,5))):
            raise ValueError('invalid manager phase conservation')
    reasons = [dict(zip(('gpu','reason','count'),map(int,v))) for v in
               re.findall(r'^L3_WAIT_REASON gpu=(\d+) reason=(\d+) count=(\d+)$',raw,re.M)]
    if len(reasons)!=36*repeats or sum(line.startswith('L3_WAIT_REASON ') for line in raw.splitlines())!=len(reasons):
        raise ValueError('missing manager wait reasons')
    for gpu in (0,1):
        part = [r for r in reasons if r['gpu']==gpu]
        if len(part)!=18*repeats or any([r['reason'] for r in part[q*18:q*18+18]]!=list(range(18)) for q in range(repeats)):
            raise ValueError('invalid manager wait reason identity')
    return {'manager':[r for r in rows if r['slot']==256],'tx':[r for r in rows if r['slot']==257],'reasons':reasons,'uninstrumented_reason_ids':list(range(14))+[17],
            'phase_scope':{'manager':'cycles classified by iteration entry state ACTIVE/QUIESCING/READY; not exact transition timestamps',
                           'tx':'c0 remaining iteration work; c1 retained-send branch; c2 live termination-token gate'}}


def parse_final_state(raw, repeats, gpus, separate_cert=False):
    fields = 'gpu term request exit pending_local marked_words stranded cache_ahead'.split()
    pattern = '^FINAL_STATE ' + ' '.join(k + r'=(\d+)' for k in fields) + '$'
    rows = [dict(zip(fields, map(int, values))) for values in re.findall(pattern, raw, re.M)]
    if len(rows) != repeats*gpus:
        raise ValueError('missing final-state audits')
    for i in range(repeats):
        if sorted(r['gpu'] for r in rows[i*gpus:(i+1)*gpus]) != list(range(gpus)):
            raise ValueError('wrong final-state GPUs')
    for r in rows:
        if (r['exit'] != 1 or any(r[k] for k in fields[4:]) or
                (gpus == 2 and (r['term'] != 2 or r['request'] <= 0))):
            raise ValueError('nonquiescent final-state audit')
    if raw.splitlines().count('FINAL_AUDIT mismatches=0 residual_edges=0 cross_residual_edges=0') != repeats:
        raise ValueError('missing final residual audits')
    cert = [dict(zip(('gpu', 'entries', 'raw_pending'), map(int, values))) for values in
            re.findall(r'^FINAL_BATCH_COMPLETED gpu=(\d+) entries=(\d+) raw_pending=(\d+)$', raw, re.M)]
    if separate_cert:
        if len(cert) != repeats*gpus:
            raise ValueError('missing separate completed-certificate audits')
        for i in range(repeats):
            if sorted(r['gpu'] for r in cert[i*gpus:(i+1)*gpus]) != list(range(gpus)):
                raise ValueError('wrong completed-certificate GPUs')
        if any(r['raw_pending'] > r['entries'] for r in cert):
            raise ValueError('pending ordinary rows lack completed evidence')
    return {'states': rows, 'completed': cert}


def execute(command, environment, log, timeout):
    start = time.monotonic()
    with log.open('w') as stream:
        process = subprocess.Popen(command, env=environment, stdout=stream, stderr=subprocess.STDOUT,
                                   start_new_session=True)
        try:
            rc = process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            # Only this runner-created child group, never other user processes.
            os.killpg(process.pid, signal.SIGKILL)
            process.wait()
            rc = 124
        stream.write(f'\nRUN_RC={rc}\nHOST_ELAPSED_SECONDS={time.monotonic()-start:.6f}\n')
    return rc


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('build', 'harness', 'sanitizer', 'out'):
        parser.add_argument('--' + name, required=True, type=Path)
    parser.add_argument('--cases', nargs='+', help='explicit diagnostic subset; never a complete matrix')
    parser.add_argument('--require-separate-cert', action='store_true')
    parser.add_argument('--helper-blocks', type=int, choices=range(1, 9))
    parser.add_argument('--include-max-budget', action='store_true')
    parser.add_argument('--admit', type=int, choices=(0, 1))
    parser.add_argument('--services', type=int, choices=range(4))
    parser.add_argument('--probe-calls', type=int, choices=(0, 1))
    parser.add_argument('--carveout', type=int, choices=range(-1, 101))
    parser.add_argument('--service-poll', type=int, choices=(0, 1))
    parser.add_argument('--timing-diag', action='store_true')
    parser.add_argument('--inject-wait-diag', action='store_true')
    parser.add_argument('--completed-filter', type=int, choices=(0, 1))
    parser.add_argument('--filter-diag', action='store_true')
    parser.add_argument('--bound-mode', type=int, choices=range(4))
    parser.add_argument('--bound-steps', type=int, default=32)
    parser.add_argument('--bound-diag', action='store_true')
    parser.add_argument('--publisher-diag', action='store_true')
    parser.add_argument('--neighbors', action='store_true')
    parser.add_argument('--helper-mirror', action='store_true')
    parser.add_argument('--search-diag', action='store_true')
    parser.add_argument('--select-labels', action='store_true')
    parser.add_argument('--returned-bound', action='store_true')
    parser.add_argument('--batch-binary', choices=('batch','unbound_diag'), default='batch')
    parser.add_argument('--neighbor-edge-limit', type=int, choices=range(1, 129), default=32)
    parser.add_argument('--sleep-ns', type=int)
    parser.add_argument('--service-shared-bytes', type=int)
    args = parser.parse_args()
    build, harness = args.build.resolve(strict=True), args.harness.resolve(strict=True)
    bm, hm = verify_tree(build), verify_tree(harness)
    if args.returned_bound:
        flags=json.loads((build/('diag_command.json' if args.bound_diag else 'batch_command.json')).read_text())
        if not args.neighbors or args.bound_mode is None or '-DL3_BATCH_BOUND_RETURNED=true' not in flags:parser.error('returned publisher requires matching bound build')
    if args.select_labels:
        flags=json.loads((build/('diag_command.json' if args.bound_diag else args.batch_binary+'_command.json')).read_text())
        if '-DL3_BATCH_LABEL_SELECT=true' not in flags:parser.error('requires label selection build')
    if args.search_diag:
        flags = json.loads((build/('diag_command.json' if args.bound_diag else args.batch_binary+'_command.json')).read_text())
        if '-DL3_BATCH_SEARCH_DIAG=true' not in flags or not args.helper_blocks:
            parser.error('search diagnostics require matching build and helper count')
    if args.helper_mirror and not args.neighbors:
        parser.error('helper mirror requires neighbors')
    if args.neighbors:
        flags = json.loads((build/('diag_command.json' if args.bound_diag else 'batch_command.json')).read_text())
        if args.bound_mode is None or '-DL3_BATCH_BOUND_NEIGHBORS=true' not in flags or args.publisher_diag:
            parser.error('neighbor mode requires matching build and bound mode, with scan publisher disabled')
        if args.helper_mirror and '-DL3_BATCH_BOUND_HELPER_LOCAL=true' not in flags:
            parser.error('helper mirror requires matching build')
    if Path(__file__).resolve() != harness / 'source/scripts/multigpu/run_l3_batch_runtime.py':
        parser.error('use frozen runner')
    args.out.mkdir(parents=True, exist_ok=False)
    out = args.out.resolve()
    allocation = slurm_preflight(out)
    sanitizer = args.sanitizer.resolve(strict=True)
    manifest = {'allocation': allocation, 'build': str(build), 'harness': str(harness),
                'build_manifest': bm, 'harness_manifest': hm, 'sanitizer': str(sanitizer),
                'sanitizer_sha256': sha256(sanitizer), 'scope': 'dirty_frozen_full_solver_correctness_only'}
    write_json(out / 'manifest.json', manifest)
    cases = []
    # The two controls establish baseline behavior before forced loan integration.
    for graph in ('ring', 'branch'):
        for source in (0, 2055):
            cases.extend((f'{graph}_s{source}_{label}', graph, source, kind, n, enabled, force, budget, None)
                         for label, kind, n, enabled, force, budget in (
                             ('control_n1', 'control', 1, 0, 0, 64),
                             ('control_n2', 'control', 2, 0, 0, 64),
                             ('disabled_n2', 'batch', 2, 0, 0, 64),
                             ('force8', 'batch', 2, 1, 1, 8),
                             ('force64', 'batch', 2, 1, 1, 64),
                             ('natural64', 'batch', 2, 1, 0, 64)) + (
                             (('force512', 'batch', 2, 1, 1, 512), ('natural512', 'batch', 2, 1, 0, 512))
                             if args.include_max_budget else ()))
    for tool in ('memcheck', 'racecheck', 'synccheck'):
        cases.append((tool, 'ring', 0, 'batch', 2, 1, 1, 64, tool))
    if args.cases:
        requested = set(args.cases)
        if requested - {c[0] for c in cases} or len(requested) != len(args.cases):
            parser.error('unknown or duplicate case')
        cases = [c for c in cases if c[0] in requested]
    write_json(out / 'selection.json', {'full_matrix': args.cases is None, 'cases': [c[0] for c in cases]})
    results = {}
    for label, graph_name, source, kind, n, enabled, force, budget, tool in cases:
        env = clean_environment()
        repeats = 1 if tool else 2
        env.update(MLMQ_WORK_BLOCKS='4', MLMQ_CUT_PERCENT='50', MLMQ_FINAL_AUDIT='all',
                   BENCH_SOURCE=str(source), BENCH_WARMUPS='0', BENCH_REPEATS=str(repeats),
                   MLMQ_BATCH_ENABLED=str(enabled), MLMQ_BATCH_FORCE=str(force), MLMQ_BATCH_SLOTS='128',
                   MLMQ_BATCH_BUDGET=str(budget), MLMQ_BATCH_MIN_SEEDS='1', CUDA_MODULE_LOADING='EAGER',
                   L3_SUPPLEMENT_ORACLE=str(harness / 'data' / f'{graph_name}_s{source}.oracle'))
        if args.helper_blocks:
            env['MLMQ_BATCH_HELPER_BLOCKS'] = str(args.helper_blocks)
        if args.admit is not None:
            env['MLMQ_BATCH_ADMIT'] = str(args.admit)
        if args.services is not None:
            env['MLMQ_BATCH_SERVICES'] = str(args.services)
        if args.probe_calls is not None:
            env['MLMQ_BATCH_PROBE_CALLS'] = str(args.probe_calls)
        if args.carveout is not None:
            env['MLMQ_BATCH_SERVICE_CARVEOUT'] = str(args.carveout)
        if args.service_poll is not None:
            env['MLMQ_BATCH_SERVICE_POLL'] = str(args.service_poll)
        if args.service_shared_bytes is not None:
            env['MLMQ_BATCH_SERVICE_SHARED_BYTES'] = str(args.service_shared_bytes)
        if args.sleep_ns is not None:
            env['MLMQ_BATCH_SLEEP_NS'] = str(args.sleep_ns)
        if args.bound_mode is not None:
            env['MLMQ_BATCH_BOUND_MODE'] = str(args.bound_mode)
            env['MLMQ_BATCH_BOUND_STEPS'] = str(args.bound_steps)
        if args.neighbors:
            env['MLMQ_BATCH_BOUND_EDGE_LIMIT'] = str(args.neighbor_edge_limit)
        binary_kind = ('diag' if args.bound_diag else args.batch_binary) if kind == 'batch' else kind
        command = [str(build / ('mlmq_' + binary_kind)), '-i', str(harness / 'data' / (graph_name + '.gr')),
                   '-n', str(n), '-d', '400000']
        if tool:
            command = [str(sanitizer), '--tool', tool, '--error-exitcode', '9'] + command
        command = ['/usr/bin/stdbuf', '-oL', '-eL'] + command
        record = {'command': command, 'environment': env, 'state': 'running'}
        results[label] = record
        write_json(out / 'status.json', {'complete': False, 'results': results})
        print('RUN', label, flush=True)
        try:
            snapshot, apps = gpu_snapshot()
            (out / (label + '.gpu_before.log')).write_text(snapshot)
            if apps:
                raise ValueError('compute process present before case')
            record['rc'] = execute(command, env, out / (label + '.log'), 180 if tool else 40)
            raw = (out / (label + '.log')).read_text()
            record['samples'] = parse_bench(raw)
            ok, reason = validate(record['samples'], 'MLMQ', n, source, 'L1SLF_L2DQ', 0, repeats)
            if record['rc'] or not ok or 'Error at node' in raw or not sanitizer_passed(raw, tool):
                raise ValueError(f'rc={record["rc"]}, {reason}, sanitizer={sanitizer_passed(raw, tool)}')
            record['oracle'] = parse_oracle_contract(raw, repeats, 4096)
            if not record['oracle']['valid']:
                raise ValueError(record['oracle'])
            record['final_state'] = parse_final_state(raw, repeats, n, args.require_separate_cert and bool(enabled))
            if args.timing_diag:
                record['timing'] = parse_timing(raw, repeats, n)
            if args.inject_wait_diag:
                record['manager_wait'] = parse_manager_wait(raw, repeats)
                record['inject_wait'] = parse_inject_wait(raw, repeats)
            if n == 2:
                record['dual'] = parse_dual_contract(raw, repeats, 4, 400000, QUEUE_TYPE_IDS['L1SLF_L2DQ'],
                    expected_window_mode=2, expected_window_min=25000, expected_window_max=25000,
                    expected_idle_backoff=0, require_l2_final=True, expected_worker_recovery=1,
                    expected_ack_capacity=107*16)
                if not record['dual']['valid']:
                    raise ValueError(record['dual']['errors'])
            if enabled:
                record['runtime'] = parse_runtime(raw, repeats, budget, force, bool(force) and args.admit != 0)
                if args.select_labels:
                    record['selection']=parse_select(raw,repeats)
                if args.bound_mode is not None:
                    record['bound'] = parse_bound(raw, repeats, args.bound_mode, args.bound_steps, int(args.bound_diag))
                    if args.publisher_diag:
                        record['publisher'] = parse_bound_publisher(raw, repeats, args.bound_mode, args.bound_steps, record['bound']['config'])
                    if args.neighbors:
                        record['neighbors'] = parse_bound_neighbors(raw, repeats, args.bound_mode,
                            args.neighbor_edge_limit, int(args.bound_diag), record['runtime'])
                    if args.helper_mirror:
                        record['placement'] = parse_bound_placement(raw, repeats, record['bound']['config'])
                    if args.returned_bound:
                        record['returned'] = parse_bound_returned(raw,repeats,args.bound_mode,int(args.bound_diag),record['runtime'])
                if args.completed_filter is not None:
                    record['completed_filter'] = parse_completed_filter(raw, repeats, args.completed_filter, int(args.filter_diag))
                if args.helper_blocks:
                    record['helpers'] = parse_helpers(raw, repeats, args.helper_blocks, record['runtime'])
                if args.search_diag:
                    record['search'] = parse_search(raw, repeats, budget, args.helper_blocks, record['runtime'], record['helpers'])
                if args.admit is not None:
                    record['admission'] = parse_admission(raw, repeats, args.admit, record['runtime'])
                if args.services is not None or args.probe_calls is not None:
                    record['services'] = parse_services(raw, repeats, args.services if args.services is not None else 3,
                                                        args.probe_calls if args.probe_calls is not None else 1)
                if args.carveout is not None:
                    record['cache'] = parse_cache(raw, repeats, args.carveout)
                if args.service_poll is not None:
                    record['poll'] = parse_poll(raw, repeats, args.service_poll)
                if args.service_shared_bytes is not None:
                    record['shared'] = parse_shared(raw, repeats, args.service_shared_bytes)
                if args.sleep_ns is not None:
                    record['sleep'] = parse_sleep(raw, repeats, args.sleep_ns)
                    record['loops'] = parse_loops(raw, repeats, args.helper_blocks or 1,
                                                 args.services if args.services is not None else 3)
            elif 'L3_BATCH_RUNTIME_AUDIT ' in raw:
                raise ValueError('disabled runtime unexpectedly active')
            snapshot, apps = gpu_snapshot()
            (out / (label + '.gpu_after.log')).write_text(snapshot)
            if apps:
                raise ValueError('compute process remains after case')
            record['state'] = 'passed'
        except Exception as error:
            record.update(state='failed', error=str(error))
            write_json(out / 'status.json', {'complete': False, 'results': results})
            raise
        write_json(out / 'status.json', {'complete': False, 'results': results})
        print('PASS', label, flush=True)
    verify_tree(build)
    verify_tree(harness)
    if sha256(sanitizer) != manifest['sanitizer_sha256']:
        raise ValueError('sanitizer changed during run')
    write_json(out / 'summary.json', {'valid': True, 'full_matrix': args.cases is None,
                                    'results': results, 'performance_evidence': False})
    write_json(out / 'status.json', {'complete': True, 'results': results})
    print('BATCH_RUNTIME_INTEGRATION_PASS performance_evidence=0', flush=True)


if __name__ == '__main__':
    main()
