#include "SSSP/l3/l3_batch_completed_filter.cuh"
#include <cstdio>
#include <cstdlib>

static void check(cudaError_t rc) {
    if (rc != cudaSuccess) { std::fprintf(stderr, "%s\n", cudaGetErrorString(rc)); std::exit(2); }
}
struct state {
    int certificate[16], distance[16], errors, ack, witness;
};
__global__ void boundaries(state *s) {
    const int i = threadIdx.x;
    const int certificates[8] = {INT_MAX, 10, 10, 10, 0, 0, INT_MAX, INT_MAX-1};
    const int distances[8] = {7, 10, 11, 9, 0, 1, INT_MAX, INT_MAX-2};
    const bool expected[8] = {false, true, true, false, true, true, false, false};
    if (i < 8) { s->certificate[i+3] = certificates[i]; s->distance[i+3] = distances[i]; }
    __syncthreads();
    if (i < 8 && l3_batch_completed_filter::covered(s->certificate,i+3,s->distance) != expected[i])
        atomicAdd(&s->errors,1);
    if (!i && l3_batch_completed_filter::covered(nullptr,7,nullptr)) atomicAdd(&s->errors,1);
}
// A real acquire predicate observes a release certificate, with a test-only
// witness standing in for the already-durable outputs. ACK prevents the next
// publication from overwriting the witness before the consumer has read it.
__global__ void publication(state *s) {
    if (threadIdx.x) return;
    for (int round=0;round<256;++round) {
        const int expected=1000-round;
        if (!blockIdx.x) {
            while (l3_atomic_load_acquire<cuda::thread_scope_device>(&s->ack)!=round) {}
            s->witness=round+1;
            auto word=cuda::atomic_ref<int,cuda::thread_scope_device>(s->certificate[0]);
            int old=word.load(cuda::memory_order_relaxed);
            while(expected<old && !word.compare_exchange_weak(old,expected,
                  cuda::memory_order_release,cuda::memory_order_relaxed)) {}
        } else {
            while (l3_atomic_load_relaxed<cuda::thread_scope_device>(s->certificate)>expected) {}
            if (!l3_batch_completed_filter::covered(s->certificate,0,s->distance)) atomicAdd(&s->errors,1);
            if (s->witness!=round+1) atomicAdd(&s->errors,1);
            s->distance[0]=expected-1;
            if (l3_batch_completed_filter::covered(s->certificate,0,s->distance)) atomicAdd(&s->errors,1);
            s->distance[0]=10000;
            l3_atomic_store_release<cuda::thread_scope_device>(&s->ack,round+1);
        }
    }
}
int main() {
    if (!std::getenv("SLURM_JOB_ID")) return 4;
    int devices=0;check(cudaGetDeviceCount(&devices));if(devices!=2)return 5;
    for(int gpu=0;gpu<2;++gpu) {
        check(cudaSetDevice(gpu));state host{};state *device;check(cudaMalloc(&device,sizeof(state)));
        check(cudaMemset(device,0,sizeof(state)));boundaries<<<1,32>>>(device);check(cudaGetLastError());check(cudaDeviceSynchronize());
        check(cudaMemcpy(&host,device,sizeof(state),cudaMemcpyDeviceToHost));if(host.errors)return 6;
        host={};host.certificate[0]=INT_MAX;host.distance[0]=10000;
        check(cudaMemcpy(device,&host,sizeof(state),cudaMemcpyHostToDevice));
        publication<<<2,32>>>(device);check(cudaGetLastError());check(cudaDeviceSynchronize());
        check(cudaMemcpy(&host,device,sizeof(state),cudaMemcpyDeviceToHost));
        if(host.errors || host.ack!=256 || host.certificate[0]!=745)return 7;
        check(cudaFree(device));
    }
    std::printf("COMPLETED_FILTER_PASS cases=1042 epochs=512 devices=2\n");
}
