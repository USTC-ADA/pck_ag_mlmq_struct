#pragma once
#include "../../SSSP/l3/l3_batch_commit_parallel.cuh"
#ifdef L3_TEST_PACKED_COMPACT
#include "../../SSSP/l3/l3_batch_peer_packed.cuh"
#endif
// Explicit opt-in for the existing real-DQ/peer/remote/L1 fixtures. Their
// owner blocks contain exactly one warp; production uses per-loan global
// storage instead. Only the new intake/APPLY are substituted.
namespace l3_test_commit_warp {
using namespace l3_batch_commit_warp;
template<int N>
__device__ l3_batch_commit::result prepare(l3_batch_commit::state<N> &s,
    std::uint64_t generation, intent &p, int *distance, int lane) {
    assert(blockDim.x == 32);
    return l3_batch_commit_parallel::prepare(s, generation, p, distance, lane);
}
}
namespace l3_test_peer_commit {
using namespace l3_batch_peer_commit;
#ifdef L3_TEST_PACKED_COMPACT
using l3_batch_peer_packed::execute_claimed;
#endif
template<int N>
__device__ bool accept_return(l3_batch_commit::state<N> &s, packet *p,
    l3_batch_commit::record *journal, int lane) {
    assert(blockDim.x == 32);
    __shared__ l3_batch_commit_parallel::workspace validation;
    return l3_batch_commit_parallel::accept_return(s, p, journal, validation, lane);
}
}
