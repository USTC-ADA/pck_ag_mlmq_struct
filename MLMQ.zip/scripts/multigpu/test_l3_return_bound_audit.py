import unittest,copy
from l3_bound_fixture import INF,returned_cases,audit_record
from run_l3_batch_runtime import parse_bound_returned
class ReturnedTests(unittest.TestCase):
    def valid_fixture(self):
        c=returned_cases()[1]
        r=dict(owner=0,query=0,mode=2,status=0,rows=2,counts=[2,1,1],tickets=[[2,2]],publication='returned',
          publisher_counts=[2,2],returned_guard_checks=16,mirror_gpu=1,mirror=[INF,INF,2]+[INF]*9,
          journal=[[0,0,0],[1,1,1]],search=dict(loans=1,seeds=1,rows=2,certified=2,records=2,remaining=0,capacity=0,empty=1,budget=0,failure=0))
        return c,r
    def test_pending_ticket_after_commit_covers_successor(self):
        c,r=self.valid_fixture();audit_record(c,r)
    def test_return_publisher_rejects_unwitnessed_mirror(self):
        c,r=self.valid_fixture();r['mirror'][0]=0
        with self.assertRaisesRegex(ValueError,'mirror/reset'):audit_record(c,r)
    def test_guard_and_publisher_count_required(self):
        for field,value in (('returned_guard_checks',0),('publisher_counts',[1,1])):
            c,r=self.valid_fixture();r[field]=value
            with self.assertRaises(ValueError):audit_record(c,r)
    def lines(self,instrumented=1,off=False):
        rt=[dict(gpu=g,loans=2,records=5) for g in (0,1)];rows=[]
        for g in (0,1):
            vals=(-1,-1,-1) if not instrumented else (0,0,0) if off else (2,5,4)
            rows += [f'L3_BATCH_BOUND_RETURNED_CONFIG gpu={g} after_finished=1',f'L3_BATCH_BOUND_RETURNED_AUDIT gpu={g} instrumented={instrumented} loans={vals[0]} records={vals[1]} published={vals[2]}']
        return '\n'.join(rows),rt
    def test_runtime_counts_and_performance_not_measured(self):
        for instrumented in (0,1):
            for mode in (0,1,2,3):
                raw,rt=self.lines(instrumented,mode==0);parse_bound_returned(raw,1,mode,instrumented,rt)
    def test_runtime_malformed_or_early_publication_rejected(self):
        raw,rt=self.lines()
        for bad in (raw.replace('gpu=1','gpu=0'),raw.replace('after_finished=1','after_finished=0'),raw.replace('records=5','records=4'),raw.replace('published=4','published=6'),raw+'\nL3_BATCH_BOUND_RETURNED_AUDIT bad'):
            with self.assertRaises(ValueError):parse_bound_returned(bad,1,2,1,rt)
        with self.assertRaises(ValueError):parse_bound_returned(raw,1,0,1,rt)
if __name__=='__main__':unittest.main()
