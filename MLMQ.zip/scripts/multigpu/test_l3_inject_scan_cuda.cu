// The builder extracts both collector bodies and node constructors verbatim
// from the frozen solver. This tests ownership at deterministic boundaries;
// full-solver validation separately covers the actual termination protocol.
#include "collector_under_test.cuh"
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <algorithm>

static void check(cudaError_t rc) {
    if (rc != cudaSuccess) {
        std::fprintf(stderr, "CUDA_FAIL %s\n", cudaGetErrorString(rc));
        std::exit(2);
    }
}
static void require(bool ok, const char *why) {
    if (!ok) { std::fprintf(stderr, "SCAN_FAIL %s\n", why); std::exit(3); }
}
constexpr int vertices = 2051, words = 96, begin_vertex = 37;
struct state {
    unsigned dirty[words], hint[3];
    int distance[vertices + 1], request, count;
    node_struct output[32];
};
__global__ void collect(state *s, int nohint, int capacity, bool output_trigger) {
    int count = 0;
    // Test-only alias: the first emitted id makes the stop word nonzero.
    // This deterministically requests return after processing the first block
    // without depending on a scheduling race with a second CTA.
    int *stop = output_trigger ? &s->output[0].id : &s->request;
    if (nohint)
        collect_dirty_slice_nohint(s->dirty, s->hint, 0, words, vertices,
            begin_vertex, s->distance, s->output, count, capacity, stop);
    else
        collect_dirty_slice(s->dirty, s->hint, 0, words, vertices,
            begin_vertex, s->distance, s->output, count, capacity, stop);
    if (!threadIdx.x) s->count = count;
}
static void mark(state &s, int vertex) {
    s.dirty[vertex / 32] |= 1u << (vertex % 32);
    s.hint[vertex / 1024] |= 1u << ((vertex / 32) % 32);
}
static state fresh() {
    state s{};
    for (int v = 0; v < vertices; ++v) s.distance[v + 1] = 100 + v;
    for (int v : {0, 4, 1023, 1026, 2050}) mark(s, v);
    return s;
}
static std::vector<int> remaining(const state &s) {
    std::vector<int> result;
    for (int v = 0; v < vertices; ++v)
        if (s.dirty[v / 32] & (1u << (v % 32))) result.push_back(v);
    return result;
}
static std::vector<int> emitted(const state &s) {
    std::vector<int> result;
    require(s.count >= 0 && s.count <= 32, "count bounds");
    for (int i = 0; i < s.count; ++i) {
        int v = s.output[i].id - begin_vertex - 1;
        require(v >= 0 && v < vertices, "global vertex offset");
        require(s.output[i].dist == 100 + v, "authoritative distance");
        result.push_back(v);
    }
    std::sort(result.begin(), result.end());
    return result;
}
int main() {
    require(std::getenv("SLURM_JOB_ID") != nullptr, "Slurm allocation required");
    int devices = 0; check(cudaGetDeviceCount(&devices)); require(devices == 2, "two visible GPUs");
    int cases = 0;
    for (int gpu = 0; gpu < devices; ++gpu) {
        check(cudaSetDevice(gpu)); state *device; check(cudaMalloc(&device, sizeof(state)));
        auto run = [&](state &s, int nohint, int capacity, bool trigger) {
            check(cudaMemcpy(device, &s, sizeof(s), cudaMemcpyHostToDevice));
            collect<<<1, 32>>>(device, nohint, capacity, trigger);
            check(cudaGetLastError()); check(cudaDeviceSynchronize());
            check(cudaMemcpy(&s, device, sizeof(s), cudaMemcpyDeviceToHost));
        };
        for (int nohint = 0; nohint != 2; ++nohint) {
            const std::vector<int> all{0, 4, 1023, 1026, 2050};
            state s = fresh(); s.request = 71; run(s, nohint, 32, false);
            require(emitted(s).empty() && remaining(s) == all, "preexisting request preserves all dirty"); ++cases;
            s.request = 0; run(s, nohint, 32, false);
            require(emitted(s) == all && remaining(s).empty(), "cancel request drains remaining work"); ++cases;
            s = fresh(); run(s, nohint, 32, true);
            require(emitted(s) == std::vector<int>({0, 4, 1023}) &&
                    remaining(s) == std::vector<int>({1026, 2050}), "midscan return preserves later blocks"); ++cases;
            run(s, nohint, 32, false);
            require(emitted(s) == std::vector<int>({1026, 2050}) && remaining(s).empty(), "resume after midscan return"); ++cases;
            s = fresh(); std::vector<int> got;
            for (int i = 0; i < 5; ++i) {
                run(s, nohint, 1, false); auto values = emitted(s);
                require(values.size() == 1, "capacity progresses"); got.push_back(values[0]);
            }
            std::sort(got.begin(), got.end());
            require(got == all && remaining(s).empty(), "capacity restore has no loss or duplicate"); ++cases;
            s = fresh(); s.distance[5] = DIST_MAX; run(s, nohint, 32, false);
            require(emitted(s) == std::vector<int>({0, 1023, 1026, 2050}) &&
                    remaining(s) == std::vector<int>({4}) && (s.hint[0] & 1), "unavailable distance remains dirty and hinted");
            s.distance[5] = 104; run(s, nohint, 32, false);
            require(emitted(s) == std::vector<int>({4}) && remaining(s).empty(), "restored distance progresses"); ++cases;
        }
        state s = fresh(); std::fill(s.hint, s.hint + 3, 0u); run(s, 1, 32, false);
        require(emitted(s) == std::vector<int>({0, 4, 1023, 1026, 2050}) && remaining(s).empty(), "nohint recovers false negative"); ++cases;
        check(cudaFree(device));
    }
    std::printf("INJECT_SCAN_PASS cases=%d devices=%d\n", cases, devices);
}
