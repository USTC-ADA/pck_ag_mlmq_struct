import copy
import json
from pathlib import Path
import tempfile
import unittest

from run_l3_batch_peer_commit import parse_cases, verify_build
from run_l3_upgrade_stage2 import sha256


def fixture(quick):
    lines = []
    rounds = 5 if quick else 20
    for o in (0, 1):
        for b in ((37,) if quick else (0, 37)):
            for g in ((33, 1024) if quick else (33, 768, 1024)):
                lines.append(f'BATCH_PEER_COMMIT_CASE owner={o} helper={1-o} begin={b} group={g} '
                             f'rounds={rounds} fallbacks={rounds//5*2} distinct512={int(g>=512)} '
                             f'capacity_stops={int(g==1024)} total_writes=100 flushes=2 consumed_before_ack=1 PASS')
    lines.append(f'BATCH_PEER_COMMIT_PASS cases={len(lines)} actual_peer=1 actual_dq=1 '
                 'no_remote_sink=1 no_l1=1 no_solver=1 not_performance=1')
    return '\n'.join(lines) + '\n'


class PeerRunnerTests(unittest.TestCase):
    def test_exact_coverage(self):
        self.assertEqual(len(parse_cases(fixture(True), True)), 4)
        self.assertEqual(len(parse_cases(fixture(False), False)), 12)

    def test_missing_duplicate_and_wrong_directions(self):
        raw = fixture(True)
        for bad in ('\n'.join(raw.splitlines()[1:]), raw + raw.splitlines()[0] + '\n',
                    raw.replace('owner=1 helper=0', 'owner=1 helper=1'),
                    raw.replace('begin=37', 'begin=0'), raw.replace('group=1024', 'group=768')):
            with self.assertRaises(ValueError):
                parse_cases(bad, True)

    def test_incomplete_contract(self):
        raw = fixture(True)
        for before, after in (('rounds=5', 'rounds=4'), ('fallbacks=2', 'fallbacks=0'),
                              ('distinct512=1', 'distinct512=0'), ('capacity_stops=1', 'capacity_stops=0'),
                              ('total_writes=100', 'total_writes=8'), ('flushes=2', 'flushes=0'),
                              ('consumed_before_ack=1', 'consumed_before_ack=0'),
                              ('no_solver=1', 'no_solver=0')):
            with self.assertRaises(ValueError):
                parse_cases(raw.replace(before, after), True)

    def test_marker_and_mode(self):
        raw = fixture(True)
        for bad in (raw + raw.splitlines()[-1] + '\n', '\n'.join(raw.splitlines()[:-1]), ''):
            with self.assertRaises(ValueError):
                parse_cases(bad, True)
        with self.assertRaises(ValueError):
            parse_cases(raw, False)

    def test_frozen_manifest(self):
        names = ['test_sm80', 'source.tgz', 'build_command.json',
                 'source/scripts/multigpu/run_l3_batch_peer_commit.py',
                 'source/scripts/multigpu/test_l3_batch_peer_commit.cu',
                 'source/SSSP/l3/l3_batch_peer_commit.cuh']
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary).resolve()
            for name in names:
                path = root / name
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_text(name)
            manifest = {'valid_build': True, 'architecture': 'sm_80', 'assertions_enabled': True,
                        'hashes': {name: sha256(root / name) for name in names}}
            def check(value):
                (root / 'manifest.json').write_text(json.dumps(value))
                return verify_build(root)
            self.assertEqual(check(manifest), manifest)
            for key, value in (('architecture', 'sm_86'), ('assertions_enabled', False), ('hashes', {})):
                bad = copy.deepcopy(manifest); bad[key] = value
                with self.assertRaises(ValueError):
                    check(bad)
            bad = copy.deepcopy(manifest); del bad['hashes'][names[0]]
            with self.assertRaises(ValueError):
                check(bad)
            (root / 'test_sm80').write_text('changed after submit')
            with self.assertRaises(ValueError):
                check(manifest)


if __name__ == '__main__':
    unittest.main()
