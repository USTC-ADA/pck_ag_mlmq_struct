#!/usr/bin/env python3
"""CPU counterfactual: global min-32 waves, same seed/budget/capacity contract.
No GPU execution or speed estimate. The frozen GPU auditor validates model traces.
"""
from pathlib import Path
import argparse,json,collections
from audit_l3_packed_trace import INF,Graph,load_batches,audit_record,sha,require

def model(g,b,index,width=32):
    labels={}
    for v,d in b['seeds']:labels[v]=min(labels.get(v,INF),d)
    cert={};pending=set(labels);waves=[];rows=scans=0;capacity=False
    own=lambda v:b['begin']<=v<b['end']
    while pending and rows<512:
        selected=sorted(pending,key=lambda v:(labels[v],v))[:min(width,512-rows)]
        wave=[[v,labels[v],int(labels[v]<cert.get(v,INF))] for v in selected];waves.append(wave)
        if sum(g.degree(v) for v,d,e in wave if e)>768-len(labels):capacity=True;break
        pending.difference_update(selected)
        for v,d,e in wave:
            if not e:continue
            for dest,w in g.edges(v):
                candidate=d+w
                if candidate<INF and candidate<labels.get(dest,INF):
                    labels[dest]=candidate
                    if own(dest):pending.add(dest)
        for v,d,e in wave:
            if e:cert[v]=min(cert.get(v,INF),d)
        rows+=sum(x[2] for x in wave);scans+=1
    counts=[1,len(b['seeds']),rows,len(cert),len(labels),len(pending),int(capacity),int(not capacity and not pending),int(not capacity and bool(pending)),0]
    return dict(owner=b['owner'],executor=1-b['owner'],batch=index,round=0,policy=0,budget=512,rows=rows,scans=scans,pending=len(pending),counts=counts,
        journal=[[v,d,cert.get(v,INF)] for v,d in sorted(labels.items())],waves=waves)

def wave_geometry(g,b,r):
    labels={}
    for v,d in b['seeds']:labels[v]=min(labels.get(v,INF),d)
    pending=set(labels);cert={};totals=collections.Counter()
    own=lambda v:b['begin']<=v<b['end']
    for wave in r['waves']:
        selected={x[0] for x in wave}
        maximum=max(d for v,d,e in wave)
        totals['attempted_waves']+=1;totals['sum_pending_width']+=len(pending)
        totals['waves_with_pending_over_32']+=len(pending)>32
        missed=sum(labels[v]<maximum for v in pending-selected)
        totals['waves_skipping_strictly_lower_label']+=missed>0;totals['missed_lower_labels']+=missed
        if sum(g.degree(v) for v,d,e in wave if e)>768-len(labels):break
        totals['accepted_waves']+=1;totals['sum_take']+=len(wave)
        pending.difference_update(selected)
        for v,d,e in wave:
            if not e:continue
            for dest,w in g.edges(v):
                candidate=d+w
                if candidate<INF and candidate<labels.get(dest,INF):
                    labels[dest]=candidate
                    if own(dest):pending.add(dest)
        for v,d,e in wave:
            if e:cert[v]=min(cert.get(v,INF),d)
    return totals

def main():
    p=argparse.ArgumentParser();p.add_argument('--capture',type=Path,required=True);p.add_argument('--gpu',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
    a.out.mkdir(parents=True,exist_ok=False)
    c=json.loads((a.capture/'capture.json').read_text());m=c['manifest']
    require(sha(m['graph'])==m['graph_sha256'] and sha(a.capture/'batches.txt')==c['batches_sha256'],'input hash')
    g=Graph(m['graph']);batches=load_batches(a.capture/'batches.txt',g)
    totals=collections.defaultdict(collections.Counter);geometry=collections.defaultdict(collections.Counter);model_values={};gpu_values={}
    with (a.out/'global_min32.jsonl').open('w') as f:
        for i,b in enumerate(batches):
            row=model(g,b,i);value=audit_record(g,b,row);model_values[i]=value
            totals['cpu_global_min32'].update(value);geometry['cpu_global_min32'].update(wave_geometry(g,b,row));f.write(json.dumps(row,separators=(',',':'))+'\n')
    seen=set()
    for line in a.gpu.open():
        row=json.loads(line);i,r,p=row['batch'],row['round'],row['policy'];key=(i,r,p)
        require(key not in seen,'duplicate GPU record');seen.add(key)
        value=audit_record(g,batches[i],row);gpu_values[key]=value
        label=f'gpu_policy{p}_round{r}';totals[label].update(value);geometry[label].update(wave_geometry(g,batches[i],row))
    require(seen=={(i,r,p) for i in range(len(batches)) for r in (0,1) for p in (0,1)},'missing GPU input')
    pairs=[]
    for (i,r,p),v in sorted(gpu_values.items()):
        z=model_values[i];pairs.append(dict(batch=i,round=r,policy=p,rows_delta=z['rows']-v['rows'],certified_delta=z['certified']-v['certified'],repeated_delta=z['repeated']-v['repeated'],records_delta=z['records']-v['records']))
    result=dict(valid=True,cpu_model='global min32; vertex-id ties; all original complete-wave capacity checks',model_journals=len(batches),gpu_journals=len(seen),input_sha256=sha(a.gpu),totals=dict(totals),geometry=dict(geometry),paired=pairs,limits=['CPU model only, not executed GPU scheduling or a performance bound','GPU atomic insertion order differs between repeats','fixed historical eligible seeds; no owner mirror or live loan obligations','fewer repeat rows may trade against capacity and frontier/output volume'])
    (a.out/'summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='paired'},indent=2))
if __name__=='__main__':main()
