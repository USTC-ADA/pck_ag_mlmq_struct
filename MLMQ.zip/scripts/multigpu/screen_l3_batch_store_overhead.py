#!/usr/bin/env python3
"""Runtime-disabled causal screen of ordinary atomicMin versus original store."""
import argparse
import json
from pathlib import Path
from statistics import median
from run_l3_batch_runtime import verify_tree
from run_l3_upgrade_stage2 import clean_environment, sha256, slurm_preflight, write_json
from run_usa_road_matrix import run_one
from run_l3_30h import parse_dual_contract, parse_oracle_contract


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('reference-build', 'store-build', 'harness', 'contract', 'out'):
        parser.add_argument('--' + name, required=True, type=Path)
    args = parser.parse_args()
    reference, store, harness = (p.resolve(strict=True) for p in (args.reference_build, args.store_build, args.harness))
    manifests = {str(p): verify_tree(p) for p in (reference, store, harness)}
    if not manifests[str(store)].get('requires_runtime_disabled'):
        raise ValueError('store build must have explicit disabled-only guard')
    if Path(__file__).resolve() != harness / 'source/scripts/multigpu/screen_l3_batch_store_overhead.py':
        parser.error('use frozen harness')
    contract = json.loads(args.contract.read_text())
    graph, oracle = Path(contract['graph_path']), Path(contract['oracle_path'])
    if sha256(graph) != contract['graph_sha256'] or sha256(oracle) != contract['oracle_sha256']:
        raise ValueError('input mismatch')
    args.out.mkdir(parents=True, exist_ok=False)
    out = args.out.resolve()
    allocation = slurm_preflight(out)
    configs = [('C2_104', reference / 'mlmq_control'), ('atomic_off', reference / 'mlmq_batch'),
               ('store_off', store / 'mlmq_batch')]
    write_json(out / 'manifest.json', {'manifests': manifests, 'contract': contract, 'allocation': allocation,
        'scope': 'exploratory disabled-runtime overhead attribution only', 'warmups': 1, 'repeats': 3, 'rounds': 2})
    results = {}
    for round_index in range(2):
        for label, binary in (configs if round_index == 0 else list(reversed(configs))):
            key = f'r{round_index}_{label}'
            env = clean_environment()
            env.update(MLMQ_WORK_BLOCKS='104', MLMQ_CUT_PERCENT=str(contract['cut_percent']),
                BENCH_SOURCE=str(contract['source']), BENCH_WARMUPS='1', BENCH_REPEATS='3',
                CUDA_MODULE_LOADING='EAGER', L3_SUPPLEMENT_ORACLE=str(oracle), MLMQ_BATCH_ENABLED='0')
            print('RUN', key, flush=True)
            record = run_one(binary, graph, 'MLMQ', 2, out / key, env, contract['source'],
                             'L1SLF_L2DQ', 1, 3, 180, delta=contract['delta'])
            record['environment'] = env
            results[key] = record
            raw = (out / (key + '.log')).read_text()
            record['oracle'] = parse_oracle_contract(raw, 4, contract['vertices'])
            record['dual'] = parse_dual_contract(raw, 4, 104, contract['delta'], 19, require_l2_final=True,
                expected_window_mode=2, expected_window_min=25000, expected_window_max=25000,
                expected_idle_backoff=0, expected_worker_recovery=1, expected_ack_capacity=1712)
            record['valid'] = record['valid'] and record['oracle']['valid'] and record['dual']['valid'] and 'L3_BATCH_RUNTIME_AUDIT' not in raw
            write_json(out / 'status.json', {'complete': False, 'results': results})
            if not record['valid']:
                raise RuntimeError('failed overhead case ' + key)
            print('PASS', key, flush=True)
    grouped = {}
    for label, _ in configs:
        samples = [s for i in range(2) for s in results[f'r{i}_{label}']['samples'] if s['warmup'] == '0']
        grouped[label] = {field: {'samples': [float(s[field]) for s in samples],
                                 'median': median(float(s[field]) for s in samples)} for field in ('solve_ms', 'query_wall_ms')}
    for path in (reference, store, harness):
        verify_tree(path)
    write_json(out / 'summary.json', {'valid': True, 'runtime_enabled': False, 'target_acceptance': False,
        'grouped': grouped, 'results': results})
    write_json(out / 'status.json', {'complete': True, 'results': results})
    print(json.dumps(grouped, indent=2), flush=True)


if __name__ == '__main__':
    main()
