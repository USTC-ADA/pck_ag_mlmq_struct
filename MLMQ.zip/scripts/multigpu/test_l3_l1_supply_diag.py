#!/usr/bin/env python3
"""CPU-only tests for the private-L1 diagnostic evidence gate."""

import unittest

from run_l3_balance_diag import parse_l1_supply


def fixture():
    lines = []
    for gpu in (0, 1):
        lines.extend([
            f"L3_L1_SUPPLY_CONFIG gpu={gpu} warps=1712 bins=128 bin_shift=21 "
            "max_batch=32 observational=1",
            f"L3_Q2_TAIL gpu={gpu} bin=2 since=4200000 total=150 available=0 "
            f"local_term=0 peer_term={2 if gpu == 0 else 0}",
            f"L3_L1_SUPPLY gpu={gpu} bin=2 sampled=10 nonempty=2 raw=30 "
            "eligible=24 edges=60 invalid=0 max_raw=16 max_eligible=16 "
            "max_edges=40 max_degree=3 ge8=2 ge16=1",
        ])
    return "\n".join(lines)


class SupplyContractTests(unittest.TestCase):
    def test_valid_observational_rows(self):
        result = parse_l1_supply(fixture())
        self.assertEqual(result["errors"], [])
        self.assertEqual(len(result["peer_quiescing_or_ready_bins"]), 1)

    def test_no_quiet_bins_is_a_valid_negative_observation(self):
        result = parse_l1_supply(fixture().replace("peer_term=2", "peer_term=0"))
        self.assertEqual(result["errors"], [])
        self.assertEqual(result["peer_quiescing_or_ready_bins"], [])

    def test_missing_gpu_is_rejected(self):
        raw = "\n".join(line for line in fixture().splitlines() if "gpu=0" in line)
        self.assertTrue(parse_l1_supply(raw)["errors"])

    def test_duplicate_bins_and_configs_are_rejected(self):
        for line in fixture().splitlines()[:3]:
            with self.subTest(line=line):
                self.assertTrue(parse_l1_supply(fixture() + "\n" + line)["errors"])

    def test_invalid_counts_are_rejected(self):
        for before, after in (
            ("eligible=24", "eligible=31"),
            ("sampled=10", "sampled=1713"),
            ("max_raw=16", "max_raw=33"),
            ("max_eligible=16", "max_eligible=17"),
            ("invalid=0", "invalid=1"),
            ("ge16=1", "ge16=2"),
            ("raw=30", "raw=-1"),
            ("edges=60", "edges=39"),
            ("max_degree=3", "max_degree=41"),
            ("since=4200000", "since=1"),
        ):
            with self.subTest(before=before, after=after):
                self.assertTrue(parse_l1_supply(fixture().replace(before, after))["errors"])

    def test_missing_bin_and_malformed_fields_are_rejected(self):
        for raw in (
            fixture().replace("L3_L1_SUPPLY gpu=1", "UNRECOGNIZED gpu=1"),
            fixture().replace("ge16=1", "ge16=1 extra=2"),
            fixture().replace("ge16=1", "ge16=1 ge16=1"),
        ):
            self.assertTrue(parse_l1_supply(raw)["errors"])

    def test_empty_observation_is_not_evidence_of_empty_queues(self):
        raw = fixture().replace(
            "sampled=10 nonempty=2 raw=30 eligible=24 edges=60 invalid=0 "
            "max_raw=16 max_eligible=16 max_edges=40 max_degree=3 ge8=2 ge16=1",
            "sampled=0 nonempty=0 raw=0 eligible=0 edges=0 invalid=0 "
            "max_raw=0 max_eligible=0 max_edges=0 max_degree=0 ge8=0 ge16=0")
        self.assertTrue(parse_l1_supply(raw)["errors"])


if __name__ == "__main__":
    unittest.main()
