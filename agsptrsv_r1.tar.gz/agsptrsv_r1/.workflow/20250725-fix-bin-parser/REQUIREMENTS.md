# Requirements: Fix gr2csr_bin.py per-block layout bug

## Vision
Binary `.gr` files use contiguous layout (all row_ptr contiguous → all col_idx contiguous → all values contiguous), but `try_perblock()` in `gr2csr_bin.py` assumes per-block interleaved layout (block0 rp→col→val→block1 rp→col→val). This causes block 1-3 to read garbage data, making all per-block interpretations fail. Fix the reading to use contiguous offsets.

## Must-Haves
- MH1: Rewrite `try_perblock()` to read row_ptr, col_idx, and values from contiguous global positions (not interleaved per-block). Row_ptr starts at byte 32 (m values), col_idx at byte `32+8*m`, values at byte `32+8*m+4*nnz`.
- MH2: For each block, compute block-local 0-based row_ptr by subtracting the previous block's cumulative nnz. Col_idx for each block starts at the appropriate position in the global col_idx array.
- MH3: Keep all 6 candidate interpretations per block (1-based, 0-based, diag-anchor). Add block offset `b*rpb` to columns when converting block-local to global.
- MH4: The `try_global()` function (contiguous global layout) is already correct — keep it unchanged.
- MH5: `gr2csr.py` (text parser) is not duplicate — it handles DIMACS text format. `gr2csr_bin.py` handles binary format. Both are needed. No changes to `gr2csr.py`.
- MH6: Test conversion of `ABACUS_shell_ud.gr` succeeds (or validates correctly at least for one block interpretation). Run existing tests.

## Nice-to-Haves
- NH1: Better error diagnostics when all interpretations fail — include more block-level detail.

## Out of Scope
- Changing `gr2csr.py` text parser
- Changing `cmd.sh`
- Modifying the triangular validation logic (`validate`/`validate_upper`)
- Adding new file formats

## Constraints
- Must work with Python 3 (supercomputer)
- Must handle binary `.gr` files with contiguous layout
- Must not break existing files that already convert correctly

## Risks
- Risk 1: Even with correct contiguous reading, per-block triangular validation may still fail for some files (non-triangular matrices). Fallback: global CSR output without validation.
- Risk 2: Some binary files might have different layouts. The fix assumes contiguous layout based on evidence from the ABACUS file.
