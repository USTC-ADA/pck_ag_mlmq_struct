# Blueprint: Fix gr2csr_bin.py per-block layout bug

## Wave Architecture

| Wave | Theme | Goal |
|------|-------|------|
| 1 | Contiguous reading core fix | Rewrite `try_perblock()` to read from contiguous global offsets instead of interleaved per-block positions |
| 2 | Diagnostics & robustness | Add per-block error detail and validate consistency of sliced arrays |
| 3 | End-to-end verification | Test with ABACUS_shell_ud.gr and broader .gr test suite |

---

## Wave 1: Contiguous reading core fix

**Goal:** Replace the interleaved per-block reading loop in `try_perblock()` with a contiguous global-offset reading approach. Read all arrays once, then iterate blocks to slice and build global CSR structures.

### Tasks

#### T1.1 — Replace interleaved reading with contiguous global reads
**Executor:** `executor-high`

**Files to modify:** `utils/gr2csr_bin.py` — function `try_perblock()` (lines ~229–310)

**Description:**
Replace the sequential `pos`-based block reading loop preamble with three bulk reads:
1. `all_rp_raw = read_int64_array(raw, 32, m)` — all `m` row_ptr values
2. `all_col = read_int32_array(raw, 32 + 8*m, nnz)` — all `nnz` column indices
3. `all_vals = read_int32_array(raw, 32 + 8*m + 4*nnz, nnz)` — all `nnz` values

Initialize `global_row_ptr = [0]` and empty lists for the three column interpretations and values. Remove the advancing `pos` cursor and its per-block `pos +=` updates. Add a `prev_cum = 0` tracker for cumulative nnz across blocks.

**Depends on:** None

**Verification:**
- The three arrays are read with correct sizes: `len(all_rp_raw) == m`, `len(all_col) == nnz`, `len(all_vals) == nnz`.
- The function skeleton still initializes `global_row_ptr`, `global_col_1`, `global_col_0`, `global_col_anchor`, `values_global`, and `ok = True`.
- No `pos` variable remains in the function (except possibly for the intra-block diag-anchor loop which uses slice-local indexing).

---

#### T1.2 — Slice per-block data and build global CSR structures
**Executor:** `executor-high`

**Files to modify:** `utils/gr2csr_bin.py` — function `try_perblock()` (per-block loop body)

**Depends on:** T1.1 (needs the global arrays to exist)

**Description:**
Replace the per-block read-and-process loop body:
1. Slice this block's row_ptr: `block_rp_raw = all_rp_raw[b*rpb : (b+1)*rpb]`
2. Compute block-local row_ptr: `block_rp_local = [v - prev_cum for v in block_rp_raw]`
3. `block_nnz = block_rp_local[-1]`
4. Slice col_idx and values: `col_local = all_col[prev_cum : prev_cum + block_nnz]`, `val_local = all_vals[prev_cum : prev_cum + block_nnz]`
5. Build `rp0 = [0] + block_rp_local`
6. Append to `global_row_ptr`: `prev_cum + rp0[i+1]` for `i` in `range(rpb)`
7. Build per-block column interpretations with `base_row = b * rpb` offset (same logic as old code but using sliced `col_local`)
8. Update `prev_cum += block_nnz`

Preserve all existing sanity checks: `block_nnz` bounds, non-decreasing row_ptr, empty-row detection, column/node count mismatches.

**Verification:**
- For block 0, `prev_cum == 0` and `block_rp_local == block_rp_raw`, so behavior is identical to old code's block 0.
- For blocks 1+, `block_rp_local[0]` equals the nnz in the block's first row (not a cumulative value that bleeds from prior blocks).
- All 3 candidate interpretations (`perblock_col_1based`, `perblock_col_0based`, `perblock_col_diaganchor`) are appended.
- Running `python3 utils/gr2csr_bin.py ABACUS_shell_ud.gr` produces valid candidates (at least one interpretation built without `ok = False`).

---

## Wave 2: Diagnostics & robustness

**Goal:** Improve error output when all interpretations fail, and add consistency guards between the global reads and per-block slicing.

### Tasks

#### T2.1 — Add per-block diagnostic output on total failure
**Executor:** `executor-high`

**Files to modify:** `utils/gr2csr_bin.py` — `main()` error path (lines ~386–394)

**Depends on:** Wave 1 complete (T1.2)

**Description:**
When all candidate interpretations fail validation, enhance the error block to print per-block diagnostics:
- Block index, `block_nnz`, and `rpb` for each block
- First 3 and last 3 row_ptr values (raw and block-local) per block
- First 3 column values (raw) per block
- Whether the block's data passed the sanity checks (`ok` flag)

This helps diagnose whether the contiguous reading produced sensible per-block data or whether the file has an unexpected layout.

**Verification:**
- When all interpretations fail, stderr output includes per-block lines like:
  ```
  Block 0: rpb=X, nnz=Y, rp_raw[:3]=..., rp_local[:3]=..., col[:3]=...
  Block 1: rpb=X, nnz=Y, ...
  ```
- When at least one interpretation succeeds, no per-block diagnostics are printed (no noise on success path).

---

#### T2.2 — Add consistency guard between global reads and per-block slicing
**Executor:** `executor-high`

**Files to modify:** `utils/gr2csr_bin.py` — function `try_perblock()` (after per-block loop)

**Depends on:** T1.2

**Description:**
After the per-block loop completes, verify consistency:
- Total nnz accumulated across blocks matches `nnz` from the file header.
- `len(global_col_1) == nnz` and `len(values_global) == nnz`.
- `global_row_ptr[m] == nnz`.
If any check fails, set `ok = False` and return `[]` early, preventing malformed candidates from being validated.

**Verification:**
- A file with an inconsistent number of blocks vs. total nnz returns `[]` from `try_perblock()` without crashing.
- For a valid file (like ABACUS_shell_ud.gr), all consistency checks pass silently.

---

## Wave 3: End-to-end verification

**Goal:** Validate the fix works on the target file and does not regress existing functionality.

### Tasks

#### T3.1 — Test conversion of ABACUS_shell_ud.gr
**Executor:** `executor-low`

**Files to modify:** None (test execution only)

**Depends on:** Wave 2 complete (T2.2)

**Description:**
Run the conversion on the local test file:
```
python3 utils/gr2csr_bin.py /home/hdz/testpath/rocm/data/mlmq/data/ABACUS_shell_ud.gr /tmp/test_output.csr
```
Verify:
- Exit code is 0 (not `sys.exit(1)`).
- A `Selected layout:` line appears on stderr.
- Output file `/tmp/test_output.csr` exists and is non-empty.
- Output file format: first line has two integers (`m nnz`), second line has `m` integers, third line has `nnz` integers, fourth line has `nnz` numbers.

**Verification:**
- Script exits 0 with a selected layout message.
- Output `.csr` file passes format inspection (4 lines, correct field counts).

---

#### T3.2 — Regression test on broader .gr file suite
**Executor:** `executor-low`

**Files to modify:** None (test execution only)

**Depends on:** T3.1

**Description:**
Run the converter on all `.gr` files in the test data directory:
```
for f in /home/hdz/testpath/rocm/data/mlmq/data/*.gr; do
    echo "=== $f ==="
    python3 utils/gr2csr_bin.py "$f" /tmp/$(basename "$f" .gr).csr 2>&1
done
```
Verify:
- No file causes the script to crash (unhandled exception).
- Files that previously converted successfully (via `try_global()`) still do.
- For each failure, the diagnostic output from T2.1 provides actionable information.

**Verification:**
- All `.gr` files either produce a `.csr` output or print a clean diagnostic message (no Python traceback).
- The ABACUS file specifically produces a `.csr` output with a per-block interpretation selected.
