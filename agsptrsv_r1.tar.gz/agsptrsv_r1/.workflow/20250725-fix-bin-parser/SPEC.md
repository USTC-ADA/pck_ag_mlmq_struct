# Specification: Fix gr2csr_bin.py per-block layout bug

## Vision
Binary `.gr` files use a **contiguous global layout** (all row_ptr contiguous → all col_idx contiguous → all values contiguous), but `try_perblock()` in `gr2csr_bin.py` assumes a **per-block interleaved layout** (block0 rp→col→val→block1 rp→col→val…). This mismatch causes blocks 2–N to read garbage data from the wrong file offsets, making every per-block candidate interpretation fail validation. The fix rewrites `try_perblock()` to read row_ptr, col_idx, and values from globally contiguous offsets, then slice per-block data and adjust row_ptr/columns accordingly. The already-correct `try_global()` must remain untouched.

## Must-Haves

### MH1: Read row_ptr, col_idx, and values from contiguous global offsets
**Description:** Rewrite `try_perblock()` to read all arrays from fixed global positions instead of an advancing per-block cursor:
- All `m` int64 row_ptr entries from byte 32
- All `nnz` int32 col_idx entries from byte `32 + 8*m`
- All `nnz` int32 values entries from byte `32 + 8*m + 4*nnz`

**Acceptance:**
- The function reads exactly 3 arrays using `read_int64_array(raw, 32, m)` and `read_int32_array` calls.
- No sequential `pos` cursor that advances through interleaved blocks.
- The total bytes read from the file are consistent with `m` int64 + `nnz` int32 * 2.

---

### MH2: Compute block-local 0-based row_ptr by subtracting previous cumulative nnz
**Description:** The stored `m` int64 row_ptr values in the contiguous format are **global-cumulative** (they do not restart at each block boundary). For each block:
- Slice `rpb` values from the global row_ptr array: `row_ptr_slice = all_rp[b*rpb : (b+1)*rpb]`
- Subtract `prev_cum_nnz` (total nnz of all previous blocks) from every value to obtain the block-local 1-based cumulative row_ptr.
- Build the block-local 0-based row_ptr as `rp0 = [0] + [v - prev_cum_nnz for v in row_ptr_slice]`.
- `block_nnz = rp0[-1]` must be non-negative and consistent.
- Append to `global_row_ptr`: `prev_cum_nnz + rp0[i+1]` for each row.

**Acceptance:**
- `global_row_ptr` matches what the old code would have produced for the same data (just from a different storage layout).
- `global_row_ptr` is strictly non-decreasing, length `m+1`, with `global_row_ptr[m] == nnz`.
- Sanity check: `sum(block_nnz for all blocks) == nnz`.

---

### MH3: Preserve all 6 candidate interpretations with correct column offsets
**Description:** Keep the three per-block column interpretations (1-based local, 0-based local, diag-anchor), building them identically to the old code, but sourcing col_idx and values from slices of the globally-read contiguous arrays:
- `col_local = all_col[prev_cum_nnz : prev_cum_nnz + block_nnz]`
- `val_local = all_vals[prev_cum_nnz : prev_cum_nnz + block_nnz]`
- Add block base row offset `b * rpb` when converting block-local columns to global indices.
- Diag-anchor logic reuses the sliced `col_local` with the same offset arithmetic — no semantic change.

**Acceptance:**
- Function returns exactly 3 candidate tuples: `perblock_col_1based`, `perblock_col_0based`, `perblock_col_diaganchor`.
- Column values are within `[0, m)` for valid interpretations.
- For a valid lower-triangular block-diagonal file, at least one interpretation passes `validate()`.

---

### MH4: Keep `try_global()` completely unchanged
**Description:** `try_global()` (lines 201–226) already reads from the correct contiguous global offsets and produces correct candidate interpretations. No modifications to this function.

**Acceptance:**
- `try_global()` text is byte-identical to the current version.
- `try_global()` continues to produce `global_col_1based`, `global_col_0based`, `global_col_diaganchor` candidates.
- `try_global()` is called before `try_perblock()` in `main()`, same as now.

---

### MH5: Keep `gr2csr.py` (text parser) unchanged
**Description:** `gr2csr.py` handles the DIMACS text format — it is not a duplicate of `gr2csr_bin.py`. Both parsers are independently necessary. No changes to `gr2csr.py`.

**Acceptance:**
- `gr2csr.py` is not modified in any way.
- `git diff` shows zero changes to `gr2csr.py`.

---

### MH6: Test conversion of ABACUS_shell_ud.gr succeeds
**Description:** Run `python3 utils/gr2csr_bin.py /home/hdz/testpath/rocm/data/mlmq/data/ABACUS_shell_ud.gr` and verify at least one interpretation passes validation, producing a valid `.csr` output file.

**Acceptance:**
- The script exits with code 0.
- A `Selected layout:` message appears on stderr (not `[ERROR] No candidate layout`).
- Output `.csr` file is created with non-zero size.
- Output file has the correct format: line 1 = `m nnz`, line 2 = `m` row_ptr values, line 3 = `nnz` col_idx values, line 4 = `nnz` values.

## Nice-to-Haves
- **NH1:** Better error diagnostics when all interpretations fail — include per-block detail (block index, block nnz, first/last row_ptr values, first/last column values).

## Out of Scope
- Changing `gr2csr.py` text parser (separate format handler).
- Changing `cmd.sh` build/test script.
- Modifying the triangular validation logic (`validate()` / `validate_upper()`).
- Adding support for new file formats or layouts beyond the contiguous layout.
- Modifying `utils/utils.cpp` or the C++ `read_tri()` function.

## Technical Constraints
- Python 3, standard library only (`sys`, `os`, `struct`) — must run on supercomputer.
- Handles binary `.gr` files with **contiguous global layout** (the actual format used by ABACUS and similar producers).
- Must not regress existing files that already convert correctly via `try_global()`.
- Little-endian byte order (unchanged from current code).

## Assumptions
- All `.gr` files use the same contiguous layout as ABACUS_shell_ud.gr.
- `num_blocks * rpb == m` (even block division) — already enforced by the existing check `rpb * num_blocks != m: return []`.
- Stored row_ptr values are **global-cumulative** (1-based, accumulating nnz across blocks), not per-block-cumulative.
- Column indices in the file are block-local (i.e., relative to the block's row range).

## Risks & Mitigations

| Risk | Mitigation |
|------|-----------|
| Even with correct contiguous reading, per-block triangular validation may still fail for some files (non-triangular matrices). | Fallback: `try_global()` runs first and may succeed. If both fail, the existing error path with diagnostics fires. |
| Some binary files might use a different layout (e.g., truly interleaved). | The fix changes the data reading loop; if the file happens to be interleaved, the existing `try_global()` still runs first. If neither path works, the user sees diagnostic output to investigate. |
| Diag-anchor logic relies on the last column in each row being the diagonal — this assumption may not hold for all matrices. | This is an existing assumption unchanged by this fix. The 1-based and 0-based interpretations provide alternatives when diag-anchor fails. |
