# CHRONICLE — Execution Log

## Summary
Fixed `gr2csr_bin.py` to handle contiguous-layout binary .gr files and added lower-triangular filter fallback.

## Wave 1: Fix try_perblock contiguous reading + Filter fallback (Completed)

### T1.1+T1.2 — Contiguous reading + per-block slicing
- Rewrote `try_perblock()` (lines 229-345) to read from contiguous global offsets
- 3 bulk reads: all row_ptr from byte 32, all col_idx from byte 32+8m, all values from byte 32+8m+4nnz
- Per-block: slice row_ptr, subtract prev_cum for block-local, build 6 interpretations
- `try_global()` unchanged
- Now produces 6 candidates (3 global + 3 per-block) instead of just 3

### Filter fallback (added)
- New `filter_lower_triangular()` function (lines 352-372)
- Filters CSR to keep only col <= row entries, ensures diagonal exists
- In `main()`: when all 12 interpretations fail, fallback to filtering global_col_0based
- Output uses `len(col)` for nnz to match filtered data

## Test Results

| File | m | orig nnz | filtered nnz | Status |
|------|---|----------|-------------|--------|
| Trefethen_20.gr | 20 | 158 | 89 | OK |
| Hamrle1.gr | 32 | 98 | 63 | OK |
| Maragal_1.gr | 32 | 234 | 233 | OK |
| GD96_d.gr | 180 | 229 | 262* | OK |
| GD97_a.gr | 84 | 332 | 250 | OK |

*GD96_d filter nnz > orig nnz: diagonal entries added for rows missing them

## Files changed
- `/home/hdz/testpath/rocm/agsptrsv_r1/utils/gr2csr_bin.py` only
- `gr2csr.py` unchanged
- `cmd.sh` unchanged
