# Specification: Simplify cmd.sh and Fix Fail-Fast Bugs

## Vision
Cmd.sh currently has 10 subcommands with redundant wrappers and a fail-fast bug in `convertbatch`. Reduce to 6 core commands by deleting `batch`, `batchall`, `batchall-strict`, and `clean` entirely, fix `convertbatch` so a conversion failure immediately terminates the script, and update all documentation. Users can then chain `convertbatch && testbatch-strict` for a reliable one-shot full pipeline.

## Must-Haves

### MH1: Delete 4 obsolete commands entirely
Delete `run_batch()` (batch), `batchAll()` (batchall), `batchAllStrict()` (batchall-strict), and `clean()` (clean) — their function bodies, case entries in the main switch, header comment lines, and help lines in `show_help()`.
| Acceptance: `grep -cE 'run_batch\(\)|batchAll\(\)|batchAllStrict\(\)|^clean\(\)' cmd.sh` returns 0 and `grep -cE '"\b(batch|batchall|batchall-strict|clean)\b"' cmd.sh` in the case statement and help function returns 0 — no orphaned references remain.

### MH2: Fix convertBatch fail-fast
In `convertBatch()`, remove the `if convert "${gr}" "${csr}" "batchnonfatal"; then ... OK ... else ... FAIL` wrapper around the `convert` call. Replace with a direct call: `convert "${gr}" "${csr}"`. Because `set -e` is active and `convert` now always calls `exit 1` on failure, any conversion failure terminates the script immediately. Remove the `fail` counter and adjust the summary to reflect only successes.
| Acceptance: `grep 'batchnonfatal' cmd.sh` returns 0; `grep 'if convert' cmd.sh` returns 0 in convertBatch context; `convertBatch` invokes `convert` directly without `if` guard.

### MH3: Verify testBatchDirStrict fail-fast logic is correct
The `set +e` / `PIPESTATUS[0]` / `set -e` pattern in `testBatchDirStrict()` must correctly capture `./test/main` exit codes through the pipe chain. Confirm no `|| true`, `continue`, or other constructs silently swallow test failures.
| Acceptance: `set +e` appears before the test invocation, `PIPESTATUS[0]` captures the exit code, `set -e` re-enables afterwards, `exit 1` is called on non-zero exit code, and no `|| true` or `continue` is present in the test loop.

### MH4: Update header and show_help for 6 commands
Update the header comment block (lines 1-16) to list exactly 6 commands: `build`, `test`, `convert`, `convertbatch`, `testbatch`, `testbatch-strict`. Update `show_help()` to list the same 6 commands with accurate descriptions, and include a `convertbatch && testbatch-strict` chaining example.
| Acceptance: Header block enumerates 6 and only 6 commands; `show_help` output matches; a `convertbatch && testbatch-strict` example appears in the Examples section of `show_help`.

### MH5: bash syntax check passes
| Acceptance: `bash -n cmd.sh` exits with code 0 and produces no error output.

## Nice-to-Haves
- NH1: Help output includes `convertbatch && testbatch-strict` chaining example (covered by MH4).

## Out of Scope
- Modifying `./test/main` or any C++/HIP source code
- Adding new commands
- Modifying the `test` subcommand's auto-convert behavior
- Changing the `testBatchDir` (non-strict) function
- Modifying `build()` or `test_one()` functions
- Any changes outside `cmd.sh`

## Technical Constraints
- Target file: `/home/hdz/testpath/rocm/agsptrsv_r1/cmd.sh` (612 lines before changes)
- Bash 4.x+ syntax (no associative arrays or other Bash 5+ features)
- `set -e` must remain active at the top of the script
- All subsequent commands must respect fail-fast semantics

## Assumptions
- `set -e` is correctly configured at line 18 and no later `set +e` persists globally
- `convert()` function is not called from any other script or context beyond what's visible in cmd.sh
- The 4 deleted commands are not depended on by any external automation (they're superseded by `convertbatch && testbatch-strict`)
- The `batchnonfatal` parameter in `convert()` has no other callers

## Risks & Mitigations
- **Risk:** Line number shifts during deletion cause later edits to target wrong lines.
  - **Mitigation:** Execute deletions first (Wave 1) before any modifications (Wave 2); editors must search by content (grep for function names) not absolute line numbers.
- **Risk:** Removing `if` wrapper in convertBatch exposes `convert`'s `exit 1` to the main script, but another `set +e` somewhere upstream could suppress it.
  - **Mitigation:** Verify no global `set +e` exists; bash -n and a manual review of the complete file confirm.
- **Risk:** `batchnonfatal` removal from `convert()` might miss some edge case where the parameter is still useful.
  - **Mitigation:** Requirements explicitly call for its removal; no other callers exist.
