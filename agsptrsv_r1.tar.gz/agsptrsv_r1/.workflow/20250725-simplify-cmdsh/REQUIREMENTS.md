# Requirements: Simplify cmd.sh and fix fail-fast bugs

## Vision
Cmd.sh 当前有 10 个子命令，冗余且 fail-fast 逻辑有 bug。精简为 6 个核心命令，修复 `convertbatch` 的 fail-fast 使转换失败也能立即停止。用户可用 `convertbatch && testbatch-strict` 串联实现一键全流程。

## Must-Haves
- MH1: 保留 6 命令：`build`、`test`、`convert`、`convertbatch`、`testbatch`、`testbatch-strict`。删除 `batch`、`batchall`、`batchall-strict`、`clean` 的全部代码（函数、case 分支、header 注释、help 行）。
- MH2: 修复 `convertbatch` fail-fast：移除 `batchnonfatal` 参数和 `if...then OK else FAIL` 包装，让 `convert` 直接调用（`exit 1` 穿透 `if` 条件上下文终止脚本）。
- MH3: 再次验证 `testbatch-strict` 的 `set +e`/`PIPESTATUS[0]`/`set -e` 逻辑正确，无 `|| true` 或 `continue` 吞掉失败。
- MH4: 更新 header 注释块和 `show_help()`，只列出 6 个保留命令，并给出 `convertbatch && testbatch-strict` 使用示例。
- MH5: `bash -n cmd.sh` 通过语法检查。

## Nice-to-Haves
- NH1: 帮助信息中给出 `convertbatch && testbatch-strict` 串联使用示例

## Out of Scope
- 修改 `./test/main` 或 C++/HIP 源码
- 新增命令
- 修改 `test` 子命令的 auto-convert 行为

## 要删除的代码范围

| 删除项 | 描述 |
|--------|------|
| `run_batch()` | batch 函数 |
| `batchAll()` | batchall 函数 |
| `batchAllStrict()` | batchall-strict 函数 |
| `clean()` | clean 函数 |
| header 的 batch/batchall/batchall-strict/clean 行 | 注释 |
| help 的对应行 | show_help |
| case 的对应分支 | 主 case |

## 要修改的代码范围

| 修改项 | 变更 |
|--------|------|
| `convertBatch()` 的 for 循环 | 移除 `if...batchnonfatal` 包装，直接调用 `convert` |