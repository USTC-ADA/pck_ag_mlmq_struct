# Blueprint: Simplify cmd.sh and Fix Fail-Fast Bugs

## Wave Architecture
- **Wave 1: Deletion** — Remove all obsolete function bodies, case entries, header lines, and help lines for the 4 cut commands. Foundation for all subsequent work.
- **Wave 2: Fix fail-fast** — Fix `convertBatch()` to call `convert` directly, and clean up the `batchnonfatal` parameter from `convert()`.
- **Wave 3: Documentation & verify** — Update header and `show_help()` for the 6 remaining commands, verify `testBatchDirStrict` logic, and run syntax check.

---

## Wave 1: Delete Obsolete Commands
**Goal:** Remove `run_batch`, `batchAll`, `batchAllStrict`, `clean` — functions, case entries, header comments, and help lines — leaving no orphaned references.

### Tasks

#### T1.1: Delete `run_batch()` function body
| Executor: executor-low | Files: `cmd.sh` | Depends: none |

Delete the entire `run_batch()` function (approximately lines 191-218 in original) including the leading comment block and closing `}`. This removes the `batch` subcommand's logic.

**Verification:** `grep -c 'run_batch()' cmd.sh` returns 0.

#### T1.2: Delete `batchAll()`, `batchAllStrict()`, `clean()` function bodies
| Executor: executor-low | Files: `cmd.sh` | Depends: none (parallel with T1.1, T1.3) |

Delete the three function bodies:
- `batchAll()` (~lines 464-486)
- `batchAllStrict()` (~lines 492-515)
- `clean()` (~lines 518-529)

Include the leading comment blocks for each.

**Verification:** `grep -cE 'batchAll\(\)|batchAllStrict\(\)|^clean\(\)' cmd.sh` returns 0.

#### T1.3: Delete case entries, header lines, and help lines for deleted commands
| Executor: executor-low | Files: `cmd.sh` | Depends: none (parallel with T1.1, T1.2) |

Delete from the `case` statement (main switch):
- `batch)` + `run_batch ...` entry
- `batchall)` + `batchAll ...` entry
- `batchall-strict)` + `batchAllStrict ...` entry
- `clean)` + `clean` entry

Delete from the header comment block (lines ~11, ~13, ~15):
- `#   bash cmd.sh batch RES [LIST]   -- batch test with matrix list`
- `#   bash cmd.sh batchall-strict DIR OUTDIR [CSV] -- convert + test all (fail-fast)`
- `#   bash cmd.sh clean              -- clean build artifacts`

Delete from `show_help()`:
- `echo "  bash cmd.sh batch RESULT [LIST]          Batch test from matrix list"`
- `echo "  bash cmd.sh batchall DIR OUTDIR [CSV]    convertbatch + testbatch in one step"`
- `echo "  bash cmd.sh batchall-strict DIR OUTDIR [CSV]  convertbatch + testbatch (stop on first failure)"`
- `echo "  bash cmd.sh clean                        Remove build artifacts"`
- Also remove the `batchall ./gr_files ./csr_output results.csv` example line.

**Verification:** No references to "batch", "batchall", "batchall-strict", or "clean" remain in the case statement, header, or show_help function. `grep -c '"batch"\|"batchall"\|"batchall-strict"\|"clean"' cmd.sh` returns 0.

---

## Wave 2: Fix convertBatch Fail-Fast
**Goal:** Change `convertBatch()` so it calls `convert` directly (without `batchnonfatal` or `if` wrapper), and remove the `batchnonfatal` code path from `convert()`.

### Tasks

#### T2.1: Simplify convertBatch() for-loop to call convert directly
| Executor: executor-low | Files: `cmd.sh` | Depends: Wave 1 complete |

In `convertBatch()`, replace the `for` loop body:

**Before:**
```bash
    local n=0 ok=0 fail=0
    for gr in "${files[@]}"; do
        n=$((n + 1))
        local base=$(basename "${gr}" .gr)
        local csr="${output_dir}/${base}.csr"

        printf "[%d/%d] %s -> %s ... " "${n}" "${total}" "$(basename "${gr}")" "${base}.csr" | tee -a build.log
        if convert "${gr}" "${csr}" "batchnonfatal"; then
            echo "OK" | tee -a build.log
            ok=$((ok + 1))
        else
            echo "FAIL" | tee -a build.log
            fail=$((fail + 1))
        fi
    done

    echo "----------------------------------------" | tee -a build.log
    echo "Batch convert done: ${ok} succeeded, ${fail} failed (out of ${total})." | tee -a build.log
```

**After:**
```bash
    local n=0 ok=0
    for gr in "${files[@]}"; do
        n=$((n + 1))
        local base=$(basename "${gr}" .gr)
        local csr="${output_dir}/${base}.csr"

        printf "[%d/%d] %s -> %s ... " "${n}" "${total}" "$(basename "${gr}")" "${base}.csr" | tee -a build.log
        convert "${gr}" "${csr}"
        echo "OK" | tee -a build.log
        ok=$((ok + 1))
    done

    echo "----------------------------------------" | tee -a build.log
    echo "Batch convert done: ${ok} succeeded (out of ${total})." | tee -a build.log
```

Key changes: remove `fail` counter, remove `if convert ... "batchnonfatal"; then ... else ... fi` wrapper, call `convert` directly (its `exit 1` will terminate the script on failure).

**Verification:** `grep 'if convert' cmd.sh` returns 0; `grep 'batchnonfatal' cmd.sh` returns 0; `convert` is called directly in the loop body.

#### T2.2: Remove batchnonfatal parameter from convert() function
| Executor: executor-low | Files: `cmd.sh` | Depends: T2.1 complete |

In `convert()`:
1. Delete `local batchnonfatal="$3"` (line 224 in original).
2. Replace the conditional at the end (lines 264-268 in original):

**Before:**
```bash
    echo "[ERROR] Both parsers failed to convert: ${input}"
    if [ -n "${batchnonfatal}" ]; then
        return 1
    else
        exit 1
    fi
```

**After:**
```bash
    echo "[ERROR] Both parsers failed to convert: ${input}"
    exit 1
```

**Verification:** `grep 'batchnonfatal' cmd.sh` returns 0; `grep 'return 1' cmd.sh` in convert context returns 0; `exit 1` is the only path after the error message.

---

## Wave 3: Documentation & Verification
**Goal:** Update header comments and `show_help()` to accurately reflect the 6 remaining commands, verify `testBatchDirStrict` code, and pass syntax check.

### Tasks

#### T3.1: Update header comment block for 6 commands
| Executor: executor-low | Files: `cmd.sh` | Depends: Wave 1 complete (parallel with T3.2) |

Update lines 6-16 of the header to list exactly 6 commands:

```
# Usage:
#   bash cmd.sh build                           -- build the project
#   bash cmd.sh test MATRIX                     -- run with a matrix file
#                                                  (.gr files are auto-converted to .csr)
#   bash cmd.sh convert INPUT.gr [OUTPUT.csr]   -- convert .gr file to .csr format
#   bash cmd.sh convertbatch DIR OUTDIR         -- batch convert all .gr to .csr
#   bash cmd.sh testbatch DIR [CSV]             -- batch test all .csr (non-stop)
#   bash cmd.sh testbatch-strict DIR [CSV]      -- batch test all .csr (fail-fast)
#
# Chain for one-shot pipeline:
#   bash cmd.sh convertbatch DIR OUTDIR && bash cmd.sh testbatch-strict OUTDIR [CSV]
```

**Verification:** Header lists exactly 6 commands; `convertbatch && testbatch-strict` chaining example is present.

#### T3.2: Update show_help() for 6 commands with chaining example
| Executor: executor-low | Files: `cmd.sh` | Depends: Wave 1 complete (parallel with T3.1) |

Update the "Commands:" section of `show_help()` to list only 6 commands:

```
Commands:
  bash cmd.sh build                        Full build (library + tests)
  bash cmd.sh test MATRIX_FILE             Run single matrix test
                                           .gr files auto-converted to .csr
  bash cmd.sh convert INPUT.gr [OUTPUT.csr]  Convert .gr to .csr format
  bash cmd.sh convertbatch DIR OUTDIR      Batch convert all .gr in DIR to OUTDIR
  bash cmd.sh testbatch DIR [CSV]          Batch test all .csr in DIR -> CSV (non-stop)
  bash cmd.sh testbatch-strict DIR [CSV]   Batch test all .csr in DIR -> CSV (fail-fast)
```

Update the "Examples:" section to include the chaining example:

```
Examples:
  bash cmd.sh test /path/to/matrix.csr
  bash cmd.sh test /path/to/graph.gr
  bash cmd.sh convert graph.gr graph.csr
  bash cmd.sh convertbatch ./gr_files ./csr_output
  bash cmd.sh testbatch ./csr_output results.csv
  bash cmd.sh testbatch-strict ./csr_output results.csv
  bash cmd.sh convertbatch ./gr_files ./csr_output && bash cmd.sh testbatch-strict ./csr_output results.csv
```

Remove the old `batchall ...` example line.

**Verification:** `show_help` output lists 6 and only 6 commands; chaining example is present; no references to batch/batchall/batchall-strict/clean.

#### T3.3: Verify testBatchDirStrict() and run syntax check
| Executor: executor-low | Files: `cmd.sh` | Depends: Wave 1 and Wave 2 complete |

1. Verify `testBatchDirStrict()` code:
   - `set +e` appears before `./test/main` invocation
   - `local test_exit_code=${PIPESTATUS[0]}` captures exit code from first pipeline command
   - `set -e` re-enables afterwards
   - `exit 1` is called on non-zero `test_exit_code`
   - No `|| true` or `continue` in the test loop

2. Run syntax check: `bash -n cmd.sh`

**Verification:** Manual review confirms fail-fast pattern is correct; `bash -n cmd.sh` exits 0 with no errors.
