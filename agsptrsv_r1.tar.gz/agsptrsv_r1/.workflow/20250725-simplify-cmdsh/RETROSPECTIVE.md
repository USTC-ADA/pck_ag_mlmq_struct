# RETROSPECTIVE — Simplify cmd.sh and Fix Fail-Fast Bugs

## What Went Well
- Bug diagnosis was straightforward — tracing the `batchnonfatal` → `return 1` path through `convertBatch`'s `if` wrapper revealed exactly why conversion failures didn't stop the pipeline.
- Deleting 4 obsolete commands and re-documenting to 6 was clean and mechanical — no ripple effects on other code.
- The `exit 1` (not `return 1`) semantics were correctly leveraged: `exit` bypasses all `set -e` suppression from `if`/`while` conditional contexts, so removing `batchnonfatal` was sufficient for fail-fast behavior.
- Wave 1 tasks ran in parallel successfully (3 independent deletions) — saved time.

## What Went Wrong
- The original SPEC for the previous workflow (20250725-cmd-test-workflow) assumed `convertBatch` would fail fatally — it doesn't. The requirements doc even noted this risk ("Risk 1") but the implementation didn't address it. Lesson: always verify assumptions about existing function behavior.
- No git repository available, so atomic commits and PR scripts were skipped. Not a blocker given the WSL-only editing constraint.

## What Was Learned
- Bash `if` conditionals suppress `set -e` for the condition command, but `exit` inside the conditional still terminates the script. So `return 1` inside `if convert ... batchnonfatal` was the real problem, not the `if` itself.
- When simplifying a CLI tool, a good rule of thumb: each removed command should leave zero grep hits across the entire file (functions, case, header, help, examples).

## Changes from SPEC
- None. All 5 Must-Haves implemented exactly as specified.
