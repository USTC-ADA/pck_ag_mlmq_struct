# Chronicle: {{workflowId}}

## Status
**Phase**: {{phase}}
**Wave**: {{currentWave}}
**Progress**: {{progressPercent}}%

## Recent Activity
{{#recentActivity}}
- {{timestamp}}: {{description}}
{{/recentActivity}}

## Current Tasks
{{#currentTasks}}
- [{{status}}] {{description}} ({{agent}})
{{/currentTasks}}

## Blockers
{{#blockers}}
- {{description}}
{{/blockers}}

## Decisions
{{#decisions}}
- {{timestamp}}: {{decision}} — {{rationale}}
{{/decisions}}

## Next Steps
{{#nextSteps}}
1. {{step}}
{{/nextSteps}}
