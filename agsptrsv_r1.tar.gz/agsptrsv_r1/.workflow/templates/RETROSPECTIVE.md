# Retrospective: {{workflowName}}

## Summary
{{summary}}

## Metrics
| Metric | Planned | Actual |
|--------|---------|--------|
| Waves | {{plannedWaves}} | {{actualWaves}} |
| Tasks | {{plannedTasks}} | {{actualTasks}} |
| Duration | {{plannedDuration}} | {{actualDuration}} |

## What Worked Well
{{#workedWell}}
- {{item}}
{{/workedWell}}

## What Could Be Improved
{{#improvements}}
- {{item}}
{{/improvements}}

## Key Decisions
{{#decisions}}
- {{decision}} — {{rationale}}
{{/decisions}}

## Technical Debt Incurred
{{#debt}}
- {{item}}
{{/debt}}

## Patterns Established
{{#patterns}}
- {{item}}
{{/patterns}}

## Learnings Extracted
{{learnings}}
