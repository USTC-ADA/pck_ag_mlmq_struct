# Specification: {{projectName}}

## Vision
{{vision}}

## Must-Haves
{{#mustHaves}}
- **MH{{index}}**: {{description}} | Acceptance: {{acceptanceCriteria}}
{{/mustHaves}}

## Nice-to-Haves
{{#niceToHaves}}
- {{item}}
{{/niceToHaves}}

## Out of Scope
{{#outOfScope}}
- {{item}}
{{/outOfScope}}

## Technical Constraints
{{#constraints}}
- {{item}}
{{/constraints}}

## Assumptions
{{#assumptions}}
- {{item}}
{{/assumptions}}

## Risks & Mitigations
{{#risks}}
- **Risk**: {{risk}} | **Mitigation**: {{mitigation}}
{{/risks}}

## Amendment History
| Date | Change | Reason |
|------|--------|--------|
