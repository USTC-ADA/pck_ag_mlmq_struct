# Blueprint: {{projectName}}

## Overview
{{goal}}

## Spec Mapping
| Must-Have | Wave | Tasks |
|-----------|------|-------|
{{#specMapping}}
| MH{{mh}} | Wave {{wave}} | {{tasks}} |
{{/specMapping}}

## Wave Architecture
{{waveArchitecture}}

{{#waves}}
### Wave {{index}}: {{name}}
**Goal**: {{goal}}

| Task | Executor | Files | Depends | Verification |
|------|----------|-------|---------|--------------|
{{#tasks}}
| {{id}}: {{description}} | {{executor}} | {{files}} | {{depends}} | {{verification}} |
{{/tasks}}

{{/waves}}

## Verification Checklist
{{#verificationItems}}
- [ ] {{item}}
{{/verificationItems}}

## Risk Assessment
{{#risks}}
- {{item}}
{{/risks}}
