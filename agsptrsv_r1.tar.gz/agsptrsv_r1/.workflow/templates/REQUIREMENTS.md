# Requirements: {{featureName}}

## Vision
{{vision}}

## Must-Haves
{{#mustHaves}}
- {{item}}
{{/mustHaves}}

## Nice-to-Haves
{{#niceToHaves}}
- {{item}}
{{/niceToHaves}}

## Out of Scope
{{#outOfScope}}
- {{item}}
{{/outOfScope}}

## Constraints
{{#constraints}}
- {{item}}
{{/constraints}}

## Assumptions
{{#assumptions}}
- {{item}}
{{/assumptions}}

## Risks
{{#risks}}
- {{item}}
{{/risks}}

## Interview Checklist
- [ ] Vision clarified
- [ ] Must-haves identified and prioritized
- [ ] Constraints documented
- [ ] Out-of-scope items explicitly excluded
- [ ] Assumptions validated
- [ ] Risks assessed
