# Specification: cmd.sh fail-fast batch test commands

## Vision
Add two new commands to `cmd.sh` that execute batch tests with fail-fast semantics — stopping immediately on the first matrix test failure, printing clear diagnostic information to stderr, and exiting with a non-zero code. Existing commands must be untouched.

## Must-Haves

**MH1: `batchall-strict` command**
Adds `batchall-strict <gr_dir> <csr_dir> [csv_file]` — converts all `.gr` files in `gr_dir` to `.csr` in `csr_dir` (via existing `convertBatch`), then tests all resulting `.csr` files sequentially with fail-fast behavior.
| Acceptance: Running `bash cmd.sh batchall-strict gr_dir csr_dir` on a directory with 5 `.gr` files where the 3rd matrix test fails causes the script to: print the failed matrix name and error details to stderr, exit with non-zero code, and NOT process the 4th and 5th matrices.

**MH2: `testbatch-strict` command**
Adds `testbatch-strict <csr_dir> [csv_file]` — tests all `.csr` files in `csr_dir` sequentially, failing fast on the first test failure (skip conversion phase entirely).
| Acceptance: Running `bash cmd.sh testbatch-strict csr_dir` with 10 `.csr` files where the 2nd fails exits immediately after the 2nd matrix without touching the remaining 8. If all pass, exits 0.

**MH3: True fail-fast (hard stop)**
Failure of any individual `./test/main` invocation (non-zero exit) causes `cmd.sh` itself to exit immediately with a non-zero code. No subsequent matrices are processed.
| Acceptance: The `for` loop in the strict functions does NOT use `|| true`, `if ... else; continue`, or any construct that absorbs the failure. An explicit `exit 1` (or equivalent) fires on first failure.

**MH4: Clear error diagnostics**
On failure, stderr receives a block with: (a) the matrix file name (basename + full path), (b) the numeric exit code from `./test/main`, and (c) the full stdout+stderr output captured from the failing `./test/main` invocation.
| Acceptance: Running a strict command that fails produces on stderr a message block visibly containing the matrix name, an integer exit code, and the raw test output — distinguishable from normal `build.log` output.

**MH5: Existing commands preserved**
The commands `build`, `test`, `batch`, `convert`, `convertbatch`, `testbatch`, `batchall`, and `clean` retain their exact original behavior, output, and exit semantics.
| Acceptance: `diff` against the original `cmd.sh` shows additions only (new functions, new case entries, updated help text). No existing function body, variable, or control-flow is altered.

## Nice-to-Haves

- NH1: `batchall-strict` skips `.csr` files that already exist and are newer than the source `.gr` (timestamp check) to avoid redundant conversion.
- NH2: Progress counter prefix like `[3/50] Testing: matrix.csr` so the user knows position before failure.
- NH3: On early exit, a summary line on stderr: `Stopped: X passed, 1 failed (matrix_name.csr).`

## Out of Scope

- Modifying `./test/main` or any C++/HIP source — only `cmd.sh` changes.
- Automatic retry or recovery after failure.
- Parallel / multi-GPU testing.
- Changing the build system, Makefile, or compilation flags.
- CI/CD integration or cron jobs.
- Adding new command-line flags/options beyond the two commands.

## Technical Constraints

- Runs on supercomputer: bash 4.x+, `module load compiler/rocm/4.0.1`, AMD GPU target `gfx906`.
- `set -e` at top of `cmd.sh` — strict functions must use `set +e`/`set -e` or explicit exit-code capture to avoid early script exit masking the intentional error handling.
- `ensure_csr()` contract: stdout = `.csr` path, diagnostics to stderr — must not break.
- All normal output still appends to `build.log` via `| log | tee -a build.log`.

## Assumptions

- The `.gr` conversion step (via `convertBatch`) already stops on fatal conversion errors (it exits non-zero) — conversion failures are treated as batch failures in the strict pipeline.
- Bash `PIPESTATUS` is available for capturing `./test/main` exit code through a pipe (or `set +e`/`set -e` gating is used).
- CSV output file path defaults to `result_YYYYMMDD_HHMMSS.csv` if not specified (same default as existing `testBatchDir`).

## Risks & Mitigations

| Risk | Mitigation |
|------|------------|
| `set -e` interferes with intentional error capture in the strict functions | Use `set +e` before test invocation, capture `$?`, then `set -e` — or use `if ... ; then` which naturally suppresses `set -e` for the condition. |
| Pipe to `log \| tee` swallows `./test/main` exit code | Use `set -o pipefail` temporarily or capture `PIPESTATUS[0]`; fail-fast must check exit code of `./test/main`, not `tee`. |
| Conversion errors in `batchall-strict` could be ambiguous | `convertBatch` already fails fatally on conversion errors; the strict wrapper inherits that behavior naturally. |
| OOM/timeout on GPU cause legitimate test failures | These are real failures that should stop the batch. They'll be debugged iteratively. |
