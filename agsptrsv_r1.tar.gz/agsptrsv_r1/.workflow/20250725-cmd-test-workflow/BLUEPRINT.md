# Blueprint: cmd.sh fail-fast batch test commands

## Wave Architecture

```
Wave 1: testbatch-strict — Core fail-fast batch test function
Wave 2: batchall-strict — Convert + test-strict pipeline
Wave 3: Documentation — Help text, header, and final polish
```

Each wave modifies only `/home/hdz/testpath/rocm/agsptrsv_r1/cmd.sh`. All waves are sequential (each depends on the previous).

---

## Wave 1: `testbatch-strict` — Core fail-fast batch test

**Goal:** Add a `testBatchDirStrict()` function that tests all `.csr` files in a directory sequentially, stopping on the first failure with clear error diagnostics. Wire it into the main dispatch. Verify independently.

**Tasks:**

| ID | Description | Executor | Files | Depends |
|----|-------------|----------|-------|---------|
| T1.1 | Create `testBatchDirStrict()` function in `cmd.sh` — mirrors `testBatchDir()` but exits on first `./test/main` failure (non-zero exit code), printing matrix name, exit code, and error output to stderr. Uses `set +e` / `set -e` gating around the test invocation for reliable exit-code capture. | executor-low | `cmd.sh` | — |
| T1.2 | Add `testbatch-strict` case entry to the main `case` block, dispatching to `testBatchDirStrict "$2" "$3"`. Add brief description to `show_help()`. | executor-low | `cmd.sh` | T1.1 |

**Verification:** Upload to supercomputer. Run:
```bash
bash cmd.sh testbatch-strict <dir_with_csr_files>
```
- If all matrices pass: exits 0, all results logged.
- If any matrix fails: exits non-zero immediately, stderr shows the failing matrix name, exit code, and test output. Remaining matrices are skipped.

---

## Wave 2: `batchall-strict` — Convert + test-strict pipeline

**Goal:** Add a `batchAllStrict()` function that chains `convertBatch` (existing) with `testBatchDirStrict()` (from Wave 1). Wire into dispatch. Verify the full pipeline.

**Tasks:**

| ID | Description | Executor | Files | Depends |
|----|-------------|----------|-------|---------|
| T2.1 | Create `batchAllStrict()` function in `cmd.sh` — accepts `<gr_dir> <csr_dir> [csv_file]`, calls `convertBatch "${gr_dir}" "${csr_dir}"` (fails fatally on conversion errors), then calls `testBatchDirStrict "${csr_dir}" "${csv_file}"`. Echoes start/end banners. | executor-low | `cmd.sh` | T1.1 |
| T2.2 | Add `batchall-strict` case entry to the main `case` block: `batchAllStrict "$2" "$3" "$4"`. Add brief description to `show_help()`. | executor-low | `cmd.sh` | T2.1 |

**Verification:** Upload to supercomputer. Run:
```bash
bash cmd.sh batchall-strict <gr_dir> <csr_dir>
```
- Converts all `.gr` files successfully.
- Tests all `.csr` files. Stops on first test failure with diagnostics on stderr.
- If any conversion fails, the script stops before testing (inherited from `convertBatch`).

---

## Wave 3: Documentation — Help text, header, and final polish

**Goal:** Ensure all documentation surfaces the new commands: usage header comments, `show_help()` output. Verify existing commands remain untouched via diff.

**Tasks:**

| ID | Description | Executor | Files | Depends |
|----|-------------|----------|-------|---------|
| T3.1 | Update the usage header comment block (lines 8-14) to list `batchall-strict` and `testbatch-strict`. Ensure `show_help()` includes both new commands with consistent formatting. | executor-low | `cmd.sh` | T1.2, T2.2 |
| T3.2 | Final audit: run `diff` against the original `cmd.sh` to confirm no existing function was modified. Verify that running `bash cmd.sh` (no args) prints complete help including the two new commands. | executor-low | `cmd.sh` | T3.1 |

**Verification:** Upload to supercomputer. Run:
```bash
bash cmd.sh
```
- Help output shows `batchall-strict` and `testbatch-strict` commands.
- Running `bash cmd.sh batchall-strict` with no args (or `bash cmd.sh testbatch-strict` with no args) prints a usage error message, not a silent failure.
- `diff original_cmd.sh cmd.sh` shows only additions (no deletions or modifications to existing code).

---

## Executor Tier Summary

| Wave | Tasks | Tier |
|------|-------|------|
| 1 | T1.1, T1.2 | executor-low (shell scripting) |
| 2 | T2.1, T2.2 | executor-low (shell scripting) |
| 3 | T3.1, T3.2 | executor-low (shell scripting) |

All tasks are straightforward bash function creation and case-statement wiring in a single file.
