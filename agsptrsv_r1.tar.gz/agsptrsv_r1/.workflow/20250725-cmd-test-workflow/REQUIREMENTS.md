# Requirements: cmd.sh fail-fast batch test for .gr files

## Vision
Developer edits code locally in WSL, uploads to supercomputer, runs `bash cmd.sh batchall-strict <gr_dir>` to compile and test all .gr files in a directory, stopping on first failure. Developer reports failure output back to AI for debugging. Iterate until all tests pass.

## Must-Haves
- MH1: New command `batchall-strict <gr_dir> <csr_dir> [csv_file]` — converts all .gr in `gr_dir` to .csr in `csr_dir`, then tests all .csr files sequentially, stopping immediately on first test failure (non-zero exit code from `./test/main`).
- MH2: `testbatch-strict <csr_dir> [csv_file]` — same fail-fast behavior but only for .csr test (skip conversion).
- MH3: Fail-fast means the cmd.sh script exits with non-zero code immediately when a matrix test fails, printing the failed matrix name and error output to stderr, and NOT continuing to the next matrix.
- MH4: Error output clearly identifies: (a) which matrix file failed, (b) the exit code, and (c) the error message from `./test/main`.
- MH5: Existing commands (`batchall`, `testbatch`, `convertbatch`, `build`, `test`, `clean`) retain their original behavior unchanged.

## Nice-to-Haves
- NH1: The `batchall-strict` command skips already-converted .csr files (by comparing timestamps) to avoid redundant conversions.
- NH2: Console output includes a progress counter like `[3/50] Testing: matrix.csr` so the user knows how far the batch got before the failure.
- NH3: On early exit due to failure, print a summary line: "Stopped: X passed, 1 failed (matrix_name.csr)."

## Out of Scope
- Modifying `./test/main` itself — only cmd.sh is in scope.
- Automatic retry or recovery after failure.
- Parallel/multi-GPU testing.
- Changing the build system or Makefile.
- CI/CD integration.

## Constraints
- Must run on the supercomputer with: bash, `module load compiler/rocm/4.0.1`, Python 3, AMD GPU target gfx906.
- `set -e` at top of cmd.sh; any command that must not trigger early exit (e.g., conversion attempts) needs `|| true` or explicit error handling.
- `ensure_csr()` outputs the .csr path to stdout; all diagnostics go to stderr. Do not break this contract.
- All build/test output continues to append to `build.log`.
- Local env is WSL (edit only, no compilation); all testing happens on supercomputer via user.

## Risks
- Risk 1: `.gr` conversion failures could also be treated as test failures if not careful. Should conversion errors stop the batch or be skipped? (Decision: conversion errors should stop immediately, since a missing .csr means the test can't run.)
- Risk 2: The `testBatchDir` function currently uses `set -e` + `./test/main ... | log` which may swallow the exit code. Need explicit `|| exit 1` or similar to propagate failure.
- Risk 3: Some matrices may legitimately fail due to OOM or timeout on the GPU — these will be debugged iteratively in subsequent rounds.
