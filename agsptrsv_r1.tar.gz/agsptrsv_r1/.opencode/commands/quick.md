---
description: Fast-track a small task (skip interview and spec gates)
subtask: true
model: opencode-go/deepseek-v4-flash
---
Quick task: $ARGUMENTS

## Qualification Gates

All four gates must pass for quick mode to proceed:

1. **File count gate**: If estimated files affected > 3 → redirect to `/discuss`.  
   Message: "This task affects >3 files. Use /discuss for full workflow."

2. **Ambiguity gate**: If task has conflicting or vague requirements → redirect to `/discuss`.  
   Message: "This task is ambiguous. Use /discuss to clarify requirements."

3. **Architecture gate**: If task involves new patterns, data model changes, schema changes, new dependencies, or cross-cutting concerns → redirect to `/discuss`.  
   Message: "This task involves architectural decisions. Use /discuss for full workflow."

4. **Time gate**: If estimated time > 30 minutes → redirect to `/discuss`.  
   Message: "This task is too large for quick mode (>30 min). Use /discuss for full workflow."

**All gates pass**: Implement immediately. Skip interview, spec, and gates. Report when done.

**Any gate fails**: Redirect to `/discuss` for full workflow.
