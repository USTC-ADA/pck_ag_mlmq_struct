---
description: Begin wave-based implementation from the locked blueprint
---
## Phase 3: Execute

### 1. Check workflow mode

Read `.workflow/config.json` and extract the `"mode"` field. Use this command:

```
grep '"mode"' .workflow/config.json | head -1 | sed 's/.*"mode"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/'
```

- `"mode": "slim"` → use OpenCode built-in `"general"` agent for all tasks
- `"mode": "full"` or field missing/unreadable → use custom executor-low / executor-high agents (default)
- If config.json is missing or corrupted → default to `"full"` mode

### 2. Load the blueprint

Read `SPEC.md` and `BLUEPRINT.md` from `.workflow/<workflow-id>/`. Parse the wave architecture: how many waves, what tasks per wave, which executor tier each task uses.

### 3. Execute waves (mode-dependent)

For each wave, for each task in the wave:

**Slim mode:**
Implement each task directly using your own tools (read, write, edit, bash). Do NOT delegate via `task()` — work on each task yourself. For each task:
- Read SPEC.md and BLUEPRINT.md from `.workflow/<workflow-id>/`
- Locate the task description in BLUEPRINT.md (task ID, description, files, verification)
- Implement the task directly, following existing code conventions
- Make one atomic git commit per task
  - PR creation (create-wave-pr.sh) is skipped in slim mode — PR scripts are full-mode only

**Full mode (default):**
**YOU MUST use the `task` tool to delegate every task.** Do NOT implement tasks yourself.
First resolve model configs:
```
bash scripts/resolve-agent-config.sh executor-low
bash scripts/resolve-agent-config.sh executor-high
```
If `resolve-agent-config.sh` is unavailable, grep `config.json` directly.

Determine the subagent type from the BLUEPRINT.md executor column:
- `executor-low` → `task(subagent_type: "executor-low", ...)`
- `executor-high` → `task(subagent_type: "executor-high", ...)`

Call `task()` with a prompt that includes:
- The SPEC.md path and BLUEPRINT.md path
- The specific task description from BLUEPRINT.md (task ID, description, files, verification)
- The resolved model info: "Configured model: <model>, temperature: <temp>"
- Instruction: "Read SPEC.md and BLUEPRINT.md before starting. Implement only this task. Follow existing code conventions. Make one atomic git commit."

After each wave (all tasks in that wave complete):
- Save a checkpoint to `.workflow/<workflow-id>/CHRONICLE.md` listing completed tasks, commit hashes, files changed
- **Full mode — Create a PR for this wave:** Call `bash scripts/create-wave-pr.sh <wave-number> <workflow-id>`. Report the PR URL to me. If the script outputs manual instructions (gh CLI unavailable), relay those instructions to me instead.
- Tell me: "Wave N/N complete. Continue? (type 'continue' or 'stop')"
- Pause and wait for response before proceeding to next wave

### 4. Handling execution failures (full mode)

When an executor reports `STATUS: blocked` or returns a bug/error/crash:

1. **Debug first** — dispatch the `debugger` agent for root cause analysis:
   - Resolve config: `bash scripts/resolve-agent-config.sh debugger`
   - Call `task(subagent_type: "debugger", description: "Debug <issue>", prompt: "Read SPEC.md and BLUEPRINT.md from .workflow/<workflow-id>/. The executor encountered this issue: <description>. Investigate the root cause. Inspect relevant code, error logs, and test output. Report: root cause hypothesis, evidence, and recommended fix approach.")`
2. **Apply the four-rule deviation system** via `bash scripts/handle-deviation.sh` based on the debugger's findings.
3. **Re-dispatch** the task to the appropriate executor with the fix context included.
4. If the debugger cannot determine the cause, escalate to the user.

Slim mode: Debug directly yourself — do NOT delegate. Use grep/read/bash to investigate the issue.

### 5. Documentation tasks (full mode)

When the BLUEPRINT assigns a documentation task (README, changelog, API docs, structured writing):

- Dispatch `writer` agent: `task(subagent_type: "writer", description: "Write <doc>", prompt: "Read SPEC.md from .workflow/<workflow-id>/. Write <doc> following the project's existing conventions. Keep it concise and accurate.")`

### Ground rules

- Do NOT implement anything outside the locked SPEC
- Each task gets one atomic git commit
- Tasks within a wave may run in parallel if they have no dependencies on each other
- If a task() call fails, report the error and pause — do not silently skip
- For bugs/errors: delegate to `debugger` before retrying. Don't guess at fixes.

When all waves are done:
- Tell me: "Execution complete. Run /accept to verify and accept."
