---
description: Verify completed work against spec and accept delivery
---
## Phase 4+5: Audit + Confirm

### 1. Check workflow mode

Read `.workflow/config.json` and extract the `"mode"` field. Use this command:

```
grep '"mode"' .workflow/config.json | head -1 | sed 's/.*"mode"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/'
```

- `"mode": "slim"` → use OpenCode built-in `"general"` agent for verification
- `"mode": "full"` or field missing/unreadable → use custom `"verifier"` agent (default)
- If config.json is missing or corrupted → default to `"full"` mode

### 2. Load the spec

Read `SPEC.md` from `.workflow/<workflow-id>/`. Identify all Must-Haves (MH1, MH2, ...) with their acceptance criteria.

### 3. Delegate verification (mode-dependent)

**Slim mode:**
Verify directly — do NOT delegate. You are the main agent. Work through these steps yourself:

1. Read `.workflow/<workflow-id>/SPEC.md` — identify all Must-Haves (MH1, MH2, ...) with their acceptance criteria.
2. Read `.workflow/<workflow-id>/BLUEPRINT.md` — identify tasks and their verification steps.
3. Read `.workflow/<workflow-id>/CHRONICLE.md` — review what was actually done during execution.
4. Inspect the implementation directly: use `read`, `grep`, and `glob` tools to check every Must-Have. Collect file:line evidence for each.
5. Run the project's test suite directly with `bash`. Record the pass/fail count.
6. Do a security scan: check for hardcoded secrets, unsanitized inputs, or insecure dependencies.
7. Produce the verification matrix yourself — for each Must-Have, record PASS or FAIL with file:line evidence. Include a test run summary.

**Full mode (default):**

**YOU MUST use the `task` tool to delegate.** Do NOT perform verification yourself.
First resolve model config for verifier agent:
```
bash scripts/resolve-agent-config.sh verifier
```
If `resolve-agent-config.sh` is unavailable, grep `config.json` directly.

Then call `task(subagent_type: "verifier", description: "Verify implementation against SPEC", prompt: "<detailed prompt>")` where the prompt includes:
- The SPEC.md path: `.workflow/<workflow-id>/SPEC.md`
- The BLUEPRINT.md path: `.workflow/<workflow-id>/BLUEPRINT.md`
- The CHRONICLE.md path: `.workflow/<workflow-id>/CHRONICLE.md`
- The resolved model info: "Use model: <model> at temperature: <temp>"
- Instructions: "Read SPEC.md, BLUEPRINT.md, and CHRONICLE.md. Inspect the actual implementation (code, tests, commits). For each Must-Have in SPEC.md, determine PASS or FAIL with file:line evidence. Also run any available tests. Return a structured verification matrix with Status and Evidence columns, plus a test run summary, plus a security checklist scan. The main agent will present this in the Acceptance Gate."

### 4. Run tests

After the verifier returns, run the project's test suite to confirm test pass count.

### 4b. Merge PR stack (full mode only)

**Full mode:** Call `bash scripts/merge-pr-stack.sh <workflow-id>`. Report the merge results to me (merged count, any failures). If the merge fails or `gh` CLI is unavailable, the script outputs manual merge instructions — relay those instructions to me.

**Slim mode:** Skip this step. PR stack merge is full-mode only.

### 5. Present Acceptance Gate
Using the verifier's matrix, present the Acceptance Gate:

```
┌─────────────────── Acceptance Gate ──────────────────┐
│  VERIFIED:                                            │
│  ✓ MH1: ... — file.ts:42 — PASS                      │
│  ✗ MH2: ... — no test coverage — FAIL                │
│                                                       │
│  Tests: N/N passing                                   │
│                                                       │
│  Type "accept" to confirm. Type "reject" to fix.      │
└───────────────────────────────────────────────────────┘
```

### 6. Handle response

If I type "accept":
- Generate `.workflow/<workflow-id>/RETROSPECTIVE.md` with: what went well, what went wrong, what was learned, what changed from SPEC
- Mark workflow complete


If I type "reject":
- List each FAIL from the verifier's matrix with what needs fixing
- Tell me: "Returning to execution phase. Re-run /execute to fix the failures."
