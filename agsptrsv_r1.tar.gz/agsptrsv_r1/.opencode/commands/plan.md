---
description: Create locked SPEC.md and BLUEPRINT.md from requirements
---
## Phase 2: Plan

### 1. Check workflow mode

Read `.workflow/config.json` and extract the `"mode"` field. Use this command:

```
grep '"mode"' .workflow/config.json | head -1 | sed 's/.*"mode"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/'
```

- `"mode": "slim"` → use OpenCode built-in agent types below
- `"mode": "full"` or field missing/unreadable → use custom myWorkFlow agents (default)
- If config.json is missing or corrupted → default to `"full"` mode

### 2. Research gate

Find the most recent workflow-id under `.workflow/` (e.g., `20260720-subagent-model-routing`):

```
ls -td .workflow/20* 2>/dev/null | head -1 | xargs basename
```

Run the research gate script with that workflow-id:

```
bash scripts/research-gate.sh <workflow-id>
```

**If RESEARCH_NEEDED:**

The requirements involve domain or technology unknowns. Dispatch the `researcher` subagent first to investigate the unfamiliar territory. For complex research (multiple unknown domains, broad API surface, cross-cutting concerns), also dispatch `explorer` **in parallel** to search the codebase for relevant patterns, existing usage, or integration points.

Full mode — dispatch researcher (and optionally explorer in parallel):
- Resolve config: `bash scripts/resolve-agent-config.sh researcher`
- Call `task(subagent_type: "researcher", description: "Research <topic>", prompt: "Read .workflow/<workflow-id>/REQUIREMENTS.md. Research any unfamiliar libraries, domains, APIs, or patterns mentioned. Return a structured research report with findings, tradeoffs, risks, and confidence ratings.")`
- Optionally in parallel: `task(subagent_type: "explorer", description: "Explore codebase for <topic>", prompt: "Search the codebase for existing patterns or code related to <topic>. Report files found, existing approaches, and integration considerations.")`

Slim mode — dispatch general subagent:
- Call `task(subagent_type: "general", description: "Research <topic>", prompt: "Read .workflow/<workflow-id>/REQUIREMENTS.md. Research any unfamiliar libraries, domains, APIs, or patterns mentioned. Return a structured research report with findings, tradeoffs, risks, and confidence ratings.")`

After research completes, pass the findings to the planner in step 4. Include a summary of research results in the planner's prompt so it can make informed architectural decisions.

**If SKIP:**

The workflow is trivial (≤2 files, no new libs/patterns, ≤10 bullet points). Log the skip (already done by research-gate.sh to `.workflow/<workflow-id>/ADL.md`) and proceed directly to planner delegation below.

### 3. Locate requirements

Read `REQUIREMENTS.md` from `.workflow/<workflow-id>/`. If the research gate above indicated RESEARCH_NEEDED, include the research findings as context when reading.

### 3.5. Agent dispatch reference

These subagents are available for task delegation. Use the correct tier:

| Task type | Agent | Description |
|-----------|-------|-------------|
| Mechanical/config/scaffolding | `executor-low` | Pattern-following; escalate if hidden complexity |
| Business logic/APIs/architecture | `executor-high` | Complex implementation, security, cross-cutting |
| Root cause analysis/hypothesis | `debugger` | Debug crashes, errors, failing tests |
| Documentation/READMEs/writing | `writer` | Structured writing, changelogs, tone consistency |
| Codebase exploration | `explorer` | Pattern detection, directory structure, conventions |
| Technology research | `researcher` | Library comparisons, API surfaces, domain research |
| Test writing/edge cases | `tester` | Unit/integration tests, coverage, flakiness |
| Spec compliance audit | `verifier` | PASS/FAIL matrix, security checklist, evidence |

### 4. Delegate to create SPEC and BLUEPRINT (mode-dependent)

**Full mode:** YOU MUST use the `task` tool to delegate. Do NOT create SPEC.md or BLUEPRINT.md yourself.

**Slim mode:**
Create SPEC.md and BLUEPRINT.md directly (no delegation). Read `.workflow/<workflow-id>/REQUIREMENTS.md` first. Then use the `write` tool to create:
- `.workflow/<workflow-id>/SPEC.md` — numbered Must-Haves (MH1, MH2...), each with acceptance criteria
- `.workflow/<workflow-id>/BLUEPRINT.md` — wave-based decomposition (3 waves maximum, 2-4 tasks per wave), each task specifying: executor tier (executor-low or executor-high), files to modify, verification method, and dependencies

Produce a summary of all Must-Haves and Out of Scope items to present the Contract Gate. For rare complex research, you may optionally use `task(subagent_type: "general")`, but this is not required.

**Full mode (default):**
First resolve the model config for the planner agent:
```
bash scripts/resolve-agent-config.sh planner
```
If `resolve-agent-config.sh` is not available, grep `config.json` directly for the planner agent section.

Then call `task(subagent_type: "planner", description: "Create SPEC and BLUEPRINT", prompt: "<detailed prompt>")` where the prompt includes:
- The full path to REQUIREMENTS.md: `.workflow/<workflow-id>/REQUIREMENTS.md`
- Instructions: "Read REQUIREMENTS.md from .workflow/<workflow-id>/. Create SPEC.md with numbered Must-Haves (MH1, MH2...), each with acceptance criteria. Create BLUEPRINT.md with wave-based decomposition (3 waves maximum, 2-4 tasks per wave). Each task in the BLUEPRINT must specify: executor tier (executor-low, executor-high, debugger, writer, explorer, tester, or verifier), files to modify, verification method, and dependencies. For documentation tasks use 'writer', for debugging use 'debugger'. Write the output files to .workflow/<workflow-id>/SPEC.md and .workflow/<workflow-id>/BLUEPRINT.md. Return a summary of all Must-Haves and Out of Scope items so the main agent can present the Contract Gate."
- The resolved model info: "Use model: <model> at temperature: <temp>"

### 5. Present Contract Gate

After the subagent returns, present the Contract Gate using the subagent's summary:

```
┌─────────────────── Contract Gate ────────────────────┐
│  MUST-HAVES:              │  OUT OF SCOPE:            │
│  MH1: ...                 │  ...                      │
│                                                       │
│  Type "confirm" to lock. Changes require re-plan.     │
└───────────────────────────────────────────────────────┘
```

Wait for "confirm" before locking.  Then tell me: "Spec locked. Run /execute to begin."
