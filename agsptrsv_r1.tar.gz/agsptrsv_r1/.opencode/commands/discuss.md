---
description: Start discovery interview to capture requirements
---
## Phase 1: Discuss

$ARGUMENTS

Interview me to capture requirements. Ask about vision, must-haves, constraints, out-of-scope, and risks. Use the `question` tool for multiple-choice when appropriate.

After the interview, write REQUIREMENTS.md to .workflow/<workflow-id>/REQUIREMENTS.md using this format:

```markdown
# Requirements: <feature>

## Vision
...

## Must-Haves
- MH1: ...

## Nice-to-Haves
- ...

## Out of Scope
- ...

## Constraints
- ...

## Risks
- ...
```

Generate a unique workflow-id as `YYYYMMDD-<short-description>`.

Then tell me: "Interview complete. Run /plan to create the specification."
