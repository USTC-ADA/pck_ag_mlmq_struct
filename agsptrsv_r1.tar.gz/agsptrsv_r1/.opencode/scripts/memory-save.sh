#!/usr/bin/env bash
set -euo pipefail

# memory-save.sh — Save a memory entry to .workflow/memory.json
# Accepts concept, content, importance (1-5), and workflow-id.
# Idempotent: entries with the same concept + content are not duplicated.
#
# Usage:
#   ./memory-save.sh concept=<name> content=<text> importance=<1-5> workflow-id=<id>
#   ./memory-save.sh --concept <name> --content <text> --importance <1-5> --workflow-id <id>
#   ./memory-save.sh --help

MEMORY_FILE=".workflow/memory.json"

# ------------------------------------------------------------------
# usage — print help
# ------------------------------------------------------------------
usage() {
    cat <<'EOF'
Usage: memory-save.sh [--concept <name>] [--content <text>] [--importance <1-5>] [--workflow-id <id>]
       memory-save.sh concept=<name> content=<text> importance=<1-5> workflow-id=<id>

Save a memory entry to .workflow/memory.json.

Arguments:
  concept       Concept tag for the entry (required)
  content       Content / body of the memory entry (required)
  importance    Importance score 1-5 (required, 1=lowest, 5=highest)
  workflow-id   Identifier of the originating workflow (required)

Flags:
  --help        Show this help message and exit

Idempotent: entries with the same concept and content are not duplicated.
Creates .workflow/ and .workflow/memory.json if they do not exist.
EOF
    exit 0
}

# ------------------------------------------------------------------
# escape_json — escape a string for inclusion in a double-quoted JSON value
# ------------------------------------------------------------------
escape_json() {
    local str="$1"
    str="${str//\\/\\\\}"       # backslash -> \\
    str="${str//\"/\\\"}"       # double-quote -> \"
    # Replace literal newlines with \n (memory entries should not contain raw newlines)
    str="${str//
/\\n}"
    echo "$str"
}

# ------------------------------------------------------------------
# Parse arguments (supports both --key value and key=value styles)
# ------------------------------------------------------------------
CONCEPT=""
CONTENT=""
IMPORTANCE=""
WORKFLOW_ID=""

while [[ $# -gt 0 ]]; do
    case "$1" in
        --help) usage ;;
        --concept)
            CONCEPT="$2"; shift 2 ;;
        --content)
            CONTENT="$2"; shift 2 ;;
        --importance)
            IMPORTANCE="$2"; shift 2 ;;
        --workflow-id)
            WORKFLOW_ID="$2"; shift 2 ;;
        --*)
            echo "ERROR: Unknown flag: $1" >&2
            usage ;;
        *=*)
            key="${1%%=*}"
            val="${1#*=}"
            # Validate key
            case "$key" in
                concept)     CONCEPT="$val" ;;
                content)     CONTENT="$val" ;;
                importance)  IMPORTANCE="$val" ;;
                workflow-id) WORKFLOW_ID="$val" ;;
                *)
                    echo "ERROR: Unknown key: '$key'" >&2
                    usage ;;
            esac
            shift ;;
        *)
            echo "ERROR: Unexpected argument: '$1'" >&2
            usage ;;
    esac
done

# ------------------------------------------------------------------
# Validation
# ------------------------------------------------------------------
if [[ -z "$CONCEPT" ]]; then
    echo "ERROR: 'concept' is required." >&2
    usage
fi
if [[ -z "$CONTENT" ]]; then
    echo "ERROR: 'content' is required." >&2
    usage
fi
if [[ -z "$IMPORTANCE" ]]; then
    echo "ERROR: 'importance' is required." >&2
    usage
fi
if [[ -z "$WORKFLOW_ID" ]]; then
    echo "ERROR: 'workflow-id' is required." >&2
    usage
fi

# Validate importance is an integer 1-5
if ! [[ "$IMPORTANCE" =~ ^[1-5]$ ]]; then
    echo "ERROR: 'importance' must be an integer between 1 and 5 (got: '$IMPORTANCE')." >&2
    exit 1
fi

# ------------------------------------------------------------------
# Ensure .workflow/ directory and memory.json exist
# ------------------------------------------------------------------
if [[ ! -d ".workflow" ]]; then
    mkdir -p ".workflow"
fi

if [[ ! -f "$MEMORY_FILE" ]]; then
    echo "[]" > "$MEMORY_FILE"
fi

# Basic structure validation
if ! grep -q '^\[' "$MEMORY_FILE" 2>/dev/null; then
    echo "WARNING: $MEMORY_FILE does not start with '[' — reinitializing." >&2
    echo "[]" > "$MEMORY_FILE"
fi

# ------------------------------------------------------------------
# Build the new entry JSON (compact single-line format)
# ------------------------------------------------------------------
escaped_concept=$(escape_json "$CONCEPT")
escaped_content=$(escape_json "$CONTENT")
escaped_workflow=$(escape_json "$WORKFLOW_ID")
timestamp=$(date -u +"%Y-%m-%dT%H:%M:%SZ")

NEW_ENTRY="{\"concept\":\"${escaped_concept}\",\"content\":\"${escaped_content}\",\"importance\":${IMPORTANCE},\"workflow_id\":\"${escaped_workflow}\",\"timestamp\":\"${timestamp}\"}"

# ------------------------------------------------------------------
# Idempotency check — skip if an entry with the same concept + content exists
# ------------------------------------------------------------------
# We search for a line that contains both the concept and content keys with the same values.
# Build a grep-friendly pattern for the content (may contain regex metacharacters).
concept_pattern="\"concept\":\"${escaped_concept}\""
content_pattern="\"content\":\"${escaped_content}\""

if grep -q "$concept_pattern" "$MEMORY_FILE" 2>/dev/null; then
    if grep -q "$content_pattern" "$MEMORY_FILE" 2>/dev/null; then
        # Both exist — check if they appear on the same line (same entry)
        if grep -q "${concept_pattern}.*${content_pattern}" "$MEMORY_FILE" 2>/dev/null; then
            echo "Entry already exists (concept='${CONCEPT}' + matching content) — skipping." >&2
            exit 0
        fi
    fi
fi

# ------------------------------------------------------------------
# Insert the new entry into the JSON array
# ------------------------------------------------------------------
tmpfile="${MEMORY_FILE}.tmp.$$"

# Collect existing entries (lines that contain a "concept" field — compact JSON objects)
entries=()
while IFS= read -r line; do
    if [[ "$line" == *'"concept"'* ]]; then
        entries+=("$line")
    fi
done < "$MEMORY_FILE"

# Append the new entry
entries+=("$NEW_ENTRY")

# Rebuild the entire JSON array (always produces valid JSON)
{
    echo "["
    for i in "${!entries[@]}"; do
        if [[ $i -gt 0 ]]; then
            echo ","
        fi
        echo "${entries[$i]}"
    done
    echo "]"
} > "$tmpfile"

mv "$tmpfile" "$MEMORY_FILE"

echo "Memory saved: concept='${CONCEPT}' importance=${IMPORTANCE} workflow='${WORKFLOW_ID}'"
exit 0
