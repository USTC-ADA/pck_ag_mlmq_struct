#!/usr/bin/env bash
# play-phase-sound.sh — Play a phase-completion notification sound
# Supports two modes: custom (default) and random
# Reads configuration from .workflow/config.json "sound" block
#
# sound.enabled=false    → silent exit 0 (NH1)
# sound.mode=custom      → play customPath file, fallback to DEFAULT_SOUND (MH1)
# sound.mode=random      → pick random *.wav from .opencode/sounds/ (MH2)
# No audio player        → warn stderr + exit 0 (MH4)

CONFIG_FILE=".workflow/config.json"
DEFAULT_SOUND=".opencode/sounds/complete.wav"

# -------- dry-run flag (NH3) --------

DRY_RUN=false
if [[ "$1" == "--dry-run" ]]; then
    DRY_RUN=true
fi

# -------- defaults --------

SOUND_ENABLED=true
SOUND_MODE="custom"
CUSTOM_PATH=""

# -------- config parsing --------

if [[ -f "$CONFIG_FILE" ]]; then
    # Strip all whitespace for simple regex parsing
    FLAT=$(tr -d '[:space:]' < "$CONFIG_FILE")

    # Extract the "sound" block (must be flat JSON — no nested braces)
    SOUND_BLOCK=$(echo "$FLAT" | grep -o '"sound":{[^}]*}' || true)

    if [[ -n "$SOUND_BLOCK" ]]; then
        # --- enabled (fix: explicitly check for false, default true) ---
        if echo "$SOUND_BLOCK" | grep -q '"enabled":false'; then
            SOUND_ENABLED=false
        fi

        # --- mode (default: custom) ---
        EXTRACTED_MODE=$(echo "$SOUND_BLOCK" | grep -o '"mode":"[^"]*"' | head -1 | sed 's/.*"mode":"\([^"]*\)".*/\1/' || true)
        if [[ -n "$EXTRACTED_MODE" ]]; then
            SOUND_MODE="$EXTRACTED_MODE"
        fi

        # --- customPath (default: empty) ---
        CUSTOM_PATH=$(echo "$SOUND_BLOCK" | grep -o '"customPath":"[^"]*"' | head -1 | sed 's/.*"customPath":"\([^"]*\)".*/\1/' || true)
    fi
fi

# -------- enabled check (NH1: silent exit if disabled; skip for dry-run) --------

if ! $SOUND_ENABLED && ! $DRY_RUN; then
    exit 0
fi

# -------- file resolution --------

if [[ "$SOUND_MODE" == "random" ]]; then
    # Random mode: collect *.wav files from sounds directory (NH2: glob excludes non-.wav)
    shopt -s nullglob
    SOUND_FILES=(.opencode/sounds/*.wav)
    shopt -u nullglob

    if [[ ${#SOUND_FILES[@]} -eq 0 ]]; then
        echo "WARNING: No .wav files found in .opencode/sounds/ for random mode. Sound disabled." >&2
        exit 0
    fi

    INDEX=$((RANDOM % ${#SOUND_FILES[@]}))
    PLAY_FILE="${SOUND_FILES[$INDEX]}"
else
    # Custom mode (default): use customPath if valid, else fall back to DEFAULT_SOUND
    PLAY_FILE="$DEFAULT_SOUND"

    if [[ -n "$CUSTOM_PATH" ]]; then
        if [[ -f "$CUSTOM_PATH" ]]; then
            PLAY_FILE="$CUSTOM_PATH"
        else
            echo "WARNING: customPath '$CUSTOM_PATH' not found, falling back to default" >&2
        fi
    fi
fi

# -------- dry-run: print resolved path and exit (skips enabled check / playback) --------

if $DRY_RUN; then
    echo "Would play: $PLAY_FILE"
    exit 0
fi

# Safety check: resolved file must exist
if [[ ! -f "$PLAY_FILE" ]]; then
    exit 0
fi

# -------- player availability check (MH4) --------

HAS_PLAYER=false
if command -v pw-play &>/dev/null; then
    HAS_PLAYER=true
elif command -v powershell.exe &>/dev/null; then
    HAS_PLAYER=true
elif command -v paplay &>/dev/null; then
    HAS_PLAYER=true
elif command -v aplay &>/dev/null; then
    HAS_PLAYER=true
fi

if ! $HAS_PLAYER; then
    echo "WARNING: No audio player found (pw-play, powershell.exe, paplay, or aplay). Sound disabled." >&2
    exit 0
fi

# -------- playback with sequential fallback chain --------

(
    PLAYED=false

    if ! $PLAYED && command -v pw-play &>/dev/null; then
        pw-play "$PLAY_FILE" >/dev/null 2>&1 && PLAYED=true
    fi

    if ! $PLAYED && command -v powershell.exe &>/dev/null; then
        WIN_PATH=$(wslpath -w "$PLAY_FILE" 2>/dev/null || true)
        if [[ -n "$WIN_PATH" ]]; then
            export SOUND_WIN_PATH="$WIN_PATH"
            powershell.exe -c '(New-Object Media.SoundPlayer $env:SOUND_WIN_PATH).PlaySync()' 2>/dev/null && PLAYED=true
        fi
    fi

    if ! $PLAYED && command -v paplay &>/dev/null; then
        paplay "$PLAY_FILE" 2>/dev/null && PLAYED=true
    fi

    if ! $PLAYED && command -v aplay &>/dev/null; then
        aplay -q "$PLAY_FILE" 2>/dev/null && PLAYED=true
    fi
) &

exit 0
