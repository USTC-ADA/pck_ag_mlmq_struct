#!/usr/bin/env bash
set -euo pipefail

# handle-deviation.sh — Handle deviation events per the four-rule system
# Rule 1 (Bugs): Auto-fix via optional fix-command, log to ADL
# Rule 2 (Missing safeguards): Log to ADL, notes missing validation/error handling added
# Rule 3 (Blocking technical issues): Log to ADL, notes the unblock action
# Rule 4 (Architecture changes): Prints user message, exits 1 — no file changes
#
# Usage:
#   ./handle-deviation.sh rule=<1-4> description=<text> workflow-id=<id> [fix-command=<cmd>]
#   ./handle-deviation.sh --rule <1-4> --description <text> --workflow-id <id> [--fix-command <cmd>]
#   ./handle-deviation.sh --help

# ------------------------------------------------------------------
# usage — print help
# ------------------------------------------------------------------
usage() {
    cat <<'EOF'
Usage: handle-deviation.sh --rule <1-4> --description <text> --workflow-id <id> [--fix-command <cmd>]
       handle-deviation.sh rule=<1-4> description=<text> workflow-id=<id> [fix-command=<cmd>]

Handle deviation events according to the four-rule deviation system.

Rules:
  1  Bugs — auto-fix (via optional fix-command), log to ADL
  2  Missing safeguards — log to ADL (validation/error handling added)
  3  Blocking technical issues — log to ADL (blocking issue resolved)
  4  Architecture changes — print user-facing message, exit 1, no file changes

Arguments:
  rule            Rule number 1-4 (required)
  description     Description of the deviation/issue (required)
  workflow-id     Workflow identifier for ADL path (required)
  fix-command     Optional command to execute for Rule 1 auto-fix

Flags:
  --help          Show this help message and exit

All deviations for rules 1-3 are timestamped and appended to:
  .workflow/<workflow-id>/ADL.md

Rule 4 does NOT modify any files — it prints a user-facing message and exits
with status 1. The orchestrator is expected to escalate for user approval.
EOF
    exit 0
}

# ------------------------------------------------------------------
# Parse arguments (supports both --key value and key=value styles)
# ------------------------------------------------------------------
RULE=""
DESCRIPTION=""
WORKFLOW_ID=""
FIX_CMD=""

while [[ $# -gt 0 ]]; do
    case "$1" in
        --help) usage ;;
        --rule)
            RULE="$2"; shift 2 ;;
        --description)
            DESCRIPTION="$2"; shift 2 ;;
        --workflow-id)
            WORKFLOW_ID="$2"; shift 2 ;;
        --fix-command)
            FIX_CMD="$2"; shift 2 ;;
        --*)
            echo "ERROR: Unknown flag: $1" >&2
            usage ;;
        *=*)
            key="${1%%=*}"
            val="${1#*=}"
            case "$key" in
                rule)         RULE="$val" ;;
                description)  DESCRIPTION="$val" ;;
                workflow-id)  WORKFLOW_ID="$val" ;;
                fix-command)  FIX_CMD="$val" ;;
                *)
                    echo "ERROR: Unknown key: '$key'" >&2
                    usage ;;
            esac
            shift ;;
        *)
            echo "ERROR: Unexpected argument: '$1'" >&2
            usage ;;
    esac
done

# ------------------------------------------------------------------
# Validation
# ------------------------------------------------------------------
if [[ -z "$RULE" ]]; then
    echo "ERROR: 'rule' is required (1-4)." >&2
    usage
fi
if [[ -z "$DESCRIPTION" ]]; then
    echo "ERROR: 'description' is required." >&2
    usage
fi
if [[ -z "$WORKFLOW_ID" ]]; then
    echo "ERROR: 'workflow-id' is required." >&2
    usage
fi

# Validate rule number is an integer 1-4
if ! [[ "$RULE" =~ ^[1-4]$ ]]; then
    echo "ERROR: Invalid rule number '${RULE}'. Must be 1, 2, 3, or 4." >&2
    exit 1
fi

# ------------------------------------------------------------------
# Construct paths
# ------------------------------------------------------------------
ADL_DIR=".workflow/${WORKFLOW_ID}"
ADL_FILE="${ADL_DIR}/ADL.md"
# Look for ADL template in installed location first, then source location
TEMPLATE_FILE=""
if [[ -f ".workflow/templates/ADL.md" ]]; then
    TEMPLATE_FILE=".workflow/templates/ADL.md"
elif [[ -f "templates/ADL.md" ]]; then
    TEMPLATE_FILE="templates/ADL.md"
fi

# ------------------------------------------------------------------
# Generate timestamp
# ------------------------------------------------------------------
ts=$(date -u +"%Y-%m-%dT%H:%M:%SZ")

# ------------------------------------------------------------------
# Rule 4: Architecture changes — message only, no file modifications
# ------------------------------------------------------------------
if [[ "$RULE" == "4" ]]; then
    echo "Rule 4: Architecture change requires user approval. Issue: ${DESCRIPTION}"
    exit 1
fi

# ------------------------------------------------------------------
# Determine action and files descriptions per rule
# ------------------------------------------------------------------
case "$RULE" in
    1)
        # Rule 1: Bugs — apply optional fix-command, log result
        if [[ -n "$FIX_CMD" ]]; then
            if eval "$FIX_CMD" 2>/dev/null; then
                ACTION="Applied fix: ${FIX_CMD}"
            else
                ACTION="Fix attempted but may have failed: ${FIX_CMD}"
            fi
            FILES="${FIX_CMD}"
        else
            ACTION="Bug identified — no fix command provided"
            FILES="none"
        fi
        echo "Rule 1: Bug logged${FIX_CMD:+ and fix applied}"
        ;;
    2)
        # Rule 2: Missing safeguards — log, agent handles the fix
        ACTION="Added missing validation/error handling"
        FILES="see implementation"
        echo "Rule 2: Missing safeguards logged — validation/error handling added"
        ;;
    3)
        # Rule 3: Blocking technical issues — log, agent handles the fix
        ACTION="Resolved blocking technical issue"
        FILES="see implementation"
        echo "Rule 3: Blocking technical issue logged — issue unblocked"
        ;;
esac

# ------------------------------------------------------------------
# Ensure ADL directory and file exist
# ------------------------------------------------------------------
if [[ ! -d "$ADL_DIR" ]]; then
    mkdir -p "$ADL_DIR"
fi

if [[ ! -f "$ADL_FILE" ]]; then
    # Create ADL file from template if available, otherwise create minimal version
    creation_date=$(date -u +"%Y-%m-%d")
    if [[ -f "$TEMPLATE_FILE" ]]; then
        cp "$TEMPLATE_FILE" "$ADL_FILE"
        # Substitute placeholders
        sed -i "s/{{workflowId}}/${WORKFLOW_ID}/g" "$ADL_FILE"
        sed -i "s/{{creationDate}}/${creation_date}/g" "$ADL_FILE"
    else
        cat > "$ADL_FILE" <<ADLEOF
# ADL: ${WORKFLOW_ID}

**Created**: ${creation_date}

## Decision Log

| Timestamp | Phase | Rule/Trigger | Description | Action Taken | Result |
|-----------|-------|--------------|-------------|--------------|--------|
|           |       |              |             |              |        |

## Deviation Log

| Timestamp | Rule | Issue | Action | Files |
|-----------|------|-------|--------|-------|
ADLEOF
    fi
fi

# ------------------------------------------------------------------
# Append deviation entry to ADL Deviation Log table
# ------------------------------------------------------------------
echo "| ${ts} | ${RULE} | ${DESCRIPTION} | ${ACTION} | ${FILES} |" >> "$ADL_FILE"

exit 0
