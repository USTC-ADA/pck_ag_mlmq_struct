#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
COMMANDS_DIR="${SCRIPT_DIR}/../commands"
AGENTS_DIR="${SCRIPT_DIR}/../agents"

PASS_COUNT=0
FAIL_COUNT=0
TOTAL=0

check_either() {
    local file="$1"
    local agent1="$2"
    local agent2="$3"
    local label="$4"
    TOTAL=$((TOTAL + 1))

    if [[ ! -f "$file" ]]; then
        echo "  FAIL — $label — file not found: $file"
        FAIL_COUNT=$((FAIL_COUNT + 1))
        return 1
    fi

    local has_task
    has_task=$(grep -c 'task(' "$file" || true)

    local has_agent1
    has_agent1=$(grep -c "subagent_type.*\"$agent1\"" "$file" || true)

    local has_agent2
    has_agent2=$(grep -c "subagent_type.*\"$agent2\"" "$file" || true)

    if [[ "$has_task" -gt 0 ]] && ( [[ "$has_agent1" -gt 0 ]] || [[ "$has_agent2" -gt 0 ]] ); then
        local found=""
        [[ "$has_agent1" -gt 0 ]] && found="$found @$agent1"
        [[ "$has_agent2" -gt 0 ]] && found="$found @$agent2"
        echo "  PASS — $label — delegates to$found via task()"
        PASS_COUNT=$((PASS_COUNT + 1))
        return 0
    elif [[ "$has_task" -gt 0 ]]; then
        echo "  WARN — $label — has task() but missing both subagent_type: \"$agent1\" and \"$agent2\""
        FAIL_COUNT=$((FAIL_COUNT + 1))
        return 1
    else
        echo "  FAIL — $label — no task() delegation found"
        FAIL_COUNT=$((FAIL_COUNT + 1))
        return 1
    fi
}

check_dual_or_single() {
    local file="$1"
    local agent1="$2"
    local agent2="$3"
    local single="$4"
    local label="$5"
    TOTAL=$((TOTAL + 1))

    if [[ ! -f "$file" ]]; then
        echo "  FAIL — $label — file not found: $file"
        FAIL_COUNT=$((FAIL_COUNT + 1))
        return 1
    fi

    local has_task
    has_task=$(grep -c 'task(' "$file" || true)

    local has_agent1
    has_agent1=$(grep -c "subagent_type.*\"$agent1\"" "$file" || true)

    local has_agent2
    has_agent2=$(grep -c "subagent_type.*\"$agent2\"" "$file" || true)

    local has_single
    has_single=$(grep -c "subagent_type.*\"$single\"" "$file" || true)

    local dual_ok=false
    local single_ok=false

    if [[ "$has_task" -gt 0 ]] && [[ "$has_agent1" -gt 0 ]] && [[ "$has_agent2" -gt 0 ]]; then
        dual_ok=true
    fi
    if [[ "$has_task" -gt 0 ]] && [[ "$has_single" -gt 0 ]]; then
        single_ok=true
    fi

    if $dual_ok && $single_ok; then
        echo "  PASS — $label — delegates to @$agent1/@$agent2 (full) and @$single (slim) via task()"
        PASS_COUNT=$((PASS_COUNT + 1))
        return 0
    elif $dual_ok; then
        echo "  PASS — $label — delegates to @$agent1/@$agent2 (full mode)"
        PASS_COUNT=$((PASS_COUNT + 1))
        return 0
    elif $single_ok; then
        echo "  PASS — $label — delegates to @$single (slim mode)"
        PASS_COUNT=$((PASS_COUNT + 1))
        return 0
    elif [[ "$has_task" -gt 0 ]]; then
        echo "  WARN — $label — has task() but missing expected agent types (need @$agent1/@$agent2 for full, or @$single for slim)"
        FAIL_COUNT=$((FAIL_COUNT + 1))
        return 1
    else
        echo "  FAIL — $label — no task() delegation found"
        FAIL_COUNT=$((FAIL_COUNT + 1))
        return 1
    fi
}

echo "=== myWorkFlow Routing Validation ==="
echo ""

check_either       "${COMMANDS_DIR}/plan.md"     "planner"       "plan"          "commands/plan.md"
check_dual_or_single "${COMMANDS_DIR}/execute.md"  "executor-low"  "executor-high" "general"       "commands/execute.md"
check_either       "${COMMANDS_DIR}/accept.md"   "verifier"      "general"       "commands/accept.md"

# Model prefix validation: agent .md files must have provider-qualified model IDs
echo ""
echo "--- Agent model prefix validation ---"
for agent in planner executor-low executor-high verifier explorer tester debugger writer researcher; do
    agent_file="${AGENTS_DIR}/${agent}.md"
    TOTAL=$((TOTAL + 1))
    if [[ ! -f "$agent_file" ]]; then
        echo "  FAIL — agents/$agent.md — file not found"
        FAIL_COUNT=$((FAIL_COUNT + 1))
        continue
    fi
    model=$(grep '^model:' "$agent_file" | head -1 | sed 's/^model: *//')
    if [[ -z "$model" ]]; then
        echo "  WARN — agents/$agent.md — missing model field in frontmatter"
        FAIL_COUNT=$((FAIL_COUNT + 1))
    elif [[ "$model" == */* ]]; then
        echo "  PASS — agents/$agent.md — model has provider prefix: $model"
        PASS_COUNT=$((PASS_COUNT + 1))
    else
        echo "  FAIL — agents/$agent.md — model missing provider prefix: $model (expected: <provider>/$model)"
        FAIL_COUNT=$((FAIL_COUNT + 1))
    fi
done

echo ""
echo "=== Summary ==="
echo "Pass: $PASS_COUNT  Fail: $FAIL_COUNT  Total: $TOTAL"

if [[ "$FAIL_COUNT" -gt 0 ]]; then
    echo "RESULT: FAIL — $FAIL_COUNT command(s) missing proper subagent delegation"
    exit 1
else
    echo "RESULT: PASS — all commands have valid subagent delegation"
    exit 0
fi
