#!/usr/bin/env bash
set -euo pipefail

usage() {
    echo "Usage: $0 [--sync] [--sync-all] [--json] [--fallback <model>] <agent-name>"
    echo ""
    echo "  agent-name      One of: planner, executor-low, executor-high, verifier, explorer, tester, debugger, writer, researcher"
    echo "  --sync          Write config.json model/temp into agent .md frontmatter"
    echo "  --sync-all      Sync all agents at once"
    echo "  --json          Output as JSON instead of key=value"
    echo "  --fallback <m>  Return the specified fallback model instead of config.json value"
    echo ""
    echo "Examples:"
    echo "  $0 planner"
    echo "  $0 --json executor-low"
    echo "  $0 --sync planner"
    echo "  $0 --fallback ds/deepseek-v4-pro verifier"
    exit 1
}

WORKFLOW_DIR=".workflow"
CONFIG_FILE="${WORKFLOW_DIR}/config.json"
AGENTS_DIR=".opencode/agents"

SYNC_MODE=false
SYNC_ALL=false
JSON_MODE=false
FALLBACK_MODE=false
FALLBACK_MODEL=""
AGENT_NAME=""


while [[ $# -gt 0 ]]; do
    case "$1" in
        --sync)            SYNC_MODE=true; shift ;;
        --sync-all)        SYNC_ALL=true; shift ;;
        --json)            JSON_MODE=true; shift ;;
        --fallback)        FALLBACK_MODE=true; FALLBACK_MODEL="$2"; shift 2 ;;
        --help)            usage ;;
        -*)                echo "ERROR: Unknown flag: $1"; usage ;;
        *)                 AGENT_NAME="$1"; shift ;;
    esac
done

if $SYNC_ALL; then
    for agent in planner executor-low executor-high verifier explorer tester debugger writer researcher; do
        echo "=== $agent ==="
        "$0" --sync "$agent" || true
    done
    exit 0
fi

if [[ -z "$AGENT_NAME" ]]; then
    echo "ERROR: No agent name specified." >&2
    usage
fi

if $FALLBACK_MODE && [[ -z "$FALLBACK_MODEL" ]]; then
    echo "ERROR: --fallback requires a model argument" >&2
    usage
fi


qualify_model() {
    local raw_model="$1"

    if [[ "$raw_model" == */* ]]; then
        echo "$raw_model"
        return
    fi

    local provider
    provider=$(grep '"provider"' "$CONFIG_FILE" | head -1 | sed 's/.*"provider"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/')

    if [[ -z "$provider" ]]; then
        echo "ERROR: No 'provider' field found in $CONFIG_FILE — cannot qualify model IDs." >&2
        exit 1
    fi

    echo "${provider}/${raw_model}"
}

validate_json() {
    local file="$1"
    if [[ ! -f "$file" ]]; then
        echo "ERROR: Config file not found at $file" >&2
        return 1
    fi
    local content
    content=$(cat "$file" | tr -d '[:space:]')
    if [[ ! "$content" =~ ^\{.*\}$ ]]; then
        echo "ERROR: $file does not appear to be valid JSON (must start with '{' and end with '}')" >&2
        return 1
    fi
    if [[ ! "$content" =~ \"agents\" ]]; then
        echo "ERROR: $file is missing required 'agents' section" >&2
        return 1
    fi
    if [[ ! "$content" =~ \"model\" ]]; then
        echo "ERROR: $file is missing expected 'model' entries in agents section" >&2
        return 1
    fi
    return 0
}

resolve_agent() {
    local name="$1"

    local match
    match=$(grep "\"$name\"" "$CONFIG_FILE" 2>/dev/null)

    if [[ -z "$match" ]]; then
        echo "ERROR: Agent '$name' not found in $CONFIG_FILE" >&2
        exit 1
    fi

    local model
    model=$(grep -A4 "\"$name\"" "$CONFIG_FILE" | grep '"model"' | head -1 | sed 's/.*"model"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/')

    local temperature
    temperature=$(grep -A4 "\"$name\"" "$CONFIG_FILE" | grep '"temperature"' | head -1 | sed 's/.*"temperature"[[:space:]]*:[[:space:]]*\([0-9.]*\).*/\1/')

    if [[ -z "$model" ]]; then
        echo "ERROR: No model found for agent '$name' in $CONFIG_FILE" >&2
        exit 1
    fi

    local qualified
    qualified=$(qualify_model "$model")
    if [[ -z "$qualified" ]]; then
        exit 1
    fi

    echo "model=$qualified temperature=$temperature"
}

_sync_one_file() {
    local agent_file="$1"
    local model="$2"
    local temp="$3"

    local tmpfile="${agent_file}.tmp"

    if grep -q '^model:' "$agent_file"; then
        sed "s|^model:.*|model: $model|" "$agent_file" > "$tmpfile"
    else
        awk -v m="$model" '{print} /^---$/{found++; if(found==2){print "model: " m}}' "$agent_file" > "$tmpfile"
    fi

    if grep -q '^temperature:' "$tmpfile"; then
        cp "$tmpfile" "${tmpfile}.bak"
        sed "s|^temperature:.*|temperature: $temp|" "${tmpfile}.bak" > "$tmpfile"
        rm -f "${tmpfile}.bak"
    else
        awk -v t="$temp" '{print} /^model:/{print "temperature: " t}' "$tmpfile" > "${tmpfile}.2"
        mv "${tmpfile}.2" "$tmpfile"
    fi

    mv "$tmpfile" "$agent_file"
    echo "Synced $agent_file: model=$model temperature=$temp"
}

sync_frontmatter() {
    local name="$1"

    local model temp
    model=$(echo "$RESOLVED" | sed 's/.*model=\([^ ]*\).*/\1/')
    temp=$(echo "$RESOLVED" | sed 's/.*temperature=\([^ ]*\).*/\1/')

    if [[ -z "$model" ]]; then
        echo "ERROR: Cannot resolve model for sync" >&2
        exit 1
    fi

    local found=false
    for candidate in "${AGENTS_DIR}/${name}.md" "agents/${name}.md"; do
        if [[ -f "$candidate" ]]; then
            _sync_one_file "$candidate" "$model" "$temp"
            found=true
        fi
    done

    if ! $found; then
        echo "ERROR: Agent file not found for '$name' (checked ${AGENTS_DIR}/ and agents/)" >&2
        exit 1
    fi
}

validate_json "$CONFIG_FILE" || exit 1

if $FALLBACK_MODE; then
    qualified=$(qualify_model "$FALLBACK_MODEL")
    if [[ -z "$qualified" ]]; then
        exit 1
    fi
    echo "model=$qualified temperature=0.0"
    exit 0
fi

RESOLVED=$(resolve_agent "$AGENT_NAME")
if [[ -z "$RESOLVED" ]]; then
    exit 1
fi

if $SYNC_MODE; then
    sync_frontmatter "$AGENT_NAME"
else
    if $JSON_MODE; then
        _model=$(echo "$RESOLVED" | sed 's/.*model=\([^ ]*\).*/\1/')
        _temp=$(echo "$RESOLVED" | sed 's/.*temperature=\([^ ]*\).*/\1/')
        echo "{\"agent\":\"$AGENT_NAME\",\"model\":\"$_model\",\"temperature\":$_temp}"
    else
        echo "$RESOLVED"
    fi
fi
