#!/usr/bin/env bash
set -euo pipefail

# research-gate.sh — Research-first gate for plan phase
# Reads REQUIREMENTS.md and decides whether domain/technology research
# is needed before delegating to the planner subagent.
#
# Usage:
#   ./research-gate.sh --workflow-id <id>
#   ./research-gate.sh workflow-id=<id>
#   ./research-gate.sh <workflow-id>
#   ./research-gate.sh --help
#
# Output on stdout: RESEARCH_NEEDED or SKIP
# When SKIP: logs the skip decision to .workflow/<workflow-id>/ADL.md
# When RESEARCH_NEEDED: brief reason written to stderr

# ------------------------------------------------------------------
# usage — print help
# ------------------------------------------------------------------
usage() {
    cat <<'EOF'
Usage: research-gate.sh --workflow-id <id>
       research-gate.sh workflow-id=<id>
       research-gate.sh <workflow-id>

Evaluate whether a /plan phase requires research before delegating to the planner.

Arguments:
  workflow-id   Identifier of the workflow to evaluate (required, positional)

Flags:
  --help        Show this help message and exit

Output (stdout):
  RESEARCH_NEEDED    Requirements indicate unknowns requiring research
  SKIP               Requirements are trivial — no research needed

SKIP triggers when ALL of the following are true:
  - ≤2 files estimated affected (few file-path references in requirements)
  - No new library/pattern indicators (no mention of unfamiliar libraries,
    new frameworks, new patterns, unknown APIs)
  - Requirement bullet count under ## Must-Haves is ≤10

When SKIP, the decision is logged as a Decision Log entry to
.workflow/<workflow-id>/ADL.md.

When RESEARCH_NEEDED, a brief human-readable reason is written to stderr.

Exit codes:
  0 — normal (RESEARCH_NEEDED or SKIP decided normally)
  1 — error (invalid arguments, missing files, etc.)
EOF
    exit 0
}

# ------------------------------------------------------------------
# Parse arguments
# ------------------------------------------------------------------
WORKFLOW_ID=""

if [[ $# -eq 0 ]]; then
    echo "ERROR: workflow-id is required" >&2
    usage
fi

while [[ $# -gt 0 ]]; do
    case "$1" in
        --help) usage ;;
        --workflow-id)
            WORKFLOW_ID="$2"; shift 2 ;;
        --*)
            echo "ERROR: Unknown flag: $1" >&2
            usage ;;
        *=*)
            key="${1%%=*}"
            val="${1#*=}"
            case "$key" in
                workflow-id)
                    WORKFLOW_ID="$val" ;;
                *)
                    echo "ERROR: Unknown key: '$key'" >&2
                    usage ;;
            esac
            shift ;;
        *)
            # Positional argument: workflow-id
            if [[ -z "$WORKFLOW_ID" ]]; then
                WORKFLOW_ID="$1"
            else
                echo "ERROR: Unexpected extra argument: '$1' (workflow-id already set to '$WORKFLOW_ID')" >&2
                usage
            fi
            shift ;;
    esac
done

# ------------------------------------------------------------------
# Validation
# ------------------------------------------------------------------
if [[ -z "$WORKFLOW_ID" ]]; then
    echo "ERROR: 'workflow-id' is required." >&2
    usage
fi

REQ_DIR=".workflow/${WORKFLOW_ID}"
REQ_FILE="${REQ_DIR}/REQUIREMENTS.md"

if [[ ! -d "$REQ_DIR" ]]; then
    echo "ERROR: Workflow directory not found: $REQ_DIR" >&2
    exit 1
fi

if [[ ! -f "$REQ_FILE" ]]; then
    echo "ERROR: REQUIREMENTS.md not found in $REQ_DIR" >&2
    exit 1
fi

# ------------------------------------------------------------------
# Load REQUIREMENTS.md content
# ------------------------------------------------------------------
REQ_CONTENT=$(cat "$REQ_FILE")

# ------------------------------------------------------------------
# Indicator 1: File count — count distinct file-path references
# ------------------------------------------------------------------
# Look for patterns that look like file paths: backtick-wrapped paths,
# paths with slashes, or explicit "X files" phrasing.
file_paths=""
# Collect unique file-like tokens (backtick-wrapped, e.g. `scripts/foo.sh`)
while IFS= read -r line; do
    # Extract backtick-enclosed tokens
    while [[ "$line" =~ \`([^\`]+)\` ]]; do
        token="${BASH_REMATCH[1]}"
        # Only count tokens that look like file paths (contain / or a dot extension)
        if [[ "$token" == */* ]] || [[ "$token" == *.* ]]; then
            file_paths="${file_paths}${token}"$'\n'
        fi
        # Remove the matched token from line to find more
        line="${line#*\`}"
        line="${line#*\`}"
    done
done <<< "$REQ_CONTENT"

# Also check for explicit "X files" phrasing (e.g., "2 files", "3 files")
files_phrase_count=0
explicit_count=0
if echo "$REQ_CONTENT" | grep -qi '[0-9][0-9]*\s*files.*affected'; then
    explicit_count=$(echo "$REQ_CONTENT" | grep -oi '[0-9][0-9]*\s*files.*affected' | grep -o '[0-9][0-9]*' | head -1)
fi
if echo "$REQ_CONTENT" | grep -qi 'files.*estimated'; then
    explicit_count=$(echo "$REQ_CONTENT" | grep -oi '[0-9][0-9]*\s*files.*estimated' | grep -o '[0-9][0-9]*' | head -1)
fi
# Also check for phrases like "≤N files" or "N files"
if echo "$REQ_CONTENT" | grep -qiP '\(?\s*[≤<]\s*[0-9]+\s*files'; then
    explicit_count=$(echo "$REQ_CONTENT" | grep -oiP '\(?\s*[≤<]\s*[0-9]+\s*files' | grep -o '[0-9][0-9]*' | head -1)
fi

# Count distinct file paths
distinct_files=$(echo "$file_paths" | sort -u | grep -c '.' 2>/dev/null || true)

# Use the higher of explicit count or distinct files count
if [[ -n "$explicit_count" ]] && [[ "$explicit_count" -gt "$distinct_files" ]]; then
    estimated_file_count="$explicit_count"
else
    estimated_file_count="$distinct_files"
fi

# ------------------------------------------------------------------
# Indicator 2: New library/pattern keywords
# ------------------------------------------------------------------
# Search for keywords indicating unfamiliar technology, new libraries,
# unknown domains, API explorations, or new patterns.
new_lib_indicators=0
NEW_LIB_PATTERNS=(
    'unfamiliar'
    'new library'
    'new libraries'
    'new framework'
    'new frameworks'
    'new pattern'
    'new patterns'
    'new SDK'
    'new plugin'
    'unknown API'
    'API surface'
    'new domain'
    'new technology'
    'external dependency'
    'new tool'
    'third-party'
    'explore'
    'investigate'
    'unknowns'
    'learning curve'
)

for pattern in "${NEW_LIB_PATTERNS[@]}"; do
    if echo "$REQ_CONTENT" | grep -qi "$pattern"; then
        new_lib_indicators=$((new_lib_indicators + 1))
    fi
done

# ------------------------------------------------------------------
# Indicator 3: Requirement bullet count under ## Must-Haves
# ------------------------------------------------------------------
# Extract the section between "## Must-Haves" and the next "## " header
must_have_section=$(echo "$REQ_CONTENT" | sed -n '/^## Must-Haves/,/^## /p' | sed '$d')
if [[ -z "$must_have_section" ]]; then
    # Try without the closing `## ` header (end of file)
    must_have_section=$(echo "$REQ_CONTENT" | sed -n '/^## Must-Haves/,$p')
fi

# Count all lines starting with "- " (bullet lines)
bullet_count=$(echo "$must_have_section" | grep -c '^- ' 2>/dev/null || echo 0)

# ------------------------------------------------------------------
# Gather reasons for the decision
# ------------------------------------------------------------------
skip_reasons=()
research_reasons=()

files_pass=false
libs_pass=false
bullets_pass=false

# File count check: SKIP if ≤2
if [[ "$estimated_file_count" -le 2 ]]; then
    files_pass=true
else
    research_reasons+=("estimated ${estimated_file_count} files affected (threshold: ≤2)")
fi

# New library check: SKIP if NONE
if [[ "$new_lib_indicators" -eq 0 ]]; then
    libs_pass=true
else
    matching=()
    for pattern in "${NEW_LIB_PATTERNS[@]}"; do
        if echo "$REQ_CONTENT" | grep -qi "$pattern"; then
            matching+=("$pattern")
        fi
    done
    research_reasons+=("new library/pattern indicators found (${new_lib_indicators} matches): ${matching[*]}")
fi

# Bullet count check: SKIP if ≤10
if [[ "$bullet_count" -le 10 ]]; then
    bullets_pass=true
else
    research_reasons+=("${bullet_count} requirement bullets found (threshold: ≤10)")
fi

# ------------------------------------------------------------------
# Decision
# ------------------------------------------------------------------
if $files_pass && $libs_pass && $bullets_pass; then
    # ── SKIP ──────────────────────────────────────────────
    # Build skip reasons for ADL
    sf="files=≤2 (${estimated_file_count})"
    sl="new_libs=none (0 indicators)"
    sb="bullets=≤10 (${bullet_count})"
    skip_summary="Trivial workflow — all SKIP conditions met: ${sf}, ${sl}, ${sb}"

    # Log SKIP to ADL.md
    ADL_FILE="${REQ_DIR}/ADL.md"
    timestamp=$(date -u +"%Y-%m-%d %H:%M:%S UTC")

    # Create ADL.md if it doesn't exist (based on template)
    if [[ ! -f "$ADL_FILE" ]]; then
        cat > "$ADL_FILE" <<ADLHEADER
# ADL: ${WORKFLOW_ID}

**Created**: $(date +"%Y-%m-%d")

## Decision Log

| Timestamp | Phase | Rule/Trigger | Description | Action Taken | Result |
|-----------|-------|--------------|-------------|--------------|--------|

## Deviation Log

| Timestamp | Rule | Issue | Action | Files |
|-----------|------|-------|--------|-------|

ADLHEADER
    fi

    # Append the decision log entry
    escaped_desc=$(echo "$skip_summary" | sed 's/|/\\|/g')
    cat >> "$ADL_FILE" <<ADLENTRY
| ${timestamp} | Plan | Research Gate (MH5) | ${escaped_desc} | Skipped research gate — proceeding directly to planner | SKIP (trivial) |
ADLENTRY

    echo "SKIP"
    exit 0
else
    # ── RESEARCH_NEEDED ───────────────────────────────────
    reason=""
    for r in "${research_reasons[@]}"; do
        reason="${reason} - ${r}
"
    done

    # Summary line plus detailed reasons
    {
        echo "RESEARCH_NEEDED"
        echo "Research gate triggered for workflow '${WORKFLOW_ID}':"
        echo -n "$reason"
    } >&2

    exit 0
fi
