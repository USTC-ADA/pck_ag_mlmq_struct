#!/usr/bin/env bash
set -euo pipefail

# create-wave-pr.sh — Create a PR for a completed wave
# Accepts wave number, workflow-id, and optional branch prefix.
# Runs `gh pr create` with wave tasks in the body.
# Falls back to manual instructions if `gh` is unavailable.
#
# Usage:
#   ./create-wave-pr.sh [--branch-prefix <prefix>] [--description <text>] <wave-number> <workflow-id>
#   ./create-wave-pr.sh --help
#   ./create-wave-pr.sh --dry-run [--branch-prefix <prefix>] <wave-number> <workflow-id>

# ------------------------------------------------------------------
# usage — print help
# ------------------------------------------------------------------
usage() {
    cat <<'EOF'
Usage: create-wave-pr.sh [--help] [--dry-run] [--branch-prefix <prefix>] [--description <text>]
                         <wave-number> <workflow-id>

Create a GitHub PR for a completed wave of work.

Arguments:
  wave-number     Wave number (e.g., 1, 2, 3) (required)
  workflow-id     Identifier of the current workflow (required)

Flags:
  --help            Show this help message and exit
  --dry-run         Print what would be done without executing
  --branch-prefix   Branch prefix for the PR head branch (default: "wave")
  --description     Additional description text to include in the PR body

If the `gh` CLI is not available or not authenticated, the script prints
clear manual instructions for creating the PR and exits 0.

Exit code: 0 on success (including fallback to manual), 1 on error.
EOF
    exit 0
}

# ------------------------------------------------------------------
# detect_gh — check if gh CLI is available and authenticated
# ------------------------------------------------------------------
detect_gh() {
    if ! command -v gh &>/dev/null; then
        echo "WARNING: GitHub CLI (gh) is not installed." >&2
        return 1
    fi
    if ! gh auth status &>/dev/null; then
        echo "WARNING: GitHub CLI (gh) is installed but not authenticated." >&2
        echo "  Run 'gh auth login' to authenticate." >&2
        return 1
    fi
    return 0
}

# ------------------------------------------------------------------
# Parse arguments
# ------------------------------------------------------------------
DRY_RUN=false
BRANCH_PREFIX="wave"
DESCRIPTION=""
WAVE_NUMBER=""
WORKFLOW_ID=""

while [[ $# -gt 0 ]]; do
    case "$1" in
        --help) usage ;;
        --dry-run)
            DRY_RUN=true
            shift ;;
        --branch-prefix)
            BRANCH_PREFIX="$2"
            shift 2 ;;
        --description)
            DESCRIPTION="$2"
            shift 2 ;;
        --*)
            echo "ERROR: Unknown flag: $1" >&2
            usage ;;
        -[0-9]*)
            # Negative numbers: reject early with a clear message
            echo "ERROR: 'wave-number' must be a positive integer (got: '$1')." >&2
            exit 1 ;;
        -*)
            echo "ERROR: Unknown flag: $1" >&2
            usage ;;
        *)
            if [[ -z "$WAVE_NUMBER" ]]; then
                WAVE_NUMBER="$1"
            elif [[ -z "$WORKFLOW_ID" ]]; then
                WORKFLOW_ID="$1"
            else
                echo "ERROR: Unexpected extra argument: '$1'" >&2
                usage
            fi
            shift ;;
    esac
done

# ------------------------------------------------------------------
# Validation
# ------------------------------------------------------------------
if [[ -z "$WAVE_NUMBER" ]]; then
    echo "ERROR: 'wave-number' is required." >&2
    usage
fi
if [[ -z "$WORKFLOW_ID" ]]; then
    echo "ERROR: 'workflow-id' is required." >&2
    usage
fi

# Validate wave-number is a positive integer
if ! [[ "$WAVE_NUMBER" =~ ^[1-9][0-9]*$ ]]; then
    echo "ERROR: 'wave-number' must be a positive integer (got: '$WAVE_NUMBER')." >&2
    exit 1
fi

# ------------------------------------------------------------------
# Build PR metadata
# ------------------------------------------------------------------
PR_TITLE="Wave ${WAVE_NUMBER}: ${WORKFLOW_ID}"
HEAD_BRANCH="${BRANCH_PREFIX}/wave-${WAVE_NUMBER}-${WORKFLOW_ID}"

# Build PR body
PR_BODY=$(cat <<BODY
## Wave ${WAVE_NUMBER}: ${WORKFLOW_ID}

This PR contains all changes for wave ${WAVE_NUMBER} of workflow \`${WORKFLOW_ID}\`.

### Summary

- **Workflow**: ${WORKFLOW_ID}
- **Wave**: ${WAVE_NUMBER}
- **Branch**: ${HEAD_BRANCH}
BODY
)

if [[ -n "$DESCRIPTION" ]]; then
    PR_BODY="${PR_BODY}

### Description

${DESCRIPTION}"
fi

PR_BODY="${PR_BODY}

### Tasks

See \`.workflow/${WORKFLOW_ID}/BLUEPRINT.md\` for the full task list for this wave.
"

# ------------------------------------------------------------------
# Dry-run mode
# ------------------------------------------------------------------
if $DRY_RUN; then
    echo "=== DRY RUN ==="
    echo "Would create PR with:"
    echo "  Title:      $PR_TITLE"
    echo "  Head:       $HEAD_BRANCH"
    echo "  Base:       main"
    echo ""
    echo "Body preview:"
    echo "---"
    echo "$PR_BODY"
    echo "---"
    if detect_gh; then
        echo ""
        echo "Command that would be executed:"
        echo "  gh pr create --title \"$PR_TITLE\" --body <see above> --head \"$HEAD_BRANCH\" --base main"
    else
        echo ""
        echo "gh is not available — manual instructions would be printed."
    fi
    exit 0
fi

# ------------------------------------------------------------------
# Check gh availability
# ------------------------------------------------------------------
if ! detect_gh; then
    echo ""
    echo "=========================================================="
    echo "  MANUAL PR CREATION INSTRUCTIONS"
    echo "=========================================================="
    echo ""
    echo "The GitHub CLI is not available. To create this PR manually:"
    echo ""
    echo "  1. Push your branch to GitHub:"
    echo "     git push origin ${HEAD_BRANCH}"
    echo ""
    echo "  2. Open GitHub and create a new Pull Request:"
    echo "     Title: ${PR_TITLE}"
    echo "     Head branch: ${HEAD_BRANCH}"
    echo "     Base branch: main"
    echo ""
    echo "  3. Use the following body:"
    echo ""
    echo "----- COPY BELOW THIS LINE -----"
    echo "$PR_BODY"
    echo "----- COPY ABOVE THIS LINE -----"
    echo ""
    echo "=========================================================="
    exit 0
fi

# ------------------------------------------------------------------
# Create the PR via gh
# ------------------------------------------------------------------
echo "Creating PR: ${PR_TITLE} ..."
echo "  Head branch: ${HEAD_BRANCH}"
echo "  Base branch: main"
echo ""

# Write body to a temp file to avoid shell escaping issues
tmp_body=$(mktemp /tmp/create-wave-pr-body.XXXXXX)
echo "$PR_BODY" > "$tmp_body"

# Create the PR
pr_url=$(gh pr create \
    --title "$PR_TITLE" \
    --body-file "$tmp_body" \
    --head "$HEAD_BRANCH" \
    --base main \
    2>&1) || {
    rc=$?
    rm -f "$tmp_body"
    echo "ERROR: gh pr create failed (exit code $rc):" >&2
    echo "$pr_url" >&2
    exit 1
}

rm -f "$tmp_body"
echo ""
echo "PR created successfully:"
echo "  $pr_url"
echo ""
echo "Done."
exit 0
