#!/usr/bin/env bash
set -euo pipefail

MODE_FILE=".workflow/config.json"

if [[ ! -f "$MODE_FILE" ]]; then
    echo "ERROR: Config file not found at $MODE_FILE" >&2
    exit 1
fi

CURRENT=$(grep '"mode"' "$MODE_FILE" 2>/dev/null | head -1 | sed 's/.*"mode"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/' || true)
CURRENT="${CURRENT:-}"

if [[ "$CURRENT" == "slim" ]]; then
    NEW="full"
elif [[ "$CURRENT" == "full" ]]; then
    NEW="slim"
else
    echo "No mode field found — adding mode: slim" >&2
    sed -i '1a\  "mode": "slim",' "$MODE_FILE"
    echo "Switched to slim mode."
    exit 0
fi

sed -i "s|\"mode\": \"$CURRENT\"|\"mode\": \"$NEW\"|" "$MODE_FILE"
echo "Switched from $CURRENT to $NEW mode."
