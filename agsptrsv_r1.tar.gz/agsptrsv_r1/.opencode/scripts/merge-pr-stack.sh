#!/usr/bin/env bash
set -euo pipefail

# merge-pr-stack.sh — Merge PRs for a workflow stack
# Lists open PRs for a workflow-id via `gh pr list`.
# Merges them newest-first (highest wave number first) via `gh pr merge --squash`.
# Falls back to manual instructions if `gh` is unavailable.
# Idempotent: already-merged PRs are not in the open list and will be skipped.
#
# Usage:
#   ./merge-pr-stack.sh [--help] [--dry-run] <workflow-id>
#   ./merge-pr-stack.sh --help

# ------------------------------------------------------------------
# usage — print help
# ------------------------------------------------------------------
usage() {
    cat <<'EOF'
Usage: merge-pr-stack.sh [--help] [--dry-run] <workflow-id>

Merge all open PRs for a workflow stack.

Arguments:
  workflow-id     Identifier of the workflow whose PRs to merge (required)

Flags:
  --help          Show this help message and exit
  --dry-run       Print what would be merged without executing

The script lists open PRs matching the workflow-id via `gh pr list`,
sorts them in descending wave order (newest/highest wave first),
and merges each via `gh pr merge --squash --delete-branch`.

If the `gh` CLI is not available or not authenticated, the script prints
clear manual instructions with the merge order and commands and exits 0.

Idempotent: PRs that have already been merged will not appear in the
open PR list and are silently skipped.

Exit code: 0 on success (including fallback to manual), 1 on error.
EOF
    exit 0
}

# ------------------------------------------------------------------
# detect_gh — check if gh CLI is available and authenticated
# ------------------------------------------------------------------
detect_gh() {
    if ! command -v gh &>/dev/null; then
        echo "WARNING: GitHub CLI (gh) is not installed." >&2
        return 1
    fi
    if ! gh auth status &>/dev/null; then
        echo "WARNING: GitHub CLI (gh) is installed but not authenticated." >&2
        echo "  Run 'gh auth login' to authenticate." >&2
        return 1
    fi
    return 0
}

# ------------------------------------------------------------------
# extract_wave_number — parse wave number from PR title
# Expected format: "Wave N: <workflow-id>" or similar
# Returns the wave number as an integer, or 0 if unparseable.
# ------------------------------------------------------------------
extract_wave_number() {
    local title="$1"
    # Extract the first number found in the PR title
    local wave
    wave=$(echo "$title" | grep -oP 'Wave\s+\K\d+' | head -1)
    if [[ -z "$wave" ]]; then
        # Fallback: try to extract any number from the title
        wave=$(echo "$title" | grep -oP '\d+' | head -1)
    fi
    echo "${wave:-0}"
}

# ------------------------------------------------------------------
# Parse arguments
# ------------------------------------------------------------------
DRY_RUN=false
WORKFLOW_ID=""

while [[ $# -gt 0 ]]; do
    case "$1" in
        --help) usage ;;
        --dry-run)
            DRY_RUN=true
            shift ;;
        --*)
            echo "ERROR: Unknown flag: $1" >&2
            usage ;;
        -[0-9]*)
            echo "ERROR: 'workflow-id' cannot be a negative number (got: '$1')." >&2
            usage ;;
        -*)
            echo "ERROR: Unknown flag: $1" >&2
            usage ;;
        *)
            if [[ -z "$WORKFLOW_ID" ]]; then
                WORKFLOW_ID="$1"
            else
                echo "ERROR: Unexpected extra argument: '$1'" >&2
                usage
            fi
            shift ;;
    esac
done

# ------------------------------------------------------------------
# Validation
# ------------------------------------------------------------------
if [[ -z "$WORKFLOW_ID" ]]; then
    echo "ERROR: 'workflow-id' is required." >&2
    usage
fi

# ------------------------------------------------------------------
# Check gh availability
# ------------------------------------------------------------------
GH_AVAILABLE=false
if detect_gh; then
    GH_AVAILABLE=true
fi

# ------------------------------------------------------------------
# Dry-run mode
# ------------------------------------------------------------------
if $DRY_RUN; then
    echo "=== DRY RUN ==="
    echo "Would list and merge PRs for workflow: ${WORKFLOW_ID}"
    echo ""

    if $GH_AVAILABLE; then
        echo "Fetching open PRs..."

        # Get open PRs as JSON
        pr_json=$(gh pr list \
            --search "${WORKFLOW_ID} in:title" \
            --state open \
            --json number,title,headRefName,url \
            --limit 50 \
            2>/dev/null || echo "[]")

        # Parse and sort
        pr_count=$(echo "$pr_json" | grep -c '"number"' || echo "0")

        if [[ "$pr_count" -eq 0 ]]; then
            echo "No open PRs found matching workflow '${WORKFLOW_ID}'."
            echo "Nothing to merge."
            exit 0
        fi

        echo "Would merge the following PRs (newest wave first):"
        echo ""

        # Extract PRs into an array, sort by wave number descending
        declare -a pr_entries
        declare -a pr_waves
        declare -a pr_numbers
        declare -a pr_titles

        while IFS= read -r line; do
            # Each line contains a PR number, but we need wave numbers
            # Use jq-style parsing from the JSON
            :
        done <<< "$pr_json"

        # Use a simpler approach: parse with grep/sed
        # Build arrays
        i=0
        while read -r number; do
            if [[ -z "$number" ]]; then continue; fi
            pr_numbers[$i]="$number"
            i=$((i + 1))
        done < <(echo "$pr_json" | grep -o '"number":[0-9]*' | grep -o '[0-9]*')

        i=0
        while read -r title; do
            if [[ -z "$title" ]]; then continue; fi
            pr_titles[$i]="$title"
            pr_waves[$i]=$(extract_wave_number "$title")
            i=$((i + 1))
        done < <(echo "$pr_json" | grep -o '"title":"[^"]*"' | sed 's/"title":"//;s/"$//')

        i=0
        while read -r url; do
            if [[ -z "$url" ]]; then continue; fi
            pr_urls[$i]="$url"
            i=$((i + 1))
        done < <(echo "$pr_json" | grep -o '"url":"[^"]*"' | sed 's/"url":"//;s/"$//')

        # Sort by wave number descending
        # Use a bubble sort on indices
        count=${#pr_numbers[@]}
        for ((i = 0; i < count; i++)); do
            for ((j = i + 1; j < count; j++)); do
                if [[ "${pr_waves[$i]}" -lt "${pr_waves[$j]}" ]]; then
                    # Swap
                    tmp_num="${pr_numbers[$i]}"
                    pr_numbers[$i]="${pr_numbers[$j]}"
                    pr_numbers[$j]="$tmp_num"
                    tmp_title="${pr_titles[$i]}"
                    pr_titles[$i]="${pr_titles[$j]}"
                    pr_titles[$j]="$tmp_title"
                    tmp_wave="${pr_waves[$i]}"
                    pr_waves[$i]="${pr_waves[$j]}"
                    pr_waves[$j]="$tmp_wave"
                fi
            done
        done

        for ((i = 0; i < count; i++)); do
            echo "  #${pr_numbers[$i]} — ${pr_titles[$i]}"
            echo "     Merge command: gh pr merge ${pr_numbers[$i]} --squash --delete-branch"
            echo ""
        done
    else
        echo "gh is not available — manual instructions would be printed."
        echo ""
        echo "  1. Go to your GitHub repository"
        echo "  2. Find open PRs with '${WORKFLOW_ID}' in the title"
        echo "  3. Merge them in descending wave order (highest wave number first)"
        echo "  4. Use 'Squash and merge' for each PR"
    fi
    exit 0
fi

# ------------------------------------------------------------------
# gh unavailable — print manual instructions
# ------------------------------------------------------------------
if ! $GH_AVAILABLE; then
    echo ""
    echo "=========================================================="
    echo "  MANUAL PR MERGE INSTRUCTIONS"
    echo "=========================================================="
    echo ""
    echo "The GitHub CLI is not available. To merge PRs for workflow"
    echo "'${WORKFLOW_ID}' manually:"
    echo ""
    echo "  1. Go to your GitHub repository's Pull Requests page"
    echo ""
    echo "  2. Filter PRs by searching for: ${WORKFLOW_ID}"
    echo ""
    echo "  3. Merge ALL open PRs for this workflow in the following order:"
    echo "     IMPORTANT: Merge the HIGHEST wave number FIRST, then"
    echo "     work downward. This prevents conflicts from cascading."
    echo ""
    echo "  4. For each PR:"
    echo "     - Click the PR to open it"
    echo "     - Select 'Squash and merge' from the merge dropdown"
    echo "     - Confirm the merge"
    echo "     - Delete the branch after merging"
    echo ""
    echo "  5. After all PRs are merged, run 'git pull' locally to sync."
    echo ""
    echo "=========================================================="
    exit 0
fi

# ------------------------------------------------------------------
# Fetch open PRs
# ------------------------------------------------------------------
echo "Fetching open PRs for workflow '${WORKFLOW_ID}'..."

pr_json=$(gh pr list \
    --search "${WORKFLOW_ID} in:title" \
    --state open \
    --json number,title,headRefName,url \
    --limit 50 \
    2>&1) || {
    rc=$?
    echo "ERROR: gh pr list failed (exit code $rc):" >&2
    echo "$pr_json" >&2
    exit 1
}

# Count PRs
pr_count=$(echo "$pr_json" | grep -c '"number"' || echo "0")

if [[ "$pr_count" -eq 0 ]]; then
    echo "No open PRs found matching workflow '${WORKFLOW_ID}'."
    echo "Nothing to merge."
    exit 0
fi

# ------------------------------------------------------------------
# Parse PR data into sorted arrays
# ------------------------------------------------------------------
declare -a pr_numbers
declare -a pr_titles
declare -a pr_waves
declare -a pr_urls

i=0
while read -r number; do
    if [[ -z "$number" ]]; then continue; fi
    pr_numbers[$i]="$number"
    i=$((i + 1))
done < <(echo "$pr_json" | grep -o '"number":[0-9]*' | grep -o '[0-9]*')

i=0
while read -r title; do
    if [[ -z "$title" ]]; then continue; fi
    pr_titles[$i]="$title"
    pr_waves[$i]=$(extract_wave_number "$title")
    i=$((i + 1))
done < <(echo "$pr_json" | grep -o '"title":"[^"]*"' | sed 's/"title":"//;s/"$//')

i=0
while read -r url; do
    if [[ -z "$url" ]]; then continue; fi
    pr_urls[$i]="$url"
    i=$((i + 1))
done < <(echo "$pr_json" | grep -o '"url":"[^"]*"' | sed 's/"url":"//;s/"$//')

# ------------------------------------------------------------------
# Sort by wave number descending (newest/highest wave first)
# ------------------------------------------------------------------
count=${#pr_numbers[@]}
for ((i = 0; i < count; i++)); do
    for ((j = i + 1; j < count; j++)); do
        if [[ "${pr_waves[$i]}" -lt "${pr_waves[$j]}" ]]; then
            # Swap numbers
            tmp="${pr_numbers[$i]}"
            pr_numbers[$i]="${pr_numbers[$j]}"
            pr_numbers[$j]="$tmp"
            # Swap titles
            tmp="${pr_titles[$i]}"
            pr_titles[$i]="${pr_titles[$j]}"
            pr_titles[$j]="$tmp"
            # Swap waves
            tmp="${pr_waves[$i]}"
            pr_waves[$i]="${pr_waves[$j]}"
            pr_waves[$j]="$tmp"
            # Swap urls
            tmp="${pr_urls[$i]}"
            pr_urls[$i]="${pr_urls[$j]}"
            pr_urls[$j]="$tmp"
        fi
    done
done

# ------------------------------------------------------------------
# Display merge plan and execute
# ------------------------------------------------------------------
echo ""
echo "Found ${count} open PR(s) for workflow '${WORKFLOW_ID}':"
for ((i = 0; i < count; i++)); do
    echo "  #${pr_numbers[$i]} — ${pr_titles[$i]} (wave ${pr_waves[$i]})"
done
echo ""
echo "Merging in newest-first order (highest wave → lowest wave)..."

merge_count=0
fail_count=0

for ((i = 0; i < count; i++)); do
    num="${pr_numbers[$i]}"
    title="${pr_titles[$i]}"
    wave="${pr_waves[$i]}"

    echo ""
    echo "--- Merging #${num} (wave ${wave}) ---"
    echo "  Title: ${title}"

    merge_output=$(gh pr merge "$num" --squash --delete-branch 2>&1) || {
        rc=$?
        echo "  FAILED (exit code $rc):" >&2
        echo "  $merge_output" >&2
        fail_count=$((fail_count + 1))
        continue
    }

    echo "  Result: ${merge_output}"
    merge_count=$((merge_count + 1))
done

# ------------------------------------------------------------------
# Report results
# ------------------------------------------------------------------
echo ""
echo "=========================================================="
echo "  MERGE SUMMARY"
echo "=========================================================="
echo "  Total PRs:  ${count}"
echo "  Merged:     ${merge_count}"
echo "  Failed:     ${fail_count}"
echo ""

if [[ "$fail_count" -gt 0 ]]; then
    echo "Some PRs failed to merge. Please review the errors above"
    echo "and merge them manually if needed."
    exit 1
else
    echo "All PRs merged successfully."
    exit 0
fi
