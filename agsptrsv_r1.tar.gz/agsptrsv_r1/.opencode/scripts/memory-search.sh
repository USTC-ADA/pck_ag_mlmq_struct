#!/usr/bin/env bash
set -euo pipefail

# memory-search.sh — Search memory entries by concept partial-match
# Optionally filter by importance threshold.
#
# Usage:
#   ./memory-search.sh concept=<partial-name> [importance=<threshold>]
#   ./memory-search.sh --concept <partial-name> [--importance <threshold>]
#   ./memory-search.sh --help

MEMORY_FILE=".workflow/memory.json"

# ------------------------------------------------------------------
# usage — print help
# ------------------------------------------------------------------
usage() {
    cat <<'EOF'
Usage: memory-search.sh --concept <partial-name> [--importance <threshold>]
       memory-search.sh concept=<partial-name> [importance=<threshold>]

Search memory entries in .workflow/memory.json by concept partial match.
Optionally filter results to entries with importance >= threshold.

Arguments:
  concept       Partial concept string to match (required, case-insensitive)
  importance    Minimum importance score (optional, 1-5)

Flags:
  --help        Show this help message and exit

Output: JSON array of matching entries. Returns empty array if no matches.
Exit code: 0 on success (including no results), 1 on error.
EOF
    exit 0
}

# ------------------------------------------------------------------
# Parse arguments
# ------------------------------------------------------------------
CONCEPT=""
IMPORTANCE=""

while [[ $# -gt 0 ]]; do
    case "$1" in
        --help) usage ;;
        --concept)
            CONCEPT="$2"; shift 2 ;;
        --importance)
            IMPORTANCE="$2"; shift 2 ;;
        --*)
            echo "ERROR: Unknown flag: $1" >&2
            usage ;;
        *=*)
            key="${1%%=*}"
            val="${1#*=}"
            case "$key" in
                concept)    CONCEPT="$val" ;;
                importance) IMPORTANCE="$val" ;;
                *)
                    echo "ERROR: Unknown key: '$key'" >&2
                    usage ;;
            esac
            shift ;;
        *)
            echo "ERROR: Unexpected argument: '$1'" >&2
            usage ;;
    esac
done

# ------------------------------------------------------------------
# Validation
# ------------------------------------------------------------------
if [[ -z "$CONCEPT" ]]; then
    echo "ERROR: 'concept' is required." >&2
    usage
fi

if [[ -n "$IMPORTANCE" ]]; then
    if ! [[ "$IMPORTANCE" =~ ^[1-5]$ ]]; then
        echo "ERROR: 'importance' must be an integer between 1 and 5 (got: '$IMPORTANCE')." >&2
        exit 1
    fi
fi

# ------------------------------------------------------------------
# Check memory.json exists
# ------------------------------------------------------------------
if [[ ! -f "$MEMORY_FILE" ]]; then
    echo "[]"
    exit 0
fi

# ------------------------------------------------------------------
# Search
# ------------------------------------------------------------------
matches=""
first=true

# Read the file line by line, extract JSON object lines (those containing "concept")
while IFS= read -r line; do
    # Only consider lines that look like JSON entries (contain "concept" field)
    if [[ "$line" != *'"concept"'* ]]; then
        continue
    fi

    # Extract the concept value from the JSON line
    # Pattern: "concept":"<value>"
    concept_val=$(echo "$line" | grep -o '"concept":"[^"]*"' | head -1 | sed 's/"concept":"//;s/"$//')

    if [[ -z "$concept_val" ]]; then
        continue
    fi

    # Case-insensitive partial match
    if [[ "${concept_val,,}" != *"${CONCEPT,,}"* ]]; then
        continue
    fi

    # If importance threshold is set, filter
    if [[ -n "$IMPORTANCE" ]]; then
        # Extract importance value from the line
        imp_val=$(echo "$line" | grep -o '"importance":[0-9]*' | head -1 | sed 's/"importance"://')
        if [[ -z "$imp_val" ]]; then
            continue
        fi
        if [[ "$imp_val" -lt "$IMPORTANCE" ]]; then
            continue
        fi
    fi

    # Build JSON array output
    if $first; then
        matches="$line"
        first=false
    else
        matches="${matches},
${line}"
    fi
done < "$MEMORY_FILE"

# Output result
if [[ -z "$matches" ]]; then
    echo "[]"
else
    echo "["
    echo "$matches"
    echo "]"
fi

exit 0
