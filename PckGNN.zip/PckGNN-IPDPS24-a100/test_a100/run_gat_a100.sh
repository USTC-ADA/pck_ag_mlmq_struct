#!/bin/bash -l
#SBATCH -J hzd
#SBATCH -w ada-A100
#SBATCH -N 1
#SBATCH -n 1
#SBATCH -o /a100-data/leo/PckGNN-IPDPS24-a100/test_a100/out_gat
#SBATCH -e /a100-data/leo/PckGNN-IPDPS24-a100/test_a100/err_gat
#SBATCH --gres=gpu:1
#SBATCH --mem=80G

# if [ $# -ne 1 ]; then
#     echo "[Usage]: run_a100.sh {matrix_name}"
#     exit 1
# fi

build_cmd="sh build_GNNA.sh && sh build_UBG.sh && sh build_ge.sh && sh build_KGGNN.sh"
run_cmd="sh run_gat.sh matrix_sample test_a100/gat_a100.csv"
#profile_cmd="ncu --set full -o test_out -f python test_spmm.py /data/GNN_dataset/${matrix_name}.pt"

srun -l \
--container-image "/a100-data/leo/image/kggnn.sqsh" \
--container-mounts "/a100-data/leo:/data" \
--container-remap-root \
--container-writable \
/bin/bash -c "export PS1=aa; source ~/.bashrc; conda activate gnnadvisor; \
cd /data/PckGNN-IPDPS24-a100/test; ${build_cmd}; cd ..; ${run_cmd}"
set +x
