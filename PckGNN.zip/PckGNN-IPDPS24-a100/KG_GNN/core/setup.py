from setuptools import setup
from torch.utils.cpp_extension import BuildExtension, CUDAExtension

setup(
    name='KGGNN',
    ext_modules=[
        CUDAExtension(
        name='KGGNN', 
        sources=[
                    'src/KG_GNN.cpp',
                    'src/gnn_run.cpp',
                    'src/gnn_analysis.cpp',
                    'src/aggregate.cu',
                    'src/aggregate_sddmm.cu',
                    'src/aggregate_gat.cu',
                    'src/aggregate_gin.cu',
                    'src/preprocessing.cu',
                    'src/bin_pack.cu',
                    'src/gnn_mm.cpp',
                    'src/mm.cu',
                    'src/mm_pipeline.cu',
                    'src/spmm_mm_pipeline.cu',
                    'src/spmm_mm_pipeline_new.cu',
                    'src/spmm_mm_pipeline_final_new.cu'
                ]
        )
    ],
    cmdclass={
        'build_ext': BuildExtension
    })