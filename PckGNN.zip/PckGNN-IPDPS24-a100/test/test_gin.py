import dgl
import torch
import torch.nn.functional as F
import torch.nn as nn
from load_dataset import *
from lib.dgl_test import *
from lib.pyg_test import *
from lib.gnna_test import *
#from lib.ubg_test import *
from lib.kg_test import *

import utils
import sys
import time
from perf_time import * 

import rabbit

import os

os.environ["CUDA_VISIBLE_DEVICES"] = '0'

if (len(sys.argv) < 2 or len(sys.argv) > 3):
    print("Usage: python test_dgl_gcn.py [dataset] [outcsv_name | optional]")
    exit(1)

dataset_dir = sys.argv[1]
if len(sys.argv) == 3:
    outcsv_name = sys.argv[2]
else:
    outcsv_name = None

# test setup
gcn_hidden = 64

# Load and initialize input data
graph_data = dataset_load(dataset_dir)
in_dim, out_dim = dataset_prop(graph_data)

# in_dim = 128
in_dim = int((in_dim + 31) / 32) * 32
out_dim = 32
#out_dim = int((out_dim + 31) / 32) * 32

print(in_dim, gcn_hidden, out_dim)

# Rabbit reorder
# graph_data.edge_index = rabbit.reorder(graph_data.edge_index.int())

weight_init = True

if (weight_init):
    random_seed = 123
    torch.manual_seed(random_seed)
    weight0 = torch.randn(in_dim, gcn_hidden)
    weight1 = torch.randn(gcn_hidden, out_dim)
    bias0 = torch.randn(gcn_hidden)
    bias1 = torch.randn(out_dim)
    paras = {'w0': weight0, 'w1': weight1, 'b0': bias0, 'b1': bias1}
else:
    paras = None

input_feature = torch.randn(graph_data.num_nodes, in_dim)

# Set device and move data
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
graph_data = graph_data.to(device)
input_feature = input_feature.to(device)

perf_time_init(dataset_dir)

reorder = True
# Transform to CSR format
graph_csr = utils.graph_to_csr(graph_data, reorder = reorder)
graph_coo = graph_csr.tocoo()
coorow = graph_coo.row.astype(int)
coocol = graph_coo.col.astype(int)
edge_index = np.array([coocol, coorow])
graph_data.edge_index = torch.tensor(edge_index, dtype=torch.long).to(device)

#print(graph_data.edge_index)

#xt = torch.mm(input_feature, weight0.to(device))

# xt = torch.mm(input_feature, weight0.to(device))
# xt = xt + bias0.to(device)
# print(xt)

# PYG test
# pyg_model = pyg_model_init("GIN", in_dim, gcn_hidden, out_dim, paras = paras).to(device)

# out_pyg = pyg_model_run(pyg_model, graph_data, input_feature)

# perf_time_start("PYG")
# out_pyg = pyg_model_run(pyg_model, graph_data, input_feature)
# pyg_time = perf_time_end()

# DGL test
dgl_model = dgl_model_init("GIN", in_dim, gcn_hidden, out_dim, paras = paras).to(device)
g = dgl_data_init(graph_data).to(device)

out_dgl = dgl_model_run(dgl_model, g, input_feature)

perf_time_start("DGL")
out_dgl = dgl_model_run(dgl_model, g, input_feature)
dgl_time = perf_time_end()

# GNNA test

# gnna_model = gnna_model_init("GIN", in_dim, gcn_hidden, out_dim, paras).to(device)

# inputInfo = gnna_data_init("GIN", graph_csr, in_dim, out_dim, device)

# out_gnna = gnna_model_run(gnna_model, inputInfo, input_feature)

# perf_time_start("GNNA")
# out_gnna = gnna_model_run(gnna_model, inputInfo, input_feature, detail_test = True)
# gnna_time = perf_time_end()

# KGGNN test

# kg_autotuning(graph_csr, input_feature, in_dim, gcn_hidden, device)

# baseline_balance = 2
balance = -1

out_kg1, kg_time = kg_run_tmp(graph_csr, input_feature, in_dim, gcn_hidden, out_dim, 
device, balance = 1, paras = paras, detail_test = 0, reorder = False, time_label = 'KG balance 1', name = 'GIN')

out_kg1, kg_time = kg_run_tmp(graph_csr, input_feature, in_dim, gcn_hidden, out_dim, 
device, balance = 1, paras = paras, detail_test = 2, reorder = False, time_label = 'KG balance 1', name = 'GIN')

out_kg2, kg_time = kg_run_tmp(graph_csr, input_feature, in_dim, gcn_hidden, out_dim, 
device, balance = -1, paras = paras, detail_test = 0, reorder = False, time_label = 'KG balance 2', name = 'GIN')

out_kg2, kg_time = kg_run_tmp(graph_csr, input_feature, in_dim, gcn_hidden, out_dim, 
device, balance = -1, paras = paras, detail_test = 2, reorder = False, time_label = 'KG balance 2', name = 'GIN')

# out_kg2, kg_time = kg_run_tmp(graph_csr, input_feature, in_dim, gcn_hidden, out_dim, 
# device, balance = 6, paras = paras, detail_test = 0, reorder = False, time_label = 'KG balance 6', name = 'GIN')

# out_kg2, kg_time = kg_run_tmp(graph_csr, input_feature, in_dim, gcn_hidden, out_dim, 
# device, balance = 6, paras = paras, detail_test = 2, reorder = False, time_label = 'KG balance 6', name = 'GIN')

# out_kg, kg_time = kg_run_tmp(graph_data, input_feature, in_dim, gcn_hidden, out_dim, 
# device, paras = paras, detail_test = 1, reorder = True)

if (outcsv_name):
    perf_time_tofile(outcsv_name)

# print(out_dgl)
# print(out_kg2)

print(torch.norm(out_pyg - out_dgl))
print(torch.norm(out_dgl - out_kg2))

if (outcsv_name != None):
    with open(outcsv_name, "a") as csvfile: 
        writer = csv.writer(csvfile)

        row = []
        row.append(dataset_dir)
        row.append(str(in_dim))
        row.append(str(pyg_time))
        row.append(str(dgl_time))
        row.append(str(gnna_time))
        row.append(str(kg_time))

        writer.writerow(row)