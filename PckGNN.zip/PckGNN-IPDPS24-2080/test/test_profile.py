import dgl
import torch
import torch.nn.functional as F
import torch.nn as nn
from load_dataset import *
from lib.dgl_test import *
from lib.pyg_test import *
from lib.gnna_test import *
from lib.ubg_test import *
from lib.kg_test import *
from lib.ge_test import *

import utils
import sys
import time
from perf_time import * 

import rabbit

import os

os.environ["CUDA_VISIBLE_DEVICES"] = '0'

if (len(sys.argv) < 2 or len(sys.argv) > 3):
    print("Usage: python test_dgl_gcn.py [dataset] [outcsv_name | optional]")
    exit(1)

dataset_dir = sys.argv[1]
if len(sys.argv) == 3:
    outcsv_name = sys.argv[2]
else:
    outcsv_name = None

# Load and initialize input data
graph_data = dataset_load(dataset_dir)
_, _ = dataset_prop(graph_data)
in_dim = 32
out_dim = in_dim
reorder = True

input_feature = torch.randn(graph_data.num_nodes, in_dim)

# Set device and move data
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
graph_data = graph_data.to(device)
input_feature = input_feature.to(device)

perf_time_init(dataset_dir)

# Transform to CSR format
graph_csr = utils.graph_to_csr(graph_data, show_degree = True, reorder = reorder)
# graph_csr_reorder = utils.graph_to_csr(graph_data, reorder = True)

weight_init = True

if (weight_init):
    random_seed = 123
    torch.manual_seed(random_seed)
    weight0 = torch.eye(in_dim)
    bias0 = torch.zeros(in_dim)
    paras = {'w0': weight0, 'b0': bias0}
else:
    paras = None

# GNNA
# gnna_model = gnna_model_init("SpMM", in_dim, 1, out_dim, paras = paras).to(device)

# inputInfo = gnna_data_init("SpMM", graph_csr, in_dim, out_dim, device)

# out_gnna = gnna_model_run(gnna_model, inputInfo, input_feature)

# perf_time_start("GNNA")
# out_gnna, _ = gnna_model_run(gnna_model, inputInfo, input_feature, detail_test = True)
# perf_time_end()

# # UBG
# out_ubg, _ = ubg_model_run("SpMM", graph_csr, in_dim, 1, \
# out_dim, input_feature, device, paras)

# out_ubg, _ = ubg_model_run("SpMM", graph_csr, in_dim, 1, \
# out_dim, input_feature, device, paras, detail_test = 2)

# # GE & cuSPARSE
# out_ge, ge_time = ge_spmm_run(graph_csr, out_dim, input_feature)
# # out_ge = out_ge.to(device)

# PckSpMM

#kg_autotuning(graph_csr, input_feature, in_dim, out_dim, device)

out_pck0, pck_time = kg_run_kernel(graph_csr, input_feature, out_dim, device,
balance = 0, detail_test = 0)
out_pck0, pck_time = kg_run_kernel(graph_csr, input_feature, out_dim, device,
balance = 0, detail_test = 1)
out_pck1, pck_time = kg_run_kernel(graph_csr, input_feature, out_dim, device,
balance = 1, detail_test = 0)
out_pck1, pck_time = kg_run_kernel(graph_csr, input_feature, out_dim, device,
balance = 1, detail_test = 1)
out_pck2, pck_time = kg_run_kernel(graph_csr, input_feature, out_dim, device,
balance = 2, detail_test = 0)
out_pck2, pck_time = kg_run_kernel(graph_csr, input_feature, out_dim, device,
balance = 2, detail_test = 1)

# print(input_feature.cpu())
# print(out_gnna.cpu())
# print(out_ge)
# print(torch.norm(out_ge - out_ubg.cpu()))
# print(torch.norm(out_ge - out_gnna.cpu()))
# print(torch.norm(out_ge - out_pck.cpu()))

# print(torch.norm(out_ubg.cpu() - out_gnna.cpu()))
# print(torch.norm(out_pck0.cpu() - out_pck1.cpu()))
# print(torch.norm(out_pck0.cpu() - out_pck2.cpu()))

#kg_autotuning(graph_csr_reorder, input_feature, in_dim, out_dim, device)
