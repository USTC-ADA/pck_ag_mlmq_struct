import dgl
import torch
import torch.nn.functional as F
import torch.nn as nn
from load_dataset import *
from lib.dgl_test import *
from lib.pyg_test import *
from lib.gnna_test import *
from lib.ubg_test import *
from lib.kg_test import *
from lib.ge_test import *

import utils
import sys
import time
from perf_time import * 

import rabbit

import os

os.environ["CUDA_VISIBLE_DEVICES"] = '0'

if (len(sys.argv) < 2 or len(sys.argv) > 3):
    print("Usage: python test_dgl_gcn.py [dataset] [outcsv_name | optional]")
    exit(1)

dataset_dir = sys.argv[1]
if len(sys.argv) == 3:
    outcsv_name = sys.argv[2]
else:
    outcsv_name = None

# Load and initialize input data
graph_data = dataset_load(dataset_dir)
_, _ = dataset_prop(graph_data)
reorder = True

# Set device and move data
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
graph_data = graph_data.to(device)

perf_time_init(dataset_dir)

# Transform to CSR format
graph_csr = utils.graph_to_csr(graph_data, show_degree = True, reorder = reorder)
# graph_csr_reorder = utils.graph_to_csr(graph_data, reorder = True)

# weight_init = True

# if (weight_init):
#     random_seed = 123
#     torch.manual_seed(random_seed)
#     weight0 = torch.eye(in_dim)
#     bias0 = torch.zeros(in_dim)
#     paras = {'w0': weight0, 'b0': bias0}
# else:
#     paras = None

scalability = []

# PckSpMM
for in_dim in [32, 64, 128, 256, 512]:
    out_dim = in_dim

    input_feature = torch.randn(graph_data.num_nodes, in_dim)
    input_feature = input_feature.to(device)

    # warm up
    out_pck, _ = kg_run_kernel(graph_csr, input_feature, out_dim, device,
    balance = 6, detail_test = 0)

    # test
    out_pck, pck_time = kg_run_kernel(graph_csr, input_feature, out_dim, device,
    balance = 6, detail_test = 1)

    scalability.append(pck_time)

    del input_feature
    del out_pck

#print(scalability)

# out_pck, pck_time = kg_run_kernel(graph_csr, input_feature, out_dim, device,
# balance = 6, detail_test = 1)

# print(input_feature.cpu())
# print(out_gnna.cpu())
# print(out_ge)

# print(torch.norm(out_ubg.cpu() - out_gnna.cpu()))
# print(torch.norm(out_pck.cpu() - out_gnna.cpu()))

#kg_autotuning(graph_csr_reorder, input_feature, in_dim, out_dim, device)
