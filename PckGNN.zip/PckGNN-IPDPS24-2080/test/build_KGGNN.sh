cd ../KG_GNN/core
sh clean.sh
python setup.py install