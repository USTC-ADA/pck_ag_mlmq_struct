cd ../GNNAdvisor
sh build.sh