#!/bin/sh
#SBATCH -J hzd
#SBATCH -w ada-A100
#SBATCH -N 1
#SBATCH -n 1
#SBATCH -o /a100-data/leo/KG_test/out
#SBATCH -e /a100-data/leo/KG_test/err
#SBATCH --gres=gpu:1
#SBATCH --mem=1024

build_cmd="sh build_GNNA.sh && sh build_UBG.sh && sh build_ge.sh && sh build_KGGNN.sh"

srun -l \
--container-image "/a100-data/leo/kggnn.sqsh" \
--container-mounts "/a100-data/leo:/data" \
--container-remap-root \
--container-writable \
/bin/bash -c "cd /data/KG-GNN/test && conda activate gnnadvisor && ${build_cmd}"

set +x