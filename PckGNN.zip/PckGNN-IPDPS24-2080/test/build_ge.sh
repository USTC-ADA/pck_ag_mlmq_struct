cd ../dgSPARSE/example/ge-spmm
python setup.py clean
python setup.py build
python setup.py install
cd ../../../test
#python test_gcn.py ../../dataset/helloworld.pt
