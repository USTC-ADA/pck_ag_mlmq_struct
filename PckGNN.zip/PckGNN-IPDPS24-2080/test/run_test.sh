if [ $# -ne 2 ]; then
    echo "[Usage]: run_test.sh {test_list} {output_csv}"
    exit 1
fi

test_list=$1
output_csv=$2

data_dir=/data/GNN_dataset/

cat ${test_list} | xargs -n1 -I {} \
sh -c "CUDA_VISIBLE_DEVICES=0 python test_gcn.py ${data_dir}{}.pt ${output_csv} || true"