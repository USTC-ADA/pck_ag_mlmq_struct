# rm -rf lib/gnncompile/*
cd ../UBG
sh clean.sh
python setup.py install