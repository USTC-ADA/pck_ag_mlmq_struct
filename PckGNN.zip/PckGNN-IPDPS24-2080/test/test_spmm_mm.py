import dgl
import torch
import torch.nn.functional as F
import torch.nn as nn
from load_dataset import *
# from lib.kg_test import *
from lib.cusparse_test import *
# from lib.ubg_test import *
import KGGNN
import numpy as np

import utils
import sys
import time
from perf_time import * 

import rabbit

import os

# os.environ["CUDA_VISIBLE_DEVICES"] = '0'

if (len(sys.argv) < 2 or len(sys.argv) > 3):
    print("Usage: python test_dgl_gcn.py [dataset] [outcsv_name | optional]")
    exit(1)

dataset_dir = sys.argv[1]
if len(sys.argv) == 3:
    outcsv_name = sys.argv[2]
else:
    outcsv_name = None

# Load and initialize input data
graph_data = dataset_load(dataset_dir)
_, _ = dataset_prop(graph_data)
in_dim = 64
out_dim = 128
reorder = False

m = graph_data.num_nodes
k = in_dim
n = out_dim

np.random.seed(5)
torch.manual_seed(5)

# Set device and move data
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
graph_data = graph_data.to(device)
torch.backends.cuda.matmul.allow_tf32 = False
torch.backends.cudnn.allow_tf32 = False

# Transform to CSR format
graph_csr = utils.graph_to_csr(graph_data, show_degree = True, reorder = reorder)

# Cora
# m = 2816
# n = 64
# k = 1440

# ogbn-arxiv
# m = 169343
# n = 64
# k = 128

# Pubmed
# m = 19717
# n = 64
# k = 512

#test
# m = 32
# n = 32
# k = 32

a = torch.randn(m, k).to(device)
ic1 = torch.randn(m, k).to(device)
b = torch.randn(k, n).to(device)
ic2 = torch.zeros(m, k).to(device)
c2 = torch.zeros(m, n).to(device)
ic3 = torch.zeros(m, k).to(device)
c3 = torch.zeros(m, n).to(device)

perf_time_init("tmp")

# c1 = torch.mm(a, b)
# c2 = torch.mm(a, b)

warmup = 10
repetitions = 100

warmup = 0
repetitions = 1

starter, ender = torch.cuda.Event(enable_timing=True), torch.cuda.Event(enable_timing=True)

cusp_time = 0

# cusparse
cusp_time = cusp_run(graph_csr, a, ic1, k, device, warmup=warmup, repetitions=repetitions)
print("cuSPARSE time: {:.4f}".format(cusp_time))

c1 = torch.mm(ic1, b)

cut_num = 4
cut = int((m+cut_num-1)/cut_num)
c1_cut = []
ic1_cut = []
for i in range(cut_num):
    istart = i * cut
    iend = min(istart + cut, m)
    c1_cut.append(ic1[istart: iend,:])

# cutlass
timings = 0.0
with torch.no_grad():
    for repeat in range(warmup):
        for i in range(cut_num):
            ic1_tmp = torch.mm(c1_cut[i], b)
        #c1 = torch.mm(ic1, b)
    torch.cuda.synchronize()
    #with torch.autograd.profiler.profile(enabled=True, use_cuda=True) as prof:
    for repeat in range(repetitions):
        starter.record()
        #c1 = torch.mm(ic1, b)
        for i in range(cut_num):
            ic1_tmp = torch.mm(c1_cut[i], b)
            ic1_cut.append(ic1_tmp)
        ender.record()
        torch.cuda.synchronize()
        curr_time = starter.elapsed_time(ender) # 从 starter 到 ender 之间用时,单位为毫秒
        timings += curr_time
torch_time = timings / repetitions * 1000
print("Torch MM time: {:.4f} us".format(torch_time))
print("cuSPARSE + Torch MM time: {:.4f} us".format(torch_time + cusp_time))

c = ic1_cut[0]
for i in range(1, cut_num):
    c = torch.cat((ic1, c1_cut[i]), dim = 0)
# tb = prof.table()
# print(tb[tb.index("Self CUDA time total:"):-1])

torch.cuda.synchronize()

# KGGNN.cublas_run_mm(a, b, c2)
# KGGNN.kg_gcn_run_mm(a, b, c2)

rowptr = torch.tensor(graph_csr.indptr)
indices = torch.tensor(graph_csr.indices)

rowptr_d = rowptr.to(device)
indices_d = indices.to(device)

# print(ic1.cpu()[0, 31])
# print(b.cpu()[31, 0])
# print(b.cpu()[0][0])
# print(b.cpu()[15][0])
# print(b.cpu()[16][0])
# print(b.cpu()[31][0])
# print(b.cpu()[0][32])
# print(b.cpu()[16][32])

# print(b.cpu()[32][0])
# print(b.cpu()[63][0])
# print(c1.cpu())
# print(c2.cpu())
# print(a.cpu())
# print(b.cpu())

#ana_info = KGGNN.kg_gcn_spmm_mm_balance_final(rowptr, indices)
#ana_info = KGGNN.kg_gcn_balance(rowptr, indices, 32)
ana_info = KGGNN.kg_gcn_balance2(rowptr, indices, 128, 15)
#KGGNN.kg_gcn_spmm_mm_run_balance(rowptr_d, indices_d, a, b, c2, ana_info)

KGGNN.kg_gcn_spmm_mm_run_final(rowptr_d, indices_d, a, b, ic2, c2, ana_info)
#KGGNN.kg_gcn_spmm_mm_run_balance(rowptr_d, indices_d, a, b, c2, ana_info)
torch.cuda.synchronize()

# print(ic1.cpu()[0][0])
# print(b.cpu()[0][0])
# print(ic1.cpu()[0][8])
# print(b.cpu()[8][0])
# print(ic1.cpu()[0][8])
# print(ic1.cpu()[0][16])
# print(ic1.cpu()[0][24])
# print(b.cpu()[0][0])
# print(b.cpu()[8][0])
# print(b.cpu()[16][0])
# print(b.cpu()[24][0])
print(torch.norm(ic1.cpu() - ic2.cpu()))

# print(c1.cpu())
# print(c2.cpu())
print(torch.norm(c1.cpu() - c2.cpu()))

# EFGNN
timings = 0.0
with torch.no_grad():
    for repeat in range(warmup):
        #KGGNN.kg_gcn_run_mm(a, b, c2)
        #KGGNN.kg_gcn_run_fused_spmm_mm(rowptr_d, indices_d, a, b, c2)
        #KGGNN.kg_gcn_spmm_mm_run_balance(rowptr_d, indices_d, a, b, c2, ana_info)
        KGGNN.kg_gcn_spmm_mm_run_final(rowptr_d, indices_d, a, b, ic2, c2, ana_info)
    torch.cuda.synchronize()
    
    for repeat in range(repetitions):
        starter.record()
        #KGGNN.kg_gcn_run_mm(a, b, c2)
        #KGGNN.kg_gcn_run_fused_spmm_mm(rowptr_d, indices_d, a, b, c2)
        #KGGNN.kg_gcn_spmm_mm_run_balance(rowptr_d, indices_d, a, b, c2, ana_info)
        KGGNN.kg_gcn_spmm_mm_run_final(rowptr_d, indices_d, a, b, ic2, c2, ana_info)
        ender.record()
        torch.cuda.synchronize()
        curr_time = starter.elapsed_time(ender) # 从 starter 到 ender 之间用时,单位为毫秒
        timings += curr_time
kg_time = timings / repetitions * 1000
print("Fused KG time: {:.4f} us".format(kg_time))

# UBG
# out_ubg, ubg_time = ubg_model_run("SpMM", graph_csr, k, 1, \
# k, a, device, paras = None, detail_test = 2)
# print("UBG time: {:.4f} us".format(ubg_time))

print(c1.cpu())
print(c2.cpu())

# print(c1.cpu()[:,63:])
# print(c2.cpu()[:,63:])
# print(ic1.cpu())
# print(ic2.cpu())

# print("ic1", ic1.cpu()[0][0])
# print("ic1", ic1.cpu()[0][31])
# print("ic1", ic1.cpu()[0][32])
# print("ic1", ic1.cpu()[0][63])

# print("b", b.cpu()[0][64])
# print("b", b.cpu()[31][64])
# print("b", b.cpu()[32][32])
# print("b", b.cpu()[63][32])

# print(c1.cpu()[0] - c2.cpu()[0])

spmm_times = 0
mm_times = 0

# balance = 2
# ana_info = KGGNN.kg_gcn_balance2(rowptr, indices, 128, 15)
# ana_info = KGGNN.kg_gcn_balance(rowptr, indices, 32)
# KGGNN.kg_gcn_run_balance(rowptr_d, indices_d, a, ic3, ana_info)


#naive SpMM + cutlass
timings = 0.0
with torch.no_grad():
    for repeat in range(warmup):
        #KGGNN.kg_gcn_run(rowptr_d, indices_d, a, ic3)
        KGGNN.kg_gcn_run_fused_mm(ic3, b, c3)
    torch.cuda.synchronize()
    
    #with torch.autograd.profiler.profile(enabled=True, use_cuda=True) as prof:
    for repeat in range(repetitions):
        starter.record()
        #KGGNN.kg_gcn_run(rowptr_d, indices_d, a, ic3)
        KGGNN.kg_gcn_run_balance(rowptr_d, indices_d, a, ic3, ana_info)
        ender.record()
        torch.cuda.synchronize()
        curr_time = starter.elapsed_time(ender)
        spmm_times += curr_time
        timings += curr_time

    for repeat in range(repetitions):
        starter.record()
        KGGNN.kg_gcn_run_fused_mm(ic3, b, c3)
        ender.record()
        torch.cuda.synchronize()
        curr_time = starter.elapsed_time(ender)
        mm_times += curr_time
        timings += curr_time
    #c3 = torch.mm(ic3, b)

spmm_times = spmm_times / repetitions * 1000
mm_times = mm_times / repetitions * 1000
torch_time = timings / repetitions * 1000

print("KG_SpMM: {:.4f} us".format(spmm_times))
print("KG_MM: {:.4f} us".format(mm_times))
print("KG_SpMM + KG_MM: {:.4f} us".format(torch_time))

# # print(a.cpu())
# # print(b.cpu())

# # print(ic3.cpu()[:, 0])
# # print(c2.cpu())
# # print(c3.cpu())
# # print(c3.cpu())
# print(torch.norm(c1.cpu() - c2.cpu()))
# print(torch.norm(c1.cpu() - c3.cpu()))
# tflops = m * n * k / 1024 / 1024 / 1024 / 1024 * 1000 * 1000
# print("torch perf: {:.2f} TFLOPS".format(tflops / torch_time))
# print("kg mm perf: {:.2f} TFLOPS".format(tflops / kg_time))
# # print(torch.max(c1.cpu() - c2.cpu()))
# # idx = int(int(torch.argmax(c1.cpu() - c2.cpu()) / n) / 64) * 64
# # print(idx)
# # print(c1[idx:idx+128])
# # print(c2[idx:idx+128])
