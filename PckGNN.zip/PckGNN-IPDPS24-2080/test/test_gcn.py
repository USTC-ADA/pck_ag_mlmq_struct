import dgl
import torch
import torch.nn.functional as F
import torch.nn as nn
from load_dataset import *
from lib.dgl_test import *
from lib.pyg_test import *
from lib.gnna_test import *
from lib.ubg_test import *
from lib.kg_test import *

import utils
import sys
import time
from perf_time import * 

import rabbit

import os

os.environ["CUDA_VISIBLE_DEVICES"] = '0'

if (len(sys.argv) < 2 or len(sys.argv) > 3):
    print("Usage: python test_dgl_gcn.py [dataset] [outcsv_name | optional]")
    exit(1)

dataset_dir = sys.argv[1]
if len(sys.argv) == 3:
    outcsv_name = sys.argv[2]
else:
    outcsv_name = None

# test setup
gcn_hidden = 64
out_dim = 32

# Load and initialize input data
graph_data = dataset_load(dataset_dir)
in_dim, out_dim = dataset_prop(graph_data)
out_dim = int((out_dim + 31) / 32) * 32

print(dataset_dir, in_dim, out_dim)

# Rabbit reorder
# graph_data.edge_index = rabbit.reorder(graph_data.edge_index.int())

weight_init = True

if (weight_init):
    random_seed = 123
    torch.manual_seed(random_seed)
    weight0 = torch.randn(in_dim, gcn_hidden)
    weight1 = torch.randn(gcn_hidden, out_dim)
    bias0 = torch.randn(gcn_hidden)
    bias1 = torch.randn(out_dim)
    paras = {'w0': weight0, 'w1': weight1, 'b0': bias0, 'b1': bias1}
else:
    paras = None

input_feature = torch.randn(graph_data.num_nodes, in_dim)

# Set device and move data
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
graph_data = graph_data.to(device)
input_feature = input_feature.to(device)

perf_time_init(dataset_dir)

print(device)

reorder = True

# Transform to CSR format
graph_csr = utils.graph_to_csr(graph_data, reorder = reorder)
graph_coo = graph_csr.tocoo()
coorow = graph_coo.row.astype(int)
coocol = graph_coo.col.astype(int)
edge_index = np.array([coocol, coorow])
graph_data.edge_index = torch.tensor(edge_index, dtype=torch.long).to(device)

#print(graph_data.edge_index)

#xt = torch.mm(input_feature, weight0.to(device))

# PYG test
# pyg_model = pyg_model_init("GCN", in_dim, gcn_hidden, out_dim, paras=paras).to(device)

# out_pyg = pyg_model_run(pyg_model, graph_data, input_feature)

# perf_time_start("PYG")
# out_pyg = pyg_model_run(pyg_model, graph_data, input_feature)
# perf_time_end()

# DGL test
# dgl_model = dgl_model_init("GCN", in_dim, gcn_hidden, out_dim, paras=paras).to(device)
# g = dgl_data_init(graph_data).to(device)

# out_dgl = dgl_model_run(dgl_model, g, input_feature)

# perf_time_start("DGL")
# out_dgl = dgl_model_run(dgl_model, g, input_feature)
# perf_time_end()

# GNNA test

# gnna_model = gnna_model_init("GCN", in_dim, gcn_hidden, out_dim, paras=paras).to(device)

# inputInfo = gnna_data_init("GCN", graph_csr, in_dim, out_dim, device)

# out_gnna = gnna_model_run(gnna_model, inputInfo, input_feature)

# perf_time_start("GNNA")
# out_gnna, _, _ = gnna_model_run(gnna_model, inputInfo, input_feature, detail_test = True)
# perf_time_end()

# # # inputInfo = gnna_data_init("GCN", graph_data, in_dim, out_dim, device, reorder = False)
# # # out_gnna, spmm_time1, spmm_time2 = gnna_model_run(gnna_model, inputInfo, input_feature, detail_test = False)
# # # perf_time_set("GNNA REORDER AGGR0", spmm_time1 / 1e3)
# # # perf_time_set("GNNA REORDER AGGR1", spmm_time2 / 1e3)

# # # gnna_err = (out_gnna - out_dgl).view(-1)
# # # gnna_flag = True
# # # for i in range(gnna_err.size(0)):
# # #     if abs(gnna_err[i]) > 1e-2:
# # #         gnna_flag = False
# # # if (gnna_flag):
# # #     print("GNNA results correct!")
# # # else:
# # #     print("GNNA results error!")

# UBG test
# out_ubg, _ = ubg_model_run("GCN", graph_csr, in_dim, gcn_hidden, \
# out_dim, input_feature, device, paras=paras, detail_test = 2)

# out_ubg, ubg_time = ubg_model_run("GCN", graph_csr, in_dim, gcn_hidden, \
# out_dim, input_feature, device, paras=paras, detail_test = 1)

#print("UBG time {:2f}".format(ubg_time))

# KGGNN test
# baseline_balance = 2
balance = -1

# out_kg1, kg_time = kg_run_tmp(graph_csr, input_feature, in_dim, gcn_hidden, out_dim, 
# device, balance = baseline_balance, paras = paras, detail_test = 1, reorder = False, time_label = 'KG balance 2')

out_kg2, kg_time = kg_run_tmp(graph_csr, input_feature, in_dim, gcn_hidden, out_dim, 
device, balance = balance, paras = paras, detail_test = 0, time_label = 'KG balance')

out_kg2, kg_time = kg_run_tmp(graph_csr, input_feature, in_dim, gcn_hidden, out_dim, 
device, balance = balance, paras = paras, detail_test = 1, time_label = 'KG balance')

out_kg2, kg_time = kg_run_tmp(graph_csr, input_feature, in_dim, gcn_hidden, out_dim, 
device, balance = 6, paras = paras, detail_test = 0, time_label = 'KG balance')

out_kg2, kg_time = kg_run_tmp(graph_csr, input_feature, in_dim, gcn_hidden, out_dim, 
device, balance = 6, paras = paras, detail_test = 1, time_label = 'KG balance')

#print("KG time {:2f}".format(ubg_time))

# out_kg3, kg_time = kg_run_tmp(graph_csr_reorder, input_feature, in_dim, gcn_hidden, out_dim, 
# device, balance = baseline_balance, paras = paras, detail_test = 1, reorder = True, time_label = 'KG reorder')

# out_kg4, kg_time = kg_run_tmp(graph_csr_reorder, input_feature, in_dim, gcn_hidden, out_dim, 
# device, balance = balance, paras = paras, detail_test = 1, reorder = True, time_label = 'KG balance + reorder')

# out_kg, kg_time = kg_run_tmp(graph_data, input_feature, in_dim, gcn_hidden, out_dim, 
# device, paras = paras, detail_test = 1, reorder = True)

if (outcsv_name):
    perf_time_tofile(outcsv_name)

# print("pyg results:", out_pyg)
# print("dgl results:", out_dgl)
# print("gnna results:", out_gnna)
# print("ubg results:", out_ubg)
# print("KG results:", out_kg1)
# print("KG results:", out_kg2)

#print(torch.norm(out_kg3 - out_kg4))
# print(torch.norm(out_pyg - out_dgl))
# print(torch.norm(out_dgl - out_gnna))
# print(torch.norm(out_dgl - out_ubg))
print(torch.norm(out_dgl - out_kg2))

# print(torch.norm(out_gnna - out_ubg))
# print(torch.norm(out_gnna - out_kg2))

# print("out1: ", out_kg1)
# print("out2: ", out_kg2)