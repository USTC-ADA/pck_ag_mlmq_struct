import dgl
import torch
import torch.nn.functional as F
import torch.nn as nn
from load_dataset import *
from lib.dgl_test import *
from lib.pyg_test import *
#from lib.gnna_test import *
from lib.ubg_test import *
from lib.kg_test import *

import utils
import sys
import time
from perf_time import * 

import rabbit

import os

os.environ["CUDA_VISIBLE_DEVICES"] = '1'

if (len(sys.argv) < 2 or len(sys.argv) > 3):
    print("Usage: python test_dgl_gcn.py [dataset] [outcsv_name | optional]")
    exit(1)

dataset_dir = sys.argv[1]
if len(sys.argv) == 3:
    outcsv_name = sys.argv[2]
else:
    outcsv_name = None

# Load and initialize input data
graph_data = dataset_load(dataset_dir)
in_dim, out_dim = dataset_prop(graph_data)

# test setup
gcn_hidden = 32
out_dim = 32
# out_dim = int((out_dim + 31) / 32) * 32

print("matrix:", dataset_dir)
print("layer feature:", in_dim, gcn_hidden, out_dim)

weight_init = True

if (weight_init):
    random_seed = 123
    torch.manual_seed(random_seed)
    weight0 = torch.randn(in_dim, gcn_hidden)
    weight1 = torch.randn(gcn_hidden, out_dim)
    att_src0 = torch.randn(1, 1, gcn_hidden)
    att_dst0 = torch.randn(1, 1, gcn_hidden)
    att_src1 = torch.randn(1, 1, out_dim)
    att_dst1 = torch.randn(1, 1, out_dim)
    bias0 = torch.randn(gcn_hidden)
    bias1 = torch.randn(out_dim)
    paras = {'w0': weight0, 'w1': weight1, 'b0': bias0, 'b1': bias1, \
    'as0': att_src0, 'ad0': att_dst0, 'as1': att_src1, 'ad1':att_dst1}
else:
    paras = None

input_feature = torch.randn(graph_data.num_nodes, in_dim)

# Set device and move data
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
graph_data = graph_data.to(device)
input_feature = input_feature.to(device)

perf_time_init(dataset_dir)

reorder = True

# Transform to CSR format
graph_csr = utils.graph_to_csr(graph_data, reorder = reorder)
graph_coo = graph_csr.tocoo()
coorow = graph_coo.row.astype(int)
coocol = graph_coo.col.astype(int)
edge_index = np.array([coocol, coorow])
graph_data.edge_index = torch.tensor(edge_index, dtype=torch.long).to(device)

# PYG test
pyg_model = pyg_model_init("GAT", in_dim, gcn_hidden, out_dim, relu_l=0.2, paras=paras).to(device)

out_pyg = pyg_model_run(pyg_model, graph_data, input_feature)

perf_time_start("PYG")
out_pyg = pyg_model_run(pyg_model, graph_data, input_feature)
perf_time_end()

# DGL test
dgl_model = dgl_model_init("GAT", in_dim, gcn_hidden, out_dim, relu_l=0.2, paras=paras).to(device)
g = dgl_data_init(graph_data).to(device)

out_dgl = dgl_model_run(dgl_model, g, input_feature)

perf_time_start("DGL")
out_dgl = dgl_model_run(dgl_model, g, input_feature)
perf_time_end()
out_dgl = out_dgl.reshape(-1, out_dim)

# UBG test
# out_ubg, _ = ubg_model_run("GAT", graph_csr, in_dim, gcn_hidden, \
# out_dim, input_feature, device, paras, detail_test = 0)

# out_ubg, ubg_time = ubg_model_run("GAT", graph_csr, in_dim, gcn_hidden, \
# out_dim, input_feature, device, paras, detail_test = 2)

# KGGNN test

# input_tmp = torch.randn(len(graph_csr.indptr) - 1, gcn_hidden).to(device)
# kg_autotuning(graph_csr, input_tmp, in_dim, gcn_hidden, device, name = 'GAT')

balance = 2

out_kg1, kg_time = kg_run_tmp(graph_csr, input_feature, in_dim, gcn_hidden, out_dim, 
device, balance = 1, paras = paras, detail_test = 0, reorder = False, time_label = 'KG balance 1', name = 'GAT')

out_kg1, kg_time = kg_run_tmp(graph_csr, input_feature, in_dim, gcn_hidden, out_dim, 
device, balance = 1, paras = paras, detail_test = 2, reorder = False, time_label = 'KG balance 1', name = 'GAT')

out_kg2, kg_time = kg_run_tmp(graph_csr, input_feature, in_dim, gcn_hidden, out_dim, 
device, balance = 2, paras = paras, detail_test = 0, reorder = False, time_label = 'KG balance 2', name = 'GAT')

out_kg2, kg_time = kg_run_tmp(graph_csr, input_feature, in_dim, gcn_hidden, out_dim, 
device, balance = 2, paras = paras, detail_test = 2, reorder = False, time_label = 'KG balance 2', name = 'GAT')

# out_kg2, kg_time = kg_run_tmp(graph_csr, input_feature, in_dim, gcn_hidden, out_dim, 
# device, balance = 6, paras = paras, detail_test = 0, reorder = False, time_label = 'KG balance 2', name = 'GAT')

# out_kg2, kg_time = kg_run_tmp(graph_csr, input_feature, in_dim, gcn_hidden, out_dim, 
# device, balance = 6, paras = paras, detail_test = 2, reorder = False, time_label = 'KG balance 2', name = 'GAT')


# print(out_pyg.size())
# print(out_dgl.size())
# print(torch.norm(out_dgl - out_pyg))
print(torch.norm(out_dgl - out_kg1))
print(torch.norm(out_dgl - out_kg2))

# print(out_pyg)
# print(out_kg2)
