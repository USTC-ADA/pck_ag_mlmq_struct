cd ../rabbit_module/src
sh clean.sh
python setup.py install