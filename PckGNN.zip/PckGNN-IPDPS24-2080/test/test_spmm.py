import dgl
import torch
import torch.nn.functional as F
import torch.nn as nn
from load_dataset import *
from lib.dgl_test import *
from lib.pyg_test import *
from lib.gnna_test import *
from lib.ubg_test import *
from lib.kg_test import *
from lib.ge_test import *

import utils
import sys
import time
from perf_time import * 

import rabbit

import csv

import os

os.environ["CUDA_VISIBLE_DEVICES"] = '1'

if (len(sys.argv) < 3 or len(sys.argv) > 4):
    print("Usage: python test_spmm.py [dataset] [in_dim] [outcsv_name | optional]")
    exit(1)

dataset_dir = sys.argv[1]
in_dim = int(sys.argv[2])
if len(sys.argv) == 4:
    outcsv_name = sys.argv[3]
else:
    outcsv_name = None

# Load and initialize input data
graph_data = dataset_load(dataset_dir)
_, _ = dataset_prop(graph_data)
#in_dim = 32
out_dim = in_dim
reorder = True

print("matrix", dataset_dir, " dim ", out_dim)

input_feature = torch.randn(graph_data.num_nodes, in_dim)

# Set device and move data
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
print(device)
graph_data = graph_data.to(device)
input_feature = input_feature.to(device)

perf_time_init(dataset_dir)

# Transform to CSR format
graph_csr = utils.graph_to_csr(graph_data, show_degree = True, reorder = reorder)
# graph_csr_reorder = utils.graph_to_csr(graph_data, reorder = True)

weight_init = True

if (weight_init):
    random_seed = 123
    torch.manual_seed(random_seed)
    weight0 = torch.eye(in_dim)
    bias0 = torch.zeros(in_dim)
    paras = {'w0': weight0, 'b0': bias0}
else:
    paras = None

# GNNA
# gnna_model = gnna_model_init("SpMM", in_dim, 1, out_dim, paras = paras).to(device)

# inputInfo = gnna_data_init("SpMM", graph_csr, in_dim, out_dim, device)

# out_gnna = gnna_model_run(gnna_model, inputInfo, input_feature)

# perf_time_start("GNNA")
# out_gnna, _ = gnna_model_run(gnna_model, inputInfo, input_feature, detail_test = True)
# gnna_time = perf_time_end()

# # UBG
# out_ubg, _ = ubg_model_run("SpMM", graph_csr, in_dim, 1, \
# out_dim, input_feature, device, paras)

# out_ubg, ubg_time = ubg_model_run("SpMM", graph_csr, in_dim, 1, \
# out_dim, input_feature, device, paras, detail_test = 2)

# print("UBG time", ubg_time)

# # PckSpMM

# kg_autotuning(graph_csr, input_feature, in_dim, out_dim, device)

# # out_pck, pck_time = kg_run_kernel('SpMM', graph_csr, input_feature, out_dim, device,
# # balance = 0, detail_test = 0)
# out_pck, pck_time = kg_run_kernel('SpMM', graph_csr, input_feature, out_dim, device,
# balance = 1, time_label = 'balance1', detail_test = 0)
# out_pck, pck_time = kg_run_kernel('SpMM', graph_csr, input_feature, out_dim, device,
# balance = 1, time_label = 'balance1', detail_test = 1)
# # out_pck, pck_time = kg_run_kernel('SpMM', graph_csr, input_feature, out_dim, device,
# # balance = 2, detail_test = 0)
# # out_pck, pck_time = kg_run_kernel('SpMM', graph_csr, input_feature, out_dim, device,
# # balance = 2, detail_test = 1)
# out_pck, pck_time = kg_run_kernel('SpMM', graph_csr, input_feature, out_dim, device,
# balance = 6, time_label = 'balance6', detail_test = 0)
# out_pck, pck_time = kg_run_kernel('SpMM', graph_csr, input_feature, out_dim, device,
# balance = 6, time_label = 'balance6', detail_test = 1)

# out_pck, pck_time = kg_run_kernel('SpMM', graph_csr, input_feature, out_dim, device,
# balance = -1, detail_test = 0)
# out_pck, pck_time = kg_run_kernel('SpMM', graph_csr, input_feature, out_dim, device,
# balance = -1, detail_test = 1)

# GE & cuSPARSE
out_ge, ge_time = ge_spmm_run(graph_csr, out_dim, input_feature)
out_ge = out_ge.to(device)

print("GE best", ge_time)

# print(input_feature.cpu())
# print(out_gnna.cpu())
# print(out_ge)
# print(torch.norm(out_ge - out_ubg.cpu()))
# #print(torch.norm(out_ge - out_gnna.cpu()))

# print(torch.norm(out_ubg.cpu() - out_gnna.cpu()))
# print(torch.norm(out_pck.cpu() - out_ubg.cpu()))
# print(torch.norm(out_ge.cpu() - out_pck.cpu()))

# if (outcsv_name != None):
#     with open(outcsv_name, "a") as csvfile: 
#         writer = csv.writer(csvfile)

#         row = []
#         row.append(dataset_dir)
#         row.append(str(in_dim))
#         row.append(str(gnna_time))
#         row.append(str(ubg_time))
#         row.append(str(ge_time))
#         row.append(str(pck_time))

#         writer.writerow(row)

#kg_autotuning(graph_csr_reorder, input_feature, in_dim, out_dim, device)
