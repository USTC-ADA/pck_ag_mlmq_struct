#include "../include/KG_GNN.h"
#include <cuda.h>
#include <stdio.h>
#include <vector>
#include <iostream>

void sinfo2device(std::vector<bin_pack_info> *host_sinfo, bin_pack_info ***sinfo, int **sinfo_n)
{
    int host_sinfo_n[WARP_NUM];
    for (int i = 0; i < WARP_NUM; i++)
        host_sinfo_n[i] = host_sinfo[i].size();
    
    cudaMalloc(sinfo_n, WARP_NUM * sizeof(int));
    cudaMemcpy(*sinfo_n, host_sinfo_n, WARP_NUM * sizeof(int), cudaMemcpyHostToDevice);

    cudaMalloc(sinfo, WARP_NUM * sizeof(bin_pack_info*));

    bin_pack_info *info_h[WARP_NUM];
    for (int i = 0; i < WARP_NUM; i++)
    {
        int level = host_sinfo_n[i];
        if (level)
        {
            // if (i <= 10)
            // {
            //     printf("host wid %d level %d\n", i, level);
            //     printf("host info st %d ed %d\n", host_sinfo[i][0].bp_st, host_sinfo[i][0].bp_ed);
            // }
            cudaMalloc(&info_h[i], level * sizeof(bin_pack_info));
            cudaMemcpy(info_h[i], &host_sinfo[i][0], level * sizeof(bin_pack_info), cudaMemcpyHostToDevice);
        }
        else
            info_h[i] = NULL;
    }

    cudaMemcpy(*sinfo, info_h, WARP_NUM * sizeof(bin_pack_info*), cudaMemcpyHostToDevice);
}

void bin_pack_construct(int m, int nnz, int *RowPtr, int *ColIdx, 
int bin_size, int pack_size, int bin_thresh, bin_pack **bp, int alpha)
{
    *bp = new bin_pack();

    (*bp)->PckPtr_h.push_back(0);
    (*bp)->RowPtr_sp_h.push_back(0);
    (*bp)->BinPtr_h.push_back(0);

    int bins = (m + bin_size - 1) / bin_size;

    std::vector<warp_info> bin_list[bins];

    int bin_nnz = 0;

    int max_pck_size = 128;

    for (int row = 0; row < m; row++)
    {
        int row_st = RowPtr[row];
        int row_ed = RowPtr[row + 1];

        int bin_id = 0;

        int ptr_st = row_st;
        int ptr = ptr_st;
        while (ptr < row_ed)
        {
            int bin_st = bin_id * bin_size;
            int bin_ed = kg_min((bin_id + 1) * bin_size, m);

            //printf("m %d bin_st %d bin_ed %d\n", row, bin_st, bin_ed);
            
            while (ptr < row_ed && ColIdx[ptr] < bin_ed)
            {
                ptr++;

                // handling extreme long rows
                if (ptr > ptr_st + max_pck_size)
                {
                    warp_info tmp = warp_info(row, row + 1, ptr_st, ptr);
                    bin_list[bin_id].push_back(tmp);

                    bin_nnz += ptr - ptr_st;

                    ptr_st = ptr;
                }
            }

            //printf("ptr_st %d ptr_ed %d ColIdx[ptr] = %d\n", ptr_st, ptr, ColIdx[ptr]);

            if (ptr > ptr_st + bin_thresh)
            {
                warp_info tmp = warp_info(row, row + 1, ptr_st, ptr);
                bin_list[bin_id].push_back(tmp);

                bin_nnz += ptr - ptr_st;
                // (*bp)->PckCont_h.push_back(- row - 1);
                // for (int col = ptr_st; col < ptr; col++)
                // {
                //     (*bp)->PckCont_h.push_back(ColIdx[col]);
                // }
                // (*bp)->PckPtr_h.push_back(PckCont_h.size());
            }
            else
            {
                for (int col = ptr_st; col < ptr; col++)
                {
                    (*bp)->ColIdx_sp_h.push_back(ColIdx[col]);
                }
            }

            bin_id++;

            ptr_st = ptr;
        }

        (*bp)->RowPtr_sp_h.push_back((*bp)->ColIdx_sp_h.size());
    }

    int current_pck_size = 0;

    for (int bin_id = 0; bin_id < bins; bin_id++)
    {
        //printf("bin_id %d size %d\n", bin_id, bin_list[bin_id].size());
        int current_bin_load = 0;

        int bin_st = bin_id * bin_size;
        int bin_ed = kg_min((bin_id + 1) * bin_size - 1, m);

        for (int i = 0; i < bin_list[bin_id].size(); i++)
        {
            warp_info tmp = bin_list[bin_id][i];

            (*bp)->PckCont_h.push_back(tmp.row_st);
            //(*bp)->PckCont_h.push_back(tmp.col_ed - tmp.col_st);
            for (int col = tmp.col_st; col < tmp.col_ed; col++)
            {
                (*bp)->PckCont_h.push_back(ColIdx[col]);
            }

            // package strategy
            current_pck_size += tmp.col_ed - tmp.col_st + alpha;
            current_bin_load += tmp.col_ed - tmp.col_st + alpha;

            (*bp)->PckPtr_h.push_back((*bp)->PckCont_h.size());
            //(*bp)->PckLoad.push_back(current_pck_size);

            // if (current_pck_size > pack_size)
            // {
            //     (*bp)->PckPtr_h.push_back((*bp)->PckCont_h.size());
            //     (*bp)->PckLoad.push_back(current_pck_size);
            //     current_pck_size = 0;
            // }
        }

        // if (current_pck_size > 0)
        // {
        //     (*bp)->PckPtr_h.push_back((*bp)->PckCont_h.size());
        //     (*bp)->PckLoad.push_back(current_pck_size);
        //     current_pck_size = 0;
        // }

        (*bp)->BinPtr_h.push_back((*bp)->PckPtr_h.size() - 1);
        (*bp)->BinLoad.push_back(current_bin_load);
    }

    if ((*bp)->PckPtr_h.back() != (*bp)->PckCont_h.size())
        (*bp)->PckPtr_h.push_back((*bp)->PckCont_h.size());

    //(*bp)->BinPtr_h.push_back((*bp)->PckCont_h.size());

    (*bp)->Pckn = (*bp)->PckPtr_h.size() - 1;
    (*bp)->spn = (*bp)->RowPtr_sp_h.size() - 1;

    printf("bin nnz %d total nnz %d rest nnz %d\n", bin_nnz, nnz, (*bp)->RowPtr_sp_h[(*bp)->spn]);

    int *PckPtr = NULL;
    int *PckCont = NULL;
    int *RowPtr_sp = NULL;
    int *ColIdx_sp = NULL;
    
    if ((*bp)->PckPtr_h.size() > 1)
    {
        cudaMalloc(&PckPtr, (*bp)->PckPtr_h.size() * sizeof(int));
        cudaMalloc(&PckCont, (*bp)->PckCont_h.size() * sizeof(int));

        cudaMemcpy(PckPtr, &((*bp)->PckPtr_h[0]), (*bp)->PckPtr_h.size() * sizeof(int), cudaMemcpyHostToDevice);
        cudaMemcpy(PckCont, &((*bp)->PckCont_h[0]), (*bp)->PckCont_h.size() * sizeof(int), cudaMemcpyHostToDevice);
    }

    if ((*bp)->spn > 0)
    {
        cudaMalloc(&RowPtr_sp, (*bp)->RowPtr_sp_h.size() * sizeof(int));
        cudaMalloc(&ColIdx_sp, (*bp)->ColIdx_sp_h.size() * sizeof(int));

        cudaMemcpy(RowPtr_sp, &((*bp)->RowPtr_sp_h[0]), (*bp)->RowPtr_sp_h.size() * sizeof(int), cudaMemcpyHostToDevice);
        cudaMemcpy(ColIdx_sp, &((*bp)->ColIdx_sp_h[0]), (*bp)->ColIdx_sp_h.size() * sizeof(int), cudaMemcpyHostToDevice);
    }

    (*bp)->bin_pack_cpy(PckPtr, PckCont, RowPtr_sp, ColIdx_sp);

    // printf("BinPtr\n");
    // for(int i = 0; i < (*bp)->BinPtr_h.size(); i++) {
    //     std::cout << (*bp)->BinPtr_h[i] << " ";
    // }
    // std::cout << endl;
    // printf("PckPtr\n");
    // for(int i = 0; i < (*bp)->PckPtr_h.size(); i++) {
    //     std::cout << (*bp)->PckPtr_h[i] << " ";
    // }
    // std::cout << endl;
    // printf("PckCont\n");
    // for(int i = 0; i < (*bp)->PckCont_h.size(); i++) {
    //     std::cout << (*bp)->PckCont_h[i] << " ";
    // }
    // std::cout << endl;
    // printf("BinLoad\n");
    // for(int i = 0; i < (*bp)->BinLoad.size(); i++) {
    //     std::cout << (*bp)->BinLoad[i] << " ";
    // }
    // std::cout << endl;
}

void bin_pack_schedule(bin_pack *bp, bin_pack_info ***bpinfo, int **bpinfo_n, int bin_block, int alpha)
{
    std::vector<bin_pack_info> host_bpinfo[WARP_NUM];

    int current_warp = 0;
    int current_block = 0;
    int warp_pos[BLOCK_NUM];
    int block_load[BLOCK_NUM];

    for (int i = 0; i < BLOCK_NUM; i++)
    {
        warp_pos[i] = 0;
        block_load[i] = 0;
    }

    int warp_load[WARP_NUM];
    for (int i = 0; i < WARP_NUM; i++)
        warp_load[i] = 0;

    int bins = bp->BinPtr_h.size() - 1;

    // printf("bin_pack bins %d pcks %d\n", bp->BinPtr_h.size() - 1, bp->PckPtr_h.size() - 1);

    // for (int i = 0; i < 1; i++)
    // {
    //     printf("BinPtr_st ed %d %d\n", bp->BinPtr_h[i], bp->BinPtr_h[i + 1]);
    //     int tmp_load = 0;
    //     for (int j = bp->BinPtr_h[i]; j < bp->BinPtr_h[i+1]; j++)
    //         tmp_load += bp->PckLoad[j];
    //     printf("checkout: %d %d %d\n", i, tmp_load, bp->BinLoad[i]);
    // }

    for (int i = 0; i < bins; i += bin_block)
    {
        int bin_end = kg_min(bins, i + bin_block);

        // based on pcks
        // int bp_st = bp->BinPtr_h[i];
        // int bp_ed = bp->BinPtr_h[bin_end];

        // int current_pcks = 0;
        // int pcks_per_warp = (bp_ed - bp_st + WARP_NUM - 1) / WARP_NUM;
        // for (int j = bp_st; j < bp_ed; j+=pcks_per_warp)
        // {
        //     //printf("bp_st bp_ed %d %d", bp_st, bp_ed);
        //     int j_end = kg_min(j + pcks_per_warp, bp_ed);

        //     bin_pack_info tmp = bin_pack_info(j, j_end);
        //     host_bpinfo[current_warp].push_back(tmp);

        //     current_warp = (current_warp + 1) % WARP_NUM;

        //     int current_warp_load = 0;
        //     for (int jj = j; jj < j_end; jj++)
        //         current_warp_load += bp->PckPtr_h[jj+1] - bp->PckPtr_h[jj] + alpha;
        //     warp_load[current_warp] += current_warp_load;
        // }

        // based on workload
        float workload_per_block = 0;
        for (int j = i; j < bin_end; j++)
        {
            workload_per_block += bp->BinLoad[j];
        }
        workload_per_block = 1.0 * workload_per_block / BLOCK_NUM;
        float workload_per_warp = workload_per_block / WARP_PER_BLOCK;

        int bp_st = bp->BinPtr_h[i];
        int bp_ed = bp_st;

        int current_warp_load = 0;
        int current_block_load = 0;

        current_block = 0;

        // printf("bin_id %d workload_per_block %.2f\n", i, workload_per_block);

        // printf("w[%d] = %.2f start %d end %d\n", i, workload_per_block, bp->BinPtr_h[i], bp->BinPtr_h[bin_end]);

        while (bp_ed < bp->BinPtr_h[bin_end])
        {
            int tmp_load = bp->PckPtr_h[bp_ed + 1] - bp->PckPtr_h[bp_ed] + alpha;
            current_warp_load += tmp_load;
            if (current_warp_load > workload_per_warp)
            {
                bin_pack_info tmp = bin_pack_info(bp_st, bp_ed + 1);
                host_bpinfo[WARP_PER_BLOCK * current_block + current_warp].push_back(tmp);

                current_warp = (current_warp + 1) % WARP_PER_BLOCK;
                if (current_warp == 0) current_block = (current_block + 1) % BLOCK_NUM;
                current_warp_load = 0;
                bp_st = bp_ed + 1;
            }

            bp_ed++;
        }

        // while (bp_ed < bp->BinPtr_h[bin_end])
        // {
        //     int tmp_load = bp->PckPtr_h[bp_ed + 1] - bp->PckPtr_h[bp_ed] + alpha;
        //     //bp->PckLoad[bp_ed];//bp->PckPtr_h[bp_ed + 1] - bp->PckPtr_h[bp_ed] + alpha;
        //     current_warp_load += tmp_load;
        //     current_block_load += tmp_load;

        //     if (current_block_load > workload_per_block)
        //     {
        //         bin_pack_info tmp = bin_pack_info(bp_st, bp_ed + 1);
        //         host_bpinfo[WARP_PER_BLOCK * current_block + current_warp].push_back(tmp);

        //         // if (current_block == 1)
        //         //     printf("block %d push_back %d %d tmp_load %d current_block_load %d\n", current_block, bp_st, bp_ed + 1, tmp_load, current_block_load);

        //         //printf("bp_st %d, bp_ed + 1 %d\n", bp_st, bp_ed + 1);

        //         warp_pos[current_block] = current_warp;
        //         current_block = (current_block + 1) % BLOCK_NUM;
        //         current_warp = warp_pos[current_block];
        //         current_block_load = 0;
        //         current_warp_load = 0;
        //         bp_st = bp_ed + 1;
        //     }

        //     if (current_warp_load > 0)
        //     {
        //         bin_pack_info tmp = bin_pack_info(bp_st, bp_ed + 1);
        //         host_bpinfo[WARP_PER_BLOCK * current_block + current_warp].push_back(tmp);

        //         // if (current_block == 1)
        //         //     printf("block %d push_back %d %d\n", current_block, bp_st, bp_ed + 1);
        //         //printf("bin_end %d, bp_ed + 1 %d\n", bin_end, bp_ed + 1);

        //         current_warp = (current_warp + 1) % WARP_PER_BLOCK;
        //         current_warp_load = 0;
        //         bp_st = bp_ed + 1;
        //     }

        //     bp_ed++;
        // }

        if (current_warp_load > 0)
        {
            bin_pack_info tmp = bin_pack_info(bp_st, bp->BinPtr_h[bin_end]);
            host_bpinfo[WARP_PER_BLOCK * current_block + current_warp].push_back(tmp);
            // printf("bin_end %d, bp->BinPtr_h[bin_end] = %d\n", bin_end, bp->BinPtr_h[bin_end]);
        }

    }

    int warp_min_load = -1;
    int warp_max_load = 0;

    // printf("workload: ");

    for (int i = 0; i < WARP_NUM; i++)
    {
        int tmp = 0;
        //tmp = warp_load[i];
        for (int j = 0; j < host_bpinfo[i].size(); j++)
        {
            for (int jj = host_bpinfo[i][j].bp_st; jj < host_bpinfo[i][j].bp_ed; jj++)
                tmp += bp->PckPtr_h[jj + 1] - bp->PckPtr_h[jj] + alpha;
            //bp->PckLoad[jj];//bp->PckPtr_h[jj + 1] - bp->PckPtr_h[jj] + alpha;
            //tmp += host_bpinfo[i][j].bp_ed - host_bpinfo[i][j].bp_st + alpha;
        }
        if (warp_min_load == -1 || tmp < warp_min_load) warp_min_load = tmp;
        if (warp_max_load < tmp) warp_max_load = tmp;
        printf("%d ", tmp);
    }

    printf("min/max warp load %d %d\n", warp_min_load, warp_max_load);

    sinfo2device(host_bpinfo, bpinfo, bpinfo_n);
    
}