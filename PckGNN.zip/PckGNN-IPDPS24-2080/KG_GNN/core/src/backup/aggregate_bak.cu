#include "../include/KG_GNN.h"
#include <cuda.h>
#include <stdio.h>

__global__ void gcn_aggregate_kernel_naive(int m, int nnz, int feat_len,
int *RowPtr, int *ColIdx, float *in_feat, float *out_feat)
{
    int local_tid = threadIdx.x;
    int global_tid = blockIdx.x * blockDim.x + local_tid;
    //int local_wid = local_tid / WARP_SIZE;
    int global_wid = global_tid / WARP_SIZE;
    int lane_id = local_tid & (WARP_SIZE - 1);

    int row = global_wid;

    //if (!lane_id) printf("warp_id %d row %d\n", global_wid, row);

    int start_ptr = RowPtr[row];
    int end_ptr = RowPtr[row + 1];
    //if (start_ptr + 32 < end_ptr) end_ptr = start_ptr + 32;
    float degree_inv = 1.0 ;/// (end_ptr - start_ptr);

    if (row < m)
    {
        int self_idx = row * feat_len;
        for (int j = lane_id; j < feat_len; j += WARP_SIZE)
        //for (int j = lane_id; j < WARP_SIZE; j+=WARP_SIZE)
        {
            float result = 0.0;
            for (int i = start_ptr; i < end_ptr; i++)
            {
                int nid = ColIdx[i];
                int feat_idx = nid * feat_len + j;
                result += in_feat[feat_idx] * degree_inv;
            }
            out_feat[self_idx + j] = result;
        }
    }
}

// Calculate a (m x k) * b (k x n) = c (m x n) and aggregate c
__global__ void gcn_aggregate_kernel_fused(int m, int nnz, int k, int n,
int *RowPtr, int *ColIdx, float *a, float* b, float *c,
block_info *binfo, int binfo_n)
{
    int bid = blockIdx.x;
    int local_tid = threadIdx.x;
    int global_tid = blockIdx.x * BLOCK_SIZE + local_tid;
    int local_wid = local_tid / WARP_SIZE;
    //int global_wid = global_tid / WARP_SIZE;
    int lane_id = local_tid & (WARP_SIZE - 1);

    __shared__ float a_buf[M_TILE_SIZE * K_BUF_TILE];
    __shared__ float b_buf[K_TILE_SIZE * N_BUF_TILE];
    __shared__ float c_buf[M_TILE_SIZE * N_BUF_TILE];

    if (local_tid >= BLOCK_SIZE) return;

    for (int block_iter = 0; block_iter < binfo_n; block_iter++)
    {
        int block_row_st = binfo[bid * binfo_n + block_iter].row_st;
        int block_row_ed = binfo[bid * binfo_n + block_iter].row_ed;

        // if (!local_tid) printf("bid %d row_st %d row_ed %d m n k %d %d %d\n", 
        // bid, block_row_st, block_row_ed, m, n, k);

        if (block_row_st < 0) return;

        int M_TILE = kg_min(block_row_ed - block_row_st, M_TILE_SIZE);
        int N_TILE = kg_min(n, N_TILE_SIZE);
        int K_TILE = kg_min(k, K_TILE_SIZE);

        for (int n_iter = 0; n_iter < n; n_iter += N_TILE)
        {
            int n_ed = kg_min(n, n_iter + N_TILE);
            int n_len = n_ed - n_iter;

            for (int m_block = block_row_st; m_block < block_row_ed; m_block += M_TILE)
            {
                int m_ed = kg_min(block_row_ed, block_row_st + M_TILE);

                // initialize
                for (int m_iter = m_block + local_wid; m_iter < m_ed; m_iter += WARP_PER_BLOCK)
                {
                    for (int n_sub_iter = lane_id; n_sub_iter < n_len; n_sub_iter += WARP_SIZE)
                    {
                        int buf_idx = (m_iter - m_block) * N_BUF_TILE + n_sub_iter;
                        c_buf[buf_idx] = 0;
                    }
                }

                for (int k_iter = 0; k_iter < k; k_iter += K_TILE)
                {
                    int k_ed = kg_min(k, k_iter + K_TILE);
                    int k_len = k_ed - k_iter;

                    // load tiled matrix a
                    if (k <= K_TILE_SIZE)
                    {
                        int a_st = k * m_block;
                        int a_ed = k * m_ed;
                        for (int load_iter = a_st + local_tid; load_iter < a_ed; load_iter += BLOCK_SIZE)
                        {
                            int buf_idxk = (load_iter - a_st) / K_TILE;
                            int buf_idxn = (load_iter - a_st) % K_TILE;
                            a_buf[buf_idxk * K_BUF_TILE + buf_idxn] = a[load_iter];
                        }
                    }
                    else
                    {
                        for (int m_iter = m_block + local_wid; m_iter < m_ed; m_iter += WARP_PER_BLOCK)
                        {
                            int buf_idx = (m_iter - m_block) * K_BUF_TILE;
                            for (int k_sub_iter = lane_id; k_sub_iter < k_len; k_sub_iter += WARP_SIZE)
                            {
                                a_buf[buf_idx + k_sub_iter] = a[m_iter * k + k_iter + k_sub_iter];
                            }
                        }
                    }

                    // load tiled matrix b
                    if (n <= N_TILE_SIZE)
                    {
                        int b_st = n * k_iter;
                        int b_ed = n * k_ed;
                        for (int load_iter = b_st + local_tid; load_iter < b_ed; load_iter += BLOCK_SIZE)
                        {
                            int buf_idxk = (load_iter - b_st) / N_TILE;
                            int buf_idxn = (load_iter - b_st) % N_TILE;
                            b_buf[buf_idxk * N_BUF_TILE + buf_idxn] = b[load_iter];
                        }
                    }
                    else
                    {
                        // if (!bid && !local_tid && !m_block && !n_iter)
                        //     printf("this\n");
                        for (int k_sub_iter = k_iter + local_wid; k_sub_iter < k_ed; k_sub_iter += WARP_PER_BLOCK)
                        {
                            int buf_idx = (k_sub_iter - k_iter) * N_BUF_TILE;
                            for (int n_sub_iter = lane_id; n_sub_iter < n_len; n_sub_iter += WARP_SIZE)
                            {
                                // if (buf_idx + n_sub_iter == 33)
                                //     printf("(%d %d -> %d, %.3f) ", local_wid, k_sub_iter * n + n_iter + n_sub_iter, buf_idx + n_sub_iter, b[k_sub_iter * n + n_iter + n_sub_iter]);
                                // if (!bid && !m_block && !n_iter)
                                //     printf("(%d %d -> %d, %.3f) ", local_wid, k_sub_iter * n + n_iter + n_sub_iter, buf_idx + n_sub_iter, b[k_sub_iter * n + n_iter + n_sub_iter]);
                                b_buf[buf_idx + n_sub_iter] = b[k_sub_iter * n + n_iter + n_sub_iter];
                            }
                        }
                    }

                    __syncthreads();

                    // if (!bid && !local_tid && !m_block && !n_iter)
                    // {
                    //     int a_st = m * m_block;
                    //     int a_ed = k * m_ed;
                    //     printf("a_buf\n");
                    //     for (int outm = m_block; outm < m_ed; outm++)
                    //     {
                    //         for (int outk = 0; outk < K_TILE; outk++)
                    //             printf("%.3f ", a_buf[(outm - m_block) * K_BUF_TILE + outk]);
                    //         printf("\n");
                    //     }

                    //     printf("b_buf\n");
                    //     for (int outk = 0; outk < K_TILE; outk++)
                    //     {
                    //         for (int outn = 0; outn < N_TILE; outn++)
                    //             printf("(%d, %.3f)", outk * N_BUF_TILE + outn, b_buf[outk * N_BUF_TILE + outn]);
                    //         printf("\n");
                    //     }
                    // }

                    // matrix multiplication
                    #pragma unroll
                    for (int m_iter = m_block + local_wid; m_iter < m_ed; m_iter += WARP_PER_BLOCK)
                    {
                        int a_buf_idx = (m_iter - m_block) * N_BUF_TILE;
                        #pragma unroll
                        for (int n_sub_iter = lane_id; n_sub_iter < n_len; n_sub_iter += WARP_SIZE)
                        {
                            int b_buf_idx = n_sub_iter;

                            float local_sum = 0.0;

                            #pragma unroll
                            for (int k_sub_iter = 0; k_sub_iter < k_len; k_sub_iter++)
                            {
                                // local_sum = local_sum + a_buf[a_buf_idx + k_sub_iter] *
                                // b_buf[b_buf_idx + k_sub_iter * N_BUF_TILE];
                                local_sum = local_sum + a_buf[a_buf_idx] * b_buf[b_buf_idx];
                                a_buf_idx++;
                                b_buf_idx += N_BUF_TILE;
                            }

                            int c_buf_idx = (m_iter - m_block) * N_BUF_TILE + n_sub_iter;
                            c_buf[c_buf_idx] += local_sum;
                        }
                    }

                    __syncthreads();
                }

                for (int m_iter = m_block + local_wid; m_iter < m_ed; m_iter += WARP_PER_BLOCK)
                {
                    for (int n_sub_iter = lane_id; n_sub_iter < n_len; n_sub_iter += WARP_SIZE)
                    {
                        int buf_idx = (m_iter - m_block) * N_BUF_TILE + n_sub_iter;
                        int c_idx = m_iter * n + n_iter + n_sub_iter;
                        c[c_idx] = c_buf[buf_idx];
                    }
                }
            }
        }
    }
}

__global__ void gcn_aggregate_kernel_balance(int m, int nnz, int feat_len,
int *RowPtr, int *ColIdx, float *in_feat, float *out_feat, warp_info* winfo, int winfo_n)
{
    int local_tid = threadIdx.x;
    if (local_tid >= BLOCK_SIZE) return;
    //int global_tid = blockIdx.x * blockDim.x + local_tid;
    int global_tid = blockIdx.x * BLOCK_SIZE + local_tid;
    //int local_wid = local_tid / WARP_SIZE;
    int global_wid = global_tid / WARP_SIZE;
    int lane_id = local_tid & (WARP_SIZE - 1);

    int tgt = global_wid;
    if (tgt > winfo_n) return;
    warp_info info = winfo[tgt];

    for (int row = info.row_st; row < info.row_ed; row++)
    //int row = 0;
    {
        int start_ptr = (RowPtr[row] > info.col_st)? RowPtr[row]: info.col_st;
        int end_ptr = (RowPtr[row + 1] < info.col_ed)? RowPtr[row + 1]: info.col_ed;
        // int start_ptr = info.col_st;
        // int end_ptr = info.col_ed;
        float degree_inv = 1.0 ;/// (RowPtr[row + 1] - RowPtr[row]);

        //if (!lane_id) printf("warp_id %d st %d ed %d\n", lane_id, start_ptr, end_ptr);

        int atom_add = 0;
        if (start_ptr != RowPtr[row] || end_ptr != RowPtr[row + 1]) atom_add = 1;

        int self_idx = row * feat_len;
        for (int j = lane_id; j < feat_len; j += WARP_SIZE)
        //for (int j = lane_id; j < WARP_SIZE; j+=WARP_SIZE)
        {
            float result = 0.0;
            for (int i = start_ptr; i < end_ptr; i++)
            {
                int nid = ColIdx[i];
                int feat_idx = nid * feat_len + j;
                result += in_feat[feat_idx] * degree_inv;
            }
            
            if (atom_add)
                atomicAdd(&out_feat[self_idx + j], result);
            else
                out_feat[self_idx + j] = result;
        }
    }
}

__global__ void gcn_aggregate_kernel_scheduled(int m, int nnz, int feat_len,
int *RowPtr, int *ColIdx, float *in_feat, float *out_feat, warp_info** sinfo, int* sinfo_n)
{
    int local_tid = threadIdx.x;
    if (local_tid >= BLOCK_SIZE) return;
    //int global_tid = blockIdx.x * blockDim.x + local_tid;
    int global_tid = blockIdx.x * BLOCK_SIZE + local_tid;
    //int local_wid = local_tid / WARP_SIZE;
    int global_wid = global_tid / WARP_SIZE;
    int lane_id = local_tid & (WARP_SIZE - 1);

    // if (!lane_id && sinfo_n[global_wid])
    //     printf("wid %d level %d\n", global_wid, sinfo_n[global_wid]);
    // return;

    for (int schedule_level = 0; schedule_level < sinfo_n[global_wid]; schedule_level++)
    {
        warp_info info = sinfo[global_wid][schedule_level];

        //if (!lane_id) printf("st %d ed %d\n", info.row_st, info.row_ed);

        for (int row = info.row_st; row < info.row_ed; row++)
        {
            int start_ptr = (RowPtr[row] > info.col_st)? RowPtr[row]: info.col_st;
            int end_ptr = (RowPtr[row + 1] < info.col_ed)? RowPtr[row + 1]: info.col_ed;
            float degree_inv = 1.0;/// (RowPtr[row + 1] - RowPtr[row]);

            //if (!lane_id) printf("warp_id %d st %d ed %d\n", lane_id, start_ptr, end_ptr);

            int atom_add = 0;
            if (start_ptr != RowPtr[row] || end_ptr != RowPtr[row + 1]) atom_add = 1;

            int self_idx = row * feat_len;
            for (int j = lane_id; j < feat_len; j += WARP_SIZE)
            //for (int j = lane_id; j < WARP_SIZE; j+=WARP_SIZE)
            {
                float result = 0.0;
                for (int i = start_ptr; i < end_ptr; i++)
                {
                    int nid = ColIdx[i];
                    int feat_idx = nid * feat_len + j;
                    result += in_feat[feat_idx] * degree_inv;
                }
                
                if (atom_add)
                    atomicAdd(&out_feat[self_idx + j], result);
                else
                    out_feat[self_idx + j] = result;
            }
        }
    }
}

__global__ void gcn_aggregate_kernel_balance_shared(int m, int nnz, int feat_len,
int *RowPtr, int *ColIdx, float *in_feat, float *out_feat, warp_info* winfo, int winfo_n)
{
    int local_tid = threadIdx.x;
    if (local_tid >= BLOCK_SIZE) return;
    //int global_tid = blockIdx.x * blockDim.x + local_tid;
    int global_tid = blockIdx.x * BLOCK_SIZE + local_tid;
    int local_wid = local_tid / WARP_SIZE;
    int global_wid = global_tid / WARP_SIZE;
    int lane_id = local_tid & (WARP_SIZE - 1);

    int tgt = global_wid;
    if (tgt > winfo_n) return;
    warp_info info = winfo[tgt];

    // Store embeddings of the whole thread block in shared memory to 
    int block_st = winfo[blockIdx.x * WARP_PER_BLOCK].row_st;
    int block_ed = winfo[kg_min((blockIdx.x + 1) * WARP_PER_BLOCK - 1, winfo_n)].row_ed;

    __shared__ float inner_embedding[WARP_PER_BLOCK][SHARED_EMBEDDING_SIZE];

    // if (block_ed - block_st > WARP_PER_BLOCK)
    // {
    //     printf("Error!\n");
    //     return;
    // }

    __syncthreads();

    for (int row = info.row_st; row < info.row_ed; row++)
    {
        int start_ptr = (RowPtr[row] > info.col_st)? RowPtr[row]: info.col_st;
        int end_ptr = (RowPtr[row + 1] < info.col_ed)? RowPtr[row + 1]: info.col_ed;
        float degree_inv = 1.0 / (RowPtr[row + 1] - RowPtr[row]);

        //if (!lane_id) printf("warp_id %d st %d ed %d\n", lane_id, start_ptr, end_ptr);

        int atom_add = 0;
        if (start_ptr != RowPtr[row] || end_ptr != RowPtr[row + 1]) atom_add = 1;

        int self_idx = row * feat_len;
        for (int j = lane_id; j < feat_len; j += WARP_SIZE)
        //for (int j = lane_id; j < WARP_SIZE; j+=WARP_SIZE)
        {
            for (int row = block_st + local_wid; row < block_ed; row+=WARP_SIZE)
            {
                inner_embedding[row - block_st][lane_id] = in_feat[row * feat_len + j];
            }

            __syncthreads();

            float result = 0.0;

            for (int i = start_ptr; i < end_ptr; i++)
            {
                int nid = ColIdx[i];
                float in_feat_value;
                if (nid >= block_st && nid < block_ed)
                    in_feat_value = inner_embedding[nid - block_st][lane_id];
                else
                    in_feat_value = in_feat[nid * feat_len + j];
                result += in_feat_value * degree_inv;
            }
            
            if (atom_add)
                atomicAdd(&out_feat[self_idx + j], result);
            else
                out_feat[self_idx + j] = result;
        }
    }
}

void gcn_aggregate(int m, int nnz, int feat_len,
int *RowPtr, int *ColIdx, float *in_feat, float *out_feat)
{
    // naive
    //int warp_num = m;
    int thread_num = m * WARP_SIZE;
    int block_num = (thread_num + BLOCK_SIZE - 1) / BLOCK_SIZE;

    dim3 grid(block_num);
    dim3 block(BLOCK_SIZE);

    gcn_aggregate_kernel_naive<<<grid, block>>>(m, nnz, feat_len,
    RowPtr, ColIdx, in_feat, out_feat);
}

void gcn_aggregate_fused(int m, int nnz, int feat_len_in, int feat_len_out,
int *RowPtr, int *ColIdx, float *in_feat, float *weight, float *out_feat,
block_info *binfo, int binfo_n)
{
    // nn + aggregation fused
    //int warp_num = m;
    int thread_num = m * WARP_SIZE;
    //int block_num = (thread_num + BLOCK_SIZE - 1) / BLOCK_SIZE;

    dim3 grid(BLOCK_NUM);
    dim3 block(BLOCK_SIZE_ALIGN);

    gcn_aggregate_kernel_fused<<<grid, block>>>(m, nnz, feat_len_in, feat_len_out,
    RowPtr, ColIdx, in_feat, weight, out_feat, binfo, binfo_n);
}

void gcn_aggregate_balance(int m, int nnz, int feat_len,
int *RowPtr, int *ColIdx, float *in_feat, float *out_feat, warp_info* winfo, int winfo_n)
{
    // neighbour grouping for balance
    int warp_num = winfo_n;
    int thread_num = warp_num * WARP_SIZE;
    int block_num = (thread_num + BLOCK_SIZE - 1) / BLOCK_SIZE;

    dim3 grid(block_num);
    dim3 block(BLOCK_SIZE_ALIGN);

    gcn_aggregate_kernel_balance<<<grid, block>>>(m, nnz, feat_len,
    RowPtr, ColIdx, in_feat, out_feat, winfo, winfo_n);
}

void gcn_aggregate_scheduled(int m, int nnz, int feat_len,
int *RowPtr, int *ColIdx, float *in_feat, float *out_feat, warp_info** sinfo, int* sinfo_n)
{
    int warp_num = BLOCK_NUM * WARP_PER_BLOCK;
    //int thread_num = warp_num * WARP_SIZE;
    //int block_num = BLOCK_SIZE;

    dim3 grid(BLOCK_NUM);
    dim3 block(BLOCK_SIZE_ALIGN);

    // printf("WARP_NUM %d warp_num %d\n", WARP_NUM, warp_num);

    gcn_aggregate_kernel_scheduled<<<grid, block>>>(m, nnz, feat_len,
    RowPtr, ColIdx, in_feat, out_feat, sinfo, sinfo_n);
}

void gcn_aggregate_balance_shared(int m, int nnz, int feat_len,
int *RowPtr, int *ColIdx, float *in_feat, float *out_feat, warp_info* winfo, int winfo_n)
{
    // neighbour grouping for balance
    int warp_num = winfo_n;
    int thread_num = warp_num * WARP_SIZE;
    int block_num = (thread_num + BLOCK_SIZE - 1) / BLOCK_SIZE;

    dim3 grid(block_num);
    dim3 block(BLOCK_SIZE_ALIGN);

    gcn_aggregate_kernel_balance_shared<<<grid, block>>>(m, nnz, feat_len,
    RowPtr, ColIdx, in_feat, out_feat, winfo, winfo_n);
}

