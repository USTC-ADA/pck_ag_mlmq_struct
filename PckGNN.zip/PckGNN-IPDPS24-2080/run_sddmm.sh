if [ $# -ne 2 ]; then
    echo "[Usage]: run.sh {matrix_list} {output_dir}"
    exit 1
fi
matrix_list=$1
out_csv=$2

cd test

matrix_dir=/data/GNN_dataset/

ulimit -m unlimited
ulimit -s unlimited
cat ../${matrix_list} | xargs -n1 -I {} \
sh -c "python test_sddmm.py ${matrix_dir}{}.pt 32 ${out_csv} && \
python test_sddmm.py ${matrix_dir}{}.pt 128 ${out_csv} && \
python test_sddmm.py ${matrix_dir}{}.pt 512 ${out_csv} || true"
