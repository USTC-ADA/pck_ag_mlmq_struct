#include <stdio.h>
#include <stdlib.h>
#include <cusparse.h>
#include <cuda_runtime.h>

void cutest_run(int m, int nnz, int featlen, int *RowPtr, int *ColIdx,
float *Vals, float *output)
{
    // cuSparse
    cusparseHandle_t cusparse_handler;
    cusparseStatus_t ErrorStatus;
    ErrorStatus = cusparseCreate(&cusparse_handler);

    cusparseMatDescr_t desc;
    ErrorStatus = cusparseCreateMatDescr(&desc);
    cusparseSetMatIndexBase(desc, CUSPARSE_INDEX_BASE_ZERO);
    cusparseSetMatFillMode(desc, CUSPARSE_FILL_MODE_LOWER);
    cusparseSetMatDiagType(desc, CUSPARSE_DIAG_TYPE_NON_UNIT);

    bsrsv2Info_t cusparse_info;
    cusparseCreateBsrsv2Info(&cusparse_info);

    cusparseSbsrmm(cusparse_handler,
    CUSPARSE_DIRECTION_ROW,
    CUSPARSE_OPERATION_NON_TRANSPOSE,
    CUSPARSE_OPERATION_NON_TRANSPOSE,
    m, feat_len, m, nnz, 1.0,
    
    );
}