import matplotlib.pyplot as plt
import csv
import sys
import numpy as np
from math import pow

matrix_example = ['arxiv', 'collab', 'mag', 'ppa', 'products']

naive = [0.340, 0.532, 0.506, 0.516, 0.461]
ng = [0.661, 0.695, 0.673, 0.749, 0.759]
nep = [0.779, 0.787, 0.786, 0.863, 0.862]

naive = [item * 100 for item in naive]
ng = [item * 100 for item in ng]
nep = [item * 100 for item in nep]

fontsize = 12
width = 5
height = 3.5

plt.rcParams['font.size'] = 14
plt.figure(figsize=(width, height))

#plt.style.use('seaborn-dark')
#plt.style.use('fivethirtyeight')
#plt.style.use('Solarize_Light2')
#print(plt.style.available)
plt.style.use('seaborn-deep')
#plt.style.use('seaborn-pastel')
#plt.style.use('seaborn-pastel')
#plt.grid(True)

print(np.mean(naive))
print(np.mean(ng))
print(np.mean(nep))

x = np.arange(len(matrix_example))
total_width, n = 0.6, 3
width = total_width / n
x = x - (total_width - width) / 2

plt.bar(x, naive, width=width, label='Naive')
plt.bar(x + width, ng,  width=width, label='w/ NG')
plt.bar(x + width * 2, nep,  width=width, label='w/ NP')

#for i in range(0, len(matrix_example)):
# plt.plot(naive, label = 'w/o Neighbour Grouping', marker = 'o')
# plt.plot(ng, label = 'w Neighbour Grouping', marker = 'o')

# for i in range(0, len(matrix_example)):
#     plt.plot(naive[i], label = , marker = 'o')
#     plt.plot(ng[i], label = , marker = 'o')

# #print(range(0, final_subset))
plt.xticks(range(0, len(matrix_example)), matrix_example)
plt.xlim(-0.5, len(matrix_example) - 0.5)
plt.ylim(0, 100)

plt.ylabel('GPU occupancy (%)', fontweight='bold')
plt.xlabel('Test case', fontweight='bold')

#plt.legend(loc='upper left', fontsize = 12)
plt.legend(bbox_to_anchor=(1.05, 0.35), loc = 3, borderaxespad = 0, fontsize = 12)

picname = 'output_fig/occupancy.png'
plt.savefig(picname, bbox_inches='tight')

picname = 'output_fig/occupancy.pdf'
plt.savefig(picname, bbox_inches='tight')
