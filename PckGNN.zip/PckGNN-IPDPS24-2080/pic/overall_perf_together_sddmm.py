import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
import csv
import sys
import numpy as np
from math import pow, log, exp

matrix_example = ['arxiv', 'collab', 'mag', 'ppa', 'products', 'ddi', 'proteins', 'reddit']

comp_name = ['cuSPARSE', 'PckGNN']

comp_k = ['32', '128', '512']

run_time = [
[3.30,  5.34,  15.84,   99.83,   293.848, 4.884, 181.23, 262.491], #cuSPARSE
[0.398, 0.619, 1.700,   10.955,  31.438,  1.113, 19.861, 28.707], #PckSpMM
]

run_time2 = [
[ 7.22, 13.63, 42.125,  121.586, 398.196, 5.121, 191.001, 276.683], #cuSPARSE
[1.485, 2.359, 6.682,   42.937,  126.643, 2.232, 77.541, 112.245], #PckSpMM
]

run_time3 = [
[37.19, 76.62, 246.519, 569.179, 0,       18.262, 686.961,  1007.937], #cuSPARSE
[5.804, 9.296, 26.505,  174.310, 0,       8.483,  310.847,  450.980], #PckSpMM
]

#a100 data
run_time4 = [
[3.30,  5.34,  15.84,   99.83,   293.848, 4.884, 181.23, 262.491], #cuSPARSE
[0.398, 0.619, 1.700,   10.955,  31.438,  1.113, 19.861, 28.707], #PckSpMM
]

run_time5 = [
[ 7.22, 13.63, 42.125,  121.586, 398.196, 5.121, 191.001, 276.683], #cuSPARSE
[1.485, 2.359, 6.682,   42.937,  126.643, 2.232, 77.541, 112.245], #PckSpMM
]

run_time6 = [
[37.19, 76.62, 246.519, 569.179, 0,       18.262, 686.961,  1007.937], #cuSPARSE
[5.804, 9.296, 26.505,  174.310, 0,       8.483,  310.847,  450.980], #PckSpMM
]

comp_n = len(run_time)

nnz = [1335586, 2171132, 6152660, 43040151, 126167053, 2140089, 79255038, 114848857]
feat_len = 32
M = 1024 * 1024

def get_gflops(run_time_tmp, factor):
    gflops_tmp = []
    for i in range(comp_n):
        gtmp = []
        for index, v in enumerate(run_time_tmp[i]):
            if (v):
                gtmp.append(factor * nnz[index] * feat_len / v / M)
            else:
                gtmp.append(0)
        gflops_tmp.append(gtmp)
    return gflops_tmp

gflops = get_gflops(run_time, 1.0)
gflops2 = get_gflops(run_time2, 4.0)
gflops3 = get_gflops(run_time3, 16.0)
gflops4 = get_gflops(run_time4, 1.0)
gflops5 = get_gflops(run_time5, 4.0)
gflops6 = get_gflops(run_time6, 16.0)

# gflops2 = []
# for i in range(comp_n):
#     gtmp = []
#     for index, v in enumerate(run_time2[i]):
#         if (v):
#             gtmp.append(4.0 * nnz[index] * feat_len / v / M)
#         else:
#             gtmp.append(0)
#     gflops2.append(gtmp)

# gflops3 = []
# for i in range(comp_n):
#     gtmp = []
#     for index, v in enumerate(run_time3[i]):
#         if (v):
#             gtmp.append(16.0 * nnz[index] * feat_len / v / M)
#         else:
#             gtmp.append(0)
#     gflops3.append(gtmp)

avg_speedups = []
geo_speedups = []
for i in range(comp_n):
    avg_speedup = 0.0
    #geo_speedup = 0.0
    non_zero_count = 0
    for j in range(len(matrix_example)):
        if (gflops[i][j] and gflops[comp_n - 1][j]):
            avg_speedup += gflops[comp_n - 1][j] / gflops[i][j]
            non_zero_count += 1
        if (gflops2[i][j] and gflops2[comp_n - 1][j]):
            avg_speedup += gflops2[comp_n - 1][j] / gflops2[i][j]
            non_zero_count += 1
        if (gflops3[i][j] and gflops3[comp_n - 1][j]):
            avg_speedup += gflops3[comp_n - 1][j] / gflops3[i][j]
            non_zero_count += 1
        #geo_speedup += log(gflops[comp_n - 1][j] / gflops[i][j])
    avg_speedup /= non_zero_count
    #geo_speedup = exp(geo_speedup / len(matrix_example))
    avg_speedups.append(avg_speedup)
    #geo_speedups.append(geo_speedup)

def mean_nonzero(arr):
    non_zero_indexes = np.nonzero(arr)[0]
    arr_tmp = np.array(arr)
    non_zero_values = arr_tmp[non_zero_indexes]
    mean = np.mean(non_zero_values)
    return mean

print("3080Ti speedups: ", avg_speedups)
#print(geo_speedups)
gflops_mean = np.array([mean_nonzero(gflops[1]), mean_nonzero(gflops2[1]), mean_nonzero(gflops3[1])])
print("3080Ti: ", np.mean(gflops_mean))

avg_speedups = []
geo_speedups = []
for i in range(comp_n):
    avg_speedup = 0.0
    #geo_speedup = 0.0
    non_zero_count = 0
    for j in range(len(matrix_example)):
        if (gflops4[i][j] and gflops4[comp_n - 1][j]):
            avg_speedup += gflops4[comp_n - 1][j] / gflops4[i][j]
            non_zero_count += 1
        if (gflops5[i][j] and gflops5[comp_n - 1][j]):
            avg_speedup += gflops5[comp_n - 1][j] / gflops5[i][j]
            non_zero_count += 1
        if (gflops6[i][j] and gflops6[comp_n - 1][j]):
            avg_speedup += gflops6[comp_n - 1][j] / gflops6[i][j]
            non_zero_count += 1
        #geo_speedup += log(gflops[comp_n - 1][j] / gflops[i][j])
    avg_speedup /= non_zero_count
    #geo_speedup = exp(geo_speedup / len(matrix_example))
    avg_speedups.append(avg_speedup)
    #geo_speedups.append(geo_speedup)

print("A100 speedups: ", avg_speedups)
#print(geo_speedups)
gflops_mean = np.array([mean_nonzero(gflops4[1]), mean_nonzero(gflops5[1]), mean_nonzero(gflops6[1])])
print("A100: ", np.mean(gflops_mean))

width = 15
height = 6

fig, axs = plt.subplots(2, 1, figsize=(width, height), sharex=True, sharey=False)
fig.tight_layout(h_pad = 1.5)

plt.rcParams['font.size'] = 14

x = np.arange(len(matrix_example))
total_width, n = 0.8, comp_n * 3
width = total_width / n
x = x - (total_width - width) / 2

#cmp_color = ['#F1DBE7', '#E0F1F7', '#DBD8E9', '#DEECD9', '#D0D2D4']
#cmp_color = ['#9BC985', '#F7D58B', '#B695BF', '#797BB7']
cmp_color = ['#9DD0C7', '#9180AC', '#D9BDD8', '#E58579', '#8AB1D2']
cmp_hatch = ['/', ' ', '\\']
edge_c = 'black'

plt.subplot(2, 1, 1)
for i in range(comp_n):
    plt.bar(x + width * i * 3, gflops[i], width = width, hatch = cmp_hatch[0], edgecolor = edge_c, color = cmp_color[i], label=comp_name[i])
for i in range(comp_n):
    plt.bar(x + width * (i * 3 + 1), gflops2[i], width = width, hatch = cmp_hatch[1], edgecolor = edge_c, color = cmp_color[i], label=comp_name[i])
for i in range(comp_n):
    plt.bar(x + width * (i * 3 + 2), gflops3[i], width = width, hatch = cmp_hatch[2], edgecolor = edge_c, color = cmp_color[i], label=comp_name[i])
plt.xticks([])
plt.title('RTX 3080Ti', fontsize=14)
plt.xlim(-0.5, len(matrix_example) - 0.5)

plt.subplot(2, 1, 2)
for i in range(comp_n):
    plt.bar(x + width * i * 3, gflops4[i], width = width, hatch = cmp_hatch[0], edgecolor = edge_c, color = cmp_color[i], label=comp_name[i])
for i in range(comp_n):
    plt.bar(x + width * (i * 3 + 1), gflops5[i], width = width, hatch = cmp_hatch[1], edgecolor = edge_c, color = cmp_color[i], label=comp_name[i])
for i in range(comp_n):
    plt.bar(x + width * (i * 3 + 2), gflops6[i], width = width, hatch = cmp_hatch[2], edgecolor = edge_c, color = cmp_color[i], label=comp_name[i])
plt.xticks([])
plt.title('Tesla A100', fontsize=14)
plt.xlim(-0.5, len(matrix_example) - 0.5)


# plt.subplot(6, 1, 1)
# for i in range(comp_n):
#     plt.bar(x + width * i, gflops[i], width = width, label=comp_name[i])
# plt.xticks([])
# plt.title('RTX 3080Ti, k = 32', fontsize=14)

# plt.subplot(6, 1, 2)
# for i in range(comp_n):
#     plt.bar(x + width * i, gflops2[i], width = width, label=comp_name[i])
# plt.xticks([])
# plt.title('RTX 3080Ti, k = 128', fontsize=14)

# plt.subplot(6, 1, 3)
# for i in range(comp_n):
#     plt.bar(x + width * i, gflops3[i], width = width, label=comp_name[i])
# plt.xticks([])
# plt.title('RTX 3080Ti, k = 512', fontsize=14)

# plt.subplot(6, 1, 4)
# for i in range(comp_n):
#     plt.bar(x + width * i, gflops4[i], width = width, label=comp_name[i])
# plt.xticks([])
# plt.title('Tesla A100, k = 32', fontsize=14)

# plt.subplot(6, 1, 5)
# for i in range(comp_n):
#     plt.bar(x + width * i, gflops5[i], width = width, label=comp_name[i])
# plt.xticks([])
# plt.title('Tesla A100, k = 128', fontsize=14)

# plt.subplot(6, 1, 6)
# for i in range(comp_n):
#     plt.bar(x + width * i, gflops6[i], width = width, label=comp_name[i])
# plt.title('Tesla A100, k = 512', fontsize=14)

legend_hatch = ['//', ' ', '\\\\']

legend_elements = []
for i in range(comp_n):
    legend_elements.append(Patch(facecolor=cmp_color[i], edgecolor=cmp_color[i], label=comp_name[i]))
        #Line2D([0], [0], color=cmp_color[i], lw=4, label=comp_name[i]))
for i in range(3):
    legend_elements.append(Patch(facecolor='white', edgecolor='black', hatch=legend_hatch[i], label=comp_k[i]))

# legend_elements = [Line2D([0], [0], color='b', lw=4, label='Line'),
#                    Line2D([0], [0], marker='o', color='w', label='Scatter',
#                           markerfacecolor='g', markersize=15),
#                    Patch(facecolor='orange', edgecolor='r',
#                          label='Color Patch')]

plt.legend(handles=legend_elements, bbox_to_anchor=(1.02, 0.85), loc = 3, borderaxespad = 0, fontsize = 12)

plt.xticks(range(0, len(matrix_example)), matrix_example)
#plt.xlim(-0.5, len(matrix_example) - 0.5)

# plt.ylabel('GFLOPS', fontweight='bold', y = 3.5)
# plt.xlabel('Test case', fontweight='bold')

#plt.legend(loc='upper left', fontsize = 12)

picname = 'output_fig/overall_perf_sddmm.png'
plt.savefig(picname, bbox_inches='tight')

picname = 'output_fig/overall_perf_sddmm.pdf'
plt.savefig(picname, bbox_inches='tight')

