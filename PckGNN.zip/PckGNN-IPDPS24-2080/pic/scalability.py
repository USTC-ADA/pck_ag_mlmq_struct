import matplotlib.pyplot as plt
import csv
import sys
import numpy as np
from math import pow, log, exp

matrix_example = ['arxiv', 'collab', 'mag', 'ppa', 'products', 'ddi', 'proteins', 'reddit']
#matrix_example = ['arxiv', 'collab', 'mag', 'ppa', 'products', 'ddi', 'proteins', 'reddit']

k_list = [32, 64, 128, 256, 512]

run_time = [[0.134, 0.273, 0.538, 1.075, 2.181],
[0.180, 0.349, 0.690, 1.389, 2.801],
[0.562, 1.097, 2.204, 4.475, 9.047],
[2.534, 5.194, 10.512, 21.173, 42.106],
[5.212, 11.032, 21.931, 42.938],
[0.106, 0.187, 0.351, 0.684, 1.355],
[2.924, 5.828, 11.611, 23.141, 46.137],
[4.200, 8.308, 16.738, 33.210, 66.448]]

nnz = [1335586, 2171132, 6152660, 43040151, 126167053, 79255038]
#nnz = [1335586, 2171132, 6152660, 43040151, 126167053, 2140089, 79255038, 114848857]

width = 8
height = 6

plt.rcParams['font.size'] = 14
plt.figure(figsize=(width, height))

for i in range(len(run_time)):
    plt.plot(run_time[i], marker='o', label=matrix_example[i])

plt.xticks(range(0, len(k_list)), k_list)
plt.xlim(-0.5, len(k_list) - 0.5)

plt.ylabel('time (ms)', fontweight='bold')
plt.xlabel('k', fontweight='bold')
plt.yscale("log")

#plt.legend(loc='upper left', fontsize = 12)
#plt.legend(bbox_to_anchor=(1.05, 0.3), loc = 3, borderaxespad = 0, fontsize = 12)

picname = 'output_fig/scala_perf.png'
plt.savefig(picname, bbox_inches='tight')

picname = 'output_fig/scala_perf.pdf'
plt.savefig(picname, bbox_inches='tight')
