import matplotlib.pyplot as plt
import csv
import sys
import numpy as np
from math import pow, log, exp

matrix_example = ['arxiv', 'collab', 'mag', 'ppa', 'products', 'ddi', 'proteins', 'reddit']

comp_name = ['cuSPARSE', 'dgSPARSE', 'GNNAdvisor', 'UBG', 'PckSpMM']

run_time = [
[0.202, 0.297, 0.807, 4.551, 12.798, 0.225, 7.465, 11.162], #cuSPARSE
[0.366, 0.207, 1.101, 3.301, 9.534,  0.166, 4.591, 8.373], #GE-SpMM
[0.334, 0.391, 1.170, 5.078, 13.989, 0.217, 8.331, 12.167], #GNNAdvisor
[0.208, 0.266, 0.822, 2.836, 7.181,  0.153, 4.096, 6.805], #UBG
[0.134, 0.180, 0.562, 2.534, 5.212,  0.106, 2.747, 4.200], #PckSpMM
]

run_time2 = [
[0.682, 0.867, 2.984, 15.083, 34.709, 0.473, 18.607, 26.998], #cuSPARSE
[0.553, 0.632, 2.983, 12.373, 26.193, 0.378, 16.303, 24.682], #GE-SpMM
[1.022, 1.253, 3.853, 18.908, 0,      0.648, 26.298, 38.163], #GNNAdvisor
[0.751, 0.917, 2.849, 13.734, 29.559, 0.531, 16.404, 24.712], #UBG
[0.470, 0.618, 1.975, 10.581, 20.065, 0.318, 11.351, 16.634], #PckSpMM
]
                                                #1
run_time3 = [
[2.698, 3.390, 11.923, 61.176, 0, 1.843, 74.687,  109.152], #cuSPARSE
[2.620, 2.782, 9.630,  58.236, 0, 1.348, 69.335,  106.505], #GE-SpMM
[5.943, 7.932, 23.240, 99.513, 0, 2.607, 150.296, 206.648], #GNNAdvisor
[3.133, 3.759, 12.558, 67.540, 0, 2.068, 123.164, 165.720], #UBG
[2.037, 2.429, 8.544,  44.932, 0, 1.176, 46.291,  63.306], #PckSpMM
]

#a100 data
run_time4 = [
[0.215, 0.282, 0.849, 4.785, 12.626, 0.147, 6.692, 9.565], #cuSPARSE
[0.332, 0.199, 1.024, 2.323, 7.634,  0.153, 3.651, 6.938], #GE-SpMM
[0.281, 0.359, 1.114, 4.778, 13.140, 0.186, 7.271, 10.670],#GNNAdvisor
[0.160, 0.206, 0.570, 2.019, 5.197,  0.102, 2.621, 3.812], #UBG
[0.114, 0.138, 0.376, 1.395, 3.675,  0.083, 1.920, 2.815], #PckSpMM
]

run_time5 = [
[0.337, 0.427, 1.387, 7.940,  20.256, 0.275, 11.517, 16.875], #cuSPARSE
[0.431, 0.554, 1.911, 6.650,  19.119, 0.399, 10.037, 17.003], #GE-SpMM
[1.082, 1.419, 4.406, 20.501, 54.782, 0.641, 27.209, 41.071], #GNNAdvisor
[0.556, 0.762, 2.276, 8.501,  23.732, 0.371, 12.659, 18.655], #UBG
[0.261, 0.326, 1.038, 6.276,  12.622, 0.253, 8.566,  12.325], #PckSpMM
]

run_time6 = [
[1.237, 1.609, 5.538,  31.511, 80.415,  1.044, 45.740,  79.549], #cuSPARSE
[1.366, 1.759, 6.061,  38.775, 93.144,  1.284, 49.459,  78.425], #GE-SpMM
[5.651, 7.652, 23.046, 87.699, 246.222, 2.144, 129.151, 183.251], #GNNAdvisor
[2.158, 2.925, 9.252,  34.500, 99.934,  1.396, 55.913,  80.419], #UBG
[1.055, 1.250, 4.171,  25.027, 50.337,  0.881, 33.733,  47.943], #PckSpMM
]

comp_n = len(run_time)

nnz = [1335586, 2171132, 6152660, 43040151, 126167053, 2140089, 79255038, 114848857]
feat_len = 32
M = 1024 * 1024

def get_gflops(run_time_tmp, factor):
    gflops_tmp = []
    for i in range(comp_n):
        gtmp = []
        for index, v in enumerate(run_time_tmp[i]):
            if (v):
                gtmp.append(factor * nnz[index] * feat_len / v / M)
            else:
                gtmp.append(0)
        gflops_tmp.append(gtmp)
    return gflops_tmp

gflops = get_gflops(run_time, 1.0)
gflops2 = get_gflops(run_time2, 4.0)
gflops3 = get_gflops(run_time3, 16.0)
gflops4 = get_gflops(run_time4, 1.0)
gflops5 = get_gflops(run_time5, 4.0)
gflops6 = get_gflops(run_time6, 16.0)

# gflops2 = []
# for i in range(comp_n):
#     gtmp = []
#     for index, v in enumerate(run_time2[i]):
#         if (v):
#             gtmp.append(4.0 * nnz[index] * feat_len / v / M)
#         else:
#             gtmp.append(0)
#     gflops2.append(gtmp)

# gflops3 = []
# for i in range(comp_n):
#     gtmp = []
#     for index, v in enumerate(run_time3[i]):
#         if (v):
#             gtmp.append(16.0 * nnz[index] * feat_len / v / M)
#         else:
#             gtmp.append(0)
#     gflops3.append(gtmp)

avg_speedups = []
geo_speedups = []
for i in range(comp_n):
    avg_speedup = 0.0
    #geo_speedup = 0.0
    non_zero_count = 0
    for j in range(len(matrix_example)):
        if (gflops[i][j] and gflops[comp_n - 1][j]):
            avg_speedup += gflops[comp_n - 1][j] / gflops[i][j]
            non_zero_count += 1
        if (gflops2[i][j] and gflops2[comp_n - 1][j]):
            avg_speedup += gflops2[comp_n - 1][j] / gflops2[i][j]
            non_zero_count += 1
        if (gflops3[i][j] and gflops3[comp_n - 1][j]):
            avg_speedup += gflops3[comp_n - 1][j] / gflops3[i][j]
            non_zero_count += 1
        #geo_speedup += log(gflops[comp_n - 1][j] / gflops[i][j])
    avg_speedup /= non_zero_count
    #geo_speedup = exp(geo_speedup / len(matrix_example))
    avg_speedups.append(avg_speedup)
    #geo_speedups.append(geo_speedup)

def mean_nonzero(arr):
    non_zero_indexes = np.nonzero(arr)[0]
    arr_tmp = np.array(arr)
    non_zero_values = arr_tmp[non_zero_indexes]
    mean = np.mean(non_zero_values)
    return mean

print("3080Ti speedups: ", avg_speedups)
#print(geo_speedups)
gflops_mean = np.array([mean_nonzero(gflops[4]), mean_nonzero(gflops2[4]), mean_nonzero(gflops3[4])])
print("3080Ti: ", np.mean(gflops_mean))

avg_speedups = []
geo_speedups = []
for i in range(comp_n):
    avg_speedup = 0.0
    #geo_speedup = 0.0
    non_zero_count = 0
    for j in range(len(matrix_example)):
        if (gflops4[i][j] and gflops4[comp_n - 1][j]):
            avg_speedup += gflops4[comp_n - 1][j] / gflops4[i][j]
            non_zero_count += 1
        if (gflops5[i][j] and gflops5[comp_n - 1][j]):
            avg_speedup += gflops5[comp_n - 1][j] / gflops5[i][j]
            non_zero_count += 1
        if (gflops6[i][j] and gflops6[comp_n - 1][j]):
            avg_speedup += gflops6[comp_n - 1][j] / gflops6[i][j]
            non_zero_count += 1
        #geo_speedup += log(gflops[comp_n - 1][j] / gflops[i][j])
    avg_speedup /= non_zero_count
    #geo_speedup = exp(geo_speedup / len(matrix_example))
    avg_speedups.append(avg_speedup)
    #geo_speedups.append(geo_speedup)

print("A100 speedups: ", avg_speedups)
#print(geo_speedups)
gflops_mean = np.array([mean_nonzero(gflops4[4]), mean_nonzero(gflops5[4]), mean_nonzero(gflops6[4])])
print("A100: ", np.mean(gflops_mean))

width = 10
height = 12

fig, axs = plt.subplots(6, 1, figsize=(width, height), sharex=True, sharey=False)
fig.tight_layout(h_pad = 1.5)

plt.rcParams['font.size'] = 14

x = np.arange(len(matrix_example))
total_width, n = 0.5, comp_n
width = total_width / n
x = x - (total_width - width) / 2

plt.subplot(6, 1, 1)
for i in range(comp_n):
    plt.bar(x + width * i, gflops[i], width = width, label=comp_name[i])
plt.xticks([])
plt.title('RTX 3080Ti, k = 32', fontsize=14)

plt.subplot(6, 1, 2)
for i in range(comp_n):
    plt.bar(x + width * i, gflops2[i], width = width, label=comp_name[i])
plt.xticks([])
plt.title('RTX 3080Ti, k = 128', fontsize=14)

plt.subplot(6, 1, 3)
for i in range(comp_n):
    plt.bar(x + width * i, gflops3[i], width = width, label=comp_name[i])
plt.xticks([])
plt.title('RTX 3080Ti, k = 512', fontsize=14)

plt.subplot(6, 1, 4)
for i in range(comp_n):
    plt.bar(x + width * i, gflops4[i], width = width, label=comp_name[i])
plt.xticks([])
plt.title('Tesla A100, k = 32', fontsize=14)

plt.subplot(6, 1, 5)
for i in range(comp_n):
    plt.bar(x + width * i, gflops5[i], width = width, label=comp_name[i])
plt.xticks([])
plt.title('Tesla A100, k = 128', fontsize=14)

plt.subplot(6, 1, 6)
for i in range(comp_n):
    plt.bar(x + width * i, gflops6[i], width = width, label=comp_name[i])
plt.title('Tesla A100, k = 512', fontsize=14)

plt.legend(bbox_to_anchor=(1.02, 3.05), loc = 3, borderaxespad = 0, fontsize = 12)

plt.xticks(range(0, len(matrix_example)), matrix_example)
plt.xlim(-0.5, len(matrix_example) - 0.5)

plt.ylabel('GFLOPS', fontweight='bold', y = 3.5)
plt.xlabel('Test case', fontweight='bold')

#plt.legend(loc='upper left', fontsize = 12)

picname = 'output_fig/overall_perf.png'
plt.savefig(picname, bbox_inches='tight')

picname = 'output_fig/overall_perf.pdf'
plt.savefig(picname, bbox_inches='tight')

