import matplotlib.pyplot as plt
import csv
import sys
import numpy

np = [32, 64, 128, 256, 512]
time = [0.166, 0.141, 0.139, 0.164, 0.190]
occ = [74.51, 76.85, 76.95, 80.33, 81.59]
L2 = [60.32, 58.00, 53.35, 43.43, 33.31]

fontsize = 14
width = 3.5
height = 2.5

plt.rcParams['font.size'] = 16
plt.style.use('seaborn-deep')
fig = plt.figure(figsize=(width, height))

ax1 = fig.add_axes([0, 0, 1, 1])
#plt.xticks(rotation=45)
#fig.xticks()

np_range = range(len(np))

ax1.plot(np_range, occ, 'o-', label="Occupancy")
ax1.set_xlabel("np")
ax1.set_ylabel("Occupancy (%)", color = '#7E9BB7')
ax1.set_xticks(np_range)
ax1.set_xticklabels([str(item) for item in np])
 
ax2 = ax1.twinx()
ax2.plot(np_range, L2, 'o-', label="Cache Hit Rate", color = '#E18E6D')
ax2.set_ylabel("L2 Cache Hit Rate (%)", color = '#E18E6D')

picname = 'output_fig/np_select.png'
plt.savefig(picname, bbox_inches='tight')

picname = 'output_fig/np_select.pdf'
plt.savefig(picname, bbox_inches='tight')
