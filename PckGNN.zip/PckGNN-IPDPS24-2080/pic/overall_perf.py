import matplotlib.pyplot as plt
import csv
import sys
import numpy as np
from math import pow, log, exp

matrix_example = ['arxiv', 'collab', 'mag', 'ppa', 'products', 'ddi', 'proteins', 'reddit']

comp_name = ['cuSPARSE', 'GE-SpMM', 'GNNAdvisor', 'UBG', 'PckSpMM']

run_time = [
[0.202, 0.297, 0.807, 4.551, 12.798, 0.225, 7.465, 11.162], #cuSPARSE
[0.366, 0.207, 1.101, 3.301, 9.534,  0.166, 4.591, 8.373], #GE-SpMM
[0.334, 0.391, 1.170, 5.078, 13.989, 0.217, 8.331, 12.167], #GNNAdvisor
[0.208, 0.266, 0.822, 2.836, 7.181,  0.153, 4.096, 6.805], #UBG
[0.134, 0.180, 0.562, 2.534, 5.212,  0.106, 2.747, 4.200], #PckSpMM
]

comp_n = len(run_time)

nnz = [1335586, 2171132, 6152660, 43040151, 126167053, 2140089, 79255038, 114848857]
feat_len = 32
M = 1024 * 1024

gflops = []
for i in range(comp_n):
    gflops.append([1.0 * nnz[index] * feat_len / v / M for index, v in enumerate(run_time[i])])
#print(gflops)

avg_speedups = []
geo_speedups = []
for i in range(comp_n):
    avg_speedup = 0.0
    geo_speedup = 0.0
    for j in range(len(matrix_example)):
        avg_speedup += gflops[comp_n - 1][j] / gflops[i][j]
        geo_speedup += log(gflops[comp_n - 1][j] / gflops[i][j])
    avg_speedup /= len(matrix_example)
    geo_speedup = exp(geo_speedup / len(matrix_example))
    avg_speedups.append(avg_speedup)
    geo_speedups.append(geo_speedup)

print(avg_speedups)
#print(geo_speedups)

print(np.mean(gflops[4]))

width = 10
height = 3.5

plt.rcParams['font.size'] = 14
plt.figure(figsize=(width, height))

x = np.arange(len(matrix_example))
total_width, n = 0.5, comp_n
width = total_width / n
x = x - (total_width - width) / 2

for i in range(comp_n):
    plt.bar(x + width * i, gflops[i], width = width, label=comp_name[i])

plt.xticks(range(0, len(matrix_example)), matrix_example)
plt.xlim(-0.5, len(matrix_example) - 0.5)

plt.ylabel('GFLOPS', fontweight='bold')
plt.xlabel('Test case', fontweight='bold')

plt.legend(loc='upper left', fontsize = 12)

picname = 'output_fig/overall_perf.png'
plt.savefig(picname, bbox_inches='tight')

picname = 'output_fig/overall_perf.pdf'
plt.savefig(picname, bbox_inches='tight')

