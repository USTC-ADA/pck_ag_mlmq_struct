import matplotlib.pyplot as plt
import csv
import sys
import numpy as np
from math import pow, log, exp

matrix_example = ['arxiv', 'products', 'proteins']

baseline = ['GNNAdvisor', 'UBG']

aggr_time = [[1.013, 46.151, 23.183],
[0.731, 29.334, 12.722]]
total_time = [[2.071, 79.745, 23.803],
[1.827, 40.337, 13.391]]

aggr_norm = [[1.0 * item1 / item2 * 100 for item1, item2 in zip(aggr_list, total_list)] for aggr_list, total_list in zip(aggr_time, total_time)]

print(aggr_norm)

plt.style.use('seaborn-deep')

width = 5
height = 2.5

plt.rcParams['font.size'] = 14
plt.figure(figsize=(width, height))

x = np.arange(len(matrix_example))
# x = x[::-1]
# matrix_example = matrix_example[::-1]
total_width, n = 0.3, 2
width = total_width / n
x = x - (total_width - width) / 2

plt.bar(x, aggr_norm[0], width=width, label=baseline[0])
plt.bar(x + width, aggr_norm[1],  width=width, label=baseline[1])

plt.xticks(range(0, len(matrix_example)), matrix_example)
plt.xlim(-0.5, len(matrix_example) - 0.5)
plt.ylim(0, 100)

plt.ylabel('Time ratio (%)', fontweight='bold')
plt.xlabel('Test case', fontweight='bold')
#plt.ylabel('Test case', fontweight='bold')

plt.legend(loc='upper left', fontsize = 12)

picname = 'output_fig/construct.png'
plt.savefig(picname, bbox_inches='tight')

picname = 'output_fig/construct.pdf'
plt.savefig(picname, bbox_inches='tight')
