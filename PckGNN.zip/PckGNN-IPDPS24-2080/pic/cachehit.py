import matplotlib.pyplot as plt
import csv
import sys
import numpy as np
from math import pow

matrix_example = ['ddi', 'proteins', 'reddit']
method = ['Naive', 'w/ GR', 'w/ BP']

l1 = [[0.4231, 0.2790, 0.1825],
[0.5446, 0.2579, 0.3162],
[0.8558, 0.7561, 0.8001]]
l2 = [[0.9531, 0.9300, 0.4557],
[0.9377, 0.8862, 0.9063],
[0.8046, 0.8298, 0.8011]]

l1 = [[item * 100 for item in group] for group in l1]
l2 = [[item * 100 for item in group] for group in l2]

# print(l1)
# print(l2)

l1 = np.array(l1)
l2 = np.array(l2)

# naive = [item * 100 for item in naive]
# gr = [item * 100 for item in gr]
# naive_l2 = [item * 100 for item in naive_l2]
# gr_l2 = [item * 100 for item in gr_l2]

fontsize = 12
width = 5
height = 3.5

plt.rcParams['font.size'] = 14
plt.figure(figsize=(width, height))

#plt.style.use('seaborn-dark')
#plt.style.use('fivethirtyeight')
#plt.style.use('Solarize_Light2')
#print(plt.style.available)
plt.style.use('seaborn-deep')
#plt.style.use('seaborn-pastel')
#plt.style.use('seaborn-pastel')
#plt.grid(True)

#print(plt.rcParams["axes.prop_cycle"])
colorls = ['#4C72B0', '#55A868', '#C44E52']

xrange = list(range(0, len(matrix_example)))

# plt.scatter(xrange, naive, label = 'L1 hit rate w/o GR', marker = '^')
# plt.scatter(xrange, gr, label = 'L1 hit rate w/ GR', marker = '^')
# plt.scatter(xrange, naive_l2, label = 'L2 hit rate w/o GR', marker = 'o')
# plt.scatter(xrange, gr_l2, label = 'L2 hit rate w/ GR', marker = 'o')

#for i in range(0, len(matrix_example)):
#plt.plot(naive, label = 'L1 hit rate w/o Graph Reordering', marker = '^')
# plt.plot(gr, label = 'L1 hit rate w/ Graph Reordering', marker = '^')
# plt.plot(naive_l2, label = 'L2 hit rate w/o Graph Reordering', marker = 'v')
# plt.plot(gr_l2, label = 'L2 hit rate w/ Graph Reordering', marker = 'v')

for i in range(len(matrix_example)):
    plt.plot(l1[:, i], label = matrix_example[i], marker = 'o')
    #plt.plot(l2[:, i], label = matrix_example[i], marker = '^')

for i in range(len(l1)):
    print(method[i], np.mean(l1[i, :]))


# for i in range(0, len(matrix_example)):
#     plt.plot(naive[i], label = , marker = 'o')
#     plt.plot(ng[i], label = , marker = 'o')

# #print(range(0, final_subset))
plt.xticks(range(0, len(method)), method)
plt.xlim(-0.5, len(method) - 0.5)
plt.ylim(0, 100)

plt.ylabel('L1 Cache hit rate (%)', fontweight='bold')
plt.xlabel('Method', fontweight='bold')

#plt.legend(loc='upper left', fontsize = 12)
plt.legend(bbox_to_anchor=(1.05, 0.3), loc = 3, borderaxespad = 0, fontsize = 14)

picname = 'output_fig/cachehit.png'
plt.savefig(picname, bbox_inches='tight')

picname = 'output_fig/cachehit.pdf'
plt.savefig(picname, bbox_inches='tight')
