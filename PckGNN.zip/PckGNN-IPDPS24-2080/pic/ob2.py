import matplotlib.pyplot as plt
import csv
import sys
import numpy as np
from math import pow

matrix_example = ['ddi', 'proteins', 'reddit']

naive = [0.4231, 0.2790, 0.1825]
gr = [0.5446, 0.2579, 0.3162]
naive_l2 = [0.9531, 0.9300, 0.4557]
gr_l2 = [0.9377, 0.8862, 0.9063]

naive = [item * 100 for item in naive]
gr = [item * 100 for item in gr]
naive_l2 = [item * 100 for item in naive_l2]
gr_l2 = [item * 100 for item in gr_l2]

fontsize = 12
width = 4
height = 2.5

plt.rcParams['font.size'] = 14
plt.figure(figsize=(width, height))

#plt.style.use('seaborn-dark')
#plt.style.use('fivethirtyeight')
#plt.style.use('Solarize_Light2')
#print(plt.style.available)
plt.style.use('seaborn-deep')
#plt.style.use('seaborn-pastel')
#plt.style.use('seaborn-pastel')
#plt.grid(True)

xrange = list(range(0, len(matrix_example)))

markersize = 80

print(plt.rcParams["axes.prop_cycle"])
colorls = ['#4C72B0', '#55A868', '#C44E52', '#8172B2', '#CCB974', '#64B5CD']

color1 = colorls[5]
color2 = colorls[2]

plt.scatter(xrange[0], naive[0], label = 'L1 hit rate w/o GR', marker = '^', c = color1, s = markersize)
plt.scatter(xrange[1], naive[1], marker = '^', c = color1, s = markersize * 5)
plt.scatter(xrange[2], naive[2], marker = '^', c = color1, s = markersize)
plt.scatter(xrange[0], gr[0], label = 'L1 hit rate w/ GR', marker = '^', c = color2, s = markersize)
plt.scatter(xrange[1], gr[1], marker = '^', c = color2, s = markersize)
plt.scatter(xrange[2], gr[2], marker = '^', c = color2, s = markersize)
#plt.scatter(xrange, gr, label = 'L1 hit rate w/ GR', c = colorls[2], marker = '^', s = markersize)
plt.scatter(xrange[0], naive_l2[0], marker = 'o', c = color1, s = markersize * 3)
plt.scatter(xrange[1:], naive_l2[1:], label = 'L2 hit rate w/o GR', marker = 'o', c = color1, s = markersize)
plt.scatter(xrange, gr_l2, label = 'L2 hit rate w/ GR', marker = 'o', c = color2, s = markersize)

#for i in range(0, len(matrix_example)):
#plt.plot(naive, label = 'L1 hit rate w/o Graph Reordering', marker = '^')
# plt.plot(gr, label = 'L1 hit rate w/ Graph Reordering', marker = '^')
# plt.plot(naive_l2, label = 'L2 hit rate w/o Graph Reordering', marker = 'v')
# plt.plot(gr_l2, label = 'L2 hit rate w/ Graph Reordering', marker = 'v')

# for i in range(0, len(matrix_example)):
#     plt.plot(naive[i], label = , marker = 'o')
#     plt.plot(ng[i], label = , marker = 'o')

# #print(range(0, final_subset))
plt.xticks(range(0, len(matrix_example)), matrix_example)
plt.xlim(-0.5, len(matrix_example) - 0.5)
plt.ylim(0, 100)

plt.ylabel('Cache hit rate (%)', fontweight='bold')
plt.xlabel('Test case', fontweight='bold')

#plt.legend(loc='upper left', fontsize = 12)
plt.legend(bbox_to_anchor=(1.05, 0.3), loc = 3, borderaxespad = 0, fontsize = 12)

picname = 'output_fig/ob2.png'
plt.savefig(picname, bbox_inches='tight')

picname = 'output_fig/ob2.pdf'
plt.savefig(picname, bbox_inches='tight')
