import matplotlib.pyplot as plt
import csv
import sys
import numpy as np
from math import pow, log, exp

matrix_example = ['arxiv', 'collab', 'mag', 'ppa', 'products', 'ddi', 'proteins', 'reddit']

comp_name = ['PyG', 'DGL', 'GNNA', 'UBG', 'PckSpMM']

run_time = [
[5.192, 6.526, 0,      0,      0,      11.403, 0,      0], #PYG
[1.562, 2.262, 16.582, 17.467, 0,      1.809,  20.288, 0], #DGL
[1.305, 1.533, 25.322, 16.818, 57.891, 0.844,  22.849, 42.642], #GNNA
[1.316, 1.452, 19.652, 11.668, 40.161, 0.779,  13.493, 26.228], #UBG
[1.145, 1.201, 15.561, 10.572, 30.554, 0.622,  8.990,  16.740] #PckSpMM
]

baseline = [1.145, 1.201, 15.561, 10.572, 30.554, 0.622,  8.990,  16.740]

run_time2 = [
[5.091, 6.443, 83.109, 142.524, 0     , 7.923, 364.659, 782.199], #PYG
[1.485, 2.032, 9.127,  15.877,  45.605, 1.163, 19.432,  29.492], #DGL
[1.362, 1.524, 18.283, 14.399,  51.405, 0.663, 19.359,  36.109], #GNNA
[1.047, 1.191, 11.883, 6.824,   26.227, 0.378, 8.338,   16.417], #UBG
[0.830, 0.928, 8.796,  5.452,   20.160, 0.322, 6.061,   11.370] #PckSpMM
]

baseline2 = [0.830, 0.928, 8.796,  5.452,   20.160, 0.322, 6.061,   11.370]

comp_n = len(run_time)

nnz = [1335586, 2171132, 6152660, 43040151, 126167053, 2140089, 79255038, 114848857]
feat_len = 32
M = 1024 * 1024

run_time_norm = [[item / baseline[index] for index, item in enumerate(time_list)] for time_list in run_time]
run_time_norm2 = [[item / baseline2[index] for index, item in enumerate(time_list)] for time_list in run_time2]

avg_speedups = []
for i in range(len(run_time_norm)):
    avg_speedup = 0.0
    act_n = 0
    for j in run_time_norm[i]:
        if (j > 0):
            avg_speedup += j
            act_n += 1
    avg_speedups.append(avg_speedup / act_n)
print(avg_speedups)

avg_speedups = []
for i in range(len(run_time_norm2)):
    avg_speedup = 0.0
    act_n = 0
    for j in run_time_norm2[i]:
        if (j > 0):
            avg_speedup += j
            act_n += 1
    avg_speedups.append(avg_speedup / act_n)
print(avg_speedups)

# avg_speedups = []
# geo_speedups = []
# for i in range(comp_n):
#     avg_speedup = 0.0
#     geo_speedup = 0.0
#     for j in range(len(matrix_example)):
#         avg_speedup += gflops[comp_n - 1][j] / gflops[i][j]
#         geo_speedup += log(gflops[comp_n - 1][j] / gflops[i][j])
#     avg_speedup /= len(matrix_example)
#     geo_speedup = exp(geo_speedup / len(matrix_example))
#     avg_speedups.append(avg_speedup)
#     geo_speedups.append(geo_speedup)

# print(avg_speedups)
#print(geo_speedups)

# print(run_time_norm)

#print(np.mean(gflops))

width = 10
height = 4

fig, axs = plt.subplots(2,1, figsize=(width, height), sharex=True, sharey=False)
fig.tight_layout(h_pad = 1.5)

x = np.arange(len(matrix_example))
total_width, n = 0.5, comp_n
width = total_width / n
x = x - (total_width - width) / 2

plt.rcParams['font.size'] = 14

plt.subplot(2, 1, 1)
for i in range(comp_n):
    plt.bar(x + width * i, run_time_norm[i], width = width, label=comp_name[i])

plt.ylim(0, 3)
plt.xticks([])
plt.title('RTX 3080Ti', fontsize=14)

plt.subplot(2, 1, 2)
for i in range(comp_n):
    plt.bar(x + width * i, run_time_norm2[i], width = width, label=comp_name[i])

plt.xticks(range(0, len(matrix_example)), matrix_example)
plt.xlim(-0.5, len(matrix_example) - 0.5)
plt.ylim(0, 3)
plt.title('Tesla A100', fontsize=14)

plt.xlabel("Test case", fontweight='bold')
plt.ylabel("Normalized time", fontweight='bold', y = 1.0)

#plt.legend(loc='upper left', fontsize = 12)
plt.legend(bbox_to_anchor=(1.02, 0.65), loc = 3, borderaxespad = 0, fontsize = 12)

picname = 'output_fig/end_to_end.png'
plt.savefig(picname, bbox_inches='tight')

picname = 'output_fig/end_to_end.pdf'
plt.savefig(picname, bbox_inches='tight')

# plt.rcParams['font.size'] = 14
# plt.figure(figsize=(width, height))

# x = np.arange(len(matrix_example))
# total_width, n = 0.5, comp_n
# width = total_width / n
# x = x - (total_width - width) / 2

# for i in range(comp_n):
#     plt.bar(x + width * i, run_time_norm[i], width = width, label=comp_name[i])

# plt.xticks(range(0, len(matrix_example)), matrix_example)
# plt.xlim(-0.5, len(matrix_example) - 0.5)
# plt.ylim(0, 3)

# plt.ylabel('Normalized time', fontweight='bold')
# plt.xlabel('Test case', fontweight='bold')

# plt.legend(loc='upper left', fontsize = 12)

# picname = 'output_fig/end_to_end.png'
# plt.savefig(picname, bbox_inches='tight')

# picname = 'output_fig/end_to_end.pdf'
# plt.savefig(picname, bbox_inches='tight')

