#pragma once

#include <omp.h>
#include <iostream>
#include <algorithm>
#include <vector>

using namespace std;

float csr_similarity_openmp(int *RowPtr, int *ColIdx, float *Vals, int m)
{

}

float csr_similarity_core(int *RowPtr, int *ColIdx, float *Vals, int m)
{
    float avg = 0.0;
    // std::cout << m << std::endl;
    // for (int i = 0; i < m + 1; i++)
    //     cout << RowPtr[i];
    // cout << endl;
    // for (int i = 0; i < RowPtr[m]; i++)
    //     cout << ColIdx[i];
    // cout << endl;

    #pragma omp parallel
    for (int i = 0; i < m; i++)
    {
        int n1 = RowPtr[i+1] - RowPtr[i];
        vector<int> set1(&ColIdx[RowPtr[i]], &ColIdx[RowPtr[i+1]]);

        // for (int j = 0; j < set1.size(); j++)
        //     cout << set1[j];

        vector<int> set3;
        set3.resize(set1.size());
        for (int j = RowPtr[i]; j < RowPtr[i+1]; j++)
        {
            int nid = ColIdx[j];
            if (nid == i)
                Vals[j] = 0;
            else
            {
                int n2 = RowPtr[nid+1] - RowPtr[nid];
                vector<int> set2(&ColIdx[RowPtr[nid]], &ColIdx[RowPtr[nid+1]]);

                set3.clear();
                set_intersection(set1.begin(), set1.end(), set2.begin(), set2.end(), back_inserter(set3));
                int common_len = set3.size();
                int n = n1;
                if (n2 > n1) n = n2;
                Vals[j] = 1.0 * common_len / n;

                //printf("%d %d %d %d %d\n", i, nid, n1, n2, common_len);
            }
            //avg += Vals[j];
        }
        // if (i % 1000 == 0)
        //     printf("%d done!\n", i);
    }

    //avg = avg / (RowPtr[m] - m);
    //cout << "Average similarity " << avg << endl;

    return avg;
}