#!/usr/bin/env python3
import torch
import math
import GNNAdvisor as GNNA
from param import *
import time

class ScatterAndGather(torch.autograd.Function):
    '''
    Basic Scatter and Gather kernel for GNN.
    Graph is undirected.
    '''
    @staticmethod
    def forward(ctx, X, inputInfo):
        ctx.inputInfo = inputInfo
        ctx.partSize, ctx.dimWorker, ctx.warpPerBlock = \
                        inputInfo.partSize, inputInfo.dimWorker, inputInfo.warpPerBlock
        X_prime = GNNA.SAG(X, inputInfo.row_pointers, inputInfo.column_index, 
                            inputInfo.degrees, inputInfo.partPtr, inputInfo.part2Node, \
                                inputInfo.partSize, inputInfo.dimWorker, inputInfo.warpPerBlock)
        return X_prime

    @staticmethod
    def backward(ctx, d_output):
        inputInfo = ctx.inputInfo
        d_input = GNNA.SAG(d_output, inputInfo.row_pointers, inputInfo.column_index, \
                                    inputInfo.degrees, inputInfo.partPtr, inputInfo.part2Node, \
                                        ctx.partSize, ctx.dimWorker, ctx.warpPerBlock)
        return d_input


class GNNAFunction(torch.autograd.Function):
    @staticmethod
    def forward(ctx, X, weight, bias, inputInfo):
        # torch.cuda.synchronize()
        # t1 = time.perf_counter()
        # ctx.save_for_backward(X, weight)
        # #print(X.size(), weight.size())
        # ctx.inputInfo = inputInfo
        # ctx.partSize, ctx.dimWorker, ctx.warpPerBlock = \
        #     inputInfo.partSize, inputInfo.dimWorker, inputInfo.warpPerBlock
        # torch.cuda.synchronize()
        # t2 = time.perf_counter()
        # save_time = (t2 - t1) * 1e6
        # ctx.save_time = save_time

        # print("[Foward]: {}\n{}\n{}\n{}\n{}".format(inputInfo.row_pointers, inputInfo.column_index, 
        #                                 inputInfo.degrees, inputInfo.partPtr, inputInfo.part2Node))    
        # print("[Foward]: partSize: {}, dimWorker: {}, warpPerBlock: {}".format(ctx.partSize, \
        #                                                     ctx.dimWorker, ctx.warpPerBlock))
        # mm_time = torch.zeros(1)
        # spmm_time = torch.zeros(1)

        X_prime, mm_time, spmm_time = GNNA.forward(X, weight, bias, inputInfo.row_pointers, inputInfo.column_index, 
                                inputInfo.degrees, inputInfo.partPtr, inputInfo.part2Node, \
                                inputInfo.partSize, inputInfo.dimWorker, inputInfo.warpPerBlock)

        # print(X.size())
        # print(weight.size())
        # X_prime = torch.mm(X, weight)
        # X_prime = GNNA.SAG(X_prime, inputInfo.row_pointers, inputInfo.column_index, 
        #                     inputInfo.degrees, inputInfo.partPtr, inputInfo.part2Node, \
        #                         inputInfo.partSize, inputInfo.dimWorker, inputInfo.warpPerBlock)
        return X_prime, spmm_time

    @staticmethod
    def backward(ctx, d_output):
        torch.cuda.synchronize()
        t1 = time.perf_counter()
        X, weight = ctx.saved_tensors
        inputInfo = ctx.inputInfo
        torch.cuda.synchronize()
        t2 = time.perf_counter()
        load_time = (t2 - t1) * 1e6

        # print("[Backward]: {}\n{}\n{}\n{}\n{}".format(inputInfo.row_pointers, inputInfo.column_index,         #                                 inputInfo.degrees, inputInfo.partPtr, inputInfo.part2Node))

        # print("[Backward]: partSize: {}, dimWorker: {}, warpPerBlock: {}".format(ctx.partSize, \
        #                                                     ctx.dimWorker, ctx.warpPerBlock))

        d_input, d_weight, mm_bw_time, spmm_bw_time = GNNA.backward(d_output, X, weight, inputInfo.row_pointers, inputInfo.column_index, 
                                        inputInfo.degrees, inputInfo.partPtr, inputInfo.part2Node,
                                        ctx.partSize, ctx.dimWorker, ctx.warpPerBlock)
        torch.cuda.synchronize()
        
        t2 = time.perf_counter()
        bw_total_time = (t2 - t1) * 1e6
        
        print("Forward total {:.2f} save time {:.2f} mm {:.2f} spmm {:.2f}".format(ctx.total_time, ctx.save_time, ctx.mm_time.item(), ctx.spmm_time.item()))
        print("Backward total {:.2f} load time {:.2f} mm {:.2f} spmm {:.2f}".format(bw_total_time, load_time, mm_bw_time.item(), spmm_bw_time.item()))
        print("--------------")
        # d_X_prime = GNNA.SAG(d_output, inputInfo.row_pointers, inputInfo.column_index, 
        #                             inputInfo.degrees, inputInfo.partPtr, inputInfo.part2Node, \
        #                                 inputInfo.partSize, inputInfo.dimWorker, inputInfo.warpPerBlock)
        # print(weight.size())
        # weight_p = weight.permute(1,0)
        # print(weight_p.size())
        # d_input =  torch.mm(d_X_prime, weight.permute(1,0));
        # d_weight = torch.mm(X.permute(1,0), d_X_prime);
        return d_input, d_weight, None

class GCNConv(torch.nn.Module):
    def __init__(self, input_dim, output_dim, weights = None, bias = None):
        super(GCNConv, self).__init__()
        if (weights == None):
            self.weights = torch.nn.Parameter(torch.randn(input_dim, output_dim))
        else:
            self.weights = torch.nn.Parameter(weights)
        if (bias == None):
            self.bias = torch.nn.Parameter(torch.randn(output_dim))
        else:
            self.bias = torch.nn.Parameter(bias)
        #self.reset_parameters()

    def reset_parameters(self):
        stdv = 1. / math.sqrt(self.weights.size(1))
        self.weights.data.uniform_(-stdv, stdv)

    def forward(self, X, inputInfo):
        '''
        @param:
        X:  the input tensor of the graph node embedding, shape: [n_nodes, n_dim].
        A:  the CSR node pointer of the graph, shape: [node, 1].
        edges: the CSR edge list of the graph, shape: [edge, 1].
        partitioin: for the graph with the part-based optimziation.
        '''
        return GNNAFunction.apply(X, self.weights, self.bias, inputInfo)


class GNNAFunction_GIN(torch.autograd.Function):
    @staticmethod
    def forward(ctx, X, weight, inputInfo, eplison):
        # print("partSize: {}, dimWorker: {}, warpPerBlock: {}".format(inputInfo.partSize, inputInfo.dimWorker, inputInfo.warpPerBlock))
        X_prime, X_agg = GNNA.forward_gin(X, weight, inputInfo.row_pointers, inputInfo.column_index, 
                                        eplison, inputInfo.partPtr, inputInfo.part2Node, 
                                        inputInfo.partSize, inputInfo.dimWorker, inputInfo.warpPerBlock)

        ctx.save_for_backward(X_agg, weight)
        ctx.inputInfo = inputInfo
        ctx.partSize, ctx.dimWorker, ctx.warpPerBlock, ctx.eplison = \
            inputInfo.partSize, inputInfo.dimWorker, inputInfo.warpPerBlock, eplison

        return X_prime

    @staticmethod
    def backward(ctx, d_output):
        
        X, weights  = ctx.saved_tensors
        inputInfo = ctx.inputInfo

        d_input, d_weights = GNNA.backward_gin(d_output, X, weights, inputInfo.row_pointers, inputInfo.column_index,
                                               ctx.eplison, inputInfo.partPtr, inputInfo.part2Node,
                                                ctx.partSize, ctx.dimWorker, ctx.warpPerBlock)
        
        return d_input, d_weights, None, None

class GINConv(torch.nn.Module):
    def __init__(self, input_dim, output_dim):
        super(GINConv, self).__init__()
        self.weights = torch.nn.Parameter(torch.randn(input_dim, output_dim))
        self.eplison = 0.5
        self.reset_parameters()

    def reset_parameters(self):
        stdv = 1. / math.sqrt(self.weights.size(1))
        self.weights.data.uniform_(-stdv, stdv)

    def forward(self, X, inputInfo):
        '''
        @param:
        X:  the input tensor of the graph node embedding, shape: [n_nodes, n_dim].
        A:  the CSR node pointer of the graph, shape: [node, 1].
        edges: the CSR edge list of the graph, shape: [edge, 1].
        partitioin: for the graph with the part-based optimziation.
        '''
        return GNNAFunction_GIN.apply(X, self.weights, inputInfo, self.eplison)