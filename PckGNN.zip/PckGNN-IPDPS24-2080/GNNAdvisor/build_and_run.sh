cd GNNConv
python setup.py install
cd ..
python 0_bench_GNNA_GCN.py