cd GNNConv
python setup.py install
cd ..