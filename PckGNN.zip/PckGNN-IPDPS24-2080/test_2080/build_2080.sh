#!/bin/bash
#SBATCH -A leo
#SBATCH -J hzd
#SBATCH -p prod
#SBATCH -w ada-server
#SBATCH -N 1
#SBATCH --ntasks-per-node=1
#SBATCH --cpus-per-task=1
#SBATCH -o /data/leo/PckGNN-IPDPS24-2080/test_2080/log
#SBATCH -e /data/leo/PckGNN-IPDPS24-2080/test_2080/err
#SBATCH -t 1-00:00:00
#SBATCH --gres=gpu:2080ti:1
#SBATCH --mem=20G

build_cmd="sh build_GNNA.sh && sh build_UBG.sh && sh build_ge.sh && sh build_KGGNN.sh"

srun -l \
--container-image "/data1/leo/image/kggnn.sqsh" \
--container-mounts "/data1/leo:/data" \
--container-mounts "/data/leo:/workspace" \
--container-remap-root \
--container-writable \
/bin/bash -c "export PS1=aa; source ~/.bashrc; conda activate gnnadvisor; cd /workspace/PckGNN-IPDPS24-2080/test; ${build_cmd}"
set +x

