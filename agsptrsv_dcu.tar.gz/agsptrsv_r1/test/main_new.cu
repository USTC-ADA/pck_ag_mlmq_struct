#include <hip/hip_runtime.h>
#include "SpTRSV.h"
#include "utils.h"
#include "YYSpTRSV.h"
#include <stdio.h>
#include <stdlib.h>
#include <hipsparse.h>
#include <hip/hip_runtime.h>
#include <sys/time.h>
#include <unistd.h>

#define VALUE_TYPE double
#define VALUE_SIZE 8

#define ERROR_THRESH 1e-4

#define REPEAT_TIME 10

#define duration(a, b) (1.0 * (b.tv_usec - a.tv_usec + (b.tv_sec - a.tv_sec) * 1.0e6))

int main(int argc, char* argv[])
{
    hipSetDevice(1);

    struct timeval tv_begin, tv_end;

    int ch;

    int input_flag = 0, graph_flag = 0, outcsv_flag = 0;
    char *input_name, *graph_name, *outcsv_name;

    while ((ch = getopt(argc, argv, "g:o:i:")) != -1)
    {
        switch (ch)
        {
            case 'g':
                graph_flag = 1;
                graph_name = optarg;
                break;
            
            case 'o':
                outcsv_flag = 1;
                outcsv_name = optarg;
                break;

            case 'i':
                input_flag = 1;
                input_name = optarg;
                break;
        }
    }

    if (input_flag == 0)
    {
        printf("[Usage]: ./main_batch -i {input_filename}\n");
        exit(1);
    }

    // Original matrix A;
    int m;
    // int n;
    // int nnzA;
    // int *csrRowPtrA;
    // int *csrColIdxA;
    // VALUE_TYPE *csrValA;

    //read_mtx(argv[1], &m, &n, &nnzA, &csrRowPtrA, &csrColIdxA, &csrValA);

    // Triangular matrix L;
    int nnzL;
    int *csrRowPtrL;
    int *csrColIdxL;
    VALUE_TYPE *csrValL;

    read_tri<VALUE_TYPE>(input_name, &m, &nnzL, &csrRowPtrL, &csrColIdxL, &csrValL);

    int layer;
    double parallelism;
    matrix_layer<VALUE_TYPE>(m, m, nnzL, csrRowPtrL, csrColIdxL, &layer, &parallelism);

    // change2trian(m, nnzA, csrRowPtrA, csrColIdxA, csrValA, 
    // &nnzL, &csrRowPtrL, &csrColIdxL, &csrValL);

    // x & randomized b
    VALUE_TYPE *x, *b;
    x = (VALUE_TYPE*)malloc(m * sizeof(VALUE_TYPE));
    b = (VALUE_TYPE*)malloc(m * sizeof(VALUE_TYPE));
    srand(0);
    for (int i = 0; i < m; i++)
    {
        b[i] = rand() * 1.0 / RAND_MAX;
    }

    // int nnz_row = 0;
    // int max_nnz = 0;
    // int max_i;
    // for (int i = 0; i < m; i++)
    // {
    //     if (csrRowPtrL[i] < csrRowPtrL[i+1] - 1 && csrColIdxL[csrRowPtrL[i+1] - 2] == i - 1)
    //     {
    //         nnz_row++;
    //     }
    //     if (csrRowPtrL[i+1] - csrRowPtrL[i] > max_nnz)
    //     {
    //         max_nnz = csrRowPtrL[i+1] - csrRowPtrL[i];
    //         max_i = i;
    //     }
    // }
    // printf("%d %d %d\n", nnz_row, max_nnz, max_i);

    PREPROCESSING_STRATEGY ps = ROW_BLOCK;
    int rb = 8;

    ptr_handler handler;
    //printf("??\n");
    // preprocessing and get handler
    handler = SpTRSV_preprocessing(m, nnzL, csrRowPtrL, csrColIdxL,
    ROW_BLOCK, 1);

    //graph_reorder_with_level(handler);

    int permutation[m];

    //matrix_reorder(handler, permutation, csrRowPtrL, csrColIdxL, csrValL);

    graph_finalize(handler);

    // printf("row ");
    // for (int i = 0; i < m + 1; i++)
    // {
    //     printf("%d ", csrRowPtrL[i]);
    // }
    // printf("\npermutation ");
    // for (int i = 0; i < m; i++)
    // {
    //     printf("%d ", permutation[i]);
    // }
    // printf("\nidx ");
    // for (int i = 0; i < nnzL; i++)
    // {
    //     printf("%d ", csrColIdxL[i]);
    // }
    // printf("\nValue ");
    // for (int i = 0; i < nnzL; i++)
    // {
    //     if (csrValL[i] == 0)
    //     {
    //         printf("%d i error!\n", i);
    //         exit(-1);
    //     }
    //     //printf("%.2f ", csrValL[i]);
    // }
    // printf("\nb ");
    // for (int i = 0; i < m; i++)
    // {
    //     printf("%.2f ", b[i]);
    // }
    // printf("\n");

    int flag;
    float sptrsv_time = 0;

    flag = 1;

    handler = SpTRSV_preprocessing(m, nnzL, csrRowPtrL, csrColIdxL,
    ps, rb);

    if (graph_flag)
    {
        write_graph(graph_name, handler, (unsigned int)-1, layer, parallelism);
    }

    printf("matrix information: location %s\n"
            "m %d nnz %d layer %d parallelism %.2f\n", 
            input_name, m, nnzL, layer, parallelism);

    // copy matrix and vector from CPU to GPU memory
    int *csrRowPtr_d, *csrColIdx_d;
    VALUE_TYPE *csrValue_d, *b_d, *x_d;
    hipMalloc(&csrRowPtr_d, (m + 1) * sizeof(int));
    hipMemcpy(csrRowPtr_d, csrRowPtrL, (m + 1) * sizeof(int), hipMemcpyHostToDevice);
    hipMalloc(&csrColIdx_d, nnzL * sizeof(int));
    hipMemcpy(csrColIdx_d, csrColIdxL, nnzL * sizeof(int), hipMemcpyHostToDevice);
    hipMalloc(&csrValue_d, nnzL * sizeof(VALUE_TYPE));
    hipMemcpy(csrValue_d, csrValL, nnzL * sizeof(VALUE_TYPE), hipMemcpyHostToDevice);
    hipMalloc(&b_d, m * sizeof(VALUE_TYPE));
    hipMemcpy(b_d, b, m * sizeof(VALUE_TYPE), hipMemcpyHostToDevice);
    hipMalloc(&x_d, m * sizeof(VALUE_TYPE));
    hipMemset(x_d, 0, sizeof(VALUE_TYPE) * m);

    SCHEDULE_STRATEGY strategy = BALANCE_AND_LOCALITY;
    sptrsv_schedule(handler, strategy);

    for (int i = 0; i < REPEAT_TIME; i++)
    {
        hipMemset(handler->get_value, 0, sizeof(int) * m);

        gettimeofday(&tv_begin, NULL);
        
        SpTRSV_executor<VALUE_TYPE>(handler, csrRowPtr_d, csrColIdx_d, csrValue_d, b_d, x_d);
        hipDeviceSynchronize();

        gettimeofday(&tv_end, NULL);

        sptrsv_time += duration(tv_begin, tv_end);
    }

    sptrsv_time /= REPEAT_TIME;

    hipMemcpy(x, x_d, m * sizeof(VALUE_TYPE), hipMemcpyDeviceToHost);

    VALUE_TYPE *b_base;
    b_base = (VALUE_TYPE*)malloc(m * sizeof(VALUE_TYPE));

    get_x_b(m, csrRowPtrL, csrColIdxL, csrValL, x, b_base);

    for (int i = 0; i < m; i++)
    {
        if (fabs(b[i] - b_base[i]) > ERROR_THRESH)
        {
            flag = 0;
            printf("Error at index %d, b = %.5f, b_base = %.5f!\n", i, b[i], b_base[i]);
            break;
        }
    }

    schedule_finalize(handler);

    graph_finalize(handler);

    //SpTRSV_finalize(handler);

    delete handler;

    printf("Solve time: %.2f us\n", sptrsv_time);
    if (flag) printf("AG-SpTRSV Correct!\n");

    if (graph_flag)
    {
        string tmp_name = graph_name;
        tmp_name += ".label";
        FILE *label_fp = fopen(tmp_name.c_str(), "w");
        fprintf(label_fp, "%d %d %d %f\n", 
        m, nnzL, layer, sptrsv_time);
    }

    // cuSparse
    hipsparseHandle_t cusparse_handler;
    hipsparseStatus_t ErrorStatus;
    ErrorStatus = hipsparseCreate(&cusparse_handler);

    hipsparseMatDescr_t desc;
    ErrorStatus = hipsparseCreateMatDescr(&desc);
    hipsparseSetMatIndexBase(desc, HIPSPARSE_INDEX_BASE_ZERO);
    hipsparseSetMatFillMode(desc, HIPSPARSE_FILL_MODE_LOWER);
    hipsparseSetMatDiagType(desc, HIPSPARSE_DIAG_TYPE_NON_UNIT);

    csrsv2Info_t cusparse_info;
    hipsparseCreateCsrsv2Info(&cusparse_info);

    int buffer_size;
#if (VALUE_SIZE == 4)
    ErrorStatus = hipsparseScsrsv2_bufferSize(cusparse_handler,
    HIPSPARSE_OPERATION_NON_TRANSPOSE, m, nnzL,
    desc, csrValue_d, csrRowPtr_d, csrColIdx_d, cusparse_info, &buffer_size);
#else
    ErrorStatus = hipsparseDcsrsv2_bufferSize(cusparse_handler,
    HIPSPARSE_OPERATION_NON_TRANSPOSE, m, nnzL,
    desc, csrValue_d, csrRowPtr_d, csrColIdx_d, cusparse_info, &buffer_size);
#endif

    if (ErrorStatus != HIPSPARSE_STATUS_SUCCESS)
    {
        printf("Error in buffersize stage!\n");
        exit(1);
    }

    void *cusparse_buffer;
    hipMalloc((void **)&cusparse_buffer, buffer_size);

#if (VALUE_SIZE == 4)
    ErrorStatus = hipsparseScsrsv2_analysis(cusparse_handler,
    HIPSPARSE_OPERATION_NON_TRANSPOSE, m, nnzL,
    desc, csrValue_d, csrRowPtr_d, csrColIdx_d, cusparse_info, 
    HIPSPARSE_SOLVE_POLICY_USE_LEVEL, cusparse_buffer);
#else
    ErrorStatus = hipsparseDcsrsv2_analysis(cusparse_handler,
    HIPSPARSE_OPERATION_NON_TRANSPOSE, m, nnzL,
    desc, csrValue_d, csrRowPtr_d, csrColIdx_d, cusparse_info, 
    HIPSPARSE_SOLVE_POLICY_USE_LEVEL, cusparse_buffer);
#endif
    if (ErrorStatus != HIPSPARSE_STATUS_SUCCESS)
    {
        printf("Error in analysis stage!\n");
        printf("hipsparse error: %d\n", ErrorStatus);
        exit(1);
    }
    int structural_zero;
    ErrorStatus = hipsparseXcsrsv2_zeroPivot(cusparse_handler, cusparse_info, &structural_zero);
    if (HIPSPARSE_STATUS_ZERO_PIVOT == ErrorStatus)
        printf("L(%d,%d) is missing\n", structural_zero, structural_zero);

    VALUE_TYPE alpha = 1.0;

    VALUE_TYPE *x_cusparse_d;
    hipMalloc(&x_cusparse_d, m * sizeof(VALUE_TYPE));

    float cusparse_time = 0;

    for (int i = 0; i < REPEAT_TIME; i++)
    {
        gettimeofday(&tv_begin, NULL);

#if (VALUE_SIZE == 4)
        ErrorStatus = hipsparseScsrsv2_solve(cusparse_handler,
        HIPSPARSE_OPERATION_NON_TRANSPOSE, m, nnzL,
        &alpha, desc, csrValue_d, csrRowPtr_d, csrColIdx_d, cusparse_info,
        b_d, x_cusparse_d, HIPSPARSE_SOLVE_POLICY_USE_LEVEL, cusparse_buffer);
#else
        ErrorStatus = hipsparseDcsrsv2_solve(cusparse_handler,
        HIPSPARSE_OPERATION_NON_TRANSPOSE, m, nnzL,
        &alpha, desc, csrValue_d, csrRowPtr_d, csrColIdx_d, cusparse_info,
        b_d, x_cusparse_d, HIPSPARSE_SOLVE_POLICY_USE_LEVEL, cusparse_buffer);
#endif
        hipDeviceSynchronize();

        gettimeofday(&tv_end, NULL);
        
        cusparse_time += duration(tv_begin, tv_end);

        if (ErrorStatus != HIPSPARSE_STATUS_SUCCESS)
        {
            printf("Error in solve stage!\n");
            exit(1);
        }
    }

    cusparse_time /= REPEAT_TIME;

    printf("Cusparse solve time: %.2f us\n", cusparse_time);

    // L has unit diagonal, so no numerical zero is reported.
    int numerical_zero;
    ErrorStatus = hipsparseXcsrsv2_zeroPivot(cusparse_handler, cusparse_info, &numerical_zero);
    if (HIPSPARSE_STATUS_ZERO_PIVOT == ErrorStatus){
        printf("L(%d,%d) is zero\n", numerical_zero, numerical_zero);
    }

    VALUE_TYPE *x_base;
    x_base = (VALUE_TYPE*)malloc(m * sizeof(VALUE_TYPE));
    memset(x_base, 0, sizeof(VALUE_TYPE)*m);
    hipMemcpy(x_base, x_cusparse_d, m * sizeof(VALUE_TYPE), hipMemcpyDeviceToHost);

    flag = 1;
    for (int i = 0; i < m; i++)
    {
        if (fabs(x[i] - x_base[i]) > ERROR_THRESH)
        {
            flag = 0;
            printf("Cusparse error at index %d, x = %.5f, x_base = %.5f!\n", i, x[i], x_base[i]);
            break;
        }
    }
    if (flag) printf("Cusparse correct!\n");

    hipFree(cusparse_buffer);
    hipFree(x_cusparse_d);

    // YYSpTRSV
    int Len;
    int *warp_num=(int *)malloc((m+1)*sizeof(int));
    if (warp_num==NULL)
        printf("warp_num error\n");
    memset(warp_num, 0, sizeof(int)*(m+1));
    
    double warp_occupy=0,element_occupy=0;
    matrix_warp<VALUE_TYPE>(m,m,nnzL,csrRowPtrL,csrColIdxL,csrValL,10,&Len,warp_num,&warp_occupy,&element_occupy);

    int *d_warp_num;
    hipMalloc((void **)&d_warp_num, Len  * sizeof(int));
    hipMemcpy(d_warp_num, warp_num, Len * sizeof(int), hipMemcpyHostToDevice);

    int num_threads = WARP_PER_BLOCK * WARP_SIZE;
    int num_blocks = ceil ((double)((Len-1)*WARP_SIZE) / (double)(num_threads));
    
    int *d_id_extractor;
    hipMalloc((void **)&d_id_extractor, sizeof(int));

    VALUE_TYPE *x_yy_d;
    hipMalloc(&x_yy_d, m * sizeof(VALUE_TYPE));

    int *yy_get_value;
    hipMalloc(&yy_get_value, m * sizeof(int));
    hipMemset(yy_get_value, 0, sizeof(int) * m);
    
    float yy_time = 0;

    for (int i = 0; i < REPEAT_TIME; i++)
    {
        hipMemset(yy_get_value, 0, sizeof(int) * m);
        hipMemset(d_id_extractor, 0, sizeof(int));
        hipMemset(x_yy_d, 0, m * sizeof(VALUE_TYPE));

        hipDeviceSynchronize();
        
        gettimeofday(&tv_begin, NULL);
        
        hipLaunchKernelGGL(yySpTRSV_csr_kernel, dim3(num_blocks), dim3(num_threads ), 0, 0, csrRowPtr_d, csrColIdx_d, 
        csrValue_d, yy_get_value, m, nnzL, b_d, x_yy_d, 0, d_warp_num, Len, d_id_extractor);
        hipDeviceSynchronize();
        
        gettimeofday(&tv_end, NULL);
        
        yy_time += duration(tv_begin, tv_end);
        
        //hipMemcpy(x_base, x_yy_d, m * sizeof(VALUE_TYPE), hipMemcpyDeviceToHost);
    }

    memset(x_base, 0, sizeof(VALUE_TYPE)*m);
    hipMemcpy(x_base, x_yy_d, m * sizeof(VALUE_TYPE), hipMemcpyDeviceToHost);

    yy_time /= REPEAT_TIME;

    printf("YYSpTRSV solve time: %.2f us\n", yy_time);

    flag = 1;
    for (int i = 0; i < m; i++)
    {
        if (fabs(x[i] - x_base[i]) > ERROR_THRESH)
        {
            flag = 0;
            printf("YYSpTRSV error at index %d, x = %.5f, x_base = %.5f!\n", i, x[i], x_base[i]);
            break;
        }
    }
    if (flag) printf("YYSpTRSV correct!\n");

    #define G (1024 * 1024 * 1024)
    #define M (1024 * 1024)

    float gflops = 1.0 * (2 * nnzL + m) / G;
    // csrValue + ColIdx + x + b + RowPtr
    float gmems = 1.0 * (nnzL * (sizeof(int) + sizeof(VALUE_TYPE)) + 
    2 * m * sizeof(VALUE_TYPE) + m * sizeof(int)) / G;

    if (outcsv_flag)
    {
        // Write to batch log
        int table_head = 0;
        if (access(outcsv_name, F_OK)) table_head = 1;

        FILE *fp_out;
        fp_out = fopen(outcsv_name, "a");

        if (table_head) fprintf(fp_out, "matrix,m,nnz,layer,parallelism,"
        "sptrsv time(us),sptrsv gflops,sptrsv memory,"
        "cusparse time(us),cusparse gflops,cusparse memory,"
        "yy time(us),yy gflops,yy memory"
        "\n");
        fprintf(fp_out, "%s,%d,%d,%d,%.2f,", input_name, m, nnzL, layer, parallelism);

        fprintf(fp_out, "%.2f,%.2f,%.2f,", sptrsv_time,
        gflops / sptrsv_time * M, gmems / sptrsv_time * M);
        fprintf(fp_out, "%.2f,%.2f,%.2f,", cusparse_time,
        gflops / cusparse_time * M, gmems / cusparse_time * M);
        fprintf(fp_out, "%.2f,%.2f,%.2f\n", yy_time,
        gflops / yy_time * M, gmems / yy_time * M);

    }

    printf("Gflops: %.4f \nMemory: %.4f\n", gflops / sptrsv_time * M, gmems / sptrsv_time * M);

    #undef G
    #undef M

    // Finalize
    hipFree(csrRowPtr_d);
    hipFree(csrColIdx_d);
    hipFree(csrValue_d);
    hipFree(x_d);
    hipFree(b_d);

}
