#include <hip/hip_runtime.h>
#include "utils.h"
#include "YYSpTRSV.h"
#include <stdio.h>
#include <stdlib.h>
#include <hipsparse.h>
#include <hip/hip_runtime.h>
#include <sys/time.h>
#include <unistd.h>

#define VALUE_TYPE float

#define ERROR_THRESH 1e-4

#define REPEAT_TIME 10

#define duration(a, b) (1.0 * (b.tv_usec - a.tv_usec + (b.tv_sec - a.tv_sec) * 1.0e6))

int main(int argc, char* argv[])
{
    hipSetDevice(1);

    struct timeval tv_begin, tv_end;

    int ch;

    int input_flag = 0, graph_flag = 0, outcsv_flag = 0;
    char *input_name, *graph_name, *outcsv_name;

    while ((ch = getopt(argc, argv, "g:o:i:")) != -1)
    {
        switch (ch)
        {
            case 'g':
                graph_flag = 1;
                graph_name = optarg;
                break;
            
            case 'o':
                outcsv_flag = 1;
                outcsv_name = optarg;
                break;

            case 'i':
                input_flag = 1;
                input_name = optarg;
                break;
        }
    }

    if (input_flag == 0)
    {
        printf("[Usage]: ./main_batch -i {input_filename}\n");
        exit(1);
    }

    // Original matrix A;
    int m;
    // int n;
    // int nnzA;
    // int *csrRowPtrA;
    // int *csrColIdxA;
    // VALUE_TYPE *csrValA;

    //read_mtx(argv[1], &m, &n, &nnzA, &csrRowPtrA, &csrColIdxA, &csrValA);

    // Triangular matrix L;
    int nnzL;
    int *csrRowPtrL;
    int *csrColIdxL;
    VALUE_TYPE *csrValL;

    read_tri(input_name, &m, &nnzL, &csrRowPtrL, &csrColIdxL, &csrValL);

    int layer;
    double parallelism;
    matrix_layer<VALUE_TYPE>(m, m, nnzL, csrRowPtrL, csrColIdxL, &layer, &parallelism);

    // change2trian(m, nnzA, csrRowPtrA, csrColIdxA, csrValA, 
    // &nnzL, &csrRowPtrL, &csrColIdxL, &csrValL);

    // x & randomized b
    VALUE_TYPE *x, *b;
    x = (VALUE_TYPE*)malloc(m * sizeof(VALUE_TYPE));
    b = (VALUE_TYPE*)malloc(m * sizeof(VALUE_TYPE));
    srand(0);
    for (int i = 0; i < m; i++)
    {
        b[i] = rand() * 1.0 / RAND_MAX;
    }

    printf("matrix information: location %s\n"
            "m %d nnz %d layer %d parallelism %.2f\n", 
            input_name, m, nnzL, layer, parallelism);

    // copy matrix and vector from CPU to GPU memory
    int *csrRowPtr_d, *csrColIdx_d;
    float *csrValue_d, *b_d, *x_d;
    hipMalloc(&csrRowPtr_d, (m + 1) * sizeof(int));
    hipMemcpy(csrRowPtr_d, csrRowPtrL, (m + 1) * sizeof(int), hipMemcpyHostToDevice);
    hipMalloc(&csrColIdx_d, nnzL * sizeof(int));
    hipMemcpy(csrColIdx_d, csrColIdxL, nnzL * sizeof(int), hipMemcpyHostToDevice);
    hipMalloc(&csrValue_d, nnzL * sizeof(float));
    hipMemcpy(csrValue_d, csrValL, nnzL * sizeof(float), hipMemcpyHostToDevice);
    hipMalloc(&b_d, m * sizeof(float));
    hipMemcpy(b_d, b, m * sizeof(float), hipMemcpyHostToDevice);
    hipMalloc(&x_d, m * sizeof(float));

    int flag;

    // YYSpTRSV
    int Len;
    int *warp_num=(int *)malloc((m+1)*sizeof(int));
    if (warp_num==NULL)
        printf("warp_num error\n");
    memset(warp_num, 0, sizeof(int)*(m+1));
    
    double warp_occupy=0,element_occupy=0;
    matrix_warp<VALUE_TYPE>(m,m,nnzL,csrRowPtrL,csrColIdxL,csrValL,10,&Len,warp_num,&warp_occupy,&element_occupy);

    int *d_warp_num;
    hipMalloc((void **)&d_warp_num, Len  * sizeof(int));
    hipMemcpy(d_warp_num, warp_num, Len * sizeof(int), hipMemcpyHostToDevice);

    int num_threads = WARP_PER_BLOCK * WARP_SIZE;
    int num_blocks = ceil ((double)((Len-1)*WARP_SIZE) / (double)(num_threads));
    
    int *d_id_extractor;
    hipMalloc((void **)&d_id_extractor, sizeof(int));

    float *x_yy_d;
    hipMalloc(&x_yy_d, m * sizeof(float));

    int *yy_get_value;
    hipMalloc(&yy_get_value, m * sizeof(int));
    hipMemset(yy_get_value, 0, sizeof(int) * m);
    
    float yy_time = 0;

    for (int i = 0; i < REPEAT_TIME; i++)
    {
        hipMemset(yy_get_value, 0, sizeof(int) * m);
        hipMemset(d_id_extractor, 0, sizeof(int));
        hipMemset(x_yy_d, 0, m * sizeof(float));

        hipDeviceSynchronize();
        
        gettimeofday(&tv_begin, NULL);
        
        hipLaunchKernelGGL(yySpTRSV_csr_kernel, dim3(num_blocks), dim3(num_threads ), 0, 0, csrRowPtr_d, csrColIdx_d, 
        csrValue_d, yy_get_value, m, nnzL, b_d, x_yy_d, 0, d_warp_num, Len, d_id_extractor);
        hipDeviceSynchronize();
        
        gettimeofday(&tv_end, NULL);
        
        yy_time += duration(tv_begin, tv_end);

    }

    yy_time /= REPEAT_TIME;

    printf("YYSpTRSV solve time: %.2f us\n", yy_time);

    if (outcsv_flag)
    {
        // Write to batch log
        int table_head = 0;
        if (access(outcsv_name, F_OK)) table_head = 1;

        FILE *fp_out;
        fp_out = fopen(outcsv_name, "a");

        #define G (1024 * 1024 * 1024)
        #define M (1024 * 1024)

        float gflops = 1.0 * (2 * nnzL + m) / G;
        // csrValue + ColIdx + x + b + RowPtr
        float gmems = 1.0 * (nnzL * (sizeof(int) + sizeof(VALUE_TYPE)) + 
        2 * m * sizeof(VALUE_TYPE) + m * sizeof(int)) / G;

        if (table_head) fprintf(fp_out, "matrix,m,nnz,layer,parallelism,"
        "yy time(us),yy gflops,yy memory"
        "\n");
        fprintf(fp_out, "%s,%d,%d,%d,%.2f,", input_name, m, nnzL, layer, parallelism);

        fprintf(fp_out, "%.2f,%.2f,%.2f\n", yy_time,
        gflops / yy_time * M, gmems / yy_time * M);

        #undef G
        #undef M
    }

    // Finalize

    hipFree(csrRowPtr_d);
    hipFree(csrColIdx_d);
    hipFree(csrValue_d);
    hipFree(x_d);
    hipFree(b_d);

}
