#include <hip/hip_runtime.h>
#include "SpTRSV.h"
#include "utils.h"
#include "YYSpTRSV.h"
#include <stdio.h>
#include <stdlib.h>
#include <hipsparse.h>
#include <hip/hip_runtime.h>
#include <sys/time.h>
#include <unistd.h>

#define VALUE_TYPE float

#define ERROR_THRESH 1e-4

#define REPEAT_TIME 10

#define duration(a, b) (1.0 * (b.tv_usec - a.tv_usec + (b.tv_sec - a.tv_sec) * 1.0e6))

int main(int argc, char* argv[])
{
    hipSetDevice(1);

    struct timeval tv_begin, tv_end;

    int ch;

    int input_flag = 0, graph_flag = 0, outcsv_flag = 0;
    char *input_name, *graph_name, *outcsv_name;

    while ((ch = getopt(argc, argv, "g:o:i:")) != -1)
    {
        switch (ch)
        {
            case 'g':
                graph_flag = 1;
                graph_name = optarg;
                break;
            
            case 'o':
                outcsv_flag = 1;
                outcsv_name = optarg;
                break;

            case 'i':
                input_flag = 1;
                input_name = optarg;
                break;
        }
    }

    if (input_flag == 0)
    {
        printf("[Usage]: ./main_batch -i {input_filename}\n");
        exit(1);
    }

    // Original matrix A;
    int m;
    // int n;
    // int nnzA;
    // int *csrRowPtrA;
    // int *csrColIdxA;
    // VALUE_TYPE *csrValA;

    //read_mtx(argv[1], &m, &n, &nnzA, &csrRowPtrA, &csrColIdxA, &csrValA);

    // Triangular matrix L;
    int nnzL;
    int *csrRowPtrL;
    int *csrColIdxL;
    VALUE_TYPE *csrValL;

    read_tri(input_name, &m, &nnzL, &csrRowPtrL, &csrColIdxL, &csrValL);

    int layer;
    double parallelism;
    matrix_layer<VALUE_TYPE>(m, m, nnzL, csrRowPtrL, csrColIdxL, &layer, &parallelism);

    // change2trian(m, nnzA, csrRowPtrA, csrColIdxA, csrValA, 
    // &nnzL, &csrRowPtrL, &csrColIdxL, &csrValL);

    // x & randomized b
    VALUE_TYPE *x, *b;
    x = (VALUE_TYPE*)malloc(m * sizeof(VALUE_TYPE));
    b = (VALUE_TYPE*)malloc(m * sizeof(VALUE_TYPE));
    srand(0);
    for (int i = 0; i < m; i++)
    {
        b[i] = rand() * 1.0 / RAND_MAX;
    }

    printf("matrix information: location %s\n"
            "m %d nnz %d layer %d parallelism %.2f\n", 
            input_name, m, nnzL, layer, parallelism);
    //printf("matrix information: row %d %d\n", csrRowPtrL[0], csrRowPtrL[m]);
    //printf("matrix information: col %d %d\n", csrColIdxL[0], csrColIdxL[nnzL-1]);
    
    // preprocessing and get handler
    PREPROCESSING_STRATEGY ps = ROW_BLOCK_THRESH;
    int row_block = 32;
    ptr_handler handler = SpTRSV_preprocessing(m, nnzL, csrRowPtrL, csrColIdxL,
    ps, row_block);

    if (graph_flag)
    {
        write_graph(graph_name, handler, 1, layer, parallelism);
    }

    SCHEDULE_STRATEGY strategy = BALANCE_AND_LOCALITY;
    sptrsv_schedule(handler, strategy);
    //simple_schedule(handler);
    //simple_schedule_workload_balance(handler);
    //simple_schedule_workload_locality(handler);
    //simple_schedule_warp_locality(handler);

    // copy matrix and vector from CPU to GPU memory
    int *csrRowPtr_d, *csrColIdx_d;
    float *csrValue_d, *b_d, *x_d;
    hipMalloc(&csrRowPtr_d, (handler->m + 1) * sizeof(int));
    hipMemcpy(csrRowPtr_d, csrRowPtrL, (handler->m + 1) * sizeof(int), hipMemcpyHostToDevice);
    hipMalloc(&csrColIdx_d, handler->nnz * sizeof(int));
    hipMemcpy(csrColIdx_d, csrColIdxL, handler->nnz * sizeof(int), hipMemcpyHostToDevice);
    hipMalloc(&csrValue_d, handler->nnz * sizeof(float));
    hipMemcpy(csrValue_d, csrValL, handler->nnz * sizeof(float), hipMemcpyHostToDevice);
    hipMalloc(&b_d, handler->m * sizeof(float));
    hipMemcpy(b_d, b, handler->m * sizeof(float), hipMemcpyHostToDevice);
    hipMalloc(&x_d, handler->m * sizeof(float));

    float sptrsv_time = 0;

    for (int i = 0; i < REPEAT_TIME; i++)
    {
        hipMemset(handler->get_value, 0, sizeof(int) * m);

        gettimeofday(&tv_begin, NULL);
        
        SpTRSV_executor<float>(handler, csrRowPtr_d, csrColIdx_d, csrValue_d, b_d, x_d);
        hipDeviceSynchronize();

        gettimeofday(&tv_end, NULL);

        sptrsv_time += duration(tv_begin, tv_end);
    }

    sptrsv_time /= REPEAT_TIME;
    
    printf("Solve time: %.2f us\n", sptrsv_time);

    hipMemcpy(x, x_d, handler->m * sizeof(float), hipMemcpyDeviceToHost);

    VALUE_TYPE *b_base;
    b_base = (VALUE_TYPE*)malloc(m * sizeof(VALUE_TYPE));

    get_x_b(m, csrRowPtrL, csrColIdxL, csrValL, x, b_base);

    int flag = 1;
    for (int i = 0; i < m; i++)
    {
        if (fabs(b[i] - b_base[i]) > ERROR_THRESH)
        {
            flag = 0;
            printf("Error at index %d, b = %.3f, b_base = %.3f!\n", i, b[i], b_base[i]);
            break;
        }
    }
    if (flag) printf("Correct!\n");

    // cuSparse
    hipsparseHandle_t cusparse_handler;
    hipsparseStatus_t ErrorStatus;
    ErrorStatus = hipsparseCreate(&cusparse_handler);

    hipsparseMatDescr_t desc;
    ErrorStatus = hipsparseCreateMatDescr(&desc);
    hipsparseSetMatIndexBase(desc, HIPSPARSE_INDEX_BASE_ZERO);
    hipsparseSetMatFillMode(desc, HIPSPARSE_FILL_MODE_LOWER);
    hipsparseSetMatDiagType(desc, HIPSPARSE_DIAG_TYPE_NON_UNIT);

    csrsv2Info_t cusparse_info;
    hipsparseCreateCsrsv2Info(&cusparse_info);

    int buffer_size;
    ErrorStatus = hipsparseScsrsv2_bufferSize(cusparse_handler,
    HIPSPARSE_OPERATION_NON_TRANSPOSE, m, nnzL,
    desc, csrValL, csrRowPtrL, csrColIdxL, cusparse_info, &buffer_size);

    if (ErrorStatus != HIPSPARSE_STATUS_SUCCESS)
    {
        printf("Error in buffersize stage!\n");
        exit(1);
    }

    void *cusparse_buffer;
    hipMalloc((void **)&cusparse_buffer, buffer_size);

    ErrorStatus = hipsparseScsrsv2_analysis(cusparse_handler,
    HIPSPARSE_OPERATION_NON_TRANSPOSE, m, nnzL,
    desc, csrValue_d, csrRowPtr_d, csrColIdx_d, cusparse_info, 
    HIPSPARSE_SOLVE_POLICY_USE_LEVEL, cusparse_buffer);
    if (ErrorStatus != HIPSPARSE_STATUS_SUCCESS)
    {
        printf("Error in analysis stage!\n");
        exit(1);
    }
    int structural_zero;
    ErrorStatus = hipsparseXcsrsv2_zeroPivot(cusparse_handler, cusparse_info, &structural_zero);
    if (HIPSPARSE_STATUS_ZERO_PIVOT == ErrorStatus)
        printf("L(%d,%d) is missing\n", structural_zero, structural_zero);

    float alpha = 1.0;

    float *x_cusparse_d;
    hipMalloc(&x_cusparse_d, handler->m * sizeof(float));

    float cusparse_time = 0;

    for (int i = 0; i < REPEAT_TIME; i++)
    {
        gettimeofday(&tv_begin, NULL);
        
        ErrorStatus = hipsparseScsrsv2_solve(cusparse_handler,
        HIPSPARSE_OPERATION_NON_TRANSPOSE, m, nnzL,
        &alpha, desc, csrValue_d, csrRowPtr_d, csrColIdx_d, cusparse_info,
        b_d, x_cusparse_d, HIPSPARSE_SOLVE_POLICY_USE_LEVEL, cusparse_buffer);
        hipDeviceSynchronize();

        gettimeofday(&tv_end, NULL);
        
        cusparse_time += duration(tv_begin, tv_end);

        if (ErrorStatus != HIPSPARSE_STATUS_SUCCESS)
        {
            printf("Error in solve stage!\n");
            exit(1);
        }
    }

    cusparse_time /= REPEAT_TIME;

    printf("Cusparse solve time: %.2f us\n", cusparse_time);

    // L has unit diagonal, so no numerical zero is reported.
    int numerical_zero;
    ErrorStatus = hipsparseXcsrsv2_zeroPivot(cusparse_handler, cusparse_info, &numerical_zero);
    if (HIPSPARSE_STATUS_ZERO_PIVOT == ErrorStatus){
        printf("L(%d,%d) is zero\n", numerical_zero, numerical_zero);
    }

    VALUE_TYPE *x_base;
    x_base = (VALUE_TYPE*)malloc(m * sizeof(VALUE_TYPE));
    hipMemcpy(x_base, x_cusparse_d, handler->m * sizeof(float), hipMemcpyDeviceToHost);

    flag = 1;
    for (int i = 0; i < m; i++)
    {
        if (fabs(x[i] - x_base[i]) > ERROR_THRESH)
        {
            flag = 0;
            printf("Cusparse error at index %d, x = %.3f, x_base = %.3f!\n", i, x[i], x_base[i]);
            break;
        }
    }
    if (flag) printf("Cusparse correct!\n");

    hipFree(cusparse_buffer);
    hipFree(x_cusparse_d);

    // YYSpTRSV
    int Len;
    int *warp_num=(int *)malloc((m+1)*sizeof(int));
    if (warp_num==NULL)
        printf("warp_num error\n");
    memset(warp_num, 0, sizeof(int)*(m+1));
    
    double warp_occupy=0,element_occupy=0;
    matrix_warp<VALUE_TYPE>(m,m,nnzL,csrRowPtrL,csrColIdxL,csrValL,10,&Len,warp_num,&warp_occupy,&element_occupy);

    int *d_warp_num;
    hipMalloc((void **)&d_warp_num, Len  * sizeof(int));
    hipMemcpy(d_warp_num, warp_num, Len * sizeof(int), hipMemcpyHostToDevice);

    int num_threads = WARP_PER_BLOCK * WARP_SIZE;
    int num_blocks = ceil ((double)((Len-1)*WARP_SIZE) / (double)(num_threads));
    
    int *d_id_extractor;
    hipMalloc((void **)&d_id_extractor, sizeof(int));

    float *x_yy_d;
    hipMalloc(&x_yy_d, handler->m * sizeof(float));
    
    float yy_time = 0;

    for (int i = 0; i < REPEAT_TIME; i++)
    {
        hipMemset(handler->get_value, 0, sizeof(int) * m);
        hipMemset(d_id_extractor, 0, sizeof(int));
        
        gettimeofday(&tv_begin, NULL);
        
        hipLaunchKernelGGL(yySpTRSV_csr_kernel, dim3(num_blocks), dim3(num_threads ), 0, 0, csrRowPtr_d, csrColIdx_d, 
        csrValue_d, handler->get_value, m, nnzL, b_d, x_yy_d, 0, d_warp_num, Len, d_id_extractor);
        hipDeviceSynchronize();
        
        gettimeofday(&tv_end, NULL);
        
        yy_time += duration(tv_begin, tv_end);
        
        //hipMemcpy(x_base, x_yy_d, m * sizeof(VALUE_TYPE), hipMemcpyDeviceToHost);
    }

    hipMemcpy(x_base, x_yy_d, m * sizeof(float), hipMemcpyDeviceToHost);

    yy_time /= REPEAT_TIME;

    printf("YYSpTRSV solve time: %.2f us\n", yy_time);

    flag = 1;
    for (int i = 0; i < m; i++)
    {
        if (fabs(x[i] - x_base[i]) > ERROR_THRESH)
        {
            flag = 0;
            printf("YYSpTRSV error at index %d, x = %.3f, x_base = %.3f!\n", i, x[i], x_base[i]);
            break;
        }
    }
    if (flag) printf("YYSpTRSV correct!\n");

    if (outcsv_flag)
    {
        // Write to batch log
        int table_head = 0;
        if (access(outcsv_name, F_OK)) table_head = 1;

        FILE *fp_out;
        fp_out = fopen(outcsv_name, "a");

        #define G (1024 * 1024 * 1024)
        #define M (1024 * 1024)

        float gflops = 1.0 * (2 * nnzL + m) / G;
        // csrValue + ColIdx + x + b + RowPtr
        float gmems = 1.0 * (nnzL * (sizeof(int) + sizeof(VALUE_TYPE)) + 
        2 * m * sizeof(VALUE_TYPE) + m * sizeof(int)) / G;

        if (table_head) fprintf(fp_out, "matrix,m,nnz,layer,parallelism,"
        "sptrsv time(us),sptrsv gflops,sptrsv memory,"
        "cusparse time(us),cusparse gflops,cusparse memory,"
        "yy time(us),yy gflops,yy memory"
        "\n");
        fprintf(fp_out, "%s,%d,%d,%d,%.2f,", argv[1], m, nnzL, layer, parallelism);

        fprintf(fp_out, "%.2f,%.2f,%.2f,", sptrsv_time,
        gflops / sptrsv_time * M, gmems / sptrsv_time * M);
        fprintf(fp_out, "%.2f,%.2f,%.2f,", cusparse_time,
        gflops / cusparse_time * M, gmems / cusparse_time * M);
        fprintf(fp_out, "%.2f,%.2f,%.2f\n", yy_time,
        gflops / yy_time * M, gmems / yy_time * M);

        #undef G
        #undef M
    }

    // Finalize

    hipFree(csrRowPtr_d);
    hipFree(csrColIdx_d);
    hipFree(csrValue_d);
    hipFree(x_d);
    hipFree(b_d);

}
