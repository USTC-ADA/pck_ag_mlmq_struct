#!/bin/bash
# ============================================================
# Build script for SpTRSV (ROCm/HIP version)
# Target: compiler/rocm/4.0.1
# ============================================================

# Locale for perl/make (use C, C.UTF-8 not available on this cluster)
export LC_ALL=C

# Adjust this to your GPU architecture
# gfx906 = MI50/MI60 (Hygon DCU), gfx908 = MI100, gfx90a = MI200
AMDGPU_TARGET="${AMDGPU_TARGET:-gfx906}"

echo "=== Building SpTRSV HIP library ==="
cd src
make clean 2>/dev/null || true
make AMDGPU_TARGET="${AMDGPU_TARGET}" -j$(nproc)
cd ..

echo "=== Building utils library ==="
cd utils
make clean 2>/dev/null || true
make AMDGPU_TARGET="${AMDGPU_TARGET}" -j$(nproc)
cd ..

echo "=== Building test executables ==="
cd test
make clean
make AMDGPU_TARGET="${AMDGPU_TARGET}" all
cd ..

echo "=== Build complete ==="
