#!/bin/bash
# ============================================================
# SpTRSV ROCm/HIP Build and Test Commands
# Target environment: compiler/rocm/4.0.1
# ============================================================
#
# Usage:
#   bash cmd.sh build                           -- build the project
#   bash cmd.sh test MATRIX                     -- run with a matrix file
#                                                  (.gr files are auto-converted to .csr)
#   bash cmd.sh convert INPUT.gr [OUTPUT.csr]   -- convert .gr file to .csr format
#   bash cmd.sh convertbatch DIR OUTDIR         -- batch convert all .gr to .csr
#   bash cmd.sh testbatch DIR [CSV]             -- batch test all .csr (non-stop)
#   bash cmd.sh testbatch-strict DIR [CSV]      -- batch test all .csr (fail-fast)
#
#   Chain for one-shot pipeline:
#     bash cmd.sh convertbatch DIR OUTDIR && bash cmd.sh testbatch-strict OUTDIR [CSV]
# ============================================================

set -e

# -- Locale for perl/make (use C, C.UTF-8 not available on this cluster) --
export LC_ALL=C

# -- Log helper: filter out locale/perl/clang noise from build.log --
#    Uses grep -a (--text) to avoid "Binary file matches" on mixed content.
log() {
    grep -a -v -E '^(perl: warning|/bin/bash: warning|sh: warning|perl: warning: Please|\tLANGUAGE|\tLC_ALL|\tLC_CTYPE|\tLANG|are supported and installed|perl: warning: Falling back|clang-[0-9]+: warning: argument unused)'
}

# -- Project root directory --
PROJ_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "${PROJ_DIR}"

# -- GPU Architecture --
# Change this to match your GPU:
#   gfx906 = MI50 / MI60 / Hygon DCU (Vega 20)
#   gfx908 = MI100 (Arcturus)
#   gfx90a = MI200 (Aldebaran)
export AMDGPU_TARGET="${AMDGPU_TARGET:-gfx906}"

# -- Converter script paths --
GR2CSR="${PROJ_DIR}/utils/gr2csr.py"         # DIMACS text .gr -> .csr
GR2CSR_BIN="${PROJ_DIR}/utils/gr2csr_bin.py"  # binary .gr -> .csr

# ============================================================
# Auto-detect and convert input matrix file to .csr if needed.
# Accepts .gr and .csr files. Returns the path to a .csr file.
#
# IMPORTANT: All diagnostic output goes to stderr (>&2).
# stdout is reserved for the return value (the .csr file path).
# ============================================================
ensure_csr() {
    local input="$1"
    local csr_file=""

    # If already .csr, use directly
    if [[ "${input}" == *.csr ]]; then
        csr_file="${input}"
        if [ ! -f "${csr_file}" ]; then
            echo "[ERROR] File not found: ${csr_file}" >&2
            exit 1
        fi
        echo "${csr_file}"
        return 0
    fi

    # If .gr, convert to .csr (tries text parser first, then binary parser)
    if [[ "${input}" == *.gr ]]; then
        if [ ! -f "${input}" ]; then
            echo "[ERROR] File not found: ${input}" >&2
            exit 1
        fi

        # Output .csr alongside the .gr file (same directory)
        csr_file="${input%.gr}.csr"

        echo "--- Format Conversion ---" | tee -a build.log >&2
        echo "Input:  ${input} (.gr)" | tee -a build.log >&2
        echo "Output: ${csr_file} (.csr)" | tee -a build.log >&2

        convert_ok=0

        # Step 1: try DIMACS text parser
        #   Use || true because set -e + pipeline would check tee's exit, not python3's.
        #   Instead, check if the output file was created successfully.
        #   Remove stale output first to avoid false positives.
        rm -f "${csr_file}"
        echo "  Trying DIMACS text parser..." | tee -a build.log >&2
        python3 "${GR2CSR}" "${input}" "${csr_file}" 2>&1 | log | tee -a build.log >&2 || true
        if [ -f "${csr_file}" ] && [ -s "${csr_file}" ]; then
            convert_ok=1
        fi

        # Step 2: if text parser failed, try binary parser
        if [ "${convert_ok}" -eq 0 ]; then
            rm -f "${csr_file}"
            echo "  Text parser failed, trying binary parser..." | tee -a build.log >&2
            python3 "${GR2CSR_BIN}" "${input}" "${csr_file}" 2>&1 | log | tee -a build.log >&2 || true
            if [ -f "${csr_file}" ] && [ -s "${csr_file}" ]; then
                convert_ok=1
            fi
        fi

        # Step 3: check result
        if [ "${convert_ok}" -eq 0 ]; then
            rm -f "${csr_file}"
            echo "[ERROR] Both text and binary parsers failed to convert: ${input}" >&2
            echo "  For binary .gr files, ensure the format matches the expected layout." >&2
            echo "  Alternatively, convert from .mtx source via:" >&2
            echo "    cd suitesparse && g++ transfer_to_tri.cpp ../utils/utils.cpp -o transfer" >&2
            echo "    ./transfer <matrix_name>" >&2
            exit 1
        fi

        echo "Conversion done." | tee -a build.log >&2
        echo "------------------------" | tee -a build.log >&2

        echo "${csr_file}"
        return 0
    fi

    # Unknown extension: try as-is
    if [ -f "${input}" ]; then
        echo "[WARN] Unknown file extension, trying as-is: ${input}" | tee -a build.log >&2
        echo "${input}"
        return 0
    fi

    echo "[ERROR] Cannot handle file: ${input}" >&2
    exit 1
}

# ============================================================
build() {
    echo "============================================"
    echo "Building SpTRSV for ROCm/HIP"
    echo "AMD GPU Target: ${AMDGPU_TARGET}"
    echo "Date: $(date)"
    echo "============================================"

    # Reset build.log
    > build.log

    # Build HIP source library (libSpTRSV.a)
    echo "--- Building libSpTRSV.a ---" | tee -a build.log
    cd src
    make clean 2>&1 | log | tee -a ../build.log
    make AMDGPU_TARGET="${AMDGPU_TARGET}" -j$(nproc) 2>&1 | log | tee -a ../build.log
    cd ..

    # Build utils library (libutils.a)
    echo "--- Building libutils.a ---" | tee -a build.log
    cd utils
    make clean 2>&1 | log | tee -a ../build.log
    make AMDGPU_TARGET="${AMDGPU_TARGET}" -j$(nproc) 2>&1 | log | tee -a ../build.log
    cd ..

    # Build test executables
    echo "--- Building test executables ---" | tee -a build.log
    cd test
    make clean 2>&1 | log | tee -a ../build.log
    make AMDGPU_TARGET="${AMDGPU_TARGET}" all 2>&1 | log | tee -a ../build.log
    cd ..

    echo "============================================"
    echo "Build complete. Check build.log for details."
    echo "============================================"
}

# ============================================================
test_one() {
    local matrix="$1"
    if [ -z "${matrix}" ]; then
        echo "[Usage]: bash cmd.sh test {matrix_file}  (.gr or .csr)"
        exit 1
    fi

    echo "=== Running SpTRSV test ===" | tee -a build.log
    echo "Date: $(date)" | tee -a build.log

    # Auto-convert .gr to .csr if needed
    local csr_file
    csr_file=$(ensure_csr "${matrix}")
    echo "Matrix: ${csr_file}" | tee -a build.log

    ulimit -s unlimited

    ./test/main -i "${csr_file}" 2>&1 | log | tee -a build.log
}

# ============================================================
convert() {
    local input="$1"
    local output="$2"

    if [ -z "${input}" ]; then
        echo "[Usage]: bash cmd.sh convert {input.gr} [output.csr]"
        echo ""
        echo "Converts a .gr graph file to .csr format."
        echo "Supports both DIMACS text and binary .gr formats."
        echo "If output is not specified, it defaults to input_name.csr"
        exit 1
    fi

    if [ ! -f "${input}" ]; then
        echo "[ERROR] File not found: ${input}"
        exit 1
    fi

    if [ -z "${output}" ]; then
        output="${input%.gr}.csr"
    fi

    echo "Converting: ${input} -> ${output}"

    # Try text parser first, then binary
    # Remove stale output first to avoid false positives
    rm -f "${output}"
    python3 "${GR2CSR}" "${input}" "${output}" 2>&1 || true
    if [ -f "${output}" ] && [ -s "${output}" ]; then
        echo "Done (text): ${output}"
        return 0
    fi

    rm -f "${output}"
    echo "Text parser failed, trying binary parser..."
    python3 "${GR2CSR_BIN}" "${input}" "${output}" 2>&1 || true
    if [ -f "${output}" ] && [ -s "${output}" ]; then
        echo "Done (binary): ${output}"
        return 0
    fi

    echo "[ERROR] Both parsers failed to convert: ${input}"
    exit 1
}

# ============================================================
# Batch convert all .gr files in a directory to .csr
# Usage: bash cmd.sh convertbatch <input_dir> <output_dir>
# ============================================================
convertBatch() {
    local input_dir="$1"
    local output_dir="$2"

    if [ -z "${input_dir}" ] || [ -z "${output_dir}" ]; then
        echo "[Usage]: bash cmd.sh convertbatch <input_dir> <output_dir>"
        echo ""
        echo "  Batch converts all .gr files in input_dir to .csr files in output_dir."
        exit 1
    fi

    if [ ! -d "${input_dir}" ]; then
        echo "[ERROR] Input directory not found: ${input_dir}"
        exit 1
    fi

    mkdir -p "${output_dir}"

    # Collect .gr files
    shopt -s nullglob
    local files=("${input_dir}"/*.gr)
    shopt -u nullglob

    local total=${#files[@]}
    if [ "${total}" -eq 0 ]; then
        echo "[WARN] No .gr files found in ${input_dir}"
        return 0
    fi

    echo "=== Batch Convert ===" | tee -a build.log
    echo "Input:  ${input_dir}  (${total} .gr files)" | tee -a build.log
    echo "Output: ${output_dir}" | tee -a build.log
    echo "Date:   $(date)" | tee -a build.log

    local n=0 ok=0
    for gr in "${files[@]}"; do
        n=$((n + 1))
        local base=$(basename "${gr}" .gr)
        local csr="${output_dir}/${base}.csr"

        printf "[%d/%d] %s -> %s ... " "${n}" "${total}" "$(basename "${gr}")" "${base}.csr" | tee -a build.log
        convert "${gr}" "${csr}"
        echo "OK" | tee -a build.log
        ok=$((ok + 1))
    done

    echo "----------------------------------------" | tee -a build.log
    echo "Batch convert done: ${ok} succeeded (out of ${total})." | tee -a build.log
}

# ============================================================
# Batch test all .csr files in a directory, save results to CSV
# Usage: bash cmd.sh testbatch <csr_dir> [csv_file]
# ============================================================
testBatchDir() {
    local csr_dir="$1"
    local csv_file="${2:-result_$(date +%Y%m%d_%H%M%S).csv}"

    if [ -z "${csr_dir}" ]; then
        echo "[Usage]: bash cmd.sh testbatch <csr_dir> [csv_file]"
        echo ""
        echo "  Batch tests all .csr files in csr_dir, appends results to csv_file."
        echo "  Default csv_file: result_YYYYMMDD_HHMMSS.csv"
        exit 1
    fi

    if [ ! -d "${csr_dir}" ]; then
        echo "[ERROR] CSR directory not found: ${csr_dir}"
        exit 1
    fi

    shopt -s nullglob
    local files=("${csr_dir}"/*.csr)
    shopt -u nullglob

    local total=${#files[@]}
    if [ "${total}" -eq 0 ]; then
        echo "[WARN] No .csr files found in ${csr_dir}"
        return 0
    fi

    echo "=== Batch Test ===" | tee -a build.log
    echo "CSR dir:  ${csr_dir}  (${total} .csr files)" | tee -a build.log
    echo "CSV file: ${csv_file}" | tee -a build.log
    echo "Date:     $(date)" | tee -a build.log

    ulimit -s unlimited

    local n=0 ok=0 fail=0
    for csr in "${files[@]}"; do
        n=$((n + 1))
        echo "[${n}/${total}] Testing: $(basename "${csr}")" | tee -a build.log
        if ./test/main -i "${csr}" -o "${csv_file}" 2>&1 | log | tee -a build.log; then
            ok=$((ok + 1))
        else
            fail=$((fail + 1))
        fi
    done

    echo "----------------------------------------" | tee -a build.log
    echo "Batch test done: ${ok} succeeded, ${fail} failed (out of ${total})." | tee -a build.log
    echo "Results saved to: ${csv_file}" | tee -a build.log
}

# ============================================================
# Batch test all .csr files in a directory (fail-fast)
# Usage: bash cmd.sh testbatch-strict <csr_dir> [csv_file]
# ============================================================
testBatchDirStrict() {
    local csr_dir="$1"
    local csv_file="${2:-result_$(date +%Y%m%d_%H%M%S).csv}"

    if [ -z "${csr_dir}" ]; then
        echo "[Usage]: bash cmd.sh testbatch-strict <csr_dir> [csv_file]"
        echo ""
        echo "  Batch tests all .csr files in csr_dir sequentially."
        echo "  Exits immediately on first test failure."
        echo "  Default csv_file: result_YYYYMMDD_HHMMSS.csv"
        exit 1
    fi

    if [ ! -d "${csr_dir}" ]; then
        echo "[ERROR] CSR directory not found: ${csr_dir}"
        exit 1
    fi

    shopt -s nullglob
    local files=("${csr_dir}"/*.csr)
    shopt -u nullglob

    local total=${#files[@]}
    if [ "${total}" -eq 0 ]; then
        echo "[WARN] No .csr files found in ${csr_dir}"
        return 0
    fi

    echo "=== Batch Test (strict) ===" | tee -a build.log
    echo "CSR dir:  ${csr_dir}  (${total} .csr files)" | tee -a build.log
    echo "CSV file: ${csv_file}" | tee -a build.log
    echo "Date:     $(date)" | tee -a build.log

    ulimit -s unlimited

    local n=0
    for csr in "${files[@]}"; do
        n=$((n + 1))
        printf "[%d/%d] Testing: %s\n" "${n}" "${total}" "$(basename "${csr}")" | tee -a build.log

        # Capture output to temp file for potential error diagnostics
        local fail_out
        fail_out=$(mktemp)

        # Use set +e / set -e gating to reliably capture ./test/main exit code
        # through the pipe chain. PIPESTATUS[0] holds the exit code of the
        # first command in the pipeline (./test/main).
        set +e
        ./test/main -i "${csr}" -o "${csv_file}" 2>&1 | log | tee -a build.log | tee "${fail_out}"
        local test_exit_code=${PIPESTATUS[0]}
        set -e

        if [ "${test_exit_code}" -ne 0 ]; then
            {
                echo ""
                echo "[FAIL] Matrix: $(basename "${csr}")"
                echo "[FAIL] Path:   ${csr}"
                echo "[FAIL] Exit code: ${test_exit_code}"
                echo "[FAIL] Output:"
                cat "${fail_out}"
            } >&2
            rm -f "${fail_out}"
            echo "Stopped: $((n - 1)) passed, 1 failed ($(basename "${csr}"))." >&2
            exit 1
        fi
        rm -f "${fail_out}"
    done

    echo "----------------------------------------" | tee -a build.log
    echo "Batch test done: ${total} succeeded, 0 failed (out of ${total})." | tee -a build.log
    echo "Results saved to: ${csv_file}" | tee -a build.log
}

# ============================================================
show_help() {
    echo "SpTRSV ROCm/HIP - Command Reference"
    echo "===================================="
    echo ""
    echo "Environment:"
    echo "  On the supercomputer, load ROCm first:"
    echo "    module load compiler/rocm/4.0.1"
    echo ""
    echo "Commands:"
    echo "  bash cmd.sh build                        Full build (library + tests)"
    echo "  bash cmd.sh test MATRIX_FILE             Run single matrix test"
    echo "                                           .gr files auto-converted to .csr"
    echo "  bash cmd.sh convert INPUT.gr [OUTPUT.csr]  Convert .gr to .csr format"
    echo "  bash cmd.sh convertbatch DIR OUTDIR      Batch convert all .gr in DIR to OUTDIR"
    echo "  bash cmd.sh testbatch DIR [CSV]          Batch test all .csr in DIR -> CSV (non-stop)"
    echo "  bash cmd.sh testbatch-strict DIR [CSV]   Batch test all .csr in DIR -> CSV (fail-fast)"
    echo ""
    echo "Supported input formats:"
    echo "  .csr  AG-SpTRSV native CSR format (used directly)"
    echo "  .gr   DIMACS text or binary graph format"
    echo "        (auto-converted to .csr before test)"
    echo "        - Text:  p sp/a/e prefix format"
    echo "        - Binary: 64-bit LE block-CSR format"
    echo ""
    echo "GPU Architecture:"
    echo "  export AMDGPU_TARGET=gfx906      # MI50/MI60 / Hygon DCU (default)"
    echo "  export AMDGPU_TARGET=gfx908      # MI100"
    echo "  export AMDGPU_TARGET=gfx90a      # MI200"
    echo ""
    echo "All build/test output is written to build.log"
    echo ""
    echo "Examples:"
    echo "  bash cmd.sh test /path/to/matrix.csr"
    echo "  bash cmd.sh test /path/to/graph.gr"
    echo "  bash cmd.sh convert graph.gr graph.csr"
    echo "  bash cmd.sh convertbatch ./gr_files ./csr_output"
    echo "  bash cmd.sh testbatch ./csr_output results.csv"
    echo "  bash cmd.sh testbatch-strict ./csr_output results.csv"
    echo "  bash cmd.sh convertbatch ./gr_files ./csr_output && bash cmd.sh testbatch-strict ./csr_output results.csv"
}

# ============================================================
# Main
case "${1}" in
    build)
        build
        ;;
    test)
        test_one "$2"
        ;;
    convert)
        convert "$2" "$3"
        ;;
    convertbatch)
        convertBatch "$2" "$3"
        ;;
    testbatch)
        testBatchDir "$2" "$3"
        ;;
    testbatch-strict)
        testBatchDirStrict "$2" "$3"
        ;;
    *)
        show_help
        ;;
esac
