# AG-SpTRSV ROCm/HIP 移植版本

## 项目信息

- **源代码**: `/home/hdz/testpath/rocm/AG-SpTRSV`（未修改）
- **转换后代码**: `/home/hdz/testpath/rocm/agsptrsv_r1`
- **转换工具**: hipify-perl (AMD ROCm/HIP)
- **目标环境**: compiler/rocm/4.0.1, GPU 架构 gfx906 (Hygon DCU / MI50/MI60)
- **超算**: SSH `ssh -P65010 sunjw@60.245.128.10`

## 转换内容

### hipify-perl 自动转换

| CUDA | HIP/ROCm |
|------|----------|
| `#include <cuda_runtime.h>` | `#include <hip/hip_runtime.h>` |
| `#include <cusparse.h>` | `#include <hipsparse.h>` |
| `cudaMalloc/cudaFree` | `hipMalloc/hipFree` |
| `cudaMemcpy/cudaMemset` | `hipMemcpy/hipMemset` |
| `cudaDeviceSynchronize` | `hipDeviceSynchronize` |
| `cudaSetDevice` | `hipSetDevice` |
| `<<<grid, block>>>` | `hipLaunchKernelGGL(...)` |
| `cusparse*` 系列函数 | `hipsparse*` 系列函数 |

### 手动修正

1. **`__shfl_down_sync(mask, val, offset)` → `__shfl_down(val, offset)`**
   - ROCm 2.9 不支持 `_sync` 后缀的 warp shuffle 内置函数
   - 涉及文件: `SpTRSV_executor_code.cu`, `SpTRSV_executor_backup*.cu`, `SpTRSV_executor_onlywarp.cu`, `SpTRSV_executor_prefetch.cu`, `specialization.cpp`, `YYSpTRSV.h`

2. **`cusparseCreateBsrsv2Info` → `hipsparseCreateBsrsv2Info`**
   - hipify-perl 漏掉了这个函数名转换
   - 涉及文件: `test/main.cu`, `test/main_batch.cu`, `test/main_new.cu`, `test/main_search.cu`, `test/main_transform.cu`

3. **`cusparseGetErrorString` → `hipsparseGetErrorString`**
   - 同上，hipify-perl 未自动转换

### 构建系统修改

- **CMakeLists.txt**: `find_package(CUDA)` → `find_package(HIP)`, `cuda_add_library` → `hip_add_library`, 链接 `hipsparse`
- **test/Makefile**: `nvcc` → `hipcc`, `-lcusparse` → `-lhipsparse`, 新增 `--amdgpu-target` 参数
- **build.sh**: 新增 GPU 架构参数传递

## 文件结构

```
agsptrsv_r1/
├── CMakeLists.txt      # HIP/CMake 构建配置
├── build.sh            # 构建脚本
├── cmd.sh              # 命令行指令集（build/test/batch/clean）
├── tips.sh             # 超算操作命令速查
├── build.log           # 编译和测试日志
├── README.md           # 本文件
├── include/            # 头文件（已 hipify）
├── src/                # 源文件（已 hipify）
├── test/               # 测试程序（已 hipify）
│   └── Makefile        # HIP/Makefile 构建配置
├── utils/              # 工具函数
├── suitesparse/        # 矩阵数据集和转换工具
├── GNN/                # GNN 训练脚本
└── pic/                # 图表
```

## 超算使用指南

### 1. 上传代码

```bash
cd /home/hdz/testpath/rocm/
rm -rf agsptrsv_r1.tar.gz
tar czf agsptrsv_r1.tar.gz agsptrsv_r1/
scp -P65010 agsptrsv_r1.tar.gz sunjw@60.245.128.10:~/scd/

sftp -P65010 sunjw@60.245.128.10
put -a -r /home/hdz/testpath/rocm/data/mlmq/data /public/home/sunjw/scd/data/mlmq/
```

bash cmd.sh batchall /public/home/sunjw/scd/data/mlmq/data /public/home/sunjw/scd/data/ag /public/home/sunjw/scd/agsptrsv_r1/result.csv
### 2. 超算上解压和编译

```bash
# 登录超算
ssh -p65010 sunjw@60.245.128.10
# 加载 ROCm 环境（必须使用 4.0.1）
module load compiler/rocm/4.0.1

cd ~/scd
rm -rf agsptrsv_r1
tar xzf agsptrsv_r1.tar.gz
cd agsptrsv_r1

# 构建
bash cmd.sh build

# 从本机拉回编译日志
scp -P65010 sunjw@60.245.128.10:~/scd/agsptrsv_r1/build.log /home/hdz/testpath/rocm/agsptrsv_r1/
```
### 3. 运行测试

```bash
# 交互式运行（申请 GPU 节点）
srun -p debug -N 1 -n 1 --gres=dcu:1 --pty bash
module load compiler/rocm/4.0.1

cd ~/scd/agsptrsv_r1

# 单矩阵测试（支持 .gr 和 .csr 文件）
bash cmd.sh test /path/to/matrix.csr
bash cmd.sh test /path/to/graph.gr          # .gr 自动转换

# 格式转换
bash cmd.sh convert input.gr output.csr

# 批量测试
bash cmd.sh batch result.csv
```

### 4. GPU 架构选择

```bash
# 默认 gfx906 (MI50/MI60)
export AMDGPU_TARGET=gfx906

# 如需其他架构
export AMDGPU_TARGET=gfx908   # MI100
export AMDGPU_TARGET=gfx90a   # MI200
```

## 关于测试数据格式

### 项目原生格式

本项目（AG-SpTRSV）使用**自定义 CSR 文本格式**的 `.csr` 文件，格式为：

```
m nnz
csrRowPtr[0] csrRowPtr[1] ... csrRowPtr[m-1]
csrColIdx[0] csrColIdx[1] ... csrColIdx[nnz-1]
csrVal[0] csrVal[1] ... csrVal[nnz-1]
```

其中 m 为矩阵行数，nnz 为非零元个数。

### .gr 文件支持（自动转换）

**`.gr` 文件支持两种格式，`cmd.sh` 会在测试前自动检测并转换。**

| 格式 | 转换器 | 说明 |
|------|--------|------|
| DIMACS 文本 | `utils/gr2csr.py` | `p sp/a/e` 前缀格式 |
| 二进制 block-CSR | `utils/gr2csr_bin.py` | 64-bit LE block-CSR 格式 |

- 转换逻辑: 先尝试文本解析，失败后自动回退到二进制解析
- 提取下三角部分（含对角线），生成 AG-SpTRSV 所需的 CSR 格式
- `.gr` 中的对角线元素直接使用原值，缺失的对角线元素自动填充 1.0
- 边方向: 仅保留 `src >= dst` 的边（下三角 + 对角线）

```bash
# 直接使用 .gr 文件测试（自动转换）
bash cmd.sh test /path/to/graph.gr

# 手动转换
bash cmd.sh convert graph.gr graph.csr
```

### 从 Matrix Market (.mtx) 转换

```bash
cd suitesparse
g++ transfer_to_tri.cpp ../utils/utils.cpp -o transfer
./transfer matrix_name
```

或直接使用 `suitesparse/matrix_tri_list` 中列出的矩阵。

## 已知兼容性问题

### ROCm 4.0.1 hipsparse bsrsv2 支持

ROCm 4.0.1 的 hipsparse 库已完整支持 `bsrsv2`（BSR 三角求解）系列函数。
如果编译时报 `undefined reference to hipsparse*bsrsv2*`，检查是否正确链接了 `-lhipsparse`。

### __shfl_down 参数差异

ROCm 4.0.1 的 `__shfl_down` 支持 2 个或 4 个参数形式。已使用 2 参数形式以保证兼容性。

### float32 求解精度与 ERROR_THRESH（standalone 测试）

**现象**：对部分含大值、稠密行的下三角矩阵（如 `08blocks.gr`，m=300, nnz=592，其中 row 110 有 37 项、元素值最大达 100），standalone 测试 `test/main.cu` 报 `Error at index 110, b = 0.786, b_base = 0.786!`，但 `b` 与 `b_base` 三位小数完全相同，差异仅在 `1e-4~5e-4` 之间。

**根因**：纯 float32 精度问题，非算法或矩阵错误。
- `test/main.cu` 中 `VALUE_TYPE` 为 `float`，AG-SpTRSV、cuSPARSE、YYSpTRSV 三个求解器以及 CPU 参考校验 `get_x_b`（`utils/utils.cpp:332-337`，float32 spmv）全部在 float32 下运算。
- 稠密行 `b[i] = Σ L[i,j]·x[j]` 累加多次乘法后，float32 舍入误差随项数和数值幅度增长（row 110：`37 项 × 最大值 100 × eps ≈ 3.7e-5`，叠加前向传播可达 ~1e-4）。
- 原 `ERROR_THRESH = 1e-4` 对这类矩阵过于严格，刚好踩在误差边界上导致误报。
- `Cusparse correct!`（AG 解 ≈ cuSPARSE 解，两个独立求解器一致）佐证矩阵与求解均正确。

**修复**：将 `test/main.cu:14` 的 `ERROR_THRESH` 从 `1e-4` 放宽到 `1e-3`。对 float32 + 大值矩阵，`1e-3` 是工程上合理的容差。

> 注：仅 standalone 测试 `test/main.cu` 做此调整。批量测试 `main_batch.cu`、`main_search.cu`、`main_new.cu`、`main_transform.cu`、`main_yy.cu` 仍保持 `1e-4` 不变，如需对它们使用相同容差，请同步修改对应文件的 `ERROR_THRESH` 宏。

### 二进制 .gr 转换（08blocks.gr 实测）

`utils/gr2csr_bin.py` 的旧版假设的 per-block int64 布局与 `08blocks.gr` 的实际布局不符。实测 `08blocks.gr` 的二进制布局为：

```
header(4×int64) + row_ptr(m×int64, 0-based 累积) + col_idx(nnz×int32, 块内局部) + values(nnz×int32) + 8B padding
```

其中 `col_idx` 为块内局部列号，基准（0-based / 1-based）在不同块间可能不一致。`utils/gr2csr_bin.py`（自动探测版）通过**逐行对角锚定**（每行最后一个列号即对角元，全局列 = 行号）自动恢复全局列号，兼容混合基准。

> 若 `utils/gr2csr_bin.py` 自动探测失败（报 `AssertionError` 或 `No candidate layout`），可临时使用独立的精简转换脚本（见上一轮对话中的 `/tmp/conv_08blocks.py`，仅实现全局 + 对角锚定路径）。

## 踩坑记录：转换、编译、测试全流程 Bug 汇总

### 一、代码转换阶段（CUDA → HIP）

**1. hipify-perl 遗漏的函数转换**

`hipify-perl` 是 ROCm 提供的半自动 CUDA→HIP 转换工具，但存在遗漏：
- `cusparseCreateBsrsv2Info` → `hipsparseCreateBsrsv2Info` 未被转换
- `cusparseGetErrorString` → `hipsparseGetErrorString` 未被转换
- 涉及文件：`test/main.cu`, `test/main_batch.cu`, `test/main_new.cu`, `test/main_search.cu`, `test/main_transform.cu`

教训：hipify-perl 不是全自动的，转换后必须 **在目标环境下实际编译** 来发现遗漏。

**2. Warp shuffle 内置函数 API 差异**

CUDA `__shfl_down_sync(mask, val, offset)` 在 ROCm 中为 `__shfl_down(val, offset)`。
ROCm 4.0.1 支持 2 参数和 4 参数形式，已使用 2 参数形式以保证兼容性。

教训：不同 GPU 平台的 warp 操作 API 有细微差别，hipify-perl 不处理内置函数转换。

### 二、编译阶段

**3. ROCm 环境加载**

超算上必须 `module load compiler/rocm/4.0.1` 才能使用 `hipcc` 编译器。

**4. GPU 架构目标必须匹配**

实际 GPU 是 `gfx906`（Hygon D160A1, Pre-Wukong DCU），编译时必须：
```bash
export AMDGPU_TARGET=gfx906
```
传错架构（如 gfx908）会导致运行时 kernel launch 失败。

**5. 链接依赖差异**

CUDA 的 `-lcusparse` 改为 HIP 的 `-lhipsparse`，Makefile 需手动修改。

### 三、测试阶段

**6. `ulimit -m unlimited` 权限拒绝（已修复）**

HPC 集群不允许普通用户修改最大内存限制（`RLIMIT_RSS`），`set -e` 下直接导致脚本退出。
- Linux 2.4+ 内核已不再强制此限制（cgroups 管控）
- 修复：删除 `ulimit -m unlimited`，保留 `ulimit -s unlimited`

**7. `ensure_csr` 函数 stdout 污染导致空矩阵测试通过（核心 Bug）**

现象：测试输出 `m 0 nnz 0`，三个求解器均报 `Correct!`，但实际未测任何有效数据。

根因链：
- `ensure_csr()` 将所有诊断消息（"--- Format Conversion ---" 等）通过 `echo` 输出到 stdout
- `csr_file=$(ensure_csr "${matrix}")` 捕获**全部 stdout**，而非仅最后一行路径
- `csr_file` 变量内容为多行文本，导致 `-i` 传入非法文件名
- `fopen()` 失败，`read_tri()` 返回 -1，但**调用方未检查返回值**
- `m` 未初始化（栈值碰巧为 0），`malloc(0)` 分配空数组，循环 0 次全跳过，`flag` 保持为 1
- 三个求解器均在空矩阵上"通过"验证

教训：
- shell 函数通过 stdout 返回值的模式，必须 **将诊断输出重定向到 stderr**（`>&2`）或日志文件
- C/C++ 代码中必须 **检查 IO 函数返回值**（`fopen`, `fscanf`, `malloc`）
- **未初始化的变量** 在错误路径上会导致"碰巧成功"的假阳性
- `m 0 nnz 0` 但测试 "Correct!" 是危险信号，不应忽略

**8. `log()` 过滤函数的管道交互问题**

`log()` 使用 `grep -v` 过滤 perl locale 警告，但当数据流中包含二进制内容时：
- grep 输出 `Binary file (standard input) matches` 到 stderr
- `2>&1` 使得 stderr/stdout 在管道中混合
- 导致日志文件污染和输出顺序混乱

教训：过滤函数应加 `grep --text` 或 `grep -a` 强制文本模式处理。

**9. `gr2csr.py` 第 159 行死代码**

```python
n_vertices, edges = gr_to_csr(input_path) if False else parse_gr(input_path)
```
`if False` 为调试残留（永远不执行前半句），且 `gr_to_csr(input_path)` 参数类型错误——这是上次调试未清理的证据。

### 四、超算环境适配要点

**10. 登录节点 vs 计算节点**

- 登录节点无 GPU，编译可在登录节点完成，但测试必须申请计算节点
- 交互式申请：`srun -p debug -N 1 -n 1 --gres=dcu:1 --pty bash`
- 进入计算节点后需重新 `module load compiler/rocm/4.0.1`

**11. 文件路径差异**

超算上 `~` 展开为 `/public/home/sunjw`（非标准 `/home/sunjw`），脚本中使用 `~` 或绝对路径时需注意。

**12. SSH 端口**

超算 SSH 端口为 65010（非标准 22），scp/ssh 均需 `-P65010`。

**13. LOCALE 环境不全**

计算节点未生成 `C.UTF-8` locale，仅 `C` 可用。`cmd.sh` 已设置 `export LC_ALL=C` 避免 warning。

**14. 文件传输注意**

超算与本地之间用 `scp -P65010` 传输，注意：
- 先 tar 打包再传输（保留目录结构和权限）
- build.log 可以从超算拉回本地分析错误

## 项目结构说明

- `src/SpTRSV_executor.cu`: 主要执行器，包含 SpTRSV kernel
- `src/preprocessing.cu`: 预处理（依赖图构建、拓扑排序等）
- `src/schedule.cu`: 调度逻辑
- `src/finalize.cu`: 资源清理
- `src/specialization.cpp`: 代码特化
- `src/transformation.cu`: 矩阵格式转换
- `test/main.cu`: 主测试程序
- `test/main_new.cu`: 新版本测试（支持 float/double）
- `test/main_batch.cu`: 批量测试
- `test/main_search.cu`: 搜索测试
- `test/main_transform.cu`: 格式转换测试
- `test/main_yy.cu`: YYSpTRSV 算法测试
