sh build.sh

matrix_name=$1
graph_name=$2

ulimit -s unlimited
./test/main -i ${matrix_name} -g ${graph_name}
cat ${graph_name}.global ${graph_name}.node ${graph_name}.edge > ${graph_name}.graph
rm ${graph_name}.global ${graph_name}.node ${graph_name}.edge

python GNN/main.py ${graph_name}.graph
