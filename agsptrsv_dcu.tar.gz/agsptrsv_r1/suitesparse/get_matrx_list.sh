WORK_DIR=/data/SuiteSparse

ls ${WORK_DIR} | grep -v .tar.gz > matrix_list
rm matrix_tri_list
cat matrix_list | xargs -n1 -I {} sh -c "./transfer {} || true"