import random

with open('matrix_tri_list', 'r') as f:
    data = f.readlines()

with open('small_matrix_tri_list', 'w') as f2:
    for matrix in data:
        with open("/data/SuiteSparse_triangular/" + matrix.strip() + ".csr", 'r') as f:
            line = f.readline().strip().split(' ')
            nnz = int(line[0])

            if (nnz < 10000):
                f2.write(matrix)

# data = random.sample(data, 50)
# with 
#     #for line in data:
#     f.writelines(data[0: len(data) - 1])
#     f.write(data[len(data) - 1].strip())


