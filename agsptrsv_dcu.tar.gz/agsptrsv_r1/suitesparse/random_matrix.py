import random

with open('matrix_tri_list', 'r') as f:
    data = f.readlines()

data = random.sample(data, 50)
with open('matrix_tri_list_rand', 'w') as f:
    #for line in data:
    f.writelines(data[0: len(data) - 1])
    f.write(data[len(data) - 1].strip())


