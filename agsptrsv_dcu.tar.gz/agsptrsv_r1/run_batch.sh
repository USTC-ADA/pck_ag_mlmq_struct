sh build.sh

WORK_DIR=/data/SuiteSparse_triangular
MATRIX_LIST=suitesparse/matrix_tri_list
RESULT_FILE=$1

cat ${MATRIX_LIST} | xargs -n1 -I {} sh -c "./test/main -i ${WORK_DIR}/{}.csr -o ${RESULT_FILE}|| true"

