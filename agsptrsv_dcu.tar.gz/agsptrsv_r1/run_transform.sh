if [ $# -ne 1 ] && [ $# -ne 2 ]; then
    echo "[Usage]: run.sh {matrix_file_name} {specialized_code.cu | optional}"
    exit 1
fi
matrix=$1
#spe_code=$2

sh build.sh

ulimit -m unlimited
ulimit -s unlimited
./test/main_transform -i ${matrix}
#ncu --set full -o ncu_report/main -f ./test/main ${matrix} ${spe_code}

# if [ $# -eq 2 ]; then
#     cp ${spe_code} test_spe/test.cu
#     cd test_spe
#     make
#     cd ..
#     ./test_spe/main ${matrix}
#     #ncu --set full -o ncu_report/spe_main -f ./test_spe/main ${matrix}
# fi
#ncu --set full -o out -f ./test/main ${matrix}