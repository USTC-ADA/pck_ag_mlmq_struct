#!/bin/bash
# ============================================================
# tips.sh — 超算操作命令速查
# 项目: AG-SpTRSV ROCm/HIP 移植 (agsptrsv_r1)
# 目标: compiler/rocm/4.0.1, gfx906
# ============================================================
#
# 使用方法: 在本地项目根目录执行
#   bash tips.sh
#
# 本文件列出提交超算、编译、测试的全流程命令。
# 本地只做编程，超算上由 cmd.sh 执行编译和测试。
# ============================================================

set -e

# -- 配置 --
SSH_HOST="sunjw@60.245.128.10"
SSH_PORT="65010"
REMOTE_DIR="~/scd"
PROJ_NAME="agsptrsv_r1"
LOCAL_DIR="/home/hdz/testpath/rocm/${PROJ_NAME}"
MODULE_LOAD="compiler/rocm/4.0.1"
AMDGPU_TARGET="gfx906"

# ============================================================
# 显示操作指南
# ============================================================
show_tips() {
    echo "============================================"
    echo "  AG-SpTRSV 超算操作命令速查"
    echo "  项目: ${PROJ_NAME}"
    echo "  目标: ${MODULE_LOAD}, ${AMDGPU_TARGET}"
    echo "============================================"
    echo ""
    echo "【1. 本地打包】"
    echo "--------------------------------------------"
    echo "  cd /home/hdz/testpath/rocm/"
    echo "  rm -rf ${PROJ_NAME}.tar.gz"
    echo "  tar czf ${PROJ_NAME}.tar.gz ${PROJ_NAME}/"
    echo ""
    echo "【2. 上传到超算】"
    echo "--------------------------------------------"
    echo "  scp -P${SSH_PORT} ${PROJ_NAME}.tar.gz ${SSH_HOST}:${REMOTE_DIR}/"
    echo ""
    echo "【3. 登录超算 & 编译】"
    echo "--------------------------------------------"
    echo "  ssh -P${SSH_PORT} ${SSH_HOST}"
    echo "  module load ${MODULE_LOAD}"
    echo "  cd ${REMOTE_DIR}"
    echo "  rm -rf ${PROJ_NAME}"
    echo "  tar xzf ${PROJ_NAME}.tar.gz"
    echo "  cd ${PROJ_NAME}"
    echo "  bash cmd.sh build"
    echo ""
    echo "【4. 交互式运行测试（需申请 GPU 节点）】"
    echo "--------------------------------------------"
    echo "  srun -p debug -N 1 -n 1 --gres=dcu:1 --pty bash"
    echo "  module load ${MODULE_LOAD}"
    echo "  cd ${REMOTE_DIR}/${PROJ_NAME}"
    echo ""
    echo "  # 单矩阵测试 (.gr 自动转换)"
    echo "  bash cmd.sh test /path/to/matrix.csr"
    echo "  bash cmd.sh test /path/to/graph.gr"
    echo ""
    echo "  # 批量测试"
    echo "  bash cmd.sh batch result.csv suitesparse/matrix_tri_list"
    echo ""
    echo "  # 格式转换"
    echo "  bash cmd.sh convert input.gr output.csr"
    echo ""
    echo "【5. 拉回编译日志到本地】"
    echo "--------------------------------------------"
    echo "  scp -P${SSH_PORT} ${SSH_HOST}:${REMOTE_DIR}/${PROJ_NAME}/build.log ${LOCAL_DIR}/"
    echo ""
    echo "【6. 一步到位：打包+上传+编译+拉回日志】"
    echo "--------------------------------------------"
    echo "  cd /home/hdz/testpath/rocm/"
    echo "  rm -rf ${PROJ_NAME}.tar.gz"
    echo "  tar czf ${PROJ_NAME}.tar.gz ${PROJ_NAME}/"
    echo "  scp -P${SSH_PORT} ${PROJ_NAME}.tar.gz ${SSH_HOST}:${REMOTE_DIR}/"
    echo "  ssh -P${SSH_PORT} ${SSH_HOST} \\"
    echo "    'module load ${MODULE_LOAD} && cd ${REMOTE_DIR} && rm -rf ${PROJ_NAME} && tar xzf ${PROJ_NAME}.tar.gz && cd ${PROJ_NAME} && bash cmd.sh build'"
    echo "  scp -P${SSH_PORT} ${SSH_HOST}:${REMOTE_DIR}/${PROJ_NAME}/build.log ${LOCAL_DIR}/"
    echo ""
    echo "【7. 清理】"
    echo "--------------------------------------------"
    echo "  # 超算上清理编译产物"
    echo "  ssh -P${SSH_PORT} ${SSH_HOST} 'cd ${REMOTE_DIR}/${PROJ_NAME} && bash cmd.sh clean'"
    echo ""
    echo "  # 本地清理 tar 包"
    echo "  rm -f ${LOCAL_DIR}/../${PROJ_NAME}.tar.gz"
    echo ""
    echo "【环境信息 (arch.log)】"
    echo "--------------------------------------------"
    echo "  ROCm:      4.0.1"
    echo "  hipcc:     /public/software/compiler/rocm/rocm-4.0.1/hip/bin/hipcc"
    echo "  GCC:       7.3.1 (devtoolset-7)"
    echo "  OS:        CentOS 7"
    echo "  GPU:       gfx906 (Hygon DCU)"
    echo "  Locale:    C (C.UTF-8 not available)"
    echo "  PyTorch:   1.10.1+rocm4.0.1"
    echo ""
    echo "【注意】"
    echo "--------------------------------------------"
    echo "  - 登录节点无 GPU，编译可在登录节点完成"
    echo "  - 测试必须在计算节点 (srun 申请 GPU)"
    echo "  - locale 仅 C 可用，cmd.sh 已设置 LC_ALL=C"
    echo "  - ulimit -m 在 HPC 上权限拒绝，已从所有脚本移除"
    echo "  - build.log 中的 perl locale warning 可忽略"
    echo ""
    echo "============================================"
}

# ============================================================
# Main: 显示指南
# ============================================================
show_tips
