if [ $# -ne 2 ]; then
    echo "[Usage]: run.sh {matrix_list} {output_csv}"
    exit 1
fi
matrix_list=$1
output_csv=$2

sh build.sh
cd test
make clean
make VERBOSE=1
cd ..

matrix_dir=/data/SuiteSparse_triangular/
data_dir=/data/full_double_0301/


ulimit -s unlimited
cat ${matrix_list} | xargs -n1 -I {} \
sh -c "./test/main_search -i ${matrix_dir}{}.csr -g ${data_dir}{} -o ${output_csv} \
&& cat ${data_dir}{}.global ${data_dir}{}.node ${data_dir}{}.edge ${data_dir}{}.label > ${data_dir}{}.data \
&& rm ${data_dir}{}.global ${data_dir}{}.node ${data_dir}{}.edge ${data_dir}{}.label || true"
#ncu --set full -o ncu_report/main -f ./test/main ${matrix} ${spe_code}

# if [ $# -eq 2 ]; then
#     cp ${spe_code} test_spe/test.cu
#     cd test_spe
#     make
#     cd ..
#     ./test_spe/main ${matrix}
#     #ncu --set full -o ncu_report/spe_main -f ./test_spe/main ${matrix}
# fi
#ncu --set full -o out -f ./test/main ${matrix}