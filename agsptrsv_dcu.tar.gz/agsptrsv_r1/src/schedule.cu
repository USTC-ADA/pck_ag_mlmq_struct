#include "../include/schedule.h"

void schedule_node(vector<ptr_node> &schedule_vec, ptr_node current_node, int current_warp)
{
    schedule_vec.push_back(current_node);
    current_node->warp_id = current_warp;
    current_node->warp_sche_level = schedule_vec.size() - 1;
}

void schedule_info_hosttodevice(ptr_handler handler)
{
    node_info *info_h[WARP_NUM];

    hipMalloc(&handler->schedule_level_d, WARP_NUM * sizeof(int));
    hipMalloc(&handler->schedule_info_d, WARP_NUM * sizeof(node_info*));

    hipMemcpy(handler->schedule_level_d, handler->schedule_level, WARP_NUM * sizeof(int), hipMemcpyHostToDevice);

    for (int i = 0; i < WARP_NUM; i++)
    {
        int level = handler->schedule_level[i];
        hipMalloc(&info_h[i], level * sizeof(node_info));

        //if (level) printf("i %d level %d\n", i, level);
        hipMemcpy(info_h[i], handler->schedule_info[i], level * sizeof(node_info), hipMemcpyHostToDevice);
    }

    hipMemcpy(handler->schedule_info_d, info_h, WARP_NUM * sizeof(node_info*), hipMemcpyHostToDevice);

    // for (int i = 0; i < WARP_NUM; i++)
    //     hipFree(info_h[i]);
}

void transfer_to_2D(ptr_handler handler)
{
    // transform from vector to 2D array
    handler->schedule_level = (int*)malloc(WARP_NUM * sizeof(int));
    handler->schedule_info = (node_info**)malloc(WARP_NUM * sizeof(node_info*));
    for (int i = 0; i < WARP_NUM; i++)
    {
        int schedule_level = handler->warp_schedule[i].size();
        handler->schedule_level[i] = schedule_level;

        if (schedule_level == 0)
        {
            handler->schedule_info[i] = NULL;
            continue;
        }

        handler->schedule_info[i] = (node_info*)malloc(schedule_level * sizeof(node_info));

        for (int j = 0; j < schedule_level; j++)
        {
            handler->schedule_info[i][j] = handler->warp_schedule[i][j]->info;
            // if (i == 0 || i == 1) printf("warp i %d num j %d row %d end %d\n", 
            // i, j, handler->warp_schedule[i][j]->info.start_row, handler->warp_schedule[i][j]->info.end_row);
        }
    }
}

void show_imbalance(ptr_handler handler)
{
    // print load imbalance
    int max_nnz, min_nnz;
    int sum = 0;
    for (int j = 0; j < handler->warp_schedule[0].size(); j++)
    {
        sum += handler->warp_schedule[0][j]->num_nnz;
    }
    max_nnz = min_nnz = sum;
    for (int i = 1; i < WARP_NUM; i++)
    {
        sum = 0;
        for (int j = 0; j < handler->warp_schedule[i].size(); j++)
        {
            sum += handler->warp_schedule[i][j]->num_nnz;
        }
        if (sum > max_nnz) max_nnz = sum;
        if (sum < min_nnz) min_nnz = sum;
    }
    printf("simple schedule: max_nnz %d min_nnz %d\n", max_nnz, min_nnz);
}

void simple_schedule(ptr_handler handler)
{
    ptr_graph graph = handler->graph;

    queue<ptr_node> topo_queue;

    // inital
    for (auto iter = graph->start_nodes.begin(); iter != graph->start_nodes.end(); iter++)
    {
        topo_queue.push(*iter);
        //(*iter)->info.elim = READ_WRITE_BLOCK;
    }

    int count = 0;

    //vector<ptr_node> warp_schedule[WARP_NUM];

    int old_level = 0;

    int current_warp = 0;
    // topological sort
    while(!topo_queue.empty())
    {
        ptr_node current_node = topo_queue.front();
        for (auto iter = current_node->child.begin(); iter != current_node->child.end(); iter++)
        {
            (*iter)->in_degree_tmp++;
            if ((*iter)->in_degree_tmp == (*iter)->in_degree)
            {
                topo_queue.push(*iter);
                (*iter)->in_degree_tmp = 0;
                // (*iter)->info.elim = READ_WRITE_BLOCK;
                // if (!is_nearwarp((*iter)->warp_id, current_node->warp_id))
                // {
                //     //printf("No elim\n");
                //     (*iter)->info.elim = NO_ELIM;
                //     current_node->info.elim = NO_ELIM;
                //     count++;
                // }
            }
        }

        if (current_node->topo_level > old_level)
        {
            old_level = current_node->topo_level;
            current_warp = 0;
        }

        // static schedule in turn
        schedule_node(handler->warp_schedule[current_warp], current_node, current_warp);
        current_warp = (current_warp + 1) % WARP_NUM;

        //if (current_node->info.start_row == 0) printf("%d %d\n", current_warp)

        topo_queue.pop();

    }
    //printf("count %d\n", count);

}

// schedule to warp with least workload
void simple_schedule_workload_balance(ptr_handler handler)
{
    ptr_graph graph = handler->graph;

    queue<ptr_node> topo_queue;

    // inital
    for (auto iter = graph->start_nodes.begin(); iter != graph->start_nodes.end(); iter++)
    {
        topo_queue.push(*iter);
    }

    //vector<ptr_node> warp_schedule[WARP_NUM];
    int workload[WARP_NUM];

    for (int i = 0; i < WARP_NUM; i++) workload[i] = 0;

    // topological sort
    while(!topo_queue.empty())
    {
        ptr_node current_node = topo_queue.front();
        for (auto iter = current_node->child.begin(); iter != current_node->child.end(); iter++)
        {
            // if (!current_node->id) 
            // {
            //     printf("queue node %d child %d\n", current_node->id, (*iter)->id);
            //     printf("in_degree_tmp %d in_degree %d\n", (*iter)->in_degree_tmp, 
            //     (*iter)->in_degree);
            // }

            (*iter)->in_degree_tmp++;
            if ((*iter)->in_degree_tmp == (*iter)->in_degree)
            {
                topo_queue.push(*iter);
                (*iter)->in_degree_tmp = 0;
            }
        }
        // choose the warp with least workload
        int least_nnz = workload[0], least_i = 0;
        for (int i = 1; i < WARP_NUM; i++)
        {
            if (workload[i] < least_nnz)
            {
                least_nnz = workload[i];
                least_i = i;
            }
        }
        schedule_node(handler->warp_schedule[least_i], current_node, least_i);
        workload[least_i] += current_node->num_nnz;
        // warp_schedule[least_i].push_back(current_node);
        // current_node->warp_id = least_i;
        // current_node->warp_sche_level = warp_schedule[least_i].size() - 1;

        topo_queue.pop();
    }

}

// schedule child node to the warp of its last parent node
void simple_schedule_warp_locality(ptr_handler handler)
{
    ptr_graph graph = handler->graph;

    queue<ptr_node> topo_queue;

    //vector<ptr_node> warp_schedule[WARP_NUM];

    float workload[WARP_NUM];

    for (int i = 0; i < WARP_NUM; i++)
        workload[i] = 0;
    
    int current_warp = 0;
    // inital
    for (auto iter = graph->start_nodes.begin(); iter != graph->start_nodes.end(); iter++)
    {
        topo_queue.push(*iter);
        // static schedule in turn
        schedule_node(handler->warp_schedule[current_warp], (*iter), current_warp);
        workload[current_warp] += (*iter)->num_nnz;
        // warp_schedule[current_warp].push_back(*iter);
        // (*iter)->warp_id = current_warp;
        // current_node->warp_sche_level = warp_schedule[current_warp].size() - 1;
        current_warp = (current_warp + 1) % WARP_NUM;
    }

    while(!topo_queue.empty())
    {
        ptr_node current_node = topo_queue.front();
        for (auto iter = current_node->child.begin(); iter != current_node->child.end(); iter++)
        {
            (*iter)->in_degree_tmp++;
            if ((*iter)->in_degree_tmp == (*iter)->in_degree)
            {
                topo_queue.push(*iter);
                (*iter)->in_degree_tmp = 0;
                int parent_block = current_node->warp_id / WARP_NUM_PER_BLOCK;
                int start_warp = parent_block * WARP_NUM_PER_BLOCK;

                int min_load = workload[start_warp];
                current_warp = start_warp;

                for (int i = start_warp + 1; i < start_warp + WARP_NUM_PER_BLOCK; i++)
                    if (workload[i] < min_load)
                    {
                        min_load = workload[i];
                        current_warp = i;
                    }
                schedule_node(handler->warp_schedule[current_warp], (*iter), current_warp);
                workload[current_warp] += current_node->num_nnz;
                // warp_schedule[current_warp].push_back(*iter);
                // (*iter)->warp_id = current_node->warp_id;
            }
        }

        topo_queue.pop();
    }

}

// considering workload-balance and data-locality at the same time
void simple_schedule_workload_locality(ptr_handler handler)
{
    ptr_graph graph = handler->graph;

    queue<ptr_node> topo_queue;

    //vector<ptr_node> warp_schedule[WARP_NUM];

    float workload[WARP_NUM];

    for (int i = 0; i < WARP_NUM; i++)
        workload[i] = 0;

    // inital
    for (auto iter = graph->start_nodes.begin(); iter != graph->start_nodes.end(); iter++)
    {
        topo_queue.push(*iter);
    }

    while(!topo_queue.empty())
    {
        ptr_node current_node = topo_queue.front();
        for (auto iter = current_node->child.begin(); iter != current_node->child.end(); iter++)
        {
            (*iter)->in_degree_tmp++;
            if ((*iter)->in_degree_tmp == (*iter)->in_degree)
            {
                topo_queue.push(*iter);
                (*iter)->in_degree_tmp = 0;
            }
        }

        // record the number of parent nodes in each block
        int block_parent[BLOCK_NUM];
        int block_parent_sum = 0;
        for (int i = 0; i < BLOCK_NUM; i++) block_parent[i] = 0;
        for (auto iter = current_node->parent.begin(); iter != current_node->parent.end(); iter++)
        {
            int block_id = (*iter)->warp_id / WARP_NUM_PER_BLOCK;
            block_parent[block_id]++;
        }
        for (int i = 0; i < BLOCK_NUM; i++) block_parent_sum += block_parent[i];

        // choose the warp with the minimum total workload
        // workload = comm_alpha * inter_block_comm + calc_alpha * num_nnz;
        float comm_alpha = 1.0;
        float calc_alpha = 1.0;
        float min_total_workload = -1;
        int least_i = -1;
        for (int i = 0; i < WARP_NUM; i++)
        {
            int current_block_id = i / WARP_NUM_PER_BLOCK;
            int inter_block_comm = block_parent_sum - block_parent[current_block_id];

            float new_workload = comm_alpha * inter_block_comm + calc_alpha * current_node->num_nnz;
            
            if (workload[i] + new_workload < min_total_workload || min_total_workload == -1)
            {
                min_total_workload = workload[i] + new_workload;
                least_i = i;
            }
        }

        schedule_node(handler->warp_schedule[least_i], current_node, least_i);
        //warp_schedule[least_i].push_back(current_node);
        //current_node->warp_id = least_i;
        workload[least_i] = min_total_workload;

        topo_queue.pop();
    }

}

void schedule_structured(ptr_handler handler)
{
    ptr_graph graph = handler->graph;

    queue<ptr_node> topo_queue;

    //vector<ptr_node> warp_schedule[WARP_NUM];

    float sm_workload[SM_NUM];
    float warp_workload[SM_NUM][WARP_NUM_PER_SM];

    for (int i = 0; i < SM_NUM; i++)
    {
        sm_workload[i] = 0;
        for (int j = 0; j < WARP_NUM_PER_SM; j++)
            warp_workload[i][j] = 0;
    }

    int current_sm = 0;
    int current_warp = 0;
    // inital
    for (auto iter = graph->start_nodes.begin(); iter != graph->start_nodes.end(); iter++)
    {
        topo_queue.push(*iter);
        int swarp = get_warp_id(current_sm, current_warp);
        schedule_node(handler->warp_schedule[swarp], *iter, swarp);

        sm_workload[current_sm] += (*iter)->num_nnz;
        warp_workload[current_sm][current_warp] += (*iter)->num_nnz;

        current_sm++;
        if (current_sm >= SM_NUM)
        {
            current_warp = (current_warp + 1) % WARP_NUM_PER_SM;
            current_sm = 0;
        }

        printf("start row 0 %d\n", (*iter)->locality_node->info.start_row);

        //printf("row %d new_warp %d\n", (*iter)->info.start_row, swarp);
    }

    //printf("??\n");

    while(!topo_queue.empty())
    {
        ptr_node current_node = topo_queue.front();
        current_warp = current_node->warp_id;
        int current_sm = get_sm_id(current_node->warp_id);
        for (auto iter = current_node->child.begin(); iter != current_node->child.end(); iter++)
        {
            (*iter)->in_degree_tmp++;
            if ((*iter)->in_degree_tmp == (*iter)->in_degree)
            {
                //printf("node row %d\n", (*iter)->info.start_row);
                topo_queue.push(*iter);
                (*iter)->in_degree_tmp = 0;

                int flag = 0;
                ptr_node parent = NULL;
                for (auto i = (*iter)->parent.begin(); i != (*iter)->parent.end(); i++)
                {
                    if ((*i)->locality_node == (*iter))
                    {
                        flag = 1;
                        parent = *i;
                    }
                }

                if ((*iter)->info.start_row == 1) printf("start row 1 %d\n", flag);

                if (flag)
                {
                    //printf("start 1\n");

                    int new_warp = next_nearwarp(parent->warp_id);

                    //printf("current %d new_warp %d\n", current_warp, new_warp);
                    //printf("sm %d warp_id %d\n", get_sm_id(new_warp), new_warp % WARP_NUM_PER_SM);

                    schedule_node(handler->warp_schedule[new_warp], *iter, new_warp);

                    sm_workload[get_sm_id(new_warp)] += (*iter)->num_nnz;
                    warp_workload[get_sm_id(new_warp)][new_warp % WARP_NUM_PER_SM]
                    += (*iter)->num_nnz;

                    //printf("row %d new_warp %d\n", (*iter)->info.start_row, new_warp);
                }
                else
                {
                    //printf("start 2\n");

                    float min_load = -1;
                    int min_i = -1;
                    for (int i = 0; i < SM_NUM; i++)
                    {
                        if (i != current_sm && (sm_workload[i] < min_load || min_load == -1))
                        {
                            min_i = i;
                            min_load = sm_workload[i];
                        }
                        //printf("%f ", sm_workload[i]);
                    }
                    //printf("sm_workload\n");
                    min_load = warp_workload[min_i][0];
                    int min_j = 0;
                    for (int j = 1; j < WARP_NUM_PER_SM; j++)
                    {
                        if (warp_workload[min_i][j] < min_load)
                        {
                            min_j = j;
                            min_load = warp_workload[min_i][j];
                        }
                    }

                    //printf("%d %d %d\n", min_i, min_j, get_warp_id(min_i, min_j));
                    int new_warp = get_warp_id(min_i, min_j);
                    schedule_node(handler->warp_schedule[new_warp], *iter, new_warp);

                    sm_workload[min_i] += (*iter)->num_nnz;
                    warp_workload[min_i][min_j] += (*iter)->num_nnz;

                    //printf("row %d new_warp %d\n", (*iter)->info.start_row, new_warp);
                }
            }
        }
        topo_queue.pop();
    }

    for (int i = 0; i < handler->warp_schedule[0].size(); i++)
    {
        printf("%d ", handler->warp_schedule[0][i]->info.start_row);
    }

    // printf("??\n");

}

// schedule with row sequence
void schedule_structured2(ptr_handler handler)
{
    ptr_graph graph = handler->graph;

    int current_sm = 0;
    int current_warp = 0;
    //ptr_node last_node = NULL;
    int count1 = 0, count2 = 0;
    for (ptr_node i = graph->start_nodes[0]; i != NULL; i = i->locality_node)
    {
        int swarp = get_warp_id(current_sm, current_warp);
        // static schedule in turn
        schedule_node(handler->warp_schedule[swarp], i, swarp);
        if (i->locality_node && std::find(i->child.begin(), i->child.end(), i->locality_node) != i->child.end())
        {
            count1++;
            current_warp = (current_warp + 1) % WARP_NUM_PER_SM;
        }
        else
        {
            count2++;
            current_sm = (current_sm + 1) % SM_NUM;
            current_warp = 0;
        }
    }

}

void simple_schedule_sequential(ptr_handler handler)
{
    ptr_graph graph = handler->graph;

    int current_warp = 0;
    for (ptr_node i = graph->start_nodes[0]; i != NULL; i = i->locality_node)
    {
        // static schedule in turn
        schedule_node(handler->warp_schedule[current_warp], i, current_warp);
        current_warp = (current_warp + 1) % WARP_NUM;
    }

}

void sptrsv_schedule(ptr_handler handler, SCHEDULE_STRATEGY strategy)
{
    if (strategy == SIMPLE)
        simple_schedule(handler);
    else if (strategy == WORKLOAD_BALANCE)
        simple_schedule_workload_balance(handler);
    else if (strategy == WARP_LOCALITY)
        simple_schedule_warp_locality(handler);
    else if (strategy == BALANCE_AND_LOCALITY)
        simple_schedule_workload_locality(handler);
    else if (strategy == SEQUENTIAL)
        simple_schedule_sequential(handler);
    else if (strategy == STRUCTURED)
        schedule_structured(handler);
    else
        printf("Scheduling strategy error!\n");

    if (SHOW_USER_IMBALANCE) show_imbalance(handler);

    sync_elimination(handler);
    
    transfer_to_2D(handler);

    schedule_info_hosttodevice(handler);
}
