#include <hip/hip_runtime.h>
#include "../include/SpTRSV.h"
#include <hip/hip_runtime.h>

#define BUF_SIZE 64
#define PREFETCH_BLOCK 4

// In this implementation, we assume that
// diagonal elements of the matrix are explicitly stored, 
// together with off-diagonal elements in CSR format
template<typename T>
__global__ void SpTRSV_simple(int *level, node_info **info, 
            const int *csrRowPtr, const int *csrColIdx, const T* csrValue,
            const T* b, T* x, int *get_value)
{
    int bid = blockIdx.x;
    int tid = threadIdx.x;
    int wid = tid / WARP_SIZE;
    int global_wid = bid * WARP_NUM_PER_BLOCK + wid;
    int lane_id = tid % WARP_SIZE;

    // node_info info_buf[PREFETCH_BLOCK];
    // int idx_buf[PREFETCH_BLOCK][BUF_SIZE];
    // T val_buf[PREFETCH_BLOCK][BUF_SIZE];

    //if (!global_wid) printf("%d", WARP_NUM_PER_BLOCK);

    __shared__ int idx_buf[WARP_NUM_PER_BLOCK][PREFETCH_BLOCK][BUF_SIZE];
    __shared__ T val_buf[WARP_NUM_PER_BLOCK][PREFETCH_BLOCK][BUF_SIZE];

    int buf_count = 0;

    for (int schedule_i = 0; schedule_i < level[global_wid]; schedule_i += PREFETCH_BLOCK)
    {
        int pre_len = (level[global_wid] - schedule_i > PREFETCH_BLOCK)? PREFETCH_BLOCK: level[global_wid] - schedule_i;

        //if (global_wid == 0) printf("pre_len %d\n", pre_len);

        for (int j = 0; j < pre_len; j++)
        {
            //info_buf[j] = info[global_wid][schedule_i + j];
            node_info current_info = info[global_wid][schedule_i + j];

            int row_st = current_info.start_row;
            int row_ed = current_info.end_row;

            int idx_st = csrRowPtr[row_st];
            int idx_ed = csrRowPtr[row_ed];

            for (int idx = idx_st + lane_id; idx < idx_ed; idx += WARP_SIZE)
            {
                idx_buf[wid][j][idx - idx_st] = csrColIdx[idx];
                val_buf[wid][j][idx - idx_st] = csrValue[idx];
            }
        }

        //if (!lane_id) printf("global wid %d done!\n", global_wid);

        for (int j = 0; j < pre_len; j++)
        {
            node_info current_info = info[global_wid][schedule_i + j];
            //node_info current_info = info_buf[j];

            int row_st = current_info.start_row;
            int row_ed = current_info.end_row;

            //if (!global_wid && !lane_id) printf("%d %d\n", row_st, row_ed);

            // One warp for one row
            //if (row_st + 1 == row_ed && col_st == -1 && col_ed == -1)
            if (row_st + 1 == row_ed)
            {
                int idx_st = csrRowPtr[row_st];
                int idx_ed = csrRowPtr[row_st + 1];

                T rh_value = b[row_st];
                T diag_value = csrValue[idx_ed - 1];

                T leftsum = 0;
                for (int idx = idx_st + lane_id; idx < idx_ed - 1; idx += WARP_SIZE)
                {
                    int dep_row = idx_buf[wid][j][idx - idx_st];
                    //int dep_row = csrColIdx[idx];
                    // if (dep_row != csrColIdx[idx])
                    // {
                    //     printf("global_wid %d Error at row_st %d\n", global_wid, row_st);
                    //     printf("idx %d buf %f ColIdx %f\n", idx - idx_st, dep_row, csrColIdx[idx]);
                    // }
                    //if (row_st < 20 && !lane_id) printf("row_st %d global_wid %d idx %d deprow %d\n", row_st, global_wid, idx, dep_row);

                    T dep_value = val_buf[wid][j][idx - idx_st];
                    //T dep_value = csrValue[idx];

                    //if (global_wid == 0) printf("True!\n");
                    // if (global_wid == 3839) 
                    // {
                    //     printf("row_st %d v1 %f dep_row %d get_value[dep_row] %d\n", 
                    //     row_st, csrValue[idx], dep_row, get_value[dep_row]);
                    // }

                    __threadfence();

                    // wait for dependency
                    while (!get_value[dep_row])
                    {
                        __threadfence();
                    }

                    // if (global_wid == 3839) 
                    // {
                    //     printf("row_st %d v1 %f dep_row %d get_value[dep_row] %d\n", 
                    //     row_st, csrValue[idx], dep_row, get_value[dep_row]);
                    // }
                    
                    leftsum += dep_value * x[dep_row];
                }

                //if (row_st < 20 && !lane_id) printf("row_st %d globalwid %d\n", row_st, global_wid);

                // warp-level reduce
                for (int offset = WARP_SIZE / 2; offset > 0; offset /= 2)
                    leftsum += __shfl_down(leftsum, offset);

                // if (!lane_id)
                // printf("warp_id %d i %d row_st %d idx_st %d idx_ed %d leftsum %.2f\n", 
                // global_wid, schedule_i, row_st, idx_st, idx_ed, leftsum);
                
                if (!lane_id)
                {
                    //printf("%d done!\n", wid);
                    x[row_st] = (rh_value - leftsum) / diag_value;
                    //x[row_st] = (b[row_st] - leftsum) / csrValue[idx_ed - 1];
                    __threadfence();
                    get_value[row_st] = 1;
                }
            }
            // One thread for one row
            // else if (row_st + 1 < row_ed && col_st == -1 && col_ed == -1)
            else if (row_st + 1 < row_ed)
            {
                T rh_value = b[row_st];
                //T diag_value = csrValue[row_ed - 1];

                for (int row_iter = row_st + lane_id; row_iter < row_ed; row_iter += WARP_SIZE)
                {
                    int idx = csrRowPtr[row_iter];

                    T leftsum = 0;

                    while (idx < csrRowPtr[row_iter + 1])
                    {
                        int dep_row = csrColIdx[idx];
                        __threadfence();
                        if (get_value[dep_row] == 1)
                        {
                            leftsum += csrValue[idx] * x[dep_row];
                            idx++;
                            dep_row = csrColIdx[idx];
                        }
                        if (dep_row == row_iter)
                        {
                            //x[row_iter] = (b[row_iter] - leftsum) / csrValue[idx];
                            x[row_iter] = (rh_value - leftsum) / csrValue[idx];
                            __threadfence();
                            get_value[row_iter] = 1;
                            idx++;
                        }
                    }

                }
            }
            else
            {
                // Not implemented
            }
        }
        //if (!lane_id && schedule_i == 0) printf("wid %d level %d\n", global_wid, schedule_i);
        //if (!global_wid && schedule_i == 0) printf("wid %d level %d\n", global_wid, schedule_i);
    }
}

template <typename T>
void SpTRSV_executor(ptr_handler handler, 
            const int *csrRowPtr_d, const int *csrColIdx_d, const T* csrValue_d,
            const T* b_d, T* x_d)
{
    // int *level_d;
    // node_info **info_d;
    // node_info *info_h[WARP_NUM];
    // int *get_value;

    // hipMalloc(&level_d, WARP_NUM * sizeof(int));
    // hipMalloc(&info_d, WARP_NUM * sizeof(node_info*));
    // hipMalloc(&get_value, handler->m * sizeof(int));

    // hipMemcpy(level_d, handler->schedule_level, WARP_NUM * sizeof(int), hipMemcpyHostToDevice);

    // for (int i = 0; i < WARP_NUM; i++)
    // {
    //     int level = handler->schedule_level[i];
    //     hipMalloc(&info_h[i], level * sizeof(node_info));

    //     //if (level) printf("i %d level %d\n", i, level);
    //     hipMemcpy(info_h[i], handler->schedule_info[i], level * sizeof(node_info), hipMemcpyHostToDevice);
    // }

    // hipMemcpy(info_d, info_h, WARP_NUM * sizeof(node_info*), hipMemcpyHostToDevice);

    // hipMemset(get_value, 0, handler->m * sizeof(int));

    hipLaunchKernelGGL(HIP_KERNEL_NAME(SpTRSV_simple<T>), dim3(BLOCK_NUM), dim3(THREAD_NUM_PER_BLOCK), 0, 0, handler->schedule_level_d, 
    handler->schedule_info_d, csrRowPtr_d, csrColIdx_d, csrValue_d, 
    b_d, x_d, handler->get_value);
    //hipDeviceSynchronize();
}

// instance
template void SpTRSV_executor<float>(ptr_handler handler, 
            const int *csrRowPtr, const int *csrColIdx, const float* csrValue,
            const float* b, float* x);
