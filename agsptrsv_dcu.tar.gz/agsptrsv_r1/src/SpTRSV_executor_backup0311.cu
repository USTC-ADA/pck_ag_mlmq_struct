#include <hip/hip_runtime.h>
#include "../include/SpTRSV.h"
#include <hip/hip_runtime.h>

// In this implementation, we assume that
// diagonal elements of the matrix are explicitly stored, 
// together with off-diagonal elements in CSR format
template<typename T>
__global__ void SpTRSV_simple(int *level, node_info **info, 
            const int *csrRowPtr, const int *csrColIdx, const T* csrValue,
            const T* b, T* x, int *get_value)
{
    int bid = blockIdx.x;
    int tid = threadIdx.x;
    int wid = tid / WARP_SIZE;
    int global_wid = bid * WARP_NUM_PER_BLOCK + wid;
    int lane_id = tid % WARP_SIZE;

    // if (global_wid == WARP_NUM - 1 && !lane_id) printf("last\n");
    // if (global_wid == 0 && !lane_id) printf("first\n");

    for (int schedule_i = 0; schedule_i < level[global_wid]; schedule_i++)
    {
        node_info current_info = info[global_wid][schedule_i];

        int row_st = current_info.start_row;
        int row_ed = current_info.end_row;

        SYNC_ELIM elim = current_info.elim;

        // One warp for one row
        //if (row_st + 1 == row_ed && col_st == -1 && col_ed == -1)
        if (row_st + 1 == row_ed)
        {
            int idx_st = csrRowPtr[row_st];
            int idx_ed = csrRowPtr[row_st + 1];

            T rh_value = b[row_st];
            T diag_value = csrValue[idx_ed - 1];

            T leftsum = 0;
            for (int idx = idx_st + lane_id; idx < idx_ed - 1; idx += WARP_SIZE)
            {
                int dep_row = csrColIdx[idx];

                T dep_value = csrValue[idx];

                // wait for dependency
                while (!get_value[dep_row])
                {
                    __threadfence();
                }
                
                leftsum += dep_value * x[dep_row];
            }

            // warp-level reduce
            for (int offset = WARP_SIZE / 2; offset > 0; offset /= 2)
                leftsum += __shfl_down(leftsum, offset);

            // if (!lane_id)
            // printf("warp_id %d i %d row_st %d idx_st %d idx_ed %d leftsum %.2f\n", 
            // global_wid, schedule_i, row_st, idx_st, idx_ed, leftsum);
            
            if (!lane_id)
            {
                x[row_st] = (rh_value - leftsum) / diag_value;
                //x[row_st] = (b[row_st] - leftsum) / csrValue[idx_ed - 1];
                __threadfence();
                get_value[row_st] = 1;
            }
        }
        // One thread for one row
        // else if (row_st + 1 < row_ed && col_st == -1 && col_ed == -1)
        else if (row_st + 1 < row_ed)
        {
            //T diag_value = csrValue[row_ed - 1];

            for (int row_iter = row_st + lane_id; row_iter < row_ed; row_iter += WARP_SIZE)
            {
                int idx = csrRowPtr[row_iter];
                T rh_value = b[row_iter];

                T leftsum = 0;

                while (idx < csrRowPtr[row_iter + 1])
                {
                    int dep_row = csrColIdx[idx];
                    __threadfence();

                    if (dep_row == row_iter)
                    {
                        //x[row_iter] = (b[row_iter] - leftsum) / csrValue[idx];
                        x[row_iter] = (rh_value - leftsum) / csrValue[idx];
                        __threadfence();
                        get_value[row_iter] = 1;
                        idx++;
                    }

                    if (get_value[dep_row] == 1)
                    {
                        leftsum += csrValue[idx] * x[dep_row];
                        idx++;
                        dep_row = csrColIdx[idx];
                    }
                }
            }
        }
    }

}

template <typename T>
void SpTRSV_executor(ptr_handler handler, 
            const int *csrRowPtr_d, const int *csrColIdx_d, const T* csrValue_d,
            const T* b_d, T* x_d)
{
    hipLaunchKernelGGL(HIP_KERNEL_NAME(SpTRSV_simple<T>), dim3(BLOCK_NUM), dim3(THREAD_NUM_PER_BLOCK), 0, 0, handler->schedule_level_d, 
    handler->schedule_info_d, csrRowPtr_d, csrColIdx_d, csrValue_d, 
    b_d, x_d, handler->get_value);
}

template<typename T>
__global__ void SpTRSV_hybrid(int *level, node_info **info, 
            const int *RowPtr, const int *ValPtr, const int *idx, const T* value,
            const T* b, T* x, int *get_value)
{
    int bid = blockIdx.x;
    int tid = threadIdx.x;
    int wid = tid / WARP_SIZE;
    int global_wid = bid * WARP_NUM_PER_BLOCK + wid;
    int lane_id = tid % WARP_SIZE;

    for (int schedule_i = 0; schedule_i < level[global_wid]; schedule_i++)
    {
        node_info current_info = info[global_wid][schedule_i];

        int row_st = current_info.start_row;
        int row_ed = current_info.end_row;

        //if (!lane_id) printf("id %d: %d %d\n", global_wid, row_st, row_ed);

        // One warp for one row
        //if (row_st + 1 == row_ed && col_st == -1 && col_ed == -1)
        if (current_info.format == TELL)
        {
            int row_num = row_ed - row_st;
            int idx_st = RowPtr[row_st];
            int idx_ed = RowPtr[row_ed];
            int val_st = ValPtr[row_st];
            int val_ed = ValPtr[row_ed];

            // if (global_wid == 2) printf("id %d: %d %d %d %d\n",
            // global_wid, idx_st, idx_ed, val_st, val_ed);

            for (int row_iter = row_st + lane_id; row_iter < row_ed; row_iter += WARP_SIZE)
            {
                T leftsum = 0;
                T rh_value = b[row_iter];

                __threadfence();

                int row_offset = row_iter - row_st;
                int val_i = val_st + row_offset;
                //if (global_wid == 2) printf("row_st val_i %d %d %d\n", row_iter, val_st, row_offset);
                for (int idx_i = idx_st + row_offset; idx_i < idx_ed; idx_i += row_num)
                {
                    int dep_row = idx[idx_i];
                    while (!get_value[dep_row])
                    {
                        __threadfence();
                    }
                    leftsum += value[val_i] * x[dep_row];
                    //if (global_wid == 2)
                    //    printf("row_st %d val_i %d dep %.2f %d %.2f\n", row_iter, val_i, value[val_i], dep_row, x[dep_row]);
                    val_i += row_num;
                }

               // if (lane_id) printf("id %d: %d = %.2f / %d %d %d %.2f\n", 
                //global_wid, row_iter, rh_value - leftsum, val_i, val_st, row_offset, value[val_i]);
                x[row_iter] = (rh_value - leftsum) / value[val_i];
                __threadfence();
                get_value[row_iter] = 1;
                //printf("id %d: x %d = %.2f %.2f\n", global_wid, row_iter, x[row_iter], b[row_iter]);
            }
        }
        else if (current_info.format == CSR)
        {
            printf("Not implemented!\n");
        }
    }
}

template <typename T>
void SpTRSV_executor_hybrid(ptr_handler handler, 
            const int *RowPtr_d, const int *ValPtr_d,
            const int *idx_d, const T* value_d,
            const T* b_d, T* x_d)
{
    hipLaunchKernelGGL(HIP_KERNEL_NAME(SpTRSV_hybrid<T>), dim3(BLOCK_NUM), dim3(THREAD_NUM_PER_BLOCK), 0, 0, handler->schedule_level_d, 
    handler->schedule_info_d, RowPtr_d, ValPtr_d, idx_d, value_d, 
    b_d, x_d, handler->get_value);
}

// instance
template void SpTRSV_executor<float>(ptr_handler handler, 
            const int *csrRowPtr, const int *csrColIdx, const float* csrValue,
            const float* b, float* x);

template void SpTRSV_executor<double>(ptr_handler handler, 
            const int *csrRowPtr, const int *csrColIdx, const double* csrValue,
            const double* b, double* x);

template void SpTRSV_executor_hybrid<float>(ptr_handler handler, 
            const int *RowPtr_d, const int *ValPtr_d,
            const int *idx_d, const float* value_d,
            const float* b_d, float* x_d);

template void SpTRSV_executor_hybrid<double>(ptr_handler handler, 
            const int *RowPtr_d, const int *ValPtr_d,
            const int *idx_d, const double* value_d,
            const double* b_d, double* x_d);
