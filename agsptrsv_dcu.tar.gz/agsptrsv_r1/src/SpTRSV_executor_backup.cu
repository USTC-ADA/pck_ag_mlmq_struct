#include <hip/hip_runtime.h>
#include "../include/SpTRSV.h"
#include <hip/hip_runtime.h>

// In this implementation, we assume that
// diagonal elements of the matrix are explicitly stored, 
// together with off-diagonal elements in CSR format
template<typename T>
__global__ void SpTRSV_simple(int *level, node_info **info, 
            const int *csrRowPtr, const int *csrColIdx, const T* csrValue,
            const T* b, T* x, int *get_value)
{
    int bid = blockIdx.x;
    int tid = threadIdx.x;
    int wid = tid / WARP_SIZE;
    int global_wid = bid * WARP_NUM_PER_BLOCK + wid;
    int lane_id = tid % WARP_SIZE;

    for (int schedule_i = 0; schedule_i < level[global_wid]; schedule_i++)
    {
        node_info current_info = info[global_wid][schedule_i];

        int row_st = current_info.start_row;
        int row_ed = current_info.end_row;
        
        // int col_st = current_info.start_idx;
        // int col_ed = current_info.end_idx;

        // One warp for one row
        //if (row_st + 1 == row_ed && col_st == -1 && col_ed == -1)
        if (row_st + 1 == row_ed)
        {
            int idx_st = csrRowPtr[row_st];
            int idx_ed = csrRowPtr[row_st + 1];

            T rh_value = b[row_st];
            T diag_value = csrValue[idx_ed - 1];

            T leftsum = 0;
            for (int idx = idx_st + lane_id; idx < idx_ed - 1; idx += WARP_SIZE)
            {
                int dep_row = csrColIdx[idx];

                T dep_value = csrValue[idx];

                // wait for dependency
                while (!get_value[dep_row])
                {
                    __threadfence();
                }
                
                leftsum += dep_value * x[dep_row];
            }

            // warp-level reduce
            for (int offset = WARP_SIZE / 2; offset > 0; offset /= 2)
                leftsum += __shfl_down(leftsum, offset);

            // if (!lane_id)
            // printf("warp_id %d i %d row_st %d idx_st %d idx_ed %d leftsum %.2f\n", 
            // global_wid, schedule_i, row_st, idx_st, idx_ed, leftsum);
            
            if (!lane_id)
            {
                x[row_st] = (rh_value - leftsum) / diag_value;
                //x[row_st] = (b[row_st] - leftsum) / csrValue[idx_ed - 1];
                __threadfence();
                get_value[row_st] = 1;
            }
        }
        // One thread for one row
        // else if (row_st + 1 < row_ed && col_st == -1 && col_ed == -1)
        else if (row_st + 1 < row_ed)
        {
            //T diag_value = csrValue[row_ed - 1];

            for (int row_iter = row_st + lane_id; row_iter < row_ed; row_iter += WARP_SIZE)
            {
                int idx = csrRowPtr[row_iter];
                T rh_value = b[row_iter];

                T leftsum = 0;

                while (idx < csrRowPtr[row_iter + 1])
                {
                    int dep_row = csrColIdx[idx];
                    __threadfence();
                    if (get_value[dep_row] == 1)
                    {
                        leftsum += csrValue[idx] * x[dep_row];
                        idx++;
                        dep_row = csrColIdx[idx];
                    }

                    if (dep_row == row_iter)
                    {
                        //x[row_iter] = (b[row_iter] - leftsum) / csrValue[idx];
                        x[row_iter] = (rh_value - leftsum) / csrValue[idx];
                        __threadfence();
                        get_value[row_iter] = 1;
                        idx++;
                    }
                }

            }
        }
        else
        {
            // Not implemented
        }
        // else
        // {
        //     for (int row_iter = row_st + lane_id; row_iter < row_ed; row_iter += WARP_SIZE)
        //     {
        //         int idx = csrRowPtr[row_iter];
        //         T rh_value = b[row_iter];

        //         T leftsum = 0;

        //         int dep_row = csrColIdx[idx];

        //         while (dep_row < row_st)
        //         {
        //             __threadfence();
        //             if (get_value[dep_row] == 1)
        //             {
        //                 leftsum += csrValue[idx] * x[dep_row];
        //                 idx++;
        //                 dep_row = csrColIdx[idx];
        //             }
        //             //get_value[row_iter] = 1;
        //         }

        //         for (int internal = 0; internal <= lane_id; internal++)
        //         {
        //             //if (internal == lane_id)
        //             //{
        //                 x[row_iter + internal] = (rh_value - leftsum) / csrValue[idx];
        //                 __threadfence();
        //                 get_value[row_iter] = 1;   
        //             //}
        //             leftsum -= 3.0 * x[row_iter + internal];
        //         }
        //         // x[row_iter] = (rh_value - leftsum) / csrValue[idx];
        //         // __threadfence();
        //         // get_value[row_iter] = 1;   
        //     }
        // }
    }
}

template <typename T>
void SpTRSV_executor(ptr_handler handler, 
            const int *csrRowPtr_d, const int *csrColIdx_d, const T* csrValue_d,
            const T* b_d, T* x_d)
{
    // int *level_d;
    // node_info **info_d;
    // node_info *info_h[WARP_NUM];
    // int *get_value;

    // hipMalloc(&level_d, WARP_NUM * sizeof(int));
    // hipMalloc(&info_d, WARP_NUM * sizeof(node_info*));
    // hipMalloc(&get_value, handler->m * sizeof(int));

    // hipMemcpy(level_d, handler->schedule_level, WARP_NUM * sizeof(int), hipMemcpyHostToDevice);

    // for (int i = 0; i < WARP_NUM; i++)
    // {
    //     int level = handler->schedule_level[i];
    //     hipMalloc(&info_h[i], level * sizeof(node_info));

    //     //if (level) printf("i %d level %d\n", i, level);
    //     hipMemcpy(info_h[i], handler->schedule_info[i], level * sizeof(node_info), hipMemcpyHostToDevice);
    // }

    // hipMemcpy(info_d, info_h, WARP_NUM * sizeof(node_info*), hipMemcpyHostToDevice);

    // hipMemset(get_value, 0, handler->m * sizeof(int));

    hipLaunchKernelGGL(HIP_KERNEL_NAME(SpTRSV_simple<T>), dim3(BLOCK_NUM), dim3(THREAD_NUM_PER_BLOCK), 0, 0, handler->schedule_level_d, 
    handler->schedule_info_d, csrRowPtr_d, csrColIdx_d, csrValue_d, 
    b_d, x_d, handler->get_value);
    //hipDeviceSynchronize();
}

// instance
template void SpTRSV_executor<float>(ptr_handler handler, 
            const int *csrRowPtr, const int *csrColIdx, const float* csrValue,
            const float* b, float* x);
