#!/bin/bash
# ============================================================
# Detect AMD GPU architecture on the supercomputer
# Run this script on the compute node with GPU access
# ============================================================

echo "=== ROCm version ==="
rocm-smi --showproductname 2>/dev/null || echo "rocm-smi not available"

echo ""
echo "=== GPU architecture (rocminfo) ==="
rocminfo 2>/dev/null | grep -E "^\s*Name:\s+gfx" || echo "rocminfo not available or no gfx target found"

echo ""
echo "=== GPU device IDs ==="
rocm-smi --showid 2>/dev/null || echo "rocm-smi not available"

echo ""
echo "=== Suggested AMDGPU_TARGET ==="
gfx=$(rocminfo 2>/dev/null | grep -oP "gfx\d+a?" | head -1)
if [ -n "$gfx" ]; then
    echo "Detected: $gfx"
    echo "Export with: export AMDGPU_TARGET=$gfx"
else
    echo "Could not auto-detect. Check rocminfo output above."
    echo "Common targets: gfx906 (MI50/MI60), gfx908 (MI100), gfx90a (MI250/MI210)"
fi

echo ""
echo "=== .gr file format detection ==="
if [ -n "$1" ] && [ -f "$1" ]; then
    echo "File: $1"
    echo "--- First 20 lines ---"
    head -20 "$1"
    echo "--- Line counts by prefix ---"
    cut -c1 "$1" | sort | uniq -c | sort -rn | head -10
else
    echo "Usage: bash arch.sh <file.gr>  (to detect .gr file format)"
fi
