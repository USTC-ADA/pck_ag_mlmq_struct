#ifndef PREPROCESSING__
#define PREPROCESSING__

#include "common.h"
#include <hip/hip_runtime.h>

enum PREPROCESSING_STRATEGY
{
    ROW_BLOCK,
    ROW_BLOCK_THRESH,
    ROW_BLOCK_AVG,
    SUPERNODE_BLOCK
};

ptr_handler SpTRSV_preprocessing(const int m,
                const int nnz,
                const int *csrRowPtr,
                const int *csrColIdx,
                PREPROCESSING_STRATEGY strategy,
                int row_block);

void graph_reorder_with_level(ptr_handler handler);

// ptr_graph generate_graph(const int m,
//                 const int nnz,
//                 const int *csrRowPtr,
//                 const int *csrColIdx);

void write_graph(const char* file_name, ptr_handler handler, unsigned int max_depthm,
int layer, float parallelism);

#endif
