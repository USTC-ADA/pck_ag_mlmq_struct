#ifndef SCHEDULE__
#define SCHEDULE__

#include "common.h"
#include "GPU_setup.h"
#include "elimination.h"
#include <stdlib.h>
#include <queue>
#include <hip/hip_runtime.h>
#include <algorithm>

#define SHOW_USER_IMBALANCE false

enum SCHEDULE_STRATEGY
{
    SIMPLE, 
    WORKLOAD_BALANCE, 
    WARP_LOCALITY, 
    BALANCE_AND_LOCALITY,
    SEQUENTIAL,
    STRUCTURED
};

void sptrsv_schedule(ptr_handler handler, SCHEDULE_STRATEGY strategy);

// void simple_schedule(ptr_handler handler);
// void simple_schedule_workload_balance(ptr_handler handler);
// void simple_schedule_warp_locality(ptr_handler handler);
// void simple_schedule_workload_locality(ptr_handler handler);

#endif
