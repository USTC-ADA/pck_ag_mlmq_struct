import matplotlib.pyplot as plt
import csv
import sys
from math import log, exp

if (len(sys.argv) != 3):
    print("Usage: python line_chart.py {input csv file name} {output picture name}")
    exit(1)
filename = sys.argv[1]
picname = sys.argv[2]

data = list(csv.reader(open(filename)))

table_head = data[0]
table_head = [item.strip() for item in table_head]

matrix_name_idx = table_head.index("matrix")
sptrsv_gflops_idx = table_head.index("sptrsv gflops")
#cusparse_gflops_idx = table_head.index("cusparse gflops")
yy_gflops_idx = table_head.index("yy gflops")

sptrsv_gflops = []
cusparse_gflops = []
yy_gflops = []
no_speedup_matrix = []

baseline_idx = yy_gflops_idx#cusparse_gflops_idx

total_speedup = 0.0

for row in data[1:]:
    # sptrsv_gflops = row["sptrsv gflops"]
    # cusparse_gflops = row["cusparse gflops"]
    # yy_gflops = row["yy gflops"]
    row = [item.strip() for item in row]

    if (float(row[baseline_idx])):
        speedup = float(row[sptrsv_gflops_idx]) / float(row[baseline_idx])
        total_speedup += log(speedup)
        sptrsv_gflops.append(speedup)
        if (speedup < 1.0):
            st = row[matrix_name_idx].rfind('/')
            ed = row[matrix_name_idx].index('.')
            no_speedup_matrix.append(row[matrix_name_idx][st+1:ed])

    #cusparse_gflops.append(float(row[cusparse_gflops_idx]))
    yy_gflops.append(float(row[baseline_idx]))

matrix_id = [i for i in range(0, len(sptrsv_gflops))]

print("total speedup:", exp(total_speedup / (len(data) - 1)))

#plt.yscale("log")
plt.plot(matrix_id, sptrsv_gflops)
#plt.plot(matrix_id, cusparse_gflops)
#plt.plot(matrix_id, yy_gflops)
plt.xlabel("matrix id")
plt.ylabel("speedup")
plt.savefig(picname)

with open('../suitesparse/slow_list', 'w') as f_out:
    for item in no_speedup_matrix:
        f_out.write(item)
        f_out.write("\n")


