import matplotlib.pyplot as plt
import csv
import sys
from math import log, exp

if (len(sys.argv) != 4):
    print("Usage: python compare.py {compare1.csv} {compare2.csv} {output picture name}")
    exit(1)

file1 = sys.argv[1]
file2 = sys.argv[2]
picname = sys.argv[3]

data1 = list(csv.reader(open(file1)))
data2 = list(csv.reader(open(file2)))

table_head = data1[0]
table_head = [item.strip() for item in table_head]

matrix_name_idx1 = table_head.index("matrix")
sptrsv_gflops_idx = table_head.index("sptrsv gflops")
cusparse_gflops_idx = table_head.index("cusparse gflops")
nnz_idx = table_head.index("nnz")

table_head2 = data2[0]
table_head2 = [item.strip() for item in table_head2]
matrix_name_idx2 = table_head2.index("matrix")
yy_gflops_idx = table_head2.index("yy gflops")

speedup = []

i = 1
len1 = len(data1)
len2 = len(data2)

row2 = [item.strip() for item in data2[i]]

no_speedup_matrix = []

total_speedup = 0.0

count = 0
for row1 in (data1[1:]):

    row1 = [item.strip() for item in row1]

    filename = row1[matrix_name_idx1]

    while (i < len2 and row2[matrix_name_idx2] != filename):
        i += 1
        row2 = [item.strip() for item in data2[i]]
    
    #print(yy_gflops_idx, row2[matrix_name_idx2])
    
    if (int(row1[nnz_idx]) > 100000 and row2[matrix_name_idx2] == filename and float(row2[yy_gflops_idx])):
        count += 1
        item = float(row1[sptrsv_gflops_idx]) / float(row2[yy_gflops_idx])
        speedup.append(item)
        total_speedup += log(item)
        if (item < 0.8):
            st = row1[matrix_name_idx1].rfind('/')
            ed = row1[matrix_name_idx1].index('.')
            #print(row1[matrix_name_idx1][st+1:ed])
            no_speedup_matrix.append(row1[matrix_name_idx1][st+1:ed])
    
matrix_id = [i for i in range(0, len(speedup))]

print("total speedup:", exp(total_speedup / count))
print("total matrix number:", count)

plt.yscale("log")
plt.plot(matrix_id, speedup)

plt.xlabel("matrix id")
plt.ylabel("speedup")
plt.savefig(picname)

with open('../suitesparse/slow_list_yy', 'w') as f_out:
    for item in no_speedup_matrix:
        f_out.write(item)
        f_out.write("\n")
