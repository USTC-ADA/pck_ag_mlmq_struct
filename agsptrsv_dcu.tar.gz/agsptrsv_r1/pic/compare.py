import matplotlib.pyplot as plt
import csv
import sys

if (len(sys.argv) != 4):
    print("Usage: python compare.py {compare1.csv} {compare2.csv} {output picture name}")
    exit(1)

file1 = sys.argv[1]
file2 = sys.argv[2]
picname = sys.argv[3]

data1 = list(csv.reader(open(file1)))
data2 = list(csv.reader(open(file2)))

table_head = data1[0]
table_head = [item.strip() for item in table_head]

matrix_name_idx = table_head.index("matrix")
sptrsv_gflops_idx = table_head.index("sptrsv gflops")
cusparse_gflops_idx = table_head.index("cusparse gflops")
yy_gflops_idx = table_head.index("yy gflops")

speedup = []

for row1, row2 in zip(data1[1:], data2[1:]):
    # sptrsv_gflops = row["sptrsv gflops"]
    # cusparse_gflops = row["cusparse gflops"]
    # yy_gflops = row["yy gflops"]
    row1 = [item.strip() for item in row1]
    row2 = [item.strip() for item in row2]

    if (float(row2[sptrsv_gflops_idx])):
        item = float(row1[sptrsv_gflops_idx]) / float(row2[sptrsv_gflops_idx])
        speedup.append(item)
        if (item < 1.0):
            print(row1[matrix_name_idx], " ", row2[matrix_name_idx])
    
matrix_id = [i for i in range(0, len(speedup))]

plt.plot(matrix_id, speedup)
#plt.plot(matrix_id, cusparse_gflops)
#plt.plot(matrix_id, yy_gflops)
plt.savefig(picname)

