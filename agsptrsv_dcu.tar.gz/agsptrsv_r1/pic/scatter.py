import matplotlib.pyplot as plt
import csv
import sys
from math import log, exp
import numpy as np

if (len(sys.argv) != 3):
    print("Usage: python line_chart.py {input csv file name} {output picture name}")
    exit(1)
filename = sys.argv[1]
picname = sys.argv[2]

data = list(csv.reader(open(filename)))

table_head = data[0]
table_head = [item.strip() for item in table_head]

matrix_name_idx = table_head.index("matrix")
sptrsv_gflops_idx = table_head.index("sptrsv gflops")
cusparse_gflops_idx = table_head.index("cusparse gflops")
yy_gflops_idx = table_head.index("yy gflops")
# parallelism_idx = table_head.index("parallelism")
# nnz_idx = table_head.index("nnz")

sptrsv_gflops = []
cusparse_gflops = []
yy_gflops = []
no_speedup_matrix = []

baseline_idx = yy_gflops_idx
x_name = "nnz"

x_idx = table_head.index(x_name)

total_speedup = 0.0
total_speedup_log = 0.0

parallelism = []
speedup_list = []

for row in data[1:]:

    row = [item.strip() for item in row]

    nnz = float(row[table_head.index("nnz")])

    if (float(row[baseline_idx]) and nnz > 1000000):
        speedup = float(row[sptrsv_gflops_idx]) / float(row[baseline_idx])
        total_speedup_log += log(speedup)
        total_speedup += speedup

        parallelism.append(float(row[x_idx]))
        speedup_list.append(speedup)

        if (speedup < 1.0):
            st = row[matrix_name_idx].rfind('/')
            ed = row[matrix_name_idx].index('.')
            no_speedup_matrix.append(row[matrix_name_idx][st+1:ed])


matrix_id = [i for i in range(0, len(sptrsv_gflops))]

print("Geomean:", exp(total_speedup_log / len(speedup_list)))
print("Average:", total_speedup / len(speedup_list))

parallelism = np.array(parallelism)
speedup_list = np.array(speedup_list)
#plt.yscale("log")
plt.scatter(parallelism, speedup_list)
#plt.plot(matrix_id, cusparse_gflops)
#plt.plot(matrix_id, yy_gflops)
plt.xscale("log")
plt.yscale("log")
plt.xlabel("matrix " + x_name)
plt.ylabel("speedup")
plt.savefig(picname)

with open('../suitesparse/slow_list', 'w') as f_out:
    for item in no_speedup_matrix:
        f_out.write(item)
        f_out.write("\n")


