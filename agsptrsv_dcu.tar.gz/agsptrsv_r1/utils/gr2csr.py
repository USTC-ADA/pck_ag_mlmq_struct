#!/usr/bin/env python3
"""
Convert DIMACS .gr graph file to AG-SpTRSV custom .csr format.

Supported .gr formats:
  1. DIMACS:   p sp <n_vertices> <n_edges>   +  a <src> <dst> <weight>
  2. 9th DIMACS: p max <n_vertices> <n_edges> +  a <src> <dst> <weight>
  3. Edge:     p edge <n_vertices> <n_edges>  +  e <src> <dst>
  4. Simple:   <n_vertices> <n_edges> on first line, then <src> <dst> [weight]

Output .csr format (lower triangular matrix):
  Line 1: m nnz
  Line 2: csrRowPtr[0] ... csrRowPtr[m-1]
  Line 3: csrColIdx[0] ... csrColIdx[nnz-1]
  Line 4: csrVal[0] ... csrVal[nnz-1]
"""

import sys
import os


def is_binary_file(filepath, check_bytes=4096):
    """Check if file appears to be binary (not text)."""
    with open(filepath, 'rb') as f:
        chunk = f.read(check_bytes)
    if not chunk:
        return False
    # Text bytes: tab(9), LF(10), CR(13), printable ASCII(32-126)
    text_bytes = {9, 10, 13} | set(range(32, 127))
    non_text_count = sum(1 for b in chunk if b not in text_bytes)
    return non_text_count / len(chunk) > 0.30


def parse_gr(filepath):
    """Parse a .gr file, return (n_vertices, edges_list)."""
    edges = []  # list of (src, dst, weight)
    n_vertices = 0

    # Detect binary files early — .gr must be DIMACS text format
    if is_binary_file(filepath):
        print("[ERROR] File appears to be binary, not DIMACS text format.", file=sys.stderr)
        print("  This converter only handles text-based .gr files.", file=sys.stderr)
        print("  For binary matrix files, use the C++ conversion pipeline:", file=sys.stderr)
        print("    cd suitesparse", file=sys.stderr)
        print("    g++ transfer_to_tri.cpp ../utils/utils.cpp -o transfer", file=sys.stderr)
        print("    ./transfer <matrix_name>", file=sys.stderr)
        print("  Or provide the matrix in .csr text format directly.", file=sys.stderr)
        sys.exit(1)

    with open(filepath, 'r', encoding='latin-1') as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith('#') or line.startswith('%'):
                continue
            parts = line.split()
            first = parts[0]

            if first == 'c':
                # comment line, skip
                continue
            elif first == 'p':
                # problem line: p sp/max/edge n m
                if len(parts) >= 3:
                    n_vertices = int(parts[2])
            elif first == 'a':
                # arc line: a src dst [weight]
                src = int(parts[1])
                dst = int(parts[2])
                weight = float(parts[3]) if len(parts) >= 4 else 1.0
                edges.append((src, dst, weight))
            elif first == 'e':
                # edge line: e src dst [weight]
                src = int(parts[1])
                dst = int(parts[2])
                weight = float(parts[3]) if len(parts) >= 4 else 1.0
                edges.append((src, dst, weight))
            elif first.isdigit() and n_vertices == 0:
                # Possibly headerless format: first line is "n_vertices n_edges"
                if len(parts) == 2:
                    n_vertices = int(parts[0])
                    # parts[1] is n_edges, not needed
                    continue
                elif len(parts) >= 2:
                    # Could be an edge line without prefix
                    try:
                        src = int(parts[0])
                        dst = int(parts[1])
                        weight = float(parts[2]) if len(parts) >= 3 else 1.0
                        edges.append((src, dst, weight))
                    except ValueError:
                        pass
            elif first == 'n':
                # node descriptor line, skip
                continue
            else:
                # Try parsing as edge: src dst [weight]
                try:
                    src = int(parts[0])
                    dst = int(parts[1])
                    weight = float(parts[2]) if len(parts) >= 3 else 1.0
                    edges.append((src, dst, weight))
                except (ValueError, IndexError):
                    pass

    return n_vertices, edges


def gr_to_csr(n, edges):
    """
    Convert graph edges to lower-triangular CSR matrix.
    Returns (m, nnz, row_ptr, col_idx, values).
    """
    m = n
    if m == 0:
        return 0, 0, [0], [], []

    # Group edges by source row, only keep lower triangle + diagonal
    row_entries = {i: [] for i in range(m)}

    for src, dst, weight in edges:
        u = src - 1  # convert to 0-indexed
        v = dst - 1
        if u >= v:  # lower triangle (including diagonal)
            row_entries[u].append((v, weight))
        elif v >= u:  # also check reverse direction
            row_entries[v].append((u, weight))

    # Ensure every row has a diagonal entry
    for i in range(m):
        has_diag = any(v == i for v, _ in row_entries[i])
        if not has_diag:
            row_entries[i].append((i, 1.0))

    # Sort columns within each row
    for i in range(m):
        row_entries[i].sort(key=lambda x: x[0])

    # Build CSR arrays
    row_ptr = [0] * (m + 1)
    col_idx = []
    values = []

    for i in range(m):
        row_ptr[i] = len(col_idx)
        for v, w in row_entries[i]:
            col_idx.append(v)
            values.append(w)
    row_ptr[m] = len(col_idx)

    nnz = len(col_idx)
    return m, nnz, row_ptr, col_idx, values


def write_csr(filepath, m, nnz, row_ptr, col_idx, values):
    """Write the custom CSR format expected by read_tri()."""
    with open(filepath, 'w') as f:
        # Line 1: m nnz
        f.write("{} {}\n".format(m, nnz))
        # Line 2: row_ptr (space-separated, trailing space OK)
        f.write(' '.join(str(rp) for rp in row_ptr[:m]) + '\n')
        # Line 3: col_idx
        f.write(' '.join(str(ci) for ci in col_idx) + '\n')
        # Line 4: values
        f.write(' '.join('{:.10g}'.format(v) for v in values) + '\n')


def main():
    if len(sys.argv) < 2:
        print("Usage: {} <input.gr> [output.csr]".format(sys.argv[0]))
        print("Converts DIMACS .gr graph to AG-SpTRSV .csr format")
        sys.exit(1)

    input_path = sys.argv[1]
    if len(sys.argv) >= 3:
        output_path = sys.argv[2]
    else:
        base = os.path.splitext(input_path)[0]
        output_path = base + '.csr'

    print("Converting: {} -> {}".format(input_path, output_path), file=sys.stderr)

    n_vertices, edges = parse_gr(input_path)
    print("  Vertices: {}, Edges: {}".format(n_vertices, len(edges)), file=sys.stderr)

    if n_vertices == 0:
        print("[ERROR] Parsed 0 vertices. File format may not be recognized.", file=sys.stderr)
        print("  Showing first 10 non-comment lines:", file=sys.stderr)
        with open(input_path, 'r', encoding='latin-1') as f:
            count = 0
            for line in f:
                line = line.strip()
                if not line or line.startswith('#') or line.startswith('%') or line.startswith('c'):
                    continue
                print("    {}".format(line), file=sys.stderr)
                count += 1
                if count >= 10:
                    break
        sys.exit(1)

    m, nnz, row_ptr, col_idx, values = gr_to_csr(n_vertices, edges)
    print("  Output: m={}, nnz={} (lower triangular)".format(m, nnz), file=sys.stderr)

    write_csr(output_path, m, nnz, row_ptr, col_idx, values)
    print("  Written: {}".format(output_path), file=sys.stderr)


if __name__ == '__main__':
    main()
