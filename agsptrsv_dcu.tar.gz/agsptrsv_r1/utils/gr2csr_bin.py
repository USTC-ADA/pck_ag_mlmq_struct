#!/usr/bin/env python3
"""
Convert binary .gr matrix files to AG-SpTRSV custom .csr format.

The binary .gr format (little-endian) found in practice for block-diagonal
triangular matrices:

  Header (4 x int64):
    [0] = version
    [1] = num_blocks
    [2] = total_rows (m)
    [3] = total_nnz

  Per-block data (repeated num_blocks times), block b covers rows
    [b*rows_per_block, (b+1)*rows_per_block):
    row_ptr  — rows_per_block int64, 1-based cumulative nnz within block
               (stored[i] = nnz count through row i; block_nnz = stored[last])
    col_idx  — block_nnz int32, block-local column indices
    values   — block_nnz int32, integer weights (cast to float)

  Trailing 8-byte padding.

Because the exact column-indexing convention (0-based / 1-based / block-local)
varies across producers, this converter AUTO-DETECTS the layout: it tries
several candidate interpretations and validates each against the rules of a
solvable lower-triangular system (col in [0,m), col <= row, every row has a
diagonal entry). The first interpretation that passes is written out.

Output .csr format (matches read_tri() in utils/utils.cpp):
  Line 1: m nnz
  Line 2: csrRowPtr[0] ... csrRowPtr[m-1]        (m values; read_tri sets [m]=nnz)
  Line 3: csrColIdx[0] ... csrColIdx[nnz-1]
  Line 4: csrVal[0] ... csrVal[nnz-1]
"""

import sys
import os
import struct


# ---------------------------------------------------------------------------
# Low-level readers
# ---------------------------------------------------------------------------

def read_int64_array(raw, byte_off, count):
    """Read `count` little-endian signed int64 starting at byte_off."""
    size = count * 8
    return list(struct.unpack('<%dq' % count, raw[byte_off:byte_off + size]))


def read_int32_array(raw, byte_off, count):
    """Read `count` little-endian signed int32 starting at byte_off."""
    if count <= 0:
        return []
    size = count * 4
    return list(struct.unpack('<%di' % count, raw[byte_off:byte_off + size]))


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------

def validate(m, nnz, row_ptr, col_idx):
    """
    Check that the matrix is a valid solvable lower-triangular system:
      - row_ptr has m+1 entries, row_ptr[0]==0, row_ptr[m]==nnz, non-decreasing
      - each col in [0, m)
      - col <= row for every entry (lower triangular)
      - every row has a diagonal entry (col == row present)
    Returns (ok, reason).
    """
    if len(row_ptr) != m + 1:
        return False, "row_ptr length %d != m+1=%d" % (len(row_ptr), m + 1)
    if len(col_idx) != nnz:
        return False, "col_idx length %d != nnz=%d" % (len(col_idx), nnz)
    if row_ptr[0] != 0:
        return False, "row_ptr[0]=%d != 0" % row_ptr[0]
    if row_ptr[m] != nnz:
        return False, "row_ptr[m]=%d != nnz=%d" % (row_ptr[m], nnz)

    diag_seen = [False] * m
    for r in range(m):
        s, e = row_ptr[r], row_ptr[r + 1]
        if s > e:
            return False, "row %d: row_ptr decreasing" % r
        if s < 0 or e > nnz:
            return False, "row %d: row_ptr out of range" % r
        if e == s:
            return False, "row %d: empty (no diagonal)" % r
        for k in range(s, e):
            c = col_idx[k]
            if c < 0 or c >= m:
                return False, "row %d: col %d out of [0,%d)" % (r, c, m)
            if c > r:
                return False, "row %d: col %d > row (upper triangular)" % (r, c)
            if c == r:
                diag_seen[r] = True
    if not all(diag_seen):
        missing = [i for i, s in enumerate(diag_seen) if not s]
        return False, "missing diagonals at rows %s" % missing[:10]
    return True, "ok"


def validate_upper(m, nnz, row_ptr, col_idx):
    """
    Check that the matrix is a valid solvable upper-triangular system:
      - row_ptr has m+1 entries, row_ptr[0]==0, row_ptr[m]==nnz, non-decreasing
      - each col in [0, m)
      - col >= row for every entry (upper triangular)
      - every row has a diagonal entry (col == row present)
    Returns (ok, reason).
    """
    if len(row_ptr) != m + 1:
        return False, "row_ptr length %d != m+1=%d" % (len(row_ptr), m + 1)
    if len(col_idx) != nnz:
        return False, "col_idx length %d != nnz=%d" % (len(col_idx), nnz)
    if row_ptr[0] != 0:
        return False, "row_ptr[0]=%d != 0" % row_ptr[0]
    if row_ptr[m] != nnz:
        return False, "row_ptr[m]=%d != nnz=%d" % (row_ptr[m], nnz)

    diag_seen = [False] * m
    for r in range(m):
        s, e = row_ptr[r], row_ptr[r + 1]
        if s > e:
            return False, "row %d: row_ptr decreasing" % r
        if s < 0 or e > nnz:
            return False, "row %d: row_ptr out of range" % r
        if e == s:
            return False, "row %d: empty (no diagonal)" % r
        for k in range(s, e):
            c = col_idx[k]
            if c < 0 or c >= m:
                return False, "row %d: col %d out of [0,%d)" % (r, c, m)
            if c < r:
                return False, "row %d: col %d < row (lower triangular, expected upper)" % (r, c)
            if c == r:
                diag_seen[r] = True
    if not all(diag_seen):
        missing = [i for i, s in enumerate(diag_seen) if not s]
        return False, "missing diagonals at rows %s" % missing[:10]
    return True, "ok"


def transpose_upper_to_lower(m, nnz, row_ptr, col_idx, values):
    """
    Transpose an upper-triangular CSR matrix to lower-triangular form.
    For each entry (r, c, v) with c >= r, place (c, r, v) in output.
    Diagonal entries (r == c) stay in place after transpose.
    Returns (out_row_ptr, out_col_idx, out_values).
    """
    out_counts = [0] * m
    for r in range(m):
        for k in range(row_ptr[r], row_ptr[r + 1]):
            c = col_idx[k]
            out_counts[c] += 1

    out_row_ptr = [0] * (m + 1)
    for i in range(m):
        out_row_ptr[i + 1] = out_row_ptr[i] + out_counts[i]

    out_col_idx = [0] * nnz
    out_values = [0.0] * nnz
    cur_pos = [0] * m

    for r in range(m):
        for k in range(row_ptr[r], row_ptr[r + 1]):
            c = col_idx[k]
            v = values[k]
            pos = out_row_ptr[c] + cur_pos[c]
            out_col_idx[pos] = r
            out_values[pos] = v
            cur_pos[c] += 1

    return out_row_ptr, out_col_idx, out_values


# ---------------------------------------------------------------------------
# Candidate interpretations
# ---------------------------------------------------------------------------

def _diag_anchor_col(row_ptr, raw_col, m):
    """
    Given 0-based row_ptr and raw (block-local) col_idx, recover global
    columns by anchoring on each row's diagonal (last entry == diagonal,
    global col == row index). Returns global col_idx or None on failure.
    """
    out = [0] * len(raw_col)
    for r in range(m):
        s, e = row_ptr[r], row_ptr[r + 1]
        if e <= s or s < 0 or e > len(raw_col):
            return None
        last_local = raw_col[e - 1]
        base = r - last_local  # so that global(last) = base + last_local = r
        for k in range(s, e):
            g = base + raw_col[k]
            out[k] = g
    return out


def try_global(raw, m, nnz):
    """Global CSR: row_ptr = m int64@32 (0-based cumulative count, i.e.
    stored[i] = rp[i+1]), col_idx = nnz int32@(32+8m),
    values = nnz int32@(32+8m+4nnz). Try col bases 1-based, 0-based, diag-anchor."""
    rp_raw = read_int64_array(raw, 32, m)
    # stored[i] is the 0-based cumulative nnz count through row i, so it equals
    # the 0-based row_ptr[i+1] directly (no base adjustment).
    row_ptr = [0] + list(rp_raw)              # length m+1
    row_ptr[m] = nnz                          # enforce sentinel

    col_off = 32 + 8 * m
    val_off = col_off + 4 * nnz
    raw_col = read_int32_array(raw, col_off, nnz)
    values = [float(v) for v in read_int32_array(raw, val_off, nnz)]

    results = []
    # 1-based global
    col1 = [c - 1 for c in raw_col]
    results.append(("global_col_1based", row_ptr[:], col1, values[:]))
    # 0-based global
    results.append(("global_col_0based", row_ptr[:], raw_col[:], values[:]))
    # diag-anchor (block-local)
    col_anchor = _diag_anchor_col(row_ptr, raw_col, m)
    if col_anchor is not None:
        results.append(("global_col_diaganchor", row_ptr[:], col_anchor, values[:]))
    return results


def try_perblock(raw, m, nnz, num_blocks):
    """Per-block CSR: row_ptr (m int64, global-cumulative) stored contiguously
    at byte 32, then nnz int32 col_idx, then nnz int32 values.
    Slice per-block data from these contiguous arrays and adjust."""
    rpb = m // num_blocks if num_blocks > 0 else m
    if rpb * num_blocks != m:
        return []  # uneven; skip

    # T1.1: Read all arrays from contiguous global offsets
    # - m int64 row_ptr values from byte 32
    # - nnz int32 col_idx values from byte 32 + 8*m
    # - nnz int32 values from byte 32 + 8*m + 4*nnz
    min_size = 32 + 8 * m + 8 * nnz
    if len(raw) < min_size:
        return []

    all_rp_raw = read_int64_array(raw, 32, m)
    if len(all_rp_raw) != m:
        return []

    col_off = 32 + 8 * m
    val_off = col_off + 4 * nnz
    all_col = read_int32_array(raw, col_off, nnz)
    all_vals = read_int32_array(raw, val_off, nnz)
    if len(all_col) != nnz or len(all_vals) != nnz:
        return []

    # Verify global row_ptr is non-decreasing
    if m > 1 and any(all_rp_raw[i] > all_rp_raw[i + 1] for i in range(m - 1)):
        return []

    # T1.2: Slice per-block data and build global CSR structures
    global_row_ptr = [0]
    global_col_1 = []
    global_col_0 = []
    global_col_anchor = []
    values_global = []
    ok = True
    prev_cum = 0   # cumulative nnz from previous blocks

    for b in range(num_blocks):
        base_row = b * rpb

        # 1) Slice this block's row_ptr from global array
        block_rp_raw = all_rp_raw[b * rpb : (b + 1) * rpb]
        if len(block_rp_raw) != rpb:
            ok = False
            break

        # 2) Compute block-local 1-based row_ptr by subtracting prev_cum
        block_rp_local = [v - prev_cum for v in block_rp_raw]

        # 3) block_nnz is last cumulative value (1-based within block)
        block_nnz = block_rp_local[-1] if block_rp_local else 0

        # 4) Sanity checks
        if block_nnz < 0 or block_nnz > (nnz - prev_cum):
            ok = False
            break
        if len(block_rp_local) > 1 and any(
            block_rp_local[i] > block_rp_local[i + 1]
            for i in range(len(block_rp_local) - 1)
        ):
            ok = False
            break

        # 5) Build 0-based local row_ptr: rp0 = [0] + block_rp_local
        rp0 = [0] + block_rp_local   # length rpb+1

        # 6) Append to global_row_ptr
        for i in range(rpb):
            global_row_ptr.append(prev_cum + rp0[i + 1])

        # 7) Slice columns and values for this block
        col_local = all_col[prev_cum : prev_cum + block_nnz]
        val_local = all_vals[prev_cum : prev_cum + block_nnz]
        if len(col_local) != block_nnz or len(val_local) != block_nnz:
            ok = False
            break

        # 8) Build 1-based global columns: col = base_row + (c - 1)
        for c in col_local:
            global_col_1.append(base_row + (c - 1))
            global_col_0.append(base_row + c)
            global_col_anchor.append(None)  # filled below
        for v in val_local:
            values_global.append(float(v))

        # 9) Diag-anchor for this block's rows
        for i in range(rpb):
            r = base_row + i
            s, e = global_row_ptr[r], global_row_ptr[r + 1]
            if e <= s:
                ok = False
                break
            # Last column of this row in block-local indexing
            last_local = col_local[e - 1 - prev_cum]
            anchor_base = r - last_local
            for k in range(s, e):
                local = col_local[k - prev_cum]
                global_col_anchor[k] = anchor_base + local
        if not ok:
            break

        # 10) Advance cumulative nnz tracker
        prev_cum += block_nnz

    if not ok:
        return []

    global_row_ptr[m] = nnz

    candidates = []
    candidates.append(("perblock_col_1based", global_row_ptr[:], global_col_1, values_global))
    candidates.append(("perblock_col_0based", global_row_ptr[:], global_col_0, values_global))
    candidates.append(("perblock_col_diaganchor", global_row_ptr[:], global_col_anchor, values_global))
    return candidates


# ---------------------------------------------------------------------------
# Output
# ---------------------------------------------------------------------------

def filter_lower_triangular(m, nnz, row_ptr, col_idx, values):
    """Filter CSR to keep only lower-triangular entries (col <= row).
    Ensures every row has a diagonal entry (col == row, value=1.0 if missing).
    Entries within each row are sorted by column so the diagonal is always last.
    Returns (new_nnz, new_row_ptr, new_col_idx, new_values)."""
    new_row_ptr = [0]
    new_col = []
    new_val = []
    for r in range(m):
        s, e = row_ptr[r], row_ptr[r + 1]
        # Collect and sort lower-triangular entries for this row
        row_entries = []
        has_diag = False
        for k in range(s, e):
            c = col_idx[k]
            if c <= r:
                v = values[k]
                # INT_MIN (-2^31) is a placeholder in binary format, skip
                if int(v) == -2147483648:
                    continue
                val = 1.0 if ALL_ONES else v
                row_entries.append((c, val))
                if c == r:
                    has_diag = True
        if not has_diag:
            row_entries.append((r, 1.0))
        row_entries.sort(key=lambda x: x[0])
        # Ensure diagonal value is positive (last entry after sort):
        # source data uses INT_MIN (-2^31) as placeholder, also handle 0
        if row_entries and row_entries[-1][0] == r and (row_entries[-1][1] <= 0.0 or ALL_ONES):
            row_entries[-1] = (r, 1.0)
        for c, v in row_entries:
            new_col.append(c)
            new_val.append(v)
        new_row_ptr.append(len(new_col))
    new_nnz = len(new_col)
    return new_nnz, new_row_ptr, new_col, new_val

ALL_ONES = True  # True: treat matrix as structural with unit values


def filter_lower_triangular_large(raw, m, nnz, output_path):
    """Streaming filter for large matrices: read row_ptr once, iterate rows
    reading col/val from raw bytes per-row, filter col <= row, write output.
    Avoids loading all nnz cols+vals into Python lists at once."""
    print("  Reading row_ptr ({} int64)...".format(m), file=sys.stderr)
    rp_raw = read_int64_array(raw, 32, m)
    row_ptr = [0] + list(rp_raw)
    row_ptr[m] = nnz

    col_off = 32 + 8 * m
    val_off = col_off + 4 * nnz

    out_nnz = 0
    out_row_ptr = [0]
    out_col = []
    out_val = []

    for r in range(m):
        s, e = row_ptr[r], row_ptr[r + 1]
        nnz_row = e - s

        # Collect and sort lower-triangular entries for this row
        row_entries = []
        has_diag = False

        if nnz_row > 0:
            cols_row = list(struct.unpack(
                '<%di' % nnz_row, raw[col_off + s * 4:col_off + e * 4]))
            vals_row = list(struct.unpack(
                '<%di' % nnz_row, raw[val_off + s * 4:val_off + e * 4]))
            for c, v in zip(cols_row, vals_row):
                if c <= r:
                    # INT_MIN (-2^31) is a placeholder, skip
                    if v == -2147483648:
                        continue
                    val = 1.0 if ALL_ONES else float(v)
                    row_entries.append((c, val))
                    if c == r:
                        has_diag = True

        if not has_diag:
            row_entries.append((r, 1.0))
        row_entries.sort(key=lambda x: x[0])
        # Ensure diagonal value is positive (last entry after sort)
        if row_entries and row_entries[-1][0] == r and (row_entries[-1][1] <= 0.0 or ALL_ONES):
            row_entries[-1] = (r, 1.0)
        for c, v in row_entries:
            out_col.append(c)
            out_val.append(v)
            out_nnz += 1

        out_row_ptr.append(out_nnz)

        if r % 100000 == 0 and r > 0:
            print("  Processing row {}/{} ({} nnz output)...".format(
                r, m, out_nnz), file=sys.stderr)

    print("  Filtered: m={}, nnz={} (was {} nnz)".format(
        m, out_nnz, nnz), file=sys.stderr)
    write_csr(output_path, m, out_nnz, out_row_ptr, out_col, out_val)
    print("Written: {}".format(output_path), file=sys.stderr)


def write_csr(filepath, m, nnz, row_ptr, col_idx, values):
    with open(filepath, 'w') as f:
        f.write("{} {}\n".format(m, nnz))
        f.write(' '.join(str(rp) for rp in row_ptr[:m]) + '\n')
        f.write(' '.join(str(ci) for ci in col_idx) + '\n')
        f.write(' '.join('{:.10g}'.format(v) for v in values) + '\n')


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    if len(sys.argv) < 2:
        print("Usage: {} <input.gr> [output.csr]".format(sys.argv[0]),
              file=sys.stderr)
        sys.exit(1)

    LARGE_NNZ = 5000000

    input_path = sys.argv[1]
    output_path = sys.argv[2] if len(sys.argv) >= 3 else \
        os.path.splitext(input_path)[0] + '.csr'

    with open(input_path, 'rb') as f:
        raw = f.read()

    if len(raw) < 32:
        print("[ERROR] File too small to contain header.", file=sys.stderr)
        sys.exit(1)

    version, num_blocks, m, nnz = read_int64_array(raw, 0, 4)
    print("Header: version={}, num_blocks={}, m={}, nnz={}".format(
        version, num_blocks, m, nnz), file=sys.stderr)
    print("File size: {} bytes ({} int64)".format(len(raw), len(raw) // 8),
          file=sys.stderr)

    if m <= 0 or nnz <= 0:
        print("[ERROR] Empty matrix (m={}, nnz={}).".format(m, nnz),
              file=sys.stderr)
        sys.exit(1)

    if nnz > LARGE_NNZ:
        print("[INFO] Large matrix (nnz={} > {}), using streaming filter."
              .format(nnz, LARGE_NNZ), file=sys.stderr)
        filter_lower_triangular_large(raw, m, nnz, output_path)
        sys.exit(0)

    # Build candidate interpretations
    candidates = []
    candidates.extend(try_global(raw, m, nnz))
    candidates.extend(try_perblock(raw, m, nnz, num_blocks))

    print("Trying {} candidate layout(s)...".format(len(candidates)),
          file=sys.stderr)

    chosen = None
    for name, rp, col, vals in candidates:
        ok, reason = validate(m, nnz, rp, col)
        print("  [{:>26s}] -> {}".format(name, "PASS" if ok else "FAIL: " + reason),
              file=sys.stderr)
        if ok and chosen is None:
            chosen = (name, rp, col, vals)

    if chosen is None:
        print("No lower-triangular layout found, trying upper-triangular...",
              file=sys.stderr)
        for name, rp, col, vals in candidates:
            ok, reason = validate_upper(m, nnz, rp, col)
            print("  [{:>26s}] -> {}".format(name,
                  "PASS (upper)" if ok else "FAIL: " + reason), file=sys.stderr)
            if ok and chosen is None:
                print("Transposing upper to lower triangular...", file=sys.stderr)
                rp_trans, col_trans, vals_trans = transpose_upper_to_lower(
                    m, nnz, rp, col, vals)
                chosen = (name + "_transposed", rp_trans, col_trans, vals_trans)

    if chosen is None:
        print("[WARN] No triangular layout detected; extracting lower triangle from global CSR.",
              file=sys.stderr)
        rp_raw = read_int64_array(raw, 32, m)
        row_ptr = [0] + list(rp_raw)
        row_ptr[m] = nnz
        col_off = 32 + 8 * m
        val_off = col_off + 4 * nnz
        raw_col = read_int32_array(raw, col_off, nnz)
        raw_val = read_int32_array(raw, val_off, nnz)
        values = [float(v) for v in raw_val]
        new_nnz, new_rp, new_col, new_val = filter_lower_triangular(
            m, nnz, row_ptr, raw_col, values)
        chosen = ("global_col_0based_filtered", new_rp, new_col, new_val)
        print("  Filtered: m={}, nnz={} (was {} nnz)".format(
            m, new_nnz, nnz), file=sys.stderr)

    name, rp, col, vals = chosen
    print("Selected layout: {}".format(name), file=sys.stderr)

    out_nnz = len(col)
    write_csr(output_path, m, out_nnz, rp, col, vals)
    print("Output: m={}, nnz={}".format(m, out_nnz), file=sys.stderr)
    print("Written: {}".format(output_path), file=sys.stderr)


if __name__ == '__main__':
    main()
