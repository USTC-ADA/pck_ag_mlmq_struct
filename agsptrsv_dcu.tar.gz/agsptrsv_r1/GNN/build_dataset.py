import sys

from SpTRSV_dataset import SpTRSVDataset

import torch
from torch_geometric.data import Data, Dataset

if (len(sys.argv) != 3):
    print("Usage: python main.py {raw dir} {processed dir}")
    exit(1)

raw_dir = sys.argv[1]
processed_dir = sys.argv[2]

my_dataset = SpTRSVDataset(processed_dir, raw_dir = raw_dir)
my_dataset.save()