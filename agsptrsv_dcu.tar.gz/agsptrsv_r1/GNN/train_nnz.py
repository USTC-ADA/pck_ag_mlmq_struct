from GNN_read import read_data
from GNN_draw import draw_graph

from SpTRSV_dataset import SpTRSVDataset

import sys

import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.utils.data
from torch.optim import Adam
from torch_geometric.data import Data
from torch_geometric.loader import DataLoader
import math
from math import log

import random

from model import GCN_nnz

if (len(sys.argv) != 2):
    print("Usage: python main.py {input dir}")

dataset = SpTRSVDataset(sys.argv[1])

batch_size = 16

train_size = int(len(dataset) * 0.7)
test_size = len(dataset) - train_size

train_set, test_set = torch.utils.data.random_split(dataset, [train_size, test_size])

train_loader = DataLoader(train_set, batch_size = batch_size, shuffle = True)
test_loader = DataLoader(test_set, batch_size = batch_size, shuffle = True)

# print(loader.batch[0].x)
print(len(dataset) / batch_size / 10)

model = GCN_nnz(node_feature = 1, n_hidden = 128, out_node_feature = 32, out_feature = 1, dropout = 0.5)

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

class MAPE(nn.Module):
    def __init__(self):
        super().__init__()
        
    def forward(self, x, y):
        return torch.mean(torch.pow((x - y), 2) / torch.pow(y, 2))
        #return abs(x - y) / y

loss_func = MAPE()
optimizer = Adam(model.parameters(), lr=2e-4, weight_decay=1e-4)

model = model.to(device)

model.train()

for epoch in range(10):
    running_loss = 0.0
    for i, batch in enumerate(train_loader):
        if (i == 0):
            print(torch.sum(batch.x[:, 0], dim=0))
            #print(batch.x)
            try_ground = torch.tensor( \
            float(torch.sum(batch.x[:, 0], dim=0)) \
            )
            batch = batch.to(device)
            print(try_ground, model(batch))

        loss = torch.tensor(0.0)

        #print(batch.edge_index)

        # total_num = len(batch.x)
        # for item in batch.edge_index[0]:
        #     if (item >= total_num):
        #         print(batch.x, batch.edge_index[0])
        #         print("Error")
        #         break
        # for item in batch.edge_index[1]:
        #     if (item >= total_num):
        #         print(batch.x, batch.edge_index[0])
        #         print("Error")
        #         break

        optimizer.zero_grad()
        batch = batch.to(device)
        res = model(batch)

        #print(res)

        #try
        try_ground = torch.tensor(float(torch.sum(batch.x, dim=0)))
        try_ground = try_ground.to(device)

        loss = loss_func(res, try_ground.reshape(1, -1))

        loss.backward()
        optimizer.step()

        running_loss += loss.item()

        if i % int(len(dataset) / batch_size / 10) == 0:    # print every 2000 mini-batches
            print('[%d, %5d] loss: %.3f' %
                  (epoch, i, running_loss / 100))
            running_loss = 0.0
    print(f"epoch {epoch} done!")

model.eval()

total_loss = 0
for i, data in enumerate(test_loader):
    if (data.edge_index.size(1) > 0):
        #data.x = data.x / data_len
        data = data.to(device)
        #data.x = data.x / data_len
        res = model(data)

        #try
        try_ground = torch.tensor(float(torch.sum(data.x, dim=0)))
        try_ground = try_ground.to(device)

        if (i == 0):
            print(res)
            print(try_ground)

        #loss = loss_func(res, try_ground.reshape(1, -1))
        loss = abs(res - try_ground) / try_ground
        total_loss += loss

print(test_size)
total_loss /= test_size
print(total_loss.item())

_, pred = res.max(dim=1)
correct = float (pred.eq(data.y).sum().item())
# acc = correct / data.val_mask.sum().item()
# print("当前运行：{}，训练集精度是：{:.4f}".format(epoch,acc))

    
