from GNN_read import read_data
from GNN_draw import draw_graph

import torch
from torch_geometric.data import Data
from torch_geometric.data import Dataset

import os

class SpTRSVDataset(Dataset):
    def __init__(self, processed_dir, raw_dir=None, transform=None, pre_transform=None, pre_filter=None):
        self.raw = raw_dir
        self.processed = processed_dir
        super(SpTRSVDataset, self).__init__(processed_dir, transform, pre_transform, pre_filter)

    @property
    def raw_file_names(self):
        Filelist = []
        for home, dirs, files in os.walk(self.raw):
            for filename in files:
                if (".data" in filename):
                    Filelist.append(os.path.join(home, filename))
        return Filelist

    @property
    def processed_file_names(self):
        Filelist = []
        for home, dirs, files in os.walk(self.processed):
            for filename in files:
                if ("data" in filename and ".pt" in filename):
                    Filelist.append(os.path.join(home, filename))
        return Filelist

    def process(self):
        pass
    
    def save(self):
        if (self.raw == None):
            print("Error: raw data directory not specified!")
            return
        idx = 0
        print(f"Loading data from {self.raw}")
        print(f"Saving data to    {self.processed}")
        for raw_path in self.raw_file_names:
            # Read data from `raw_path`.
            num_node, num_edge, layer, parallelism, \
            node_feature, edge_data, label = read_data(raw_path)
            if (not edge_data[0]):
                continue
            error_flag = 0
            total_num = len(node_feature)
            for i1, i2 in zip(edge_data[0], edge_data[1]):
                if (i1 >= total_num or i2 >= total_num):
                    print(f"Edge index error in {raw_path}")
                    error_flag = 1
                    break

            if (error_flag): continue
            
            node_attr = torch.tensor(node_feature)
            edge_index = torch.tensor(edge_data)
            label = torch.tensor(label)

            global_info = torch.tensor([num_node, num_edge, layer, parallelism])

            data = Data(x = node_attr, edge_index = edge_index, y = label,
            global_info = global_info)

            if self.pre_filter is not None and not self.pre_filter(data):
                continue

            if self.pre_transform is not None:
                data = self.pre_transform(data)

            torch.save(data, os.path.join(self.processed, f'data_{idx}.pt'))
            idx += 1

    def len(self):
        return len(self.processed_file_names)
    
    def get(self, idx):
        data = torch.load(os.path.join(self.processed, f'data_{idx}.pt'))
        return data

class SpTRSVDataset_ex(SpTRSVDataset):
    def __init__(self, processed_dir, raw_dir=None, transform=None, pre_transform=None, pre_filter=None):
        self.raw = raw_dir
        self.processed = processed_dir
        super(SpTRSVDataset_ex, self).__init__(processed_dir, transform, pre_transform, pre_filter)

    def get(self, idx):
        data = torch.load(os.path.join(self.processed, f'data_{idx}.pt'))

        edge_attr = []
        edge_idx = []

        for i in range(len(data.edge_index[0])):
            edge_attr.append([1.0, 0.0])

        edge_idx = []

        i1 = []
        i2 = []
        i1 = data.edge_index[0].tolist()
        i2 = data.edge_index[1].tolist()
        for i in range(len(data.x) - 1):
            i1.append(i)
            i2.append(i)
            edge_attr.append([0.0, 1.0])

        data.edge_index = torch.tensor([i1, i2])
        data.edge_attr = torch.tensor(edge_attr)

        return data
