from GNN_read import read_data
from GNN_draw import draw_graph

import sys

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.data import Data

from model import GCN

if (len(sys.argv) != 2):
    print("Usage: python main.py {input file}")

num_node, num_edge, node_feature, edge_data, label = read_data(sys.argv[1])

node_attr = torch.tensor(node_feature)
edge_index = torch.tensor(edge_data)
label = torch.tensor(label)

data = Data(x = node_attr, edge_index = edge_index, y = label)

model = GCN(node_feature = 1, n_hidden = 128, out_node_feature = 128, out_feature = data.y.size(0), dropout = 0.5)

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

optimizer = Adam(model.parameters(),lr=0.01,weight_decay=5e-4)

data = data.to(device)
model = model.to(device)

x = model(data)

print(data.y.size(0))

model.train()

# for i in range(0, 100):
#     optimizer.zero_grad()
#     res = model(data)
#     loss = F.nll_loss(res, data.y)
#     loss.backward()
#     optimizer.step()
#     _, pred = res.max(dim=1)
#     correct = float (pred.eq(data.y).sum().item())
#     acc = correct / data.val_mask.sum().item()
#     print("当前运行：{}，验证集精度是：{:.4f}".format(epoch,acc))

# model.eval()
# _, pred = model(data).max(dim=1)
# correct = float (pred[data.test_mask].eq(data.y[data.test_mask]).sum().item())
# acc = correct / data.test_mask.sum().item()
# print('测试集准确率: {:.4f}'.format(acc))
