from GNN_read import read_data
from GNN_draw import draw_graph

from SpTRSV_dataset import SpTRSVDataset_ex

import sys

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.optim import Adam
from torch_geometric.data import Data
from torch_geometric.loader import DataLoader
from math import log

from model import GCN_ps

if (len(sys.argv) != 2):
    print("Usage: python main.py {input dir}")

dataset = SpTRSVDataset_ex(sys.argv[1])

batch_size = 1

loader = DataLoader(dataset, batch_size = batch_size, shuffle = True)

model = GCN_ps(node_feature = 2, n_hidden = 128, out_node_feature = 32, out_feature = 3, dropout = 0.5)

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

class MAPE(nn.Module):
    def __init__(self):
        super().__init__()
        
    def forward(self, x, y):
        return torch.mean(torch.pow((x - y), 2) / torch.pow(y, 2))

#loss_func = MAPE()
loss_func = nn.CrossEntropyLoss()
loss_func2 = nn.MSELoss(reduction="mean")

optimizer = Adam(model.parameters(), lr=1e-4, weight_decay=5e-5)

#model = model.to(device)

model.train()

for epoch in range(1):
    running_loss = 0.0
    for i, batch in enumerate(loader):
        loss = torch.tensor(0.0)

        optimizer.zero_grad()
        #batch = batch.to(device)
        res = model(batch)

        #res = res.to('cpu')

        #target = torch.tensor(int(batch.y[0]))
        target = torch.softmax(batch.y[3:6], dim = 0)
        min_time = min(batch.y[3:6])
        max_time = max(batch.y[3:6])
        if (abs(max_time - min_time) / min_time > 0.05):
            print (i, batch.y[3:6])
        
        loss = loss_func2(res, target)
        #print(res, batch.y[0].long())

        loss.backward()
        optimizer.step()

        # print statistics
        running_loss += loss.item()
        if i % 100 == 99:    # print every 2000 mini-batches
            print('[%d, %5d] loss: %.3f' %
                  (epoch, i, running_loss / 100))
            running_loss = 0.0
        
        #torch.cuda.empty_cache()

stat = torch.zeros(3)

total_accuracy = 0
for i, data in enumerate(loader):
    if (data.edge_index.size(1) > 0):
        #data = data.to(device)
        res = model(data)

        #res = res.to('cpu')

        y = F.one_hot(torch.tensor(int(data.y[0])), num_classes=3)
        y = y.float()

        # print(res, torch.argmax(res))
        # print(y, torch.argmax(y))
        # #input("???")

        if (data.y[0] == torch.argmin(res)):
            total_accuracy += 1

        pos = int(int(data.y[0]))
        stat[pos] += 1

print(stat)

print("Accuracy: ", 1.0 * total_accuracy / len(dataset))