import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.data import Data
from torch_geometric.nn import GCNConv, SAGEConv, GATConv
from torch_geometric.nn import aggr

class GCN_nnz(nn.Module):
    def __init__(self, node_feature, n_hidden, out_node_feature, out_feature, dropout):
        super(GCN_nnz, self).__init__()
        self.dropout = nn.Dropout(p = dropout)
        self.conv1 = GCNConv(in_channels = node_feature, out_channels = n_hidden)
        self.conv2 = GCNConv(in_channels = n_hidden, out_channels = out_node_feature)
        self.sage1 = SAGEConv(in_channels = node_feature, out_channels = n_hidden)
        self.sage2 = SAGEConv(in_channels = n_hidden, out_channels = out_node_feature)
        self.global_pool = aggr.SumAggregation()
        self.linear1 = nn.Linear(in_features = out_node_feature, \
        out_features = 128)
        self.linear2 = nn.Linear(in_features = 128, \
        out_features = out_feature)
        self.linear = nn.Linear(in_features = out_node_feature, \
        out_features = out_feature)
    
    def forward(self, data):
        x, edge_index = data.x, data.edge_index
        #x = self.conv1(x, edge_index)
        print(x[:, 0])
        x = self.sage1(x[:, 0].reshape(-1), edge_index)
        x = F.relu(x)
        x = self.dropout(x)
        #x = self.conv2(x, edge_index)
        x = self.sage2(x, edge_index)
        x = F.relu(x)
        x = self.dropout(x)
        x = self.global_pool(x)
        #x = self.linear(x)
        x = self.linear1(x)
        x = self.linear2(x)
        #x = torch.softmax(x, dim=1)

        return x

class GNN_time(nn.Module):
    def __init__(self, node_feature, n_hidden, out_node_feature, out_feature, dropout):
        super(GNN_time, self).__init__()
        self.dropout = nn.Dropout(p = dropout)
        self.conv1 = GCNConv(in_channels = node_feature, out_channels = n_hidden)
        self.conv2 = GCNConv(in_channels = n_hidden, out_channels = out_node_feature)

        self.sage1 = SAGEConv(in_channels = node_feature, out_channels = n_hidden)
        self.sage2 = SAGEConv(in_channels = n_hidden, out_channels = out_node_feature)
        
        self.gat_in = GATConv(in_channels = node_feature, out_channels = n_hidden, edge_dim = 2)
        self.gat_mid1 = GATConv(in_channels = n_hidden, out_channels = n_hidden, edge_dim = 2)
        self.gat_mid2 = GATConv(in_channels = n_hidden, out_channels = n_hidden, edge_dim = 2)
        self.gat_out = GATConv(in_channels = n_hidden, out_channels = out_node_feature, edge_dim = 2)

        aggr_list = ["mean", "var", "sum", "max"]
        self.global_pool = aggr.MultiAggregation(aggr_list)
        self.linear1 = nn.Linear( len(aggr_list) * out_node_feature + 4, \
        out_features = 128)
        self.linear2 = nn.Linear(in_features = 128, \
        out_features = out_feature)
        self.linear = nn.Linear(in_features = out_node_feature, \
        out_features = out_feature)
    
    def forward(self, data):
        x, edge_index, edge_attr = data.x, data.edge_index, data.edge_attr
        #x = self.conv1(x, edge_index)
        #x = self.sage1(x, edge_index)
        x = self.gat_in(x, edge_index, edge_attr)
        x = F.relu(x)
        x = self.dropout(x)

        # x = self.gat_mid1(x, edge_index, edge_attr)
        # x = F.relu(x)
        # x = self.dropout(x)

        # x = self.gat_mid2(x, edge_index, edge_attr)
        # x = F.relu(x)
        # x = self.dropout(x)
        #x = self.conv2(x, edge_index)
        #x = self.sage2(x, edge_index)
        x = self.gat_out(x, edge_index, edge_attr)
        x = F.relu(x)
        x = self.dropout(x)
        x = self.global_pool(x)
        #x = self.linear(x)
        
        x = torch.cat((x.reshape(-1), data.global_info))
        #x = data.global_info
        #print(x)

        x = self.linear1(x)
        x = self.linear2(x)
        #x = torch.softmax(x, dim=1)

        return x

# class GCN(nn.Module):
#     def __init__(self, node_feature, n_hidden, out_node_feature, out_feature, dropout):
#         super(GCN, self).__init__()
#         self.dropout = nn.Dropout(p = dropout)
#         self.weight2d = nn.Conv2d(in_channels=1,out_channels=1,kernel_size=(1,2))
#         self.conv1 = GCNConv(in_channels = node_feature, out_channels = n_hidden)
#         self.conv2 = GCNConv(in_channels = n_hidden, out_channels = out_node_feature)
#         aggr_list = ["mean", "var", "sum", "max"]
#         self.global_pool = aggr.MultiAggregation(aggr_list)
#         #self.global_pool = aggr.SumAggregation()
#         self.linear1 = nn.Linear(in_features = len(aggr_list) * out_node_feature, \
#         out_features = 128)
#         # self.linear1 = nn.Linear(in_features = out_node_feature, \
#         # out_features = 128)
#         self.linear2 = nn.Linear(in_features = 128, \
#         out_features = out_feature)
#         self.linear = nn.Linear(in_features = out_node_feature, \
#         out_features = out_feature)
    
#     #def forward(self, data):
#     def forward(self, data):
#         x, edge_index, edge_attr = data.x, data.edge_index, data.edge_attr
#         edge_attr = edge_attr.reshape(1, 1, len(edge_attr), -1)
        
#         #print(edge_attr.size())
#         #print("haha")
#         edge_weight = self.weight2d(edge_attr)
#         edge_weight = F.relu(edge_weight)
#         #print("haho")
#         #print(edge_weight.size())
#         edge_weight = edge_weight.reshape(-1)

#         x = self.conv1(x, edge_index, edge_weight)
#         x = F.relu(x)
#         x = self.dropout(x)
#         x = self.conv2(x, edge_index, edge_weight)
#         x = F.relu(x)
#         x = self.dropout(x)
#         x = self.global_pool(x)
#         #x = self.linear(x)
#         x = self.linear1(x)
#         x = self.linear2(x)
#         #x = torch.sigmoid(x)

#         return x

class GCN_ps(nn.Module):
    def __init__(self, node_feature, n_hidden, out_node_feature, out_feature, dropout):
        super(GCN_ps, self).__init__()
        self.dropout = nn.Dropout(p = dropout)
        self.conv1 = GCNConv(in_channels = node_feature, out_channels = n_hidden)
        self.conv2 = GCNConv(in_channels = n_hidden, out_channels = out_node_feature)
        self.gat1 = GATConv(in_channels = node_feature, out_channels = n_hidden, edge_dim = 2)
        self.gat2 = GATConv(in_channels = n_hidden, out_channels = out_node_feature, edge_dim = 2)

        aggr_list = ["mean", "var", "sum", "max"]
        self.global_pool = aggr.MultiAggregation(aggr_list)
        self.linear1 = nn.Linear( len(aggr_list) * out_node_feature + 4, \
        out_features = 128)
        self.linear2 = nn.Linear(in_features = 128, \
        out_features = out_feature)
        self.linear = nn.Linear(in_features = out_node_feature, \
        out_features = out_feature)
    
    def forward(self, data):
        x, edge_index, edge_attr = data.x, data.edge_index, data.edge_attr
        #x = self.conv1(x, edge_index)
        x = self.gat1(x, edge_index, edge_attr)
        x = F.relu(x)
        x = self.dropout(x)
        #x = self.conv2(x, edge_index)
        x = self.gat2(x, edge_index, edge_attr)
        x = F.relu(x)
        x = self.dropout(x)
        x = self.global_pool(x)

        x = torch.cat((x.reshape(-1), data.global_info))
        #x = self.linear(x)
        x = self.linear1(x)
        x = self.linear2(x)
        #print(x)
        x = torch.softmax(x, dim=0)
        #print(x)

        return x

class GCN_rblock(nn.Module):
    def __init__(self, node_feature, n_hidden, out_node_feature, out_feature, dropout):
        super(GCN_rblock, self).__init__()
        self.dropout = nn.Dropout(p = dropout)
        self.conv1 = GCNConv(in_channels = node_feature, out_channels = n_hidden)
        self.conv2 = GCNConv(in_channels = n_hidden, out_channels = out_node_feature)
        self.gat1 = GATConv(in_channels = node_feature, out_channels = n_hidden, edge_dim = 2)
        self.gat2 = GATConv(in_channels = n_hidden, out_channels = out_node_feature, edge_dim = 2)

        aggr_list = ["mean", "var", "sum", "max"]
        self.global_pool = aggr.MultiAggregation(aggr_list)
        self.linear1 = nn.Linear(in_features = len(aggr_list) * out_node_feature, \
        out_features = 128)
        self.linear2 = nn.Linear(in_features = 128, \
        out_features = out_feature)
        self.linear = nn.Linear(in_features = out_node_feature, \
        out_features = out_feature)
    
    def forward(self, data):
        x, edge_index, edge_attr = data.x, data.edge_index, data.edge_attr
        #x = self.conv1(x, edge_index)
        x = self.gat1(x, edge_index, edge_attr)
        x = F.relu(x)
        x = self.dropout(x)
        #x = self.conv2(x, edge_index)
        x = self.gat2(x, edge_index, edge_attr)
        x = F.relu(x)
        x = self.dropout(x)
        x = self.global_pool(x)
        #x = self.linear(x)
        x = self.linear1(x)
        x = self.linear2(x)
        #x = torch.softmax(x, dim=1)

        return x