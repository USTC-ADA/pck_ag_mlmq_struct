import networkx as nx
import matplotlib.pyplot as plt

def draw_graph(filename, num_node, num_edge, node_feature, edge_data):
    G = nx.DiGraph()

    for i in range(0, num_edge):
        G.add_edge(edge_data[0][i], edge_data[1][i])
    
    #print(nx.info(G))

    nx.draw(G)
    plt.savefig(filename)
