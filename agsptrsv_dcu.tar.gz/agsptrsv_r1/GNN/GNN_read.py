def read_data(filename):
    with open(filename, 'r') as f:
        line = f.readline()
    
        global_data = line.strip().split(" ")
        
        num_node = int(global_data[0])
        num_edge = int(global_data[1])
        layer = int(global_data[2])
        parallelism = float(global_data[3])

        node_feature = []
        
        for i in range(0, num_node):
            line = f.readline()
            node_data = line.strip().split(" ")
            node_feature.append([float(item) for item in node_data])
        
        node_feature = [item[1:] for item in sorted(node_feature, key=(lambda x:x[0]))]

        edge_source = []
        edge_dest = []
        
        for i in range(0, num_edge):
            line = f.readline()
            edge_data = line.strip().split(" ")
            edge_source.append(int(edge_data[0]))
            edge_dest.append(int(edge_data[1]))
        
        edge_data = [edge_source, edge_dest]

        line = f.readline()
        label = line.strip().split(" ")
        label = [float(item) for item in label]

    return num_node, num_edge, layer, parallelism, node_feature, edge_data, label
