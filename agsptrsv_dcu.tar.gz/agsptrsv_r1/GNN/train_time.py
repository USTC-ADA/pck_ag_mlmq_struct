from GNN_read import read_data
from GNN_draw import draw_graph

from SpTRSV_dataset import SpTRSVDataset_ex

import gc

import sys

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.optim import Adam
from torch_geometric.data import Data
from torch_geometric.loader import DataLoader
import math
from math import log

from model import GNN_time

if (len(sys.argv) != 2):
    print("Usage: python main.py {input dir}")

dataset = SpTRSVDataset_ex(sys.argv[1])
print(dataset[0].global_info)

batch_size = 1

train_size = int(len(dataset) * 0.7)
test_size = len(dataset) - train_size

train_set, test_set = torch.utils.data.random_split(dataset, [train_size, test_size])

#loader = DataLoader(dataset, batch_size = batch_size, shuffle = True)
train_loader = DataLoader(train_set, batch_size = batch_size, shuffle = True)
test_loader = DataLoader(test_set, batch_size = batch_size, shuffle = True)
print(len(train_loader), len(test_loader))

model = GNN_time(node_feature = 2, n_hidden = 128, out_node_feature = 128, out_feature = 1, dropout = 0.2)

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

class MAPE(nn.Module):
    def __init__(self):
        super().__init__()
        
    def forward(self, x, y):
        #return torch.mean(torch.pow((x - y), 2) / torch.pow(y, 2))
        return abs(x - y) / y

loss_func = MAPE()
optimizer = Adam(model.parameters(), lr=5e-4, weight_decay=1e-4)

model = model.to(device)

model.train()

for epoch in range(20):
    running_loss = 0.0
    for i, batch in enumerate(train_loader):

        loss = torch.tensor(0.0)

        # batch = Data(x=batch.x, edge_index=torch.tensor(edge_idx[i]), \
        # edge_attr=torch.tensor(edge_attr[i]), y=batch.y)
        optimizer.zero_grad()
        batch = batch.to(device)
        res = model(batch)

        #try
        #try_ground = torch.tensor(batch.y[3])

        loss = loss_func(res, batch.y[3].reshape(batch_size, -1))

        loss.backward()
        optimizer.step()
        loss = loss.to("cpu")

        running_loss += loss.detach().item()

        if i % 100 == 99:    # print every 2000 mini-batches
            print('[%d, %5d] loss: %.3f' %
                  (epoch, i, running_loss / 100))
            running_loss = 0.0

        # del batch, res, loss
        # gc.collect()
        # torch.cuda.empty_cache()

    print(f"epoch {epoch} done!")



# cuda.select_device(0)
# cuda.close()
# cuda.select_device(0)

model.eval()

total_loss = 0
for i, data in enumerate(test_loader):
    #data.x = data.x / data_len
    # data = Data(x=data.x, edge_index=torch.tensor(edge_idx[i]), \
    # edge_attr=torch.tensor(edge_attr[i]), y=data.y)
    # print(len(data.x), len(data.edge_index[0]))
    data = data.to(device)
    res = model(data)

    #try_ground = torch.tensor(data.y[3])

    if (i == 0):
        print(res)
        print(data.y[3])

    loss = loss_func(res, data.y[3].reshape(batch_size, -1))
    total_loss += loss.detach().item()

    # del data, res, loss
    # gc.collect()
    # torch.cuda.empty_cache()

# cuda.select_device(0)
# cuda.close()
# cuda.select_device(0)

print(len(test_loader))
total_loss /= len(test_loader)
print(total_loss)

# _, pred = res.max(dim=1)
# correct = float (pred.eq(data.y).sum().item())
# acc = correct / data.val_mask.sum().item()
# print("当前运行：{}，训练集精度是：{:.4f}".format(epoch,acc))
