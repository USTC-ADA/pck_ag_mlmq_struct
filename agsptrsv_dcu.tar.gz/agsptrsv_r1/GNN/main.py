from GNN_draw import draw_graph
from GNN_read import read_data
import sys

if (len(sys.argv) != 2):
    print("Usage: python main.py {input file}")

num_node, num_edge, node_feature, edge_data, label = read_data(sys.argv[1])

draw_graph("GNN/test_out.png", num_node, num_edge, node_feature, edge_data)

# print(num_node, num_edge)
# print(node_feature)
# print(edge_data)
