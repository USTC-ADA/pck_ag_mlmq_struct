from GNN_read import read_data
from GNN_draw import draw_graph

from SpTRSV_dataset import SpTRSVDataset

import sys

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.optim import Adam
from torch_geometric.data import Data
from torch_geometric.loader import DataLoader
import math
from math import log

from model import GCN

if (len(sys.argv) != 2):
    print("Usage: python main.py {input dir}")

dataset = SpTRSVDataset(sys.argv[1])

batch_size = 1

loader = DataLoader(dataset, batch_size = batch_size, shuffle = True)

# print(loader.batch[0].x)
# print(dataset[0].y.size(0))

model = GCN(node_feature = 1, n_hidden = 128, out_node_feature = 32, out_feature = 1, dropout = 0.2)

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

class MAPE(nn.Module):
    def __init__(self):
        super().__init__()
        
    def forward(self, x, y):
        #return torch.mean(torch.pow((x - y), 2) / torch.pow(y, 2))
        return abs(x - y) / y

loss_func = MAPE()
optimizer = Adam(model.parameters(), lr=2e-4, weight_decay=1e-4)

model = model.to(device)

model.train()

# min_try = 9999999
# max_try = -1
# y = []
# for i, batch in enumerate(loader):
#     try_ground = torch.tensor( \
#     float(torch.sum(batch.x, dim=0)) \
#     ).to(device)
#     if (try_ground.item() > max_try):
#         max_try = try_ground.item()
#     if (try_ground.item() < min_try):
#         min_try = try_ground.item()
# data_len = max_try - min_try
# print(data_len)

# print(dataset[0])

edge_attr = []
edge_idx = []
for i in range(len(dataset)):
    edge_attr.append([])
    for j in range(len(dataset[i].edge_index[0])):
        edge_attr[i].append([1.0, 0.0])
    i1 = dataset[i].edge_index[0].tolist()
    i2 = dataset[i].edge_index[1].tolist()
    #print(i1)
    for j in range(len(dataset[i].x) - 1):
        i1.append(j)
        i2.append(j+1)
        edge_attr[i].append([0.0, 1.0])
    edge_idx.append(torch.tensor([i1, i2]))
    #dataset[i].edge_index[0].append(j)
    #dataset[i].edge_index[0].append(j + 1)

# print(edge_idx[0])
# print(edge_attr[0])
#exit(0)
# for data in loader:
#     data.x = data.x / data_len

for epoch in range(40):
    running_loss = 0.0
    for i, batch in enumerate(dataset):
        if (i == 0):
            print(torch.sum(batch.x, dim=0))
            #print(batch.x)
            try_ground = torch.tensor( \
            float(torch.sum(batch.x, dim=0)) \
            )
            try_ground = batch.y[3].clone
            print(try_ground)

        loss = torch.tensor(0.0)
        if (batch.edge_index.size(1) > 0):
            batch = Data(x=batch.x, edge_index=torch.tensor(edge_idx[i]), \
            edge_attr=torch.tensor(edge_attr[i]), y=batch.y)

            optimizer.zero_grad()
            batch = batch.to(device)
            res = model(batch)

            #try
            #try_ground = torch.tensor(float(torch.sum(batch.x, dim=0)))
            try_ground = torch.tensor(batch.y[3])
            # try_ground = torch.tensor( \
            # (log(float(torch.sum(batch.x, dim=0)) - min_try )/data_len) \
            # ).to(device)
            #res = res.to('cpu')
            #input("Press Enter to continue...")

            loss = loss_func(res, try_ground.reshape(batch_size, -1))
            # print(res)
            # print(try_ground)
            # print(loss)
            #loss = F.nll_loss(res, batch.y[0].reshape(batch_size, -1))
            loss.backward()
            optimizer.step()
            loss = loss.to("cpu")

        #print(loss)
        # print statistics
        running_loss += loss.item()

        if i % 100 == 99:    # print every 2000 mini-batches
            print('[%d, %5d] loss: %.3f' %
                  (epoch, i, running_loss / 100))
            running_loss = 0.0
    print(f"epoch {epoch} done!")

model.eval()

total_loss = 0
for i, data in enumerate(dataset):
    if (data.edge_index.size(1) > 0):
        #data.x = data.x / data_len
        data = Data(x=data.x, edge_index=torch.tensor(edge_idx[i]), \
        edge_attr=torch.tensor(edge_attr[i]), y=data.y)
        data = data.to(device)
        #data.x = data.x / data_len
        res = model(data)

        #try_ground = torch.tensor(float(torch.sum(data.x, dim=0)))
        try_ground = torch.tensor(data.y[3])

        if (i == 0):
            print(res)
            print(try_ground)

        #try
        #try_ground = batch.x.size(0)
        #if ()
        #try_ground = torch.tensor( \
        #(float(torch.sum(batch.x, dim=0)-min_try)/data_len) \
        #).to(device)
        #print("pred_y", res[0])
        #print("y", data.y[3])
        #loss = loss_func(res, data.y[3].reshape(batch_size, -1))
        #loss = abs(res[0] - data.y[3]) / data.y[3]
        #loss = abs(res[0] - try_ground) / data.y[3]
        loss = abs(res[0] - try_ground) / try_ground
        total_loss += loss

print(len(dataset))
total_loss /= len(dataset)
print(total_loss.item())

_, pred = res.max(dim=1)
correct = float (pred.eq(data.y).sum().item())
# acc = correct / data.val_mask.sum().item()
# print("当前运行：{}，训练集精度是：{:.4f}".format(epoch,acc))
