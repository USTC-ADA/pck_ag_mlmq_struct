from GNN_read import read_data
from GNN_draw import draw_graph

from SpTRSV_dataset import SpTRSVDataset_ex

import sys

import torch
import torch.nn as nn
import torch.nn.functional as F
import math
from torch.optim import Adam
from torch_geometric.data import Data
from torch_geometric.loader import DataLoader

from model import GCN_rblock

if (len(sys.argv) != 2):
    print("Usage: python main.py {input dir}")

dataset = SpTRSVDataset_ex(sys.argv[1])

batch_size = 1

loader = DataLoader(dataset, batch_size = batch_size, shuffle = True)

model = GCN_rblock(node_feature = 1, n_hidden = 128, out_node_feature = 32, out_feature = 6, dropout = 0.5)

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

class MAPE(nn.Module):
    def __init__(self):
        super().__init__()
        
    def forward(self, x, y):
        return torch.mean(torch.pow((x - y), 2) / torch.pow(y, 2))

#loss_func = MAPE()
loss_func = nn.CrossEntropyLoss()
loss_func2 = nn.MSELoss(reduction="mean")

optimizer = Adam(model.parameters(), lr=2e-3, weight_decay=5e-5)

model = model.to(device)

model.train()

for epoch in range(10):
    running_loss = 0.0
    for i, batch in enumerate(loader):
        loss = torch.tensor(0.0)

        optimizer.zero_grad()
        batch = batch.to(device)

        #print(batch.x.size(), batch.edge_index.size(), batch.edge_attr.size())

        res = model(batch)

        #res = res.to('cpu')

            # y = F.one_hot(torch.tensor(int(batch.y[0])), num_classes=3)
            # y = y.float()
        # print(res)
        # print(loss_func(res.to('cpu'), torch.tensor(0).reshape(-1)))
        # print(loss_func(res.to('cpu'), torch.tensor(1).reshape(-1)))
        # print(loss_func(res.to('cpu'), torch.tensor(2).reshape(-1)))
        # input("Wait")
        #target = batch.y[4:7].reshape(1, -1)
        #target = torch.softmax(target, dim = 1)#.to(device)
        target = torch.tensor(math.log2(batch.y[2])).to(device)
        #target = torch.tensor(1).to(device)

        #print(res)
        #print(batch.y[2], target.long())

        loss = loss_func(res, target.long().reshape(-1))

        loss.backward()
        optimizer.step()

        # print statistics
        running_loss += loss.item()
        if i % 100 == 99:    # print every 2000 mini-batches
            print('[%d, %5d] loss: %.3f' %
                  (epoch, i, running_loss / 100))
            running_loss = 0.0
    print('====================')

stat = torch.zeros(6)
total_accuracy = 0
for i, data in enumerate(loader):
    if (data.edge_index.size(1) > 0):
        data = data.to(device)
        res = model(data)

        #res = res.to('cpu')

        target = torch.tensor(math.log2(data.y[2])).to(device)

        if (target == torch.argmax(res)):
            total_accuracy += 1

        pos = int(target.to("cpu"))
        stat[pos] += 1

print(stat)
print("Accuracy: ", 1.0 * total_accuracy / len(dataset))